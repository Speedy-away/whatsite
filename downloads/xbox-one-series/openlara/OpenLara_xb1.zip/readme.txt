Instruction:

STEP 1: Create empty folder and
for original PC, PSX and Sega Saturn CD version owners
    copy data from your CD into [your_folder]
    (! to extract content from PSX CD images please use this tool https://github.com/m35/jpsxdec !)
for ported android version owners
    unzip data file /sdcard/obb/com.squareenix.tombraider1classic/main.42.com.squareenix.tombraider1classic.obb into [your_folder]
for Steam/GOG version owners
    go to ..\Steam\steamapps\common\Tomb Raider (I)\ and run dosbox.exe
    enter these commands
        mount C .
        imgmount d ".\game.dat" -t iso -fs iso
        xcopy D:\DATA\ C:\DATA\
    after that you'll get level files in the new "DATA" folder copy them into [your_folder]
for advanced users
    copy all game folders into "[your_folder]/"
    copy audiotrack files (track_*.ogg, track_*.mp3) into "[your_folder]/audio/"
	
STEP 2: use zip to compress !!! WITHOUT COMPRESSION !!! content of this folder into content.zip archive
for example: http://xproger.info/projects/OpenLara/files/content.zip

STEP 3: switch your Xbox One into Developer Mode (google for it)

STEP 4: in the Dev Home dashboard you need to setup home network and login into your user account

STEP 5: open https://xboxone:11443/ from PC and follow the video instructions https://youtu.be/fno3aqPOGao

STEP 6: run OpenLara from Dev Home

Feedback:
    bug reports : https://github.com/XProger/OpenLara/issues
    questions   : https://www.facebook.com/OpenLaraTR
