# Ymir UWP 0.4.2.1 (x64)

Sega Saturn emulator for Xbox Series X|S (Dev Mode) and Windows 10/11.

## Xbox (Dev Mode)

1. Open the Device Portal in a browser: `https://<xbox-ip>:11443` (Dev Home -> Remote Access settings).
2. *Home* -> *My games & apps* -> **Add** -> select `ymir-sdl3_0.4.2.1_x64_RelWithDebInfo.msix` -> **Next**.
3. Add the dependency `Dependencies\x64\Microsoft.VCLibs.x64.14.00.appx` -> **Start**.
4. In Dev Home, select the Ymir tile -> **View** button -> *View details* -> **App type: Game**.
   (The default "App" type limits the app to 1 GB of RAM and part of the GPU.)
5. Launch Ymir from its tile and use the Welcome screen to select the Saturn BIOS and games folder. A BIOS selected
   from another drive is copied into the app profile. Alternatively, create `Ymir\roms\ipl\` at the root of an
   NTFS USB drive and put the BIOS there. The drive needs permissions for UWP apps; on a PC, as admin:
   `icacls E:\ /grant "*S-1-15-2-1:(OI)(CI)F" /T` (replace `E:` with the drive letter).
   Without a USB `Ymir` folder, the profile is stored in the app's LocalState folder, reachable through the
   Device Portal file explorer: `LocalAppData\<package family>\LocalState\StrikerX3\Ymir\`.
6. The Shell menus are gamepad-navigable; no mouse or keyboard is required. Press A to select and B to go back.
7. Optional: Settings -> Video -> enable **Use hardware acceleration** (Direct3D 12 renderer).

Log file: `LocalState\StrikerX3\Ymir\ymir-uwp.log`.

## Windows 10/11

1. Enable Developer Mode (Settings -> System -> For developers).
2. Right-click `Install.ps1` -> *Run with PowerShell*. It installs the certificate (asks for elevation), the
   dependencies and the app.
3. Launch Ymir from the Start menu.
