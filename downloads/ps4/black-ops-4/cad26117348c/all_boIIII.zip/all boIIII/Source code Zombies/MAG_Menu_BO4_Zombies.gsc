
#using scripts\core_common\callbacks_shared;
#using scripts\core_common\system_shared;
#using scripts\core_common\clientfield_shared;
#using scripts\core_common\flag_shared;
#using scripts\core_common\ai\zombie_utility;
#using scripts\zm_common\zm_powerups;
#using scripts\zm_common\zm_perks;
#using scripts\zm_common\zm_magicbox;
#using scripts\zm_common\zm_round_logic;
#using scripts\zm_common\zm_score;
#using scripts\core_common\rank_shared;
#using scripts\core_common\player\player_stats;
#using scripts\zm_common\zm_stats;

#namespace clientids_shared;

function autoexec __init__system__()
{
    system::register(#"clientids_shared", &__init__, undefined, undefined);
}

function __init__()
{
    callback::on_start_gametype(&mag_level_init);
    callback::on_connect(&mag_on_connect);
    callback::on_spawned(&mag_on_spawned);
}


function mag_level_init()
{
    level.mag_version = "Zombies v1.2";
}

function mag_on_connect()
{
    self endon(#"disconnect");
    if (!isdefined(level.mag_version))
        level.mag_version = "Zombies v1.2";
    self mag_setup();
    if (!self.mag.buttons_started)
    {
        self.mag.buttons_started = 1;
        self thread mag_buttons();
    }
}

function mag_on_spawned()
{
    self endon(#"disconnect");
    if (!isdefined(self.mag))
        self mag_setup();
    if (!self.mag.buttons_started)
    {
        self.mag.buttons_started = 1;
        self thread mag_buttons();
    }

    // Si le joueur est mort menu ouvert, on restaure les armes avant de reappliquer les options.
    if (self.mag.open)
        self mag_close();

    if (!self.mag.welcome)
    {
        self.mag.welcome = 1;
        wait 2;
        self iprintlnbold("^1MAG ^7Zombies Menu ^2BO4 ^7- Dev By ^1UrBaaZz ^7& ^5ZERTY");
        if (self.mag.access)
            self iprintln("^1MAG ^7Menu : ^3[{+frag}] + [{+usereload}]");
        self iprintln("Discord server: discord.gg/FYHewFgZkb");
    }

    if (self mag_tog("god"))
        self enableinvulnerability();
    if (self mag_tog("third"))
        self setclientthirdperson(1);
    if (self mag_tog("sprint"))
        self setperk(#"specialty_unlimitedsprint");
    if (isdefined(self.mag.speed) && self.mag.speed > 1)
        self setmovespeedscale(self.mag.speed);
}

function mag_setup()
{
    if (isdefined(self.mag))
        return;
    self.mag = spawnstruct();
    self.mag.open = 0;
    self.mag.busy = 0;
    self.mag.welcome = 0;
    self.mag.menu = "main";
    self.mag.parent = "main";
    self.mag.cursor = [];
    self.mag.opts = [];
    self.mag.tog = [];
    // 3 lignes visibles par defaut ; 4 est la limite maximale.
    self.mag.lines = 3;
    self.mag.bold = 0;
    self.mag.drawn = 0;
    self.mag.speed = 1;
    self.mag.theme = 0;
    self.mag.access = self ishost();
    self.mag.host = self ishost();
    self.mag.buttons_started = 0;
    self.mag.target = undefined;
    self.mag.ufo_on = 0;
    self.mag.ufo = undefined;
    self.mag.score_step = 1000;
    self.mag.stat_step = 100;
}

function mag_tog(key)
{
    if (!isdefined(self.mag) || !isdefined(self.mag.tog[key]))
        return 0;
    return self.mag.tog[key];
}


function mag_buttons()
{
    self endon(#"disconnect");
    for (;;)
    {
        if (!self.mag.open)
        {
            if (self.mag.access && self fragbuttonpressed() && self usebuttonpressed())
            {
                self mag_open();
                wait 0.4;
            }
        }
        else if (!self.mag.busy)
        {
            if (self adsbuttonpressed() || self actionslotonebuttonpressed())
            {
                self mag_scroll(-1);
                wait 0.14;
            }
            else if (self attackbuttonpressed() || self actionslottwobuttonpressed())
            {
                self mag_scroll(1);
                wait 0.14;
            }
            else if (self usebuttonpressed())
            {
                self mag_select();
                wait 0.25;
            }
            else if (self stancebuttonpressed())
            {
                self mag_back();
                wait 0.25;
            }
        }
        waitframe(1);
    }
}


function mag_theme_code(index)
{
    if (index == 1)
        return "^5";
    if (index == 2)
        return "^2";
    if (index == 3)
        return "^6";
    if (index == 4)
        return "^3";
    return "^1";
}

function mag_label(o)
{
    s = o.label;
    if (isdefined(o.tog))
    {
        if (self mag_tog(o.tog))
            s = s + " ^2[ON]";
        else
            s = s + " ^1[OFF]";
    }
    return s;
}

function mag_print(text)
{
    if (self.mag.bold)
        self iprintlnbold(text);
    else
        self iprintln(text);
}

function mag_draw()
{
    if (!self.mag.open)
        return;

    self.mag.drawn = gettime();
    n = self.mag.lines;
    if (!isdefined(n) || n < 1)
        n = 3;
    if (n > 4)
        n = 4;

    total = self.mag.opts.size;
    cur = self mag_cur();

    start = 0;
    if (cur >= n)
        start = cur - n + 1;
    maxstart = total - n;
    if (maxstart < 0)
        maxstart = 0;
    if (start > maxstart)
        start = maxstart;
    if (start < 0)
        start = 0;

    self mag_clear();

    c = mag_theme_code(self.mag.theme);
    self mag_print(c + "[{+frag}]MAG ^7Zombies [{+speed_throw}] ^3" + self.mag.title_text + " ^7" + (cur + 1) + "/" + total);
    for (i = 0; i < n; i++)
    {
        idx = start + i;
        if (idx >= total)
            self mag_print("^7 ");
        else if (idx == cur)
            self mag_print(c + "[{+usereload}] > ^7" + self mag_label(self.mag.opts[idx]));
        else
            self mag_print("^7    " + self mag_label(self.mag.opts[idx]));
    }
}

function mag_clear()
{
    for (i = 0; i < self.mag.lines + 6; i++)
        self mag_print(" ");
}

function mag_refresh()
{
    self endon(#"disconnect", #"mag_closed");
    for (;;)
    {
        wait 0.25;
        if (!self.mag.open)
            return;
        delay = 2500;
        if (self.mag.bold)
            delay = 1500;
        if (!self.mag.busy && gettime() - self.mag.drawn > delay)
            self mag_draw();
    }
}


function mag_cur()
{
    if (!isdefined(self.mag.cursor[self.mag.menu]))
        self.mag.cursor[self.mag.menu] = 0;
    return self.mag.cursor[self.mag.menu];
}

function mag_open()
{
    if (!isalive(self))
        return;
    self.mag.open = 1;
    self disableweapons();
    self mag_load(self.mag.menu);
    self thread mag_refresh();
}

function mag_close()
{
    self.mag.open = 0;
    self notify(#"mag_closed");
    self enableweapons();
    self mag_clear();
    self iprintln("^1MAG ^7Menu closed");
}

function mag_scroll(dir)
{
    total = self.mag.opts.size;
    if (total == 0)
        return;
    cur = self mag_cur() + dir;
    if (cur < 0)
        cur = total - 1;
    if (cur >= total)
        cur = 0;
    self.mag.cursor[self.mag.menu] = cur;
    self mag_draw();
}

function mag_select()
{
    cur = self mag_cur();
    if (cur >= self.mag.opts.size)
        return;
    o = self.mag.opts[cur];
    if (isdefined(o.func))
    {
        self.mag.busy = 1;
        self [[ o.func ]](o.a1, o.a2);
        self.mag.busy = 0;
    }
    self mag_draw();
}

function mag_back()
{
    if (self.mag.menu == "main")
    {
        self mag_close();
        return;
    }
    self mag_load(self.mag.parent);
}

function mag_go(menu, unused)
{
    self mag_load(menu);
}

function mag_add(label, func, a1, a2, tog)
{
    o = spawnstruct();
    o.label = label;
    o.func = func;
    o.a1 = a1;
    o.a2 = a2;
    o.tog = tog;
    self.mag.opts[self.mag.opts.size] = o;
}

function mag_load(menu)
{
    self.mag.menu = menu;
    self.mag.opts = [];
    self.mag.parent = "main";
    self mag_build(menu);
    if (self.mag.opts.size == 0)
        self mag_add("No options available", undefined);
    if (self mag_cur() >= self.mag.opts.size)
        self.mag.cursor[menu] = 0;
    self mag_draw();
}

function mag_build(menu)
{
    switch (menu)
    {
        case "main":
            self.mag.title_text = "Main Menu";
            self mag_add("Self Menu", &mag_go, "self");
            self mag_add("Zombie Menu", &mag_go, "zombies");
            self mag_add("Weapons Menu", &mag_go, "weapons");
            self mag_add("Perks Menu", &mag_go, "perks");
            self mag_add("Powerups Menu", &mag_go, "powerups");
            self mag_add("Modify Score Menu", &mag_go, "score");
            self mag_add("Mystery Box Menu", &mag_go, "box");
            self mag_add("Teleport Menu", &mag_go, "teleport");
            self mag_add("Message Menu", &mag_go, "messages");
            self mag_add("Fun Menu", &mag_go, "fun");
            self mag_add("Account Menu", &mag_go, "account");
            if (self.mag.host)
            {
                self mag_add("Players List", &mag_go, "players");
                self mag_add("Co-op Controls", &mag_go, "coop");
                self mag_add("Restart Zombies Match", &mag_restart);
            }
            self mag_add("Menu Settings", &mag_go, "settings");
            self mag_add("discord.gg/FYHewFgZkb", &mag_close_opt);
            break;

        case "self":
            self.mag.title_text = "Self Menu";
            self mag_add("God Mode", &mag_god, undefined, undefined, "god");
            self mag_add("Infinite Ammo", &mag_ammo, undefined, undefined, "ammo");
            self mag_add("Max Ammo", &mag_maxammo);
            self mag_add("UFO Binds ([{+stance}] + [{+melee}])", &mag_ufo, undefined, undefined, "ufo");
            self mag_add("Third Person", &mag_third, undefined, undefined, "third");
            self mag_add("Unlimited Sprint", &mag_sprint, undefined, undefined, "sprint");
            self mag_add("Super Jump", &mag_superjump, undefined, undefined, "sjump");
            self mag_add("Super Speed (x1/x2/x3)", &mag_speed);
            self mag_add("Auto Heal", &mag_autoheal, undefined, undefined, "autoheal");
            self mag_add("Heal Now", &mag_heal);
            self mag_add("Give All Perks", &mag_all_perks);
            self mag_add("Suicide", &mag_suicide);
            break;

        case "zombies":
            self.mag.title_text = "Zombie Menu";
            self mag_add("Kill All Zombies", &mag_kill_all_zombies);
            self mag_add("Teleport Zombies In Front", &mag_teleport_zombies);
            self mag_add("Zombie Conveyor (loop)", &mag_zombie_position_toggle, undefined, undefined, "zpos");
            self mag_add("No Target", &mag_notarget, undefined, undefined, "notarget");
            self mag_add("Kill Aura", &mag_kill_aura, undefined, undefined, "killaura");
            self mag_add("Set Round", &mag_go, "rounds");
            self mag_add("Open All Doors / Debris", &mag_open_all_doors);
            break;

        case "rounds":
            self.mag.title_text = "Set Round";
            self.mag.parent = "zombies";
            self mag_add("Round 5", &mag_round_edit, 5);
            self mag_add("Round 10", &mag_round_edit, 10);
            self mag_add("Round 20", &mag_round_edit, 20);
            self mag_add("Round 30", &mag_round_edit, 30);
            self mag_add("Round 50", &mag_round_edit, 50);
            self mag_add("Round 100", &mag_round_edit, 100);
            self mag_add("Round 255", &mag_round_edit, 255);
            self mag_add("Round 999", &mag_round_edit, 999);
            break;

        case "weapons":
            self.mag.title_text = "Zombies Weapons";
            self.mag.parent = "main";
            self mag_add("Weapons List", &mag_go, "weapons_list");
            self mag_add("Give Max Ammo", &mag_maxammo);
            self mag_add("Take Current Weapon", &mag_take_weapon);
            self mag_add("Drop Current Weapon", &mag_drop_weapon);
            self mag_add("Zombies Camos", &mag_go, "camos");
            break;

        case "weapons_list":
            self.mag.title_text = "Weapons List";
            self.mag.parent = "weapons";
            self mag_add("Assault Rifles", &mag_go, "w_ar");
            self mag_add("Submachine Guns", &mag_go, "w_smg");
            self mag_add("Tactical Rifles", &mag_go, "w_tr");
            self mag_add("Light Machine Guns", &mag_go, "w_lmg");
            self mag_add("Sniper Rifles", &mag_go, "w_sniper");
            self mag_add("Pistols", &mag_go, "w_pistol");
            self mag_add("Shotguns", &mag_go, "w_shotgun");
            self mag_add("Launchers & Specials", &mag_go, "w_special");
            self mag_add("Wonder Weapons", &mag_go, "w_wonder");
            break;

        case "w_ar":
            self.mag.title_text = "Assault Rifles";
            self.mag.parent = "weapons_list";
            self mag_add("ICR-7", &mag_give, #"ar_accurate_t8");
            self mag_add("Maddox RFB", &mag_give, #"ar_fastfire_t8");
            self mag_add("Rampart 17", &mag_give, #"ar_damage_t8");
            self mag_add("Vapr-XKG", &mag_give, #"ar_stealth_t8");
            self mag_add("KN-57", &mag_give, #"ar_standard_t8");
            self mag_add("Hitchcock M9", &mag_give, #"ar_modular_t8");
            self mag_add("Swordfish", &mag_give, #"ar_galil_t8");
            self mag_add("Peacekeeper", &mag_give, #"ar_peacekeeper_t8");
            self mag_add("Grav", &mag_give, #"ar_mg1909_t8");
            self mag_add("ABR 223", &mag_give, #"ar_an94_t8");
            break;

        case "w_smg":
            self.mag.title_text = "Submachine Guns";
            self.mag.parent = "weapons_list";
            self mag_add("MX9", &mag_give, #"smg_standard_t8");
            self mag_add("Cordite", &mag_give, #"smg_fastfire_t8");
            self mag_add("GKS", &mag_give, #"smg_accurate_t8");
            self mag_add("Spitfire", &mag_give, #"smg_handling_t8");
            self mag_add("Saug 9mm", &mag_give, #"smg_capacity_t8");
            self mag_add("Switchblade X9", &mag_give, #"smg_folding_t8");
            self mag_add("MP40", &mag_give, #"smg_mp40_t8");
            self mag_add("Escargot", &mag_give, #"smg_thompson_t8");
            break;

        case "w_tr":
            self.mag.title_text = "Tactical Rifles";
            self.mag.parent = "weapons_list";
            self mag_add("Auger DMR", &mag_give, #"tr_powersemi_t8");
            self mag_add("Swordfish", &mag_give, #"tr_longburst_t8");
            self mag_add("ABR 223", &mag_give, #"tr_midburst_t8");
            self mag_add("Essex Model 07", &mag_give, #"tr_leveraction_t8");
            self mag_add("M16", &mag_give, #"tr_damageburst_t8");
            self mag_add("Daemon 3XB", &mag_give, #"tr_flechette_t8");
            break;

        case "w_lmg":
            self.mag.title_text = "Light Machine Guns";
            self.mag.parent = "weapons_list";
            self mag_add("Titan", &mag_give, #"lmg_standard_t8");
            self mag_add("VKM 750", &mag_give, #"lmg_heavy_t8");
            self mag_add("Hades", &mag_give, #"lmg_spray_t8");
            self mag_add("Zweihander", &mag_give, #"lmg_double_t8");
            self mag_add("Tigershark", &mag_give, #"lmg_stealth_t8");
            break;

        case "w_sniper":
            self.mag.title_text = "Sniper Rifles";
            self.mag.parent = "weapons_list";
            self mag_add("Paladin HB50", &mag_give, #"sniper_powerbolt_t8");
            self mag_add("Outlaw", &mag_give, #"sniper_fastrechamber_t8");
            self mag_add("Koshka", &mag_give, #"sniper_quickscope_t8");
            self mag_add("SDM", &mag_give, #"sniper_powersemi_t8");
            self mag_add("Locus", &mag_give, #"sniper_locus_t8");
            self mag_add("Vendetta", &mag_give, #"sniper_damagesemi_t8");
            self mag_add("Mini 14", &mag_give, #"sniper_mini14_t8");
            break;

        case "w_pistol":
            self.mag.title_text = "Pistols";
            self.mag.parent = "weapons_list";
            self mag_add("Mozu", &mag_give, #"pistol_revolver_t8");
            self mag_add("RK 7 Garrison", &mag_give, #"pistol_burst_t8");
            self mag_add("Strife", &mag_give, #"pistol_standard_t8");
            self mag_add("Welling", &mag_give, #"pistol_topbreak_t8");
            self mag_add("SG12 (full auto)", &mag_give, #"pistol_fullauto_t8");
            break;

        case "w_shotgun":
            self.mag.title_text = "Shotguns";
            self.mag.parent = "weapons_list";
            self mag_add("MOG 12", &mag_give, #"shotgun_pump_t8");
            self mag_add("SG12", &mag_give, #"shotgun_semiauto_t8");
            self mag_add("Rampage", &mag_give, #"shotgun_fullauto_t8");
            self mag_add("Argus", &mag_give, #"shotgun_precision_t8");
            self mag_add("Trenchgun", &mag_give, #"shotgun_trenchgun_t8");
            break;

        case "w_special":
            self.mag.title_text = "Launchers & Specials";
            self.mag.parent = "weapons_list";
            self mag_add("Hellion Salvo", &mag_give, #"launcher_standard_t8");
            self mag_add("Ballistic Knife", &mag_give, #"special_ballisticknife_t8_dw");
            self mag_add("Crossbow", &mag_give, #"special_crossbow_t8");
            self mag_add("Death Machine", &mag_give, #"minigun");
            self mag_add("Combat Knife", &mag_give, #"knife_loadout");
            self mag_add("Bowie Knife", &mag_give, #"melee_bowie");
            self mag_add("Default Weapon", &mag_give, #"defaultweapon");
            break;

        case "w_wonder":
            self.mag.title_text = "Wonder Weapons";
            self.mag.parent = "weapons_list";
            self mag_add("Ray Gun", &mag_give, #"ray_gun");
            self mag_add("Winter's Howl", &mag_give, #"ww_freezegun_t8");
            self mag_add("Alistair's Folly", &mag_give, #"ww_random_ray_gun2");
            self mag_add("Chaos Theory", &mag_give, #"ww_random_ray_gun3");
            self mag_add("Hand of Ouranos", &mag_give, #"ww_hand_o");
            self mag_add("Hand of Hemera", &mag_give, #"ww_hand_h");
            self mag_add("Hand of Gaia", &mag_give, #"ww_hand_g");
            self mag_add("Hand of Charon", &mag_give, #"ww_hand_c");
            self mag_add("Apollo's Will", &mag_give, #"zhield_zpear_dw");
            self mag_add("Ballistic Shield", &mag_give, #"zhield_dw");
            break;

        case "camos":
            self.mag.title_text = "Zombies Camos";
            self.mag.parent = "weapons";
            self mag_add("Zombies Camo 1", &mag_camo_apply, 3);
            self mag_add("Zombies Camo 2", &mag_camo_apply, 6);
            self mag_add("Zombies Camo 3", &mag_camo_apply, 9);
            self mag_add("Zombies Camo 4", &mag_camo_apply, 12);
            self mag_add("Zombies Camo 5", &mag_camo_apply, 15);
            self mag_add("Zombies Camo 6", &mag_camo_apply, 18);
            self mag_add("Zombies Camo 7", &mag_camo_apply, 21);
            self mag_add("Zombies Camo 8", &mag_camo_apply, 24);
            self mag_add("Zombies Camo 9", &mag_camo_apply, 27);
            self mag_add("Zombies Camo 10", &mag_camo_apply, 30);
            self mag_add("Zombies Camo 11", &mag_camo_apply, 33);
            self mag_add("Zombies Camo 12", &mag_camo_apply, 36);
            self mag_add("Zombies Camo 13", &mag_camo_apply, 39);
            self mag_add("Zombies Camo 14", &mag_camo_apply, 42);
            break;

        case "perks":
            self.mag.title_text = "Give Zombie Perk";
            self.mag.parent = "main";
            self mag_add("Give All Perks", &mag_all_perks);
            self mag_add("Timeslip", &mag_give_perk, "specialty_cooldown");
            self mag_add("Quick Revive", &mag_give_perk, "specialty_quickrevive");
            self mag_add("Death Perception", &mag_give_perk, "specialty_awareness");
            self mag_add("Stamin-Up", &mag_give_perk, "specialty_staminup");
            self mag_add("Ethereal Razor", &mag_give_perk, "specialty_etherealrazor");
            self mag_add("Blood Wolf Bite", &mag_give_perk, "specialty_wolf_protector");
            self mag_add("Zombshell", &mag_give_perk, "specialty_zombshell");
            self mag_add("Blaze Phase", &mag_give_perk, "specialty_death_dash");
            self mag_add("Electric Cherry", &mag_give_perk, "specialty_electriccherry");
            self mag_add("Dying Wish", &mag_give_perk, "specialty_berserker");
            self mag_add("Stone Cold Stronghold", &mag_give_perk, "specialty_camper");
            self mag_add("Victorious Tortoise", &mag_give_perk, "specialty_shield");
            self mag_add("Deadshot Dealer", &mag_give_perk, "specialty_deadshot");
            self mag_add("Bandolier Bandit", &mag_give_perk, "specialty_extraammo");
            self mag_add("Winter's Wail", &mag_give_perk, "specialty_widowswine");
            self mag_add("Mule Kick", &mag_give_perk, "specialty_additionalprimaryweapon");
            self mag_add("PhD Slider", &mag_give_perk, "specialty_phdflopper");
            self mag_add("Secret Sauce", &mag_give_perk, "specialty_mystery");
            break;

        case "powerups":
            self.mag.title_text = "Zombie Powerups";
            self.mag.parent = "main";
            self mag_add("Max Ammo", &mag_give_powerup, "full_ammo");
            self mag_add("Fire Sale", &mag_give_powerup, "fire_sale");
            self mag_add("Bonus Points", &mag_give_powerup, "bonus_points_player");
            self mag_add("Free Perk", &mag_give_powerup, "free_perk");
            self mag_add("Nuke", &mag_give_powerup, "nuke");
            self mag_add("Full Power", &mag_give_powerup, "hero_weapon_power");
            self mag_add("Insta-Kill", &mag_give_powerup, "insta_kill");
            self mag_add("Double Points", &mag_give_powerup, "double_points");
            self mag_add("Carpenter", &mag_give_powerup, "carpenter");
            break;

        case "box":
            self.mag.title_text = "Mystery Box";
            self.mag.parent = "main";
            self mag_add("Box Prices", &mag_go, "boxprice");
            self mag_add("Teleport To Active Box", &mag_box_teleport);
            self mag_add("Show All Mystery Boxes", &mag_box_show_all);
            self mag_add("Freeze Active Box", &mag_box_freeze);
            break;

        case "boxprice":
            self.mag.title_text = "Set Box Price";
            self.mag.parent = "box";
            self mag_add("Default Price (950)", &mag_box_price, 950);
            self mag_add("Free Box", &mag_box_price, 0);
            self mag_add("Price 10", &mag_box_price, 10);
            self mag_add("Price 100", &mag_box_price, 100);
            self mag_add("Price 500", &mag_box_price, 500);
            self mag_add("Price 1000", &mag_box_price, 1000);
            break;

        case "teleport":
            self.mag.title_text = "Teleport Menu";
            self.mag.parent = "main";
            self mag_add("Teleport To Crosshair", &mag_tele_cross);
            self mag_add("Save Position", &mag_save_pos);
            self mag_add("Load Position", &mag_load_pos);
            self mag_add("Teleport Up (sky)", &mag_tele_sky);
            break;

        case "messages":
            self.mag.title_text = "Message Menu";
            self.mag.parent = "main";
            self mag_add("Hello World", &mag_msg, "^2Hello World !");
            self mag_add("MAG Menu", &mag_msg, "^1MAG ^7Menu ^2BO4");
            self mag_add("Free Palestine", &mag_msg, "^3Free Palestine");
            self mag_add("Fuck Israel", &mag_msg, "^1Fuck Israel");
            self mag_add("Hey brother are you gay?", &mag_msg, "^5Hey brother are you gay?");
            self mag_add("ggwp ez", &mag_msg, "^6ggwp ez !");
            self mag_add("Dev By UrBaaZz & ZERTY", &mag_msg, "^7Dev By ^1UrBaaZz ^7& ^5ZERTY");
            break;

        case "fun":
            self.mag.title_text = "Fun Menu";
            self.mag.parent = "main";
            self mag_add("Earthquake", &mag_quake);
            self mag_add("Spin Mode", &mag_spin, undefined, undefined, "spin");
            break;

        case "account":
            self.mag.title_text = "Account Menu";
            self.mag.parent = "main";
            self mag_add("Max Level (55)", &mag_acc_level55);
            self mag_add("Level 1000 (^1experimental^7)", &mag_acc_level1000);
            self mag_add("Plasma Loop", &mag_acc_plasma, undefined, undefined, "plasma");
            self mag_add("Complete Active Contracts", &mag_acc_contracts);
            self mag_add("Unlock All (lvl 55 required)", &mag_acc_unlock_all, undefined, undefined, "acc_unlock");
            self mag_add("Max Weapon Levels", &mag_acc_weapon_levels, undefined, undefined, "acc_wlevels");
            self mag_add("Give Achievements", &mag_acc_achievements, undefined, undefined, "acc_achiev");
            self mag_add("Stats Menu", &mag_go, "stats");
            break;

        case "stats":
            self.mag.title_text = "Stats Menu";
            self.mag.parent = "account";
            self mag_add("Step : ^3" + self.mag.stat_step + " ^7(change)", &mag_acc_stat_step);
            names = array("Total Games Played", "Highest Round", "Most Kills", "Most Headshots", "Round");
            for (i = 0; i < names.size; i++)
                self mag_add(names[i] + " : ^3" + self.mag.stat_step, &mag_acc_stat_edit, i);
            break;

        case "score":
            self.mag.title_text = "Modify Score";
            self.mag.parent = "main";
            self mag_add("Current : ^3" + self.score + " ^7points", undefined);
            self mag_add("Step : ^3" + self.mag.score_step + " ^7(change)", &mag_score_step);
            self mag_add("Add ^2+" + self.mag.score_step, &mag_score_add, 1);
            self mag_add("Remove ^1-" + self.mag.score_step, &mag_score_add, -1);
            self mag_add("Set Score : 0", &mag_score_set, 0);
            self mag_add("Set Score : 500", &mag_score_set, 500);
            self mag_add("Set Score : 10000", &mag_score_set, 10000);
            self mag_add("Set Score : 100000", &mag_score_set, 100000);
            self mag_add("Set Score : 1000000", &mag_score_set, 1000000);
            self mag_add("Set Score : 10000000", &mag_score_set, 10000000);
            break;

        case "players":
            self.mag.title_text = "Players List";
            self.mag.parent = "main";
            foreach (p in getplayers())
            {
                if (!isdefined(p) || p == self)
                    continue;
                s = p.name;
                if (isdefined(p.mag) && p.mag.access)
                    s = s + " ^2[MENU]";
                self mag_add(s, &mag_pick_player, p);
            }
            if (self.mag.opts.size == 0)
                self mag_add("No other players", undefined);
            else
            {
                self mag_add("^2Give Menu Access To All", &mag_access_all, 1);
                self mag_add("^1Remove Menu Access From All", &mag_access_all, 0);
            }
            break;

        case "player":
            self.mag.parent = "players";
            p = self.mag.target;
            if (!isdefined(p))
            {
                self.mag.title_text = "Player";
                self mag_add("Player unavailable", undefined);
                break;
            }
            self.mag.title_text = p.name;
            if (isdefined(p.mag) && p.mag.access)
                self mag_add("Menu Access : ^2YES", undefined);
            else
                self mag_add("Menu Access : ^1NO", undefined);
            self mag_add("Give Menu Access", &mag_p_access, p, 1);
            self mag_add("Remove Menu Access", &mag_p_access, p, 0);
            self mag_add("God Mode ON/OFF", &mag_p_god, p);
            self mag_add("Freeze/Unfreeze", &mag_p_freeze, p);
            self mag_add("Teleport Player To Me", &mag_p_tele_to_me, p);
            self mag_add("Teleport Me To Player", &mag_p_tele_me, p);
            self mag_add("Kill/Down Player", &mag_p_kill, p);
            break;

        case "coop":
            self.mag.title_text = "Co-op Controls";
            self.mag.parent = "main";
            self mag_add("God Mode ON For Others", &mag_all, "god");
            self mag_add("God Mode OFF For Others", &mag_all, "nogod");
            self mag_add("Infinite Ammo ON For Others", &mag_all, "ammo");
            self mag_add("Infinite Ammo OFF For Others", &mag_all, "noammo");
            self mag_add("Teleport All To Me", &mag_all, "tele");
            self mag_add("Freeze All Players", &mag_all, "freeze");
            self mag_add("Unfreeze All Players", &mag_all, "unfreeze");
            self mag_add("Kill/Down All Other Players", &mag_all, "kill");
            break;

        case "settings":
            self.mag.title_text = "Menu Settings";
            self.mag.parent = "main";
            self mag_add("Display: normal/bold", &mag_display);
            self mag_add("Theme: red", &mag_theme, 0);
            self mag_add("Theme: blue", &mag_theme, 1);
            self mag_add("Theme: green", &mag_theme, 2);
            self mag_add("Theme: magenta", &mag_theme, 3);
            self mag_add("Theme: yellow", &mag_theme, 4);
            if (self.mag.lines == 3)
                self mag_add("Lines shown : 3 ^2[ON]", &mag_set_lines, 3);
            else
                self mag_add("Lines shown : 3", &mag_set_lines, 3);
            if (self.mag.lines == 4)
                self mag_add("Lines shown : 4 ^2[ON]", &mag_set_lines, 4);
            else
                self mag_add("Lines shown : 4", &mag_set_lines, 4);
            break;
    }
}


function mag_close_opt(a, b)
{
    self mag_close();
}

function mag_msg(text, b)
{
    self mag_clear();
    self iprintlnbold(text);
    wait 1.25;
}

function mag_switch(key)
{
    self.mag.tog[key] = !self mag_tog(key);
    return self.mag.tog[key];
}

function mag_god(a, b)
{
    if (self mag_switch("god"))
    {
        self notify(#"mag_god_stop");
        self thread mag_god_loop();
        self iprintln("God Mode ^2ON");
    }
    else
    {
        self notify(#"mag_god_stop");
        self disableinvulnerability();
        self iprintln("God Mode ^1OFF");
    }
}

function mag_god_loop()
{
    self endon(#"disconnect", #"mag_god_stop");
    for (;;)
    {
        if (!self mag_tog("god"))
            return;
        self enableinvulnerability();
        wait 0.1;
    }
}

function mag_ammo(a, b)
{
    if (self mag_switch("ammo"))
    {
        self iprintln("Infinite Ammo ^2ON");
        self thread mag_ammo_loop();
    }
    else
    {
        self notify(#"mag_ammo_stop");
        self iprintln("Infinite Ammo ^1OFF");
    }
}

function mag_ammo_loop()
{
    self endon(#"disconnect", #"mag_ammo_stop");
    for (;;)
    {
        w = self getcurrentweapon();
        if (isdefined(w) && w != getweapon(#"none") && !(isdefined(w.isgadget) && w.isgadget))
        {
            self setweaponammoclip(w, w.clipsize);
            self givemaxammo(w);
        }
        wait 0.1;
    }
}

function mag_maxammo(a, b)
{
    foreach (w in self getweaponslist())
    {
        if (isdefined(w) && w != getweapon(#"none"))
            self givemaxammo(w);
    }
    self iprintln("Max Ammo ^2given");
}

function mag_third(a, b)
{
    if (self mag_switch("third"))
    {
        self setclientthirdperson(1);
        self iprintln("Third Person ^2ON");
    }
    else
    {
        self setclientthirdperson(0);
        self iprintln("Third Person ^1OFF");
    }
}

function mag_sprint(a, b)
{
    if (self mag_switch("sprint"))
    {
        self setperk(#"specialty_unlimitedsprint");
        self iprintln("Unlimited Sprint ^2ON");
    }
    else
    {
        self unsetperk(#"specialty_unlimitedsprint");
        self iprintln("Unlimited Sprint ^1OFF");
    }
}

function mag_superjump(a, b)
{
    if (self mag_switch("sjump"))
    {
        self thread mag_superjump_loop();
        self iprintln("Super Jump ^2ON");
    }
    else
    {
        self notify(#"mag_sjump_stop");
        self iprintln("Super Jump ^1OFF");
    }
}

function mag_superjump_loop()
{
    self endon(#"disconnect", #"mag_sjump_stop");
    was = 1;
    for (;;)
    {
        grounded = self isonground();
        if (was && !grounded && !self.mag.open)
        {
            v = self getvelocity();
            if (v[2] > 10)
            {
                for (k = 0; k < 3; k++)
                {
                    v = self getvelocity();
                    self setvelocity((v[0], v[1], 950));
                    waitframe(1);
                }
            }
        }
        was = self isonground();
        waitframe(1);
    }
}

function mag_speed(a, b)
{
    self.mag.speed++;
    if (self.mag.speed > 3)
        self.mag.speed = 1;
    self setmovespeedscale(self.mag.speed);
    self iprintln("Speed ^3x" + self.mag.speed);
}

function mag_heal(a, b)
{
    if (!isalive(self))
        return;
    self.health = self.maxhealth;
    self iprintln("Health ^2restored");
}

function mag_autoheal(a, b)
{
    if (self mag_switch("autoheal"))
    {
        self thread mag_autoheal_loop();
        self iprintln("Auto Heal ^2ON");
    }
    else
    {
        self notify(#"mag_heal_stop");
        self iprintln("Auto Heal ^1OFF");
    }
}

function mag_autoheal_loop()
{
    self endon(#"disconnect", #"mag_heal_stop");
    for (;;)
    {
        if (isalive(self) && isdefined(self.maxhealth) && self.health < self.maxhealth)
            self.health = self.maxhealth;
        wait 0.2;
    }
}

function mag_all_perks(a, b)
{
    self thread zm_perks::function_cc24f525();
    self iprintln("^2All Zombie Perks requested");
}

function mag_give_perk(perk, b)
{
    if (!isdefined(perk))
        return;
    if (self hasperk(perk))
    {
        self iprintln("Perk already active");
        return;
    }
    self thread zm_perks::wait_give_perk(perk);
    self iprintln("Perk ^2requested: ^3" + perk);
}

function mag_suicide(a, b)
{
    self mag_close();
    self suicide();
}


function mag_kill_all_zombies(a, b)
{
    if (!isdefined(level.zombie_team))
    {
        self iprintln("^1Zombie team unavailable");
        return;
    }
    level.zombie_total = 0;
    for (pass = 0; pass < 3; pass++)
    {
        zombies = GetAITeamArray(level.zombie_team);
        for (i = 0; i < zombies.size; i++)
        {
            if (isdefined(zombies[i]) && isalive(zombies[i]))
                zombies[i] DoDamage(zombies[i].health + 99, zombies[i].origin);
        }
    }
    self iprintln("All Zombies ^1eliminated");
}

function mag_teleport_zombies(a, b)
{
    if (!isdefined(level.zombie_team))
    {
        self iprintln("^1Zombie team unavailable");
        return;
    }
    forward = anglestoforward(self.angles);
    foreach (zombie in GetAITeamArray(level.zombie_team))
    {
        if (isdefined(zombie) && isalive(zombie))
            zombie ForceTeleport(self.origin + (forward[0] * 70, forward[1] * 70, forward[2] * 70));
    }
    self iprintln("Zombies teleported in front of you");
}

function mag_zombie_position_toggle(a, b)
{
    if (self mag_switch("zpos"))
    {
        self thread mag_zombie_position_loop();
        self iprintln("Zombie Conveyor ^2ON");
    }
    else
    {
        self notify(#"mag_zpos_stop");
        self iprintln("Zombie Conveyor ^1OFF");
    }
}

function mag_zombie_position_loop()
{
    self endon(#"disconnect", #"mag_zpos_stop");
    self endon(#"game_ended");
    for (;;)
    {
        if (!self mag_tog("zpos") || !isalive(self) || !isdefined(level.zombie_team))
        {
            wait 0.2;
            continue;
        }
        forward = anglestoforward(self.angles);
        foreach (zombie in GetAITeamArray(level.zombie_team))
        {
            if (isdefined(zombie) && isalive(zombie))
                zombie ForceTeleport(self.origin + (forward[0] * 70, forward[1] * 70, forward[2] * 70));
        }
        wait 0.2;
    }
}

function mag_notarget(a, b)
{
    if (self mag_switch("notarget"))
    {
        self.ignoreme = true;
        self iprintln("No Target ^2ON");
    }
    else
    {
        self.ignoreme = false;
        self iprintln("No Target ^1OFF");
    }
}

function mag_kill_aura(a, b)
{
    if (self mag_switch("killaura"))
    {
        self thread mag_kill_aura_loop();
        self iprintln("Kill Aura ^2ON");
    }
    else
    {
        self notify(#"mag_killaura_stop");
        self iprintln("Kill Aura ^1OFF");
    }
}

function mag_kill_aura_loop()
{
    self endon(#"disconnect", #"mag_killaura_stop");
    self endon(#"game_ended");
    for (;;)
    {
        zombies = GetAITeamArray(level.zombie_team);
        foreach (zombie in zombies)
        {
            if (isdefined(zombie) && isalive(zombie) && distanceSquared(zombie.origin, self.origin) < 150 * 150)
                zombie DoDamage(zombie.health + 1, self.origin, self, undefined, "MOD_EXPLOSIVE");
        }
        wait 0.05;
    }
}

function mag_round_edit(value, b)
{
    value = int(value);
    if (value < 1 || value > 9999)
    {
        self iprintln("^1Round value out of range");
        return;
    }
    zm_round_logic::set_round_number(value);
    self thread mag_kill_all_zombies();
    self iprintln("Round set to ^3" + value);
}

function mag_give_powerup(powerup, b)
{
    if (!isdefined(powerup))
        return;
    self zm_powerups::specific_powerup_drop(powerup, self.origin, undefined, undefined, undefined, 1);
    self iprintln("Powerup requested: ^3" + powerup);
}

function mag_open_all_doors(a, b)
{
    players = getplayers();
    if (players.size == 0)
    {
        self iprintln("^1No active player");
        return;
    }
    setdvar(#"zombie_unlock_all", 1);
    level flag::set("power_on");
    level clientfield::set("zombie_power_on", 1);

    power_trigs = getentarray("use_elec_switch", "targetname");
    foreach (trig in power_trigs)
    {
        if (isdefined(trig) && isdefined(trig.script_int))
        {
            level flag::set("power_on" + trig.script_int);
            level clientfield::set("zombie_power_on", trig.script_int + 1);
        }
    }

    zombie_doors = getentarray("zombie_door", "targetname");
    for (i = 0; i < zombie_doors.size; i++)
    {
        if (isdefined(zombie_doors[i]))
        {
            if (!(isdefined(zombie_doors[i].has_been_opened) && zombie_doors[i].has_been_opened))
                zombie_doors[i] notify(#"trigger", {#activator:players[0]});
            if (isdefined(zombie_doors[i].power_door_ignore_flag_wait) && zombie_doors[i].power_door_ignore_flag_wait)
                zombie_doors[i] notify(#"power_on");
        }
        waitframe(1);
    }

    zombie_airlock_doors = getentarray("zombie_airlock_buy", "targetname");
    for (i = 0; i < zombie_airlock_doors.size; i++)
    {
        if (isdefined(zombie_airlock_doors[i]))
            zombie_airlock_doors[i] notify(#"trigger", {#activator:players[0]});
        waitframe(1);
    }

    zombie_debris = getentarray("zombie_debris", "targetname");
    for (i = 0; i < zombie_debris.size; i++)
    {
        if (isdefined(zombie_debris[i]))
            zombie_debris[i] notify(#"trigger", {#activator:players[0]});
        waitframe(1);
    }
    level notify(#"open_sesame");
    wait 1;
    setdvar(#"zombie_unlock_all", 0);
    self iprintln("Doors / Debris ^2opened where supported by this map");
}


function mag_box_price(value, b)
{
    if (!isdefined(level.chests))
    {
        self iprintln("^1Mystery Box not initialized on this map");
        return;
    }
    if (level.chests.size == 0)
    {
        self iprintln("^1Mystery Box not initialized on this map");
        return;
    }
    foreach (chest in level.chests)
    {
        if (isdefined(chest))
            chest.zombie_cost = value;
    }
    self iprintln("Box price set to ^3" + value);
}

function mag_box_show_all(a, b)
{
    if (!isdefined(level.chests))
    {
        self iprintln("^1Mystery Box not initialized on this map");
        return;
    }
    if (level.chests.size == 0)
    {
        self iprintln("^1Mystery Box not initialized on this map");
        return;
    }
    foreach (chest in level.chests)
    {
        if (isdefined(chest))
            chest zm_magicbox::show_chest();
    }
    self iprintln("All registered Mystery Boxes shown");
}

function mag_box_teleport(a, b)
{
    if (!isdefined(level.chests))
    {
        self iprintln("^1No active Mystery Box on this map");
        return;
    }
    if (level.chests.size == 0 || !isdefined(level.chest_index))
    {
        self iprintln("^1No active Mystery Box on this map");
        return;
    }
    if (level.chest_index < 0 || level.chest_index >= level.chests.size)
    {
        self iprintln("^1No active Mystery Box on this map");
        return;
    }
    chest = level.chests[level.chest_index];
    if (!isdefined(chest) || !isdefined(chest.zbarrier))
    {
        self iprintln("^1Active box has no teleport marker");
        return;
    }
    origin = chest.zbarrier.origin;
    forward = anglestoforward(chest.zbarrier.angles);
    right = anglestoright(chest.zbarrier.angles);
    target_angles = vectortoangles(right);
    target_origin = origin - 48 * right;
    offset = randomintrange(0, 4);
    if (offset == 0)
        target_origin = target_origin + 16 * right;
    else if (offset == 1)
        target_origin = target_origin + 16 * forward;
    else if (offset == 2)
        target_origin = target_origin - 16 * right;
    else
        target_origin = target_origin - 16 * forward;
    self setorigin(target_origin);
    self setplayerangles(target_angles);
    self iprintln("Teleported to active Mystery Box");
}

function mag_box_freeze(a, b)
{
    if (!isdefined(level.chests))
    {
        self iprintln("^1No active Mystery Box on this map");
        return;
    }
    if (level.chests.size == 0 || !isdefined(level.chest_index))
    {
        self iprintln("^1No active Mystery Box on this map");
        return;
    }
    if (level.chest_index < 0 || level.chest_index >= level.chests.size)
    {
        self iprintln("^1No active Mystery Box on this map");
        return;
    }
    chest = level.chests[level.chest_index];
    if (!isdefined(chest))
    {
        self iprintln("^1Active Mystery Box unavailable");
        return;
    }
    chest.no_fly_away = !isdefined(chest.no_fly_away) ? true : undefined;
    if (isdefined(chest.no_fly_away))
        self iprintln("Active Box movement ^2locked");
    else
        self iprintln("Active Box movement ^1restored");
}


function mag_give(name, b)
{
    w = getweapon(name);
    if (!isdefined(w) || w == getweapon(#"none"))
    {
        self iprintln("^1Weapon not available here");
        return;
    }
    self giveweapon(w);
    self givemaxammo(w);
    self switchtoweapon(w);
    self iprintln("Weapon ^2given");
}

function mag_camo_apply(id, b)
{
    weapon = self getcurrentweapon();
    if (!isdefined(weapon) || weapon == getweapon(#"none") || (isdefined(weapon.isgadget) && weapon.isgadget))
    {
        self iprintln("^1No compatible weapon in hand");
        return;
    }
    self setcamo(weapon, id);
    self iprintln("Camo ID ^2applied: ^3" + id);
}

function mag_take_weapon(a, b)
{
    weapon = self getcurrentweapon();
    if (isdefined(weapon) && weapon != getweapon(#"none"))
        self takeweapon(weapon);
}

function mag_drop_weapon(a, b)
{
    weapon = self getcurrentweapon();
    if (isdefined(weapon) && weapon != getweapon(#"none"))
        self dropitem(weapon);
}


function mag_aim_pos()
{
    eye = self geteye();
    trace = bullettrace(eye, eye + anglestoforward(self getplayerangles()) * 100000, 0, self);
    if (isdefined(trace) && isdefined(trace[ #"position" ]))
        return trace[ #"position" ];
    return self.origin;
}

function mag_tele_cross(a, b)
{
    self setorigin(self mag_aim_pos());
    self iprintln("Teleported to crosshair");
}

function mag_save_pos(a, b)
{
    self.mag.pos = self.origin;
    self.mag.ang = self getplayerangles();
    self iprintln("Position ^2saved");
}

function mag_load_pos(a, b)
{
    if (!isdefined(self.mag.pos))
    {
        self iprintln("^1No position saved");
        return;
    }
    self setorigin(self.mag.pos);
    self setplayerangles(self.mag.ang);
    self iprintln("Position ^2loaded");
}

function mag_tele_sky(a, b)
{
    self setorigin(self.origin + (0, 0, 2000));
    self iprintln("Teleported upward");
}

function mag_quake(a, b)
{
    earthquake(0.6, 4, self.origin, 1500);
}

function mag_spin(a, b)
{
    if (self mag_switch("spin"))
        self thread mag_spin_loop();
    else
        self notify(#"mag_spin_stop");
}

function mag_spin_loop()
{
    self endon(#"disconnect", #"mag_spin_stop");
    for (;;)
    {
        if (!self mag_tog("spin") || !isalive(self))
        {
            wait 0.1;
            continue;
        }
        angles = self getplayerangles();
        self setplayerangles((angles[0], angles[1] + 12, angles[2]));
        waitframe(1);
    }
}


function mag_pick_player(p, b)
{
    self.mag.target = p;
    self mag_load("player");
}

function mag_access_all(value, b)
{
    foreach (p in getplayers())
    {
        if (!isdefined(p) || p == self || isbot(p))
            continue;
        self mag_p_access(p, value, 1);
    }
    self iprintln("Menu access updated for ^3all players");
    self mag_load("players");
}

function mag_p_access(p, value, silent)
{
    if (!isdefined(p))
        return;
    if (!isdefined(p.mag))
        p mag_setup();
    if (!p.mag.buttons_started)
    {
        p.mag.buttons_started = 1;
        p thread mag_buttons();
    }
    p.mag.access = value;
    if (value)
    {
        p iprintlnbold("^1MAG ^7Zombies Menu ^2unlocked ^7: ^3[{+frag}] + [{+usereload}]");
        self iprintln(p.name + " ^2has menu access");
    }
    else
    {
        p.mag.tog["ufo"] = 0;
        p notify(#"mag_ufo_stop");
        if (p.mag.ufo_on)
            p mag_ufo_set(0);
        p.mag.tog["killaura"] = 0;
        p notify(#"mag_killaura_stop");
        p.mag.tog["zpos"] = 0;
        p notify(#"mag_zpos_stop");
        p.mag.tog["ammo"] = 0;
        p notify(#"mag_ammo_stop");
        p.mag.tog["god"] = 0;
        p notify(#"mag_god_stop");
        p disableinvulnerability();
        p.mag.tog["autoheal"] = 0;
        p notify(#"mag_heal_stop");
        p.mag.tog["sjump"] = 0;
        p notify(#"mag_sjump_stop");
        p.mag.tog["spin"] = 0;
        p notify(#"mag_spin_stop");
        if (p.mag.tog["third"])
            p setclientthirdperson(0);
        p.mag.tog["third"] = 0;
        if (p.mag.tog["sprint"])
            p unsetperk(#"specialty_unlimitedsprint");
        p.mag.tog["sprint"] = 0;
        p.mag.speed = 1;
        p setmovespeedscale(1);
        if (p.mag.open)
            p mag_close();
        p iprintlnbold("^1MAG Menu access removed");
        self iprintln(p.name + " ^1lost menu access");
    }
    if (!isdefined(silent) && self.mag.menu == "player")
        self mag_load("player");
}


function mag_score_step(a, b)
{
    s = self.mag.score_step;
    if (s == 100)
        s = 1000;
    else if (s == 1000)
        s = 10000;
    else if (s == 10000)
        s = 100000;
    else if (s == 100000)
        s = 1000000;
    else
        s = 100;
    self.mag.score_step = s;
    self mag_load("score");
}

function mag_score_add(dir, b)
{
    amount = self.mag.score_step;
    if (dir > 0)
        self zm_score::add_to_player_score(amount);
    else
    {
        if (amount > self.score)
            amount = self.score;
        if (amount > 0)
            self zm_score::minus_to_player_score(amount);
    }
    self iprintln("Score : ^3" + self.score);
    self mag_load("score");
}

function mag_score_set(value, b)
{
    diff = value - self.score;
    if (diff > 0)
        self zm_score::add_to_player_score(diff);
    else if (diff < 0)
        self zm_score::minus_to_player_score(0 - diff);
    self iprintln("Score set to ^3" + value);
    self mag_load("score");
}


function mag_acc_done(key)
{
    self.mag.tog[key] = 0;
    if (self.mag.open)
        self mag_draw();
}

function mag_acc_level55(a, b)
{
    self addrankxpvalue("kill", 2516000000);
    self rank::updaterank();
    wait 0.1;
    uploadstats(self);
    self iprintln("^2Rank and XP set");
}

function mag_acc_level1000(a, b)
{
    self addrankxpvalue("kill", 2516000000);
    self setparagonrank(999);
    self rank::updaterank();
    wait 0.1;
    uploadstats(self);
    self iprintln("^2Rank and XP set ^7(level 1000 : experimental)");
}

function mag_acc_plasma(a, b)
{
    if (self mag_switch("plasma"))
    {
        self notify(#"mag_plasma_stop");
        self thread mag_acc_plasma_loop();
        self iprintln("Plasma Loop ^2ON");
    }
    else
    {
        self notify(#"mag_plasma_stop");
        self iprintln("Plasma Loop ^1OFF");
    }
}

function mag_acc_plasma_loop()
{
    self endon(#"disconnect", #"mag_plasma_stop");
    for (;;)
    {
        if (!self mag_tog("plasma"))
            return;
        self function_e8f77739(#"zm_timeplayed", 1000000);
        wait 0.1;
    }
}

function mag_acc_contracts(a, b)
{
    count = 0;
    if (isdefined(self.pers["contracts"]))
    {
        foreach (index, contract in self.pers["contracts"])
        {
            target = contract.target_value;
            if (isdefined(target) && target)
            {
                contract.current_value = target;
                count++;
            }
        }
    }
    self iprintln("Active Contracts completed : ^3" + count);
}

function mag_acc_unlock_all(a, b)
{
    if (self mag_tog("acc_unlock"))
    {
        self iprintln("Unlock All already ^3running");
        return;
    }
    if (self stats::get_stat("playerstatslist", "rank", "statvalue") < 54)
    {
        self iprintln("^1Level 55 required for Unlock All");
        return;
    }
    self.mag.tog["acc_unlock"] = 1;
    self thread mag_acc_unlock_all_run();
}

function mag_acc_unlock_all_run()
{
    self endon(#"disconnect");

    // statsmilestones4.csv est une table vide : elle est sautee.
    tables = array(1, 2, 3, 5);
    starts = array(1, 292, 548, 1024);
    ends = array(292, 548, 589, 1412);
    groups = array(#"weapon_pistol", #"weapon_smg", #"weapon_assault", #"weapon_lmg", #"weapon_cqb", #"weapon_sniper", #"weapon_tactical", #"weapon_launcher", #"weapon_knife", #"weapon_special");

    total = 0;
    for (t = 0; t < tables.size; t++)
        total += ends[t] - starts[t];

    done = 0;
    batch = 0;
    self iprintln("Unlock All ^2started ^7(" + total + " entries)");

    for (t = 0; t < tables.size; t++)
    {
        file = "gamedata/stats/zm/statsmilestones" + tables[t] + ".csv";
        for (value = starts[t]; value < ends[t]; value++)
        {
            stat = spawnstruct();
            stat.value = int(tablelookup(file, 0, value, 2));
            stat.type = tablelookup(file, 0, value, 3);
            stat.name = tablelookup(file, 0, value, 4);

            // Les challenges "attachment" sont inutiles sans la colonne 13 : ignores.
            if (stat.type == "attachment")
                continue;

            switch (stat.type)
            {
                case "global":
                    self stats::set_stat(#"PlayerStatsList", stat.name, #"StatValue", stat.value);
                    self stats::set_stat(#"PlayerStatsList", stat.name, #"Challengevalue", stat.value);
                    break;

                case "group":
                    foreach (group in groups)
                    {
                        self stats::set_stat(#"GroupStats", group, #"stats", stat.name, #"StatValue", stat.value);
                        self stats::set_stat(#"GroupStats", group, #"stats", stat.name, #"Challengevalue", stat.value);
                        wait 0.01;
                    }
                    break;

                default:
                    foreach (weap in level.zombie_weapons)
                    {
                        if (isdefined(weap.weapon))
                        {
                            self addweaponstat(weap.weapon, stat.name, stat.value);
                            self addweaponstat(weap.weapon, #"kills", 5000);
                            self addweaponstat(weap.weapon, #"headshots", 5000);
                            self addweaponstat(weap.weapon, #"allperkkills", 5000);
                            self addweaponstat(weap.weapon, #"noperkkills", 5000);
                            self addweaponstat(weap.weapon, #"packedkills", 5000);
                            self addweaponstat(weap.weapon, #"heavykills", 5000);
                            self addweaponstat(weap.weapon, #"minibosskills", 5000);
                            self addweaponstat(weap.weapon, #"verminkills", 5000);
                            self addweaponstat(weap.weapon, #"crawlerkills", 5000);
                            self addweaponstat(weap.weapon, #"instakills", 5000);
                            self addweaponstat(weap.weapon, #"hash_704097a2cc8e63e5", 5000);
                            self addweaponstat(weap.weapon, #"hash_657e22dcdd18da77", 5000);
                            wait 0.01;
                        }
                    }
                    break;
            }

            done++;
            batch++;
            wait 0.1;

            if (batch >= 25)
            {
                uploadstats(self);
                self iprintln("Unlock All : ^3" + done + "/" + total);
                batch = 0;
            }
        }
    }

    if (batch > 0)
        uploadstats(self);

    self iprintln("Unlock All Challenges ^2done");
    self mag_acc_done("acc_unlock");
}

function mag_acc_weapon_levels(a, b)
{
    if (self mag_tog("acc_wlevels"))
    {
        self iprintln("Max Weapon Levels already ^3running");
        return;
    }
    self.mag.tog["acc_wlevels"] = 1;
    self thread mag_acc_weapon_levels_run();
}

function mag_acc_weapon_levels_run()
{
    self endon(#"disconnect");
    self iprintln("Max Weapon Levels ^2started");

    foreach (gun in level.zombie_weapons)
    {
        if (isdefined(gun.weapon))
        {
            self stats::set_stat(#"hash_60e21f66eb3a1f18", gun.weapon.name, #"xp", 665535);
            self stats::set_stat(#"hash_60e21f66eb3a1f18", gun.weapon.name, #"plevel", 2);
            wait 0.01;
        }
    }

    attachments = array(#"reflex", #"elo", #"acog", #"dualoptic", #"mms", #"holo");
    foreach (attachment in attachments)
    {
        self stats::set_stat(#"hash_2ea32bf38705dfdc", attachment, #"kills", #"StatValue", 5000);
        self stats::set_stat(#"hash_2ea32bf38705dfdc", attachment, #"kills", #"ChallengeValue", 5000);
        wait 1;
    }

    wait 0.5;
    uploadstats(self);
    self iprintln("Max Weapon Ranks ^2set");
    self mag_acc_done("acc_wlevels");
}

function mag_acc_achievements(a, b)
{
    if (self mag_tog("acc_achiev"))
    {
        self iprintln("Achievements already ^3running");
        return;
    }
    self.mag.tog["acc_achiev"] = 1;
    self thread mag_acc_achievements_run();
}

function mag_acc_achievements_run()
{
    self endon(#"disconnect");

    list = array(
        "zm_office_cold_war", "zm_office_ice", "zm_office_shock", "zm_office_power",
        "zm_office_strike", "zm_office_office", "zm_office_crawl", "zm_office_gas",
        "zm_office_pentupagon", "zm_office_everywhere", "zm_red_tragedy", "zm_red_follower",
        "zm_red_tribute", "zm_red_mountains", "zm_red_no_obol", "zm_red_sun",
        "zm_red_wind", "zm_red_eagle", "zm_red_defense", "zm_red_gods",
        "zm_white_shard", "zm_white_starting", "zm_white_unlock", "zm_white_mod",
        "zm_white_trap", "zm_white_pap", "zm_white_knuckles", "zm_white_perk",
        "zm_white_stun", "zm_white_roof", "zm_trophy_doctor_is_in", "zm_trials_round_30",
        "zm_escape_most_escape", "zm_escape_patch_up", "zm_escape_hot_stuff", "zm_escape_hist_reenact",
        "zm_escape_match_made", "zm_escape_west_side", "zm_escape_senseless", "zm_escape_gat",
        "zm_escape_throw_dog", "zm_orange_ascend", "zm_orange_bells", "zm_orange_freeze",
        "zm_orange_hounds", "zm_orange_totems", "zm_orange_pack", "zm_orange_secret",
        "zm_orange_power", "zm_orange_ziplines", "zm_orange_jar", "ZM_ZODT8_TRIAL_STEP_1",
        "ZM_MANSION_ARTIFACT", "ZM_MANSION_STAKE", "ZM_MANSION_BOARD", "ZM_MANSION_BITE",
        "ZM_MANSION_QUICK", "ZM_MANSION_ALCHEMICAL", "ZM_MANSION_CRAFTING", "ZM_MANSION_SHOCKING",
        "ZM_MANSION_CLOCK", "ZM_MANSION_SHRINKING", "zm_towers_challenges", "zm_towers_get_ww",
        "zm_towers_trap_build", "zm_towers_ww_kills", "zm_towers_kitty_kitty", "zm_towers_dismember",
        "zm_towers_boss_kill", "zm_towers_arena_survive", "zm_towers_fast_pap", "ZM_ZODT8_ARTIFACT",
        "ZM_ZODT8_STOWAWAY", "ZM_ZODT8_DEEP_END", "ZM_ZODT8_LITTLE_PACK", "ZM_ZODT8_SHORTCUT",
        "ZM_ZODT8_TENTACLE", "ZM_ZODT8_STOKING", "ZM_ZODT8_ROCK_PAPER", "ZM_ZODT8_SWIMMING",
        "zm_trophy_jack_of_all_blades", "zm_trophy_straw_purchase", "zm_trophy_perkaholic_relapse", "zm_trophy_gold",
        "zm_rush_personal_score", "zm_rush_team_score", "zm_rush_multiplier_100", "mp_trophy_special_issue_weaponry",
        "mp_trophy_special_issue_equipment", "wz_specialist_super_fan", "wz_first_win", "wz_not_a_fluke",
        "wz_blackout_historian", "wz_zombie_fanatic", "mp_trophy_battle_tested", "mp_trophy_welcome_to_the_club",
        "MP_SPECIALIST_MEDALS", "MP_MULTI_KILL_MEDALS", "mp_trophy_vanquisher"
    );

    self iprintln("Achievements ^2started ^7(" + list.size + ")");
    for (i = 0; i < list.size; i++)
    {
        self giveachievement(list[i]);
        if ((i + 1) % 20 == 0)
            self iprintln("Achievements : ^3" + (i + 1) + "/" + list.size);
        wait 0.5;
    }

    wait 0.5;
    self iprintln("^6All Achievements Unlocked");
    self mag_acc_done("acc_achiev");
}

function mag_acc_stat_step(a, b)
{
    s = self.mag.stat_step;
    if (s == 100)
        s = 500;
    else if (s == 500)
        s = 1000;
    else if (s == 1000)
        s = 5000;
    else if (s == 5000)
        s = 10000;
    else
        s = 100;
    self.mag.stat_step = s;
    self mag_load("stats");
}

function mag_acc_stat_edit(which, b)
{
    amount = self.mag.stat_step;
    switch (which)
    {
        case 0:
            self zm_stats::function_ab006044("TOTAL_GAMES_PLAYED", amount);
            break;
        case 1:
            self zm_stats::function_1b763e4("HIGHEST_ROUND_REACHED", amount);
            break;
        case 2:
            self zm_stats::function_1b763e4("kills", amount);
            break;
        case 3:
            self zm_stats::function_1b763e4("MOST_HEADSHOTS", amount);
            break;
        case 4:
            self zm_stats::function_ab006044("TOTAL_ROUNDS_SURVIVED", amount);
            self zm_stats::function_a6efb963("TOTAL_ROUNDS_SURVIVED", amount);
            self zm_stats::function_9288c79b("TOTAL_ROUNDS_SURVIVED", amount);
            break;
        default:
            return;
    }
    self iprintln("Stat applied : ^3" + amount);
}


function mag_crouching()
{
    if (self stancebuttonpressed())
        return 1;
    return self getstance() == "crouch";
}

function mag_ufo_set(on)
{
    if (on == self.mag.ufo_on)
        return;
    self.mag.ufo_on = on;
    if (on)
    {
        self.mag.ufo = spawn("script_model", self.origin);
        self.mag.ufo setmodel(#"tag_origin");
        self playerlinkto(self.mag.ufo);
        self iprintln("UFO ^2ON ^7- hold ^3[{+frag}] ^7to fly - ^3[{+stance}] + [{+melee}] ^7to land");
    }
    else
    {
        self unlink();
        if (isdefined(self.mag.ufo))
            self.mag.ufo delete();
        self.mag.ufo = undefined;
        self iprintln("UFO ^1OFF");
    }
}

function mag_ufo(a, b)
{
    self notify(#"mag_ufo_stop");
    if (self mag_switch("ufo"))
    {
        self thread mag_ufo_loop();
        self iprintln("UFO Binds ^2ON ^7- ^3crouch + melee ^7to fly / land");
    }
    else
    {
        self mag_ufo_set(0);
        self iprintln("UFO Binds ^1OFF");
    }
}

function mag_ufo_loop()
{
    self endon(#"disconnect", #"mag_ufo_stop");
    held = 0;
    for (;;)
    {
        waitframe(1);
        if (!self mag_tog("ufo") || !self.mag.access)
        {
            self.mag.tog["ufo"] = 0;
            self mag_ufo_set(0);
            return;
        }
        if (!isalive(self))
        {
            if (self.mag.ufo_on)
                self mag_ufo_set(0);
            held = 1;
            continue;
        }
        if (self.mag.open)
            continue;
        combo = self mag_crouching() && self meleebuttonpressed();
        if (combo && !held)
        {
            held = 1;
            if (self.mag.ufo_on)
                self mag_ufo_set(0);
            else
                self mag_ufo_set(1);
        }
        else if (!combo)
            held = 0;
        if (self.mag.ufo_on && isdefined(self.mag.ufo) && self fragbuttonpressed())
            self.mag.ufo.origin = self.mag.ufo.origin + anglestoforward(self getplayerangles()) * 30;
    }
}

function mag_p_god(p, b)
{
    if (!isdefined(p))
        return;
    if (!isdefined(p.mag))
        p mag_setup();
    if (p mag_switch("god"))
    {
        p notify(#"mag_god_stop");
        p thread mag_god_loop();
        self iprintln(p.name + " God Mode ^2ON");
    }
    else
    {
        p notify(#"mag_god_stop");
        p disableinvulnerability();
        self iprintln(p.name + " God Mode ^1OFF");
    }
}

function mag_p_freeze(p, b)
{
    if (!isdefined(p))
        return;
    if (!isdefined(p.mag))
        p mag_setup();
    if (p mag_switch("frozen"))
    {
        p freezecontrols(1);
        self iprintln(p.name + " ^1frozen");
    }
    else
    {
        p freezecontrols(0);
        self iprintln(p.name + " ^2unfrozen");
    }
}

function mag_p_tele_to_me(p, b)
{
    if (isdefined(p))
        p setorigin(self.origin);
}

function mag_p_tele_me(p, b)
{
    if (isdefined(p))
        self setorigin(p.origin);
}

function mag_p_kill(p, b)
{
    if (isdefined(p) && isalive(p))
        p suicide();
}

function mag_all(what, b)
{
    foreach (p in getplayers())
    {
        if (!isdefined(p) || p == self)
            continue;
        if (!isdefined(p.mag))
            p mag_setup();
        if (what == "god")
        {
            if (!p mag_tog("god"))
            {
                p.mag.tog["god"] = 1;
                p notify(#"mag_god_stop");
                p thread mag_god_loop();
            }
        }
        else if (what == "nogod")
        {
            p.mag.tog["god"] = 0;
            p notify(#"mag_god_stop");
            p disableinvulnerability();
        }
        else if (what == "ammo")
        {
            if (!p mag_tog("ammo"))
            {
                p.mag.tog["ammo"] = 1;
                p notify(#"mag_ammo_stop");
                p thread mag_ammo_loop();
            }
        }
        else if (what == "noammo")
        {
            p.mag.tog["ammo"] = 0;
            p notify(#"mag_ammo_stop");
        }
        else if (what == "tele")
            p setorigin(self.origin);
        else if (what == "freeze")
            p freezecontrols(1);
        else if (what == "unfreeze")
            p freezecontrols(0);
        else if (what == "kill" && isalive(p))
            p suicide();
    }
    self iprintln("Done for ^3other players");
}

function mag_restart(a, b)
{
    self iprintln("Restarting Zombies match...");
    wait 1;
    map_restart(1);
}
s
function mag_theme(index, b)
{
    self.mag.theme = index;
    self mag_draw();
}

function mag_set_lines(n, b)
{
    if (n < 3)
        n = 3;
    if (n > 4)
        n = 4;
    self.mag.lines = n;
    self mag_load("settings");
}

function mag_display(a, b)
{
    self mag_clear();
    self.mag.bold = !self.mag.bold;
    self mag_load("settings");
}
