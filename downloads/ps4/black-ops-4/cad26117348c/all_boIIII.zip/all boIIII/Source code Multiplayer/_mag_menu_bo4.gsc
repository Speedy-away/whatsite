
#using scripts\core_common\callbacks_shared;
#using scripts\core_common\system_shared;
#using script_47fb62300ac0bd60; // stats (set_stat_global / get_stat_global)

#namespace clientids_shared;

function autoexec __init__system__()
{
    system::register(#"clientids_shared", &__init__, undefined, undefined);
}

function __init__()
{
    callback::on_start_gametype(&mag_level_init);
    callback::on_connect(&mag_on_connect);
    callback::on_spawned(&mag_on_spawned);
}


function mag_level_init()
{
    level.mag_version = "v1.5";
}

function mag_on_connect()
{
    self endon(#"disconnect");
    if (!isdefined(level.mag_version))
        level.mag_version = "v1.5";
    self mag_setup();
    self thread mag_buttons();
}

function mag_on_spawned()
{
    self endon(#"disconnect");
    if (!isdefined(self.mag))
    {
        self mag_setup();
        self thread mag_buttons();
    }
    if (!self.mag.welcome)
    {
        self.mag.welcome = 1;
        wait 2;
        self iprintlnbold("^1MAG ^7Menu ^2BO4 ^7- Dev By ^1UrBaaZz ^7& ^5ZERTY");
        if (self.mag.access)
            self iprintln("^1MAG ^7Menu : ^3[{+frag}] + [{+usereload}]");
        self iprintln("Discord server: discord.gg/FYHewFgZkb");
    }
    if (self mag_tog("aimbot"))
    {
        self notify(#"mag_aim_stop");
        self thread mag_aim_loop();
    }
    // les toggles actifs repartent apres la mort
    if (self mag_tog("god"))
        self enableinvulnerability();
    if (self mag_tog("third"))
        self setclientthirdperson(1);
    if (self mag_tog("sprint"))
        self setperk(#"specialty_unlimitedsprint");
    if (isdefined(self.mag.speed) && self.mag.speed > 1)
        self setmovespeedscale(self.mag.speed);
    // perks du Self Menu : le jeu les remet a zero a chaque spawn
    self thread mag_spawn_restore();
}

function mag_setup()
{
    if (isdefined(self.mag))
        return;
    self.mag = spawnstruct();
    self.mag.open = 0;
    self.mag.busy = 0;
    self.mag.welcome = 0;
    self.mag.menu = "main";
    self.mag.cursor = [];
    self.mag.opts = [];
    self.mag.tog = [];
    self.mag.lines = 3;
    self.mag.bold = 0;
    self.mag.drawn = 0;
    self.mag.speed = 1;
    self.mag.fov = 0;
    self.mag.ufo_on = 0;
    self.mag.theme = 0;
    self.mag.access = self ishost();
    self.mag.host = self ishost();
    self mag_aim_init();
}

function mag_tog(key)
{
    if (!isdefined(self.mag) || !isdefined(self.mag.tog[key]))
        return 0;
    return self.mag.tog[key];
}


function mag_buttons()
{
    self endon(#"disconnect");
    for (;;)
    {
        if (!self.mag.open)
        {
            if (self.mag.access && self fragbuttonpressed() && self usebuttonpressed())
            {
                self mag_open();
                wait 0.4;
            }
        }
        else if (!self.mag.busy)
        {
            if (self adsbuttonpressed() || self actionslotonebuttonpressed())
            {
                self mag_scroll(-1);
                wait 0.14;
            }
            else if (self attackbuttonpressed() || self actionslottwobuttonpressed())
            {
                self mag_scroll(1);
                wait 0.14;
            }
            else if (self usebuttonpressed())
            {
                self mag_select();
                wait 0.25;
            }
            else if (self stancebuttonpressed())
            {
                self mag_back();
                wait 0.25;
            }
        }
        waitframe(1);
    }
}


function mag_theme_code(index)
{
    if (index == 1)
        return "^5";
    if (index == 2)
        return "^2";
    if (index == 3)
        return "^6";
    if (index == 4)
        return "^3";
    return "^1";
}

function mag_label(o)
{
    s = o.label;
    if (isdefined(o.tog))
    {
        if (self mag_tog(o.tog))
            s = s + " ^2[ON]";
        else
            s = s + " ^1[OFF]";
    }
    return s;
}


function mag_print(text)
{
    if (self.mag.bold)
        self iprintlnbold(text);
    else
        self iprintln(text);
}


function mag_draw()
{
    if (!self.mag.open)
        return;
    self.mag.drawn = gettime();
    n = self.mag.lines;
    total = self.mag.opts.size;
    cur = self mag_cur();
    start = cur - int(n / 2);
    if (start > total - n)
        start = total - n;
    if (start < 0)
        start = 0;
    c = mag_theme_code(self.mag.theme);
    self mag_print(c + "[{+frag}]MAG ^7Menu [{+speed_throw}]" + c + "| ^7" + self.mag.title_text + "  ^3" + (cur + 1) + "^7/" + total);
    for (i = 0; i < n; i++)
    {
        idx = start + i;
        if (idx >= total)
            self mag_print("^7 ");
        else if (idx == cur)
            self mag_print(c + "[{+usereload}] > ^7" + self mag_label(self.mag.opts[idx]));
        else
            self mag_print("^7    " + self mag_label(self.mag.opts[idx]));
    }
}


function mag_clear()
{
    for (i = 0; i < self.mag.lines + 6; i++)
        self mag_print(" ");
}


function mag_refresh()
{
    self endon(#"disconnect", #"mag_closed");
    for (;;)
    {
        wait 0.25;
        if (!self.mag.open)
            return;
        delay = 2500;
        if (self.mag.bold)
            delay = 1500;
        if (!self.mag.busy && gettime() - self.mag.drawn > delay)
            self mag_draw();
    }
}


function mag_cur()
{
    if (!isdefined(self.mag.cursor[self.mag.menu]))
        self.mag.cursor[self.mag.menu] = 0;
    return self.mag.cursor[self.mag.menu];
}

function mag_open()
{
    self.mag.open = 1;
    self disableweapons();
    self mag_load(self.mag.menu);
    self thread mag_refresh();
}

function mag_close()
{
    self.mag.open = 0;
    self notify(#"mag_closed");
    self enableweapons();
    self mag_clear();
    self iprintln("^1MAG ^7Menu ^1closed");
}

function mag_scroll(dir)
{
    total = self.mag.opts.size;
    if (total == 0)
        return;
    cur = self mag_cur() + dir;
    if (cur < 0)
        cur = total - 1;
    if (cur >= total)
        cur = 0;
    self.mag.cursor[self.mag.menu] = cur;
    self mag_draw();
}

function mag_select()
{
    cur = self mag_cur();
    if (cur >= self.mag.opts.size)
        return;
    o = self.mag.opts[cur];
    if (isdefined(o.func))
    {
        self.mag.busy = 1;
        self [[ o.func ]](o.a1, o.a2);
        self.mag.busy = 0;
    }
    self mag_draw();
}

function mag_back()
{
    if (self.mag.menu == "main")
    {
        self mag_close();
        return;
    }
    self mag_load(self.mag.parent);
}

function mag_go(menu, unused)
{
    self mag_load(menu);
}

function mag_add(label, func, a1, a2, tog)
{
    o = spawnstruct();
    o.label = label;
    o.func = func;
    o.a1 = a1;
    o.a2 = a2;
    o.tog = tog;
    self.mag.opts[self.mag.opts.size] = o;
}

function mag_load(menu)
{
    self.mag.menu = menu;
    self.mag.opts = [];
    self.mag.parent = "main";
    self mag_build(menu);
    if (self mag_cur() >= self.mag.opts.size)
        self.mag.cursor[menu] = 0;
    self mag_draw();
}

function mag_build(menu)
{
    switch (menu)
    {
        case "main":
            self.mag.title_text = "Main Menu";
            self mag_add("Player Options", &mag_go, "self");
            self mag_add("Account Options", &mag_go, "account");
            self mag_add("Aimbot Options", &mag_go, "aimbot");
            self mag_add("Weapons Options", &mag_go, "weapons");
            self mag_add("Message Options", &mag_go, "messages");
            self mag_add("Fun Options", &mag_go, "fun");
            self mag_add("Bullets Options", &mag_go, "bullets");
            self mag_add("Teleport Options", &mag_go, "teleport");
            if (self.mag.host)
            {
                self mag_add("Players List", &mag_go, "players");
                self mag_add("Lobby Options", &mag_go, "lobby");
                self mag_add("Bots Options", &mag_go, "bots");
                self mag_add("Maps Options", &mag_go, "maps");
            }
            self mag_add("Menu Settings", &mag_go, "settings");
         //   self mag_add("Close Menu", &mag_close_opt);
            break;

        case "aimbot":
            self.mag.title_text = "Aimbot Menu";
            self mag_add("Aimbot", &mag_aim_toggle, undefined, undefined, "aimbot");
            self mag_add("Trigger : " + mag_aim_mode_name(self.mag.aim_mode), &mag_aim_cycle, "mode");
            self mag_add("Wall check", &mag_aim_option, "aim_visible", undefined, "aim_visible");
            if (self.mag.aim_bone)
                self mag_add("Target : Chest", &mag_aim_cycle, "bone");
            else
                self mag_add("Target : Head", &mag_aim_cycle, "bone");
            self mag_add("Aim cone : " + self.mag.aim_fov + " degrees", &mag_aim_cycle, "fov");
            self mag_add("Range : " + self.mag.aim_range + " units", &mag_aim_cycle, "range");
            self mag_add("Smoothing : " + self.mag.aim_smooth + " (1 = snap)", &mag_aim_cycle, "smooth");
          //  self mag_add("Debug info", &mag_aim_option, "aim_debug", undefined, "aim_debug");
            break;

        case "self":
            self.mag.title_text = "Player Options";
            self mag_add("God Mod", &mag_god, undefined, undefined, "god");
            self mag_add("Infinite Ammo", &mag_ammo, undefined, undefined, "ammo");
            self mag_add("UFO Binds ([{+stance}] + [{+melee}])", &mag_ufo, undefined, undefined, "ufo");
            self mag_add("No Recoil", &mag_norecoil, undefined, undefined, "norecoil");
            self mag_add("No Death Barrier", &mag_nobarrier, undefined, undefined, "nobarrier");
            self mag_add("Loop Skin", &mag_skin_toggle, undefined, undefined, "skinloop");
            self mag_add("Invisible", &mag_invisible, undefined, undefined, "invis");
            self mag_add("Third Person", &mag_third, undefined, undefined, "third");
            self mag_add("Unlimited Sprint", &mag_sprint, undefined, undefined, "sprint");
            self mag_add("Super Jump", &mag_superjump, undefined, undefined, "sjump");
            self mag_add("Super Speed (x1/x2/x3)", &mag_speed);
            self mag_add("Fast Reload", &mag_perk, #"specialty_fastreload", "p_reload", "p_reload");
            self mag_add("Fast Hands", &mag_perk, #"specialty_fastweaponswitch", "p_hands", "p_hands");
            self mag_add("Fast ADS", &mag_perk, #"specialty_fastads", "p_ads", "p_ads");
            self mag_add("Silent Steps", &mag_perk, #"specialty_quieter", "p_quiet", "p_quiet");
            self mag_add("Fire While Sprinting", &mag_perk, #"specialty_sprintfire", "p_sprintfire", "p_sprintfire");
            self mag_add("Auto Heal", &mag_autoheal, undefined, undefined, "autoheal");
            self mag_add("Infinite Abilities & Lethal", &mag_abilities, undefined, undefined, "iabil");
            self mag_add("Heal Now", &mag_heal);
            self mag_add("Max Ammo", &mag_maxammo);
            self mag_add("Suicide", &mag_suicide);
            break;

        case "account":
            self.mag.title_text = "Account Options";
            self mag_add("Rank Max (Level 55)", &mag_rank_max);
            self mag_add("Choose Prestige", &mag_go, "prestige");
            self mag_add("Prestige Master Level 1000", &mag_paragon_max);
            self mag_add("Unlock All", &mag_unlock_all);
            self mag_add("Upload Stats (Save Now)", &mag_upload_stats);
         //   self mag_add("Unlock MP Trophy Progress (5)", &mag_all_trophies);
        //    self mag_add("Check MP Trophy Progress", &mag_trophy_status);
            self mag_add("Unlock All Trophies (103)", &mag_all_trophies_full);
         //   self mag_add("Stop Trophy Requests", &mag_trophy_cancel);
         //   self mag_add("Show My Stats", &mag_show_stats);
            break;

        case "prestige":
            self.mag.title_text = "Choose Prestige";
            self.mag.parent = "account";
            maxp = level.var_50c857b7;
            if (!isdefined(maxp) || maxp < 1 || maxp > 20)
                maxp = 11;
            for (i = 0; i <= maxp; i++)
            {
                if (i == maxp)
                    self mag_add("Prestige Master (" + i + ")", &mag_set_prestige, i);
                else if (i == 0)
                    self mag_add("No Prestige (0)", &mag_set_prestige, i);
                else
                    self mag_add("Prestige " + i, &mag_set_prestige, i);
            }
            break;

        case "weapons":
            self.mag.title_text = "Weapons Options";
            self mag_add("Weapons List", &mag_go, "weapons_list");
            self mag_add("Take Current Weapon", &mag_take_weapon);
            self mag_add("Drop Current Weapon", &mag_drop_weapon);
         //   self mag_add("Select Camos", &mag_go, "camos");
            self mag_add("Camo Loop", &mag_camo_toggle, undefined, undefined, "camoloop");
            break;

        case "camos":
            self.mag.title_text = "Select Camos";
            self.mag.parent = "weapons";
            self mag_add("Generic Camos", &mag_go, "camo_generic");
            self mag_add("Mastery Camos", &mag_go, "camo_mastery");
            self mag_add("Pack-a-Punch Camos", &mag_go, "camo_pap");
            self mag_add("Reactive Camos", &mag_go, "camo_reactive");
            self mag_add("Black Market Camos", &mag_go, "camo_market");
            break;

        case "camo_generic":
            self.mag.title_text = "Generic Camos";
            self.mag.parent = "camos";
            self mag_add("MP 1", &mag_camo_set, 1);
            self mag_add("MP 2", &mag_camo_set, 4);
            self mag_add("MP 3", &mag_camo_set, 7);
            self mag_add("MP 4", &mag_camo_set, 10);
            self mag_add("MP 5", &mag_camo_set, 13);
            self mag_add("MP 6", &mag_camo_set, 16);
            self mag_add("MP 7", &mag_camo_set, 19);
            self mag_add("MP 8", &mag_camo_set, 22);
            self mag_add("MP 9", &mag_camo_set, 25);
            self mag_add("MP 10", &mag_camo_set, 28);
            self mag_add("MP 11", &mag_camo_set, 31);
            self mag_add("MP 12", &mag_camo_set, 34);
            self mag_add("MP 13", &mag_camo_set, 37);
            self mag_add("MP 14", &mag_camo_set, 40);
            self mag_add("Blackout 1", &mag_camo_set, 2);
            self mag_add("Blackout 2", &mag_camo_set, 5);
            self mag_add("Blackout 3", &mag_camo_set, 8);
            self mag_add("Blackout 4", &mag_camo_set, 11);
            self mag_add("Blackout 5", &mag_camo_set, 14);
            self mag_add("Blackout 6", &mag_camo_set, 17);
            self mag_add("Blackout 7", &mag_camo_set, 20);
            self mag_add("Blackout 8", &mag_camo_set, 23);
            self mag_add("Blackout 9", &mag_camo_set, 26);
            self mag_add("Blackout 10", &mag_camo_set, 29);
            self mag_add("Blackout 11", &mag_camo_set, 32);
            self mag_add("Blackout 12", &mag_camo_set, 35);
            self mag_add("Blackout 13", &mag_camo_set, 38);
            self mag_add("Blackout 14", &mag_camo_set, 41);
            self mag_add("Zombies 1", &mag_camo_set, 3);
            self mag_add("Zombies 2", &mag_camo_set, 6);
            self mag_add("Zombies 3", &mag_camo_set, 9);
            self mag_add("Zombies 4", &mag_camo_set, 12);
            self mag_add("Zombies 5", &mag_camo_set, 15);
            self mag_add("Zombies 6", &mag_camo_set, 18);
            self mag_add("Zombies 7", &mag_camo_set, 21);
            self mag_add("Zombies 8", &mag_camo_set, 24);
            self mag_add("Zombies 9", &mag_camo_set, 27);
            self mag_add("Zombies 10", &mag_camo_set, 30);
            self mag_add("Zombies 11", &mag_camo_set, 33);
            self mag_add("Zombies 12", &mag_camo_set, 36);
            self mag_add("Zombies 13", &mag_camo_set, 39);
            self mag_add("Zombies 14", &mag_camo_set, 42);
            break;

        case "camo_mastery":
            self.mag.title_text = "Mastery Camos";
            self.mag.parent = "camos";
            self mag_add("Gold", &mag_camo_set, 43);
            self mag_add("Diamond", &mag_camo_set, 44);
            self mag_add("Dark Matter", &mag_camo_set, 45);
            self mag_add("Diamond (Last Tier)", &mag_camo_set, 199);
            self mag_add("Dark Matter (Last Tier)", &mag_camo_set, 192);
            break;

        case "camo_pap":
            self.mag.title_text = "Pack-a-Punch Camos";
            self.mag.parent = "camos";
            self mag_add("Voyage of Despair Purple", &mag_camo_set, 146);
            self mag_add("Voyage of Despair Red", &mag_camo_set, 147);
            self mag_add("Voyage of Despair Green", &mag_camo_set, 148);
            self mag_add("Voyage of Despair Yellow", &mag_camo_set, 149);
            self mag_add("Voyage of Despair Pink", &mag_camo_set, 150);
            self mag_add("IX Blue", &mag_camo_set, 151);
            self mag_add("IX Red", &mag_camo_set, 152);
            self mag_add("IX Green", &mag_camo_set, 153);
            self mag_add("IX Purple", &mag_camo_set, 154);
            self mag_add("IX Orange", &mag_camo_set, 155);
            self mag_add("Blood of the Dead Yellow", &mag_camo_set, 156);
            self mag_add("Blood of the Dead Red", &mag_camo_set, 157);
            self mag_add("Blood of the Dead Yellow 2", &mag_camo_set, 158);
            self mag_add("Blood of the Dead Green", &mag_camo_set, 159);
            self mag_add("Blood of the Dead Purple", &mag_camo_set, 160);
            self mag_add("Classified 1", &mag_camo_set, 161);
            self mag_add("Classified 2", &mag_camo_set, 162);
            self mag_add("Classified 3", &mag_camo_set, 163);
            self mag_add("Classified 4", &mag_camo_set, 164);
            self mag_add("Classified 5", &mag_camo_set, 165);
            self mag_add("Dead of the Night Green", &mag_camo_set, 280);
            self mag_add("Dead of the Night Purple", &mag_camo_set, 281);
            self mag_add("Dead of the Night Red", &mag_camo_set, 282);
            self mag_add("Dead of the Night Blue", &mag_camo_set, 283);
            self mag_add("Dead of the Night Orange", &mag_camo_set, 284);
            self mag_add("Ancient Evil Purple", &mag_camo_set, 74);
            self mag_add("Ancient Evil Blue", &mag_camo_set, 75);
            self mag_add("Ancient Evil Orange", &mag_camo_set, 76);
            self mag_add("Ancient Evil Yellow", &mag_camo_set, 77);
            self mag_add("Ancient Evil Green", &mag_camo_set, 78);
            self mag_add("Alpha Omega", &mag_camo_set, 345);
            self mag_add("Tag der Toten", &mag_camo_set, 394);
            break;

        case "camo_reactive":
            self.mag.title_text = "Reactive Camos";
            self.mag.parent = "camos";
            self mag_add("D-Day", &mag_camo_set, 298);
            self mag_add("Roadtrip", &mag_camo_set, 300);
            self mag_add("Masked", &mag_camo_set, 310);
            self mag_add("Bobine", &mag_camo_set, 52);
            self mag_add("Search", &mag_camo_set, 57);
            self mag_add("Strip", &mag_camo_set, 62);
            self mag_add("Rave", &mag_camo_set, 67);
            self mag_add("Nebula", &mag_camo_set, 89);
            self mag_add("After Life", &mag_camo_set, 90);
            self mag_add("Postluminescence", &mag_camo_set, 119);
            self mag_add("115", &mag_camo_set, 129);
            self mag_add("Grey Matter", &mag_camo_set, 131);
            self mag_add("Denied Access", &mag_camo_set, 167);
            self mag_add("Skull", &mag_camo_set, 168);
            self mag_add("Solar Eruption", &mag_camo_set, 381);
            self mag_add("Vision of the Future", &mag_camo_set, 387);
            self mag_add("Pestilence", &mag_camo_set, 389);
            self mag_add("Crypted", &mag_camo_set, 286);
            self mag_add("Judas", &mag_camo_set, 357);
            self mag_add("Incandescent", &mag_camo_set, 359);
            self mag_add("Encoded", &mag_camo_set, 363);
            break;

        case "camo_market":
            self.mag.title_text = "Black Market Camos";
            self.mag.parent = "camos";
            self mag_add("Twitch 1", &mag_camo_set, 79);
            self mag_add("Twitch 2", &mag_camo_set, 118);
            self mag_add("$", &mag_camo_set, 46);
            self mag_add("Green Course", &mag_camo_set, 47);
            self mag_add("Blue", &mag_camo_set, 48);
            self mag_add("Kiss", &mag_camo_set, 49);
            self mag_add("Fortuna", &mag_camo_set, 50);
            self mag_add("Donuts", &mag_camo_set, 51);
            self mag_add("Serment", &mag_camo_set, 80);
            self mag_add("Imbu", &mag_camo_set, 81);
            self mag_add("Megalodon", &mag_camo_set, 82);
            self mag_add("Surf", &mag_camo_set, 83);
            self mag_add("Goinfre", &mag_camo_set, 84);
            self mag_add("Chrysalide", &mag_camo_set, 86);
            self mag_add("Locker", &mag_camo_set, 87);
            self mag_add("Bacon", &mag_camo_set, 117);
            self mag_add("Dead Time", &mag_camo_set, 120);
            self mag_add("Dirty Bubble", &mag_camo_set, 121);
            self mag_add("Heaven", &mag_camo_set, 122);
            self mag_add("Pique-nique Royal", &mag_camo_set, 123);
            self mag_add("Mai Tai Zombie", &mag_camo_set, 124);
            self mag_add("Colonne Piegee", &mag_camo_set, 126);
            self mag_add("Derezzed", &mag_camo_set, 134);
            self mag_add("Steam Explosion", &mag_camo_set, 135);
            self mag_add("Goinfre 2", &mag_camo_set, 136);
            self mag_add("Arabesque", &mag_camo_set, 137);
            self mag_add("Se Sentir Vise", &mag_camo_set, 166);
            self mag_add("Rampage", &mag_camo_set, 170);
            self mag_add("Soul Eater", &mag_camo_set, 171);
            self mag_add("Marathon", &mag_camo_set, 172);
            self mag_add("Avant Garde", &mag_camo_set, 173);
            self mag_add("Plasma", &mag_camo_set, 293);
            self mag_add("Air Fight", &mag_camo_set, 305);
            self mag_add("Cherry", &mag_camo_set, 314);
            self mag_add("Gigakiller", &mag_camo_set, 315);
            self mag_add("Flicker", &mag_camo_set, 316);
            self mag_add("Rocket Box", &mag_camo_set, 317);
            self mag_add("USA", &mag_camo_set, 346);
            self mag_add("Juicy", &mag_camo_set, 347);
            self mag_add("Glyph", &mag_camo_set, 348);
            self mag_add("Gratte-gratte", &mag_camo_set, 350);
            self mag_add("Flocon", &mag_camo_set, 351);
            self mag_add("Vertige", &mag_camo_set, 353);
            self mag_add("High Tension", &mag_camo_set, 354);
            self mag_add("Gluant", &mag_camo_set, 355);
            break;

        case "weapons_list":
            self.mag.title_text = "Weapons List";
            self.mag.parent = "weapons";
            self mag_add("Assault Rifles", &mag_go, "w_ar");
            self mag_add("Submachine Guns", &mag_go, "w_smg");
            self mag_add("Tactical Rifles", &mag_go, "w_tr");
            self mag_add("Light Machine Guns", &mag_go, "w_lmg");
            self mag_add("Sniper Rifles", &mag_go, "w_sniper");
            self mag_add("Pistols", &mag_go, "w_pistol");
            self mag_add("Shotguns", &mag_go, "w_shotgun");
            self mag_add("Launchers & Specials", &mag_go, "w_special");
            self mag_add("Specialist Weapons", &mag_go, "w_hero");
            break;

        case "w_ar":
            self.mag.title_text = "Assault Rifles";
            self.mag.parent = "weapons_list";
            self mag_add("ICR-7", &mag_give, #"ar_accurate_t8");
            self mag_add("Maddox RFB", &mag_give, #"ar_fastfire_t8");
            self mag_add("Rampart 17", &mag_give, #"ar_damage_t8");
            self mag_add("Vapr-XKG", &mag_give, #"ar_stealth_t8");
            self mag_add("KN-57", &mag_give, #"ar_standard_t8");
            self mag_add("Hitchcock M9", &mag_give, #"ar_modular_t8");
            self mag_add("Swordfish", &mag_give, #"ar_galil_t8");
            self mag_add("Peacekeeper", &mag_give, #"ar_peacekeeper_t8");
            self mag_add("Grav", &mag_give, #"ar_mg1909_t8");
            self mag_add("ABR 223", &mag_give, #"ar_an94_t8");
            break;

        case "w_smg":
            self.mag.title_text = "Submachine Guns";
            self.mag.parent = "weapons_list";
            self mag_add("MX9", &mag_give, #"smg_standard_t8");
            self mag_add("Cordite", &mag_give, #"smg_fastfire_t8");
            self mag_add("GKS", &mag_give, #"smg_accurate_t8");
            self mag_add("Spitfire", &mag_give, #"smg_handling_t8");
            self mag_add("Saug 9mm", &mag_give, #"smg_capacity_t8");
            self mag_add("Switchblade X9", &mag_give, #"smg_folding_t8");
            self mag_add("MP40", &mag_give, #"smg_mp40_t8");
            self mag_add("Escargot", &mag_give, #"smg_thompson_t8");
            break;

        case "w_tr":
            self.mag.title_text = "Tactical Rifles";
            self.mag.parent = "weapons_list";
            self mag_add("Auger DMR", &mag_give, #"tr_powersemi_t8");
            self mag_add("Swordfish", &mag_give, #"tr_longburst_t8");
            self mag_add("ABR 223", &mag_give, #"tr_midburst_t8");
            self mag_add("Essex Model 07", &mag_give, #"tr_leveraction_t8");
            self mag_add("M16", &mag_give, #"tr_damageburst_t8");
            self mag_add("Daemon 3XB", &mag_give, #"tr_flechette_t8");
            break;

        case "w_lmg":
            self.mag.title_text = "Light Machine Guns";
            self.mag.parent = "weapons_list";
            self mag_add("Titan", &mag_give, #"lmg_standard_t8");
            self mag_add("VKM 750", &mag_give, #"lmg_heavy_t8");
            self mag_add("Hades", &mag_give, #"lmg_spray_t8");
            self mag_add("Zweihander", &mag_give, #"lmg_double_t8");
            self mag_add("Tigershark", &mag_give, #"lmg_stealth_t8");
            break;

        case "w_sniper":
            self.mag.title_text = "Sniper Rifles";
            self.mag.parent = "weapons_list";
            self mag_add("Paladin HB50", &mag_give, #"sniper_powerbolt_t8");
            self mag_add("Outlaw", &mag_give, #"sniper_fastrechamber_t8");
            self mag_add("Koshka", &mag_give, #"sniper_quickscope_t8");
            self mag_add("SDM", &mag_give, #"sniper_powersemi_t8");
            self mag_add("Locus", &mag_give, #"sniper_locus_t8");
            self mag_add("Vendetta", &mag_give, #"sniper_damagesemi_t8");
            self mag_add("Mini 14", &mag_give, #"sniper_mini14_t8");
            break;

        case "w_pistol":
            self.mag.title_text = "Pistols";
            self.mag.parent = "weapons_list";
            self mag_add("Mozu", &mag_give, #"pistol_revolver_t8");
            self mag_add("RK 7 Garrison", &mag_give, #"pistol_burst_t8");
            self mag_add("Strife", &mag_give, #"pistol_standard_t8");
            self mag_add("Welling", &mag_give, #"pistol_topbreak_t8");
            self mag_add("SG12 (full auto)", &mag_give, #"pistol_fullauto_t8");
            break;

        case "w_shotgun":
            self.mag.title_text = "Shotguns";
            self.mag.parent = "weapons_list";
            self mag_add("MOG 12", &mag_give, #"shotgun_pump_t8");
            self mag_add("SG12", &mag_give, #"shotgun_semiauto_t8");
            self mag_add("Rampage", &mag_give, #"shotgun_fullauto_t8");
            self mag_add("Argus", &mag_give, #"shotgun_precision_t8");
            self mag_add("Trenchgun", &mag_give, #"shotgun_trenchgun_t8");
            break;

        case "w_special":
            self.mag.title_text = "Launchers & Specials";
            self.mag.parent = "weapons_list";
            self mag_add("Hellion Salvo", &mag_give, #"launcher_standard_t8");
            self mag_add("Ballistic Knife", &mag_give, #"special_ballisticknife_t8_dw");
            self mag_add("Crossbow", &mag_give, #"special_crossbow_t8");
            self mag_add("Ray Gun", &mag_give, #"ray_gun");
            self mag_add("Death Machine", &mag_give, #"minigun");
            self mag_add("Combat Knife", &mag_give, #"knife_loadout");
            self mag_add("Bowie Knife", &mag_give, #"melee_bowie");
            self mag_add("Default Weapon", &mag_give, #"defaultweapon");
            break;

        case "w_hero":
            self.mag.title_text = "Specialist Weapons";
            self.mag.parent = "weapons_list";
            self mag_add("Annihilator", &mag_give, #"hero_annihilator");
            self mag_add("Purifier", &mag_give, #"hero_flamethrower");
            self mag_add("War Machine", &mag_give, #"hero_pineapplegun");
            self mag_add("Sparrow", &mag_give, #"hero_bowlauncher");
            self mag_add("Tempest", &mag_give, #"hero_lightninggun");
            self mag_add("Scythe", &mag_give, #"sig_minigun");
            self mag_add("Ballistic Shield", &mag_give, #"sig_buckler_dw");
            self mag_add("Sparrow (quickshot)", &mag_give, #"sig_bow_quickshot");
            break;

        case "fun":
            self.mag.title_text = "Fun Options";
            self mag_add("Jetpack (hold X)", &mag_jetpack, undefined, undefined, "jetpack");
            self mag_add("Rocket Rain", &mag_rocket_rain);
            self mag_add("Earthquake", &mag_quake);
            self mag_add("Spin Mode", &mag_spin, undefined, undefined, "spin");
            break;

        case "bullets":
            self.mag.title_text = "Bullets Options";
            self mag_add("Explosive Bullets", &mag_bullets, "explosive", undefined, "b_explosive");
            self mag_add("Rocket Bullets", &mag_bullets, "rocket", undefined, "b_rocket");
            self mag_add("Teleport Gun", &mag_bullets, "teleport", undefined, "b_teleport");
            self mag_add("Bullets OFF", &mag_bullets_off);
            break;

        case "teleport":
            self.mag.title_text = "Teleport Options";
            self mag_add("Teleport To Crosshair", &mag_tele_cross);
            self mag_add("Save Position", &mag_save_pos);
            self mag_add("Load Position", &mag_load_pos);
            self mag_add("Teleport Up (sky)", &mag_tele_sky);
            break;

        case "players":
            self.mag.title_text = "Players List";
            foreach (p in getplayers())
            {
                if (p == self)
                    continue;
                self mag_add(p.name, &mag_pick_player, p);
            }
            if (self.mag.opts.size == 0)
                self mag_add("^3No other player", undefined);
            break;

        case "player":
            self.mag.parent = "players";
            p = self.mag.target;
            if (!isdefined(p))
            {
                self.mag.title_text = "Player";
                self mag_add("^1Player left", undefined);
                break;
            }
            self.mag.title_text = p.name;
            self mag_add("Give Menu Access", &mag_p_access, p, 1);
            self mag_add("Remove Menu Access", &mag_p_access, p, 0);
            self mag_add("God Mode ON / OFF", &mag_p_god, p);
            self mag_add("Freeze ON / OFF", &mag_p_freeze, p);
            self mag_add("Teleport To Me", &mag_p_tele_to_me, p);
            self mag_add("Teleport Me To Player", &mag_p_tele_me, p);
            self mag_add("Kill Player", &mag_p_kill, p);
            self mag_add("Kick Player", &mag_p_kick, p);
            break;

        case "lobby":
            self.mag.title_text = "Lobby Options";
            self mag_add("All Players God Mode", &mag_all, "god");
            self mag_add("All Players Infinite Ammo", &mag_all, "ammo");
            self mag_add("Teleport All To Me", &mag_all, "tele");
            self mag_add("Freeze All", &mag_all, "freeze");
            self mag_add("Unfreeze All", &mag_all, "unfreeze");
            self mag_add("Kill All", &mag_all, "kill");
            self mag_add("Ranked Match (XP)", &mag_ranked, undefined, undefined, "ranked");
            self mag_add("Unlimited Time & Score", &mag_unlimited);
            self mag_add("Low Gravity", &mag_gravity, undefined, undefined, "gravity");
            self mag_add("Super Speed Lobby", &mag_lobby_speed, undefined, undefined, "lspeed");
            self mag_add("Fast Restart", &mag_restart);
            break;

        case "messages":
            self.mag.title_text = "Message Options";
            if (self.mag.host)
                self mag_add("Send To All Players", &mag_msg_all, undefined, undefined, "msgall");
            self mag_add("Hello World", &mag_msg, "^2Hello World !");
            self mag_add("MAG Menu", &mag_msg, "^1MAG ^7Menu ^2BO4");
            self mag_add("Free Palestine", &mag_msg, "^3Free Palestine");
            self mag_add("Fuck Israel", &mag_msg, "^1Fuck Israel");
            self mag_add("Hey brother are you gay?", &mag_msg, "^5Hey brother are you gay?");
            self mag_add("ggwp ez", &mag_msg, "^6ggwp ez !");
            self mag_add("Dev By UrBaaZz & ZERTY", &mag_msg, "^7Dev By ^1UrBaaZz ^7& ^5ZERTY");
            break;

        case "bots":
            self.mag.title_text = "Bots Options";
            self mag_add("Add Bot", &mag_add_bot);
            self mag_add("Fill Lobby (Max Bots)", &mag_fill_bots);
            self mag_add("Kick All Bots", &mag_kick_bots);
            break;

        case "maps":
            self.mag.title_text = "Maps Options";
            self mag_add("Nuketown", &mag_map, "mp_nuketown_4");
            self mag_add("Frequency", &mag_map, "mp_frenetic");
            self mag_add("Seaside", &mag_map, "mp_seaside");
            self mag_add("Jungle", &mag_map, "mp_jungle2");
            self mag_add("Hacienda", &mag_map, "mp_hacienda");
            self mag_add("Militia", &mag_map, "mp_militia");
            self mag_add("Slums", &mag_map, "mp_slums2");
            self mag_add("Icebreaker", &mag_map, "mp_icebreaker");
            self mag_add("Gridlock", &mag_map, "mp_gridlock");
            self mag_add("Contraband", &mag_map, "mp_offshore");
            self mag_add("Morocco", &mag_map, "mp_morocco");
            self mag_add("Summit", &mag_map, "mp_mountain2");
            self mag_add("Casino", &mag_map, "mp_casino");
            self mag_add("Arsenal", &mag_map, "mp_urban");
            self mag_add("Firing Range", &mag_map, "mp_firingrange2");
            self mag_add("Madagascar", &mag_map, "mp_madagascar");
            self mag_add("mp_austria", &mag_map, "mp_austria");
            self mag_add("mp_cairo", &mag_map, "mp_cairo");
            self mag_add("mp_elevation", &mag_map, "mp_elevation");
            self mag_add("mp_embassy", &mag_map, "mp_embassy");
            self mag_add("mp_geothermal", &mag_map, "mp_geothermal");
            self mag_add("mp_maldives", &mag_map, "mp_maldives");
            self mag_add("mp_russianbase", &mag_map, "mp_russianbase");
            self mag_add("mp_silo", &mag_map, "mp_silo");
            self mag_add("mp_station", &mag_map, "mp_station");
            self mag_add("mp_cosmodrome", &mag_map, "mp_cosmodrome");
            break;

        case "settings":
            self.mag.title_text = "Menu Settings";
            self mag_add("Color : MAG Red", &mag_theme, 0);
            self mag_add("Color : Cyan", &mag_theme, 1);
            self mag_add("Color : Green", &mag_theme, 2);
            self mag_add("Color : Purple", &mag_theme, 3);
            self mag_add("Color : Yellow", &mag_theme, 4);
            if (self.mag.bold)
                self mag_add("Display : Center (bold) - change", &mag_display);
            else
                self mag_add("Display : Top-left - change", &mag_display);
            self mag_add("Custom : 3", &mag_set_lines, 3);
            self mag_add("Custom : 5", &mag_set_lines, 5);
            self mag_add("Custom : 6", &mag_set_lines, 6);
            self mag_add("Custom : 7", &mag_set_lines, 7);
            self mag_add("^1MAG ^7Menu " + level.mag_version + " - Dev By ^1UrBaaZz ^7& ^5ZERTY", undefined);
            break;

        default:
            self.mag.title_text = "Main Menu";
            self.mag.menu = "main";
            self mag_build("main");
            break;
    }
}

function mag_close_opt(a, b)
{
    self mag_close();
}

function mag_switch(key)
{
    self.mag.tog[key] = !self mag_tog(key);
    return self.mag.tog[key];
}



function mag_god(a, b)
{
    if (self mag_switch("god"))
    {
        self enableinvulnerability();
        self iprintln("God Mode ^2ON");
    }
    else
    {
        self disableinvulnerability();
        self iprintln("God Mode ^1OFF");
    }
}

function mag_ammo(a, b)
{
    if (self mag_switch("ammo"))
    {
        self iprintln("Infinite Ammo ^2ON");
        self thread mag_ammo_loop();
    }
    else
    {
        self notify(#"mag_ammo_stop");
        self iprintln("Infinite Ammo ^1OFF");
    }
}

function mag_ammo_loop()
{
    self endon(#"disconnect", #"mag_ammo_stop");
    for (;;)
    {
        w = self getcurrentweapon();
        if (isdefined(w) && w != getweapon(#"none"))
        {
            self setweaponammoclip(w, w.clipsize);
            self givemaxammo(w);
        }
        wait 0.1;
    }
}

function mag_maxammo(a, b)
{
    foreach (w in self getweaponslist())
        self givemaxammo(w);
    self iprintln("Max Ammo ^2given");
}


function mag_crouching()
{
    if (self stancebuttonpressed())
        return 1;
    return self getstance() == "crouch";
}

function mag_ufo_set(on)
{
    if (on == self.mag.ufo_on)
        return;
    self.mag.ufo_on = on;
    if (on)
    {
        self.mag.ufo = spawn("script_model", self.origin);
        self.mag.ufo setmodel(#"tag_origin");
        self playerlinkto(self.mag.ufo);
        self iprintln("UFO ^2ON ^7- hold ^3[{+frag}] ^7to fly - ^3[{+stance}] + [{+melee}] ^7to land");
    }
    else
    {
        self unlink();
        if (isdefined(self.mag.ufo))
            self.mag.ufo delete();
        self.mag.ufo = undefined;
        self iprintln("UFO ^1OFF");
    }
}

function mag_ufo(a, b)
{
    self notify(#"mag_ufo_stop");
    if (self mag_switch("ufo"))
    {
        self thread mag_ufo_loop();
        self iprintln("UFO Binds ^2ON ^7- ^3crouch + melee ^7to fly / land");
    }
    else
    {
        self mag_ufo_set(0);
        self iprintln("UFO Binds ^1OFF");
    }
}

function mag_ufo_loop()
{
    self endon(#"disconnect", #"mag_ufo_stop");
    held = 0;
    for (;;)
    {
        waitframe(1);
        if (!self mag_tog("ufo") || !self.mag.access)
        {
            self.mag.tog["ufo"] = 0;
            self mag_ufo_set(0);
            return;
        }
        if (!isalive(self))
        {
            if (self.mag.ufo_on)
                self mag_ufo_set(0);
            held = 1;
            continue;
        }
        if (self.mag.open)
            continue;
        combo = self mag_crouching() && self meleebuttonpressed();
        if (combo && !held)
        {
            held = 1;
            if (self.mag.ufo_on)
                self mag_ufo_set(0);
            else
                self mag_ufo_set(1);
        }
        else if (!combo)
            held = 0;
        if (self.mag.ufo_on && isdefined(self.mag.ufo) && self fragbuttonpressed())
            self.mag.ufo.origin = self.mag.ufo.origin + anglestoforward(self getplayerangles()) * 30;
    }
}


function mag_norecoil(a, b)
{
    self notify(#"mag_recoil_stop");
    if (self mag_switch("norecoil"))
    {
        self thread mag_norecoil_loop();
        self iprintln("No Recoil ^2ON");
    }
    else
        self iprintln("No Recoil ^1OFF");
}

function mag_norecoil_loop()
{
    self endon(#"disconnect", #"mag_recoil_stop");
    prev = undefined;
    for (;;)
    {
        waitframe(1);
        if (!self mag_tog("norecoil") || !self.mag.access)
        {
            self.mag.tog["norecoil"] = 0;
            return;
        }
        if (!isalive(self) || self.mag.open || self mag_tog("spin") || self mag_tog("frozen") || self mag_tog("ufo") && self.mag.ufo_on)
        {
            prev = undefined;
            continue;
        }
        cur = self getplayerangles();
        stick = self getnormalizedcameramovement();
        idle = 1;
        if (isdefined(stick) && (abs(stick[0]) > 0.08 || abs(stick[1]) > 0.08))
            idle = 0;
        engaged = self attackbuttonpressed() && !(self mag_tog("aimbot") && self mag_aim_active());
        if (isdefined(prev) && engaged && idle)
            self setplayerangles(prev);
        else
            prev = cur;
    }
}


function mag_nobarrier(a, b)
{
    if (self mag_switch("nobarrier"))
    {
        self thread mag_nobarrier_loop();
        self thread mag_nobarrier_leave();
        mag_barrier_apply();
        self iprintln("No Death Barrier ^2ON ^7(kill triggers off for everyone)");
    }
    else
    {
        self notify(#"mag_nobarrier_stop");
        self.oobdisabled = 0;
        mag_barrier_apply();
        self iprintln("No Death Barrier ^1OFF");
    }
}

function mag_nobarrier_loop()
{
    self endon(#"disconnect", #"mag_nobarrier_stop");
    for (;;)
    {
        self.oobdisabled = 1;
        wait 0.2;
    }
}


function mag_nobarrier_leave()
{
    self endon(#"mag_nobarrier_stop");
    self waittill(#"disconnect");
    wait 0.5;
    mag_barrier_apply();
}


function mag_barrier_apply()
{
    on = 0;
    foreach (p in getplayers())
    {
        if (isdefined(p) && isdefined(p.mag) && p mag_tog("nobarrier"))
            on = 1;
    }

    names = ["trigger_hurt", "trigger_hurt_new"];
    foreach (n in names)
    {
        foreach (t in getentarray(n, "classname"))
        {
            if (!isdefined(t))
                continue;
            if (on)
            {
                // on memorise l'etat d'origine : certains triggers sont coupes/actives par le script de la map
                if (!isdefined(t.mag_was))
                    t.mag_was = t istriggerenabled();
                t triggerenable(0);
            }
            else if (isdefined(t.mag_was))
            {
                t triggerenable(t.mag_was);
                t.mag_was = undefined;
            }
        }
    }

    if (isdefined(level.oow))
    {
        if (!isdefined(level.mag_oow))
        {
            level.mag_oow = spawnstruct();
            level.mag_oow.min = level.oow.height_min;
            level.mag_oow.max = level.oow.height_max;
        }
        if (on)
        {
            level.oow.height_min = -2147483647;
            level.oow.height_max = 2147483647;
        }
        else
        {
            level.oow.height_min = level.mag_oow.min;
            level.oow.height_max = level.mag_oow.max;
        }
    }
}

function mag_invisible(a, b)
{
    if (self mag_switch("invis"))
    {
        self hide();
        self iprintln("Invisible ^2ON");
    }
    else
    {
        self show();
        self iprintln("Invisible ^1OFF");
    }
}

function mag_third(a, b)
{
    if (self mag_switch("third"))
        self setclientthirdperson(1);
    else
        self setclientthirdperson(0);
}

function mag_sprint(a, b)
{
    if (self mag_switch("sprint"))
    {
        self setperk(#"specialty_unlimitedsprint");
        self iprintln("Unlimited Sprint ^2ON");
    }
    else
    {
        self unsetperk(#"specialty_unlimitedsprint");
        self iprintln("Unlimited Sprint ^1OFF");
    }
}

function mag_superjump(a, b)
{
    if (self mag_switch("sjump"))
    {
        self thread mag_superjump_loop();
        self iprintln("Super Jump ^2ON");
    }
    else
    {
        self notify(#"mag_sjump_stop");
        self iprintln("Super Jump ^1OFF");
    }
}

function mag_superjump_loop()
{
    self endon(#"disconnect", #"mag_sjump_stop");
    was = 1;
    for (;;)
    {
        g = self isonground();
        if (was && !g && !self.mag.open)
        {
            v = self getvelocity();
            if (v[2] > 10)
            {
                // le jeu recalcule la vitesse du saut sur quelques images : on pousse 3 images de suite
                for (k = 0; k < 3; k++)
                {
                    v = self getvelocity();
                    self setvelocity((v[0], v[1], 950));
                    waitframe(1);
                }
            }
        }
        was = self isonground();
        waitframe(1);
    }
}

function mag_speed(a, b)
{
    self.mag.speed++;
    if (self.mag.speed > 3)
        self.mag.speed = 1;
    self setmovespeedscale(self.mag.speed);
    self iprintln("Speed ^3x" + self.mag.speed);
}

function mag_suicide(a, b)
{
    self mag_close();
    self suicide();
}


function mag_fov(a, b)
{
    if (!self ishost())
    {
        self iprintln("^1FOV : host only");
        return;
    }
    if (!isdefined(self.mag.fov_base))
    {
        base = getdvarfloat(#"cg_fov_default", 0);
        if (base <= 0)
            base = 80;
        self.mag.fov_base = base;
        cur = getdvarfloat(#"cg_fov", 0);
        if (cur <= 0)
            cur = base;
        self.mag.fov_base_cur = cur;
        self iprintln("^3dbg ^7origine : cg_fov_default=" + base + " cg_fov=" + cur);
    }
    values = [100, 90, 110, 120, 80, 65, 0];
    self.mag.fov = mag_aim_next(values, self.mag.fov);
    self notify(#"mag_fov_stop");
    if (self.mag.fov > 0)
    {
        setdvar(#"cg_fov_default", self.mag.fov);
        setdvar(#"cg_fov", self.mag.fov);
        self thread mag_fov_loop();
        self iprintln("FOV ^3" + self.mag.fov);
    }
    else
    {
        setdvar(#"cg_fov_default", self.mag.fov_base);
        setdvar(#"cg_fov", self.mag.fov_base_cur);
        self resetfov();
        self iprintln("FOV ^3default");
    }
    waitframe(2);
    self iprintln("^3dbg ^7cg_fov=" + getdvarfloat(#"cg_fov", 0) + " cg_fov_default=" + getdvarfloat(#"cg_fov_default", 0));
    self mag_load("self");
}

function mag_fov_loop()
{
    self endon(#"disconnect", #"mag_fov_stop");
    for (;;)
    {
        if (self.mag.fov > 0)
        {
            if (getdvarfloat(#"cg_fov_default", 0) != self.mag.fov)
                setdvar(#"cg_fov_default", self.mag.fov);
            if (getdvarfloat(#"cg_fov", 0) != self.mag.fov)
                setdvar(#"cg_fov", self.mag.fov);
        }
        wait 0.25;
    }
}


function mag_perk(perk, key)
{
    if (self mag_switch(key))
    {
        self setperk(perk);
        self iprintln("Perk ^2ON");
    }
    else
    {
        self unsetperk(perk);
        self iprintln("Perk ^1OFF");
    }
}

function mag_perk_keys()
{
    return ["p_reload", "p_hands", "p_ads", "p_quiet", "p_sprintfire"];
}

function mag_perk_names()
{
    return [#"specialty_fastreload", #"specialty_fastweaponswitch", #"specialty_fastads", #"specialty_quieter", #"specialty_sprintfire"];
}


function mag_spawn_restore()
{
    self endon(#"disconnect", #"death");
    wait 1;
    keys = mag_perk_keys();
    names = mag_perk_names();
    for (i = 0; i < keys.size; i++)
    {
        if (self mag_tog(keys[i]))
            self setperk(names[i]);
    }
}

function mag_heal(a, b)
{
    if (!isalive(self))
        return;
    self.health = self.maxhealth;
    self iprintln("Health ^2restored");
}

function mag_autoheal(a, b)
{
    if (self mag_switch("autoheal"))
    {
        self thread mag_autoheal_loop();
        self iprintln("Auto Heal ^2ON");
    }
    else
    {
        self notify(#"mag_heal_stop");
        self iprintln("Auto Heal ^1OFF");
    }
}

function mag_autoheal_loop()
{
    self endon(#"disconnect", #"mag_heal_stop");
    for (;;)
    {
        if (isalive(self) && isdefined(self.maxhealth) && self.health < self.maxhealth)
            self.health = self.maxhealth;
        wait 0.2;
    }
}


function mag_abilities(a, b)
{
    if (self mag_switch("iabil"))
    {
        self thread mag_abilities_loop();
        self iprintln("Infinite Abilities ^2ON");
    }
    else
    {
        self notify(#"mag_abil_stop");
        self iprintln("Infinite Abilities ^1OFF");
    }
}

function mag_abilities_loop()
{
    self endon(#"disconnect", #"mag_abil_stop");
    for (;;)
    {
        if (isalive(self))
        {
            foreach (w in self getweaponslist())
            {
                if (isdefined(w.isgadget) && w.isgadget)
                {
                    slot = self gadgetgetslot(w);
                    if (slot >= 0 && slot < 3)
                        self gadgetpowerset(slot, 100);
                }
            }
            if (isdefined(self.grenadetypeprimary) && isdefined(self.grenadetypeprimarycount))
                self setweaponammoclip(self.grenadetypeprimary, self.grenadetypeprimarycount);
        }
        wait 0.5;
    }
}


function mag_msg_all(a, b)
{
    if (self mag_switch("msgall"))
        self iprintln("Messages sent to ^2all players");
    else
        self iprintln("Messages sent to ^1me only");
}

function mag_msg(text, b)
{
    if (self mag_tog("msgall"))
    {
        foreach (p in getplayers())
        {
            if (isdefined(p) && !isbot(p))
                p iprintlnbold(text);
        }
    }
    else
        self iprintlnbold(text);
}


function mag_skin_list()
{
    // index des specialistes MP : Ajax, Battery, Crash, Firebreak, Nomad, Outrider, Prophet, Recon, Reaper, Ruin, Seraph, Spectre, Torque, Zero
    return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
}

function mag_skin_apply(index)
{
    self setcharacterbodytype(index);
    self setcharacteroutfit(0);
}

function mag_skin_toggle(a, b)
{
    self notify(#"mag_skin_stop");
    if (self mag_switch("skinloop"))
    {
        self thread mag_skin_loop();
        self iprintln("Loop Skin ^2ON");
    }
    else
        self iprintln("Loop Skin ^1OFF");
}

function mag_skin_loop()
{
    self endon(#"disconnect", #"mag_skin_stop");
    list = mag_skin_list();
    last = -1;
    for (;;)
    {
        wait 1;
        if (!self mag_tog("skinloop") || !self.mag.access)
        {
            self.mag.tog["skinloop"] = 0;
            return;
        }
        if (!isalive(self))
            continue;
        pick = list[randomint(list.size)];
        if (pick == last)
            continue;
        last = pick;
        self mag_skin_apply(pick);
    }
}


function mag_give(name, b)
{
    w = getweapon(name);
    if (!isdefined(w) || w == getweapon(#"none"))
    {
        self iprintln("^1Weapon not available here");
        return;
    }
    self giveweapon(w);
    self givemaxammo(w);
    self switchtoweapon(w);
    self iprintln("Weapon ^2given");
}


function mag_camo_list()
{
    return [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
        22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42,
        43, 44, 45, 199, 192,
        146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160,
        161, 162, 163, 164, 165, 280, 281, 282, 283, 284, 74, 75, 76, 77, 78, 345, 394,
        298, 300, 310, 52, 57, 62, 67, 89, 90, 119, 129, 131, 167, 168, 381, 387, 389, 286, 357, 359, 363,
        79, 118, 46, 47, 48, 49, 50, 51, 80, 81, 82, 83, 84, 86, 87, 117, 120, 121, 122, 123, 124, 126,
        134, 135, 136, 137, 166, 170, 171, 172, 173, 293, 305, 314, 315, 316, 317, 346, 347, 348, 350, 351, 353, 354, 355
    ];
}

function mag_camo_toggle(a, b)
{
    self notify(#"mag_camo_stop");
    if (self mag_switch("camoloop"))
    {
        self thread mag_camo_loop();
        self iprintln("Camo Loop ^2ON");
    }
    else
        self iprintln("Camo Loop ^1OFF");
}

function mag_camo_loop()
{
    self endon(#"disconnect", #"mag_camo_stop");
    list = mag_camo_list();
    i = 0;
    for (;;)
    {
        wait 0.1;
        if (!self mag_tog("camoloop") || !self.mag.access)
        {
            self.mag.tog["camoloop"] = 0;
            return;
        }
        if (!isalive(self) || self.mag.open)
            continue;
        w = self getcurrentweapon();
        if (!isdefined(w) || w == getweapon(#"none") || (isdefined(w.isgadget) && w.isgadget))
            continue;
        i++;
        if (i >= list.size)
            i = 0;
        // setcamo : change le camo de l'arme en main sans la retirer ni la redonner (pas d'animation)
        self setcamo(w, list[i]);
    }
}


function mag_camo_set(id, b)
{
    if (self mag_tog("camoloop"))
    {
        self.mag.tog["camoloop"] = 0;
        self notify(#"mag_camo_stop");
        self iprintln("Camo Loop ^1OFF");
    }
    w = self getcurrentweapon();
    if (!isdefined(w) || w == getweapon(#"none") || (isdefined(w.isgadget) && w.isgadget))
    {
        self iprintln("^1No weapon in hand");
        return;
    }
    self setcamo(w, id);
    self iprintln("Camo ^2applied ^7(" + id + ")");
}

function mag_take_weapon(a, b)
{
    self takeweapon(self getcurrentweapon());
}

function mag_drop_weapon(a, b)
{
    self dropitem(self getcurrentweapon());
}


function mag_jetpack(a, b)
{
    if (self mag_switch("jetpack"))
    {
        self thread mag_jetpack_loop();
        self iprintln("Jetpack ^2ON ^7- hold ^3[X]");
    }
    else
    {
        self notify(#"mag_jetpack_stop");
        self iprintln("Jetpack ^1OFF");
    }
}

function mag_jetpack_loop()
{
    self endon(#"disconnect", #"mag_jetpack_stop");
    for (;;)
    {
        if (self jumpbuttonpressed() && !self.mag.open)
        {
            v = self getvelocity();
            z = v[2] + 60;
            if (z > 350)
                z = 350;
            self setvelocity((v[0], v[1], z));
        }
        waitframe(1);
    }
}

function mag_aim_pos()
{
    eye = self geteye();
    trace = bullettrace(eye, eye + anglestoforward(self getplayerangles()) * 100000, 0, self);
    return trace[#"position"];
}

function mag_rocket_rain(a, b)
{
    w = getweapon(#"launcher_standard_t8");
    pos = self mag_aim_pos();
    self iprintln("Rocket Rain ^2incoming");
    for (i = 0; i < 12; i++)
    {
        start = pos + (randomintrange(-400, 400), randomintrange(-400, 400), 2500);
        magicbullet(w, start, pos + (randomintrange(-250, 250), randomintrange(-250, 250), 0), self);
        wait 0.15;
    }
}

function mag_quake(a, b)
{
    earthquake(0.6, 4, self.origin, 1500);
}


function mag_spin(a, b)
{
    if (self mag_switch("spin"))
        self thread mag_spin_loop();
    else
        self notify(#"mag_spin_stop");
}

function mag_spin_loop()
{
    self endon(#"disconnect", #"mag_spin_stop");
    for (;;)
    {
        a = self getplayerangles();
        self setplayerangles((a[0], a[1] + 12, a[2]));
        waitframe(1);
    }
}


function mag_bullets(type, b)
{
    key = "b_" + type;
    on = !self mag_tog(key);
    self.mag.tog["b_explosive"] = 0;
    self.mag.tog["b_rocket"] = 0;
    self.mag.tog["b_teleport"] = 0;
    self notify(#"mag_bullets_stop");
    if (!on)
    {
        self iprintln("Bullets ^1OFF");
        return;
    }
    self.mag.tog[key] = 1;
    self thread mag_bullets_loop(type);
    self iprintln("Bullets ^2" + type);
}

function mag_bullets_off(a, b)
{
    self.mag.tog["b_explosive"] = 0;
    self.mag.tog["b_rocket"] = 0;
    self.mag.tog["b_teleport"] = 0;
    self notify(#"mag_bullets_stop");
    self iprintln("Bullets ^1OFF");
}

function mag_bullets_loop(type)
{
    self endon(#"disconnect", #"mag_bullets_stop");
    rocket = getweapon(#"launcher_standard_t8");
    for (;;)
    {
        self waittill(#"weapon_fired");
        pos = self mag_aim_pos();
        if (type == "explosive")
        {
            dir = anglestoforward(self getplayerangles());
            magicbullet(rocket, pos - dir * 24, pos, self);
            radiusdamage(pos, 250, 300, 50, self, "MOD_EXPLOSIVE");
            earthquake(0.3, 0.5, pos, 400);
        }
        else if (type == "rocket")
        {
            magicbullet(rocket, self geteye() + anglestoforward(self getplayerangles()) * 50, pos, self);
        }
        else if (type == "teleport")
        {
            self setorigin(pos);
        }
    }
}


function mag_tele_cross(a, b)
{
    self setorigin(self mag_aim_pos());
}

function mag_save_pos(a, b)
{
    self.mag.pos = self.origin;
    self.mag.ang = self getplayerangles();
    self iprintln("Position ^2saved");
}

function mag_load_pos(a, b)
{
    if (!isdefined(self.mag.pos))
    {
        self iprintln("^1No position saved");
        return;
    }
    self setorigin(self.mag.pos);
    self setplayerangles(self.mag.ang);
}

function mag_tele_sky(a, b)
{
    self setorigin(self.origin + (0, 0, 2000));
}



function mag_pick_player(p, b)
{
    self.mag.target = p;
    self mag_load("player");
}

function mag_p_access(p, value)
{
    if (!isdefined(p) || !isdefined(p.mag))
        return;
    p.mag.access = value;
    if (value)
    {
        p iprintlnbold("^1MAG ^7Menu ^2unlocked ^7: ^3[{+frag}] + [{+usereload}]");
        self iprintln(p.name + " ^2has the menu");
    }
    else
    {
        p.mag.tog["aimbot"] = 0;
        p notify(#"mag_aim_stop");
        if (p.mag.open)
            p mag_close();
        p iprintlnbold("^1MAG ^7Menu ^1removed");
        self iprintln(p.name + " ^1lost the menu");
    }
}

function mag_p_god(p, b)
{
    if (!isdefined(p) || !isdefined(p.mag))
        return;
    if (p mag_switch("god"))
    {
        p enableinvulnerability();
        self iprintln(p.name + " God Mode ^2ON");
    }
    else
    {
        p disableinvulnerability();
        self iprintln(p.name + " God Mode ^1OFF");
    }
}

function mag_p_freeze(p, b)
{
    if (!isdefined(p) || !isdefined(p.mag))
        return;
    if (p mag_switch("frozen"))
    {
        p freezecontrols(1);
        self iprintln(p.name + " ^1frozen");
    }
    else
    {
        p freezecontrols(0);
        self iprintln(p.name + " ^2unfrozen");
    }
}

function mag_p_tele_to_me(p, b)
{
    if (isdefined(p))
        p setorigin(self.origin);
}

function mag_p_tele_me(p, b)
{
    if (isdefined(p))
        self setorigin(p.origin);
}

function mag_p_kill(p, b)
{
    if (isdefined(p) && isalive(p))
        p suicide();
}

function mag_p_kick(p, b)
{
    if (!isdefined(p) || p == self)
        return;
    kick(p getentitynumber());
    self mag_load("players");
}


function mag_all(what, b)
{
    foreach (p in getplayers())
    {
        if (p == self)
            continue;
        if (!isdefined(p.mag))
            p mag_setup();
        if (what == "god")
        {
            p.mag.tog["god"] = 1;
            p enableinvulnerability();
        }
        else if (what == "ammo")
        {
            if (!p mag_tog("ammo"))
            {
                p.mag.tog["ammo"] = 1;
                p thread mag_ammo_loop();
            }
        }
        else if (what == "tele")
            p setorigin(self.origin);
        else if (what == "freeze")
            p freezecontrols(1);
        else if (what == "unfreeze")
            p freezecontrols(0);
        else if (what == "kill")
        {
            if (isalive(p))
                p suicide();
        }
    }
    self iprintln("Done for ^3all players");
}

function mag_unlimited(a, b)
{
    setgametypesetting(#"timelimit", 0);
    setgametypesetting(#"scorelimit", 0);
    self iprintln("Unlimited Time & Score ^2ON");
}

function mag_gravity(a, b)
{
    if (self mag_switch("gravity"))
    {
        setdvar(#"bg_gravity", 200);
        self iprintln("Low Gravity ^2ON");
    }
    else
    {
        setdvar(#"bg_gravity", 800);
        self iprintln("Low Gravity ^1OFF");
    }
}

function mag_lobby_speed(a, b)
{
    if (self mag_switch("lspeed"))
    {
        setdvar(#"g_speed", 500);
        self iprintln("Super Speed Lobby ^2ON");
    }
    else
    {
        setdvar(#"g_speed", 190);
        self iprintln("Super Speed Lobby ^1OFF");
    }
}

function mag_add_bot(a, b)
{
    bot = addtestclient();
    if (!isdefined(bot))
        self iprintln("^1No free slot for a bot");
    else
        self iprintln("Bot ^2added");
}


function mag_fill_bots(a, b)
{
    self thread mag_fill_bots_run();
}

function mag_fill_bots_run()
{
    self endon(#"disconnect");
    if (isdefined(level.mag_filling) && level.mag_filling)
        return;
    level.mag_filling = 1;
    added = 0;
    for (i = 0; i < 18; i++)
    {
        bot = addtestclient();
        if (!isdefined(bot))
            break;
        added++;
        wait 0.25;
    }
    level.mag_filling = 0;
    if (added > 0)
        self iprintln("Lobby filled : ^2" + added + " ^7bots added");
    else
        self iprintln("^1Lobby already full");
}

function mag_kick_bots(a, b)
{
    count = 0;
    foreach (p in getplayers())
    {
        if (isdefined(p) && isbot(p))
        {
            kick(p getentitynumber());
            count++;
        }
    }
    self iprintln("^2" + count + " ^7bots kicked");
}

function mag_restart(a, b)
{
    map_restart(1);
}

function mag_map(name, b)
{
    self iprintlnbold("Loading ^3" + name);
    wait 1;
    map(name);
}

function mag_theme(index, b)
{
    self.mag.theme = index;
}

function mag_set_lines(n, b)
{
    self.mag.lines = n;
}

// bascule l'affichage du menu : haut gauche (iprintln) <-> milieu de l'ecran (iprintlnbold)
function mag_display(a, b)
{
    self mag_clear();
    self.mag.bold = !self.mag.bold;
    self mag_load("settings");
}

function mag_upload()
{
    wait 0.1;
    uploadstats(self);
}

function mag_upload_stats(a, b)
{
    uploadstats(self);
    self iprintlnbold("Stats ^2uploaded");
}

function mag_max_rank()
{
    r = level.var_54c3050a;
    if (!isdefined(r) || r < 1 || r > 200)
        r = 54;
    return r;
}

function mag_refresh_rank()
{
    p = self mag_stat(#"plevel");
    r = self mag_stat(#"rank");
    self.pers[#"rank"] = r;
    self.pers[#"plevel"] = p;
    self setrank(r, p);
}

function mag_rank_max(a, b)
{
    r = mag_max_rank();
    xp = getrankminxp(r);
    self stats::set_stat_global(#"rankxp", xp, 1);
    self stats::set_stat_global(#"rank", r, 1);
    self.pers[#"rankxp"] = xp;
    self mag_refresh_rank();
    self mag_upload();
    self iprintlnbold("Rank Max ^2done ^7(level " + (r + 1) + ") - stats uploaded");
}

function mag_set_prestige(p, b)
{
    self stats::set_stat_global(#"plevel", p, 1);
    self mag_refresh_rank();
    self mag_upload();
    self iprintlnbold("Prestige ^2" + p + " ^7set - stats uploaded");
}

function mag_paragon_max(a, b)
{
    maxp = level.var_50c857b7;
    if (!isdefined(maxp) || maxp < 1 || maxp > 20)
        maxp = 11;
    self stats::set_stat_global(#"plevel", maxp, 1);
    self stats::set_stat_global(#"paragon_rank", 1000, 1);
    self function_bcb12efa(1000);
    self mag_refresh_rank();
    self mag_upload();
    self iprintlnbold("Prestige Master ^2Level 1000 - stats uploaded");
}

function mag_unlock_all(a, b)
{
    self mag_rank_max();
    wait 0.5;
    self mag_paragon_max();
    self iprintlnbold("Unlock All ^2done ^7(Rank Max + Prestige Master 1000)");
}

function mag_stat(name)
{
    v = self stats::get_stat_global(name, 1);
    if (!isdefined(v))
        return 0;
    return v;
}

function mag_show_stats(a, b)
{
    self iprintln("Level ^3" + (self mag_stat(#"rank") + 1) + " ^7- Prestige ^3" + self mag_stat(#"plevel") + " ^7- XP ^3" + self mag_stat(#"rankxp") + " ^7- Master ^3" + self mag_stat(#"paragon_rank"));
}

function mag_ranked(a, b)
{
    if (!isdefined(level.mag_ranked_save))
    {
        level.mag_ranked_save = [];
        level.mag_ranked_save[0] = level.rankedmatch;
        level.mag_ranked_save[1] = level.custommatch;
        level.mag_ranked_save[2] = level.var_4f35d4f2;
    }
    if (self mag_switch("ranked"))
    {
        level.rankedmatch = 1;
        level.custommatch = 0;
        level.var_4f35d4f2 = 0;
        self iprintlnbold("Ranked Match ^2ON ^7- XP & stats like an official match");
    }
    else
    {
        level.rankedmatch = level.mag_ranked_save[0];
        level.custommatch = level.mag_ranked_save[1];
        level.var_4f35d4f2 = level.mag_ranked_save[2];
        self iprintlnbold("Ranked Match ^1OFF");
    }
}

function mag_trophy_ready()
{
    if (!sessionmodeismultiplayergame() || isbot(self) || isarenamode())
    {
        self iprintln("^1Multiplayer standard player required");
        return 0;
    }
    if (isdefined(level.disablestattracking) && level.disablestattracking)
    {
        self iprintln("^1Stats disabled by this game mode");
        return 0;
    }
    return 1;
}

function mag_trophy_stat_at_least(name, minimum)
{
    before = self stats::get_stat_global(name, 1);
    if (!isdefined(before))
        return 0;
    if (before < minimum)
        self stats::set_stat_global(name, minimum, 1);
    after = self stats::get_stat_global(name, 1);
    return isdefined(after) && after >= minimum;
}

function mag_trophy_medals(equipment)
{
    if (equipment)
        return [#"stats_swat_grenade_multikill_x2_summary", #"stats_cluster_semtex_multikill_x2_summary",
                #"hash_3427f2d4181d570", #"stats_radiation_field_multikill_x2_summary",
                #"stats_tripwire_ied_multikill_x2_summary", #"stats_seeker_shock_mine_paralyzed_headshot",
                #"stats_sensor_dart_multikill_x2_summary", #"stats_grapple_gun_multikill_x2_summary",
                #"stats_spawn_beacon_multikill_x2_summary", #"stats_concertina_wire_multikill_x2_summary"];
    return [#"stats_battle_shield_x2_multikill_summary", #"stats_war_machine_x2_multikill_summary",
            #"stats_tak5_multikill_x2_multikill_summary", #"stats_purifier_x2_multikill_summary",
            #"stats_attack_dog_x2_multikill_summary", #"stats_tempest_x2_multikill_summary",
            #"stats_vision_pulse_x2_multikill_summary", #"stats_gravity_slam_multikill_x2",
            #"stats_annihilator_x2_multikill_summary", #"stats_deployable_cover_x2_multikill_summary"];
}

function mag_trophy_sum(names)
{
    total = 0;
    foreach (name in names)
    {
        value = self stats::get_stat_global(name, 1);
        if (!isdefined(value))
            return -1;
        total += value;
    }
    return total;
}

function mag_trophy_fill_medals(equipment)
{
    names = mag_trophy_medals(equipment);
    total = self mag_trophy_sum(names);
    if (total < 0)
        return 0;
    // Le trophee porte sur la somme des medailles, pas sur dix de CHAQUE type.
    if (total < 10)
    {
        value = self stats::get_stat_global(names[0], 1);
        if (!self mag_trophy_stat_at_least(names[0], value + 10 - total))
            return 0;
    }
    return self mag_trophy_sum(names) >= 10;
}

function mag_all_trophies(a, b)
{
    if (!self mag_trophy_ready())
        return;
    if (isdefined(self.mag.trophy_running) && self.mag.trophy_running)
        return;
    self.mag.trophy_running = 1;
    self thread mag_trophy_progress();
}

function mag_trophy_progress(full)
{
    self endon(#"disconnect");
    self iprintln("^3Checking MP trophy progression...");
    count = 0;
    // Ne jamais abaisser le rang, l'XP ou le prestige existants.
    rank = self stats::get_stat_global(#"rank", 1);
    rankok = isdefined(rank);
    if (rankok && rank < 54)
    {
        rankok = self mag_trophy_stat_at_least(#"rankxp", getrankminxp(54));
        if (rankok)
            rankok = self mag_trophy_stat_at_least(#"rank", 54);
        if (rankok)
        {
            self.pers[#"rankxp"] = self mag_stat(#"rankxp");
            self mag_refresh_rank();
        }
    }
    if (rankok && self mag_stat(#"rank") >= 54)
    {
        self giveachievement("mp_trophy_welcome_to_the_club");
        wait 1;
        self giveachievement("mp_trophy_battle_tested");
        count += 2;
    }
    else
        self iprintln("^1Rank write failed - rank trophies skipped");
    wait 1;
    if (self mag_trophy_stat_at_least(#"wins", 50))
    {
        self giveachievement("mp_trophy_vanquisher");
        count++;
    }
    else
        self iprintln("^1Wins write failed - trophy skipped");
    wait 1;
    if (self mag_trophy_fill_medals(0))
    {
        self giveachievement("mp_trophy_special_issue_weaponry");
        count++;
    }
    else
        self iprintln("^1Weapon medals unavailable - trophy skipped");
    wait 1;
    if (self mag_trophy_fill_medals(1))
    {
        self giveachievement("mp_trophy_special_issue_equipment");
        count++;
    }
    else
        self iprintln("^1Equipment medals unavailable - trophy skipped");
    self mag_upload();
    if (isdefined(full) && full)
    {
        self mag_trophy_remaining(count);
        self.mag.trophy_running = 0;
        return;
    }
    self.mag.trophy_running = 0;
    self iprintlnbold("MP progression checked: ^3" + count + "/5 ^7trophy requests");
    self iprintln("^3Stats uploaded - check progression and trophies");
}

function mag_trophy_status(a, b)
{
    if (!sessionmodeismultiplayergame())
        return;
    self iprintln("MP Level ^3" + (self mag_stat(#"rank") + 1) + "^7/55 - Wins ^3" + self mag_stat(#"wins") + "^7/50");
    self iprintln("Weapon medals ^3" + self mag_trophy_sum(mag_trophy_medals(0)) + "^7/10 - Equipment ^3" + self mag_trophy_sum(mag_trophy_medals(1)) + "^7/10");
    self iprintln("^7These are game counters; check PS4 trophy list separately");
}

// 102 identifiants presentes dans le catalogue DDL du PKG PS4 1.26.
// Le platine est attribue par la PS4, pas par un identifiant GSC invente.
// Les 97 demandes suivantes ne modifient pas les statistiques des autres modes.
function mag_all_trophies_full(a, b)
{
    if (!self mag_trophy_ready())
        return;
    if (isdefined(self.mag.trophy_running) && self.mag.trophy_running)
    {
        self iprintln("^3Trophy requests already running");
        return;
    }
    self.mag.trophy_cancel = 0;
    self.mag.trophy_sent = 0;
    self.mag.trophy_last = "MP progression";
    self.mag.trophy_running = 1;
    self thread mag_trophy_progress(1);
}

function mag_trophy_cancel(a, b)
{
    self.mag.trophy_cancel = 1;
    self iprintln("^3Stop requested - current MP checks may finish first");
}

function mag_trophy_remaining(mp_count)
{
    names = mag_trophy_other_names();
    self.mag.trophy_sent = mp_count;
    self iprintln("^3Full trophy requests: about 2 minutes");
    foreach (name in names)
    {
        if (self.mag.trophy_cancel)
        {
            self iprintlnbold("Stopped: ^3" + self.mag.trophy_sent + "/102 ^7requests");
            return;
        }
        self.mag.trophy_last = name;
        self iprintln("^3" + (self.mag.trophy_sent + 1) + "/102 ^7" + name);
        self giveachievement(name);
        self.mag.trophy_sent++;
        wait 1;
    }
    self mag_upload();
    self iprintlnbold("Finished: ^3" + self.mag.trophy_sent + "/102 ^7trophy requests");
    self iprintln("^7Check PS4 trophies; Platinum is awarded by the console");
}

function mag_trophy_other_names()
{
    return [
        "st_centennial",
        "st_mp101",
        "st_skirmisher",
        "st_sleuth",
        "st_stargazer",
        "wz_blackout_historian",
        "wz_first_win",
        "wz_not_a_fluke",
        "wz_specialist_super_fan",
        "wz_zombie_fanatic",
        "zm_escape_gat",
        "zm_escape_hist_reenact",
        "zm_escape_hot_stuff",
        "zm_escape_match_made",
        "zm_escape_most_escape",
        "zm_escape_patch_up",
        "zm_escape_senseless",
        "zm_escape_throw_dog",
        "zm_escape_west_side",
        "zm_mansion_alchemical",
        "zm_mansion_artifact",
        "zm_mansion_bite",
        "zm_mansion_board",
        "zm_mansion_clock",
        "zm_mansion_crafting",
        "zm_mansion_quick",
        "zm_mansion_shocking",
        "zm_mansion_shrinking",
        "zm_mansion_stake",
        "zm_office_cold_war",
        "zm_office_crawl",
        "zm_office_everywhere",
        "zm_office_gas",
        "zm_office_ice",
        "zm_office_office",
        "zm_office_pentupagon",
        "zm_office_power",
        "zm_office_shock",
        "zm_office_strike",
        "zm_orange_ascend",
        "zm_orange_bells",
        "zm_orange_freeze",
        "zm_orange_hounds",
        "zm_orange_jar",
        "zm_orange_pack",
        "zm_orange_power",
        "zm_orange_secret",
        "zm_orange_totems",
        "zm_orange_ziplines",
        "zm_red_defense",
        "zm_red_eagle",
        "zm_red_follower",
        "zm_red_gods",
        "zm_red_mountains",
        "zm_red_no_obol",
        "zm_red_sun",
        "zm_red_tragedy",
        "zm_red_tribute",
        "zm_red_wind",
        "zm_rush_multiplier_100",
        "zm_rush_personal_score",
        "zm_rush_team_score",
        "zm_towers_arena_survive",
        "zm_towers_boss_kill",
        "zm_towers_challenges",
        "zm_towers_dismember",
        "zm_towers_fast_pap",
        "zm_towers_get_ww",
        "zm_towers_kitty_kitty",
        "zm_towers_trap_build",
        "zm_towers_ww_kills",
        "zm_trophy_doctor_is_in",
        "zm_trophy_gold",
        "zm_trophy_jack_of_all_blades",
        "zm_trophy_perkaholic_relapse",
        "zm_trophy_straw_purchase",
        "zm_tutorial_completion",
        "zm_white_knuckles",
        "zm_white_mod",
        "zm_white_pap",
        "zm_white_perk",
        "zm_white_roof",
        "zm_white_shard",
        "zm_white_starting",
        "zm_white_stun",
        "zm_white_trap",
        "zm_white_unlock",
        "zm_zodt8_artifact",
        "zm_zodt8_deep_end",
        "zm_zodt8_little_pack",
        "zm_zodt8_rock_paper",
        "zm_zodt8_shortcut",
        "zm_zodt8_stoking",
        "zm_zodt8_stowaway",
        "zm_zodt8_swimming",
        "zm_zodt8_tentacle",
        "zm_zodt8_trial_step_1"
    ];
}


function mag_aim_init()
{
    self.mag.aim_mode = 0;
    self.mag.aim_bone = 0;
    self.mag.aim_fov = 30;
    self.mag.aim_range = 6000;
    self.mag.aim_smooth = 2;
    self.mag.aim_nextshot = 0;
    self.mag.tog["aim_visible"] = 1;
    self.mag.tog["aim_debug"] = 0;
}

function mag_aim_mode_name(mode)
{
    if (mode == 1)
        return "Hold R2 (fire)";
    if (mode == 2)
        return "Always on";
    return "Hold L[{+speed_throw}]";
}

function mag_aim_toggle(a, b)
{
    self notify(#"mag_aim_stop");
    if (self mag_switch("aimbot"))
    {
        self thread mag_aim_loop();
        self iprintln("Aimbot ^2ON ^7- " + mag_aim_mode_name(self.mag.aim_mode));
    }
    else
        self iprintln("Aimbot ^1OFF");
}

function mag_aim_option(key, b)
{
    self mag_switch(key);
}

function mag_aim_cycle(key, b)
{
    if (key == "mode")
    {
        self.mag.aim_mode++;
        if (self.mag.aim_mode > 2)
            self.mag.aim_mode = 0;
    }
    else if (key == "bone")
        self.mag.aim_bone = !self.mag.aim_bone;
    else if (key == "fov")
    {
        values = [15, 30, 60, 90, 180];
        self.mag.aim_fov = mag_aim_next(values, self.mag.aim_fov);
    }
    else if (key == "range")
    {
        values = [1500, 3000, 6000, 12000];
        self.mag.aim_range = mag_aim_next(values, self.mag.aim_range);
    }
    else if (key == "smooth")
    {
        values = [1, 2, 4, 8];
        self.mag.aim_smooth = mag_aim_next(values, self.mag.aim_smooth);
    }
    self mag_load("aimbot");
}

function mag_aim_next(values, value)
{
    for (i = 0; i < values.size - 1; i++)
        if (values[i] == value)
            return values[i + 1];
    return values[0];
}

function mag_aim_point(p)
{
    if (self.mag.aim_bone)
        point = p gettagorigin("j_spineupper");
    else
        point = p gettagorigin("j_head");
    if (!isdefined(point))
        point = p geteye();
    return point;
}

function mag_aim_enemy(p)
{
    if (!isdefined(p) || p == self || !isalive(p))
        return 0;
    if (isdefined(level.teambased) && level.teambased && isdefined(self.team) && isdefined(p.team) && p.team == self.team)
        return 0;
    return 1;
}

function mag_aim_visible(eye, point, p)
{
    trace = bullettrace(eye, point, 1, self);
    if (!isdefined(trace) || !isdefined(trace[#"fraction"]))
        return 1;
    if (trace[#"fraction"] >= 0.97)
        return 1;
    if (isdefined(trace[#"entity"]) && trace[#"entity"] == p)
        return 1;
    return 0;
}

function mag_aim_wallshot(target, point, eye)
{
    if (gettime() < self.mag.aim_nextshot)
        return;
    if (!self attackbuttonpressed())
        return;
    if (!isdefined(target) || !isalive(target))
        return;
    weapon = self getcurrentweapon();
    if (!isdefined(weapon) || weapon == level.weaponnone)
        return;
    if (self getweaponammoclip(weapon) <= 0)
        return;
    if (self mag_aim_visible(eye, point, target))
        return;
    self.mag.aim_nextshot = gettime() + 100;
    target dodamage(100, point, self, self, "head", "MOD_HEAD_SHOT", 0, weapon);
    self playlocalsound(#"mpl_hit_alert");
}

function mag_aim_active()
{
    if (self.mag.aim_mode == 1)
        return self attackbuttonpressed();
    if (self.mag.aim_mode == 2)
        return 1;
    return self adsbuttonpressed();
}

function mag_aim_delta(angle)
{
    while (angle > 180)
        angle -= 360;
    while (angle < -180)
        angle += 360;
    return angle;
}

function mag_aim_loop()
{
    self endon(#"disconnect", #"mag_aim_stop");
    dbgtime = 0;
    for (;;)
    {
        waitframe(1);
        if (!self mag_tog("aimbot") || !self.mag.access)
        {
            self.mag.tog["aimbot"] = 0;
            return;
        }
        if (!isalive(self) || self.mag.open || self mag_tog("spin") || self mag_tog("frozen"))
            continue;
        if (!self mag_aim_active())
            continue;
        eye = self geteye();
        current = self getplayerangles();
        forward = anglestoforward(current);
        maxdist = self.mag.aim_range * self.mag.aim_range;
        mindot = cos(self.mag.aim_fov);
        best = undefined;
        bestpoint = undefined;
        bestdot = -2;
        n_enemy = 0;
        n_range = 0;
        n_cone = 0;
        n_vis = 0;
        foreach (p in getplayers())
        {
            if (!self mag_aim_enemy(p))
                continue;
            n_enemy++;
            point = self mag_aim_point(p);
            dist = distancesquared(eye, point);
            if (dist < 1 || dist > maxdist)
                continue;
            n_range++;
            dot = vectordot(forward, vectornormalize(point - eye));
            if (dot < mindot)
                continue;
            n_cone++;
            if (self mag_tog("aim_visible") && !self mag_aim_visible(eye, point, p))
                continue;
            n_vis++;
            if (dot > bestdot)
            {
                best = p;
                bestpoint = point;
                bestdot = dot;
            }
        }
        if (self mag_tog("aim_debug") && gettime() - dbgtime > 1000)
        {
            dbgtime = gettime();
            self iprintln("^3AIM ^7enemies ^3" + n_enemy + " ^7range ^3" + n_range + " ^7cone ^3" + n_cone + " ^7visible ^3" + n_vis);
        }
        if (!isdefined(best))
            continue;
        if (!self mag_tog("aim_visible"))
            self mag_aim_wallshot(best, bestpoint, eye);
        desired = vectortoangles(bestpoint - eye);
        pitch = current[0] + mag_aim_delta(desired[0] - current[0]) / self.mag.aim_smooth;
        yaw = current[1] + mag_aim_delta(desired[1] - current[1]) / self.mag.aim_smooth;
        if (pitch > 85)
            pitch = 85;
        if (pitch < -85)
            pitch = -85;
        self setplayerangles((pitch, yaw, current[2]));
    }
}
