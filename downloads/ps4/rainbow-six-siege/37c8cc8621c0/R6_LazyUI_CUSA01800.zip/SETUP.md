# R6 LazyUI for PS4

This build targets Rainbow Six Siege game version **03.71**, title ID **CUSA01800**, with GoldHEN's plugin loader already active.

## Install

1. Fully close Rainbow Six Siege.
2. Copy `r6_lazyui.sprx` to `/data/GoldHEN/plugins/r6_lazyui.sprx`.
3. If `/data/GoldHEN/plugins.ini` already exists, replace its `[CUSA01800]` section with the block below and keep the sections for other games. For a fresh install, copy the included `plugins.ini` to `/data/GoldHEN/plugins.ini`. Enable only LazyUI for R6.
4. Reopen Rainbow Six Siege and press **L3 + R3** to open the menu.

```ini
[CUSA01800]
/data/GoldHEN/plugins/r6_lazyui.sprx
```

## Controller

- **L3 + R3** opens or closes the menu.
- **L1 / R1** changes tabs. **D-pad** navigates or adjusts the selected setting.
- **Left stick** moves the pointer. **Cross** selects. Hold **Cross** on the header to move the menu.
- **Circle** closes the menu.
- Use **Config** to save or load preferences.

## In this build

Find **Radar** and **Snaplines** under **Overlay options** on the **ESP** tab. Enable directional arrows with **FOV arrows** on the **Targets** tab.

Made by patchguard. Operator badges are from the [Ubisoft operator roster](https://www.ubisoft.com/en-us/game/rainbow-six/siege/game-info/operators).
