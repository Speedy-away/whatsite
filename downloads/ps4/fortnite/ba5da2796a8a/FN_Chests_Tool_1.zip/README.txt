FN Chests Tool  (plugin v25 + ps4debug payload, all inside one exe)

1. Boot the PS4 and load GoldHEN as usual.
2. Double-click FN_Chests_Tool.exe. A browser page opens (http://127.0.0.1:8787). Keep the black window open.
3. Check the PS4 IP (top right), press Save if you change it. Default 192.168.1.189.
4. "Send ps4debug payload": optional (only for dumping). Needs GoldHEN loaded; if ps4debug already runs it says so.
5. "Install plugin": uploads fn_chests25.prx and updates plugins.ini (backup saved next to the exe). Do it once.
6. Start Fortnite, join a match, wait 1 minute. The "plugin 9099" light turns green when the plugin is ready.
7. Use the buttons: Aura, Tour, TP, Open nearest, Stop, Reset, Tour speed, Aura radius, Read plugin log.

In game: L1+L3 menu, L1+R1 aura, L1+R3 tour, L1+UP tp to nearest chest.
Tour needs a vehicle (cannon / SUV); the server only accepts the teleport there.

The exe is unsigned: Windows SmartScreen / antivirus may warn. Allow it if you built/trust it.
Plugin v25 was compiled but only the tool's PC side was tested (against a fake PS4).
