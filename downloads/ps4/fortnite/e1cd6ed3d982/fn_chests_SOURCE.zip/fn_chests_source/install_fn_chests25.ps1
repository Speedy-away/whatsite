$ip='192.168.1.189'; $port=2121
$dir=Split-Path -Parent $MyInvocation.MyCommand.Path
$base="ftp://anonymous:x@${ip}:${port}/data/GoldHEN/"
$w=New-Object Net.WebClient
try {
  $w.UploadFile($base+'plugins/fn_chests25.prx','STOR',(Join-Path $dir 'fn_chests25.prx')) | Out-Null
  $r=[Net.WebRequest]::Create($base+'plugins/fn_chests25.prx'); $r.Method='SIZE'; $x=$r.GetResponse()
  'size on ps4: '+$x.ContentLength+'  local: '+(Get-Item (Join-Path $dir 'fn_chests25.prx')).Length; $x.Close()
  $ini=Join-Path $dir 'ps4_plugins_before_chests25.ini'
  $w.DownloadFile($base+'plugins.ini',$ini)
  $lines=[IO.File]::ReadAllLines($ini) | Where-Object { $_ -notmatch 'fn_chests' }
  $out=@(); foreach($l in $lines){ $out+=$l; if($l.Trim() -eq '[CUSA07669]'){ $out+='/data/GoldHEN/plugins/fn_chests25.prx' } }
  if(($out -join "`n") -notmatch 'fn_chests25'){ throw 'no [CUSA07669] section' }
  $new=Join-Path $dir 'plugins_with_chests25.ini'
  [IO.File]::WriteAllText($new,($out -join "`r`n")+"`r`n")
  $w.UploadFile($base+'plugins.ini','STOR',$new) | Out-Null
  'plugins.ini updated: fn_chests25.prx (old fn_chests line removed, backup: ps4_plugins_before_chests25.ini)'
} catch { 'fail: '+$_.Exception.Message }
