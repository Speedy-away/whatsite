// fn_chests - GoldHEN plugin for Fortnite CUSA07669 (own EZFN server, offline use).
// Calls FortCheatManager functions through UObject::ProcessEvent, on the game thread (Detour on ProcessEvent).
// Triggers: pad combos (L1 + D-pad) and text commands on TCP 9099 (fn_cmd.bat). Log: /data/GoldHEN/fn_chests_log.txt
// Build: OpenOrbis toolchain + GoldHEN Plugins SDK, same flow as the BO2 plugins (BUILD_FN_CHESTS.bat).
// Never run on a console by the author of this file; see README "What can still go wrong".
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <orbis/libkernel.h>
#include <orbis/Net.h>
#include <orbis/UserService.h>
#include <orbis/_types/pad.h>
#include "plugin_common.h"

attr_public const char *g_pluginName = "fn_chests";
attr_public const char *g_pluginDesc = "Fortnite FortCheatManager caller (private server)";
attr_public const char *g_pluginAuth = "B33";
attr_public uint32_t g_pluginVersion = 0x00000100;

// ---- config ---------------------------------------------------------------------------------------------
#define LOG_PATH        "/data/GoldHEN/fn_chests_log.txt"
#define CMD_PORT        9099
#define START_DELAY_US  (30u * 1000000u)      // wait before patching the game code (engine init)
#define QUEUE_SIZE      16
#define PAD_POLL_MS     16

// build-specific addresses (eboot.bin, fixed module addresses). Regen: dump_objects.bat + probe_live.bat, see notes/fn_findings.txt
#define A_PROCESSEVENT      0xfaadbcULL     // UObject::ProcessEvent (vtable slot 72), verified live
#define A_GENGINE_A         0x154f3fa8ULL   // GEngine global candidates (probe_live)
#define A_GENGINE_B         0x15524688ULL
#define A_CLS_FORTENGINE    0x128bcbe0ULL   // UClass objects (static module data)
#define A_CLS_GAMEINSTANCE  0x128d4550ULL
#define A_CLS_CHEATMANAGER  0x13144eb8ULL
#define ENGINE_SCAN_SIZE    0x4000          // GameInstance pointer lives inside UEngine (not in the first 0x1000)
#define OBJ_CLASS           0x10            // UObject::ClassPrivate
#define GI_LOCALPLAYERS     0x38            // GameInstance.LocalPlayers (TArray: data, num)
#define LP_CONTROLLER       0x30            // LocalPlayer.PlayerController
#define A_GOBJECTS          0x15494740ULL   // chunked FUObjectItem array: +0 chunk table, 24-byte items, 65536 per chunk
#define A_CLS_CONTAINER     0x1250a7c0ULL   // BuildingContainer
#define A_CLS_INTERACTION   0x125f0be8ULL   // FortControllerComponent_Interaction (owns ServerAttemptInteract)
#define A_FN_GETPAWN        0x112d98d8ULL   // Controller.K2_GetPawn
#define A_FN_GETLOC         0x111a3c10ULL   // Actor.K2_GetActorLocation
#define A_FN_GETROT         0x111a3d60ULL   // Actor.K2_GetActorRotation
#define A_FN_TELEPORT       0x111a5a48ULL   // Actor.K2_TeleportTo(DestLocation, DestRotation) -> bool
#define A_FN_SERVERCHEAT    0x13165910ULL   // ServerCheat(FString Msg)
#define A_FN_GETVEHICLE     0x130dff00ULL   // FortPlayerPawn.GetVehicleActor() -> AActor*
#define A_FN_INTERACT       0x125ed848ULL   // FortControllerComponent_Interaction.ServerAttemptInteract(ReceivingActor, ...)
#define OBJ_OUTER           0x20
#define MAX_CONT            4096
#define STEP_MS             250
#define TP_WAIT_MS          700
#define INT_WAIT_MS         2800            // stay on the container while the server runs the search             // delay between steps of the 'chests' sequence
#define AURA_RADIUS         320.0           // game units (~3 m)
#define AURA_SCAN_MS        10000
#define AURA_TICK_MS        300
#define TOUR_STEP_MS        100             // default ms per chest (tp wait = 2/3 of it); change live with: speed <ms>
#define TOUR_ARRIVE_MS      700             // max time to get the pawn onto the target
#define TOUR_PIN_MS         25              // re-send the teleport this often until it holds
#define TOUR_NEAR           150.0           // close enough to interact
#define TOUR_RANGE          600.0           // max distance from tour point to accept a re-found chest
#define TP_LIFT             120.0           // teleport this far above the container
#define PC_CHEATMANAGER     0x3e0           // PlayerController.CheatManager. FILL: dedotto (CheatManagerClass a +0x3d8 e' confermato); 'status' lo mostra

typedef struct { const char *name; uint64_t addr; int on_controller; uint32_t pad_combo; int sp; } Fn;   // sp != 0: handled by the plugin itself (no cheat call)
// UFunction objects from objects_dump.txt. All assumed to take no parameters.
static const Fn FNS[] = {
    { "enablecheats", 0x114a1a08ULL, 1, 0 },                                    // PlayerController.EnableCheats
    { "tpchest",      0, 0, ORBIS_PAD_BUTTON_L1 | ORBIS_PAD_BUTTON_UP, 1 },   // own impl: teleport to nearest not-yet-visited container  // TeleportToNearestUnsearchedContainer
    { "chests",       0, 0, 0, 2 },  // own impl: visit + interact with every container
    { "probe",        0, 0, 0, 3 },
    { "stop",         0, 0, 0, 4 },
    { "reset",        0, 0, 0, 5 },
    { "trace",        0, 0, 0, 6 },
    { "chest1",       0, 0, 0, 7 },
    { "near",         0, 0, 0, 8 },     // interact with the nearest chest without teleporting
    { "sc",           0, 0, 0, 9 },
    { "radius",       0, 0, 0, 11 },
    { "tour",         0, 0, ORBIS_PAD_BUTTON_L1 | ORBIS_PAD_BUTTON_R3, 12 },
    { "speed",        0, 0, 0, 13 },
    { "menu",         0, 0, ORBIS_PAD_BUTTON_L1 | ORBIS_PAD_BUTTON_L3, 14 },    // radius <units>: aura range
    { "aura",         0, 0, ORBIS_PAD_BUTTON_L1 | ORBIS_PAD_BUTTON_R1, 10 },   // toggle: auto-open every chest within AURA_RADIUS while you walk     // ServerCheat(<text>) on the server     // teleport to the nearest unvisited chest, interact once, stay there  // OpenAllContainersAndWriteLootEconomy
    { "god",          0x13141ee0ULL, 0, 0 },  // ToggleUnlimitedHealth
    { "ammo",         0x131404a0ULL, 0, 0 },  // ToggleInfiniteAmmo
    { "stamina",      0x13140740ULL, 0, 0 },                                    // ToggleInfiniteStamina
    { "freecam",      0x1313fe80ULL, 0, 0 },                                    // ToggleFreeCamera
    { "buildmats",    0x13141e00ULL, 0, 0 },                                    // ToggleUnlimitedBuildMaterials
    { "nocooldown",   0x131410e0ULL, 0, 0 },                                    // ToggleNoCoolDown
    { "durability",   0x13140660ULL, 0, 0 },                                    // ToggleInfiniteDurability
    { "consumables",  0x13140580ULL, 0, 0 },                                    // ToggleInfiniteConsumables
    { "gofast",       0x1311e628ULL, 0, 0 },                                    // GoFast
    { "clearfog",     0x1310f9b8ULL, 0, 0 },                                    // ClearMapFog
};
#define NFNS (sizeof FNS / sizeof FNS[0])

// ---- plumbing -------------------------------------------------------------------------------------------
static void logf_(const char *fmt, ...) {
    char buf[512];
    va_list ap; va_start(ap, fmt); int n = vsnprintf(buf, sizeof buf - 1, fmt, ap); va_end(ap);
    if (n < 0) return;
    if (n > (int)sizeof buf - 2) n = sizeof buf - 2;
    buf[n++] = '\n';
    int fd = sceKernelOpen(LOG_PATH, 0x0001 | 0x0200 | 0x0008, 0666);   // WRONLY | CREAT | APPEND
    if (fd < 0) return;
    sceKernelWrite(fd, buf, n);
    sceKernelClose(fd);
}
static uint64_t now_ms(void) { return sceKernelGetProcessTime() / 1000; }

static int readable(uint64_t p, uint64_t n) {
    while (n) {
        void *st = 0, *en = 0; int prot = 0;
        if (sceKernelQueryMemoryProtection((void *)p, &st, &en, &prot) != 0 || (uint64_t)st > p || !(prot & 1)) return 0;
        uint64_t left = (uint64_t)en - p;
        if (left >= n) return 1;
        n -= left; p = (uint64_t)en;
    }
    return 1;
}
static uint64_t rd64(uint64_t a) { return readable(a, 8) ? *(volatile uint64_t *)a : 0; }
static int plausible(uint64_t p) { return (p >= 0x400000ULL && p < 0x16000000ULL) || (p >= 0x1000000000ULL && p < 0x4000000000ULL); }

static inline int ld(volatile int *v) { return __atomic_load_n(v, __ATOMIC_ACQUIRE); }
static inline void st(volatile int *v, int x) { __atomic_store_n(v, x, __ATOMIC_RELEASE); }

// ---- game objects ---------------------------------------------------------------------------------------
typedef void (*pe_t)(void *self, void *fn, void *params);
static Detour g_det;
static void *g_stub = 0;                 // trampoline into the original ProcessEvent
static volatile int g_hooked = 0, g_busy = 0;
static uint64_t g_pc = 0;

static int resolve_pc(void) {
    if (g_pc && rd64(g_pc + OBJ_CLASS)) return 1;
    uint64_t eng = 0;
    const uint64_t globals[2] = { A_GENGINE_A, A_GENGINE_B };
    for (int i = 0; i < 2; i++) {
        uint64_t e = rd64(globals[i]);
        if (plausible(e) && rd64(e + OBJ_CLASS) == A_CLS_FORTENGINE) { eng = e; break; }
    }
    if (!eng) { logf_("GEngine not found at %lx / %lx", A_GENGINE_A, A_GENGINE_B); return 0; }
    uint64_t gi = 0;
    if (!readable(eng, ENGINE_SCAN_SIZE)) { logf_("engine %lx not readable", eng); return 0; }
    for (uint64_t o = 0; o < ENGINE_SCAN_SIZE; o += 8) {
        uint64_t p = *(volatile uint64_t *)(eng + o);
        if (plausible(p) && rd64(p + OBJ_CLASS) == A_CLS_GAMEINSTANCE) { gi = p; break; }
    }
    if (!gi) { logf_("GameInstance not found inside engine %lx", eng); return 0; }
    uint64_t data = rd64(gi + GI_LOCALPLAYERS);
    if (!plausible(data)) { logf_("LocalPlayers empty"); return 0; }
    uint64_t lp = rd64(data);
    if (!plausible(lp)) return 0;
    uint64_t pc = rd64(lp + LP_CONTROLLER);
    if (!plausible(pc) || !rd64(pc + OBJ_CLASS)) { logf_("no PlayerController yet"); return 0; }
    g_pc = pc;
    logf_("chain ok: engine %lx gi %lx lp %lx pc %lx", eng, gi, lp, pc);
    return 1;
}

static void call_pe(uint64_t self, uint64_t fn) {
    uint8_t params[64] __attribute__((aligned(16)));
    memset(params, 0, sizeof params);
    ((pe_t)g_stub)((void *)self, (void *)fn, params);
}


// Locate the CheatManager inside the controller: exact class match first, then the fixed guess.
static uint64_t find_cm(void) {
    uint64_t v = rd64(g_pc + PC_CHEATMANAGER);       // confirmed live: CheatClass at +3d8, CheatManager at +3e0
    if (plausible(v) && plausible(rd64(v + OBJ_CLASS))) return v;   // instance class is a subclass of FortCheatManager
    return 0;
}
static void dump_pc_words(void) {
    for (uint64_t o = 0x3a0; o < 0x420; o += 8) {
        uint64_t p = rd64(g_pc + o);
        logf_("pc+%lx = %lx (class %lx)", o, p, plausible(p) ? rd64(p + OBJ_CLASS) : 0);
    }
}


// ---- own chest logic ------------------------------------------------------------------------------------
static int g_super_off = 0x40;           // UStruct::SuperStruct, verified/searched in find_super_off()
static int g_dbl = 1;                    // FVector = 3 doubles (UE5) or 3 floats; decided from a live read
static uint64_t g_visited[512]; static int g_nvis = 0;

// cached readable-range read (the scan touches ~700k objects)
static uint64_t g_rs = 0, g_re = 0;
static int fast_ok(uint64_t p, uint64_t n) {
    if (p >= g_rs && p + n <= g_re) return 1;
    void *st_ = 0, *en = 0; int prot = 0;
    if (sceKernelQueryMemoryProtection((void *)p, &st_, &en, &prot) != 0 || (uint64_t)st_ > p || !(prot & 1)) return 0;
    g_rs = (uint64_t)st_; g_re = (uint64_t)en;
    return p + n <= g_re;
}
static uint64_t frd64(uint64_t a) { return fast_ok(a, 8) ? *(volatile uint64_t *)a : 0; }

static int is_sub_of(uint64_t cls, uint64_t base) {
    for (int i = 0; i < 40 && plausible(cls); i++) {
        if (cls == base) return 1;
        cls = frd64(cls + g_super_off);
    }
    return 0;
}
static void find_super_off(void) {       // locate SuperStruct using the live CheatManager's class chain
    uint64_t cm = find_cm(); if (!cm) return;
    uint64_t cls = rd64(cm + OBJ_CLASS);
    for (int o = 0x30; o <= 0x70; o += 8) {
        uint64_t c = cls; int hit = 0;
        for (int i = 0; i < 6 && plausible(c); i++) { if (c == A_CLS_CHEATMANAGER) { hit = 1; break; } c = rd64(c + o); }
        if (hit) { g_super_off = o; logf_("SuperStruct offset = %x", o); return; }
    }
    logf_("SuperStruct offset not found, keeping %x", g_super_off);
}


#define A_NAMEPOOL 0x15444240ULL
static int fname_str(uint32_t idx, char *out, int max) {      // FNamePool entry -> ascii (no number suffix)
    uint64_t blk = rd64(A_NAMEPOOL + 0x10 + 8ULL * (idx >> 16));
    if (!plausible(blk)) return 0;
    uint64_t e = blk + (uint64_t)(idx & 0xFFFF) * 2;
    if (!readable(e, 2 + 64)) return 0;
    uint16_t h = *(volatile uint16_t *)e; int ln = h >> 6;
    if (!ln || ln >= max || (h & 1)) return 0;
    memcpy(out, (const void *)(e + 2), ln); out[ln] = 0;
    return ln;
}
static int class_name(uint64_t cls, char *out, int max) {
    uint64_t v = rd64(cls + 0x18);
    return fname_str((uint32_t)v, out, max);
}
static uint64_t g_fc[96]; static signed char g_fv[96]; static int g_nfc = 0;
static int class_wanted(uint64_t cls) {                        // chests / ammo boxes only
    for (int i = 0; i < g_nfc; i++) if (g_fc[i] == cls) return g_fv[i];
    char nm[96]; int ok = 0;
    if (class_name(cls, nm, sizeof nm)) ok = strstr(nm, "Chest") || strstr(nm, "Ammo");
    if (g_nfc < 96) { g_fc[g_nfc] = cls; g_fv[g_nfc++] = ok; }
    return ok;
}

// ---- trace: log interaction-related ProcessEvent calls while the player opens a chest by hand ------------
static volatile int g_trace = 0; static int g_trace_n = 0;
static uint64_t g_tf[1024]; static signed char g_tv[1024];
static int trace_fn_wanted(uint64_t fn) {
    unsigned h = (unsigned)((fn >> 4) ^ (fn >> 14)) & 1023;
    if (g_tf[h] == fn) return g_tv[h];
    char nm[96]; int ok = 0;
    if (plausible(fn) && fname_str((uint32_t)rd64(fn + 0x18), nm, sizeof nm))
        ok = (strstr(nm, "Interact") || strstr(nm, "Search") || strstr(nm, "Container") || strstr(nm, "OpenChest") || strstr(nm, "Loot")) && !strstr(nm, "GetMinDistance") && !strstr(nm, "GetMin");
    g_tf[h] = fn; g_tv[h] = ok;
    return ok;
}
static uint8_t g_tc[1024];
static void trace_call(uint64_t self, uint64_t fn, uint8_t *params) {
    if (g_trace_n >= 300 || !trace_fn_wanted(fn)) return;
    unsigned h = (unsigned)((fn >> 4) ^ (fn >> 14)) & 1023;
    if (g_tc[h] >= 6) return; g_tc[h]++;
    g_trace_n++;
    char fnm[96] = "?", cnm[96] = "?";
    fname_str((uint32_t)rd64(fn + 0x18), fnm, sizeof fnm);
    if (plausible(self)) class_name(rd64(self + OBJ_CLASS), cnm, sizeof cnm);
    uint64_t q[4] = {0,0,0,0}; if (readable((uint64_t)params, 32)) memcpy(q, params, 32);
    logf_("TRACE %s on %s(%lx): %lx %lx %lx %lx", fnm, cnm, self, q[0], q[1], q[2], q[3]);
}
// learned ServerAttemptInteract call (captured when the player opens a real chest)
static uint64_t g_tpl[8]; static int g_have_tpl = 1, g_comp_off = 0x1b0, g_learn_n = 0;
static void learn_interact(uint64_t self, uint8_t *params) {
    if (g_learn_n >= 12) return; g_learn_n++;
    uint64_t q[8]; for (int i = 0; i < 8; i++) q[i] = *(uint64_t *)(params + i * 8);
    char nm[96] = "?"; if (plausible(q[0])) class_name(rd64(q[0] + OBJ_CLASS), nm, sizeof nm);
    logf_("LEARN interact self %lx actor %lx (%s) p: %lx %lx %lx %lx %lx %lx", self, q[0], nm, q[1], q[2], q[3], q[4], q[5], q[6]);
    if (!plausible(q[0]) || !class_wanted(rd64(q[0] + OBJ_CLASS))) return;     // only chests teach us
    memcpy(g_tpl, q, sizeof q);
    if (plausible(q[1]) && readable(q[0], 0x1000))
        for (int o = 0; o < 0x1000; o += 8) if (*(volatile uint64_t *)(q[0] + o) == q[1]) { g_comp_off = o; logf_("LEARN component is at actor+%x", o); break; }
    if (g_comp_off < 0) logf_("LEARN component pointer not found inside the actor (it is probably a subobject; comp class %lx)", plausible(q[1]) ? rd64(q[1] + OBJ_CLASS) : 0);
}

typedef struct { uint64_t obj; double x, y, z; uint64_t cls; } Cont;
static Cont g_cont[MAX_CONT]; static int g_ncont = 0;
static uint64_t g_interact = 0;          // interaction component of our controller

static void call_pe2(uint64_t self, uint64_t fn, void *params) { ((pe_t)g_stub)((void *)self, (void *)fn, params); }

static int get_vec(uint64_t actor, uint64_t fn, double *o) {
    uint8_t p[96] __attribute__((aligned(16))); memset(p, 0, sizeof p);
    call_pe2(actor, fn, p);
    double *d = (double *)p; float *f = (float *)p;
    int dbl_ok = 1;
    for (int i = 0; i < 3; i++) if (!(d[i] == d[i]) || d[i] > 1e8 || d[i] < -1e8 || (d[i] != 0 && d[i] < 1e-6 && d[i] > -1e-6)) dbl_ok = 0;
    g_dbl = dbl_ok;
    if (dbl_ok) { o[0] = d[0]; o[1] = d[1]; o[2] = d[2]; } else { o[0] = f[0]; o[1] = f[1]; o[2] = f[2]; }
    return 1;
}
static uint64_t get_pawn(void) {
    uint8_t p[32] __attribute__((aligned(16))); memset(p, 0, sizeof p);
    call_pe2(g_pc, A_FN_GETPAWN, p);
    uint64_t pw = *(uint64_t *)p;
    return plausible(pw) && rd64(pw + OBJ_CLASS) ? pw : 0;
}

// walk GObjects: collect BuildingContainer instances, find our interaction component
static void scan_objects(void) {
    g_ncont = 0; g_interact = 0;
    uint64_t chunks = rd64(A_GOBJECTS);
    if (!plausible(chunks)) { logf_("GObjects chunk table not readable"); return; }
    for (int ci = 0; ci < 64; ci++) {
        uint64_t chunk = rd64(chunks + ci * 8);
        if (!plausible(chunk) || !readable(chunk, 65536ULL * 24)) break;
        for (int i = 0; i < 65536; i++) {
            const uint8_t *it = (const uint8_t *)(chunk + (uint64_t)i * 24);
            uint64_t q0 = *(const uint64_t *)it;
            if (!q0 || (q0 & 0x1020000000000000ULL)) continue;
            uint64_t obj = ((q0 & 0x3fff00000000ULL) | *(const uint32_t *)(it + 8)) << 3;
            if (!plausible(obj)) continue;
            uint64_t cls = frd64(obj + OBJ_CLASS);
            if (!plausible(cls)) continue;
            if (cls == A_CLS_INTERACTION) { if (frd64(obj + OBJ_OUTER) == g_pc) g_interact = obj; continue; }
            if (g_ncont < MAX_CONT && is_sub_of(cls, A_CLS_CONTAINER) && class_wanted(cls)) { g_cont[g_ncont].obj = obj; g_cont[g_ncont].cls = cls; g_ncont++; }
        }
    }
}
static void fill_positions(void) {
    int n = 0;
    for (int i = 0; i < g_ncont; i++) {
        double v[3];
        get_vec(g_cont[i].obj, A_FN_GETLOC, v);
        if (v[0] == 0 && v[1] == 0 && v[2] == 0) continue;
        g_cont[n] = g_cont[i]; g_cont[n].x = v[0]; g_cont[n].y = v[1]; g_cont[n].z = v[2]; n++;
    }
    g_ncont = n;
}
static int was_visited(uint64_t o) { for (int i = 0; i < g_nvis; i++) if (g_visited[i] == o) return 1; return 0; }
static int nearest(double *me, int skip_visited) {
    int best = -1; double bd = 1e300;
    for (int i = 0; i < g_ncont; i++) {
        if (skip_visited && was_visited(g_cont[i].obj)) continue;
        double dx = g_cont[i].x - me[0], dy = g_cont[i].y - me[1], dz = g_cont[i].z - me[2], d = dx*dx + dy*dy + dz*dz;
        if (d < bd) { bd = d; best = i; }
    }
    return best;
}
static uint64_t get_vehicle(uint64_t pawn) {
    uint8_t p[32] __attribute__((aligned(16))); memset(p, 0, sizeof p);
    call_pe2(pawn, A_FN_GETVEHICLE, p);
    uint64_t v = *(uint64_t *)p;
    return plausible(v) && rd64(v + OBJ_CLASS) ? v : 0;
}
static int g_tp_logged = 0;
static void teleport_pawn(uint64_t pawn, double x, double y, double z) {
    uint64_t veh = get_vehicle(pawn);
    uint64_t tgt = veh ? veh : pawn;                                     // seated: move the vehicle (its position may be client-driven)
    if (g_tp_logged < 12) { g_tp_logged++; logf_("teleport target: %s %lx", veh ? "VEHICLE" : "pawn", tgt); }
    uint8_t p[96] __attribute__((aligned(16))); memset(p, 0, sizeof p);
    double rot[3] = {0, 0, 0}; get_vec(tgt, A_FN_GETROT, rot);          // keep facing
    if (g_dbl) { double *d = (double *)p; d[0] = x; d[1] = y; d[2] = z; d[3] = rot[0]; d[4] = rot[1]; d[5] = rot[2]; }
    else { float *f = (float *)p; f[0] = (float)x; f[1] = (float)y; f[2] = (float)z; f[3] = (float)rot[0]; f[4] = (float)rot[1]; f[5] = (float)rot[2]; }
    call_pe2(tgt, A_FN_TELEPORT, p);
}
static void interact(uint64_t actor) {
    if (!g_interact) { logf_("no interaction component (outer == controller) found"); return; }
    uint64_t comp = rd64(actor + g_comp_off);                             // learned live: component at actor+1b0 for the chest classes
    if (!plausible(comp)) { logf_("interact: no component at %lx+%x, skipped", actor, g_comp_off); return; }
    uint8_t p[64] __attribute__((aligned(16))); memset(p, 0, sizeof p);
    *(uint64_t *)p = actor;                                               // ReceivingActor
    *(uint64_t *)(p + 8) = comp;                                          // InteractComponent
    p[16] = 2;                                                            // ETInteractionType seen on real chest opens
    call_pe2(g_interact, A_FN_INTERACT, p);                               // OptionalObjectData = 0, InteractionBeingAttempted = 0
}

// 'chests' sequence state (advanced from the game thread, one step every STEP_MS)
static int g_limit = 0, g_nohome = 0;
static int g_auto = 0, g_idx = 0, g_phase = 0; static uint64_t g_next = 0;
static double g_home[3];
static int g_order[MAX_CONT];

static void do_probe(void) {
    find_super_off();
    uint64_t pawn = get_pawn();
    double v[3] = {0,0,0}; if (pawn) get_vec(pawn, A_FN_GETLOC, v);
    logf_("probe: pawn %lx loc %f %f %f (%s)", pawn, v[0], v[1], v[2], g_dbl ? "double" : "float");
    scan_objects(); int raw = g_ncont; fill_positions();
    logf_("probe: containers %d (with position %d), interaction comp %lx", raw, g_ncont, g_interact);
    for (int i = 0; i < g_nfc; i++) { char nm[96] = "?"; class_name(g_fc[i], nm, sizeof nm); logf_("  class %lx %s wanted=%d", g_fc[i], nm, g_fv[i]); if (i > 40) break; }
    for (int i = 0; i < g_ncont && i < 6; i++) logf_("  #%d obj %lx class %lx at %.0f %.0f %.0f", i, g_cont[i].obj, g_cont[i].cls, g_cont[i].x, g_cont[i].y, g_cont[i].z);
}
static void do_tpchest(void) {
    find_super_off();
    uint64_t pawn = get_pawn(); if (!pawn) { logf_("tpchest: no pawn"); return; }
    double me[3]; get_vec(pawn, A_FN_GETLOC, me);
    scan_objects(); fill_positions();
    int b = nearest(me, 1);
    if (b < 0) { logf_("tpchest: nothing left (%d containers, %d visited) - send 'reset'", g_ncont, g_nvis); return; }
    if (g_nvis < 512) g_visited[g_nvis++] = g_cont[b].obj;
    teleport_pawn(pawn, g_cont[b].x, g_cont[b].y, g_cont[b].z + TP_LIFT);
    logf_("tpchest: -> %lx at %.0f %.0f %.0f (%d containers)", g_cont[b].obj, g_cont[b].x, g_cont[b].y, g_cont[b].z, g_ncont);
    Notify(TEX_ICON_SYSTEM, "fn_chests: tpchest");
}
static void do_chests_start(int limit) {
    g_limit = limit; g_nohome = limit > 0;
    find_super_off();
    uint64_t pawn = get_pawn(); if (!pawn) { logf_("chests: no pawn"); return; }
    get_vec(pawn, A_FN_GETLOC, g_home);
    scan_objects(); fill_positions();
    // greedy nearest-neighbour order
    double cur[3] = { g_home[0], g_home[1], g_home[2] }; int n = 0;
    uint64_t saved[512]; int ns = g_nvis; memcpy(saved, g_visited, sizeof saved); g_nvis = 0;
    for (int k = 0; k < g_ncont; k++) {
        int b = nearest(cur, 1); if (b < 0) break;
        g_order[n++] = b; if (g_nvis < 512) g_visited[g_nvis++] = g_cont[b].obj; else break;
        cur[0] = g_cont[b].x; cur[1] = g_cont[b].y; cur[2] = g_cont[b].z;
    }
    memcpy(g_visited, saved, sizeof saved); g_nvis = ns;
    g_ncont = n > 512 ? 512 : n;                                          // sequence capped by the visited table logic
    if (g_limit > 0 && g_ncont > g_limit) g_ncont = g_limit;
    g_idx = 0; g_phase = 0; g_auto = g_ncont > 0; g_next = now_ms();
    logf_("chests: sequence over %d containers, interaction %lx, learned=%d", g_ncont, g_interact, g_have_tpl);
    if (!g_have_tpl) logf_("chests: no interact call learned yet - only teleporting. Open one real chest by hand first.");
    Notify(TEX_ICON_SYSTEM, "fn_chests: %d containers", g_ncont);
}

static double g_aura_r = AURA_RADIUS;
static int g_aura = 0; static uint64_t g_aura_next = 0, g_aura_scan = 0; static int g_aura_n = 0;
static void aura_tick(void) {
    uint64_t t = now_ms();
    if (t < g_aura_next) return;
    g_aura_next = t + AURA_TICK_MS;
    uint64_t pawn = get_pawn(); if (!pawn) return;
    if (!g_ncont || t - g_aura_scan > AURA_SCAN_MS) { if (g_aura_n < 2) logf_("aura: scanning..."); scan_objects(); if (g_aura_n < 2) logf_("aura: %d containers, reading positions...", g_ncont); fill_positions(); if (g_aura_n < 2) logf_("aura: %d with position", g_ncont); g_aura_scan = t; }
    double me[3]; get_vec(pawn, A_FN_GETLOC, me);
    int best = -1; double bd = g_aura_r * g_aura_r;
    for (int i = 0; i < g_ncont; i++) {
        if (was_visited(g_cont[i].obj)) continue;
        double dx = g_cont[i].x - me[0], dy = g_cont[i].y - me[1], dz = g_cont[i].z - me[2], d = dx*dx + dy*dy + dz*dz;
        if (d < bd) { bd = d; best = i; }
    }
    if (best < 0) return;
    Cont *c = &g_cont[best];
    if (!plausible(c->obj) || rd64(c->obj + OBJ_CLASS) != c->cls || (rd64(c->obj + 8) & 0x18000)) { if (g_nvis < 512) g_visited[g_nvis++] = c->obj; return; }
    interact(c->obj);
    if (g_nvis >= 512) g_nvis = 0;
    g_visited[g_nvis++] = c->obj;
    g_aura_n++;
    if (g_aura_n <= 60) logf_("aura: %lx at %.0f (radius %.0f)", c->obj, __builtin_sqrt(bd), g_aura_r);
}
static int g_tauto; static void tour_tick(void);
static void menu_draw(void); static volatile int g_mdraw; static uint64_t g_mlast;
static void auto_tick(void) {
    if (g_mdraw && now_ms() - g_mlast > 600) { g_mdraw = 0; g_mlast = now_ms(); menu_draw(); }
    if (g_tauto) { tour_tick(); return; }
    if (g_aura && !g_auto) { aura_tick(); return; }
    if (!g_auto || now_ms() < g_next) return;
    uint64_t pawn = get_pawn(); if (!pawn) { g_auto = 0; logf_("chests: pawn lost, stopped"); return; }
    if (g_idx >= g_ncont) {
        if (!g_nohome) teleport_pawn(pawn, g_home[0], g_home[1], g_home[2]);
        g_auto = 0; logf_("chests: done, back home"); Notify(TEX_ICON_SYSTEM, "fn_chests: done"); return;
    }
    Cont *c = &g_cont[g_order[g_idx]];
    if (g_phase == 0 && (!plausible(c->obj) || rd64(c->obj + OBJ_CLASS) != c->cls || (rd64(c->obj + 8) & 0x18000))) { logf_("chests: %d stale object %lx skipped", g_idx + 1, c->obj); g_idx++; g_next = now_ms(); return; }
    if (g_phase == 0) { teleport_pawn(pawn, c->x, c->y, c->z + TP_LIFT); g_phase = 1; g_next = now_ms() + TP_WAIT_MS; return; }
    { double pp[3]; get_vec(pawn, A_FN_GETLOC, pp); double dx = c->x - pp[0], dy = c->y - pp[1], dz = c->z - pp[2];
      if (g_idx < 12) logf_("chests: pawn is %.0f from chest %d (xy %.0f z %.0f)", __builtin_sqrt(dx*dx + dy*dy + dz*dz), g_idx + 1, __builtin_sqrt(dx*dx + dy*dy), dz); }
    interact(c->obj); logf_("chests: %d/%d %lx", g_idx + 1, g_ncont, c->obj); g_idx++; g_phase = 0; g_next = now_ms() + INT_WAIT_MS;
}


static double g_tour[512][3]; static uint64_t g_tobj[512], g_tcls[512];
static uint64_t g_tstart = 0, g_tstep = TOUR_STEP_MS, g_tarrive = 0, g_tpin = 0;
static int g_tn = 0, g_ti = 0, g_tphase = 0, g_tauto = 0, g_topen = 0; static uint64_t g_tnext = 0;
static void do_tour_start(int limit) {
    find_super_off();
    uint64_t pawn = get_pawn(); if (!pawn) { logf_("tour: no pawn"); return; }
    double home[3]; get_vec(pawn, A_FN_GETLOC, home);
    scan_objects(); fill_positions();
    uint64_t saved[512]; int ns = g_nvis; memcpy(saved, g_visited, sizeof saved); if (!limit) g_nvis = 0;   // single tp keeps the visited list
    double cur[3] = { home[0], home[1], home[2] }; int n = 0;
    for (int k = 0; k < g_ncont && n < 512 && (!limit || n < limit); k++) {
        int b = nearest(cur, 1); if (b < 0) break;
        g_tour[n][0] = g_cont[b].x; g_tour[n][1] = g_cont[b].y; g_tour[n][2] = g_cont[b].z; g_tobj[n] = g_cont[b].obj; g_tcls[n] = g_cont[b].cls; n++;
        if (g_nvis < 512) g_visited[g_nvis++] = g_cont[b].obj;
        cur[0] = g_cont[b].x; cur[1] = g_cont[b].y; cur[2] = g_cont[b].z;
    }
    if (!limit) { memcpy(g_visited, saved, sizeof saved); g_nvis = ns; }
    g_tn = n; g_ti = 0; g_tphase = 0; g_topen = 0; g_tauto = n > 0; g_tnext = now_ms();
    logf_("tour: %d containers (no arrival check)", n); g_tarrive = 0;
    Notify(TEX_ICON_SYSTEM, "fn_chests: tour %d", n);
}
static void tour_tick(void) {
    if (now_ms() < g_tnext) return;
    uint64_t pawn = get_pawn(); if (!pawn) { g_tauto = 0; logf_("tour: pawn lost, stopped"); return; }
    if (g_ti >= g_tn) { g_tauto = 0; logf_("tour: done, %d interacts sent of %d", g_topen, g_tn); Notify(TEX_ICON_SYSTEM, "fn_chests: tour done"); return; }
    double *p = g_tour[g_ti];
    if (g_tphase == 0) { teleport_pawn(pawn, p[0], p[1], p[2] + TP_LIFT); g_tphase = 1; g_tnext = now_ms() + (g_tstep * 4 / 10 < 30 ? 30 : g_tstep * 4 / 10); return; }
    uint64_t o = g_tobj[g_ti];
    if (!(plausible(o) && rd64(o + OBJ_CLASS) == g_tcls[g_ti] && !(rd64(o + 8) & 0x18000))) {
        // the actor was unloaded while we were far away: look it up again near the teleport point
        scan_objects(); fill_positions();
        int b = nearest(p, 0); o = 0;
        if (b >= 0) { double dx = g_cont[b].x - p[0], dy = g_cont[b].y - p[1], dz = g_cont[b].z - p[2]; if (dx*dx + dy*dy + dz*dz < TOUR_RANGE * TOUR_RANGE) o = g_cont[b].obj; }
    }
    if (o) { interact(o); g_topen++; } else logf_("tour: %d/%d no chest found near point", g_ti + 1, g_tn);
    if (g_ti < 12 || (g_ti % 20) == 0) { double me[3]; get_vec(pawn, A_FN_GETLOC, me); double dx = p[0] - me[0], dy = p[1] - me[1], dz = p[2] - me[2]; logf_("tour: %d/%d pawn %.0f from point, chest %lx", g_ti + 1, g_tn, __builtin_sqrt(dx*dx + dy*dy + dz*dz), o); }
    g_ti++; g_tphase = 0; g_tnext = now_ms() + g_tstep * 6 / 10;
}
static char g_sc_text[128];
static void do_near(void) {
    find_super_off();
    uint64_t pawn = get_pawn(); if (!pawn) { logf_("near: no pawn"); return; }
    double me[3]; get_vec(pawn, A_FN_GETLOC, me);
    scan_objects(); fill_positions();
    int b = nearest(me, 0);
    if (b < 0) { logf_("near: no container"); return; }
    double dx = g_cont[b].x - me[0], dy = g_cont[b].y - me[1], dz = g_cont[b].z - me[2];
    logf_("near: nearest %lx at distance %.0f (xy %.0f z %.0f)", g_cont[b].obj, __builtin_sqrt(dx*dx + dy*dy + dz*dz), __builtin_sqrt(dx*dx + dy*dy), dz);
    interact(g_cont[b].obj);
    logf_("near: interact sent");
    Notify(TEX_ICON_SYSTEM, "fn_chests: near");
}
static void do_servercheat(void) {
    if (!g_sc_text[0]) { logf_("sc: empty"); return; }
    static uint16_t w[128];
    int n = 0; for (; g_sc_text[n] && n < 120; n++) w[n] = (uint16_t)(uint8_t)g_sc_text[n];
    w[n] = 0;
    uint8_t p[32] __attribute__((aligned(16))); memset(p, 0, sizeof p);
    *(uint64_t *)p = (uint64_t)w; *(int32_t *)(p + 8) = n + 1; *(int32_t *)(p + 12) = 128;
    call_pe2(g_pc, A_FN_SERVERCHEAT, p);
    logf_("sc: sent '%s'", g_sc_text);
    Notify(TEX_ICON_SYSTEM, "fn_chests: sc %s", g_sc_text);
}
static uint64_t g_mopen; static int g_menu, g_msel; static void menu_draw(void); static volatile int g_mdraw; static uint64_t g_mlast;
static void run_special(int sp) {
    if (sp == 1) { if (g_tauto) logf_("tpchest: tour running"); else do_tour_start(1); }
    else if (sp == 2) do_chests_start(0);
    else if (sp == 7) do_chests_start(1);
    else if (sp == 8) do_near();
    else if (sp == 9) do_servercheat();
    else if (sp == 11) { double r = 0; for (const char *q = g_sc_text; *q >= '0' && *q <= '9'; q++) r = r * 10 + (*q - '0'); if (r >= 50 && r <= 100000) g_aura_r = r; logf_("aura radius = %.0f", g_aura_r); Notify(TEX_ICON_SYSTEM, "fn_chests: radius %.0f", g_aura_r); }
    else if (sp == 10) { g_aura = !g_aura; g_aura_next = 0; g_aura_n = 0; logf_("aura %s", g_aura ? "ON" : "OFF"); Notify(TEX_ICON_SYSTEM, "fn_chests: aura %s", g_aura ? "ON" : "OFF"); }
    else if (sp == 3) do_probe();
    else if (sp == 14) { logf_("menu: %s", g_menu ? "close" : "open"); g_mopen = now_ms(); g_menu = !g_menu; g_msel = 0; if (g_menu) menu_draw(); else Notify(TEX_ICON_SYSTEM, "fn_chests menu closed"); }
    else if (sp == 12) { if (g_tauto) { g_tauto = 0; logf_("tour: stopped"); Notify(TEX_ICON_SYSTEM, "fn_chests: tour OFF"); } else do_tour_start(0); }
    else if (sp == 13) { double r = 0; for (const char *q = g_sc_text; *q >= '0' && *q <= '9'; q++) r = r * 10 + (*q - '0'); if (r >= 50 && r <= 5000) g_tstep = (uint64_t)r; logf_("tour speed = %lu ms per chest", (unsigned long)g_tstep); Notify(TEX_ICON_SYSTEM, "fn_chests: speed %lu ms", (unsigned long)g_tstep); }
    else if (sp == 4) { g_auto = 0; g_tauto = 0; logf_("stopped"); }
    else if (sp == 5) { g_nvis = 0; logf_("visited list cleared"); }
    else if (sp == 6) { g_trace = !g_trace; g_trace_n = 0; memset(g_tc, 0, sizeof g_tc); logf_("trace %s - open one chest by hand now", g_trace ? "ON" : "OFF"); Notify(TEX_ICON_SYSTEM, "fn_chests: trace %s", g_trace ? "ON" : "OFF"); }
}

static void run_cmd(const Fn *f) {
    if (!g_stub) { logf_("%s: no ProcessEvent stub", f->name); return; }
    if (!resolve_pc()) { logf_("%s: controller chain not resolved", f->name); return; }
    if (f->sp) { run_special(f->sp); return; }
    uint64_t cm = find_cm();
    if (!f->on_controller && !cm) {
        logf_("%s: no CheatManager yet, calling EnableCheats first", f->name);
        call_pe(g_pc, FNS[0].addr);
        cm = find_cm();
        if (!cm) { dump_pc_words();
             logf_("%s: CheatManager still null at pc+%x (offset wrong or EnableCheats refused)", f->name, PC_CHEATMANAGER); return; }
    }
    if (!f->on_controller) logf_("%s: CheatManager %lx class %lx", f->name, cm, rd64(cm + OBJ_CLASS));
    uint64_t self = f->on_controller ? g_pc : cm;
    call_pe(self, f->addr);
    logf_("%s: called on %lx", f->name, self);
    Notify(TEX_ICON_SYSTEM, "fn_chests: %s", f->name);
}

// queue (socket/pad thread -> game thread)
static const Fn *g_queue[QUEUE_SIZE];
static volatile int g_head = 0, g_tail = 0;
static int push_cmd(const Fn *f) {
    int t = ld(&g_tail);
    if (((t + 1) % QUEUE_SIZE) == ld(&g_head)) return 0;
    g_queue[t] = f;
    st(&g_tail, (t + 1) % QUEUE_SIZE);
    return 1;
}
static void request(const Fn *f) {
    if (ld(&g_hooked)) push_cmd(f);
    else run_cmd(f);                     // no hook: runs on the calling thread (can crash)
}

// hook: runs on whatever thread calls ProcessEvent; one drain at a time, everything else passes through

// ---- game-thread detection: the thread that makes the most ProcessEvent calls --------------------------
static uint64_t g_gt = 0; static uint64_t g_tid[8]; static uint32_t g_tcnt[8]; static uint32_t g_tcalls = 0;
static inline void thread_vote(uint64_t me) {
    int i = 0;
    for (; i < 8 && g_tid[i]; i++) if (g_tid[i] == me) break;
    if (i < 8) { g_tid[i] = me; g_tcnt[i]++; }
    if (++g_tcalls >= 20000) {
        int b = 0; for (int k = 1; k < 8; k++) if (g_tcnt[k] > g_tcnt[b]) b = k;
        if (g_tid[b] != g_gt) { g_gt = g_tid[b]; logf_("game thread = %lx (%u of 20000 calls)", g_gt, g_tcnt[b]); }
        memset(g_tid, 0, sizeof g_tid); memset(g_tcnt, 0, sizeof g_tcnt); g_tcalls = 0;
    }
}
static void pe_hook(void *self, void *fn, void *params) {
    uint64_t me = (uint64_t)scePthreadSelf(); thread_vote(me);
    if (!g_gt || me != g_gt) { ((pe_t)g_stub)(self, fn, params); return; }      // only the game thread may touch objects
    if (g_trace && !g_busy) trace_call((uint64_t)self, (uint64_t)fn, (uint8_t *)params);
    if ((uint64_t)fn == A_FN_INTERACT && !g_busy) learn_interact((uint64_t)self, (uint8_t *)params);
    if (__atomic_exchange_n(&g_busy, 1, __ATOMIC_ACQ_REL) == 0) {
        while (ld(&g_head) != ld(&g_tail)) {
            int h = ld(&g_head);
            const Fn *f = g_queue[h];
            st(&g_head, (h + 1) % QUEUE_SIZE);
            run_cmd(f);
        }
        auto_tick();
        __atomic_store_n(&g_busy, 0, __ATOMIC_RELEASE);
    }
    ((pe_t)g_stub)(self, fn, params);
}

static int install_hook(void) {
    Detour_Construct(&g_det, DetourMode_x64);
    g_stub = Detour_DetourFunction(&g_det, A_PROCESSEVENT, (void *)&pe_hook);
    return g_stub ? 0 : -1;
}

// ---- pad (libScePad from the game's own modules, as in the BO2 plugin) ----------------------------------
typedef int32_t (*pad_gethandle_t)(int32_t, uint32_t, uint32_t);
typedef int32_t (*pad_readstate_t)(int32_t, OrbisPadData *);
static pad_gethandle_t p_gethandle; static pad_readstate_t p_readstate;
static int g_pad = -1;
static int pad_init(void) {
    static int tried = 0, loaded = 0;
    if (g_pad >= 0) return 1;
    if (!p_readstate) {
        OrbisKernelModule mods[256]; size_t n = 0;
        int r = sceKernelGetModuleList(mods, 256, &n);
        if (r != 0) { if (!tried) logf_("pad: sceKernelGetModuleList failed %x", r); tried = 1; return 0; }
        for (size_t i = 0; i < n && !p_readstate; i++) {              // any module that exports the pad API
            void *rs = 0, *gh = 0;
            sceKernelDlsym(mods[i], "scePadReadState", &rs); sceKernelDlsym(mods[i], "scePadGetHandle", &gh);
            if (rs && gh) {
                OrbisKernelModuleInfo mi; memset(&mi, 0, sizeof mi); mi.size = sizeof mi; sceKernelGetModuleInfo(mods[i], &mi);
                p_readstate = (pad_readstate_t)rs; p_gethandle = (pad_gethandle_t)gh;
                logf_("pad module %s: gethandle %p readstate %p", mi.name, gh, rs);
            }
        }
        if (!p_readstate && !loaded) {                                // not loaded by the game: load it ourselves
            loaded = 1;
            uint32_t h = sceKernelLoadStartModule("libScePad.sprx", 0, 0, 0, 0, 0);
            void *rs = 0, *gh = 0;
            if ((int32_t)h > 0) { sceKernelDlsym(h, "scePadReadState", &rs); sceKernelDlsym(h, "scePadGetHandle", &gh); }
            logf_("pad: %zu modules, none exports the pad API; LoadStartModule(libScePad) = %x rs %p gh %p", n, h, rs, gh);
            if (rs && gh) { p_readstate = (pad_readstate_t)rs; p_gethandle = (pad_gethandle_t)gh; }
        }
        if (!p_readstate || !p_gethandle) return 0;
    }
    int32_t user = -1;
    int ur = sceUserServiceGetInitialUser(&user);
    if (ur != 0 || user < 0) { if (!tried) logf_("pad: GetInitialUser failed %x user %d", ur, user); tried = 1; return 0; }
    int h = p_gethandle(user, 0, 0);
    if (h < 0) { if (!tried) logf_("pad: scePadGetHandle failed %x", h); tried = 1; return 0; }
    g_pad = h;
    logf_("pad handle %d (user %x)", h, user);
    return 1;
}

// ---- on-screen menu (shown as PS4 notifications): L1+L3 opens/closes, UP/DOWN select, CROSS toggles, CIRCLE closes ----
static int g_menu = 0, g_msel = 0; static uint64_t g_mshow = 0;
static const Fn *find_fn(const char *n);
#define MENU_N 5
static int g_mdn = 0;
static void menu_draw(void) {                                  // one short line: only the selected item (notifications can't stay on screen)
    if (g_mdn < 40) logf_("menu: draw #%d sel %d", ++g_mdn, g_msel);
    const char *on[2] = { "OFF", "ON" };
    if (g_msel == 0) Notify(TEX_ICON_SYSTEM, "MENU 1/5  > Aura: %s", on[g_aura ? 1 : 0]);
    else if (g_msel == 1) Notify(TEX_ICON_SYSTEM, "MENU 2/5  > Tour: %s", on[g_tauto ? 1 : 0]);
    else if (g_msel == 2) Notify(TEX_ICON_SYSTEM, "MENU 3/5  > Speed: %lu ms", (unsigned long)g_tstep);
    else if (g_msel == 3) Notify(TEX_ICON_SYSTEM, "MENU 4/5  > TP nearest chest (X)");
    else Notify(TEX_ICON_SYSTEM, "MENU 5/5  > Close (X)");
}
static void menu_key(uint32_t edge) {
    if (edge & ORBIS_PAD_BUTTON_UP) { g_msel = (g_msel + MENU_N - 1) % MENU_N; g_mdraw = 1; }
    else if (edge & ORBIS_PAD_BUTTON_DOWN) { g_msel = (g_msel + 1) % MENU_N; g_mdraw = 1; }
    else if (edge & ORBIS_PAD_BUTTON_CIRCLE) { g_menu = 0; Notify(TEX_ICON_SYSTEM, "fn_chests menu closed"); }
    else if (edge & ORBIS_PAD_BUTTON_CROSS) {
        if (g_msel == 0) request(find_fn("aura"));
        else if (g_msel == 1) request(find_fn("tour"));
        else if (g_msel == 2) g_tstep = g_tstep <= 60 ? 100 : (g_tstep <= 100 ? 200 : 60);
        else if (g_msel == 3) request(find_fn("tpchest"));
        else { g_menu = 0; Notify(TEX_ICON_SYSTEM, "fn_chests menu closed"); return; }
        g_mshow = now_ms() + 500;
    }
}
static void pad_tick(void) {
    static uint32_t prev;
    if (!pad_init()) return;
    OrbisPadData d; memset(&d, 0, sizeof d);
    if (p_readstate(g_pad, &d) != 0) { g_pad = -1; return; }
    static uint32_t pfull;
    uint32_t edge = d.buttons & ~pfull; pfull = d.buttons;
    if (g_menu && now_ms() - g_mopen > 15000) { g_menu = 0; g_mdraw = 0; logf_("menu: auto-closed"); Notify(TEX_ICON_SYSTEM, "fn_chests menu closed"); }
    if (g_menu) {
        if (edge) { static int en = 0; if (en < 30) logf_("menu: key edge %x (buttons %x)", edge, d.buttons); en++; }
        if (edge) g_mopen = now_ms();
        menu_key(edge);
        if (g_mshow && now_ms() >= g_mshow) { g_mshow = 0; if (g_menu) g_mdraw = 1; }
    }
    uint32_t mask = 0; for (size_t i = 0; i < NFNS; i++) mask |= FNS[i].pad_combo;
    uint32_t b = d.buttons & mask;                         // exact match: L1+R1+R3 must not also fire L1+R1
    for (size_t i = 0; i < NFNS; i++) {
        uint32_t c = FNS[i].pad_combo;
        if (c && b == c && prev != c && (!g_menu || FNS[i].sp == 14)) request(&FNS[i]);
    }
    prev = b;
}

static void *worker_thread(void *arg) {
    (void)arg;
    uint64_t t0 = now_ms();
    int hooked_try = 0;
    for (;;) {
        sceKernelUsleep(PAD_POLL_MS * 1000);
        if (!hooked_try && now_ms() - t0 >= START_DELAY_US / 1000) {
            hooked_try = 1;
            int r = install_hook();
            if (r == 0) { st(&g_hooked, 1); logf_("ProcessEvent hooked at %lx (stub %p)", A_PROCESSEVENT, g_stub); }
            else logf_("hook failed, pad/socket commands would run on their own thread (can crash): disabled");
        }
        if (ld(&g_hooked)) pad_tick();
    }
    return 0;
}

// ---- command server -------------------------------------------------------------------------------------
static const Fn *find_fn(const char *n) {
    for (size_t i = 0; i < NFNS; i++) if (strcmp(FNS[i].name, n) == 0) return &FNS[i];
    return 0;
}
static void reply(int c, const char *fmt, ...) {
    char out[256]; va_list ap; va_start(ap, fmt); int n = vsnprintf(out, sizeof out, fmt, ap); va_end(ap);
    if (n > 0) sceNetSend(c, out, n, 0);
}
static void handle_line(int c, char *line) {
    char *e = line + strlen(line);
    while (e > line && (e[-1] == '\r' || e[-1] == '\n' || e[-1] == ' ')) *--e = 0;
    if (!strcmp(line, "status")) {
        int ok = resolve_pc();
        reply(c, "hook=%d pc=%lx cm=%lx chain=%d\n", ld(&g_hooked), g_pc, g_pc ? find_cm() : 0, ok);
        return;
    }
    if (!strcmp(line, "list")) {
        for (size_t i = 0; i < NFNS; i++) reply(c, "%s\n", FNS[i].name);
        return;
    }
    if (!strncmp(line, "radius ", 7)) {
        if (!ld(&g_hooked)) { reply(c, "hook not installed yet\n"); return; }
        strncpy(g_sc_text, line + 7, sizeof g_sc_text - 1); g_sc_text[sizeof g_sc_text - 1] = 0;
        line = (char *)"radius";
    }
    if (!strncmp(line, "speed ", 6)) {
        if (!ld(&g_hooked)) { reply(c, "hook not installed yet\n"); return; }
        strncpy(g_sc_text, line + 6, sizeof g_sc_text - 1); g_sc_text[sizeof g_sc_text - 1] = 0;
        line = (char *)"speed";
    }
    if (!strncmp(line, "sc ", 3)) {
        if (!ld(&g_hooked)) { reply(c, "hook not installed yet\n"); return; }
        strncpy(g_sc_text, line + 3, sizeof g_sc_text - 1); g_sc_text[sizeof g_sc_text - 1] = 0;
        line = (char *)"sc";
    }
    const Fn *f = find_fn(line);
    if (!f) { reply(c, "unknown: %s (try: list)\n", line); return; }
    if (!ld(&g_hooked)) { reply(c, "hook not installed yet (wait %us after game start)\n", START_DELAY_US / 1000000u); return; }
    reply(c, push_cmd(f) ? "queued\n" : "queue full\n");
}
static void *server_thread(void *arg) {
    (void)arg;
    int s = sceNetSocket("fn_chests", ORBIS_NET_AF_INET, ORBIS_NET_SOCK_STREAM, 0);
    if (s < 0) { logf_("sceNetSocket failed %x", s); return 0; }
    int one = 1; sceNetSetsockopt(s, 0xffff /* SOL_SOCKET */, 4 /* SO_REUSEADDR */, &one, sizeof one);
    OrbisNetSockaddr a; memset(&a, 0, sizeof a);
    a.len = 16; a.sa_family = ORBIS_NET_AF_INET;
    uint16_t port = sceNetHtons(CMD_PORT); memcpy(a.sa_data, &port, 2);   // sin_port; sin_addr = INADDR_ANY (zero)
    if (sceNetBind(s, &a, sizeof a) < 0 || sceNetListen(s, 2) < 0) { logf_("bind/listen %d failed", CMD_PORT); sceNetSocketClose(s); return 0; }
    logf_("command server on %d", CMD_PORT);
    for (;;) {
        int c = sceNetAccept(s, 0, 0);
        if (c < 0) { sceKernelUsleep(100000); continue; }
        char buf[128];
        int n = sceNetRecv(c, buf, sizeof buf - 1, 0);
        if (n > 0) { buf[n] = 0; handle_line(c, buf); }
        sceNetSocketClose(c);
    }
    return 0;
}

// ---- plugin entry ---------------------------------------------------------------------------------------
int32_t attr_public plugin_load(int32_t argc, const char *argv[]) {
    (void)argc; (void)argv;
    struct proc_info pi;
    if (sys_sdk_proc_info(&pi) != 0) return 0;
    logf_("==== fn_chests BUILD-V25 (fast tour): %s v%s", pi.titleid, pi.version);
    if (strcmp(pi.titleid, "CUSA07669") && strcmp(pi.titleid, "CUSA07022")) { logf_("not Fortnite, off"); return 0; }
    logf_("hook in %u s", START_DELAY_US / 1000000u);
    OrbisPthread t1, t2;
    scePthreadCreate(&t1, NULL, worker_thread, NULL, "fn_chests_w");
    scePthreadCreate(&t2, NULL, server_thread, NULL, "fn_chests_s");
    return 0;
}
int32_t attr_public plugin_unload(int32_t argc, const char *argv[]) { (void)argc; (void)argv; return 0; }
s32 attr_module_hidden module_start(s64 argc, const void *args) { (void)argc; (void)args; return 0; }
s32 attr_module_hidden module_stop(s64 argc, const void *args) { (void)argc; (void)args; return 0; }
