@echo off
cd /d "%~dp0"
powershell -NoProfile -Command "$w=New-Object Net.WebClient; try{ $t=$w.DownloadString('ftp://anonymous:x@192.168.1.189:2121/data/GoldHEN/fn_chests_log.txt'); $i=$t.LastIndexOf('==== fn_chests BUILD-V4'); if($i -ge 0){$t.Substring($i)}else{$t} }catch{ 'no log: '+$_.Exception.Message }"
pause
