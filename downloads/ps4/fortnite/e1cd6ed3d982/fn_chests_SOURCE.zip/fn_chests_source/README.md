# fn_chests — source pack and full recap

Tooling for **Fortnite CUSA07669, build 43.10 (Spectrum_FN_43.10)** on a jailbroken PS4 (FW 14.02, GoldHEN),
used against a **private EZFN server** on the author's own console. It teleports to every existing chest and opens it.

Contents
```
plugin/   fn_chests GoldHEN plugin (C, builds to a SELF .prx)   -> main.c, plugin_common.[ch], build.sh
tool/     FN_Chests_Tool for Windows (Go, stdlib only)          -> main.go, ftp.go, index.html, build.sh
          plugin.prx (v25) and ps4debug.bin are embedded into the exe at build time
fn_cmd.bat, fn_log.bat, install_fn_chests25.bat/.ps1            -> command-line helpers (no exe needed)
```

## 1. What works and what does not (status of v25)

| Feature | Status |
|---|---|
| Plugin loads through GoldHEN `plugins.ini`, hooks `UObject::ProcessEvent` | works |
| Game-thread detection (the plugin only touches objects from the game thread) | works |
| **Aura** — opens every chest within a radius (default 320 units, ~3 m) as you walk | works (only when close) |
| **near** — opens the nearest chest without teleporting | works (only when close) |
| **Tour** — teleport to every chest in turn and open it | works from a **vehicle** (cannon / SUV): all chests opened. Outside a vehicle the server reverts the position |
| Pad combos + notification menu (L1+L3) | works (pad is read through a privately loaded `libScePad`) |
| Cheat functions of `FortCheatManager` (god, ammo, infinite stamina, ...) | **no effect**: the bodies are empty in this shipping build |
| `ServerCheat` strings | no visible effect |
| Real on-screen overlay menu | not implemented (notifications only) |
| Opening chests from far away without a vehicle | impossible client-side: the server checks distance from the *server* pawn position. Needs a server (EZFN) change |

v25 was compiled and run; the PC tool was tested only against a fake PS4 (FTP + command port + payload port).

## 2. Architecture of the plugin

* **Delivery.** `/data/GoldHEN/plugins/fn_chestsN.prx`, listed under `[CUSA07669]` in `/data/GoldHEN/plugins.ini`.
  Every build must use a **new file name** (the PS4 can keep loading an old same-name file); the installers rewrite `plugins.ini`
  so only the newest `fn_chests*` line exists. The log (`/data/GoldHEN/fn_chests_log.txt`) starts every load with `==== fn_chests BUILD-Vnn ...`.
* **Build.** OpenOrbis toolchain + GoldHEN Plugins SDK, `create-fself ... --paid 0x3800000000000011`.
* **Start.** 30 s after the game starts (`START_DELAY_US`) a Detour is installed on `ProcessEvent` (0xfaadbc).
  A worker thread polls the pad every 16 ms and runs a TCP command server on port 9099.
* **Game-thread model.** `pe_hook` drains a command queue and runs `auto_tick()` (aura / tour / menu drawing) on the game thread only.
  Every 20000 `ProcessEvent` calls it votes for the busiest thread; other threads pass through. The original function is called
  through the Detour stub (`g_stub`, `call_pe2`) so the plugin never re-enters its own hook. Unknown: why the long old `chests` sequence
  crashed the game at random (do not use it).
* **UE5 layout (43.10, addresses fixed for this exact build).**
  GObjects 0x15494740 (chunk table at +0, 24-byte items, 65536 per chunk; compressed pointer `obj = ((q0 & 0x3fff00000000) | dword[+8]) << 3`,
  invalid if `q0 & 0x1020000000000000`); FNamePool 0x15444240 (blocks at +0x10, header `len = hdr>>6`; FName index at UObject+0x18);
  UObject: +0x08 flags (destroyed mask 0x18000), +0x10 ClassPrivate, +0x18 Name, +0x20 Outer; SuperStruct at 0x40; FVector = 3 doubles.
* **Object chain.** GEngine global (0x154f3fa8 or 0x15524688) → FortEngine → GameInstance (scan up to 0x4000) →
  LocalPlayers (GI+0x38) → LocalPlayer+0x30 = PlayerController. PC+0x3d8 = CheatClass, PC+0x3e0 = CheatManager.
* **Chest enumeration.** Walk GObjects, keep instances whose class name contains "Chest" / "Ammo" (`BuildingContainer`, `Tiered_Chest_Athena_C`,
  `AlwaysSpawn_NormalChest_C`, ...), read positions with `K2_GetActorLocation`. Client unloads far actors, so stored pointers go stale;
  the tour therefore stores coordinates and looks the chest up again after arriving.
* **Opening a chest.** Call `FortControllerComponent_Interaction.ServerAttemptInteract` (UFunction 0x125ed848) on the interaction component
  (found by scanning GObjects for class 0x125f0be8 whose outer is the PlayerController). Real chest call: `param[0]` ReceivingActor,
  `param[8]` InteractComponent = `*(actor+0x1b0)`, byte at offset 16 = 2 (ETInteractionType), rest zero. Type 1 = doorway / cannon.
* **Teleport.** `K2_TeleportTo` (0x111a5a48) on the pawn, or on the vehicle actor when `GetVehicleActor` (0x130dff00) returns one.
  Destination is chest position + `TP_LIFT` (120 units). The server accepts it for a player in a vehicle.
* **Tour loop (`tour_tick`).** Order = greedy nearest neighbour from the player position. Per chest: teleport, wait `0.4·step`, re-find the chest
  if its pointer is stale, interact, wait `0.6·step`. `step` is `g_tstep` (default 100 ms, command `speed <50..5000>`).
* **Pad.** `scePadReadState` is not exported by the game's own modules, so the plugin loads `libScePad.sprx` itself and calls
  `scePadGetHandle`. Combos are matched exactly (L1+R1 does not also fire on L1+R1+R3). While the menu is open only the menu combo is live.
* **Menu.** PS4 notifications cannot stay on screen, so the menu shows one item per notification (`MENU 2/5 > Tour: OFF`) and redraws only on input,
  at most every 600 ms, from the game thread. It closes by itself after 15 s without input.

## 3. Commands

Controller: **L1+L3** menu · **L1+R1** aura · **L1+R3** tour · **L1+UP** teleport to nearest unvisited chest.
Menu: UP/DOWN select, **X** run (Aura, Tour, Speed 60/100/200 ms, TP nearest, Close), **CIRCLE** close.

TCP port 9099 (plain text, one command per connection): `aura`, `tour`, `tpchest`, `near`, `stop`, `reset`, `speed <ms>`, `radius <units>`,
`menu`, `status`, `list`, `probe`, `trace`, `sc <text>` (ServerCheat), `chests` (old full sequence, unstable).

## 4. Build

Plugin (`plugin/build.sh`): set `OO_PS4_TOOLCHAIN` and `GOLDHEN_SDK`, run the script, output `build/fn_chests.prx`.
Upload under a **new** name and rewrite `plugins.ini` (see `install_fn_chests25.ps1`, or use the Windows tool).

Tool (`tool/build.sh`): Go 1.21+, no network, `GOOS=windows GOARCH=amd64`. To ship a newer plugin, copy it to `tool/plugin.prx`
and change `pluginName` in `main.go`.

## 5. Windows tool

`FN_Chests_Tool.exe` starts a local web UI on `127.0.0.1:8787`. It sends the ps4debug payload (ports 9090 then 9020, then checks 744),
installs the plugin over FTP (port 2121, anonymous, passive mode; GoldHEN's `SIZE` is larger than the uploaded bytes — informational only),
rewrites `plugins.ini` (backup saved next to the exe), sends commands to port 9099 and reads the log. The PS4 IP is stored in `fn_tool.txt`
(default 192.168.1.189).

## 6. Version history (what each build changed)

| Build | Change |
|---|---|
| v2–v3 | first plugin; CheatManager read at wrong offset → fixed to pc+0x3e0 |
| v4–v9 | own chest scan + interact; learn real interact params; cheat functions found empty in this build |
| v10–v13 | `near`, `aura`, radius commands, vehicle teleport attempt (rejected outside a vehicle) |
| v14–v15 | aura radius commands; game-thread-only execution (fixes freeze when enabling aura in the Battle Bus) |
| v16 | `tour` (coordinate based, re-finds unloaded chests) |
| v17–v18 | pad combos, on-screen notification menu, speed command |
| v19 | pad fix: plugin loads `libScePad` itself |
| v20 | teleport pin loop (later removed: it measured the client position, which moves instantly) |
| v21–v22 | menu fixes: exact combos, one-line notifications, game-thread drawing, auto-close, debug breadcrumbs |
| v23 | faster tp timings |
| v24 | one-item notifications, removed useless god/ammo combos |
| v25 | no arrival check, ~0.1 s per chest, speed 50–5000 ms |

## 7. Lessons

* The client position read right after a teleport is meaningless: the client moves instantly and the server corrects later.
  The only proof a chest opened is the loot actually appearing (or the server log).
* The server decides: distance check on interact, position authority outside vehicles. Anything beyond the aura needs a server change.
* Notifications cannot be a persistent menu; a real overlay would need hooking the video-out flip and drawing into the framebuffer.
* Keep one stated assumption instead of questions; log breadcrumbs around every risky step (they found the pad and menu bugs).

For use on your own console, your own game copy and your own server.
