@echo off
rem usage: fn_cmd.bat chests   (or: tpchest, god, ammo, status, list ...)
if "%~1"=="" (echo usage: fn_cmd.bat ^<command^> ^| try: list & goto end)
powershell -NoProfile -Command "$c=New-Object Net.Sockets.TcpClient('192.168.1.189',9099); $s=$c.GetStream(); $b=[Text.Encoding]::ASCII.GetBytes('%~1'); $s.Write($b,0,$b.Length); Start-Sleep -Milliseconds 700; $r=New-Object byte[] 2048; $n=$s.Read($r,0,2048); [Text.Encoding]::ASCII.GetString($r,0,$n); $c.Close()"
:end
