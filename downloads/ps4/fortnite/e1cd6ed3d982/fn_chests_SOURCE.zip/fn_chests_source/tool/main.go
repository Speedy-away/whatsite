package main

import (
	"bytes"
	_ "embed"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

//go:embed plugin.prx
var pluginPRX []byte

//go:embed ps4debug.bin
var ps4debugBIN []byte

//go:embed index.html
var indexHTML []byte

const (
	pluginName = "fn_chests25.prx"
	titleID    = "CUSA07669"
	ftpPort    = 2121
	cmdPort    = 9099
	debugPort  = 744
	defaultIP  = "192.168.1.189"
	listenAddr = "127.0.0.1:8787"
	pluginsDir = "/data/GoldHEN/plugins/"
	pluginsINI = "/data/GoldHEN/plugins.ini"
	pluginLog  = "/data/GoldHEN/fn_chests_log.txt"
	configName = "fn_tool.txt"
)

func exeDir() string {
	p, err := os.Executable()
	if err != nil {
		return "."
	}
	return filepath.Dir(p)
}

func loadIP() string {
	b, err := os.ReadFile(filepath.Join(exeDir(), configName))
	if err != nil {
		return defaultIP
	}
	ip := strings.TrimSpace(string(b))
	if net.ParseIP(ip) == nil {
		return defaultIP
	}
	return ip
}

func saveIP(ip string) { os.WriteFile(filepath.Join(exeDir(), configName), []byte(ip+"\n"), 0o644) }

func portOpen(ip string, port int) bool {
	c, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", ip, port), 1200*time.Millisecond)
	if err != nil {
		return false
	}
	c.Close()
	return true
}

type resp struct {
	OK  bool   `json:"ok"`
	Msg string `json:"msg"`
}

func reply(w http.ResponseWriter, ok bool, format string, a ...any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resp{ok, fmt.Sprintf(format, a...)})
}

func sendPayload(ip string) (string, error) {
	if portOpen(ip, debugPort) {
		return fmt.Sprintf("ps4debug is already running on %d - nothing to send", debugPort), nil
	}
	for _, port := range []int{9090, 9020} {
		c, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", ip, port), 3*time.Second)
		if err != nil {
			continue
		}
		c.SetWriteDeadline(time.Now().Add(30 * time.Second))
		_, err = c.Write(ps4debugBIN)
		c.Close()
		if err != nil {
			return "", fmt.Errorf("port %d: %v", port, err)
		}
		time.Sleep(3 * time.Second)
		if portOpen(ip, debugPort) {
			return fmt.Sprintf("payload sent to port %d - ps4debug is up on %d", port, debugPort), nil
		}
		return fmt.Sprintf("payload sent to port %d, but ps4debug does not answer on %d yet (wait a few seconds and press Status)", port, debugPort), nil
	}
	return "", fmt.Errorf("PS4 not ready: ports 9090/9020 are closed. Check the PS4 IP, jailbreak the console and load GoldHEN first, then try again")
}

func installPlugin(ip string) (string, error) {
	f, err := ftpDial(ip, ftpPort)
	if err != nil {
		return "", fmt.Errorf("FTP %s:%d: %v", ip, ftpPort, err)
	}
	defer f.Close()
	if err := f.Store(pluginsDir+pluginName, pluginPRX); err != nil {
		return "", err
	}
	var out strings.Builder
	// GoldHEN's FTP reports a different SIZE than the bytes uploaded (padding) - informational only
	if n, err := f.Size(pluginsDir + pluginName); err == nil {
		fmt.Fprintf(&out, "uploaded %d bytes (PS4 reports %d). ", len(pluginPRX), n)
		if n < len(pluginPRX) {
			return "", fmt.Errorf("upload incomplete: PS4 has %d bytes, sent %d - run Install again", n, len(pluginPRX))
		}
	} else {
		fmt.Fprintf(&out, "uploaded %d bytes. ", len(pluginPRX))
	}
	ini, err := f.Retrieve(pluginsINI)
	if err != nil {
		return "", fmt.Errorf("cannot read plugins.ini: %v", err)
	}
	os.WriteFile(filepath.Join(exeDir(), "ps4_plugins_backup.ini"), ini, 0o644)
	var lines []string
	found := false
	for _, l := range strings.Split(strings.ReplaceAll(string(ini), "\r\n", "\n"), "\n") {
		if strings.Contains(l, "fn_chests") {
			continue
		}
		lines = append(lines, l)
		if strings.TrimSpace(l) == "["+titleID+"]" {
			lines = append(lines, pluginsDir+pluginName)
			found = true
		}
	}
	if !found {
		return "", fmt.Errorf("no [%s] section in plugins.ini", titleID)
	}
	newINI := strings.TrimRight(strings.Join(lines, "\r\n"), "\r\n") + "\r\n"
	if err := f.Store(pluginsINI, []byte(newINI)); err != nil {
		return "", err
	}
	out.WriteString("plugins.ini updated (backup: ps4_plugins_backup.ini). Restart Fortnite.")
	return out.String(), nil
}

func sendCmd(ip, cmd string) (string, error) {
	c, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", ip, cmdPort), 3*time.Second)
	if err != nil {
		return "", fmt.Errorf("plugin not reachable on %d (is Fortnite running with the plugin, and 30 s passed?)", cmdPort)
	}
	defer c.Close()
	c.Write([]byte(cmd))
	c.SetReadDeadline(time.Now().Add(1500 * time.Millisecond))
	buf := make([]byte, 2048)
	n, _ := c.Read(buf)
	return strings.TrimSpace(string(buf[:n])), nil
}

func readLog(ip string) (string, error) {
	f, err := ftpDial(ip, ftpPort)
	if err != nil {
		return "", err
	}
	defer f.Close()
	b, err := f.Retrieve(pluginLog)
	if err != nil {
		return "", err
	}
	s := string(b)
	if i := strings.LastIndex(s, "==== fn_chests BUILD-V"); i >= 0 {
		s = s[i:]
	}
	var keep []string
	for _, l := range strings.Split(s, "\n") {
		if strings.Contains(l, "scanning...") || strings.Contains(l, "containers, reading") || strings.Contains(l, "with position") || strings.Contains(l, "stale object") {
			continue
		}
		keep = append(keep, l)
	}
	if len(keep) > 400 {
		keep = keep[len(keep)-400:]
	}
	return strings.Join(keep, "\n"), nil
}

var allowed = map[string]string{
	"aura": "aura", "tour": "tour", "stop": "stop", "reset": "reset", "near": "near", "tp": "tpchest", "menu": "menu",
	"speed60": "speed 60", "speed100": "speed 100", "speed200": "speed 200",
	"radius320": "radius 320", "radius600": "radius 600", "radius1000": "radius 1000",
}

func main() {
	ip := loadIP()
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(bytes.ReplaceAll(indexHTML, []byte("{{PLUGIN}}"), []byte(pluginName)))
	})
	mux.HandleFunc("/api/ip", func(w http.ResponseWriter, r *http.Request) {
		if v := strings.TrimSpace(r.URL.Query().Get("set")); v != "" {
			if net.ParseIP(v) == nil {
				reply(w, false, "invalid IP")
				return
			}
			ip = v
			saveIP(ip)
		}
		reply(w, true, "%s", ip)
	})
	mux.HandleFunc("/api/status", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]bool{
			"ps4":    portOpen(ip, ftpPort) || portOpen(ip, 9090) || portOpen(ip, debugPort),
			"ftp":    portOpen(ip, ftpPort),
			"debug":  portOpen(ip, debugPort),
			"plugin": portOpen(ip, cmdPort),
		})
	})
	mux.HandleFunc("/api/payload", func(w http.ResponseWriter, r *http.Request) {
		m, err := sendPayload(ip)
		if err != nil {
			reply(w, false, "%v", err)
			return
		}
		reply(w, true, "%s", m)
	})
	mux.HandleFunc("/api/install", func(w http.ResponseWriter, r *http.Request) {
		m, err := installPlugin(ip)
		if err != nil {
			reply(w, false, "%v", err)
			return
		}
		reply(w, true, "%s", m)
	})
	mux.HandleFunc("/api/cmd", func(w http.ResponseWriter, r *http.Request) {
		c, ok := allowed[r.URL.Query().Get("c")]
		if !ok {
			reply(w, false, "unknown command")
			return
		}
		m, err := sendCmd(ip, c)
		if err != nil {
			reply(w, false, "%v", err)
			return
		}
		reply(w, true, "%s: %s", c, m)
	})
	mux.HandleFunc("/api/log", func(w http.ResponseWriter, r *http.Request) {
		s, err := readLog(ip)
		if err != nil {
			reply(w, false, "%v", err)
			return
		}
		reply(w, true, "%s", s)
	})
	ln, err := net.Listen("tcp", listenAddr)
	if err != nil {
		fmt.Println("port 8787 busy - is the tool already open? Open http://" + listenAddr)
		time.Sleep(3 * time.Second)
		return
	}
	fmt.Println("FN Chests Tool running on http://" + listenAddr + "  (close this window to quit)")
	go func() {
		time.Sleep(400 * time.Millisecond)
		exec.Command("rundll32", "url.dll,FileProtocolHandler", "http://"+listenAddr).Start()
	}()
	http.Serve(ln, mux)
}
