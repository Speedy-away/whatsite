package main

import (
	"bufio"
	"fmt"
	"io"
	"net"
	"net/textproto"
	"strconv"
	"strings"
	"time"
)

// Minimal passive-mode FTP client (anonymous), enough for GoldHEN's FTP server.
type ftpConn struct {
	host string
	c    net.Conn
	tp   *textproto.Conn
}

func ftpDial(host string, port int) (*ftpConn, error) {
	c, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), 5*time.Second)
	if err != nil {
		return nil, err
	}
	f := &ftpConn{host: host, c: c, tp: textproto.NewConn(c)}
	if _, _, err := f.tp.ReadResponse(220); err != nil {
		c.Close()
		return nil, err
	}
	f.tp.Cmd("USER anonymous")
	code, _, _ := f.tp.ReadResponse(0)
	if code == 331 {
		f.tp.Cmd("PASS x")
		if err := f.expectAny("PASS", 230, 202); err != nil {
			c.Close()
			return nil, err
		}
	} else if code != 230 {
		c.Close()
		return nil, fmt.Errorf("login refused (%d)", code)
	}
	f.tp.Cmd("TYPE I")
	f.expectAny("TYPE", 200)
	return f, nil
}

func (f *ftpConn) expectAny(what string, codes ...int) error {
	code, msg, err := f.tp.ReadResponse(0)
	if err != nil && code == 0 {
		return err
	}
	for _, c := range codes {
		if c == code {
			return nil
		}
	}
	return fmt.Errorf("%s: unexpected reply %d %s", what, code, msg)
}

func (f *ftpConn) pasv() (net.Conn, error) {
	f.tp.Cmd("PASV")
	code, msg, err := f.tp.ReadResponse(0)
	if err != nil && code == 0 {
		return nil, err
	}
	if code != 227 {
		return nil, fmt.Errorf("PASV: %d %s", code, msg)
	}
	i, j := strings.Index(msg, "("), strings.LastIndex(msg, ")")
	if i < 0 || j < i {
		return nil, fmt.Errorf("PASV: cannot parse %q", msg)
	}
	p := strings.Split(msg[i+1:j], ",")
	if len(p) != 6 {
		return nil, fmt.Errorf("PASV: cannot parse %q", msg)
	}
	hi, _ := strconv.Atoi(strings.TrimSpace(p[4]))
	lo, _ := strconv.Atoi(strings.TrimSpace(p[5]))
	return net.DialTimeout("tcp", fmt.Sprintf("%s:%d", f.host, hi*256+lo), 5*time.Second)
}

func (f *ftpConn) Store(path string, data []byte) error {
	dc, err := f.pasv()
	if err != nil {
		return err
	}
	f.tp.Cmd("STOR %s", path)
	code, msg, err := f.tp.ReadResponse(0)
	if err != nil && code == 0 {
		dc.Close()
		return err
	}
	if code != 150 && code != 125 {
		dc.Close()
		return fmt.Errorf("STOR %s: %d %s", path, code, msg)
	}
	if _, err := dc.Write(data); err != nil {
		dc.Close()
		return err
	}
	dc.Close()
	code, msg, err = f.tp.ReadResponse(0)
	if err != nil && code == 0 {
		return err
	}
	if code != 226 && code != 250 {
		return fmt.Errorf("STOR %s: %d %s", path, code, msg)
	}
	return nil
}

func (f *ftpConn) Retrieve(path string) ([]byte, error) {
	dc, err := f.pasv()
	if err != nil {
		return nil, err
	}
	defer dc.Close()
	f.tp.Cmd("RETR %s", path)
	code, msg, err := f.tp.ReadResponse(0)
	if err != nil && code == 0 {
		return nil, err
	}
	if code != 150 && code != 125 {
		return nil, fmt.Errorf("RETR %s: %d %s", path, code, msg)
	}
	data, err := io.ReadAll(bufio.NewReader(dc))
	if err != nil {
		return nil, err
	}
	dc.Close()
	f.tp.ReadResponse(0)
	return data, nil
}

func (f *ftpConn) Size(path string) (int, error) {
	f.tp.Cmd("SIZE %s", path)
	code, msg, err := f.tp.ReadResponse(0)
	if err != nil && code == 0 {
		return 0, err
	}
	if code != 213 {
		return 0, fmt.Errorf("SIZE: %d %s", code, msg)
	}
	return strconv.Atoi(strings.TrimSpace(msg))
}

func (f *ftpConn) Close() {
	f.tp.Cmd("QUIT")
	f.c.Close()
}
