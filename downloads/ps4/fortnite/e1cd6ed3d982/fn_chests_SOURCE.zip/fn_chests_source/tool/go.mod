module fntool

go 1.24
