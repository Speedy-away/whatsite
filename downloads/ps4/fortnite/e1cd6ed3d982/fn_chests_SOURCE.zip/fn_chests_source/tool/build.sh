#!/bin/sh
# Build the Windows tool (stdlib only, no network needed). plugin.prx and ps4debug.bin are embedded.
set -e
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -ldflags="-s -w" -o FN_Chests_Tool.exe .
ls -la FN_Chests_Tool.exe
