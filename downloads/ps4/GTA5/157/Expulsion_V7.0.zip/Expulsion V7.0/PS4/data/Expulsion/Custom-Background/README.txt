EXPULSION CUSTOM BACKGROUND

Copy this folder to /data/Expulsion/Custom-Background on the PS4.
Open Settings > Menu Settings > Custom Background.
Enable the background, select LushModz.bg157, and Save Background Settings.
Opacity, darkening and contain/cover/stretch fit are adjustable.
Refresh Images reloads the selected image and rescans up to 32 prepared files.
The image fills the menu option area across the new and legacy designs.
Player panels retain their matching theme and colors.

This renderer uses a coarse, bounded approximation of your image made from
at most 256 colored rectangles, plus a darkening overlay. It does not load
JPG/PNG textures directly. The original LushModz.jpg is included unchanged;
LushModz-preview.png shows the prepared image detail before in-game blending.
Appearance and frame-time cost still require testing on the PS4.

To prepare another image on a computer with Python:
  python prepare_custom_background.py input.jpg MyImage.bg157 --preview preview.png
On Windows the converter uses System.Drawing if Pillow is unavailable.
On other platforms install Pillow first. Copy the resulting .bg157 file into
this folder, then use Refresh Images and select it in the menu.
Use simple logos or bold shapes for the clearest result at this drawing budget.
Files must have a lowercase .bg157 extension. Invalid files are rejected.
Save Background Settings stores both the selected filename and menu controls.
