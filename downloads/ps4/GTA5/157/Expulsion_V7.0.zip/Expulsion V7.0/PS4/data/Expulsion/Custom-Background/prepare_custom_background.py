"""Convert an image to bounded native-drawing rectangles; no game texture offsets needed.

Uses Pillow if installed, or Windows System.Drawing without extra dependencies.
Usage: python prepare_custom_background.py input.jpg output.bg157 [--rects 256]
"""
import argparse
import heapq
import os
from pathlib import Path
import struct
import subprocess
import tempfile
import zlib


def read_image(path, size):
    try:
        from PIL import Image, ImageOps
    except ImportError:
        if os.name != "nt":
            raise RuntimeError("Run this tool on Windows, or install Pillow: python -m pip install Pillow")
        with tempfile.TemporaryDirectory(prefix="expulsion-image-") as directory:
            output = Path(directory) / "pixels.bin"
            env = dict(os.environ, EXPULSION_IMAGE_INPUT=str(path.resolve()),
                       EXPULSION_IMAGE_OUTPUT=str(output), EXPULSION_IMAGE_SIZE=str(size))
            script = r'''
$ErrorActionPreference='Stop';Add-Type -AssemblyName System.Drawing
$source=[Drawing.Image]::FromFile($env:EXPULSION_IMAGE_INPUT)
try {
 if($source.Width -gt 16384 -or $source.Height -gt 16384){throw 'Image dimensions exceed 16384'}
 $limit=[int]$env:EXPULSION_IMAGE_SIZE;$factor=[Math]::Min(1.0,$limit/[double][Math]::Max($source.Width,$source.Height))
 $w=[Math]::Max(1,[int][Math]::Round($source.Width*$factor));$h=[Math]::Max(1,[int][Math]::Round($source.Height*$factor))
 $bitmap=New-Object Drawing.Bitmap($w,$h,[Drawing.Imaging.PixelFormat]::Format32bppArgb)
 try {
  $graphics=[Drawing.Graphics]::FromImage($bitmap)
  try {$graphics.Clear([Drawing.Color]::Transparent);$graphics.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic;$graphics.DrawImage($source,0,0,$w,$h)}finally{$graphics.Dispose()}
  $lock=$bitmap.LockBits((New-Object Drawing.Rectangle(0,0,$w,$h)),[Drawing.Imaging.ImageLockMode]::ReadOnly,[Drawing.Imaging.PixelFormat]::Format32bppArgb)
  try {
   if($lock.Stride -ne $w*4){throw 'Unexpected pixel stride'}
   $bytes=New-Object byte[]($w*$h*4);[Runtime.InteropServices.Marshal]::Copy($lock.Scan0,$bytes,0,$bytes.Length)
   $stream=[IO.File]::Create($env:EXPULSION_IMAGE_OUTPUT);$writer=New-Object IO.BinaryWriter($stream)
   try {$writer.Write([int]$w);$writer.Write([int]$h);$writer.Write($bytes)}finally{$writer.Dispose()}
  }finally{$bitmap.UnlockBits($lock)}
 }finally{$bitmap.Dispose()}
}finally{$source.Dispose()}
'''
            subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", script],
                           env=env, check=True, creationflags=subprocess.CREATE_NO_WINDOW)
            raw = output.read_bytes()
            width, height = struct.unpack_from("<II", raw)
            pixels = [(raw[i+2], raw[i+1], raw[i], raw[i+3]) for i in range(8, len(raw), 4)]
            return width, height, pixels
    with Image.open(path) as source:
        image = ImageOps.exif_transpose(source).convert("RGBA")
        image.thumbnail((size, size), Image.Resampling.LANCZOS)
        return image.width, image.height, list(image.getdata())


def make_rectangles(width, height, pixels, limit):
    def region(x, y, w, h):
        values = [pixels[row*width+col] for row in range(y, y+h) for col in range(x, x+w)]
        mean = tuple(round(sum(p[c] for p in values)/len(values)) for c in range(4))
        error = sum(sum((p[c]-mean[c])**2 for c in range(4)) for p in values)
        return error, (x, y, w, h, *mean)

    score, rect = region(0, 0, width, height)
    serial = 0
    leaves = {serial: rect}
    queue = [(-score, serial, rect)]
    while queue and len(leaves) < limit:
        negative, index, rect = heapq.heappop(queue)
        x, y, w, h = rect[:4]
        if negative == 0 or (w == 1 and h == 1):
            continue
        xs = [(x, w)] if w == 1 else [(x, w//2), (x+w//2, w-w//2)]
        ys = [(y, h)] if h == 1 else [(y, h//2), (y+h//2, h-h//2)]
        if len(leaves) + len(xs)*len(ys)-1 > limit:
            continue
        del leaves[index]
        for yy, hh in ys:
            for xx, ww in xs:
                score, child = region(xx, yy, ww, hh)
                serial += 1
                leaves[serial] = child
                heapq.heappush(queue, (-score, serial, child))
    return sorted(leaves.values(), key=lambda r: (r[1], r[0]))


def write_preview(path, width, height, rectangles):
    rgba = bytearray(width*height*4)
    for x, y, w, h, r, g, b, a in rectangles:
        for row in range(y, y+h):
            for col in range(x, x+w):
                offset = (row*width+col)*4
                rgba[offset:offset+4] = bytes((r, g, b, a))
    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind+data) & 0xffffffff)
    rows = b"".join(b"\0" + rgba[y*width*4:(y+1)*width*4] for y in range(height))
    path.write_bytes(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b""))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--rects", type=int, default=256)
    parser.add_argument("--size", type=int, default=128)
    parser.add_argument("--preview", type=Path)
    args = parser.parse_args()
    if not 16 <= args.rects <= 256 or not 32 <= args.size <= 256:
        parser.error("--rects must be 16..256 and --size must be 32..256")
    if args.output.suffix.lower() != ".bg157":
        parser.error("Output filename must end in .bg157")
    width, height, pixels = read_image(args.input, args.size)
    rectangles = make_rectangles(width, height, pixels, args.rects)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    payload = struct.pack("<8sHHHH", b"EXPBG157", width, height, len(rectangles), 0)
    payload += b"".join(struct.pack("<HHHHBBBB", *rect) for rect in rectangles)
    args.output.write_bytes(payload)
    if args.preview:
        write_preview(args.preview, width, height, rectangles)
    print(f"Prepared {args.output.name}: {width}x{height}, {len(rectangles)} rectangles, {len(payload)} bytes")


if __name__ == "__main__":
    main()
