Orbitale - menu pour GTA V
==========================
  PS4 1.57 / PS5 retrocompatibilite (CUSA00411) : v1.2.5   -> plugins/
  Xbox 360 TU26 (545408A7, DashLaunch)           : v1.2.7   -> xbox360/  (voir xbox360/LISEZMOI.txt)

CONTENU
  plugins/orbitale.prx        le menu PS4 / PS5 (plugin)
  plugins/orbitale-coop.prx   module cooperatif (optionnel)
  Orbitale/                   a copier dans /data/orbitale sur la console
  plugins.ini.example         comment declarer les plugins
  xbox360/orbitale.xex        le menu Xbox 360 (plugin DashLaunch) + LISEZMOI.txt

INSTALLATION PS4 / PS5 (ProspereHEN / etaHEN)
  1. Copie plugins/orbitale.prx et orbitale-coop.prx dans /data/prospere/plugins/
     (GoldHEN : /data/GoldHEN/plugins/)
  2. Copie le dossier Orbitale/ dans /data/  -> /data/orbitale/
  3. Ajoute les lignes de plugins.ini.example dans ton plugins.ini
  4. Mets ta cle de licence dans /data/orbitale/licence.key (une seule ligne)
  5. Lance GTA V. Apres quelques secondes le menu s'active.

INSTALLATION XBOX 360
  Dossier Orbitale/ -> Hdd:\Orbitale\ ou Usb:\Orbitale\ , xbox360/orbitale.xex charge par DashLaunch (launch.ini ou MorePlugins),
  cle dans Orbitale\licence.key (Hdd: ou USB). Details : xbox360/LISEZMOI.txt

LICENCE
  - Une cle = une PlayStation + une Xbox 360 (chacune liee a son premier lancement).
  - La cle se valide en ligne au lancement ; ensuite ~24 h de jeu possibles hors-ligne.
  - Pas de cle / cle refusee : le menu reste inactif et affiche la raison a l'ecran.
  - Journal : /data/orbitale/lic.log (PS) ou Orbitale\logs\lic.log (Xbox 360)

COOP (optionnel)
  Renseigne /data/orbitale/coop.ini (serveur, identifiant). Ne partage jamais ton mot de passe.

(c) 2026 Orbitale - lbxmb.fr. Tous droits reserves.
