Depose ici tes fichiers .xml (Objects) au format Menyoo. Le menu les liste automatiquement.
