Depose ici tes fichiers .xml (Outfits) au format Menyoo. Le menu les liste automatiquement.
