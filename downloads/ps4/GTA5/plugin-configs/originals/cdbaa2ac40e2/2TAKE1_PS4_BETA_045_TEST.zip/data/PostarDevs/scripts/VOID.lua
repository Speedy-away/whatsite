-- VOID 0.5: external utilities for the existing 0.3 PS4 script API.
-- Uses only exposed natives. No money/XP gifts, griefing or PC dependencies.
-- Native availability is not proof of physical console behavior.
local flags={god=false,invisible=false,ragdoll=false,jump=false,melee=false,
 police=false,npcs=false,run=false,swim=false,regen=false,clip=false,ammo=false,
 repair=false,engine=false,radio=false}
local vision="off"
local last_ammo=0
local last_period=-1000
local pending_anim=nil
local previous=nil
local colors={
 {"Mint Green",3,255,171},{"Shiny Blue",5,5,255},{"Joker Green",2,153,57},
 {"Pindel Pink",247,136,206},{"Bleek Banana",236,255,140},{"WaterMelon",187,235,42},
 {"Magnetic Blue",73,76,153},{"Aqua Blue",66,208,255},{"MP100",255,249,122},
 {"Galaxy Purple",53,3,255},{"Brunswick Green",43,85,64},
}
local themes={
 {"VOID",{0,0,0},{136,72,218}}, {"Joker",{53,3,255},{2,153,57}},
 {"Mario",{220,20,20},{20,60,220}}, {"Luigi",{2,153,57},{20,60,220}},
 {"Peach",{247,136,206},{255,249,122}}, {"YouTube",{0,0,0},{255,0,0}},
 {"Spotify",{0,0,0},{30,215,96}}, {"TikTok",{0,0,0},{255,255,255}},
}
local weapons={
 {"Pistol","WEAPON_PISTOL"},{"Combat Pistol","WEAPON_COMBATPISTOL"},
 {"AP Pistol","WEAPON_APPISTOL"},{"Heavy Pistol","WEAPON_HEAVYPISTOL"},
 {"Micro SMG","WEAPON_MICROSMG"},{"SMG","WEAPON_SMG"},
 {"Assault Rifle","WEAPON_ASSAULTRIFLE"},{"Carbine Rifle","WEAPON_CARBINERIFLE"},
 {"Advanced Rifle","WEAPON_ADVANCEDRIFLE"},{"Combat MG","WEAPON_COMBATMG"},
 {"Pump Shotgun","WEAPON_PUMPSHOTGUN"},{"Assault Shotgun","WEAPON_ASSAULTSHOTGUN"},
 {"Sniper Rifle","WEAPON_SNIPERRIFLE"},{"Heavy Sniper","WEAPON_HEAVYSNIPER"},
 {"RPG","WEAPON_RPG"},{"Homing Launcher","WEAPON_HOMINGLAUNCHER"},
 {"Minigun","WEAPON_MINIGUN"},{"Stun Gun","WEAPON_STUNGUN"},
}
local auto_logger=false
local log_buffer="VOID action logger\n"
local function report(label,err)
 local line=label..": "..tostring(err);util.log(line)
 if auto_logger then
  if #log_buffer>48000 then log_buffer="VOID action logger (rotated)\n"end
  log_buffer=log_buffer..string.format("[%d] %s\n",util.time_ms(),line)
  if not files.write("actions.log",log_buffer)then util.log("VOID logger could not save actions.log")end
 end
end
local function safe(label,fn)
 return function(...)
  local ok,err=pcall(fn,...)
  if not ok then report(label,err)elseif auto_logger then report(label,"callback completed; in-game effect unverified")end
 end
end
local function action(label,fn,parent)menu.action(label,safe(label,fn),parent)end
local function car()
 local v=Native.GET_VEHICLE_PED_IS_IN(players.local_ped(),false)
 if v==0 then util.log("Vehicle action skipped: enter a vehicle first");return nil end
 return v
end
local function car_action(label,fn,parent)
 action(label,function()local v=car();if v then fn(v)end end,parent)
end
local function toggle(label,key,parent,apply)
 menu.toggle(label,function(on)
  -- Commit the script flag only after a successful native call.
  if apply then apply(on)end
  flags[key]=on
 end,parent)
end
local function paint(v,a,b)
 Native.SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(v,a[1],a[2],a[3])
 Native.SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(v,b[1],b[2],b[3])
 Native.TOGGLE_VEHICLE_MOD(v,20,true)
 Native.SET_VEHICLE_TYRE_SMOKE_COLOR(v,b[1],b[2],b[3])
 Native.SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(v,5)
 Native.SET_VEHICLE_NUMBER_PLATE_TEXT(v,"VOID")
end
local function max_car(v)
 Native.SET_VEHICLE_MOD_KIT(v,0)
 for slot=0,49 do
  local n=Native.GET_NUM_VEHICLE_MODS(v,slot)
  if n>0 then Native.SET_VEHICLE_MOD(v,slot,n-1,false)end
 end
 Native.TOGGLE_VEHICLE_MOD(v,18,true)
 Native.SET_VEHICLE_TYRES_CAN_BURST(v,false)
 paint(v,{0,0,0},{136,72,218})
end
local function position()
 local e=players.local_entity()
 local x,y,z=entity.get_coords(e)
 return {x,y,z,Native.GET_ENTITY_HEADING(e)}
end
local function valid(p)
 if type(p)~="table" then return false end
 for i=1,4 do
  if type(p[i])~="number" or p[i]~=p[i] or math.abs(p[i])>30000 then return false end
 end
 return true
end
local function travel(p)
 assert(valid(p),"invalid saved position")
 local e=players.local_entity();local before=position()
 entity.set_coords(e,p[1],p[2],p[3]);Native.SET_ENTITY_HEADING(e,p[4])
 previous=before -- Last requested origin; this script does not claim arrival.
end
local function nudge(dx,dy,dz)
 local e=players.local_entity();local x,y,z=entity.get_offset(e,dx,dy,dz)
 travel({x,y,z,Native.GET_ENTITY_HEADING(e)})
end
local function vision_set(mode)
 Native.SET_NIGHTVISION(mode=="night")
 Native.SET_SEETHROUGH(mode=="thermal")
 vision=mode
end
local function extra_features(player,cars,settings)
 action("Clean Blood and Damage",function()local p=players.local_ped();Native.CLEAR_PED_BLOOD_DAMAGE(p);Native.RESET_PED_VISIBLE_DAMAGE(p)end,player)
 action("Dry Player",function()Native.CLEAR_PED_WETNESS(players.local_ped())end,player)
 car_action("Clean Vehicle",function(v)Native.SET_VEHICLE_DIRT_LEVEL(v,0.0)end,cars)
 car_action("Place Vehicle on Ground",function(v)Native.SET_VEHICLE_ON_GROUND_PROPERLY(v,5.0)end,cars)
 car_action("Vehicle Invincible ON",function(v)Native.SET_ENTITY_INVINCIBLE(v,true)end,cars)
 car_action("Vehicle Invincible OFF",function(v)Native.SET_ENTITY_INVINCIBLE(v,false)end,cars)
 car_action("Repair All Tires",function(v)for _,i in ipairs({0,1,2,3,4,5,45,47})do Native.SET_VEHICLE_TYRE_FIXED(v,i)end end,cars)
 local doors=menu.submenu("Doors",cars)
 for i=0,5 do local door=i;car_action("Open Door "..i,function(v)Native.SET_VEHICLE_DOOR_OPEN(v,door,false,false)end,doors)end
 car_action("Close All Doors",function(v)for i=0,5 do Native.SET_VEHICLE_DOOR_SHUT(v,i,false)end end,doors)
 car_action("Lock Vehicle",function(v)Native.SET_VEHICLE_DOORS_LOCKED(v,2)end,doors)
 car_action("Unlock Vehicle",function(v)Native.SET_VEHICLE_DOORS_LOCKED(v,1)end,doors)
 local scene_root=menu.submenu("Local Scene Spawner")
 for _,category in ipairs({{"Vehicles","vehicle",{"adder","zentorno","sultan","bati"}},{"Peds","ped",{"s_m_y_cop_01","ig_lamardavis","a_c_husky"}},{"Objects","object",{"prop_roadcone02a","prop_barrier_work05","prop_beachball_02"}}})do
  local parent=menu.submenu(category[1],scene_root)
  for _,model in ipairs(category[3])do local kind,name=category[2],model;action(name,function()local x,y,z=entity.get_coords(players.local_ped());scene.request(kind,name,x,y+5,z,0)end,parent)end
 end
 action("Clear This Script's Spawned Entities",scene.clear,scene_root)
 menu.toggle("Auto Logger",function(on)auto_logger=on;if on then report("Logger","enabled")end end,settings)
 action("Save Current Toggle Configuration",function()
  local rows={"VOID_CONFIG1"};for k,v in pairs(flags)do rows[#rows+1]=k.."="..tostring(v)end;rows[#rows+1]="vision="..vision
  assert(files.write("settings.txt",table.concat(rows,"\n").."\n"),"configuration save failed")
 end,settings)
 action("Log Current Toggle Configuration",function()for k,v in pairs(flags)do util.log(k.."="..tostring(v))end end,settings)
end
function onLoad()
 local player=menu.submenu("Player")
 action("Restore Health",players.restore_health,player)
 action("Restore Armor",players.restore_armor,player)
 action("Clear Wanted Level",function()Native.CLEAR_PLAYER_WANTED_LEVEL(Native.PLAYER_ID())end,player)
 toggle("God Mode","god",player,function(on)Native.SET_ENTITY_INVINCIBLE(players.local_ped(),on)end)
 toggle("Invisible","invisible",player,function(on)Native.SET_ENTITY_VISIBLE(players.local_ped(),not on,false)end)
 toggle("No Ragdoll","ragdoll",player,function(on)Native.SET_PED_CAN_RAGDOLL(players.local_ped(),not on)end)
 toggle("Auto Restore Health","regen",player)
 toggle("Police Ignore Player","police",player,function(on)Native.SET_POLICE_IGNORE_PLAYER(Native.PLAYER_ID(),on)end)
 toggle("NPCs Ignore Player","npcs",player,function(on)Native.SET_EVERYONE_IGNORE_PLAYER(Native.PLAYER_ID(),on)end)
 toggle("Fast Run 1.49x","run",player,function(on)Native.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(Native.PLAYER_ID(),on and 1.49 or 1.0)end)
 toggle("Fast Swim 1.49x","swim",player,function(on)Native.SET_SWIM_MULTIPLIER_FOR_PLAYER(Native.PLAYER_ID(),on and 1.49 or 1.0)end)
 toggle("Super Jump","jump",player)
 toggle("Explosive Melee","melee",player)
 local view=menu.submenu("Vision")
 action("Night Vision",function()vision_set("night")end,view)
 action("Thermal Vision",function()vision_set("thermal")end,view)
 action("Disable Both Vision Effects",function()vision_set("off")end,view)
 local cars=menu.submenu("Vehicle")
 car_action("Repair",function(v)Native.SET_VEHICLE_FIXED(v)end,cars)
 toggle("Auto Repair Current Vehicle","repair",cars)
 toggle("Keep Current Engine Running","engine",cars)
 car_action("Max Upgrades + VOID Preset",max_car,cars)
 car_action("Stop Vehicle",function(v)Native.SET_VEHICLE_FORWARD_SPEED(v,0)end,cars)
 for _,speed in ipairs({30,60,100,150})do
  local kmh=speed
  car_action("Set Forward Speed: "..kmh.." km/h",function(v)Native.SET_VEHICLE_FORWARD_SPEED(v,kmh/3.6)end,cars)
 end
 car_action("Engine ON",function(v)Native.SET_VEHICLE_ENGINE_ON(v,true,true,false)end,cars)
 car_action("Engine OFF",function(v)Native.SET_VEHICLE_ENGINE_ON(v,false,true,false)end,cars)
 car_action("Enable Reduced Grip",function(v)Native.SET_VEHICLE_REDUCE_GRIP(v,true)end,cars)
 car_action("Restore Normal Grip",function(v)Native.SET_VEHICLE_REDUCE_GRIP(v,false)end,cars)
 car_action("Bulletproof Tires",function(v)Native.SET_VEHICLE_TYRES_CAN_BURST(v,false)end,cars)
 car_action("Normal Tires",function(v)Native.SET_VEHICLE_TYRES_CAN_BURST(v,true)end,cars)
 local lights=menu.submenu("Lights / Indicators",cars)
 car_action("Headlights Automatic",function(v)Native.SET_VEHICLE_LIGHTS(v,0)end,lights)
 car_action("Headlights ON",function(v)Native.SET_VEHICLE_LIGHTS(v,2)end,lights)
 car_action("Headlights OFF",function(v)Native.SET_VEHICLE_LIGHTS(v,1)end,lights)
 car_action("Hazards ON",function(v)for i=0,1 do Native.SET_VEHICLE_INDICATOR_LIGHTS(v,i,true)end end,lights)
 car_action("Hazards OFF",function(v)for i=0,1 do Native.SET_VEHICLE_INDICATOR_LIGHTS(v,i,false)end end,lights)
 local presets=menu.submenu("Modded Paint Presets",cars)
 for _,entry in ipairs(colors)do
  local c=entry
  car_action(c[1],function(v)paint(v,{c[2],c[3],c[4]},{c[2],c[3],c[4]})end,presets)
 end
 local theme=menu.submenu("Two-Tone Paint Themes",cars)
 for _,entry in ipairs(themes)do local c=entry;car_action(c[1],function(v)paint(v,c[2],c[3])end,theme)end
 local guns=menu.submenu("Weapons")
 action("Give Standard Loadout",function()
  local p=players.local_ped()
  for _,w in ipairs(weapons)do Native.GIVE_WEAPON_TO_PED(p,Native.GET_HASH_KEY(w[2]),9999,false,false)end
 end,guns)
 toggle("Infinite Clip","clip",guns,function(on)Native.SET_PED_INFINITE_AMMO_CLIP(players.local_ped(),on)end)
 toggle("Infinite Ammo - Selected Weapon","ammo",guns)
 local give=menu.submenu("Give Weapon",guns)
 for _,entry in ipairs(weapons)do local w=entry;action(w[1],function()Native.GIVE_WEAPON_TO_PED(players.local_ped(),Native.GET_HASH_KEY(w[2]),9999,false,false)end,give)end
 local tint=menu.submenu("Current Weapon Tint",guns)
 for i=0,7 do local index=i;action("Tint "..i,function()Native.SET_PED_WEAPON_TINT_INDEX(players.local_ped(),Native.GET_SELECTED_PED_WEAPON(players.local_ped()),index)end,tint)end
 local tele=menu.submenu("Teleport Utilities")
 for _,d in ipairs({{"Up 10m",0,0,10},{"Up 50m",0,0,50},{"Down 5m",0,0,-5},{"Forward 5m",0,5,0},{"Backward 5m",0,-5,0},{"Left 5m",-5,0,0},{"Right 5m",5,0,0}})do
  local c=d;action(c[1],function()nudge(c[2],c[3],c[4])end,tele)
 end
 action("Return to Previous Origin",function()assert(previous,"no previous teleport origin");travel(previous)end,tele)
 action("Log Current Coordinates",function()local p=position();util.log(string.format("Position: %.3f, %.3f, %.3f | heading %.2f",p[1],p[2],p[3],p[4]))end,tele)
 local bookmarks=menu.submenu("Saved Locations",tele)
 for i=1,8 do
  local slot=i;local parent=menu.submenu("Location "..i,bookmarks);local filename="location_"..i..".txt"
  action("Save Current Position",function()
   local p=position();assert(valid(p),"invalid current position")
   assert(files.write(filename,string.format("%.6f,%.6f,%.6f,%.6f",p[1],p[2],p[3],p[4])),"location save failed")
   util.log("Saved Location "..slot)
  end,parent)
  action("Load Saved Position",function()
   local data=files.read(filename);assert(data,"location is empty")
   local a,b,c,d=data:match("^([^,]+),([^,]+),([^,]+),([^,]+)$")
   travel({tonumber(a),tonumber(b),tonumber(c),tonumber(d)})
  end,parent)
 end
 local animations=menu.submenu("Animations")
 local anims={{"Salute","anim@mp_player_intincarsalutestd@ds@","idle_a"},
  {"Air Guitar","anim@mp_player_intcelebrationmale@air_guitar","air_guitar"},
  {"Wave","friends@frj@ig_1","wave_a"},{"Yoga","amb@world_human_yoga@male@base","base_a"}}
 for _,entry in ipairs(anims)do local a=entry;action(a[1],function()Native.REQUEST_ANIM_DICT(a[2]);pending_anim={dict=a[2],clip=a[3],started=util.time_ms()}end,animations)end
 action("Stop Animation",function()pending_anim=nil;Native.CLEAR_PED_TASKS(players.local_ped())end,animations)
 local settings=menu.submenu("Settings")
 toggle("Mobile Radio","radio",settings,function(on)Native.SET_MOBILE_RADIO_ENABLED_DURING_GAMEPLAY(on)end)
 action("Log Script Version",function()util.log("VOID 0.5 | PS4 API 2 | local utilities; no money features")end,settings)
 extra_features(player,cars,settings)
 util.log("VOID 0.5 loaded; all script toggles start OFF")
end
function onFrame()
 local ped=players.local_ped()
 if not Native.DOES_ENTITY_EXIST(ped) or Native.IS_ENTITY_DEAD(ped,0)then return end
 local player=Native.PLAYER_ID()
 if flags.god then Native.SET_ENTITY_INVINCIBLE(ped,true)end
 if flags.invisible then Native.SET_ENTITY_VISIBLE(ped,false,false)end
 if flags.ragdoll then Native.SET_PED_CAN_RAGDOLL(ped,false)end
 if flags.jump then Native.SET_SUPER_JUMP_THIS_FRAME(player)end
 if flags.melee then Native.SET_EXPLOSIVE_MELEE_THIS_FRAME(player)end
 if flags.run then Native.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(player,1.49)end
 if flags.swim then Native.SET_SWIM_MULTIPLIER_FOR_PLAYER(player,1.49)end
 if flags.police then Native.SET_POLICE_IGNORE_PLAYER(player,true)end
 if flags.npcs then Native.SET_EVERYONE_IGNORE_PLAYER(player,true)end
 local now=util.time_ms()
 if now-last_period>=1000 then
  last_period=now
  if flags.regen and Native.GET_ENTITY_HEALTH(ped)<Native.GET_ENTITY_MAX_HEALTH(ped)then players.restore_health()end
  local v=Native.GET_VEHICLE_PED_IS_IN(ped,false)
  if v~=0 then
   if flags.repair then Native.SET_VEHICLE_FIXED(v)end
   if flags.engine then Native.SET_VEHICLE_ENGINE_ON(v,true,true,false)end
  end
 end
 if flags.ammo then
  local w=Native.GET_SELECTED_PED_WEAPON(ped)
  if last_ammo~=0 and last_ammo~=w then Native.SET_PED_INFINITE_AMMO(ped,false,last_ammo);last_ammo=0 end
  if w~=0 and w~=0xA2719263 then Native.SET_PED_INFINITE_AMMO(ped,true,w);last_ammo=w end
 elseif last_ammo~=0 then Native.SET_PED_INFINITE_AMMO(ped,false,last_ammo);last_ammo=0 end
 if pending_anim then
  local a=pending_anim
  if Native.HAS_ANIM_DICT_LOADED(a.dict)then
   Native.TASK_PLAY_ANIM(ped,a.dict,a.clip,8.0,-8.0,-1,1,1.0,false,false,false);pending_anim=nil
  elseif now-a.started>5000 then util.log("Animation streaming timed out: "..a.dict);pending_anim=nil end
 end
end
function onUnload()
 local p=players.local_ped();local id=Native.PLAYER_ID()
 -- Do not modify detached/previous vehicles; their action-based edits are intentional.
 local function undo(name,fn)if flags[name]then safe("cleanup "..name,fn)()end end
 undo("god",function()Native.SET_ENTITY_INVINCIBLE(p,false)end)
 undo("invisible",function()Native.SET_ENTITY_VISIBLE(p,true,false)end)
 undo("ragdoll",function()Native.SET_PED_CAN_RAGDOLL(p,true)end)
 undo("police",function()Native.SET_POLICE_IGNORE_PLAYER(id,false)end)
 undo("npcs",function()Native.SET_EVERYONE_IGNORE_PLAYER(id,false)end)
 undo("run",function()Native.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(id,1.0)end)
 undo("swim",function()Native.SET_SWIM_MULTIPLIER_FOR_PLAYER(id,1.0)end)
 undo("clip",function()Native.SET_PED_INFINITE_AMMO_CLIP(p,false)end)
 if last_ammo~=0 then safe("cleanup ammo",function()Native.SET_PED_INFINITE_AMMO(p,false,last_ammo)end)()end
 if vision~="off" then safe("cleanup vision",function()vision_set("off")end)()end
 undo("radio",function()Native.SET_MOBILE_RADIO_ENABLED_DURING_GAMEPLAY(false)end)
 pending_anim=nil
 util.log("VOID 0.5 stopped; script-controlled player toggles reset")
end
