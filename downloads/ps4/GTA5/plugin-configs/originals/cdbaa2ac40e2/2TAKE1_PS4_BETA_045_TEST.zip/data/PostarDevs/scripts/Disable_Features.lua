-- PS4 remake of compatible local options in disable.enablestuff.lua.
-- Remote vehicle removal and unsupported monetization patches are omitted.
local recording, cutscenes = false, false
function onLoad()
    menu.toggle("Disable Game Recording", function(value) recording = value end)
    menu.toggle("Skip Cutscenes", function(value) cutscenes = value end)
end
function onFrame()
    if recording then Native.CANCEL_REPLAY_RECORDING() end
    if cutscenes and Native.IS_CUTSCENE_PLAYING() then
        Native.STOP_CUTSCENE_IMMEDIATELY()
    end
end
