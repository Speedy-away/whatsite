-- PS4 remake of the saved-location functionality in CrustyTeleporter.lua.
-- Replaces Windows APPDATA, io, os.time and keyboard input with scoped files
-- and automatic location names. Entries are external script data, not PRX code.
local points = {}
local function save()
    local lines = {}
    for i, p in ipairs(points) do
        lines[i] = string.format("%.6f,%.6f,%.6f", p[1], p[2], p[3])
    end
    assert(files.write("locations.txt", table.concat(lines, "\n")), "could not save locations")
end
local function add_button(i)
    local p = points[i]
    menu.action("Location " .. i, function()
        entity.set_coords(players.local_entity(), p[1], p[2], p[3])
    end)
end
function onLoad()
    local data = files.read("locations.txt") or ""
    for line in data:gmatch("[^\r\n]+") do
        local a,b,c = line:match("^([%d%.%-]+),([%d%.%-]+),([%d%.%-]+)$")
        a,b,c = tonumber(a),tonumber(b),tonumber(c)
        if a and b and c and math.abs(a)<30000 and math.abs(b)<30000 and math.abs(c)<30000 and #points<64 then
            points[#points+1]={a,b,c}
        end
    end
    menu.action("Save Current Location", function()
        assert(#points<64, "64 saved locations maximum")
        local x,y,z=entity.get_coords(players.local_entity())
        points[#points+1]={x,y,z}
        save()
        add_button(#points)
        util.toast("Teleport", "Saved Location "..#points)
    end)
    for i=1,#points do add_button(i) end
end
