-- Original PS4 bridge implementation inspired by the credited upstream project.
-- No PC-native crossmaps, player attacks, IP collection, award/XP writes or auto-updater.
local jobs={}
local function log(s)util.log(s)end
local function safe(label,fn)return function(...)local ok,err=pcall(fn,...);if not ok then log(label..": "..tostring(err))end end end
local function action(label,fn,parent)return menu.action(label,safe(label,fn),parent)end
local function require_api()assert(scene and Velora.API_VERSION and Velora.API_VERSION>=2,"Install the API2 PS4 PRX supplied with these remakes")end
local function car()local v=Native.GET_VEHICLE_PED_IS_IN(players.local_ped(),false);if v==0 then log("Enter a vehicle first");return nil end;return v end
local function car_action(label,fn,parent)return action(label,function()local v=car();if v then fn(v)end end,parent)end
local function spawn(kind,model,x,y,z,fn)
 local p=players.local_entity();local a,b,c=entity.get_offset(p,x,y,z)
 local ticket=scene.request(kind,model,a,b,c,Native.GET_ENTITY_HEADING(p))
 jobs[ticket]=fn or false
 return ticket
end
local function pump()
 local pending={};for ticket in pairs(jobs)do pending[#pending+1]=ticket end
 for _,ticket in ipairs(pending)do local fn=jobs[ticket]
  if fn~=nil then local status,handle=scene.status(ticket)
  if status=="ready"then jobs[ticket]=nil;if fn then safe("spawn callback",fn)(handle,ticket)end
  elseif status~="pending"then jobs[ticket]=nil;scene.delete(ticket);log("Model request failed or timed out")end end
 end
end
local function clear()jobs={};scene.clear()end
local function max_car(v,performance)
 Native.SET_VEHICLE_MOD_KIT(v,0)
 local slots=performance and {11,12,13,15,16} or nil
 if slots then for _,slot in ipairs(slots)do local n=Native.GET_NUM_VEHICLE_MODS(v,slot);if n>0 then Native.SET_VEHICLE_MOD(v,slot,n-1,false)end end
 else for slot=0,49 do local n=Native.GET_NUM_VEHICLE_MODS(v,slot);if n>0 then Native.SET_VEHICLE_MOD(v,slot,n-1,false)end end end
 Native.TOGGLE_VEHICLE_MOD(v,18,true)
end

-- Ultimate PS4 Local: NPC/vehicle scene builder and categorized weapons.
-- Upstream: Aurelian Spodarec, https://github.com/AurelianSpodarec/GTA_UltimateMenu (MIT).
-- Player-directed attacks and spoof/IP features are intentionally absent.
local actors={};local god=false;local armed=false
local function actor(model,dx,dy,seat_car,seat_index)
 return spawn("ped",model,dx,dy,0,function(handle,ticket)
  actors[#actors+1]=ticket
  if god then Native.SET_ENTITY_INVINCIBLE(handle,true)end
  if armed then Native.GIVE_WEAPON_TO_PED(handle,Native.GET_HASH_KEY("WEAPON_PISTOL"),250,false,true)end
  if seat_car then scene.seat(ticket,seat_car,seat_index)else scene.follow(ticket)end
 end)
end
local function crew(vehicle,model)
 spawn("vehicle",vehicle,0,10,1,function(_,ticket)
  actor(model,-2,7,ticket,-1);actor(model,2,7,ticket,0)
 end)
end
local function each_actor(fn)
 for _,ticket in ipairs(actors)do local status,handle=scene.status(ticket);if status=="ready"then safe("actor action",fn)(ticket,handle)end end
end
function onLoad()
 require_api()
 local cast=menu.submenu("Pedestrian Scene Builder")
 for _,category in ipairs({{"Police / SWAT",{"s_m_y_cop_01","s_m_y_swat_01"}},{"Emergency Crew",{"s_m_y_fireman_01","s_m_m_paramedic_01"}},{"Story Actors",{"player_zero","player_one","player_two","ig_lamardavis","ig_lestercrest"}},{"Companions",{"s_m_y_blackops_01","s_m_y_blackops_02"}}})do
  local group=menu.submenu(category[1],cast)
  for _,model in ipairs(category[2])do local name=model;action(name,function()actor(name,2,3)end,group)end
 end
 local options=menu.submenu("Created Ped Options",cast)
 menu.toggle("Created Ped God Mode",function(on)god=on;each_actor(function(_,handle)Native.SET_ENTITY_INVINCIBLE(handle,on)end)end,options)
 menu.toggle("Arm Newly Created Peds",function(on)armed=on end,options)
 action("Regroup Created Peds",function()each_actor(function(ticket)scene.follow(ticket)end)end,options)
 action("Give Created Peds a Pistol",function()each_actor(function(_,handle)Native.GIVE_WEAPON_TO_PED(handle,Native.GET_HASH_KEY("WEAPON_PISTOL"),250,false,true)end)end,options)
 local display=menu.submenu("Local Vehicle / Crew Scenes")
 action("Police Cruiser Display",function()crew("police","s_m_y_cop_01")end,display)
 action("Fire Crew Display",function()crew("firetruk","s_m_y_fireman_01")end,display)
 action("Ambulance Crew Display",function()crew("ambulance","s_m_m_paramedic_01")end,display)
 action("SWAT Van Display",function()crew("riot","s_m_y_swat_01")end,display)
 local guns=menu.submenu("Weapons - Local Player")
 local melee=menu.submenu("Melee",guns);local pistols=menu.submenu("Handguns",guns)
 action("Antique Cavalry Dagger",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_DAGGER");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Baseball Ball",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_BAT");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Broken Bottle",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_BOTTLE");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Crowbar",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_CROWBAR");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Flashlight",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_FLASHLIGHT");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Golf Club",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_GOLFCLUB");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Hammer",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_HAMMER");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Hatchet",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_HATCHET");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Brass Knuckles",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_KNUCKLE");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Knife",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_KNIFE");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Machete",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_MACHETE");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Switchblade",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_SWITCHBLADE");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Nightstick",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_NIGHTSTICK");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Pipe Wrench",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_WRENCH");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Battle Axe",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_BATTLEAXE");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Pool Cue",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_POOLCUE");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Stone Hatchet",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_STONE_HATCHET");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,melee)
 action("Pistol",function()local p=players.local_ped();local h=Native.GET_HASH_KEY("WEAPON_PISTOL");Native.GIVE_WEAPON_TO_PED(p,h,9999,false,false);if not Native.HAS_PED_GOT_WEAPON(p,h,false)then log("Weapon unavailable on this game build")end end,pistols)
 action("Clear This Script's Scene",function()clear();actors={}end)
 log("Ultimate PS4 Local loaded; scenes are local displays, not emergency-service dispatch or player attacks")
end
function onFrame()pump()end
function onUnload()clear();actors={}end
