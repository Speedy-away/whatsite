-- Original PS4 bridge implementation inspired by the credited upstream project.
-- No PC-native crossmaps, player attacks, IP collection, award/XP writes or auto-updater.
local jobs={}
local function log(s)util.log(s)end
local function safe(label,fn)return function(...)local ok,err=pcall(fn,...);if not ok then log(label..": "..tostring(err))end end end
local function action(label,fn,parent)return menu.action(label,safe(label,fn),parent)end
local function require_api()assert(scene and Velora.API_VERSION and Velora.API_VERSION>=2,"Install the API2 PS4 PRX supplied with these remakes")end
local function car()local v=Native.GET_VEHICLE_PED_IS_IN(players.local_ped(),false);if v==0 then log("Enter a vehicle first");return nil end;return v end
local function car_action(label,fn,parent)return action(label,function()local v=car();if v then fn(v)end end,parent)end
local function spawn(kind,model,x,y,z,fn)
 local p=players.local_entity();local a,b,c=entity.get_offset(p,x,y,z)
 local ticket=scene.request(kind,model,a,b,c,Native.GET_ENTITY_HEADING(p))
 jobs[ticket]=fn or false
 return ticket
end
local function pump()
 local pending={};for ticket in pairs(jobs)do pending[#pending+1]=ticket end
 for _,ticket in ipairs(pending)do local fn=jobs[ticket]
  if fn~=nil then local status,handle=scene.status(ticket)
  if status=="ready"then jobs[ticket]=nil;if fn then safe("spawn callback",fn)(handle,ticket)end
  elseif status~="pending"then jobs[ticket]=nil;scene.delete(ticket);log("Model request failed or timed out")end end
 end
end
local function clear()jobs={};scene.clear()end
local function max_car(v,performance)
 Native.SET_VEHICLE_MOD_KIT(v,0)
 local slots=performance and {11,12,13,15,16} or nil
 if slots then for _,slot in ipairs(slots)do local n=Native.GET_NUM_VEHICLE_MODS(v,slot);if n>0 then Native.SET_VEHICLE_MOD(v,slot,n-1,false)end end
 else for slot=0,49 do local n=Native.GET_NUM_VEHICLE_MODS(v,slot);if n>0 then Native.SET_VEHICLE_MOD(v,slot,n-1,false)end end end
 Native.TOGGLE_VEHICLE_MOD(v,18,true)
end

-- Moist PS4 Local: original remake of documented local utilities.
-- Upstream: https://github.com/IN2-Moist/2Take1-Moist-Script
-- Distributed upstream modules are compiled; no bytecode is redistributed here.
local boost=false;local boost_speed=35;local last_boost=-1000;local quick_repair=false;local last_repair=-1000
function onLoad()
 require_api()
 local cars=menu.submenu("Vehicle Utilities")
 menu.toggle("Horn Boost (R3)",function(on)boost=on end,cars)
 action("Boost Speed: 90 km/h",function()boost_speed=25 end,cars)
 action("Boost Speed: 126 km/h",function()boost_speed=35 end,cars)
 action("Boost Speed: 180 km/h",function()boost_speed=50 end,cars)
 menu.toggle("Automatic Vehicle Repair",function(on)quick_repair=on end,cars)
 car_action("Make Current Vehicle Invincible",function(v)Native.SET_ENTITY_INVINCIBLE(v,true)end,cars)
 car_action("Restore Current Vehicle Damage",function(v)Native.SET_ENTITY_INVINCIBLE(v,false)end,cars)
 car_action("Stop Current Vehicle",function(v)Native.SET_VEHICLE_FORWARD_SPEED(v,0)end,cars)
 car_action("Performance Upgrades",function(v)max_car(v,true)end,cars)
 local lights=menu.submenu("Vehicle Lights",cars)
 car_action("Headlights ON",function(v)Native.SET_VEHICLE_LIGHTS(v,2)end,lights)
 car_action("Headlights Automatic",function(v)Native.SET_VEHICLE_LIGHTS(v,0)end,lights)
 car_action("Hazards ON",function(v)for i=0,1 do Native.SET_VEHICLE_INDICATOR_LIGHTS(v,i,true)end end,lights)
 car_action("Hazards OFF",function(v)for i=0,1 do Native.SET_VEHICLE_INDICATOR_LIGHTS(v,i,false)end end,lights)
 local rescue=menu.submenu("Local Rescue Vehicles")
 for _,model in ipairs({"dinghy","buzzard","ambulance","firetruk"})do local name=model;action(name,function()spawn("vehicle",name,0,8,1,function(_,ticket)scene.enter(ticket,-1)end)end,rescue)end
 local player=menu.submenu("Player Utilities")
 action("Restore Health",players.restore_health,player);action("Restore Armor",players.restore_armor,player)
 action("Clear Wanted Level",function()Native.CLEAR_PLAYER_WANTED_LEVEL(Native.PLAYER_ID())end,player)
 action("Give Pistol / SMG / Rifle",function()local p=players.local_ped();for _,n in ipairs({"WEAPON_PISTOL","WEAPON_SMG","WEAPON_ASSAULTRIFLE"})do Native.GIVE_WEAPON_TO_PED(p,Native.GET_HASH_KEY(n),9999,false,false)end end,player)
 local animation=menu.submenu("Animation Utilities")
 action("Stop My Animation",function()Native.CLEAR_PED_TASKS(players.local_ped())end,animation)
 action("Clear This Script's Spawned Entities",clear)
 log("Moist PS4 Local loaded; boost and automatic repair OFF")
end
function onFrame()
 pump();local v=Native.GET_VEHICLE_PED_IS_IN(players.local_ped(),false);if v==0 then return end
 local now=util.time_ms()
 if boost and Native.IS_CONTROL_PRESSED(0,86)and now-last_boost>=500 then last_boost=now;Native.SET_VEHICLE_FORWARD_SPEED(v,boost_speed)end
 if quick_repair and now-last_repair>=1000 then last_repair=now;Native.SET_VEHICLE_FIXED(v)end
end
function onUnload()clear()end
