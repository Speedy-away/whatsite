-- Original PS4 bridge implementation inspired by the credited upstream project.
-- No PC-native crossmaps, player attacks, IP collection, award/XP writes or auto-updater.
local jobs={}
local function log(s)util.log(s)end
local function safe(label,fn)return function(...)local ok,err=pcall(fn,...);if not ok then log(label..": "..tostring(err))end end end
local function action(label,fn,parent)return menu.action(label,safe(label,fn),parent)end
local function require_api()assert(scene and Velora.API_VERSION and Velora.API_VERSION>=2,"Install the API2 PS4 PRX supplied with these remakes")end
local function car()local v=Native.GET_VEHICLE_PED_IS_IN(players.local_ped(),false);if v==0 then log("Enter a vehicle first");return nil end;return v end
local function car_action(label,fn,parent)return action(label,function()local v=car();if v then fn(v)end end,parent)end
local function spawn(kind,model,x,y,z,fn)
 local p=players.local_entity();local a,b,c=entity.get_offset(p,x,y,z)
 local ticket=scene.request(kind,model,a,b,c,Native.GET_ENTITY_HEADING(p))
 jobs[ticket]=fn or false
 return ticket
end
local function pump()
 local pending={};for ticket in pairs(jobs)do pending[#pending+1]=ticket end
 for _,ticket in ipairs(pending)do local fn=jobs[ticket]
  if fn~=nil then local status,handle=scene.status(ticket)
  if status=="ready"then jobs[ticket]=nil;if fn then safe("spawn callback",fn)(handle,ticket)end
  elseif status~="pending"then jobs[ticket]=nil;scene.delete(ticket);log("Model request failed or timed out")end end
 end
end
local function clear()jobs={};scene.clear()end
local function max_car(v,performance)
 Native.SET_VEHICLE_MOD_KIT(v,0)
 local slots=performance and {11,12,13,15,16} or nil
 if slots then for _,slot in ipairs(slots)do local n=Native.GET_NUM_VEHICLE_MODS(v,slot);if n>0 then Native.SET_VEHICLE_MOD(v,slot,n-1,false)end end
 else for slot=0,49 do local n=Native.GET_NUM_VEHICLE_MODS(v,slot);if n>0 then Native.SET_VEHICLE_MOD(v,slot,n-1,false)end end end
 Native.TOGGLE_VEHICLE_MOD(v,18,true)
end

-- Keks PS4 Local: supported local-feature remake; not the full original menu.
-- Upstream: https://github.com/kektram/Keks-menu (Kektram, GPL-3.0).
local flying=false;local cycling=false;local last_color=-1000;local flight_speed=15
local function rgb(v,r,g,b)Native.SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(v,r,g,b);Native.SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(v,r,g,b)end
function onLoad()
 require_api()
 local cars=menu.submenu("Vehicle Options")
 car_action("Performance Upgrades",function(v)max_car(v,true)end,cars)
 car_action("All Available Upgrades",function(v)max_car(v,false)end,cars)
 menu.toggle("Vehicle Flight - Left Stick / R2 / L2",function(on)flying=on end,cars)
 action("Flight Speed: Slow",function()flight_speed=8 end,cars)
 action("Flight Speed: Medium",function()flight_speed=15 end,cars)
 action("Flight Speed: Fast",function()flight_speed=30 end,cars)
 menu.toggle("Cycling Vehicle Colors",function(on)cycling=on end,cars)
 car_action("VOID Black / Purple",function(v)Native.SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(v,0,0,0);Native.SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(v,136,72,218)end,cars)
 car_action("Repair Current Vehicle",function(v)Native.SET_VEHICLE_FIXED(v)end,cars)
 local vehicles=menu.submenu("Vehicle Spawner")
 for _,model in ipairs({"adder","t20","zentorno","sultanrs","kuruma2","deluxo","toreador","oppressor2"})do local name=model;action(name,function()spawn("vehicle",name,0,6,1,function(handle,ticket)max_car(handle,true);scene.enter(ticket,-1)end)end,vehicles)end
 local peds=menu.submenu("Local Companions")
 for _,model in ipairs({"s_m_y_blackops_01","s_m_y_swat_01","ig_lamardavis"})do local name=model;action(name,function()spawn("ped",name,2,3,0,function(handle,ticket)scene.follow(ticket)end)end,peds)end
 local props=menu.submenu("Object Placement")
 for _,model in ipairs({"prop_mp_ramp_03","prop_barrier_work05","prop_roadcone02a","prop_beachball_02"})do local name=model;action(name,function()spawn("object",name,0,7,0)end,props)end
 action("Clear This Script's Spawned Entities",clear)
 log("Keks PS4 Local loaded; flight and color cycling OFF")
end
function onFrame()
 pump();local v=Native.GET_VEHICLE_PED_IS_IN(players.local_ped(),false)
 if v~=0 then
  if flying then
   local a=Native.GET_ENTITY_HEADING(v)*math.pi/180
   local sideways=Native.GET_CONTROL_NORMAL(0,30)*flight_speed
   local forward=-Native.GET_CONTROL_NORMAL(0,31)*flight_speed
   local up=(Native.GET_CONTROL_NORMAL(0,71)-Native.GET_CONTROL_NORMAL(0,72))*flight_speed
   Native.SET_ENTITY_VELOCITY(v,math.cos(a)*sideways-math.sin(a)*forward,math.sin(a)*sideways+math.cos(a)*forward,up)
  end
  local now=util.time_ms();if cycling and now-last_color>=350 then last_color=now;rgb(v,math.floor(127+127*math.sin(now/1000)),math.floor(127+127*math.sin(now/1000+2.1)),math.floor(127+127*math.sin(now/1000+4.2)))end
 end
end
function onUnload()clear()end
