-- Coordinates helper for PS4. Up/Forward teleport actions intentionally removed.
-- Compatible with API1 and API2. No movement or stat changes.
local show=false
local function values()
 local p=players.local_ped();local x,y,z=entity.get_coords(p)
 return x,y,z,Native.GET_ENTITY_HEADING(p)
end
function onLoad()
 menu.toggle("Show Coords",function(on)show=on end)
 menu.action("Log Current Coords",function()
  local x,y,z,h=values()
  util.log(string.format("PRESET COORDS: X=%.4f Y=%.4f Z=%.4f HEADING=%.2f",x,y,z,h))
 end)
end
function onFrame()
 if not show then return end
 local x,y,z,h=values()
 Native.DRAW_RECT(.79,.085,.39,.065,0,0,0,170,0)
 Native.SET_TEXT_FONT(0);Native.SET_TEXT_SCALE(0.0,.33)
 Native.SET_TEXT_COLOUR(255,255,255,255);Native.SET_TEXT_CENTRE(false)
 Native.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
 Native.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(string.format("X %.3f   Y %.3f   Z %.3f~n~Heading %.2f",x,y,z,h))
 Native.END_TEXT_COMMAND_DISPLAY_TEXT(.605,.063,0)
end
function onUnload()show=false end
