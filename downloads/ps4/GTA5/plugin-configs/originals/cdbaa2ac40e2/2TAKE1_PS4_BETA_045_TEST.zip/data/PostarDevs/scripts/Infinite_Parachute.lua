-- PS4 remake of Parachute.lua from 0x2XPx/2Take1-script-Archive.
-- Replaces the PC toggle thread and system.yield with a bounded frame callback.
local enabled, last = false, 0
function onLoad()
    menu.toggle("Infinite Parachute", function(value) enabled = value end)
end
function onFrame()
    local now = util.time_ms()
    if not enabled or now - last < 250 then return end
    last = now
    local ped = players.local_ped()
    local weapon = Native.GET_HASH_KEY("GADGET_PARACHUTE")
    if not Native.HAS_PED_GOT_WEAPON(ped, weapon, false) then
        Native.GIVE_DELAYED_WEAPON_TO_PED(ped, weapon, 1, false)
    end
end
function onUnload() enabled = false end
