-- Heist Editor PS4 1.57. Independent adaptation of the user's PS4 derivative.
-- Workflow reference: jhowkNx/Heist-Control-v2. Not an original PC script port.
-- Named stats only. Supplied presets require console validation; no payout globals.
local VERSION="PS4 0.2 TEST"
local slot_mode=0 -- Auto / MP0 / MP1. No guessed MP0 fallback.
local backups={}
local groups={CAYO={},CASINO={},DOOMSDAY={},TUNER={}}
local report="Idle"
local function slot()
 if slot_mode>0 then return slot_mode-1 end
 return getCharSlot()
end
local function allowed(section,key)return groups[section] and groups[section][key]end
local function read(cs,key)
 local ok,v=pcall(StatGetInt,cs,key)
 if not ok or type(v)~="number" or v%1~=0 or v< -2147483648 or v>2147483647 then return nil end
 return v
end
local function path(section,cs)return "backup_"..section.."_MP"..cs..".txt"end
local function load_backup(section,cs)
 local id=section..cs;if backups[id]then return backups[id]end
 local data=files.read(path(section,cs));local result={}
 if data then
  assert(data:sub(1,14)=="HEIST_BACKUP1\n","invalid backup header")
  for line in data:sub(15):gmatch("[^\r\n]+")do
   local key,value=line:match("^([A-Z0-9_]+)=(-?%d+)$");value=tonumber(value)
   assert(key and allowed(section,key) and value and value%1==0 and value>=-2147483648 and value<=2147483647 and result[key]==nil,"invalid backup record")
   result[key]=value
  end
 end
 backups[id]=result;return result
end
local function save_backup(section,cs,b)
 local keys={};for k in pairs(b)do keys[#keys+1]=k end;table.sort(keys)
 local lines={"HEIST_BACKUP1"};for _,k in ipairs(keys)do lines[#lines+1]=k.."="..b[k]end
 assert(files.write(path(section,cs),table.concat(lines,"\n").."\n"),"backup save failed; no stats written")
end
local function status(message)report=message;util.log("Heist Editor: "..message)end
local function apply(section,batch,restoring)
 assert(players.is_online(),"join an online session first")
 local cs=slot();local original=load_backup(section,cs);local current={};local merged={}
 for k,v in pairs(original)do merged[k]=v end
 for _,p in ipairs(batch)do
  assert(allowed(section,p[1]) and type(p[2])=="number" and p[2]%1==0 and p[2]>=-2147483648 and p[2]<=2147483647,"invalid stat batch")
  local v=read(cs,p[1]);assert(v~=nil,"cannot back up "..p[1].."; no stats written")
  current[p[1]]=v;if merged[p[1]]==nil then merged[p[1]]=v end
 end
 if not restoring then save_backup(section,cs,merged);backups[section..cs]=merged end
 local wrote=0
 for _,p in ipairs(batch)do
  local ok,value=pcall(StatSetInt,cs,p[1],p[2]);if not ok or value==false or read(cs,p[1])~=p[2]then
   local failed=0
   for key,v in pairs(current)do local success=pcall(StatSetInt,cs,key,v);if not success or read(cs,key)~=v then failed=failed+1 end end
   status("Write unconfirmed at "..p[1].."; rollback unconfirmed="..failed);return false
  end
  wrote=wrote+1
 end
 status(section.." MP"..cs..": "..wrote.." stat readbacks matched; check planning board in game")
 return true
end
local function restore(section)
 local cs=slot();local b=load_backup(section,cs);local batch={};for k,v in pairs(b)do batch[#batch+1]={k,v}end
 assert(#batch>0,"no stored backup for this character");return apply(section,batch,true)
end
local function addkeys(section,list)for _,key in ipairs(list)do groups[section][key]=true end end
local cayo_base={"H4CNF_BS_GEN","H4CNF_BS_ENTR","H4CNF_BS_ABIL","H4CNF_WEAPONS","H4CNF_WEP_DISRP","H4CNF_ARM_DISRP","H4CNF_HEL_DISRP","H4CNF_TARGET","H4CNF_TROJAN","H4CNF_APPROACH","H4_MISSIONS","H4_PROGRESS","H4_PLAYTHROUGH_STATUS"}
addkeys("CAYO",cayo_base)
local loot_keys={}
for _,kind in ipairs({"CASH","COKE","WEED","GOLD"})do for _,where in ipairs({"I","C"})do local k="H4LOOT_"..kind.."_"..where;loot_keys[#loot_keys+1]=k;loot_keys[#loot_keys+1]=k.."_SCOPED"end end
loot_keys[#loot_keys+1]="H4LOOT_PAINT";loot_keys[#loot_keys+1]="H4LOOT_PAINT_SCOPED";addkeys("CAYO",loot_keys)
local targets={"Tequila","Ruby Necklace","Bearer Bonds","Pink Diamond","Madrazo Files","Panther Statue"}
local weapons={"Aggressor","Conspirator","Crack Shot","Saboteur","Marksman"}
local loot_types={"Gold","Cocaine","Weed","Cash","Paintings","Mixed","None"}
local ct,cw,cd,cl=4,1,1,1
local function loot_batch()
 local values={};for _,k in ipairs(loot_keys)do values[k]=0 end
 local function put(k,v)values[k]=v;values[k.."_SCOPED"]=v end
 if cl==1 or cl==6 then put("H4LOOT_GOLD_C",255)end
 if cl==2 or cl==6 then put("H4LOOT_COKE_I",255)end
 if cl==3 or cl==6 then put("H4LOOT_WEED_I",65280)end
 if cl==4 or cl==6 then put("H4LOOT_CASH_I",16711680)end
 if cl==5 or cl==6 then put("H4LOOT_PAINT",127)end
 local batch={};for _,k in ipairs(loot_keys)do batch[#batch+1]={k,values[k]}end;return batch
end
local function cayo_preps()return {{"H4CNF_BS_GEN",131071},{"H4CNF_BS_ENTR",63},{"H4CNF_BS_ABIL",63},{"H4CNF_WEP_DISRP",3},{"H4CNF_ARM_DISRP",3},{"H4CNF_HEL_DISRP",3},{"H4CNF_APPROACH",-1},{"H4_MISSIONS",65535},{"H4_PLAYTHROUGH_STATUS",32}}end
local function cayo_all()
 local b=cayo_preps();for _,v in ipairs({{"H4CNF_TARGET",ct-1},{"H4CNF_WEAPONS",cw},{"H4_PROGRESS",cd==1 and 126823 or 131055},{"H4CNF_TROJAN",2}})do b[#b+1]=v end
 for _,v in ipairs(loot_batch())do b[#b+1]=v end;return b
end
local casino_keys={"H3OPT_MODVEH","H3_COMPLETEDPOSIX","CAS_HEIST_FLOW","H3_LAST_APPROACH","H3OPT_APPROACH","H3_HARD_APPROACH","H3OPT_TARGET","H3OPT_POI","H3OPT_ACCESSPOINTS","H3OPT_CREWWEAP","H3OPT_CREWDRIVER","H3OPT_CREWHACKER","H3OPT_WEAPS","H3OPT_VEHS","H3OPT_DISRUPTSHIP","H3OPT_BODYARMORLVL","H3OPT_KEYLEVELS","H3OPT_MASKS","H3OPT_BITSET1","H3OPT_BITSET0"};addkeys("CASINO",casino_keys)
local casino_targets={"Cash","Gold","Artwork","Diamonds"}
local approaches={{"Silent and Sneaky",127,262270},{"Big Con",159,524118},{"Aggressive",799,3670102}}
local gunmen={{"Chester McCoy",4},{"Gustavo Mota",2},{"Patrick McReary",5},{"Charlie Reed",3},{"Karl Abolaji",1}}
local drivers={{"Chester McCoy",5},{"Eddie Toh",3},{"Taliana Martinez",2},{"Zach Nelson",4},{"Karim Denz",1}}
local hackers={{"Avi Schwartzman",4},{"Paige Harris",5},{"Christian Feltz",2},{"Yohan Blair",3},{"Rickie Lukens",1}}
local ht,ha,hd,hg,hdr,hh,hv,hcar=4,1,1,1,1,1,1,1
local function casino_all()return {{"H3OPT_MODVEH",-1},{"H3_COMPLETEDPOSIX",-1},{"CAS_HEIST_FLOW",-1},{"H3_LAST_APPROACH",0},{"H3OPT_APPROACH",ha},{"H3_HARD_APPROACH",hd==2 and ha or 0},{"H3OPT_TARGET",ht-1},{"H3OPT_POI",1023},{"H3OPT_ACCESSPOINTS",2047},{"H3OPT_CREWWEAP",gunmen[hg][2]},{"H3OPT_CREWDRIVER",drivers[hdr][2]},{"H3OPT_CREWHACKER",hackers[hh][2]},{"H3OPT_WEAPS",hv-1},{"H3OPT_VEHS",hcar-1},{"H3OPT_DISRUPTSHIP",3},{"H3OPT_BODYARMORLVL",-1},{"H3OPT_KEYLEVELS",2},{"H3OPT_MASKS",2},{"H3OPT_BITSET1",approaches[ha][2]},{"H3OPT_BITSET0",approaches[ha][3]}}end
local doom_keys={"GANGOPS_FLOW_MISSION_PROG","GANGOPS_HEIST_STATUS","GANGOPS_FLOW_NOTIFICATIONS"};addkeys("DOOMSDAY",doom_keys)
local doom={{"Act I - Data Breaches",503,-229383},{"Act II - Bogdan",240,-229378},{"Act III - Doomsday",16368,-229380}}
addkeys("TUNER",{"TUNER_GEN_BS","TUNER_CURRENT"})
local contracts={"Union Depository","Superdollar Deal","Bank Contract","ECU Job","Prison Contract","Agency Deal","Lost Contract","Data Contract"};local contract=1
local function reset(section)local b={};for key in pairs(groups[section])do b[#b+1]={key,0}end;return apply(section,b)end
local function dump()
 local cs=slot();local lines={"Heist Editor "..VERSION,"Character=MP"..cs,"Presets supplied as references; console effects unverified"}
 for _,section in ipairs({"CAYO","CASINO","DOOMSDAY","TUNER"})do lines[#lines+1]="["..section.."]";local keys={};for k in pairs(groups[section])do keys[#keys+1]=k end;table.sort(keys);for _,k in ipairs(keys)do lines[#lines+1]=k.."="..tostring(read(cs,k))end end
 assert(files.write("status.txt",table.concat(lines,"\n").."\n"),"status file save failed");status("Status file saved in scripts/config")
end
local function action(label,fn,parent)menu.action(label,function()local ok,err=pcall(fn);if not ok then status("ERROR: "..tostring(err))end end,parent)end
local function cycle(label,items,get,set,parent)
 local id;id=menu.action(label..": "..items[get()],function()local n=get()%#items+1;set(n);menu.rename(id,label..": "..items[n])end,parent)
end
function onLoad()
 local c=menu.submenu("Cayo Perico")
 cycle("Primary Target",targets,function()return ct end,function(v)ct=v end,c)
 cycle("Secondary Loot",loot_types,function()return cl end,function(v)cl=v end,c)
 cycle("Weapons",weapons,function()return cw end,function(v)cw=v end,c)
 cycle("Difficulty",{"Normal","Hard"},function()return cd end,function(v)cd=v end,c)
 action("Apply Selected Cayo Setup",function()apply("CAYO",cayo_all())end,c)
 action("Apply Target Only",function()apply("CAYO",{{"H4CNF_TARGET",ct-1}})end,c)
 action("Apply Loot Only",function()apply("CAYO",loot_batch())end,c)
 action("Apply Weapons Only",function()apply("CAYO",{{"H4CNF_WEAPONS",cw}})end,c)
 action("Complete Preparations Only",function()apply("CAYO",cayo_preps())end,c)
 local h=menu.submenu("Diamond Casino")
 cycle("Target",casino_targets,function()return ht end,function(v)ht=v end,h)
 local an={};for _,a in ipairs(approaches)do an[#an+1]=a[1]end
 cycle("Approach",an,function()return ha end,function(v)ha=v end,h)
 cycle("Difficulty",{"Normal","Hard"},function()return hd end,function(v)hd=v end,h)
 for _,crew in ipairs({{"Gunman",gunmen,function()return hg end,function(v)hg=v end},{"Driver",drivers,function()return hdr end,function(v)hdr=v end},{"Hacker",hackers,function()return hh end,function(v)hh=v end}})do local names={};for _,v in ipairs(crew[2])do names[#names+1]=v[1]end;cycle(crew[1],names,crew[3],crew[4],h)end
 cycle("Weapon Variant",{"0","1"},function()return hv end,function(v)hv=v end,h)
 cycle("Vehicle Variant",{"0","1","2","3"},function()return hcar end,function(v)hcar=v end,h)
 action("Apply Selected Casino Setup",function()apply("CASINO",casino_all())end,h)
 action("Apply Casino Target Only",function()apply("CASINO",{{"H3OPT_TARGET",ht-1}})end,h)
 action("Unlock POI and Access Points",function()apply("CASINO",{{"H3OPT_POI",1023},{"H3OPT_ACCESSPOINTS",2047}})end,h)
 action("Duggan Disruption and Level 2 Cards",function()apply("CASINO",{{"H3OPT_DISRUPTSHIP",3},{"H3OPT_BODYARMORLVL",-1},{"H3OPT_KEYLEVELS",2}})end,h)
 local d=menu.submenu("Doomsday - Experimental Presets")
 for _,v in ipairs(doom)do local a=v;action(a[1],function()apply("DOOMSDAY",{{doom_keys[1],a[2]},{doom_keys[2],a[3]},{doom_keys[3],1557}})end,d)end
 local t=menu.submenu("LS Tuners - Experimental Presets")
 cycle("Contract",contracts,function()return contract end,function(v)contract=v end,t)
 action("Apply Selected Contract",function()apply("TUNER",{{"TUNER_GEN_BS",12543},{"TUNER_CURRENT",contract-1}})end,t)
 action("Complete Tuners Preparations",function()apply("TUNER",{{"TUNER_GEN_BS",0x0FFFFFFF}})end,t)
 for _,v in ipairs({{c,"CAYO"},{h,"CASINO"},{d,"DOOMSDAY"},{t,"TUNER"}})do local parent,section=v[1],v[2];action("Read Status",dump,parent);action("Restore Stored Backup",function()restore(section)end,parent);action("Reset Managed Stats to Zero",function()reset(section)end,parent)end
 local settings=menu.submenu("Settings and Status")
 cycle("Character",{"Auto","MP0","MP1"},function()return slot_mode+1 end,function(v)slot_mode=v-1 end,settings)
 action("Read-Only Bridge Test",function()local cs=slot();assert(read(cs,"H4_PROGRESS")~=nil,"stat read failed");status("Stat bridge readable for MP"..cs.."; no writes performed")end,settings)
 action("Write Full Status File",dump,settings)
 action("Log Last Result",function()util.log(report)end,settings)
 action("Version: "..VERSION,function()util.log("No payout or lobby globals mapped; not a complete Heist Control port")end,settings)
end
