-- PS4 remake of the compatible portions of nocams.lua from the PC archive.
-- PC native hashes/trusted-mode flags are replaced by named PS4 API bindings.
local idle, stunts = false, false
function onLoad()
    menu.toggle("Prevent Idle Camera", function(value) idle = value end)
    menu.toggle("Disable Stunt Jump Camera", function(value)
        Native.SET_STUNT_JUMPS_CAN_TRIGGER(not value)
        stunts = value
    end)
end
function onFrame()
    if idle then Native.INVALIDATE_IDLE_CAM() end
end
function onUnload()
    if stunts then Native.SET_STUNT_JUMPS_CAN_TRIGGER(true) end
end
