local routes={
{name="Playing Cards",points={
{1992.183,3046.28,47.125},
{120.38,-1297.669,28.705},
{79.293,3704.578,40.945},
{2937.738,5325.846,100.176},
{727.153,4189.818,40.476},
{-103.14,369.008,112.267},
{99.959,6619.539,32.314},
{-282.6689,6226.274,31.3554},
{1707.556,4921.021,41.865},
{-1581.8604,5204.295,3.9093},
{10.8264,-1101.1573,29.613},
{1690.0428,3589.0144,35.5883},
{1159.1442,-316.5876,69.5134},
{2341.8074,2571.737,47.6079},
{-3048.193,585.2986,7.7708},
{-3149.7073,1115.8302,20.7216},
{-1840.641,-1235.3188,13.2937},
{810.6056,-2978.7407,5.8116},
{202.2747,-1645.2251,29.7679},
{253.2056,215.9778,106.2848},
{-1166.183,-233.9277,38.262},
{729.9886,2514.7131,73.1663},
{188.1851,3076.3318,43.0447},
{3687.9143,4569.0728,24.9397},
{1876.9755,6410.034,46.5982},
{2121.1458,4784.6865,40.8114},
{900.0845,3558.1562,33.6258},
{2695.2722,4324.496,45.6516},
{-1829.4277,798.4049,138.0583},
{-1203.7251,-1558.8663,4.1736},
{-73.2829,-2005.4764,18.2561},
{-1154.2014,-527.2959,31.7117},
{990.0786,-1800.3907,31.3781},
{827.5513,-2158.7441,29.417},
{-1512.0801,-103.625,54.2027},
{-970.7493,104.3396,55.0431},
{-428.6815,1213.9049,325.9329},
{-167.8387,-297.1122,39.0353},
{2747.3215,3465.1196,55.6336},
{-1103.659,2714.6895,19.4539},
{549.4841,-189.3053,54.4369},
{-1287.6895,-1118.8177,6.3057},
{1131.428,-982.0297,46.6521},
{-1028.0834,-2746.9358,13.3589},
{-538.5779,-1278.5424,26.3437},
{1326.4489,-1651.2626,52.0964},
{183.3252,-685.2661,42.607},
{1487.8461,1129.2,114.3005},
{-2305.538,3387.973,31.0201},
{-522.632,4193.4595,193.7517},
{-748.9897,5599.5337,41.5794},
{-288.0628,2545.2104,74.4223},
{2565.3264,296.8703,108.7367},
{-408.2484,585.783,124.378},
}},
{name="Signal Jammer Viewing Points",points={
{1006.372,-2881.68,30.422},
{-980.242,-2637.703,88.528},
{-688.195,-1399.329,23.331},
{1120.696,-1539.165,54.871},
{2455.134,-382.585,112.635},
{793.878,-717.299,48.083},
{-168.3,-590.153,210.936},
{-1298.3429,-435.8369,108.129},
{-2276.4841,335.0941,195.723},
{-667.25,228.545,154.051},
{682.561,567.5302,153.895},
{2722.561,1538.1031,85.202},
{758.539,1273.6871,445.181},
{-3079.2578,768.5189,31.569},
{-2359.338,3246.831,104.188},
{1693.7318,2656.602,60.84},
{3555.018,3684.98,61.27},
{1869.0221,3714.4348,117.068},
{2902.552,4324.699,101.106},
{-508.6141,4426.661,87.511},
{-104.417,6227.2783,63.696},
{1607.5012,6437.3154,32.162},
{2792.933,5993.922,366.867},
{1720.6129,4822.467,59.7},
{-1661.0101,-1126.742,29.773},
{-1873.49,2058.357,154.407},
{2122.4602,1750.886,138.114},
{-417.424,1153.1431,339.128},
{3303.9011,5169.7925,28.735},
{-1005.8481,4852.1475,302.025},
{-306.627,2824.859,69.512},
{1660.6631,-28.07,179.137},
{754.647,2584.067,133.904},
{-279.9081,-1915.608,54.173},
{-260.4421,-2411.8071,126.019},
{552.132,-2221.8528,73.0},
{394.3919,-1402.144,76.267},
{1609.7911,-2243.767,130.187},
{234.2919,220.771,168.981},
{-1237.1211,-850.4969,82.98},
{-1272.7319,317.9532,90.352},
{0.088,-1002.4039,96.32},
{470.5569,-105.049,135.908},
{-548.5471,-197.9911,82.813},
{2581.0469,461.9421,115.095},
{720.14,4097.634,38.075},
{1242.4711,1876.0681,92.242},
{2752.1128,3472.779,67.911},
{-2191.856,4292.4077,55.013},
{450.475,5581.514,794.0683},
}},
{name="Stunt Jump Starts",points={
{2.143237,1720.5264,224.36223},
{-437.43567,-1196.3062,52.99947},
{466.72003,4319.375,59.95854},
{-166.34563,6578.911,12.059387},
{-977.3154,4180.1816,133.4073},
{-7.579316,-1037.7183,37.534637},
{-268.0506,-770.5955,55.124},
{-86.19047,-537.1067,38.11981},
{-1594.7732,-762.3895,20.853231},
{-248.65648,-215.40202,47.082996},
{-1442.9155,403.0396,109.28736},
{3351.9866,5156.3345,18.207516},
{1687.4855,2340.2605,73.36435},
{307.3563,-621.0101,42.3353},
{-882.79474,-854.2749,17.6236},
{364.7186,-1162.9991,28.2918},
{396.10138,-1656.2368,48.000576},
{52.473076,-779.20447,42.219185},
{32.60692,6526.0977,29.624762},
{1789.045,2049.2378,65.45301},
{-1070.7548,10.703864,50.348785},
{84.6931,-2196.2747,5.747},
{1637.9042,3608.2751,33.474846},
{566.68,-594.16003,43.86801},
{452.99863,-1374.922,43.02972},
{-425.5986,-1555.6082,22.706762},
{-963.1714,-2778.5056,14.478279},
{-2009.6931,-319.28024,47.545036},
{1671.9133,3151.226,45.29734},
{-524.65186,-1489.8649,12.315341},
{787.837,-2912.4077,5.628719},
{1978.6943,1925.877,87.246},
{672.2588,-3003.4043,6.047905},
{108.17593,-2815.1226,9.17942},
{109.05937,-3209.3123,7.463991},
{124.214874,-2954.8147,9.250035},
{174.63142,-2782.5117,7.013673},
{163.6802,-2961.3328,7.712487},
{285.75012,-3014.0552,8.774601},
{371.4717,-2635.26,9.349143},
{-854.31323,-2551.8374,20.418636},
{-986.5257,-2507.1882,20.45239},
{-589.2717,-1532.1613,3.122784},
{-626.5751,-1075.8972,21.066702},
{-453.6471,-1397.4199,30.327072},
{-445.23865,-542.0142,24.500528},
{-594.9152,-109.85971,40.96681},
{-726.34106,-58.790874,39.675186},
{1480.1853,-2218.5376,77.756454},
{367.16415,-2522.2588,6.246408},
}},
{name="Static Movie Props",points={
{94.202,-1294.965,29.067},
{-1010.051,-502.175,36.493},
{2517.254,3789.326,53.698},
{-2349.036,3270.785,32.968},
{1165.416,247.5531,-50.73},
{-41.795,2873.231,59.625},
{-1169.573,4926.988,223.7279},
}},
}

-- Collectibles PS4 Routes: original route UI using factual upstream coordinates.
-- Original project/author: IB_U_Z_Z_A_R_Dl, Illegal-Services/Collectibles-2Take1-Lua.
-- No artificial pickups, stat writes, reward/XP grants, spawned figurines or auto-collect.
local indices={};local visited={};local labels={};local with_vehicle=false
local function announce(i)
 local r=routes[i];menu.rename(labels[i],string.format("%s [%d/%d]",r.name,indices[i],#r.points))
end
local function save()
 local t={};for i=1,#routes do t[i]=string.format("%d,%d",indices[i],visited[i])end
 assert(files.write("route_progress.txt",table.concat(t,"\n")),"could not save route cursor")
end
local function request(i)
 local r=routes[i];local p=r.points[indices[i]];local ped=players.local_ped();local e=players.local_entity()
 if e~=ped and not with_vehicle then util.log("Exit the vehicle or enable Teleport With Vehicle");return end
 if p[3]<-10 and Native.GET_INTERIOR_FROM_ENTITY(ped)==0 then util.log("This point requires its interior; enter/load the correct interior first");return end
 -- Exact-location requests only; no claim of collection/arrival, interior streaming or reward.
 entity.set_coords(e,p[1],p[2],p[3]+.5)
 util.log(string.format("%s point %d/%d requested: %.3f %.3f %.3f",r.name,indices[i],#r.points,p[1],p[2],p[3]))
end
local function safe(label,fn)return function()local ok,err=pcall(fn);if not ok then util.log(label..": "..tostring(err))end end end
function onLoad()
 assert(menu.rename,"Install the API2 PRX supplied with these routes")
 local saved=files.read("route_progress.txt")or "";local n=0
 for line in saved:gmatch("[^\r\n]+")do n=n+1;local a,b=line:match("^(%d+),(%d+)$");if routes[n]then a,b=tonumber(a),tonumber(b);if a and a>=1 and a<=#routes[n].points and b and b<=#routes[n].points then indices[n]=a;visited[n]=b end end end
 menu.toggle("Teleport With Vehicle",function(on)with_vehicle=on end)
 for i,r in ipairs(routes)do
  local k=i;indices[k]=indices[k]or 1;visited[k]=visited[k]or 0;local parent=menu.submenu(r.name);labels[k]=parent;announce(k)
  menu.action("Request Current Position",safe("route position",function()request(k)end),parent)
  menu.action("Next Point",safe("next point",function()indices[k]=indices[k]%#r.points+1;announce(k);save()end),parent)
  menu.action("Previous Point",safe("previous point",function()indices[k]=(indices[k]-2)%#r.points+1;announce(k);save()end),parent)
  menu.action("Mark Visited and Advance",safe("route progress",function()visited[k]=math.min(#r.points,visited[k]+1);indices[k]=indices[k]%#r.points+1;announce(k);save()end),parent)
  menu.action("Log Current Coordinates / Progress",function()local p=r.points[indices[k]];util.log(string.format("%s %d/%d: %.4f,%.4f,%.4f | manually visited %d (not verified collection)",r.name,indices[k],#r.points,p[1],p[2],p[3],visited[k]))end,parent)
  menu.action("Reset This Route",safe("reset route",function()indices[k]=1;visited[k]=0;announce(k);save()end),parent)
 end
 util.log("Collectibles PS4 routes loaded. Some props require interiors; jammers can be high on towers. Collection and stunt completion remain normal gameplay.")
end
