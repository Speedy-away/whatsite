
## Installation

1. Transfer **OxagonLite_xxx.prx** to /data/GoldHEN/plugins using an FTP client (e.g. **FileZilla**).

2. Transfer the **Oxagon** folder and **Oxagon.key** to the /data directory.

3. Rename OxagonLite_xxx.prx by replacing xxx with your game's title update version:

   * 153 for GTA V 1.53
   * 156 for GTA V 1.56

4. Open plugins.ini and add the appropriate entry for your game version:

[CUSA00419]
/data/GoldHEN/plugins/OxagonLite_153.prx

[CUSA00411]
/data/GoldHEN/plugins/OxagonLite_156.prx
