// ---------------- SYSTEME ESSENCE (constantes, doivent rester en tete de fichier) ----------------



// ---------------- SYSTEME USURE DES PNEUS (constantes) ----------------

#define TYRE_MODE_NONE 0

#define TYRE_MODE_CAR  1

#define TYRE_MODE_BIKE 2

#define FUEL_STATION_COUNT 27

#define FUEL_ICON_SIZE 0.012f

#define FUEL_ICON_GAP 0.012f

#define FUEL_ENGINE_HEALTH_FULL 1000.0f

#define FUEL_ENGINE_HEALTH_MIN 150.0f

#define FUEL_ALERT_REPEAT_MS 4000

#define FUEL_GAS_BLIP_SPRITE 361

#define FUEL_GAS_BLIP_COLOUR 17

// ---------------- SYSTEME TRANSMISSION MANUELLE (constantes) ----------------

#define TRANS_GEAR_MAX 6

#define TRANS_CONTROL_STICK_UP   61  // INPUT_VEH_MOVE_UP_ONLY (palette haut du volant)

#define TRANS_CONTROL_STICK_DOWN 62  // INPUT_VEH_MOVE_DOWN_ONLY (palette bas du volant)

#define TRANS_CONTROL_ACCELERATE 71  // INPUT_VEH_ACCELERATE

#define TRANS_STICK_THRESHOLD 0.5f

#define TRANS_STOP_SPEED_MS   0.3f

#define TRANS_STOP_HOLD_MS    400

#define TRANS_REVERSE_CAP_MS  8.3f

#define TRANS_LIMITER_MARGIN   0.96f

#define TRANS_LIMITER_POWER_MS 14

#define TRANS_LIMITER_CUT_MS   16

#define TRANS_LIMITER_CUT_KMH  3.0f

#define TRANS_LUG_THRESHOLD    0.55f // fraction du plancher du rapport en dessous de laquelle le moteur peine

#define TRANS_LUG_PENALTY_KMH  4.0f  // marge d'acceleration restante quand le moteur peine

#define TRANS_SHIFT_KICK_MS 200

#define TRANS_REV_IDLE    800.0f

#define TRANS_REV_REDLINE 7000.0f

#define TRANS_DASH_X      0.8800f

#define TRANS_DASH_Y      0.9400f

#define TRANS_DASH_WIDTH  0.1300f

#define TRANS_DASH_HEIGHT 0.0160f



int PlayerPointer = 0;

bool IsModderBoolean;

bool Godmode;

bool invisible;

bool FreezePos;

bool BLOCKER[6];

bool FreezeGunProtection;

bool FreezeGroupProtection;

int Bgroup;

int online_char;

bool ModelFreezeProtection;

#define NOP 0x60000000

int NumMenu = 0;

int NumMenuLevel;

bool TeleportGunTest;

int lastNumMenu[20];

int lastOption[20];

int currentOption;

int DelayDraw = 0;

int optionCount;

int testFix = 0;

int testFix3 = 0;

int testFix2 = 0;

int testFix6 = 0;

int testFix78 = 0;

bool Blackout = 0;

bool DeleteWater = 0;

bool firstopenmenu;

int TeleportSelectorAirport = 0;

float TeleportsCoordsX_Airport[] = { -1070.906250 ,     -1142.084229,    1682.196411,   2124.625732 , -2446.711182,  -1563.743286 ,   -978.708496 };

float TeleportsCoordsY_Airport[] = { -2972.122803 ,     -2697.341553,    3279.987793,   4805.270020,  3142.811035,   2769.382080 ,   -3001.840820 };

float TeleportsCoordsZ_Airport[] = { 13.773568 ,         13.324973,      40.647972 ,    40.479958,    32.194775,   16.819347 ,      13.31788 };

char* TeleportsNames_Airport[] = { "Los Santos Airport","Flight School", "Sandy Shores", "Trevor's Airfield", "Fort Zancudo", "Fort Zancudo Front", "LS Airport Hangar" };

int TeleportSelectorLSC = 0;

float TeleportsCoordsX_LSC[] = { -221.749908 ,      -196.349442,    116.223175,   1176.822632 ,   1173.452271 ,   -370.533752,    -701.829956  ,    709.295471 ,      57.513451,     -1135.707275 ,      1205.028442 };

float TeleportsCoordsY_LSC[] = { -1158.249756 ,     -1303.103271,   6606.201660,   2657.973145,     2661.584717,   -130.402649,   -921.928772   , -1081.996216,      -1389.658691,   -1987.154175,      -3089.802490 };

float TeleportsCoordsZ_LSC[] = { 23.040998 ,         30.650515,       31.462461 ,    37.370682,       37.289780 ,      38.197617, 18.589094     ,  21.975765,        28.968079,      12.976217,         5.374923 };

char* TeleportsNames_LSC[] = { "Mort Mutual Insurance","Bennys Garage", "Beekers Garage", "Sandy Shores", "Grand Senora Dust", "Burton", "Little Seoul Car Wash", "La Mesa" , "Strawberry Car Wash" , "Los Santos Airport" , "Simeon Docks" };

int TeleportSelectorCLTH = 0;

float TeleportsCoordsX_CLTH[] = { -4.509100 ,      1678.057495,    1179.679688,   -1089.404785 ,   134.122055 ,   -148.234741,     -725.551453 ,    -1460.654419 , -1210.620361,  -1342.185913 ,   -814.432800,      411.403564,     89.320786 };

float TeleportsCoordsY_CLTH[] = { 6521.252930 ,     4819.882324,   2691.378662,   2697.033447,     -200.211334,   -308.074463,   -162.833710   , -227.550964,      -784.160217,   -1280.013428,      -1085.986938,    -806.654907,   -1392.317627 };

float TeleportsCoordsZ_CLTH[] = { 30.571024 ,         41.299820,       37.124043 ,    19.442095,       53.864090 ,     38.104240,  36.570301     , 48.728519,        16.549015,      4.443256,         10.567306 ,    28.742212 ,    28.800083 };

char* TeleportsNames_CLTH[] = { "Polito Bay","Grapeseed", "Grand Senora", "Great Chaparral", "Suburban - Havick", "Ponsonbys - Burton", "Ponsonbys - Rockford Hills", "Ponsonbys - Morningwood" , "Suburban - Del Perro" , "Masks - Vespucci Beach" , "Binco - Vespucci", "Binco - Strawberry", "Strawberry" };

int TeleportSelectorBARB = 0;

float TeleportsCoordsX_BARB[] = { -286.639038 ,      1938.357910,    -27.791309,   -829.426392 ,   -1294.995239 ,   1198.025757,     127.762802 };

float TeleportsCoordsY_BARB[] = { 6239.389648 ,     3717.808350,   -136.863708,   -191.582718,     -1117.641724,   -471.814178,   -1718.656494 };

float TeleportsCoordsZ_BARB[] = { 30.567659 ,         31.607185,       56.515392 ,    36.921909,       6.157444 ,     65.670250,  28.659100  };

char* TeleportsNames_BARB[] = { "Polito Bay","Sandy Shores", "Havick", "Rockford Hills", "Vespucci", "Mirror Park", "Davis" };

int TeleportSelectorWEAP = 0;

float TeleportsCoordsX_WEAP[] = { -318.859039 ,      1704.671997,    -1108.600830,   -3155.888672 ,   2571.371826 ,   235.666794,     -1328.592896 ,    -665.232727 , 844.439026,  17.377790 ,            814.442017 };

float TeleportsCoordsY_WEAP[] = { 6074.433105 ,     3748.880615,   2685.694092,   1073.844482,     313.879608,        -42.263149,   -387.114410   , -952.522522,      -1009.422424,   -1122.183105,      -2130.448486 };

float TeleportsCoordsZ_WEAP[] = { 30.614943 ,         33.286053,       18.177374 ,    20.188726,       107.970573 ,     69.221313,  36.126881     , 20.866556,        27.511728,      28.469843,         28.867798 };

char* TeleportsNames_WEAP[] = { "Polito Bay","Sandy Shores", "Great Chaparral", "Chumash", "Palomino Fwy", "Hawick", "Morningwood", "Little Seoul" , "La Mesa" , "Pillbox Hill" , "Cypress Flats" };

int TeleportSelectorTATT = 0;

float TeleportsCoordsX_TATT[] = { -285.910400 ,      1853.771851,    -3155.888672,   318.228790 ,   -1163.504639 ,   1318.160889 };

float TeleportsCoordsY_TATT[] = { 6202.941895 ,     3746.440918,   1073.844482,   164.457535,     -1413.232788,   -1642.176147 };

float TeleportsCoordsZ_TATT[] = { 30.626459 ,         32.395195,       20.188726 ,    103.146561,       4.360025 ,     51.787762 };

char* TeleportsNames_TATT[] = { "Polito Bay","Sandy Shores", "Chumash", "Vinewood", "Vespucci", "El Burro Heights" };

int TeleportSelectorCINA = 0;

float TeleportsCoordsX_CINA[] = { 300.407776 ,      401.796814,    -1410.071167 };

float TeleportsCoordsY_CINA[] = { 193.051071 ,      -713.924988,   -199.047531 };

float TeleportsCoordsZ_CINA[] = { 103.590019 ,         28.569710,       46.502586  };

char* TeleportsNames_CINA[] = { "Vinewood Cinema","Ten Cent", "Morningwood Cinema" };

int PickWeaps[] = { -105925489, -1989692173, 996550793, 496339155, 978070226, -214137936, -546236071, -1296747938, -1766583645, -1456120371, -1835415205, -30788308, 1765114797, -2050315855, -1298986476, 779501861, 1295434569, 792114228, 1577485217, 2081529176, 768803961, -962731009, 483787975, 663586612, -2115084258, 693539241, -2027042680, -1997886297, 1587637620, -887893374, 1724937680, 2017151059, 1735599485, 1274757841, -1888453608, -1521817673, -794112265, -863291131, -1200951717, -864236261, 772217690, -1491601256, -2066319660, 1705498857, 746606563, 160266735, 1125567497, -831529621, 545862290, 341217064, 1897726628, 1852930709, -2136239332, -831529621, 1426343849, -107080240, -482507216, 738282662, 155886031, 483577702, 513448440, -562499202, -31919185, 1575005502, -405862452, -723152950, 1575005502, -1514616151 };

char *Pickwaf[] = { "w_ex_molotov", "w_ex_molotov_hi", "w_ex_pe", "w_ex_pe_hi", "w_lr_40mm", "w_lr_40mm_pu", "w_lr_grenadelauncher", "w_lr_grenadelauncher_hi", "w_lr_rpg", "w_lr_rpg_hi", "w_lr_rpg_rocket", "w_lr_rpg_rocket_pu", "w_me_bat", "w_mg_minigun_hi", "w_pi_pistol50_mag2", "w_pi_pistol_hi", "w_pi_pistol_mag1", "w_pi_pistol_mag2", "w_pi_stungun", "w_pi_stungun_hi", "w_sb_assaultsmg", "w_sb_assaultsmg_hi", "w_sb_assaultsmg_mag1", "w_sb_assaultsmg_mag2", "w_sb_microsmg", "w_sb_microsmg_hi", "w_sb_microsmg_mag1", "w_sb_microsmg_mag2", "w_sb_smg", "w_sb_smg_hi", "w_sb_smg_mag1" };

bool DisableFog;

bool MoneyRain;

int MaxRadius = 8;

bool Ammo;

bool NoRagdoll;

bool TestCID;

bool StartPFX;

float MenuWidth = 0.2350f;

float MenuWidthInfoBox = 0.0050;

int ParticleEntity;

const char *lower = "abcdefghijklmnopqrstuvwxyz";

const char *upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

int Handling_Bikes[27] = { 16, 17, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 237, 248, 263, 277, 283, 286 };

int Handling_Air[31] = { 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 239, 240, 241, 242, 243, 244, 245, 246, 247, 259, 272, 274, 275, 285, 287, 294, 298, 299 };

const char* ParticleString;

const char* ParticleString2;

int IsMod,

IsUsingGodModePossibly2Online,

IsUsingGodModeOnline2,

IsUsingGodModeOnline3,

IsUsingNoClipOnline,

IsUsingNoClip2Online,

IsUsingGodModeMe,

IsUsingGodModePossiblyMe,

IsMod2,

IsOpenCam,

IsOpenCam2,

IsFrozen,

GPMA_stub_0,

GPMA_stub_1,

NoTrafficAddr,

PrologueBypassAddr,

SessionFreezeProtectionAddr,

EnableBytes,

DisableBytes,

BlockMsgsAddr;

float SetSuspension = 0;

int HandlingOffset = 0;

bool ExplosiveAmmo;

bool FireAmmo;

bool g_bKeyBoardDisplayed;

int KeyboardIndex = 0;

bool optionPress;

bool rightPress;

bool leftPress;

bool leftPressSlow;

bool rightPressSlow;

bool fastRightPress;

bool fastLeftPress;

bool squarePress;

int selectedPlayer;

bool menuSounds = true;

bool keyboardActive;

int keyboardAction;

int *keyboardVar = 0;

char *infoText;

bool newTimerTick = true;

int maxTimerCount;

bool newTimerTick2 = true;

int maxTimerCount2;

bool instructions = true;

int instructCount;

int mov;

bool instructionsSetupThisFrame;

bool xInstruction;

bool squareInstruction;

bool squareInstruction2;

bool squareInstruction3;

bool lrInstruction;

bool udInstruction;

int bannerTextRed = 255;

int bannerTextGreen = 255;

int bannerTextBlue = 255;

int bannerRectRed = 255;

int bannerRectGreen = 255;

int bannerRectBlue = 255;

int optionsRed = 255;

int optionsGreen = 255;

int optionsBlue = 255;

int optionsOpacity = 255;

bool FindMobileAddress;

int StartPointing = 0;

const char* point = ".";

int DelayPrint = 0;

int R_Selector = 10;

int G_Selector = 10;

int B_Selector = 10;

int BackgruondR = 0;//0 // blue

int BackgruondG = 0;//10

int BackgruondB = 0;//30

int SelectedTextR = 0;

int SelectedTextG = 0;

int SelectedTextB = 0;

int SelectedTextA = 255;

int SubtitleBoxR = 0;

int SubtitleBoxG = 0;

int SubtitleBoxB = 0;

int SubtitleBoxA = 130;

int SubtitleBoxSecR = 0;

int SubtitleBoxSecG = 0;

int SubtitleBoxSecB = 0;

int SubtitleBoxSecA = 10;

bool EnableNeon;

bool SetNeonColour;

bool RainbowNeon;

bool EnableMusic = true;

bool SendAdmin;

int AdminSelector = 0;

bool EnableNaked;

int TimerFreeze = 0;

char Array[11];

int AdminArray[7];

int NeonColorR,

NeonColorG,

NeonColorB;

bool HideRadar;

float MobilePosX = 99.62;

float MobilePosY = -45.305;

float MobileAppsScale = -113;

float MobileUnk = -90;

float MobileRotation = -90;

bool SendArmyAttackers;

bool testVar;

bool CreateVeh;

int CreateVehPlayer = 0;

int VehicleSpawnerType = 0;

int newcar = 0;

float fMass = 0.0;

float finitialDragCoeff = 0.0;

float fpercentSubmerged = 0.0;

float fvehCentreOfMass1 = 0.0;

float fvehCentreOfMass2 = 0.0;

float fvehCentreOfMass3 = 0.0;

float fvehInertiaMultiplier1 = 0.0;

float fvehInertiaMultiplier2 = 0.0;

float fvehInertiaMultiplier3 = 0.0;

float finitialDriveForce = 0.0;

float fdriveInertia = 0.0;

float fclutchRateUpShift = 0.0;

float fclutchRateDownShift = 0.0;

float fbrakeForce = 0.0;

float fSteeringLock = 0.0;

bool IsUsingRealFreeze;

bool AttachObject;

int WantedLevel = 0;

int PlateSelector = 0;

bool IsInNetworkMenus;

bool IsInNetworkSelector = 0;

char* PlateTypes[] = {"Blue/White", "Yellow/black", "Yellow/Blue", "Blue/White2", "Blue/White3", "Yankton"};

int VehWeapSelector = 0;

int BoostCarType = 0;

int BoostGunType = 0;

float BoostCarSpeed = 0;

char* BoostCarText[] = {"Forward", "Backward"};

bool BoostCar;

int VehWeaponHash = 0;

int VehicleRocketsDelay = 0;

bool VehWeapBool;

char* VehWeap[] = {"Rocket", "Hunter", "Firework", "Enemy Laser"};

char* XPModifier[] = {"XP Up", "XP Down"};

int XPModifierSelector = 0;

 char* ATTACHOBJ_STR;

int ATTACHOBJ_PedHandle;

int TeleportSelector = 0;

int AnimationType = 0;

int TeleportSelectorFav = 0;

int TeleportSelectorNetFav = 0;

float HostFreezeCoordsX[] = { 4208.6777 ,  400.0220,  1471.5936, -2198.3100 , 3214.6643 ,  10817.8154,     -6354.351   ,  -6460.243};

float HostFreezeCoordsY[] = { 8184.8369,  8627.1602,  -4569.4760,  -4733.7504,  -43834.6210 , -9453.6162 , -3506.011 ,  -3261.991  };

float HostFreezeCoordsZ[] = { 775.4022 ,     2994.9985,     16.7436 ,   18.5128,    111.8154 , 21.8659,     6430.5234,      3350.2383};

float TeleportsCoordsX[] = { -1102.2910 ,  -1561.5250,  1741.4960, -2012.8470 , -74.94243 ,  430.2037 , 178.3295   ,  17.8323,    -558.9814 , 12.4553 ,  -795.4600 ,     -775.0500 , 3524.0700 ,1226.7500 ,3601.3830, -1244.1380 , 3369.2240, 1736.0712, -129.9640 };

float TeleportsCoordsY[] = { -2894.5160 ,  -3232.3460,  3269.2570,  2956.5270,  -818.63446 , 5614.7340 , 7041.8220 ,  7630.0140 ,  2945.7010,  -1110.2580 ,  308.8900 ,  312.3200,   3711.9500, 125.5000, 3668.7930 , -1454.9980, 5184.1500,  2583.6311 , 8130.8730 };

float TeleportsCoordsZ[] = { 13.9467 ,     26.3361,     41.6014 ,   32.8101,    326.174347 , 766.1684,   1.8671,      13.5068,   14.5917 ,    29.7970,     85.7100,      85.7000,    20.9913,   81.8394,  33.8718 ,    4.3478,    1.4602,     45.1847,   6705.6510 };

char* TeleportsNames[] = {"Airport","Airport Terminal", "Trevor Air Field", "Fort Zacundo", "Maze bank city Helipad", "Mount Chiliad Jump", "Far away beach", "Far Island", "Zancudo river", "Ammunation Office", "400k Garage (Outside)", "400k Apartment (Outside)", "Humane Lab (Waterbody)", "Track", "Private Garage", "Inside Store", "Dock (Near Lighthouse)", "Prison", "High in The Sky"};

char* AttachmentNames[] = {"Statue", "USA Flag", "Shrub" , "Rocket in The Ass" , "Thick hair" , "Recorded" , "Alien Egg" , "Guitar" , "Car wash" , "Snowman" , "Drum" , "Drum 2" , "Ring" , "Cone" , "Trevor TV" , "Old TV", "Boxing Glove", "Plant", "Bullet Shield", "Katana" };

int MessageTo = 0;

int AttachmentSelector = 0;

int AttachmentSelectorPlayer = 0;

char* Windows[] = {"Front Right", "Front Left", "Back Right" , "Back Left" };

int WindowIndex = 0;

float Coordes[6];

int ATTACHOBJ_HeadBoneIndex;

bool FreezeTimer;

bool ATTACHOBJ_Is_All;

float ATTACHOBJ_XCoord, ATTACHOBJ_YCoord, ATTACHOBJ_ZCoord, ATTACHOBJ_Pitch, ATTACHOBJ_Roll, ATTACHOBJ_Yaw;

bool OBJECT_ID_FREED_EVENT, OBJECT_ID_REQUEST_EVENT, ARRAY_DATA_VERIFY_EVENT = true, SCRIPT_ARRAY_DATA_VERIFY_EVENT = true, REQUEST_CONTROL_EVENT = false, GIVE_CONTROL_EVENT,

WEAPON_DAMAGE_EVENT, REQUEST_PICKUP_EVENT, REQUEST_MAP_PICKUP_EVENT, GAME_CLOCK_EVENT, GAME_WEATHER_EVENT, RESPAWN_PLAYER_PED_EVENT, GIVE_WEAPON_EVENT = true, 

REMOVE_WEAPON_EVENT = true, REMOVE_ALL_WEAPONS_EVENT = true, VEHICLE_COMPONENT_CONTROL_EVENT, FIRE_EVENT, EXPLOSION_EVENT, START_PROJECTILE_EVENT, ALTER_WANTED_LEVEL_EVENT, CHANGE_RADIO_STATION_EVENT,

RAGDOLL_REQUEST_EVENT, SCRIPTED_GAME_EVENT = true, REMOTE_SCRIPT_INFO_EVENT = false, REMOTE_SCRIPT_LEAVE_EVENT = false, CLEAR_AREA_EVENT, NETWORK_REQUEST_SYNCED_SCENE_EVENT = false,

NETWORK_START_SYNCED_SCENE_EVENT = true, NETWORK_UPDATE_SYNCED_SCENE_EVENT, NETWORK_STOP_SYNCED_SCENE_EVENT, NETWORK_CLEAR_PED_TASKS_EVENT = true, NETWORK_ENTITY_AREA_STATUS_EVENT,

SCRIPT_ENTITY_STATE_CHANGE_EVENT, NETWORK_INCREMENT_STAT_EVENT = true, MODIFY_VEHICLE_LOCK_WORD_STATE_DATA, REQUEST_DETACHMENT_EVENT, KICK_VOTES_EVENT = true, BLOW_UP_VEHICLE_EVENT, NETWORK_PTFX_EVENT,

REPORT_CASH_SPAWN_EVENT = true;

int PriPed;

int PedVar = 0;

int gameped[30];

int ObjectHash;

float Coordsz[6];

int PedVariable = 2;

int GroupFormating = 3;

int MovementSelector = 0;

bool FlyCar;

char* MovementNames[] = {"Chubby", "Injured", "Drunk", "Sexy" , "Hobo" , "Old Man" , "Holding a Baby" , "Fat" };

char *Movements[] = {"move_f@chubby@a", "move_injured_generic", "move_m@drunk@verydrunk", "move_f@sexy@a" , "move_m@hobo@a" , "move_lester_CaneUp" , "move_f@film_reel" , "move_f@fat@a"  };

float GroupSpacing = 1.1000;

bool ClearTasksAll;

int selectedPedestrian;

bool SpawnPed;

char* PedModel;

int newvar0;

int newvar1;

char DATA[500];

int ObjectsProtectionDelay;

int PlanesFreezeProtectionDelay = 0;

bool DeleteNearbyVehicles;

bool DeleteNearbyPlanes;

bool DeleteNearbyObjects;

bool DeleteNearbyPed;

int WeaponPedSelector3 = 0;

int WeaponPedSelector = 0;

int WeaponPedSelector2 = 0;

char* weaponInfos[16] = {

	 "WEAPON_LASSO",

	 "WEAPON_FISHINGROD",

	 "WEAPON_MOONSHINEJUG",

	 "WEAPON_MELEE_CLEAVER",

	 "WEAPON_MELEE_HATCHET",

	 "WEAPON_MELEE_HATCHET_MP",

	 "WEAPON_MELEE_KNIFE",

	 "WEAPON_MELEE_MACHETE",

	 "WEAPON_MELEE_TORCH",

	 "WEAPON_MELEE_LANTERN",

	 "WEAPON_MELEE_DAVY_LANTERN",

	 "WEAPON_MELEE_LANTERN_ELECTRIC",

	 "WEAPON_MELEE_BROKEN_SWORD",

	 "WEAPON_MELEE_KNIFE_CIVIL_WAR",

	 "WEAPON_MELEE_ANCIENT_HATCHET",

	 "WEAPON_REVOLVER_CATTLEMAN",

};

static const Hash weapon_hashes[] = {

	-1569615261, -100946242, 148160082, -1716189206, 1737195953,1317494643,-1786099057, 1141786504,-2067956739,453432689,1593441988,584646201,

	-1716589765,324215364,736523883,-270015777,-1074790547,-2084633992,-1357824103,-1660422300,2144741730,487013001,2017895192,-494615257,

	-1654528753,911657153,100416529,205991906,856002082,-1568386805,1305664598,-1312131151,1119849093,-1813897027,741814745,-37975472,

	-1600701090,615608432,101631238,883325847,-38085395,-2000187721,28811031,600439132,1233104067,4192643659,1627465347,3231910285,3523564046,

	3218215474,2132975508,2460120199,137902532,2138347493,2828843422,984333226,3342088282,1672152130,2874559379,126349499,1198879012,171789620,

	3696079510,3638508604,

};

int FixWeaponsEditorSetsTimer;

bool FixWeaponsEditorSets;

char* weaponNames[] = {

	 "Pistol","Combat Pistol","AP Pistol","Pistol .50",

	"Micro SMG","SMG","Assault SMG","Assault Rifle","Carbine Rifle","Advance Rifle","MG","Combat MG","Pump Shotgun","Sawnoff Shotgun","Assault Shotgun",

	"Bullpup Shotgun","Stungun","Sniper Rifle","Heavy Sniper"

};

char* weaponNames2[] = {

	 "Unarmed", "Animal","Couger","Knife","Night Stick","Hammer","Bat","Golf Club","Crow Bar","Pistol","Combat Pistol","AP Pistol","Pistol .50",

	"Micro SMG","SMG","Assault SMG","Assault Rifle","Carbine Rifle","Advance Rifle","MG","Combat MG","Pump Shotgun","Sawnoff Shotgun","Assault Shotgun",

	"Bullpup Shotgun","Stungun","Sniper Rifle","Heavy Sniper","Remote Sniper","Grenade Launcher","Grenade Launcher (Smoke)","RPG","Minigun",

	"Grenade","Sticky Bomb","Smoke Grenade","BZ Gas","Molotov","Fire Extinguisher","Jerry Can","Digi Scanner","Brief Case","Brief Case 2",

	"Ball","Flare","Bottle","Gusenberg","Special Carbine","Heavy Pistol", "SNS Pistol", "Bullpump Rifle","Dagger","Vintage Pistol","Firework",

	"Musket", "Heavy Shotgun","Marksman Rifle", "Homing Launcher", "Proximity Mine","Snow Ball", "Flare Gun", "Combat PDW", "Marksman Pistol",

	"Knuckle Dusters",

};

int DropWeaponSelector = 0;

char* DropWeaponNames[] = {

	"Pistol","Combat Pistol","AP Pistol",

	"Micro SMG","SMG","Assault Rifle","Carbine Rifle","Advance Rifle", "Sawnoff Shotgun",  "Pump Shotgun", "Assault Shotgun",

	"Sniper Rifle","Heavy Sniper","MG","Combat MG","Grenade Launcher","RPG","Minigun",

	"Grenade","Sticky Bomb","Molotov", "Petrocan","Smoke Grenade","Knife","Bat","Hammer",

	"Crowbar","Golf Club","Night Stick","Fire Extinguisher"

};

char* DropWeaponModels[] = {

	"PICKUP_WEAPON_PISTOL",

	"PICKUP_WEAPON_COMBATPISTOL",

	"PICKUP_WEAPON_APPISTOL",

	"PICKUP_WEAPON_MICROSMG",

	"PICKUP_WEAPON_SMG",

	"PICKUP_WEAPON_ASSAULTRIFLE",

	"PICKUP_WEAPON_CARBINERIFLE",

	"PICKUP_WEAPON_ADVANCEDRIFLE",

	"PICKUP_WEAPON_SAWNOFFSHOTGUN",

	"PICKUP_WEAPON_PUMPSHOTGUN",

	"PICKUP_WEAPON_ASSAULTSHOTGUN",

	"PICKUP_WEAPON_SNIPERRIFLE",

	"PICKUP_WEAPON_HEAVYSNIPER",

	"PICKUP_WEAPON_MG",

	"PICKUP_WEAPON_COMBATMG",

	"PICKUP_WEAPON_GRENADELAUNCHER",

	"PICKUP_WEAPON_RPG",

	"PICKUP_WEAPON_MINIGUN",

	"PICKUP_WEAPON_GRENADE",

	"PICKUP_WEAPON_STICKYBOMB",

	"PICKUP_WEAPON_MOLOTOV",

	"PICKUP_WEAPON_PETROLCAN",

	"PICKUP_WEAPON_SMOKEGRENADE",

	"PICKUP_WEAPON_KNIFE",

	"PICKUP_WEAPON_BAT",

	"PICKUP_WEAPON_HAMMER",

	"PICKUP_WEAPON_CROWBAR",

	"PICKUP_WEAPON_GOLFCLUB",

	"PICKUP_WEAPON_NIGHTSTICK",

	"PICKUP_WEAPON_FIREEXTINGUISHER"

};

int DropWeaponHashes[] = { 453432689 ,

-1989692173 ,

996550793,

496339155,

978070226,

-214137936,

-546236071,

-1296747938,

-1766583645,

-1456120371,

-1835415205,

-30788308,

1765114797,

-2050315855,

-1298986476,

779501861,

1295434569,

792114228,

1577485217,

2081529176,

768803961,

-962731009,

483787975,

663586612,

-2115084258,

693539241,

-2027042680,

-1997886297,

1587637620,

-887893374,

};

char* WEAPON_AUDIO[] = {""};

int MobileProtectionDelay;

int ScrollerSpeed = 12;

char* SCORPION_THEME_FILE = "FortniteUI.ini";

int DesignStable;

float addCharTextSize = 0.35f;

char* WeaponsEditorEnums[] = {"Audio", "Slot","Damage Type","Explosion Default","Explosion Hit Car","Explosion Hit Truck","Explosion Hit Bike","Explosion Hit Boat", "Explosion Hit Plane", "Fire Type", "Wheel Slot", "Group","Ammo Info", "Aiming Info" , "Clip Size" , "Accuracy Spread" , "Accurate Mode Accuracy" , "Run And Gun Accuracy" , "Recoil Accuracy Max" , "Recoil Error Time" , "Recoil Recovery Rate" , "Recoil Accuracy HeadShot" , "Min Head Shot Distance" , "Max Head Shot Distance" , "Head Shot Damage" , "Recoil Accuracy HeadShot Player" , "Min Head Shot Distance Player" , "Max HeadShot Distance Player" , "HeadShot Damage Player" , "Damage" , "Damage Time" , "Damage Time" , "Damage Time In Vehicle" , "Hit Limbs Damage" , "Network Hit Limbs Damage" , "Lightly Armoured Damage", "Force" , "Force Hit Ped" , "Force Hit Vehicle", "Force Hit Flying Heli", "Force Max Strength Mult", "Force Falloff Range Start", "Force Falloff Range End", "Force Falloff Min", "Projectile Force", "Frag Impulse", "Penetration", "Vertical Launch Adjustment", "Drop Forward Velocity", "Speed", "Bullets In Batch", "Batch Spread", "Reload Time MP", "Reload Time SP", "Vehicle Reload Time", "Anim Reload Rate", "Bullets Per Anim Loop", "Time Between Shots", "Time Left Between Shots Where Should Fire Is Cached", "SpinUp Time","Spin Time", "SpinDown Time", "Alternate Wait Time", "Bullet Bending Near Radius", "Bullet Bending Far Radius", "Bullet Bending Zoomed Radius", "Effect Group", "FlashFx", "FlashFxAlt", "ShellFx", "TracerFx", "PedDamageHash", "Tracer Fx ChanceSP", "Tracer Fx ChanceMP", "Flash Fx ChanceSP", "Flash Fx ChanceMP", "Flash Fx Alt Chance", "FlashFxScale","Initial Rumble Duration",  "Rumble Damage Intensity", "Rumble Duration", "Rumble Intensity", "Rumble Damage Intensity", "Network Player Damage", "NetworkPedDamage", "Network HeadShot Player Damage", "LockOn Range", "Weapon Range", "Sound Range", "Potential Blast Event Range", "Damage FallOff Range Min", "Damage FallOff Range Max", "Damage FallOff", "Vehicle Weapon Hash", "Default Camera Hash", "Assisted Aiming Camera Hash", "Recoil Shake Hash", "Min Time Between Recoil Shakes", "Recoil Shake Amplitude", "Explosion Shake Amplitude", "Camera Fov" , "Zoom Factor For Accurate Mode", "Movement Mode Conditiona lIdle" , "Human Name Hash"};

static int WeaponsEditorSelector = 0;

static int WeaponsEditorSelector2 = 0;

static int WeaponsEditorSelector3 = 0;

int WeaponsEditorDelay[1];

int WeaponsEditorEnumSelector = 0;

int WeaponEditorVar = -99;//0 = FLOAT | 1 = INT

int WeaponEditorOptionType = 1;//1= Integer	2= Float 3= Hash 4-String

float WeaponEditorF = 0;

static int WeaponEditorInteger = 0;

static int WeaponEditorAmmoPointer = 0;

static int WeaponEditorAimingPointer = 0;

bool NoCustomMsg = true;

int NameSpacing = 0;

int MsgSpacing = 0;

int MsgSize = 0;

int NameSize = 0;

int SecPed;

int SecVeh;

int OutColorPickerR;

int OutColorPickerG;

int OutColorPickerB;

int EnterNewColour = 0;

bool ColourPicker;

int ShadowR = 0;

int ShadowG = 0;

int ShadowB = 0;

int ShadowA = 160;//0, 49, 151

int MarkerR = 0;

int MarkerG = 12;

int MarkerB = 59;

int MarkerA = 100;

int HeaderSecR = 0;

int HeaderSecG = 10;

int HeaderSecB = 107;

int HeaderSecA = 255;

int BackgruondOpacity = 140;

int ScrollerR= 255;//0, 49, 151

int ScrollerG= 255;

int ScrollerB= 255;

int ScrollerOpacity= 150;

int CheckBoxR = 255;

int CheckBoxG = 200;

int CheckBoxB = 0;

int CheckBoxA = 180;

int CheckBoxColoredR = 108;

int CheckBoxColoredG = 4;

int CheckBoxColoredB = 0;

int CheckBoxColoredA = 190;

int CheckBoxOpacity = 255;

int CheckBoxOutLineR = 255;

int CheckBoxOutLineG = 255;

int CheckBoxOutLineB = 255;

int CheckBoxOutLineA = 255;

bool CustomFont;

char* UserID;

char SUBTITLE_TEXT_ALIGN[10];

char* SubtitleTextAlign = "left";

bool IsSubtitleCenter;

bool ISGoneOnline;

float SaveFontSize = 0;

int PauseModeTimer = 0;

#define DEX 1

#define CEX 2

#define KERNEL CEX

bool foundStealHost;

int netScripts;

int netScrCount;

int thrStrLength;

int lowerStruc;

bool SpoofedMsg;

bool CheckStartup;

const char* protectionMsg = "~b~Scorpion Anti-Modders\n~r~www.scorpionsprx.co.uk\n~w~Your IP:%s";

bool EBOOT_CHECKER;

bool DrawButton;

bool SessionFreezeV2;

int netScrPoolStruc;

int DropKickFeatureTimer;

int DropKickBoolean[4];

bool StartFrzDLC;

bool SlodFreeze;

bool SlodFreezeTimer;

int model = 0x3F039CBA;

int SlodHandle;

int SlodSelectedPed;

int carfreeze;

bool FreezeVehicle;

int dlcped;

int timerLoading;

int DeleteFreezeDLC;

int	FreezeCarModel;

bool FreezeEntitiesDetector = true;

bool PauseModeActive;

bool ForceHostMode;

bool ForceHost;

char BufferMsg[500];

char BufferName[500];

char* FontTypes[2] = {"Bold", "Italic"};

char* MsgTypes[2] = {"Normal Message", "Admin Message (Patched)"};

char* ColorMsg[] = {"White", "Red", "Green", "Blue", "Yellow", "Orange", "Pruple"};

char* NameSymbol[] = {"Rockstar Logo", "Rockstar Icon 2", "Rockstar Verified", "Wanted Star"};

char* OldName;

int NameSymbolsSelector;

int FontSelector = 0;

int NameFontSelector = 0;

int ColorSelector = 0;

int NameColorSelector = 0;

int MsgSelector = 0;

int ScenarioSelector = 0;

int ScenarioSelector2 = 0;

int ScenarioSelector3 = 0;

char* ScenariosNames[] = {"Coffee", "Smoke", "Binoculars" , "Freeway" , "Slumped" , "Standing" , "Cheering" , "Clipboard" , "Drill" , "Drinking" , "Drug Dealer" , "Golf" , "Hammering" , "Muscle Flex" , "Muscle Free Weights" , "Musician" , "Paparazzi" , "Picnic", "Yoga", "Welding"};

char* ScenariosList[] = {"WORLD_HUMAN_AA_COFFEE", "WORLD_HUMAN_AA_SMOKE", "WORLD_HUMAN_BINOCULARS" , "WORLD_HUMAN_BUM_FREEWAY" , "WORLD_HUMAN_BUM_SLUMPED" , "WORLD_HUMAN_BUM_STANDING" , "WORLD_HUMAN_CHEERING" , "WORLD_HUMAN_CLIPBOARD" , "WORLD_HUMAN_CONST_DRILL" , "WORLD_HUMAN_DRINKING" , "WORLD_HUMAN_DRUG_DEALER" , "WORLD_HUMAN_GOLF_PLAYER", "WORLD_HUMAN_HAMMERING", "WORLD_HUMAN_MUSCLE_FLEX", "WORLD_HUMAN_MUSCLE_FREE_WEIGHTS", "WORLD_HUMAN_MUSICIAN", "WORLD_HUMAN_PAPARAZZI", "WORLD_HUMAN_PICNIC", "WORLD_HUMAN_YOGA", "WORLD_HUMAN_WELDING" };

bool PauseModeTeleportating = true;

int MENU_BUTTONS[2] = {204, 177};

int testFix5 = 0;

int testFix8 = 0;

int CnetFrameTimer = 0;

int OpenMenuTimer = 0;

int OpenMenuTimerMax = 0;

int SelectorR = 255;

int SelectorG = 193;

int SelectorB = 0;

int SelectorOpacity = 255;

int optionsFont = 0;

char* Music = "NIGEL1C_START";

char MusicArray[50];

float optionsSize = 0.35f;

float optionsSize2 = 0.35f;

float TitleSize = 1.1500;

int maxOptions = 12;

float infoheight = 0.034f;

float SideBox = 0.378f;

float MiddleLines = 0.378f;

float LeftInfoText = 0.275f;

float LeftInfoResult = 0.374f;

float RightInfoText = 0.3800f;

float RightInfoResult = 0.4800f;

float menuXCoord = 0.154f;

float optionCountx = 0.260f;

float checky = 0.165f;

float onOffX = 0.2450f;

float textXCoord = 0.070f;

float subTitleX = 0.045;

float subTitleY = 0.1465;

bool DrawGlare = true;

float charText = 0.260f;

int AddCombination = 0;

int BOTTOMTEXT = 0;

int MobileOffset;

int MobileOffsetCheck;

int SocketCountry;

int SocketAll;

int SocketCity;

int SocketPROXY;

int MaxCount = 0;

int SocketISP;

float NewOptionCoord = 0.0;

float test = 1.0000;

char* GetStr;

float fnitialDragCoeffOutput = 0.0;

bool TriggerBot;

int TriggerBotNum = 1;

bool HashGun;

int VehR, VehG, VehB;

bool RainbowColor;

bool BoostGun;

bool AutoRemoveScratches;

bool SlingShot;

bool FreezeMyVehicle;

bool ForceGun;

int grav_partfx = 0;

bool ExplosiveBullets;

bool WeaponPowerfullGuns;

bool InfiniteAmmo;

bool FreezeAttach;

int FreezeAttachTimer = 0;

int FreezeAttachAddr;

int DropKickProtAddr1;

int DropKickProtAddr2;

bool TeleportGun =false;

bool TeleportGun1 =false;

bool DeleteGun;

bool SlowMotionGun;

int ExplosiveBulletsNum = 16;

bool CheckAvailableUpdate= false;

int CheckAvailableUpdateTimer= 0;

const char* NewUpdate;

int SaveVar=0;

float LoadingTimer = 0.0;

bool SuperMan;

bool SuperJump;

bool super_check;

float TestXMove = 0;

float UIIP[5];

int CurrVeh;

bool MuteAll;

//bool IsModder;

bool DisableDetectedGodMode = true;

int inf = (int)-1U / 2 == (int)(-1U / 2) ? (int)-1U : (int)(-1U / 2);

bool IsInVeh;

bool WrapInSpawned = true;

bool SpawnerInvincible = true;

bool Vehicle_Invincible;

bool Vehicle_Invisibility;

float Vehicle_RPM = 100;

int pedanm;

bool StartAnim;

int AnimTypeMe = 1;

char* ANIM_STRING;

char* ANIMID_STRING;

int RealCurrentOption = 0;

bool EnableSounds = true;

float FloatPercent = 0.01;

unsigned char EncryptionKey[4] = { 0x00, 0x18, 0x22, 0xC7 };//001822C7

unsigned char EncryptionKey1[4] = { 0x00, 0x24, 0x78, 0xB9 };//002478B9

unsigned char EncryptionKey2[4] = { 0x00, 0x00, 0x01, 0x32 };//00000132

unsigned char EncryptionKey3[4] = { 0x00, 0x00, 0x00, 0xDF };//000000DF

unsigned char EncryptionKey4[4] = { 0x00, 0x10, 0x00, 0x44 };//00100044

unsigned char EncryptionKey5[4] = { 0x01, 0x3D, 0xF0, 0xC8 };//013DF0C8

unsigned char EncryptionKey6[4] = { 0x01, 0x59, 0xA6, 0x4C };//0159A64C

unsigned char EncryptionKey7[4] = { 0x01, 0x26, 0xAB, 0xF0 };//0126ABF0

unsigned char EncryptionKey8[4] = { 0x00, 0x4B, 0xB9, 0xB0 };//004BB9B0

unsigned char EncryptionKey9[4] = { 0x00, 0x4B, 0xB5, 0x58 };//004BB558

unsigned char EncryptionKey10[4] = { 0x00, 0x4B, 0xB3, 0xE0 };//004BB3E0

unsigned char EncryptionKey11[4] = { 0x04, 0x87, 0x1B, 0x83 };//04871B83

unsigned char EncryptionKey12[4] = { 0x01, 0x38, 0x9F, 0x63 };//01389F63

unsigned char EncryptionKey13[4] = { 0x00, 0x08, 0x79, 0x7F };//0008797F

unsigned char EncryptionKey14[4] = { 0x01, 0xF1, 0xD6, 0xEC };//01F1D6EC

unsigned char EncryptionKey15[4] = { 0x01, 0x00, 0x00, 0x00 };//01000000

bool LeftMenu = true;

bool GodMode;

bool Invisibility;

bool DisplayHost = true;

bool ShowFreeSlots = true;

bool ShowFPS = true;

bool BlockJoinNonHost;

bool PrologueDistance;

bool UndetectableGodMode = true;

int PlayerOpacity = 255;

bool NeverWanted;

bool SuperRun;

bool SettingsBoolSub[10]; 

bool ThermalVision;

bool NightVision;

int VisionTimer = 0;

bool VisionActive;

int NightTimer = 0;

bool NightActive;

int tick = 0;

int SnacksVar = 100;

int SmokesVar = 100;

int ArmorVar = 100;

int CashGiftVar = 3;

int CASH_GIFT_INT[] = {1000, 10000, 100000, 500000, 1000000, 2000000, 3000000, 6000000, 9000000, 30000000, 60000000, 90000000, 1000000000, 2147483647};

char* CASH_GIFT[] = {"1000", "10,000", "100,000", "500,000", "1,000,000", "2,000,000", "3,000,000", "6,000,000", "9,000,000", "30,000,000", "60,000,000", "90,000,000", "1,000,000,000", "2,147,483,647" };

int FireworksVar = 100;

int KillsVar = 100;

int DeathsVar = 100;

int KDRVar = 100;

int RecoveryRankOption[18];

int RecoveryMoneyOption[18];

int RecoveryCharacterSelector = 1;

int RecoveryStamina[18] = {100};

char* RecoveryCharacterSelectorChar[] = {"Character 1", "Character 2"};

float GetVehSpeed = 0;

float FloatPercentHandling = 0.1;

bool ExplosiveMelee;

bool CreateVehicle;

bool RequestModeloop;

bool RequestModelResult;

int RequestModelTimer = 0;

int ResetModelTimer;

bool DisconnectSess;

int DisconnectSessT;

bool LastChangeModel;

bool EnableWalkOnWater;

vector3 coordWater;

bool WalkOnWater;

bool  FolowWaves;

float  NewZ = 0;

float  zPlane = 0;

float  LastZ = 0;

bool EnableWW;

bool LastChangeModel2;

bool SlodFreezeProtection;//CRASH LOADING

bool PrologueTest;

int VehicleFreezeProtectionDelay;

int ScriptEntityPool = 0;

bool VehicleAttachProtection;

bool WarMode;

int LastChangedModel = 0;

const char* RecvMsgFromServer = "";

int RequestModelHash = 0;

bool FreezeSessionProtection;

bool ScriptHandlerProtection = true;

bool BlockEntities;

bool HostFreezeProtection;

bool WarProtection;

bool DeletePedsProtection;

int MisionsProtectionAddr = 0;

int PausedAddr = 0;

int DisGodmodeAddr = 0;

int CheckIsMobileAddr = 0;

bool RankDownAll;

bool RankUpAll;

int rankUP[17];

bool DropVars[20];

bool DropPickup;

int DropPickupModel;

int DropPickupBehavior;

int DropPickupAmount;

bool SpamMessages;

bool RemoveWantedLevel;

int rankDOWN[17];

bool ChronicleAll;

int cHRONtIMER;

int ScriptHandleFreezeInt = 1;

int ScriptHandleFreezeAddr = 0;

int PLAYER_INFO_R = 0;

int PLAYER_INFO_G = 0;

int PLAYER_INFO_B = 0;

int PLAYER_INFO_A = 120;

int PLAYER_INFO_LINE_R = 255;

int PLAYER_INFO_LINE_G = 255;

int PLAYER_INFO_LINE_B = 255;

int PLAYER_INFO_LINE_A = 120;

char* MobileScrenario;

bool MisionsProtection;

bool NoTimeout;

bool UnlockPrologue;

bool BlockEvents;

bool RespawnProtection;

bool UnknownFreezeProtection;

bool MobileFreezeProtection;

bool NonHostKickProtection;

bool DropKickProt = true;

float PlayerInfoLine0 = 0;

float PlayerInfoLine1 = 0;

float PlayerInfoLine2 = 0;

int HookAddr4;

bool FakeLeaveProtection;

bool BlockSendEventsData;

bool BlockRecieveEventsData;

int ProjEnt = 0;

int ProjectileSpeed = 0;

int ProjectilePlayerInt;

char* ProjectilePlayersChar[18];

bool ProjectileSpeedAct;

int sceneRocket;

int MoreTime;

char bufferMac[500];

bool SetBackgroundColour;

bool SetHeaderPriColour;

bool SetHeaderSecColour;

bool SetShadowColour;

bool SetCheckBoxsColour;

bool SetCheckBoxsOffColour;

bool SetSubtitleBoxsPriColour;

bool SetSubtitleBoxsSecColour;

bool SetScrollerColour;

bool SetTextsColour;

bool SetSelectedTextColour;

bool ShowCreatorVar;

int CrnR = 255;

	int CrnG = 255;

	int CrnB = 255;

int ShowCreditsAlpha = 255;

int ShowCreditsAlphaP1 = 200;

int ShowCreditsAlphaP3 = 0;

int ShowCreditsAlphaP2 = 0;

float ShowC_X = -0.1;

float ShowCText_X;

int TestVAR83;

float ShowC_XSize = 0.05;

bool EndOfCredits;

int EndOfCreditsTimer = 0;

char* test_text;

int DetactFromProjectileTimer = 0;

int AttachToProjectileTimer = 0;

int ObjectsProtectionDelayME = 0;

char GetOptionsCount[30];

int ToggleCount[15];

bool NoIdleKick = true;

bool SilentPhone;

bool BlockJoin;

bool Spectate;

bool BypassOnlineTut;

bool OffRadar;

bool DisableShit;

bool CreatedObj;

bool ConfirmDel;

bool ForceClearTasks;

bool TheMaster;

int testFix4 = 0;

int HostFreezeDelay = 0;

int NearPedsDelay = 0;

int NearVehDelay = 0;

int NearMarkerDelay = 0;

int NearEventsDelay = 0;

int NearAESPDelay = 0;

int VehWeapDelay = 0;

int AdminDelay = 0;

int StatsDelay = 0;

float currentheight;

int NearestCarInteger = 0;

char* NearestCarChar[] = {"Driver", "Passenger"};

vector3 coordsx;

float teleportheight = 875; // might have to add to this

bool boolTeleport;

int testFix7 = 0;

int EbootCheckerDelay  = 0;

bool FreezePosition;

bool HeroHealthRegeneration;

int HeroGenHealthTimer;

bool Suicide;

int TestFunc=0;

bool SearchingPatt;

bool SearchingPatt2 = true;

bool SearchForSPRX;

int HookAddress,Hook2Address,Hook3Address;

int KillYourSelfTimer;

bool SuperNoClip;

bool Forcefield;

bool UnfreezeNoClip;

int SPRX_Offset;

bool EnableNoClip;

int IPGrabber = 0;

bool IPGrabberDelayBoolean = true;

int IPGrabberDelay = 0;

bool GetIp;

bool buffchekContinent;

bool buffchek;

bool buffchekAll;

//char IPResolverV1Contry[50000];

//char IPResolverIPs[3][80000];

const char* NewString;

int sock_desc2;

int SocketContinent;

bool buffchekCity;

bool buffchekProxy;

const char* WelcomeMsg;

bool buffchekISP, buffchekIP;

const char* ISP,

	*Continent,

	*IP,

	*City;

int RDOffset = 0, RD1Offset = 0;

float gGlareDir;

bool AutoClearReports = true;

bool AutoKickModders;

int gGlareHandle; // int

int GlareAlpha = 0;

float GlareX = 0.5299, GlareY = 0.5510, GlareXs = 1.1749, GlareYs = 1.1620;

bool featureAdvanceNoClip;

bool HumanRocket;

int AttachObjectSel = 0;

char* AttachObjectType[] = {"Known Objects", "All Objects"};

bool AttachObjectsProtection;

bool BlockPlayersCoordinates;

bool BlockMessages;

char* TextPrintVariable = "";

char* PrintRectColorVariable = "grey";

int PrintTimerVariable = 0;

int PrintTimerVariable2 = 0;

char* PrintSaveTextVariable;

int PrintFontVariable= 0;

bool PrintDrawRectVariable = true;

bool PrintStatusVariable;

char PrintBuff[104];

float PrintSizeXVariable = 0.38;

bool CloneProtection;

bool PlayerAttachProtection;

int MethodProtectionFromPlayers = 2;

int AttachPlayerProTimer = 0;

float PrtotectTimer = 0;

vector3 SaveAnimFreeze;

int FreezeAnimationTimer = 0;

bool FreezeAnimation;

int FreezeAnimationPlayer;

bool LastAnimStep;

bool SessionFreezeV1;

bool ScorpionFreeze;

int ScorpionFreezeAddr;

int Scorpion2FreezeAddr;

int CLOTHES[13];//not

int CLOTHES2[13];//not

int SWITCH_DRAWABLE_VAR[12];

int SWITCH_TEXTURE_VAR[12];

int SWITCH_PALETTE_VAR[12];

int DRAWABLE_VAR[12];

int TEXTURE_VAR[12];

int PALETTE_VAR[12];

bool ChangeModel;

char* MODEL_STRING;

bool UseComponent;

bool UseComponent2;

bool ChangeModel2;

int timer;

bool TrapInCage;

char* SPAM_MSGSES[18];//NOT

int ESP_LINE_R = 255,

ESP_LINE_G = 0,

ESP_LINE_B = 0;

int rainmoneycooldown, rainmoneycooldown2, rainmoneycooldown3, ESP_Delay;

bool ChangeModel3;

bool SetPedDetails;

bool SetPedDetails2;

bool SetPedDetails3;

bool StartResetModel;

int StartPrint;

int MODEL_HASH;

int MODEL_HASH3;

int Walkonwater;

int Walkonair;

int Height = 200;

int obj;

int obj2;

int VisibleTimer = 0;

int player_count =0;

int tmp_player_ped = 0;

int* FRZBMX;

int CurrentModel;

int hookAddr = 0;

bool NoReload;

char* MenuTitle;

bool ClearTasksArgs;

bool WeatherArgs = true;

int addressEnt;

const char* TestMac;

float OptionsJumper = 0.0320;

float OptionsHeight = 0.0300;

float SubtitleHeight = .0345;

int FORMATING[29] = { 214, 195, 193, 171, 201, 214, 195, 193, 171, 201, 214, 195, 193, 171, 201, 214, 195, 193, 171, 201, 214, 195, 193, 171, 201, 214, 195, 193, 171,  };//%02X:%02X:%02X:%02X:%02X:%02X

int MAC[17] = { 181, 176, 201, 195, 181, 201, 182, 197, 201, 197, 177, 201, 195, 194, 201, 176, 197,  };//MAC ADDR

int MOBILEFREEZEPRO[8] = { 194, 202, 196, 192, 203, 197, 199, 203};//0x12D3018

int NEWPROTECTION[8] = { 193, 195, 198, 195, 199, 196, 196, 197 };//0x138E0C8

int BLOCKSENDEVENTS[8] = { 194, 195, 199, 202, 193, 195, 195, 199};//0xA01864

int BLOCKRECIEVEEVENTS[8] = { 194, 195, 198, 195, 195, 198, 202, 197 };//0xA01864

int SLOD_PROTECTION[8] = { 194, 202, 192, 203, 194, 202, 195, 203 };//0x127BE94

int BLOCKPLAYERSCOORDINATES[8] = { 193, 195, 194, 198, 197, 197, 193, 195};//0x13390CC

int NO_RELOAD[8] = { 194, 197, 197, 192, 196, 199, 197, 199 };//0x0FDDE18

int NO_RELOAD_DEFAULT[10] = { 193, 195, 203, 197, 202, 202, 198, 196, 197, 199, };

int CELLSCOR[12] = { 144, 150, 159, 159, 160, 144, 156, 129, 131, 154, 156, 157, };

int CellData[8] = { 144, 150, 159, 159, 183, 146, 135, 146, };

 char* SuperCars_ui[] = {

"Truffade Adder",

"Overflod Entity XF",

"Grotti Cheetah",

"Pegassi Infernus",

"Pegassi Vacca",

"Vapid Bullet",

"Coil Voltic",

"Pegassi Zentorno",

"Grotti Turismo R",

"Pegassi Osiris",

"Progen T20",

};

unsigned int SuperCars[11] = { 0xB779A091, 0xB2FE5CF9, 0xB1D95DA0, 0x18F25AC7, 0x142E0DC3, 0x9AE6DDA1, 0x9F4B77BE, 0xAC5DF515, 0x185484E1, 0x767164D6, 0x6322B39A };

char* VehicleSoundNames[] = {

"Reset",

"Asea",

"Banshee",

"Blista",

"Dominator",

"Elegy2",

"Infernus",

"Jester",

"Nine F",

"Sultan",

"Voltic",

"Zentorno",

};

int VehicleSoundCount = 12;

const float FuelStationsX[FUEL_STATION_COUNT] = {

49.4187f, 263.894f, 1039.958f, 1207.260f, 2539.685f, 2679.858f, 2005.055f, 1687.156f, 1701.314f,

179.857f, -94.4619f, -2554.996f, -1800.375f, -1437.622f, -2096.243f, -724.619f, -526.019f,

-70.2148f, 265.648f, 819.653f, 1208.951f, 1181.381f, 620.843f, 2581.321f, 176.631f, -319.292f,

1784.324f

};

const float FuelStationsY[FUEL_STATION_COUNT] = {

2778.793f, 2606.463f, 2671.134f, 2660.175f, 2594.192f, 3263.946f, 3773.887f, 4929.392f,

6416.028f, 6602.839f, 6419.594f, 2334.40f, 803.661f, -276.747f, -320.286f, -935.1631f,

-1211.003f, -1761.792f, -1261.309f, -1028.846f, -1402.567f, -330.847f, 269.100f, 362.039f,

-1562.025f, -1471.715f, 3330.55f

};

const float FuelStationsZ[FUEL_STATION_COUNT] = {

58.043f, 44.983f, 39.550f, 37.899f, 37.944f, 55.240f, 32.403f, 42.078f, 32.763f, 31.868f,

31.489f, 33.078f, 138.651f, 46.207f, 13.168f, 19.213f, 18.184f, 29.534f, 29.292f, 26.403f,

35.224f, 69.316f, 103.089f, 108.468f, 29.263f, 30.549f, 41.253f

};

char* SportsCars_ui[] = {

"Annis Elegy RH8",

"Hijak Khamelion",

"Grotti Carbonizzare",

"Benefactor Feltzer 1",

"Benefactor Feltzer 2",

"Dewbauchee Rapid GT 1",

"Inverto Coquette 1",

"Dewbauchee Rapid GT 2",

"Obey 9F Cabrio",

"Obey 9F",

"Benefactor Surano",

"Bravado Banshee",

"Pfister Comet",

"Benefactor Schwartzer",

"Schyster Fusilade",

"Bravado Buffalo",

"Bravado Buffalo 2",

"Maibatsu Penumbra",

"Karin Sultan",

"Karin Futo",

"Lampadati Furore GT",

"Dewbauchee Massacro 1",

"Dewbauchee Massacro 2",

"Dinka Jester 1",

"Dinka Jester 2",

"Enus Windsor",

"Albany Alpha",

"Karin Kuruma 1",

"Karin Kuruma 2",

};

char* SportsClassicCars_ui[] = {

"Inverto Coquette 2",

	"Inverto Coquette 3",

	"Truffade Z-Type",

	"Grotti Stinger GT",

	"Grotti Stinger",

	"Pegassi Monroe",

	"Dewbauchee JB 700",

	"Declasse Tornado 1",

	"Declasse Tornado 2",

	"Declasse Tornado 3",

	"Declasse Tornado 4",

	"Vapid Peyote",

	"Albany Manana",

	"Albany Virgo",

	"Albany Roosevelt",

	"Vapid Blade",

	"Benefactor Glendale",

	"Lampadati Pigalle",

	"Lampadati Casco",

	"Vapid Chino",

};

char* MuscleCars_ui[] = {

"Vapid Hotknife",

	"Bravado Gauntlet",

	"Declasse Vigero",

	"Vapid Dominator",

	"Albany Buccaneer",

	"Imponte Phoenix",

	"Declasse Sabre Turbo",

	"Imponte Ruiner",

	"Declasse Voodoo",

	"Cheval Picador",

	"Rat Loader 1",

	"Rat Loader 2",

};

char* Sedans_ui[] = {

"Enus Super Diamond",

	"Ubermacht Oracle 1",

	"Ubermacht Oracle 2",

	"Dundreary Stretch",

	"Cheval Fugitive",

	"Cheval Surge",

	"Benefactor Schafter",

	"Karin Asterope",

	"Karin Intruder",

	"Albany Washington",

	"Vapid Stanier",

	"Vulcan Ingot",

	"Albany Emperor 1",

	"Albany Emperor 2",

	"Albany Emperor 3",

	"Albany Primo",

	"Dundreary Regina",

	"Chariot Romero Hearse",

	"Obey Tailgater",

	"Declasse Premier",

	"Zirconium Stratum",

	"Declasse Asea 1",

	"Declasse Asea 2",

};

char* Coupes_ui[] = {

"Dewbauchee Exemplar",

	"Enus Cognoscenti Cabrio",

	"Lampadati Felon GT",

	"Lampadati Felon",

	"Ubermacht Zion Cabrio",

	"Ubermacht Zion",

	"Ubermacht Sentinel XS",

	"Ubermacht Sentinel",

	"Ocelot F620",

	"Ocelot Jackal",

};

char* Compacts_ui[] = {

"Karin Dilettante 1",

	"Karin Dilettante 2",

	"Weeny Issi",

	"Bollokan Prairie",

	"Dinka Blista",

	"Declasse Rhapsody",

	"Vulcar Warrener",

	"Benefactor Panto",

};

char* SUVnTrucks_ui[] = {

 "Gallivanter Baller 1",

	 "Gallivanter Baller 2",

	 "Obey Rocoto",

	 "Albany Cavalcade 1",

	 "Albany Cavalcade 2",

	 "Benefactor Dubsta 1",

	 "Benefactor Dubsta 2",

	 "Benefactor Dubsta 3",

	 "Benefactor Serrano",

	 "Dundreary Landstalker",

	 "Fathom FQ 2",

	 "Mammoth Patriot",

	 "Emperor Habanero",

	 "Vapid Radius",

	 "Declasse Granger",

	 "Canis Mesa 1",

	 "Canis Mesa 2",

	 "Canis Seminole",

	 "Canis Kalahari",

	 "Bravado Gresley",

	 "Karin BeeJay XL",

	 "Enus Huntley",

	 "Sadler 1",

	 "Sadler 2",

	 "Vapid Guardian",

	 "HVY Insurgent 1",

	 "HVY Insurgent 2",

	 "Karin Technical",

};char* OffRoads_ui[] = {

  "Monster Truck",

	 "Vapid Sandking XL",

	 "BF Dune Buggy",

	 "BF Dune 2 (Space Docker)",

	 "BF Injection",

	 "BF Bifta",

	 "Nagasaki Blazer 1",

	 "Nagasaki Blazer 2 (Trevors)",

	 "Canis Mesa (Merryweather)",

	 "Vapid Sandking SWB",

	 "Bravado Duneloader",

	 "Canis Bodhi",

	 "Declasse Rancher XL 1",

	 "Declasse Rancher XL 2",

	 "Karin Rebel 1",

	 "Karin Rebel 2",

	 "Nagasaki Blazer Lifeguard",

	 "Coil Brawler",

	 "Dinka Enduro",

};char* Vans_ui[] = {

  "Bravado Bison 1",

	 "Bravado Bison 2",

	 "Bravado Bison 3",

	 "Bravado Paradise",

	 "Zirconium Journey",

	 "Vapid Minivan",

	 "Vapid Bobcat XL",

	 "Bravado Rumpo 1",

	 "Bravado Rumpo 2",

	 "Brute Pony 1",

	 "Brute Pony 2",

	 "Declasse Burrito 1",

	 "Declasse Burrito 2",

	 "Declasse Burrito 3",

	 "Declasse Burrito 4",

	 "Declasse Burrito 5",

	 "Declasse Burrito 6",

	 "Declasse Burrito 7",

	 "Vapid Speedo 1",

	 "Vapid Speedo 2",

	 "Bravado Youga",

	 "Boxville 1",

	 "Boxville 2",

	 "Boxville 3",

	 "Boxville 4",

	 "Brute Camper",

	 "Taco Van",

	 "BF Surfer",

	 "BF Surfer (Rusted)",

	 "Vapid Slamvan 1",

	 "Vapid Slamvan 2",

};

char* EmergencyCars_ui[] = {

 "FIB",

	 "FIB SUV",

	 "Firetruck",

	 "Ambulance",

	 "Police 1",

	 "Police 2",

	 "Police 3",

	 "Police 4",

	 "Police Bike",

	 "Police Old 1",

	 "Police Old 2",

	 "Police Van",

	 "Swat Truck",

	 "Sheriff 1",

	 "Sheriff 2",

	 "Prison Bus",

	 "Park Ranger",

	 "Life Guard SUV",

};char* ServicVehicles_ui[] = {

 "Airport Bus",

	 "Dashhound",

	 "Bus",

	 "Rental Shuttle Bus",

	 "Tour Bus",

	 "Taxi",

};char* Military_ui[] = {

 "Rhino Tank",

	 "Barracks 1",

	 "Barracks 2",

	 "Barracks 3",

	 "Canis Crusader",

	 "Tanker 1",

	 "Tanker 2",

};

	 char* Motorcycles_ui[] = {

  "Nagasaki Carbon RS",

	 "Pegassi Bati 801RR",

	 "Pegassi Bati 801",

	 "LCC Hexer",

	 "LCC Innovation",

	 "Dinka Double-T",

	 "Dinka Thrust",

	 "Dinka Vindicator",

	 "Pegassi Ruffian",

	 "Shitzu Vader",

	 "Shitzu PCJ 600",

	 "Shitzu Hakuchou",

	 "Dinka Akuma",

	 "Maibatsu Sanchez (Decal)",

	 "Maibatsu Sanchez",

	 "Pegassi faggio",

	 "Western Daemon",

	 "Western Bagger",

	 "Principe Nemesis",

	 "Sovereign",

	 "Principe Lectro",

}; char* Bicycles_ui[] = {

  "Whippet Race Bike",

	 "Tri-Cycles Race Bike",

	 "Scorcher",

	 "Endurex Race Bike",

	 "Cruiser",

	 "BMX",

	 "Fixter",

};char* CommercialVehicles_ui[] = {

   "Maibatsu Mule 1",

	 "Maibatsu Mule 2",

	 "Maibatsu Mule 3",

	 "JoBuilt Phantom",

	 "Vapid Benson",

	 "MTL Packer",

	 "MTL Pounder",

	 "JoBuilt Hauler",

	 "Brute Stockade 1",

	 "Brute Stockade 2",

	 "HVY Biff",

	 "HVY Dump",

	 "HVY Dozer",

	 "HVY Forklift",

	 "HVY Handler",

	 "HVY Cutter",

	 "Utility Truck 1",

	 "Utility Truck 2",

	 "Utility Truck 3",

	 "Trashmaster 1",

	 "Trashmaster 2",

	 "Towtruck 1",

	 "Towtruck 2",

	 "TipTruck 1",

	 "TipTruck 2",

	 "Mixer 1",

	 "Mixer 2",

	 "Flatbed Truck",

	 "Airport Ripley",

	 "Rubble",

	 "Vapid Scrap Truck",

	 "Lawnmower",

	 "Dock Tug",

	 "Airport Tug",

	 "Tractor 1",

	 "Tractor 2",

	 "Tractor 3",

	 "Caddy 1",

	 "Caddy 2",

};char* Helicopters_ui[] = {

   "Annihilator",

	 "Buzzard Attack Chopper 1",

	 "Buzzard Attack Chopper 2",

	 "Frogger 1",

	 "Frogger 2",

	 "Maverick",

	 "Cargobob 1",

	 "Cargobob 2",

	 "Cargobob 3",

	 "Police Maverick",

	 "Swift 1",

	 "Swift 2",

	 "Buckingham Valkyrie",

	 "Savage",

};

	 char* Planes_ui[] = {

	"Titan",

	 "Buckingham Luxor 1",

	 "Buckingham Luxor 2",

	 "Buckingham Shamal",

	 "Buckingham Vestra",

	 "Buckingham Miljet",

	 "Velum 1",

	 "Velum 2",

	 "Mammatus",

	 "Duster",

	 "Mallard",

	 "Cuban 800",

	 "Cargo Plane",

	 "Blimp",

	 "P-996 Lazer",

	 "Skylift",

	 "Jet",

	 "Bersa",

	 "Mammoth Hydra",

};	 char* Boats_ui[] = {

	 "Dinka Marquis",

	 "Shitzu Jetmax",

	 "Shitzu Squalo",

	 "Shitzu Suntrap",

	 "Shitzu Tropic",

	 "Speedophile Seashark 1",

	 "Speedophile Seashark 2",

	 "Police Predator",

	 "Submarine",

	 "Pegassi Speeder",

	 "Nagasaki Dinghy 1",

	 "Nagasaki Dinghy 2",

	 "Nagasaki Dinghy 3",

	 "Lampadati Toro",

};char* Trailers_ui[] = {

	 "Army Tanker",

	 "Army Trailer 1",

	 "Army Trailer 2",

	 "Bale Trailer",

	 "Boat Trailer",

	 "Cablecar",

	 "Dock Trailer",

	 "Freight Car 1",

	 "Freight Car 2",

	 "Freight Container 1",

	 "Freight Container 2",

	 "Freight Train Boxcar",

	 "Grain Trailer",

	 "Metro Train",

	 "Mobile Home Trailer",

	 "Rake Trailer",

	 "Train Fuel Tank Car",

	 "Car Carrier Trailer",

	 "Marquis Trailer",

	 "Super Car Carrier Trailer",

	 "Trailer Logs",

	 "Trailers 1",

	 "Trailers 2",

	 "Trailers 3",

	 "Trailer Small",

	 "Trailer Flat",

	 "Tv Trailer",

};

int sports_h = 0;

int sportsc_h = 0;

int muscle_h = 0;

int super_h = 0;

int VehicleSoundSelector = 0;

// ---------------- SYSTEME ESSENCE (variables) ----------------

bool EnableFuelSystem = true;



// ---------------- SYSTEME USURE DES PNEUS (variables) ----------------

int TyreWheelIndexCar[4]  = { 0, 1, 4, 5 };

int TyreWheelIndexBike[2] = { 0, 1 };

float TyreWearPct[4]        = { 100.0f, 100.0f, 100.0f, 100.0f };

float TyreWearBaseRate      = 0.00075f;

float TyreWearCorneringMult = 0.05f;

float LastVehicleHeading    = -1.0f;

bool  TyreWearEnabled       = true;

int   TyreWearSpeedPct      = 100; // 100 = vitesse normale, 200 = deux fois plus vite, etc.

float TyreHudX = 0.90f;

float TyreHudY = 0.78f;

float TyreHudSpacingX = 0.030f;

float TyreHudSpacingY = 0.032f;

float TyreHudWidth  = 0.009f;

float TyreHudHeight = 0.040f;

float TyreHudCarWidth  = 0.028f;

float TyreHudCarHeight = 0.075f;



// ---------------- BARRE DE VITESSE ----------------

bool EnableSpeedBar = true;

bool EnableRingGauges = true;

float SpeedBarMaxKmh = 300.0f;

bool FuelEngineStutter = true;

bool FuelGasStationBlips = true;

bool FuelEmergencyWaypoint = true;

bool FuelAttendantNPC = true;

bool FuelSoundAlerts = true;

float FuelLevel = 100.0f;

float FuelConsumption = 0.6f;

int FuelRefillRate = 15;

int FuelLowThreshold = 15;

int FuelEmergencyThreshold = 8;

int FuelStationRadius = 10;

int FuelMinStart = 55;

int FuelMaxStart = 100;

int FuelLowStartChance = 15;

Vehicle FuelLastVehicle = 0;

float FuelVehTopSpeed = 40.0f;

bool FuelNearStation = false;

bool FuelEngineDegraded = false;

float FuelSavedEngineHealth = 1000.0f;

Ped FuelAttendantPed = 0;

bool FuelAttendantActive = false;

bool FuelBlipsCreated = false;

Blip FuelStationBlips[FUEL_STATION_COUNT] = {0};

bool FuelEmergencyWaypointSet = false;

bool FuelWasLow = false;

int FuelLastAlertTime = 0;

int sedans_h = 0;

int coupes_h = 0;

int offroads_h = 0;

int emerg_h = 0;

int service_h = 0;

int military_h = 0;

int motorcycles_h = 0;

int bicycles_h = 0;

int helicopters_h = 0;

int planes_h = 0;

int boats_h = 0;

int vans_h = 0;

int compacts_h = 0;

int suvs_h = 0;

int comme_h = 0;

int trailers_h = 0;

int trains_h = 0;

int utility_h = 0;

int properties_val[] = { 0, 61, 64, 63, 65, 62, 1, 3, 4, 2, 35, 36, 37, 43, 42, 41, 39, 40, 38, 6, 5, 7, 34, 24, 26, 27, 57, 56, 54, 66, 69, 68, 14, 11, 67, 13, 15, 16, 8, 9, 10, 12, 32, 25, 53, 33, 28, 55, 52, 50, 34, 70, 71, 72, 17, 21, 22, 18, 23, 20, 19, 60, 58, 59, 30, 47, 48, 29, 49, 51, 46, 44, 45 };

bool Allow18Player;

bool ObjectDetector;

int AttachedEntity;

bool GetAttachedEntity;

int GetAttachedEntityTimer;

bool ReadArgs;

bool ExitGameWhileCrashes = true;

// ---------------- SYSTEME TRANSMISSION MANUELLE (variables) ----------------

bool  EnableTransmissionSystem = true;

bool  TransWheelspinEnabled    = true;

int   TransShiftBoostLowKmh    = 26; // poussee reelle au passage vers les rapports 2 et 3

int   TransShiftBoostHighKmh   = 16; // poussee reelle au passage vers les rapports 4 et plus

int   TransDownshiftBrakeKmh   = 6;  // frein moteur reel a chaque retrogradage

float TransShakeIntensity      = 0.04f; // intensite de la secousse camera au changement de rapport

Vehicle TransLastVehicle       = 0;

int     TransCurrentGear       = 0; // -1 = marche arriere, 0 = point mort, 1..TRANS_GEAR_MAX = rapports avant

int     TransPreviousGear      = 0;

bool    TransStickUpLatched    = false;

bool    TransStickDownLatched  = false;

bool    TransLimiterActive     = false;

int     TransShiftKickUntil    = 0;

int     TransBelowStopSince    = 0; // 0 = pas actuellement sous le seuil d'arret

bool    TransEngineMisfireState = false;

bool    TransWheelspinPending  = false;

int     TransWheelspinEndAt    = 0;

float   TransVehTopSpeedMs     = 40.0f;

float TransGearFractions[7] = { 0.00f, 0.16f, 0.30f, 0.46f, 0.64f, 0.84f, 1.00f };

float TransGearCapsMs[7] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };


bool ReadCloneHandlerArgs;

bool ReadScriptHandlerArgs;

bool ReadUnkArgs;

bool ReadUnk2Args;

bool ReadUnk3Args;

bool ReadUnk4Args;

char* SenderObjName;

bool RedirectingEntity[10];

bool ForceRequestModel;

int ForceRequestModelTimer = 0;

int ForceRequestModelHash = 0;

bool IsAttachedObjectOnMe;

int Object_R6 = 5;

char* ObjectAttacker;

int ObjectAttackerID;

int BlockIt = 1;

unsigned int ObjectHashes[66] =

{

	0x97255A03,

	0x5DB600C9,//ind_prop_dlc_flag_02

	0x2BD57A5A,

	0xB2274905,

	0xC83B7CA7,

	0xADBC8AE3,

	0x6B795EBC,

	0x369D8410,

	0x558E77DA,

	0x9F984011,

	0x9866A5DB,

	0x830FADE4,

	0x63F9CEA3,//prop_beach_ring_01

	0x3C1B83BA,

	0x557C7587,//prop_trev_tv_01

	0x5C9F1C35,//prop_tv_test

	0x1405669B,

	0x1AFA6A0A,

	0x08DA1C0E,//prop_juicestand

	0xE2BA016F,

	3258159972,

	3760607069,

	3291218330,

	1228377684,

	3379896055,//unk

	3187083715,//unk

	3083173879,

	2365581599,

	2473165924,//unk

	1585260068,

	3885918439,

	4283117964,//unk

	2306058344,//unk

	2402097066,//unk

	1530424218,

	1022578470,

	238789712,

	3229200997,

	0x98EE1ACD,

	0xA7303751,

	0xB467C540,

	0x874B5974,

	0xC9751EF7,

	0xBDF709C3,

	0x93698464,

	0xFF4B318C,

	0x8973A868,

	0x8F2D17AA,

	0xC079B265,

	0xEDC48F9F,

	0x40F52369,

	0xED4D99B5,

	0x745F3383,

	0x614C63BD,

	0x27FE17FD,

	0xC2BC19CD,

	0x9A753742,

	0xB5D6F04D,

	0x34DCF0A3,

	0x7F2B2371,

	0x73E498DB,

	0x49344B5A,

	0x4D6410F7,

	0xC79A987E,

	0xA50DDDD0,

	0x35974C98

};

 char* TRAFFICLEVELS[5] = {"Default", "High", "Medium", "Low", "No Traffic"};

int TrafficLevels = 0;

bool GetEntitiesAddr;

int weather_h = 0;

int SetHour = 0;

int SetMin, SetSec;

int NextTime;

float WindSpeed = 0.0;

bool Thunder;

float TrafficLevel2 = 4.0;

bool SuperPunchBoolean;

bool DisplayCoordinates;

bool AdvancedESP;

bool AimbotToggle;

bool IsReady = true;

int DISPATCHOffset = 0;

int HandDamageOffset = 0;

int HandDamageAddr;

bool LoadSettings;

int FindAddresses = 0;

float BlockerFont = 0.35;

int SelectedCharR = 0;

int SelectedCharG = 0;

int SelectedCharB = 0;

int SelectedCharA = 255;

float SubtitleY = 0.1640;

int frametime = -1;

int fps = 30;

bool NetworkBoxInfo;

bool NetworkBoxInfoCoords;

float TextModderX = 0.3320;

float TextPlayerName = 0.3180;

float ShaderX_1 = 0.3100;

float ShaderX_2 = 0.3550;

float ShaderX_3 = 0.3170;

float TextModderY = 0.8000;

float TextPlayerNameY = 0.8100;

float ShaderY_1 = 0.8360;

float ShaderY_2 = 0.7940;

float ShaderY_3 = 0.8350;

float OtherText = 0.2300;

float InfoNetBoxX;

float InfoNetBoxY;

int AmmoTypeSelector = 0;

int AudioTypeSelector = 0;

int SlotTypeSelector = 0;

int GroupTypeSelector = 0;

int FlashFxTypeSelector = 0;

int FlashFxAltTypeSelector = 0;

int ShellFxTypeSelector = 0;

int TracerFxTypeSelector = 0;

int PedDamageHashTypeSelector = 0;

int VehicleWeaponHashTypeSelector = 0;

int DefaultCameraHashTypeSelector = 0;

int AssistedAimingCameraTypeSelector = 0;

int RecoilShakeHashTypeSelector = 0;

int HumanNameHashTypeSelector = 0;

int MovementModeConditionalTypeSelector = 0;

char* MovementModeConditionalType[] = { "MMI_Unarmed","MMI_1Handed","MMI_2Handed","MMI_2Handed_Short","MMI_MiniGun","Empty" };

char* HumanNameHashType[] = { "WT_UNARMED","WT_INVALID","WT_KNIFE","WT_NGTSTK","WT_HAMMER","WT_BAT","WT_GOLFCLUB","WT_CROWBAR","WT_PIST","WT_PIST_CBT","WT_PIST_AP","WT_PIST_50","WT_SMG_MCR","WT_SMG","WT_SMG_ASL","WT_RIFLE_ASL","WT_RIFLE_CBN","WT_RIFLE_ADV","WT_MG","WT_MG_CBT","WT_SG_PMP","WT_SG_SOF","WT_SG_ASL","WT_SG_BLP","WT_STUN","WT_SNIP_RIF","WT_SNIP_HVY","WT_SNIP_RMT","WT_GL","WT_GL_SMOKE","WT_RPG","WT_MINIGUN","WT_GNADE","WT_GNADE_STK","WT_GNADE_SMK","WT_BZGAS","WT_MOLOTOV","WT_FIRE","WT_PETROL","WT_DIGI","WT_NV","WT_PARA","WT_BALL","WT_FLARE","WT_V_TANK","WT_V_SPACERKT","WT_V_PLANEMSL","WT_V_PLRLSR","WT_V_PLRBUL","WT_V_LZRCAN","WT_A_ENMYLSR","WT_ELCFEN","Empty" };

char* AssistedAimingCameraType[] = { "Third Person", "Hip Assisted Aim", "Shotgun Assisted Aim", "RPG Assisted Aim", "Thrown Assisted Aim", "Empty" };

char* RecoilShakeHashType[] = { "Pistol Recoil Shake", "SMG Recoil Shake", "Assault Rifle Recoil", "MG Recoil Shake", "Shotgun Recoil Shake", "First Person Recoil", "Grenade Launcher Recoil", "RPG Recoil Shake", "Minigun Recoil Shake", "Tank Recoil Shake", "Empty" };

char* DefaultCameraHashType[] = { "Melee Camera", "Third Person Camera", "Hip Camera", "Shotgun Camera", "Sniper Low Zoom Cam", "Sniper Camera", "RPG Camera", "Thrown Camera", "Digi Scanner Cam", "Empty" };

char* VehicleWeaponHashType[] = { "Vehicle Tank", "Vehicle Rocket", "Vehicle Laser", "Vehicle Bullet", "Vehicle Enemy Laser", "Vehicle SearchLight", "Empty" };

char* PedDamageHashType[] = { "BulletSmall", "BulletLarge", "ShotgunLarge", "Empty" };

char* TracerFxType[] = { "bullet_tracer", "bullet_shotgun_tracer", "bullet_tracer_jet", "Empty" };

char* ShellFxType[] = { "eject_pistol", "eject_auto", "eject_shotgun", "eject_stungun", "eject_heli_gun" , "Empty" };

char* FlashFxAltType[] = { "muz_alternate_star", "muz_minigun_alt", "Empty" };

char* FlashFxType[] = { "muz_smg", "muz_pistol", "muz_assault_rifle", "muz_shotgun", "muz_stungun", "muz_alternate_star" , "muz_rpg" , "muz_minigun" , "weap_extinguisher" , "weap_petrol_can" , "muz_tank" , "muz_buzzard" , "muz_hunter" , "muz_laser" , "Empty" };

char* GroupType[] = { "Unarmed", "Melee", "Pistol", "SMG", "Rifle", "MG" , "Shotgun" , "Stungun" , "Sniper" , "Heavy" , "Thrown" , "Fire Extinguisher" , "Petrolcan" , "Digi Scanner" , "Night Vision", "Parachute" };

char* SlotType[] = { "Unarmed", "Knife", "Night Stick", "Hammer", "Bat", "Golf Club" , "Crow Bat" , "Pistol" , "Combat Pistol" , "AP Pistol" , "Pistol 50" , "Micro SMG" , "SMG" , "Assault SMG" , "Assault Rifle", "Carbine Rifle", "Advanced Rifle", "MG", "Combat MG", "Pump Shotgun", "Sawnoff Shotgun", "Assault Shotgun", "Bullpup Shotgun", "Stungun", "Sniper Rifle", "Heavy Sinper", "Grenade Launcher", "Grenade Launcher Smoke", "RPG", "Passenger Rocket", "Stinger", "Minigun", "Grenade", "Sticky Bomb", "Smoke Grenade", "BZGAS", "Molotov", "Fire Extinguisher", "Petrolcan", "Digi Scanner", "Night Vision", "Parachute", "Object", "Priefcase", "Ball", "Flare" };

char* AudioType[] = { "Pistol", "Combat Pistol", "AP Pistol", "Pistol 50", "Micro SMG" , "SMG" , "Assault SMG" , "Assault Rifle" , "Carbine Rifle" , "Advanced Rifle" , "MG" , "Combat MG" , "Pump Shotgun" , "Sawnoff Shotgun", "Assault Shotgun", "Pullpup Shotgun", "Stungun", "Sniper Rifle", "Heavy Sinper", "Remote Sniper", "Grenade Launcher", "RPG", "Minigun", "Grenade", "Sticky Bomb", "Smoke Grenade", "Molotov", "Petrolcan", "Vehicle Tank", "Vehicle Space Rocket", "Vehicle Bullet" };

char* AmmoType[] = { "Pistol", "SMG", "Rifle", "MG", "Shotgun" , "Stungun" , "Sniper" , "Sniper Remote" , "Fire Extinguisher" , "Petrolcan" , "Minigun" , "Grenade Launcher" , "Grenade Launcher Smoke" , "RPG", "Stinger", "Grenade", "Ball", "Sticky Bomb", "Smoke Grenade", "BZGAS", "Flare", "Molotov", "Tank", "Space Rocket", "Plane Rocket", "Player Laser", "Enemy Laser" };

char* AimingType[] = { "None", "None" };

int TestVariable0 = 0;

float TestVariable = 0;

int ConfigVar[20];

int LOGOffset;

char* TestVariable3;

char TextFromFile[50];

char TextFromFile2[50];

int TestVariable4 = 0;

int TestVariable5 = 0;

bool UseComponentExtra;

int TitleFont = 0;

int MalesVar = 0;

int PedsVar = 0;

int FemalesVar = 0;

int SinglePlayerVar = 0;

int MultiplayerVar = 0;

int CutsceneVar = 0;

int GangVar = 0;

int AnimalsVar = 0;

char *AnimalsChar[] = {"Rhesus Monkey", "Boar", "Chop", "Coyote", "Husky", "Mountain Lion", "Pig", "Retriever", "Rottweiler", "Shepherd", "Chimpanzee"};

char *AnimalsModels[] = {"a_c_rhesus", "a_c_boar", "a_c_chop", "a_c_coyote", "a_c_husky", "a_c_mtlion", "a_c_pig", "a_c_retriever", "a_c_rottweiler", "a_c_shepherd", "a_c_chimp"};

char *GangChar[] = {"Ballas", "Families", "Lost Girl", "Vagos", "Armboss", "Armgoon 1", "Armgoon 2", "Armlieut", "Azteca", "Chemwork", "Chiboss", "Chicold", "Chigoon 1", "Chigoon 2", "Korboss", "Mexboss 1", "Mexboss 2", "Ballaeast", "Ballaorig", "Ballasout", "Famca", "Famdnf", "Famfor", "Korean 1", "Korean 2", "Korlieut", "Lost 1", "Lost 2", "Lost 3", "Mexgang", "Mexgoon 1", "Mexgoon 2", "Mexgoon 3", "Pologoon 1", "Pologoon 2", "Salvaboss", "Salvagoon 1", "Salvagoon 2", "Salvagoon 3", "Strpunk 1", "Strpunk 2"};

char *GangModels[] = {"g_f_y_ballas_01", "g_f_y_families_01", "g_f_y_lost_01", "g_f_y_vagos_01",

	"g_m_m_armboss_01", 

	"g_m_m_armgoon_01",

	"g_m_y_armgoon_02",

	"g_m_m_armlieut_01", 

	"g_m_y_azteca_01", 

	"g_m_m_chemwork_01", 

	"g_m_m_chiboss_01", 

	"g_m_m_chicold_01", 

	"g_m_m_chigoon_01",

	"g_m_m_chigoon_02", 

	"g_m_m_korboss_01", 

	"g_m_m_mexboss_01",

	"g_m_m_mexboss_02",

	"g_m_y_ballaeast_01",

	"g_m_y_ballaorig_01",

	"g_m_y_ballasout_01",

	"g_m_y_famca_01",

	"g_m_y_famdnf_01",

	"g_m_y_famfor_01",

	"g_m_y_korean_01",

	"g_m_y_korean_02",

	"g_m_y_korlieut_01",

	"g_m_y_lost_01",

	"g_m_y_lost_02",

	"g_m_y_lost_03",

	"g_m_y_mexgang_01",

	"g_m_y_mexgoon_01",

	"g_m_y_mexgoon_02",

	"g_m_y_mexgoon_03",

	"g_m_y_pologoon_01",

	"g_m_y_pologoon_02",

	"g_m_y_salvaboss_01",

	"g_m_y_salvagoon_01",

	"g_m_y_salvagoon_02",

	"g_m_y_salvagoon_03",

	"g_m_y_strpunk_01",

	"g_m_y_strpunk_02",

};

char *CutsceneChar[] = {"Amanda De Santa", "Brad", "Brad cadaver", "Casey", "Dr Friedlander", "Floyd", "G", "Hao", "Hunter", "Jimmy", "Johnny Klebitz", "Lamar", "Lazlow", "Lester", "Prologue Driver", "Prolsec", "Reporter", "Siemon", "Tracy", "Wade"};

char *CutsceneModels[] = {"cs_amandatownley", "cs_brad", "cs_bradcadaver", "cs_casey", "cs_drfriedlander", "cs_floyd", "csb_g", "ig_hao", "ig_hunter", "ig_jimmydisanto", "ig_johnnyklebitz", "ig_lamardavis", "ig_lazlow", "ig_lestercrest", "csb_prologuedriver", "csb_prolsec", "csb_reporter", "ig_siemonyetarian", "ig_tracydisanto", "ig_wade"};

char *SinglePlayerChar[] = {"Michael", "Franklin", "Trevor"};

char *SinglePlayerModels[] = {"player_zero", "player_one", "player_two"};

char *MultiplayerChar[] = {"Freemode Female", "Freemode Male", "Armoured", "Claude", "Deadhooker", "Exarmy", "Famdd", "Fibsec", "Marston", "Misty", "Niko", "Pros", "Shopkeep", "Stripperlite"};

char *MultiplayerModels[] = {"mp_f_freemode_01", "mp_m_freemode_01", "mp_s_m_armoured_01", "mp_m_claude_01", "mp_f_deadhooker", "mp_m_exarmy_01", "mp_m_famdd_01", "mp_m_fibsec_01", "mp_m_marston_01", "mp_f_misty_01", "mp_m_niko_01", "mp_g_m_pros_01", "mp_m_shopkeep_01", "mp_f_stripperlite"};

bool Movement;

char* MOVEMENT;

int pedmv;

int Stripper = 1;

int NetStripper = 1;

int Injureed = 1;

int NetInjureed = 1;

int Flying = 1;

int NetFlying = 1;

int Sweep = 1;

int NetSweep = 1;

int Drunk = 1;

int NetDrunk = 1;

int Angry = 1;

int NetAngry = 1;

int Walk = 1;

int NetWalk = 1;

int Run = 1;

int NetRun = 1;

int Sports = 1;

int NetSports = 1;

int Dances = 1;

int NetDances = 1;

int Setting = 1;

int NetSetting = 1;

int LayDown = 1;

int NetLayDown = 1;

int Waves = 1;

int NetWaves = 1;

bool fpsbool;

int fpsgrab = 0;

int FixColorPicker = 0;

bool TeleportPlayerVehtoMe;

bool VehPlayerVeh;

bool BurnVeh;

bool KillEvVeh;

bool NoCollVeh;

bool NoCollic;

bool SlingshotVeh;

bool BoostVeh;

//int fps = 25;

int FrameCountPre;

int FrameCount;

int RVehWeap = 0, GVehWeap = 255, BVehWeap = 0;

bool request_model_looping;

bool request_entity_looping;

int request_model_handle = 0;

int request_entity_handle = 0;

bool SetVehColour;

float  InfoBoxYMax = 0.7260;

float  InfoBoxY = 0.7260;

float  InfoBoxXFix = 0.0745;

int request_model_timer = 0;

bool MaxUpgradesSettings;

int request_entity_timer = 0;

const char* SubTitleDispatch;

int Dispatch_VEH_Index = 0;

int Dispatch_PED_Index = 0;

int DispatchModels_SELECTOR = 0;

int DispatchModels_PED_MIN = 0;

int DispatchModels_PED_MAX = 0;

int DispatchModels_VEH_MIN = 0;

int DispatchModels_VEH_MAX = 0;

int DispatchModels_VEH_KEYBOARD = 0;

int DispatchModels_PED_KEYBOARD = 0;

int DispatchChecker = 0;

int DispatchCheckerPed = 0;

int DoesChangedVehicle[11];

int DoesChangedPed[11];

char *DispatchChar[] = { "Male Cop 1", "Male Cop 2", "Hway Cop", "Snow Cop", "Female Cop", "Swat", "Male Sheriff", "Female Sheriff", "Marine", "Paramedic", "Fireman", "Black Ops 1", "Black Ops 2", "Polo Goon"};

char* DispatchModels[] = { "csb_cop" , "s_m_y_cop_01", "s_m_y_hwaycop_01",  "s_m_m_snowcop_01", "s_f_y_cop_01", "S_M_Y_Swat_01", "s_m_y_sheriff_01", "s_f_y_sheriff_01", "s_m_m_marine_01", "s_m_m_paramedic_01", "s_m_y_fireman_01", "s_m_y_blackops_01", "s_m_y_blackops_02", "G_M_Y_PoloGoon_01"};

int VehicleModels_SELECTOR = 0;

char *VehicleChar[] = { "police (CAR)", "police2 (CAR)", "police3 (CAR)", "police4 (CAR)", "policeold1 (CAR)", "policeold2 (CAR)", "pranger (CAR)", "riot (CAR)", "sheriff (CAR)", "sheriff2 (CAR)", "policeb (BIKE)", "ambulance (CAR)", "policet (CAR)", "fbi (CAR)", "fbi2 (CAR)", "firetruk (CAR)", "lguard (CAR)", "pbus (CAR)", "mesa3 (CAR)", "predator (BOAT)", "cavalcade (CAR)", "annihilator (HELI)" , "polmav (HELI)", "crusader (CAR)", "savage (HELI)", "valkyrie (HELI)", "swift2 (HELI)", "swift (HELI)", "frogger (HELI)", "maverick (HELI)", "skylift (HELI)", "cargobob3 (HELI)", "cargobob2 (HELI)", "cargobob (HELI)", "buzzard2 (HELI)", "buzzard (HELI)", "squalo (BOAT)", "speeder (BOAT)", "marquis (BOAT)", "dinghy (BOAT)", "dinghy2 (BOAT)", "jetmax (BOAT)" , "tropic (BOAT)" , "seashark (BOAT)" , "seashark2 (BOAT)" , "toro (BOAT)", "sanchez (BIKE)", "sanchez2 (BIKE)" , "akuma (BIKE)" , "carbonrs (BIKE)" , "bagger (BIKE)" , "bati (BIKE)" , "sovereign (BIKE)", "lectro (BIKE)", "vindicator (BIKE)", "double (BIKE)" };

char *VehicleModels[] = { "police", "police2", "police3", "police4", "policeold1", "policeold2", "pranger", "riot", "sheriff", "sheriff2", "policeb", "ambulance", "policet", "fbi", "fbi2", "firetruk", "lguard", "pbus", "mesa3", "predator", "cavalcade", "annihilator" , "polmav", "crusader", "savage", "valkyrie", "swift2", "swift", "frogger", "maverick", "skylift", "cargobob3", "cargobob2", "cargobob", "buzzard2", "buzzard", "squalo", "speeder", "marquis", "dinghy", "dinghy2", "jetmax" , "tropic" , "seashark" , "seashark2" , "toro", "sanchez", "sanchez2" , "akuma" , "carbonrs" , "bagger" , "bati" , "sovereign", "lectro", "vindicator", "double" };

int ThemeRed,

ThemeGreen,

ThemeBlue,

ThemeAlpha;

int ThemeColorSel = 0;

char* THEME_COLORS[] = {"Background", "Player Marker", "Header Secondary", "Scroller", "Selected Char", "Options", "CheckBox On", "CheckBox Frame", "Subtitle Box Primary", "Subtitle Box Secondary", "Selected Text", "Player Info Background", "Player Info Lines" };

char *MalesChar[] = {"Swat", "Clown", "Super Hero", "Pogo", "Rambo", "Space Ranger", "Astronaut", "Assassin", "Justin", "Yeti", "Mime", "Cop", "Snow Cop", "Alien", "Zombie", "Old Naked Guy", "Old Man", "Break Dance", "George W", "Muscle Beach", "Biker", "Mummy", "Guard", "Chris Formage", "Clay", "Clay Pain", "Lost", "Lost 2", "Dude", "Surfer", "BOSS", "Thug", "Joker", "Gay", "Afriamer", "Doctor", "Priest", "Tyler Dix"};

char *MalesModels[] = {"s_m_y_swat_01", "s_m_y_clown_01", "u_m_y_imporage", "u_m_y_pogo_01", "u_m_y_babyd", "u_m_y_rsranger_01", "s_m_m_movspace_01", "mp_g_m_pros_01", "u_m_y_justin", "ig_orleans", "s_m_y_mime", "s_m_y_cop_01", "s_m_m_snowcop_01", "s_m_m_movalien_01", "u_m_y_zombie_01", "a_m_o_acult_01", "a_m_o_acult_02", "a_m_y_breakdance_01", "s_m_m_movprem_01", "a_m_y_musclbeac_01", "u_m_m_bikehire_01", "s_m_m_strperf_01", "s_m_m_prisguard_01", "ig_chrisformage", "ig_clay", "ig_claypain", "g_m_y_lost_01", "g_m_y_lost_03", "csb_porndudes", "a_m_y_surfer_01", "a_m_m_og_boss_01", "a_m_y_mexthug_01", "a_m_y_juggalo_01", "a_m_m_tranvest_01", "a_m_m_afriamer_01", "s_m_m_doctor_01", "ig_priest", "ig_tylerdix"};

char *PedestrianChar[] = {"Swat", "Clown", "Super Hero", "Pogo", "Rambo", "Space Ranger", "Astronaut", "Assassin", "Justin", "Yeti", "Mime", "Cop", "Snow Cop", "Alien", "Zombie", "Old Man", "Break Dance", "George W", "Muscle Beach", "Biker", "Mummy", "Guard", "Chris Formage", "Clay", "Clay Pain", "Lost", "Lost 2", "Dude", "Surfer", "BOSS", "Thug", "Joker", "Gay", "Afriamer", "Doctor", "Priest", "Tyler Dix", "Rhesus Monkey", "Chop", "Coyote", "Husky", "Mountain Lion", "Pig" , "Retriever" , "Rottweiler" , "Shepherd" , "Chimpanzee" };

char *PedestrianModels[] = {"s_m_y_swat_01", "s_m_y_clown_01", "u_m_y_imporage", "u_m_y_pogo_01", "u_m_y_babyd", "u_m_y_rsranger_01", "s_m_m_movspace_01", "mp_g_m_pros_01", "u_m_y_justin", "ig_orleans", "s_m_y_mime", "s_m_y_cop_01", "s_m_m_snowcop_01", "s_m_m_movalien_01", "u_m_y_zombie_01",  "a_m_o_acult_02", "a_m_y_breakdance_01", "s_m_m_movprem_01", "a_m_y_musclbeac_01", "u_m_m_bikehire_01", "s_m_m_strperf_01", "s_m_m_prisguard_01", "ig_chrisformage", "ig_clay", "ig_claypain", "g_m_y_lost_01", "g_m_y_lost_03", "csb_porndudes", "a_m_y_surfer_01", "a_m_m_og_boss_01", "a_m_y_mexthug_01", "a_m_y_juggalo_01", "a_m_m_tranvest_01", "a_m_m_afriamer_01", "s_m_m_doctor_01", "ig_priest", "ig_tylerdix", "a_c_rhesus", "a_c_chop", "a_c_coyote", "a_c_husky", "a_c_mtlion", "a_c_pig", "a_c_retriever", "a_c_rottweiler", "a_c_shepherd", "a_c_chimp"};

char *FemalesChar[] = {"Topless Girl", "Stripper", "Female With Skirt Up", "Classy Stripper", "Beach Girl", "Female Bodybuilder", "Indian Women", "Flabby woman", "Hippie Girl", "Joker", "Runner Girl", "Yoga Girl", "Maude", "Hillary Clinton", "Tonya", "Air Hostess", "Bartender Girl", "Baywatch", "Cop", "Factory", "Ranger", "Sheriff", "Stripperlite", "Biker Girl", "Corpse", "Old Woman", "Princess"};

char *FemalesModels[] = {"a_f_y_topless_01", "mp_f_stripperlite", "u_f_y_poppymich", "csb_stripper_02", "a_f_m_beach_01", "a_f_m_bodybuild_01", "a_f_o_indian_01", "a_f_m_fatcult_01", "a_f_y_hippie_01", "a_f_y_juggalo_01", "a_f_y_runner_01", "a_f_y_yoga_01", "ig_maude", "ig_mrsphillips", "ig_tonya", "s_f_y_airhostess_01", "s_f_y_bartender_01", "s_f_y_baywatch_01", "s_f_y_cop_01", "s_f_y_factory_01", "s_f_y_ranger_01", "s_f_y_sheriff_01", "s_f_y_stripperlite", "u_f_y_bikerchic", "u_f_y_corpse_02", "u_f_o_moviestar", "u_f_y_princess"};

 Hash WepArray[58] = { 0x99B507EA, 0x678B81B1, 0x4E875F73, 0x958A4A8F, 0x440E4788, 0x84BD7BFD, 0x1B06D571, 0x5EF9FEC4, 0x22D8FE39, 0x99AEEB3B, 0x13532244, 0x2BE6766B, 0xEFE7E2DF, 0xBFEFFF6D, 0x83BF0278, 0xAF113F99, 0x9D07F764, 0x7FD62962, 0x1D073A89, 0x7846A318, 0xE284C527, 0x9D61E50F, 0x3656C8C1, 0x5FC3C11, 0xC472FE2, 0xA284510B, 0x4DD2DC56, 0xB1CA77B1, 0x687652CE, 0x42BF8A85, 0x93E220BD, 0x2C3731D9, 0xFDBC8A50, 0xA0973D5E, 0x24B17070, 0x60EC506, 0x34A67B97, 0x23C9F95C, 0x497FACC3, 0xF9E6AA4B, 0x61012683, 0xD205520E, 0xBFD21232, 0x92A27487, 0x83839C4, 0xA89CB99E, 0xC0A3098D, 0x7F229F94, 0x7F7497E5, 0x787F0BB, 0xAB564B93, 0x63AB0442, 0x47757124, 0xA3D4D34, 0x3AABBBAA, 0xC734385A, 0xA3D4D34, 0xDC4DB296 };

 char* WEATHER_[13] = {"Blizzard", "Clear", "Clearing", "Clouds", "ExtraSunny", "Foggy", "Neutral", "Overcast", "Rain", "Thunder", "Smog", "Snow", "Xmas"};

 char* RecoveryRankChar[] = {"100","200", "300", "400", "500", "600", "700", "800", "900", "1000", "2000", "3000", "4000", "5000", "6000", "7000", "8000"};

 char* RecoveryMoneyChar[] = {"~g~$~w~1000","~g~$~w~10000", "~g~$~w~100000", "~g~$~w~1000000", "~g~$~w~10000000", "~g~$~w~100000000"};

 char* RecoveryMoneyValues[] = {"1000","10000", "100000", "1000000", "10000000", "100000000"};

 char* KeyboardResult;

 bool ChangeModelParticle;

 bool AnimFreezeStep;

 int AnimFreezeStepTimer = 0;

 //1 ,72 / 73 / 71 / 121 / 304 / 309 / 315 / 357 / 369 / 378 / 362/ 311

 int LocationsSel;

 int LocationsVaule[] = {1, 72 , 73 , 71 , 121 , 304 , 309 , 315 , 357 , 369 , 378 , 362 , 311 };

 char* Locations[] = {"Player", "Los Santos Customs", "Clothes", "Barber" , "Strip Club" , "GTA Online Mission" , "Race" ,"Race Car", "Garage", "Garage For Sale", "Team Deathmatch", "Masks", "Arm Wrestling" };