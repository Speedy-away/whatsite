void Float(float Val, bool center, float y, float scalex, float scaley, int r, int b, int g, int a)
{
	/*
	unsigned int drawWait;
	   unsigned int Timer;
	    GET_GAME_TIMER(&Timer);
	    if (Timer > drawWait) {
		drawWait = Timer + 50;
		  if (!IS_FONT_LOADED(font))
	      {
		  LOAD_TEXT_FONT(font);
	      }
		}
		*/
	SET_TEXT_FONT(optionsFont);
	SET_TEXT_SCALE(scalex, scaley);
	//SET_TEXT_RIGHT_JUSTIFY(true);
	if (currentOption == optionCount)
			{
				SET_TEXT_SCALE(0.38f, 0.38f);
				SET_TEXT_WRAP(0.1f, charText);
				SET_TEXT_COLOUR(255, 255, 255, 255);
				BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
				ADD_TEXT_COMPONENT_FLOAT(Val, 4);
				END_TEXT_COMMAND_DISPLAY_TEXT(0.150f, y, 0);
			}
			else
			{
				SET_TEXT_COLOUR(255, 255, 255, 255);
				BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
				ADD_TEXT_COMPONENT_FLOAT(Val, 4);
				END_TEXT_COMMAND_DISPLAY_TEXT(0.150f, y, 0);
				SET_TEXT_WRAP(0.1f, charText);
			}
}
void Text(int textType, const char * text, int font, float x, float y, float scalex, float scaley, int r, int g, int b, int a, bool center)//selected text colour
	{
	SET_TEXT_FONT(font);
	//SET_TEXT_BACKGROUND(0);
	SET_TEXT_DROPSHADOW(0, 0, 0, 0, 255);
	//SET_TEXT_EDGE(0, 0, 0, 0, 255);
    SET_TEXT_SCALE(scalex, scaley);
    SET_TEXT_PROPORTIONAL(1);
	SET_TEXT_COLOUR(r, g, b, a);
	if(center)
	SET_TEXT_CENTRE(center);
	if (textType == 1)
	{
		//SET_TEXT_BACKGROUND(1);
	}
	else if (textType == 2)
	{
		SET_TEXT_DROPSHADOW(1, 0, 0, 0, 255);
	}
	else if (textType == 3)
	{
		//SET_TEXT_EDGE(1, 0, 0, 0, 255);
	}
		BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
		
	SET_TEXT_WRAP(0.0f, 1.0f);
	
	}
	void TextOption(char * text, int font, float x, float y, float scalex, float scaley, int r, int g, int b, int a, bool center)//selected text colour
	{
		  
			SET_TEXT_FONT(font);
			SET_TEXT_SCALE(scalex, scaley);
			if(center)
			SET_TEXT_CENTRE(center);
			if (currentOption == optionCount)
			{
				SET_TEXT_WRAP(0.0f, 1.0f);
				SET_TEXT_COLOUR(SelectedTextR, SelectedTextG, SelectedTextB, SelectedTextA);
				
		BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
			}
			else
			{
				if ((r != 0) && (g != 0) && (b != 0))
				{
					//SET_TEXT_OUTLINE();
					SET_TEXT_DROPSHADOW(2, 0, 0, 0, 255);
				}
				else {
					//SET_TEXT_DROP_SHADOW();
					SET_TEXT_PROPORTIONAL(1);
					//SET_TEXT_JUSTIFICATION(1);
				}
				SET_TEXT_COLOUR(r, g, b, a);
				
		BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
				SET_TEXT_WRAP(0.0f, 1.0f);
			}
		
	}
//float WrapX = 0.260f, float Xcoord = -2.150f
void TextRight2(char *text, int font, float y, float scalex, float scaley, float WrapX, float Xcoord)// rainbow mode numbers
{
		SET_TEXT_FONT(font);
		//SET_TEXT_BACKGROUND(0);
		//SET_TEXT_EDGE(0, 0, 0, 0, 255);
		SET_TEXT_DROPSHADOW(0, 0, 0, 0, 255);
		SET_TEXT_SCALE(scalex, scaley);
		SET_TEXT_RIGHT_JUSTIFY(true);
		if (currentOption == optionCount)
		{
			SET_TEXT_WRAP(0.1f, WrapX);
			SET_TEXT_COLOUR(0, 0, 0, 255);
			
		BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		END_TEXT_COMMAND_DISPLAY_TEXT(Xcoord, y, 0);
		}
		else
		{
	
			SET_TEXT_WRAP(0.1f, WrapX);
			SET_TEXT_COLOUR(255, 255, 255, 255);
			
		BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		END_TEXT_COMMAND_DISPLAY_TEXT(Xcoord, y, 0);
		}
}
void TextRight3(char *text, int font, float y, float scalex, float scaley)// rainbow mode numbers
{
	   
		SET_TEXT_FONT(font);
		SET_TEXT_SCALE(scalex, scaley);
		SET_TEXT_RIGHT_JUSTIFY(true);
		if (currentOption == optionCount)
		{
			SET_TEXT_WRAP(0.1f, charText - 0.03);
			SET_TEXT_COLOUR(0, 0, 0, 255);
			
		BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		END_TEXT_COMMAND_DISPLAY_TEXT(-2.150f, y, 0);
		}
		else
		{
			SET_TEXT_DROPSHADOW(2, 0, 0, 0, 255);
			SET_TEXT_COLOUR(255, 255, 255, 255);
			
			BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		END_TEXT_COMMAND_DISPLAY_TEXT(-2.150f, y, 0);
			SET_TEXT_WRAP(0.1f, charText - 0.03);
		}
}

void drawFloatRight(float Value, bool center, float y, float scalex, float scaley, int r, int b, int g, int a)
{
		SET_TEXT_FONT(0);
		SET_TEXT_SCALE(scalex, scaley);
		SET_TEXT_COLOUR(r, g, b, a);
		SET_TEXT_RIGHT_JUSTIFY(true);
		SET_TEXT_WRAP(0.1f, charText);
		SET_TEXT_CENTRE(center);
		SET_TEXT_DROPSHADOW(0, 0, 0, 0, 0);
		BEGIN_TEXT_COMMAND_DISPLAY_TEXT("NUMBER");
		ADD_TEXT_COMPONENT_FLOAT(Value, 2);
		END_TEXT_COMMAND_DISPLAY_TEXT(0.150f, y, 0);
}
void drawFloat(float Val, bool center, float x, float y, float scalex, float scaley, int r, int b, int g, int a)
{
		SET_TEXT_FONT(0);
		SET_TEXT_SCALE(scalex, scaley);
		SET_TEXT_COLOUR(r, g, b, a);
		SET_TEXT_WRAP(0.0f, 1.0f);
		if(center)
		SET_TEXT_CENTRE(center);
		SET_TEXT_DROPSHADOW(0, 0, 0, 0, 0);	
		BEGIN_TEXT_COMMAND_DISPLAY_TEXT("NUMBER");
		ADD_TEXT_COMPONENT_FLOAT(Val, 4);
		END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
}
void drawInteger(int Val, int font,  float x, float y, float scalex, float scaley, int r, int b, int g, int a, int center)
{
	/*
	unsigned int drawWait;
	   unsigned int Timer;
	    GET_GAME_TIMER(&Timer);
	    if (Timer > drawWait) {
		drawWait = Timer + 50;
		  if (!IS_FONT_LOADED(font))
	      {
		  LOAD_TEXT_FONT(font);
	      }
		}
		*/
		SET_TEXT_FONT(font);
		SET_TEXT_SCALE(scalex, scaley);
		SET_TEXT_COLOUR(r, g, b, a);
		SET_TEXT_WRAP(0.0f, 1.0f);
		if(center)
		SET_TEXT_CENTRE(center);
		SET_TEXT_DROPSHADOW(0, 0, 0, 0, 0);
		BEGIN_TEXT_COMMAND_DISPLAY_TEXT("NUMBER");
		ADD_TEXT_COMPONENT_INTEGER(Val);
		END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
}
void drawTextRightJustify(char * text, int font, float x, float y, float scalex, float scaley, int r, int b, int g, int a, int vari)
{
	/*
	unsigned int drawWait;
	   unsigned int Timer;
	    GET_GAME_TIMER(&Timer);
	    if (Timer > drawWait) {
		drawWait = Timer + 50;
		  if (!IS_FONT_LOADED(font))
	      {
		  LOAD_TEXT_FONT(font);
	      }
		}
		*/
		SET_TEXT_FONT(font);//0.4755
		SET_TEXT_SCALE(scalex, scaley);
		//SET_TEXT_OUTLINE();
		SET_TEXT_DROPSHADOW(2, 0, 0, 0, 255);
		SET_TEXT_RIGHT_JUSTIFY(true);
		SET_TEXT_WRAP(0.0f, x);
		//SET_TEXT_COLOUR(255, 255, 255, 255);
		SET_TEXT_COLOUR(r, g, b, a);
		BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
}
// SET_TEXT_USE_UNDERSCORE( 1 );
void drawTextOption(char * text, int font, float x, float y, float scalex, float scaley, int r, int g, int b, int a, bool center)//selected text colour
	{
			SET_TEXT_FONT(font);
			SET_TEXT_BACKGROUND(0);
			SET_TEXT_EDGE(0, 0, 0, 0, 255);
			SET_TEXT_DROPSHADOW(0, 0, 0, 0, 255);
			SET_TEXT_SCALE(scalex, scaley);
			if(center)
			SET_TEXT_CENTRE(center);
			
			if (currentOption == optionCount)
			{
				SET_TEXT_EDGE(1, 255, 0, 0, 255);
				SET_TEXT_WRAP(0.0f, 1.0f);
				SET_TEXT_COLOUR(SelectedTextR, SelectedTextG, SelectedTextB, SelectedTextA);
				
				BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
				ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
				END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
			}
			else
			{
				if ((r != 0) && (g != 0) && (b != 0))
				{
					//SET_TEXT_DROPSHADOW(0, 0, 0, 0, 255);
				}
				else {
					//SET_TEXT_PROPORTIONAL(1);
				}
				SET_TEXT_PROPORTIONAL(1);
				SET_TEXT_COLOUR(r, g, b, a);
				BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
				ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
				END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
				SET_TEXT_WRAP(0.0f, 1.0f);
			}
		
	}

void drawTextOption2(char * text, int font, float x, float y, float scalex, float scaley, int r, int g, int b, int a, bool center)//selected text colour
{
	   
		SET_TEXT_FONT(font);
		SET_TEXT_SCALE(scalex, scaley);
		if(center)
		SET_TEXT_CENTRE(center);
		SET_TEXT_COLOUR(r, g, b, a);
		SET_TEXT_OUTLINE();
		if ((r != 0) && (g != 0) && (b != 0))
		{
			//SET_TEXT_OUTLINE();
			SET_TEXT_DROPSHADOW(2, 0, 0, 0, 255);
		}
		else {
			SET_TEXT_PROPORTIONAL(1);
		}
		
		BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0);
	
	
		SET_TEXT_WRAP(0.0f, 1.0f);
}

