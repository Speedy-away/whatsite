bool test_func;
int keyboardAction;
char keyboardActive = 0;bool godmode;
bool superrun;
int *keyboardVar = 0;
bool SelectedItem;


char* TITLE_MENU = "RFOoDxMoDz's ";

int BKG_R = 0;

int BKG_G = 0;

int BKG_B = 0;

int BtnR = 41,

    BtnG = 68,

    BtnB = 243;

int BtnA = 170;

bool RespawnProtection = false;

bool DropKickProtection = false;

bool FakeLeaveProtection = false;

bool UnknownFreezeProtection = false;

char* status;

int ScrollerR = 255;//50, 24, 58

int ScrollerG = 255;//50, 24, 58

int ScrollerB = 255;//50, 24, 58

int ScrollerA = 255;//50, 24, 58

int BannerR = 250;

int BannerG = 0;

int BannerB = 0;

int BannerA = 240;

int BannerRX = 163;

int BannerGX = 0;

int BannerBX = 0;

int BannerAX = 240;

int BannerRX1 = 0;

int BannerGX1 = 40;

int BannerBX1 = 125;

int BannerAX1 = 240;

int SelClrR = 255;

int SelClrG = 255;

int SelClrB = 0;

int scalex_ = 0;

int scaley_ = 0;

int TitleFont = 1;

int OptionsFont = 0;

int SRL_R = 255;

int SRL_G = 255;

int SRL_B = 255;

int TITLE_R = 255;

int TITLE_G = 255;

int TITLE_B = 255;

int gGlareHandle; // int

int maxTimerCount;

int timer = 0;

int TextTimer = 0,

    CreditTextTimer = 0,

    NumMenu = 0,

    NumMenuLevel,

    lastNumMenu[20],

    lastOption[20],

    currentOption,

    optionCount,

    SELECTED_INDEX,

    buttonID,

    maxOptions = 10,

    player_count =0,

    tmp_player_ped,

    Model;

int  FreezeHost;

unsigned char EncryptionKey[4] = { 0x00, 0x9F, 0xB8, 0xF8 }; //009FB8F8

unsigned char EncryptionKey1[4] = { 0x01, 0x1B, 0x1C, 0xF4 };//011B1CF4

unsigned char EncryptionKey2[4] = { 0x01, 0xE7, 0x0D, 0x78 };//01E70D78

unsigned char EncryptionKey3[4] = { 0x01, 0xEA, 0x9B, 0xEC };//01EA9BEC

unsigned char EncryptionKey4[4] = { 0x00, 0x9D, 0xDF, 0x0C };//009DDF0C

unsigned char EncryptionKey5[4] = { 0x01, 0x3D, 0xF0, 0xC8 };//013DF0C8

unsigned char EncryptionKey6[4] = { 0x01, 0x59, 0xA6, 0x4C };//0159A64C

unsigned char EncryptionKey7[4] = { 0x01, 0x26, 0xAB, 0xF0 };//0126ABF0

unsigned char EncryptionKey8[4] = { 0x00, 0x4B, 0xB9, 0xB0 };//004BB9B0

unsigned char EncryptionKey9[4] = { 0x00, 0x4B, 0xB5, 0x58 };//004BB558

unsigned char EncryptionKey10[4] = { 0x00, 0x4B, 0xB3, 0xE0 };//004BB3E0

char EncryptionString[23];

char EncryptionString1[2];

char EncryptionString2[11];

char EncryptionString3[6];

char EncryptionString4[4];

char EncryptionString5[11];

char EncryptionString6[18];

char EncryptionString7[22];

char EncryptionString8[23];

char EncryptionString9[20];

int instructCount;

int mov;

int GetR;

int GetG;

int GetB;

int GetA;

bool instructions = true;

bool instructionsSetupThisFrame;

bool xInstruction;

bool squareInstruction;

bool lrInstruction;

bool OutfitInstruction;

bool HostFreezeProtection = false;

bool WarProtection = false;

bool DeletePedsProtection = false;

bool AnimationsProtection = false;

bool MapFreezeProtection = false;

bool BlockEvents = true;

int MenuAlpha = 100;

bool SelectedItem4;

bool  PressX = false;

bool  rightPress = false;

bool  leftPress = false;

bool  fastRPress = false;

bool  fastLPress = false;

bool WhiteColor;

bool WhiteColor_toggle;

bool newTimerTick = true;

char* InfoText = "";

float

CenterDraw = 0.26f,

Menu_X = 0.758,

Title_X = 0.6350,

Cunt = 0.648,

CuntStat = 0.853,

Cunt2 = 0.633;

float X = 0.0f;

float Y = 0.0f;

float Z = 0.0f;

float gGlareDir;

float GlareX = 1.1449, GlareY = 0.4550, GlareXs = 1.1449, GlareYs = 0.8350;

int InfoTextR = 0;

int InfoTextG = 0;

int InfoTextB = 0;

int InfoTextA = 150;

float zcoord = 0;

int TimerZCoord;

int heading;

vector3 coordLoading;

bool FreezeSessionProtection = true;

bool BlockEntities = false;

int CrrdzY = 0;

bool ModelFreezeProtection = true;

int ModelFreezeProtectionTimer = 0;

bool FreezeGlitchforPlayers = false;

bool FreezeGlitchforPlayersCheck = false;

int FreezeGlitchforPlayersTimer = 0;

int FreezeGlitchforPlayersHandle[18];

bool FreezeGlitchforPlayersDelete = false;

vector3 Savecoord0;

bool FreezeGlitchforPlayers2 = false;

bool FreezeGlitchforPlayersCheck2 = false;

int FreezeGlitchforPlayersTimer2 = 0;

int FreezeGlitchforPlayersHandle2[18];

bool FreezeGlitchforPlayersDelete2 = false;

vector3 Savecoord1;

bool StartMaster0 = false;

bool StartMasterCheck0 = false;

int StartMasterTimer0 = 0;

bool StartMaster1 = false;

bool StartMasterCheck1 = false;

int StartMasterTimer1 = 0;