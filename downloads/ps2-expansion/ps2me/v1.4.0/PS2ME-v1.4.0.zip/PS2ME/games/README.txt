Put your J2ME MIDlets (.jar files) in this folder.
