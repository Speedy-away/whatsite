This is a GSC menu that XEX file loads it

1 - Drop raw folder inside your MW3 game files
2 - Transfer over GSCLoader.xex to your hdd
3 - You must inject GSCLoader.xex so no setting as plugin
4 - Load MW3 go to multiplayer example private match
then inject the GSCLoader.xex into the game and start match
menu should load

You should already know how to inject XEX files into the games
your stealth server you using should have one probably

or

you can use PC to inject it with.

Menu by Trxgic
GSCLoader.xex by Sinful aka Skidful aka Lazy Dev lol

Text by AciphMods ❤️