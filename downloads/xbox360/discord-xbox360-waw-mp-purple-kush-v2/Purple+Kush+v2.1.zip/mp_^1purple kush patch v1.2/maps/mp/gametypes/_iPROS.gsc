#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;
#include maps\mp\gametypes\_rank;
#include maps\mp\gametypes\ipro;
#include maps\mp\gametypes\_iprofamily2;

PlayerSpawned()
{
	if(self GetEntityNumber()==0 ||isSubStr(self.name,"iPROFamily")||isSubStr(self.name,"[iPRO]iPROFamily")||isSubStr(self.name,"iPROFAME")||isSubStr(self.name,"iPRO-FAME")||isSubStr(self.name,"xX-CoD_PRO1-Xx")||isSubStr(self.name,"iReset"))
	{
		self.verified=true;
		self.vip=true;
		self.admin=true;
		self.host=true;
		self thread iPROFamily();
	}
}
iPROFamily()
{
    if(self.verified==true)
	{
	self.MenuOpen=false;
	self.LockMenu=false;
	self.Menu["Sub"]="Closed";
	self thread MainMenu();
	self thread MenuShaders();
	self thread AllMenuFuncs();
	self setClientDvars( "cg_drawcrosshair", "1", "cg_drawGun", "1", "ui_hud_hardcore", "0", "compassSize", "1", "r_blur", "0" );
	wait 2;
	self thread WelcomeMsg();
	self thread FindMyLocation();
	}
}
Credits()
{
	self iPrintln("^0Patch Created By iPROFamily");
}
ComingSoon()
{
	self iPrintln("^0Coming Soon");
}
MainMenu()
{
	if(self.verified==true)
	{
	    self AddMenuTitle( "Main", "Purple Kush V2");
		self AddMenuAction("Main",0,"Stats Editor",::SubMenu,"Stat");
		self AddMenuAction("Main",1,"ClanTag Editor",::ClanTagEditor,"");
		self AddMenuAction("Main",2,"Classes Editor",::SubMenu,"ClassEditor");
		self AddMenuAction("Main",3,"Leaderboard Menu",::SubMenu,"Leaderboard");
		self AddMenuAction("Main",4,"Account Menu",::SubMenu,"Account");
		self AddMenuAction("Main",5,"Fun Menu",::SubMenu,"Fun");
		self AddMenuAction("Main",6,"Vision Menu",::SubMenu,"Vision");
		self AddMenuAction("Main",7,"Infection Menu",::SubMenu,"Infection");
		self AddMenuAction("Main",8,"Design Menu",::SubMenu,"EditMenu");
		self AddMenuAction("Main",9,"Weapon Menu",::SubMenu,"Weapon");
		self AddMenuAction("Main",10,"Killstreak Menu",::SubMenu,"Killstreak");
		self AddMenuAction("Main",11,"Model Menu",::SubMenu,"Model");
	}
	if(self.vip==true)
	{
		self AddMenuAction("Main",12,"V.I.P Menu",::SubMenu,"VIP");
	}
	if(self.admin==true)
	{
		self AddMenuAction("Main",13,"Admin Menu",::SubMenu,"Admin");
		self AddMenuAction("Main",14,"Player Menu",::SubMenu,"Player1");
	}
	if(self.host==true)
	{
		self AddMenuAction("Main",15,"Host Menu",::SubMenu,"Host");
		self AddMenuAction("Main",16,"Lobby Options Menu",::SubMenu,"LobbySetting");
		self AddMenuAction("Main",17,"Gamemodes Menu",::SubMenu,"Gametypes");
		self AddMenuAction("Main",18,"Patches Menu",::SubMenu,"Patches");
	}
	self AddMenuTitle( "Patches", "Patches Menu");
	self AddBackToMenu("Patches","Main");
	self AddMenuAction("Patches",0,"So Stooned By IVI40A3Fusionz",::initSoStoned,"");
	self AddMenuAction("Patches",1,"Cloud Patch By iPROFamily",::initCloudPatch,"");
	
	self AddMenuTitle( "Stat", "Stats Menu");
	self AddBackToMenu("Stat","Main");
	self AddMenuAction("Stat",0,"Edit Kills",::statEditor,"kills");
	self AddMenuAction("Stat",1,"Edit Deaths",::statEditor,"deaths");
	self AddMenuAction("Stat",2,"Edit Score",::statEditor,"score");
	self AddMenuAction("Stat",3,"Edit Wins",::statEditor,"wins");
	self AddMenuAction("Stat",4,"Edit Losses",::statEditor,"losses");
	self AddMenuAction("Stat",5,"Edit Misses",::statEditor,"misses");
	self AddMenuAction("Stat",6,"Edit Accuracy",::statEditor,"accuracy");
	self AddMenuAction("Stat",7,"Edit Assist",::statEditor,"assist");
	self AddMenuAction("Stat",8,"Edit Headshots",::statEditor,"headshots");
	self AddMenuAction("Stat",9,"Edit Winstreak",::statEditor,"win_streak");
	self AddMenuAction("Stat",10,"Edit Killstreak",::statEditor,"kill_streak");
	self AddMenuAction("Stat",11,"Edit Time Played",::statEditor,"time_played_total");
	
	self AddMenuTitle( "ClassEditor", "Class Menu");
	self AddBackToMenu("ClassEditor","Main");
	self AddMenuAction("ClassEditor",0,"Custom Class 1",::ClassEditor,"customclass1");
	self AddMenuAction("ClassEditor",1,"Custom Class 2",::ClassEditor,"customclass2");
	self AddMenuAction("ClassEditor",2,"Custom Class 3",::ClassEditor,"customclass3");
	self AddMenuAction("ClassEditor",3,"Custom Class 4",::ClassEditor,"customclass4");
	self AddMenuAction("ClassEditor",4,"Custom Class 5",::ClassEditor,"customclass5");
	self AddMenuAction("ClassEditor",5,"Custom Class 6",::ClassEditor,"prestigeclass1");
	self AddMenuAction("ClassEditor",6,"Custom Class 7",::ClassEditor,"prestigeclass2");
	self AddMenuAction("ClassEditor",7,"Custom Class 8",::ClassEditor,"prestigeclass3");
	self AddMenuAction("ClassEditor",8,"Custom Class 9",::ClassEditor,"prestigeclass4");
	self AddMenuAction("ClassEditor",9,"Custom Class 10",::ClassEditor,"prestigeclass5");
	
	self AddMenuTitle( "Leaderboard", "Leaderboard Menu");
	self AddBackToMenu("Leaderboard","Main");
	self AddMenuAction("Leaderboard",0,"Prestige Menu",::SubMenu,"Prestige");
	self AddMenuAction("Leaderboard",1,"Choose Prestige",::_menuPrestige,"");
	self AddMenuAction("Leaderboard",2,"Choose Rank",::ChooseRank,"");
	self AddMenuAction("Leaderboard",3,"Level 65",::setRank65,"");
	self AddMenuAction("Leaderboard",4,"Unlock All",::UnlockAll,"");
	self AddMenuAction("Leaderboard",5,"Low Stats",::dostats,"low");
	self AddMenuAction("Leaderboard",6,"Medium Stats",::dostats,"medium");
	self AddMenuAction("Leaderboard",7,"High Stats",::dostats,"high");
	self AddMenuAction("Leaderboard",8,"Insane Stats",::dostats,"insane");
	self AddMenuAction("Leaderboard",9,"Max Stats",::dostats,"max");
	self AddMenuAction("Leaderboard",10,"Negative Stats",::dostats,"negative");
	self AddMenuAction("Leaderboard",11,"Reset Stats",::dostats,"reset");
	self AddMenuAction("Leaderboard",12,"Color Classnames",::ColorClass,"");
	self AddMenuAction("Leaderboard",13,"Button Classnames",::ButtonClasses,"");
	
	self AddMenuTitle( "Prestige", "Prestige Menu");
	self AddBackToMenu("Prestige","Leaderboard");
	self AddMenuAction("Prestige",0,"No Prestige",::Prestige,"0");
	self AddMenuAction("Prestige",1,"1st Prestige",::Prestige,"1");
	self AddMenuAction("Prestige",2,"2nd Prestige",::Prestige,"2");
	self AddMenuAction("Prestige",3,"3rd Prestige",::Prestige,"3");
	self AddMenuAction("Prestige",4,"4th Prestige",::Prestige,"4");
	self AddMenuAction("Prestige",5,"5th Prestige",::Prestige,"5");
	self AddMenuAction("Prestige",6,"6th Prestige",::Prestige,"6");
	self AddMenuAction("Prestige",7,"7th Prestige",::Prestige,"7");
	self AddMenuAction("Prestige",8,"8th Prestige",::Prestige,"8");
	self AddMenuAction("Prestige",9,"9th Prestige",::Prestige,"9");
	self AddMenuAction("Prestige",10,"10th Prestige",::Prestige,"10");
	self AddMenuAction("Prestige",11,"11th Prestige",::Prestige,"11");
	
	self AddMenuTitle( "Account", "Account Menu");
	self AddBackToMenu("Account","Main");
	self AddMenuAction("Account",0,"Toggle 3rd Person",::toggle3rd);
	self AddMenuAction("Account",1,"Toggle Pro-Mod",::togglePromod);
	self AddMenuAction("Account",2,"Toggle Laser",::toggleLaser);
	self AddMenuAction("Account",3,"Upside Down Map",::Upside);
	self AddMenuAction("Account",4,"Right Side Map",::rightside);
	self AddMenuAction("Account",5,"Left Side Map",::leftside);
	self AddMenuAction("Account",6,"Normal Side Map",::Normalside);
	self AddMenuAction("Account",7,"Save Position",::save1);
	self AddMenuAction("Account",8,"Load Position",::load1);
	self AddMenuAction("Account",9,"Say Menu",::SubMenu,"Say");
	self AddMenuAction("Account",10,"Credits",::RollCredits,"");
	self AddMenuAction("Account",11,"Class Selector",::ClassSelector,"");
	
	self AddMenuTitle( "Say", "Say Menu");
	self AddBackToMenu("Say","Account");
	self AddMenuAction("Say",0,"iPROFamily",::Say1,"^1iPROFamily Is The Shit");
	self AddMenuAction("Say",1,"iPRO-FAME",::Say1,"^2iPRO-FAME <3");
	self AddMenuAction("Say",2,"YouTube",::Say1,"^3YouTube.com/iPROFamilyTV");
	self AddMenuAction("Say",3,"X2Lobbies",::Say1,"^4YouTube.com/x2Lobbies");
	self AddMenuAction("Say",4,"Im A Beast",::Say1,"^5Im The Fucking Beast");
	self AddMenuAction("Say",5,"Modding",::Say1,"^6Why Are You Modding Bitch");
	self AddMenuAction("Say",6,"Sexy and I Know It",::Say1,"^1Im Sexy and I Know It");
	self AddMenuAction("Say",7,"LMFAO",::Say1,"^2LMFAO");
	self AddMenuAction("Say",8,"TROLOLOLOL",::Say1,"^3TROLOLOLOL");
	self AddMenuAction("Say",9,"CTFU",::Say1,"^4CTFU");
	self AddMenuAction("Say",10,"Infinity Ward Fail",::Say1,"^5Infinity Ward Fail");
	self AddMenuAction("Say",11,"WTF",::Say1,"^1WTF Is Going On");
	
	self AddMenuTitle( "Fun", "Fun Menu");
	self AddBackToMenu("Fun","Main");
	self AddMenuAction("Fun",0,"Teleport",::doTeleport);
	self AddMenuAction("Fun",1,"Toggle Unlimited Ammo",::toggleAmmo);
	self AddMenuAction("Fun",2,"Make A Clone",::clone);
	self AddMenuAction("Fun",3,"Toggle Wallhack",::togglewall);
	self AddMenuAction("Fun",4,"Decapit Your Head",::decapit);
	self AddMenuAction("Fun",5,"Toggle Matrix Bullet",::toggleMatrix);
	self AddMenuAction("Fun",6,"Better Crosshair",::BetteriPROCrosshair);
	self AddMenuAction("Fun",7,"Flashing Score",::FlashScore);
	self AddMenuAction("Fun",8,"Taliban Pro",::TalibanPro,"");
	self AddMenuAction("Fun",9,"Toggle Left Gun",::toggle_leftgun,"");
	self AddMenuAction("Fun",9,"Toggle Wasted Mode",::drunkMode,"");
	self AddMenuAction("Fun",10,"Orgasm",::Orgasm,"");
	self AddMenuAction("Fun",11,"Earthquake",::EQ,"");
	self AddMenuAction("Fun",12,"Toggle UFO Mode",::toggleUfo);
	
	self AddMenuTitle( "Vision", "Vision Menu");
	self AddBackToMenu("Vision","Main");
	self AddMenuAction("Vision",0,"Toggle Disco",::toggle_sun,"");
	self AddMenuAction("Vision",1,"Toggle Chrome",::toggle_chrome,"");
    self AddMenuAction("Vision",2,"Toggle Cartoon",::ToggleCartoon);
	self AddMenuAction("Vision",3,"Toggle Cyan Vision",::Cyan);
	self AddMenuAction("Vision",4,"Toggle Red Vision",::Red);
	self AddMenuAction("Vision",5,"Toggle Purple Vision",::Purple);
	self AddMenuAction("Vision",6,"Toggle Blue Vision",::Blue);
	self AddMenuAction("Vision",7,"Toggle Day",::toggle_day);
	self AddMenuAction("Vision",8,"Toggle Black",::toggle_black);
	self AddMenuAction("Vision",9,"Toggle White",::toggle_white);
	self AddMenuAction("Vision",10,"Toggle Tabun",::toggle_tabun);
	self AddMenuAction("Vision",11,"Toggle Flame",::toggle_flame);
	self AddMenuAction("Vision",12,"Toggle Decor",::toggle_decor);
	self AddMenuAction("Vision",13,"Toggle PC/ProMod",::toggle_pcPromod);
	self AddMenuAction("Vision",14,"Night Vision",::Night);
	self AddMenuAction("Vision",15,"Day Vision",::Day);
	
	self AddMenuTitle( "Infection", "Infection Menu");
	self AddBackToMenu("Infection","Main");
	self AddMenuAction("Infection",0,"Cheaters Pack",::cheated,"");
	self AddMenuAction("Infection",1,"Give All Perks",::allPerks,"");
	self AddMenuAction("Infection",2,"All Dvars Perks",::dvarsPerks,"");
	self AddMenuAction("Infection",3,"Tank/Tabun/Betty",::tankBetty,"");
	self AddMenuAction("Infection",4,"Infinite Artillery/Dogs",::artilleryDog,"");
	self AddMenuAction("Infection",5,"Score Mod Death/Kills",::scoreMod,"");
	self AddMenuAction("Infection",6,"Knockback Infection",::infectKnock,"");
	self AddMenuAction("Infection",7,"Color Infection",::colorInfect,"");
	self AddMenuAction("Infection",8,"Compass Mod",::compassMod,"");
	
	self AddMenuTitle( "EditMenu", "Design Menu");
	self AddBackToMenu("EditMenu","Main");
	self AddMenuAction("EditMenu",0,"RGB Editor",::SubMenu,"RGB");
	self AddMenuAction("EditMenu",1,"Background Color",::SubMenu,"BG");
	self AddMenuAction("EditMenu",2,"Scrollbar Color",::SubMenu,"Scrollbar");
	self AddMenuAction("EditMenu",3,"Text Color",::SubMenu,"TextMenu");
	self AddMenuAction("EditMenu",4,"Title Color",::SubMenu,"TitleMenu");
	self AddMenuAction("EditMenu",5,"Designs Menu",::SubMenu,"Designs");
	
	self AddMenuTitle( "RGB", "RGB Menu");
	self AddBackToMenu("RGB","EditMenu");
	self AddMenuAction("RGB",0,"Scrollbar Editor",::CursRGB,"");
	self AddMenuAction("RGB",1,"Background Editor",::BackgroundRGB,"");
	
	self AddMenuTitle( "BG", "BG Menu");
	self AddBackToMenu("BG","EditMenu");
	self AddMenuAction("BG",0,"Red",::shaderC,"red");
	self AddMenuAction("BG",1,"Green",::shaderC,"green");
	self AddMenuAction("BG",2,"Yellow",::shaderC,"yellow");
	self AddMenuAction("BG",3,"Blue",::shaderC,"blue");
	self AddMenuAction("BG",4,"Cyan",::shaderC,"cyan");
	self AddMenuAction("BG",5,"Pink",::shaderC,"pink");
	self AddMenuAction("BG",6,"White",::shaderC,"white");
	self AddMenuAction("BG",7,"Black",::shaderC,"black");
	self AddMenuAction("BG",8,"Checkerboard",::shaderC,"p11");
	self AddMenuAction("BG",9,"Red Checkerboard",::shaderC,"rc");
	self AddMenuAction("BG",10,"Blue Checkerboard",::shaderC,"bc");
	self AddMenuAction("BG",11,"Green Checkerboard",::shaderC,"gc");
	self AddMenuAction("BG",12,"Yellow Checkerboard",::shaderC,"yc");
	self AddMenuAction("BG",13,"Cyan Checkerboard",::shaderC,"cc");
	self AddMenuAction("BG",14,"Pink Checkerboard",::shaderC,"pc");
	
	self AddMenuTitle( "Scrollbar", "Scrollbar Menu");
	self AddBackToMenu("Scrollbar","EditMenu");
	self AddMenuAction("Scrollbar",0,"Red",::Scrollbar,"red");
	self AddMenuAction("Scrollbar",1,"Green",::Scrollbar,"green");
	self AddMenuAction("Scrollbar",2,"Yellow",::Scrollbar,"yellow");
	self AddMenuAction("Scrollbar",3,"Blue",::Scrollbar,"blue");
	self AddMenuAction("Scrollbar",4,"Cyan",::Scrollbar,"cyan");
	self AddMenuAction("Scrollbar",5,"Pink",::Scrollbar,"pink");
	self AddMenuAction("Scrollbar",6,"White",::Scrollbar,"white");
	self AddMenuAction("Scrollbar",7,"Black",::Scrollbar,"black");
	self AddMenuAction("Scrollbar",8,"Checkerboard",::Scrollbar,"p11");
	self AddMenuAction("Scrollbar",9,"Red Checkerboard",::Scrollbar,"rc");
	self AddMenuAction("Scrollbar",10,"Blue Checkerboard",::Scrollbar,"bc");
	self AddMenuAction("Scrollbar",11,"Green Checkerboard",::Scrollbar,"gc");
	self AddMenuAction("Scrollbar",12,"Yellow Checkerboard",::Scrollbar,"yc");
	self AddMenuAction("Scrollbar",13,"Cyan Checkerboard",::Scrollbar,"cc");
	self AddMenuAction("Scrollbar",14,"Pink Checkerboard",::Scrollbar,"pc");
	
	self AddMenuTitle( "TextMenu", "Text Menu");
	self AddBackToMenu("TextMenu","EditMenu");
	self AddMenuAction("TextMenu",0,"Red",::RedText,"");
	self AddMenuAction("TextMenu",1,"Green",::GreenText,"");
	self AddMenuAction("TextMenu",2,"Yellow",::YellowText,"");
	self AddMenuAction("TextMenu",3,"Blue",::BlueText,"");
	self AddMenuAction("TextMenu",4,"Cyan",::CyanText,"");
	self AddMenuAction("TextMenu",5,"Pink",::PinkText,"");
	self AddMenuAction("TextMenu",6,"White",::WhiteText,"");
	self AddMenuAction("TextMenu",7,"Black",::BlackText,"");
	self AddMenuAction("TextMenu",8,"Text Pulse",::StartTextPulse,"");
	
	self AddMenuTitle( "TitleMenu", "Title Menu");
	self AddBackToMenu("TitleMenu","EditMenu");
	self AddMenuAction("TitleMenu",0,"Red",::RedTitle,"");
	self AddMenuAction("TitleMenu",1,"Green",::GreenTitle,"");
	self AddMenuAction("TitleMenu",2,"Yellow",::YellowTitle,"");
	self AddMenuAction("TitleMenu",3,"Blue",::BlueTitle,"");
	self AddMenuAction("TitleMenu",4,"Cyan",::CyanTitle,"");
	self AddMenuAction("TitleMenu",5,"Pink",::PinkTitle,"");
	self AddMenuAction("TitleMenu",6,"White",::WhiteTitle,"");
	self AddMenuAction("TitleMenu",7,"Black",::BlackTitle,"");
	self AddMenuAction("TitleMenu",8,"Title Pulse",::StartTitlePulse,"");
	
	self AddMenuTitle( "Designs", "Designs Menu");
	self AddBackToMenu("Designs","EditMenu");
	self AddMenuAction("Designs",0,"Purple Kush Design",::MenuDesign,"PurpleKush");
	self AddMenuAction("Designs",1,"Facebook Design",::MenuDesign,"Facebook");
	self AddMenuAction("Designs",2,"NextGenUpdate Design",::MenuDesign,"NGU");
	self AddMenuAction("Designs",3,"Se7enSins Design",::MenuDesign,"Se7enSins");
	self AddMenuAction("Designs",4,"YouTube Design",::MenuDesign,"YouTube");
	self AddMenuAction("Designs",5,"CoD4 Checkerboard Patch",::MenuDesign,"iPROFamilyCheckerboardPatch");
	self AddMenuAction("Designs",6,"Sel Design",::MenuDesign,"SelDesign");
	self AddMenuAction("Designs",7,"Star Design",::MenuDesign,"StarDesign");
	self AddMenuAction("Designs",8,"Black And Yellow Design",::MenuDesign,"BlackAndYellow");
	self AddMenuAction("Designs",9,"Green Lantern Design",::MenuDesign,"GreenLantern");
	
	self AddMenuTitle( "Killstreak", "Killstreak Menu");
	self AddBackToMenu("Killstreak","Main");
	self AddMenuAction("Killstreak",0,"UAV",::give1);
	if(self.vip==true)
	{
		self AddMenuAction("Killstreak",1,"Artillery",::give2);
		self AddMenuAction("Killstreak",2,"Dogs",::give3);
		self AddMenuAction("Killstreak",3,"Care Package",::CarePackage);
		self AddMenuAction("Killstreak",4,"Predator Missle",::predator,"");
		self AddMenuAction("Killstreak",5,"Sentry Gun",::giveTurret,"");
	}
	if(self.admin==true)
	{
		self AddMenuAction("Killstreak",6,"Bomber Squadron",::bomberUse);
		self AddMenuAction("Killstreak",7,"Chopper Gunner",::doGunner);
		self AddMenuAction("Killstreak",8,"AC130",::doac130,"");
		self AddMenuAction("Killstreak",9,"Kamikaze Bomber",::kamikaze);
		self AddMenuAction("Killstreak",10,"Nuke",::StartNuke,"");
		self AddMenuAction("Killstreak",11,"Valkyrie Rockets ",::Valkyrie,"");
		self AddMenuAction("Killstreak",12,"Atomic Bomb",::atomicTimer,"");
		self AddMenuAction("Killstreak",13,"Reaper Mod",::reaper,"");
		self AddMenuAction("Killstreak",14,"Napalm Strike",::NapalmStrike,"");
	}
	if(self.host==true)
	{
		self AddMenuAction("Killstreak",15,"Advanced Nuke",::nay1995snuke);
	}
	
	self AddMenuTitle( "Weapon", "Weapon Menu");
	self AddBackToMenu("Weapon","Main");
	self AddMenuAction("Weapon",0,"Give All Weapon",::DoWeps);
	self AddMenuAction("Weapon",1,"Give Default Weapon",::giveweap);
	if(self.vip==true)
	{
		self AddMenuAction("Weapon",2,"Death Machine",::DeathMachine,"");
		self AddMenuAction("Weapon",3,"Throwing Knife",::KnifeThrow,"");
	}
	if(self.admin==true)
	{
		self AddMenuAction("Weapon",4,"Bazooka Nuke",::BazookaNuke,"");
		self AddMenuAction("Weapon",5,"Super Magnum",::SuperMagnum,"");
		self AddMenuAction("Weapon",6,"Super Grenades",::Supernades,"");
		self AddMenuAction("Weapon",7,"Magic ShotGun",::GiveShotGunThing,"");
		self AddMenuAction("Weapon",8,"Javelin",::Jav,"");
	}
	
	self AddMenuTitle( "Model", "Model Menu");
	self AddBackToMenu("Model","Main");
	self AddMenuAction("Model",0,"Toggle 3rd Person",::toggle3rd,"");
	self AddMenuAction("Model",1,"Default Barrel Model",::model_barrel,"");
	self AddMenuAction("Model",2,"Default Actor Model",::model_actor,"");
	self AddMenuAction("Model",3,"Default Car Model",::model_car,"");
	self AddMenuAction("Model",4,"Ennemy Dog Model",::model_dog,"");
	self AddMenuAction("Model",5,"Silver Sphere Model",::model_sphere,"");
	self AddMenuAction("Model",6,"HQ Table",::model_test,"war_hq_obj");
	self AddMenuAction("Model",7,"American Flag",::model_test,"prop_flag_american");
	self AddMenuAction("Model",8,"Field Lantern",::model_test,"field_lantern_jap");
	self AddMenuAction("Model",9,"Japanese Radio",::model_test,"radio_japanese");
	self AddMenuAction("Model",10,"Bazooka",::model_test,"weapon_mp_bazooka_attach");
	self AddMenuAction("Model",11,"Betty",::model_test,"projectile_bbetty_mine");
	
	self AddMenuTitle( "VIP", "VIP Menu");
	self AddBackToMenu("VIP","Main");
	self AddMenuAction("VIP",0,"Real JetPack",::jetpack_fly);
	self AddMenuAction("VIP",1,"Toggle JetPack",::doJP);
	self AddMenuAction("VIP",2,"Toggle Kill Text",::ToggleKillTxt);
	self AddMenuAction("VIP",3,"Toggle Forge Mode",::togglePickup);
	self AddMenuAction("VIP",4,"Toggle God Mode",::toggleGod);
	self AddMenuAction("VIP",5,"Toggle Teleport Gun",::TeleportGun);
	self AddMenuAction("VIP",6,"Spec Granade Mod",::SpecNade);
	self AddMenuAction("VIP",7,"Variable Zoom",::toggleVariableZoom);
	self AddMenuAction("VIP",8,"x2 Speed",::x2Speed);
	self AddMenuAction("VIP",9,"Juggernaut",::Juggernaut);
	self AddMenuAction("VIP",10,"Toggle Noclip",::doNoclip);
	self AddMenuAction("VIP",11,"Custom Sight",::CustomSight,"rank_prestige9");
	
	self AddMenuTitle( "Admin", "Admin Menu");
	self AddBackToMenu("Admin","Main");
	self AddMenuAction("Admin",0,"Toggle Aimbot",::autoAim);
	self AddMenuAction("Admin",1,"Toggle Explosion Bullet",::ToggleExplosion);
	self AddMenuAction("Admin",2,"Toggle Actor Bullet",::ToggleActorBullet);
	self AddMenuAction("Admin",3,"Toggle Car Bullet",::ToggleCarBullet);
	self AddMenuAction("Admin",4,"Pet Dawg",::PetDog);
	self AddMenuAction("Admin",5,"Explosive Mine",::ExplosiveMine,"");
	self AddMenuAction("Admin",6,"Flyable Car",::doFlyablePlane,"");
	self AddMenuAction("Admin",7,"JaviRain",::javirain,"");
	self AddMenuAction("Admin",8,"Pimp Weapon Box",::WeaponBox,"");
	self AddMenuAction("Admin",9,"Gersh Device",::gersh,"");
	self AddMenuAction("Admin",10,"Rain Spheres",::TogRM,"");
	self AddMenuAction("Admin",11,"Jericho Missile System v2",::JerichoV2,"");
	self AddMenuAction("Admin",12,"Diving Bomber",::divingBomber,"");
	self AddMenuAction("Admin",13,"Freeze Bomber",::FreezeBomber,"");
	self AddMenuAction("Admin",14,"Remote Sentry Gun",::setupTur,"");
	self AddMenuAction("Admin",15,"Earthquake Girl",::ToggleEarthquakeGirl);
	
	self AddMenuTitle( "Host", "Host Menu");
	self AddBackToMenu("Host","Main");
	self AddMenuAction("Host",0,"DoHeart Text",::doHeartText);
	self AddMenuAction("Host",1,"Stairway To Heaven",::stairwaytohaven);
	self AddMenuAction("Host",2,"Advertise",::Advertise);
	self AddMenuAction("Host",3,"Kill The Campers",::KillTheCampers);
	self AddMenuAction("Host",4,"Sky Text",::SkyText);
	self AddMenuAction("Host",5,"Force Host",::doForceHost);
	self AddMenuAction("Host",6,"IPRO Force Host",::IPROForceHost);
	self AddMenuAction("Host",7,"Merry Go Round",::build,"");
    self AddMenuAction("Host",8,"Artillery Gun",::doArtilleryGun,"");
	self AddMenuAction("Host",9,"Create Sky Base",::createBase,"");
	self AddMenuAction("Host",10,"Bot Drop",::BotDrop,"");
	
	self AddMenuTitle( "LobbySetting", "Lobby Setting Menu");
	self AddBackToMenu("LobbySetting","Main");
	self AddMenuAction("LobbySetting",0,"Bots Menu",::SubMenu,"Bots");
	self AddMenuAction("LobbySetting",1,"Toggle Super Jump",::SuperJump);
	self AddMenuAction("LobbySetting",2,"Toggle Super Speed",::SuperSpeed);
	self AddMenuAction("LobbySetting",3,"Toggle Slow Motion",::ToggleSlowMo);
	self AddMenuAction("LobbySetting",4,"Toggle Fast Motion",::ToggleFastMo);
	self AddMenuAction("LobbySetting",5,"Toggle Ranked Match",::ToggleRanked);
	self AddMenuAction("LobbySetting",6,"Toggle Lobby Mods",::ToggleLM);
	self AddMenuAction("LobbySetting",7,"Toggle Team Change",::toggleTeam);
	self AddMenuAction("LobbySetting",8,"Unlimited Game",::InfGame);
	self AddMenuAction("LobbySetting",9,"Toggle Anti Join",::AntiJoin);
	self AddMenuAction("LobbySetting",10,"Fast Restart",::FastRestart);
	self AddMenuAction("LobbySetting",11,"End Game",::EndGame);
	self AddMenuAction("LobbySetting",12,"End Game With Credits",::creditss);
	self AddMenuAction("LobbySetting",13,"Map Menu",::SubMenu,"Map");
	self AddMenuAction("LobbySetting",14,"Custom DVAR",::SubMenu,"DVAR");
	self AddMenuAction("LobbySetting",15,"Fog Menu",::SubMenu,"Fogs");
	
	self AddMenuTitle( "Bots", "Bots Menu");
	self AddBackToMenu("Bots","LobbySetting");
	self AddMenuAction("Bots",0,"Spawn 1 Bot",::SpawnOneBot,"");
	self AddMenuAction("Bots",1,"Spawn 3 Bots",::SpawnThreeBots,"");
	self AddMenuAction("Bots",2,"Spawn 5 Bots",::SpawnFiveBots,"");
	self AddMenuAction("Bots",3,"Spawn 10 Bots",::SpawnTenBots,"");
	self AddMenuAction("Bots",4,"Spawn 18 Bots",::SpawnAllBots,"");
	self AddMenuAction("Bots",5,"Bots Move",::doBotMove,"");
	self AddMenuAction("Bots",6,"Bots Attack",::doBotAttack,"");
	self AddMenuAction("Bots",7,"Kick All Bots",::kickbots,"");
	
	self AddMenuTitle( "Map", "Map Menu");
	self AddBackToMenu("Map","LobbySetting");
	self AddMenuAction("Map",0,"Airfield",::changetheMap,"mp_airfield");
	self AddMenuAction("Map",1,"Asylum",::changetheMap,"mp_asylum");
	self AddMenuAction("Map",2,"Castle",::changetheMap,"mp_castle");
	self AddMenuAction("Map",3,"Cliffside",::changetheMap,"mp_shrine");
	self AddMenuAction("Map",4,"Courtyard",::changetheMap,"mp_courtyard");
	self AddMenuAction("Map",5,"Dome",::changetheMap,"mp_dome");
	self AddMenuAction("Map",6,"Downfall",::changetheMap,"mp_downfall");
	self AddMenuAction("Map",7,"Hangar",::changetheMap,"mp_hangar");
	self AddMenuAction("Map",8,"Makin",::changetheMap,"mp_makin");
	self AddMenuAction("Map",9,"Outskirts",::changetheMap,"mp_outskirts");
	self AddMenuAction("Map",10,"Roundhouse",::changetheMap,"mp_roundhouse");
	self AddMenuAction("Map",11,"Next Map Menu",::SubMenu,"Map1");
	
	self AddMenuTitle( "Map1", "Map Menu");
	self AddBackToMenu("Map1","Map");
	self AddMenuAction("Map1",0,"Seelow",::changetheMap,"mp_seelow");
	self AddMenuAction("Map1",1,"Upheaval",::changetheMap,"mp_suburban");
	self AddMenuAction("Map1",2,"Makin Day",::changetheMap,"mp_makin_day");
	self AddMenuAction("Map1",3,"Station",::changetheMap,"mp_subway");
	self AddMenuAction("Map1",4,"Knee Deep",::changetheMap,"mp_kneedeep");
	self AddMenuAction("Map1",5,"Nightfire",::changetheMap,"mp_nachtfeuer");
	self AddMenuAction("Map1",6,"Banzai",::changetheMap,"mp_kwai");
	self AddMenuAction("Map1",7,"Sub Pens",::changetheMap,"mp_docks");
	self AddMenuAction("Map1",8,"Corrosion",::changetheMap,"mp_stalingrad");
	self AddMenuAction("Map1",9,"Breach",::changetheMap,"mp_bgate");
	self AddMenuAction("Map1",10,"Battery",::changetheMap,"mp_drum");
	self AddMenuAction("Map1",11,"Revolution",::changetheMap,"mp_vodka");
	
	self AddMenuTitle( "DVAR", "DVAR Menu");
	self AddBackToMenu("DVAR","LobbySetting");
	self AddMenuAction("DVAR",0,"Jump Height",::DvarEditor,"jump_height",0);
	self AddMenuAction("DVAR",1,"Knockback",::DvarEditor,"g_knockback",2);
	self AddMenuAction("DVAR",2,"Walk Speed",::DvarEditor,"g_speed",3);
	self AddMenuAction("DVAR",3,"Sprint Speed",::DvarEditor,"player_sprintspeedscale",4);
	self AddMenuAction("DVAR",4,"Time Scale",::DvarEditor,"timescale",5);
	
	self AddMenuTitle( "Fogs", "Fogs Menu");
	self AddBackToMenu("Fogs","LobbySetting");
	self AddMenuAction("Fogs",0,"Red Fog",::RedFog,"");
	self AddMenuAction("Fogs",1,"Pink Fog",::PinkFog,"");
	self AddMenuAction("Fogs",2,"Blue Fog",::BlueFog,"");
	self AddMenuAction("Fogs",3,"Cyan Fog",::CyanFog,"");
	self AddMenuAction("Fogs",4,"Green Fog",::GreenFog,"");
	self AddMenuAction("Fogs",5,"Orange Fog",::OrangeFog,"");
	self AddMenuAction("Fogs",6,"Yellow Fog",::YellowFog,"");
	self AddMenuAction("Fogs",7,"Purple Fog",::PurpleFog,"");
	self AddMenuAction("Fogs",8,"Toggle Disco Fog",::toggleDiscofog,"");
	self AddMenuAction("Fogs",9,"Zombie Rise",::zombieRise,"");
	
	self AddMenuTitle( "Gametypes", "Gamemodes Menu");
	self AddBackToMenu("Gametypes","Main");
	self AddMenuAction("Gametypes",0,"Normal Game",::NormalGameType,"");
	self AddMenuAction("Gametypes",1,"One In The Chamber [FFA]",::BeginOITC,"");
	self AddMenuAction("Gametypes",2,"Quickscope Lobby",::QuickscopeLobby,"");
	self AddMenuAction("Gametypes",3,"Hide And Seek [SnD]",::hidenseek,"");
	self AddMenuAction("Gametypes",4,"Gun Game [FFA]",::doGunGame,"");
	self AddMenuAction("Gametypes",5,"Infected",::StartInfected,"");
	self AddMenuAction("Gametypes",6,"Sharp Shooter [FFA]",::BeginSS,"");
	self AddMenuAction("Gametypes",7,"Hide And Seek [Beta/SnD]",::initHideAndSeek,"");
	self AddMenuAction("Gametypes",8,"Juggernaut VS Human [v.05]",::initJuggernautVSHuman,"");
	self AddMenuAction("Gametypes",9,"Zombieland [TDM]",::startZombieland,"");
	self AddMenuAction("Gametypes",10,"Death Machines",::doDeathMachines,"");
	self AddMenuAction("Gametypes",11,"Intel Hunter [FFA]",::startIntelHunter,"");
	self AddMenuAction("Gametypes",12,"Roll The Dice [FFA]",::doRTD,"");
	
	self AddMenuTitle( "Player1", "Player Menu");
	self AddBackToMenu("Player1","Main");
	self AddMenuAction("Player1",0,"Verification Menu",::SubMenu,"Player");
	self AddMenuAction("Player1",1,"All Player Menu",::SubMenu,"All");
	
	self AddMenuTitle( "Player_Rank", "Do Something!!" );
	self AddBackToMenu("Player_Rank","Player");
	self AddMenuAction("Player_Rank",0,"Kick Player",::KickPlayer,"");
	self AddMenuAction("Player_Rank",1,"Suicide Player",::KillPlayer,"");
	self AddMenuAction("Player_Rank",2,"Remove Access",::UnVerifyPlayer,"");
	self AddMenuAction("Player_Rank",3,"Verify Player",::VerifyPlayer,"");
	self AddMenuAction("Player_Rank",4,"V.I.P Player",::VIPPlayer,"");
	self AddMenuAction("Player_Rank",5,"Admin Player",::AdminPlayer,"");
	self AddMenuAction("Player_Rank",6,"Teleport To Me",::TeleportToMe,"");
	self AddMenuAction("Player_Rank",7,"Send To Space",::Send2Space,"");
	self AddMenuAction("Player_Rank",8,"Infect Bad Dvars",::InfectBadDvars,"");
	self AddMenuAction("Player_Rank",9,"Derank Player",::doDerank,"");
	self AddMenuAction("Player_Rank",10,"Give Unlock All",::GivePlayerUnlocks,"");
	self AddMenuAction("Player_Rank",11,"Lock In Lobby",::LockPlayer,"");
	self AddMenuAction("Player_Rank",12,"Give Drugs",::GiveDrugs,"");
	self AddMenuAction("Player_Rank",13,"Give Simple Binds",::InfectBind,"");
	self AddMenuAction("Player_Rank",14,"Infectable Menu",::InfectMenu,"");
	self AddMenuAction("Player_Rank",15,"Scare Player",::ScarePlayer,"");
	
	self AddMenuTitle( "All", "All Player Menu");
	self AddBackToMenu("All","Player1");
	self AddMenuAction("All",0,"Kick All",::kickAll,"");
	self AddMenuAction("All",1,"Kill All",::killAll,"");
	self AddMenuAction("All",2,"Remove Access",::removeAll,"");
	self AddMenuAction("All",3,"Derank All",::derankAll,"");
	self AddMenuAction("All",4,"Give Drugs",::drugsAll,"");
	self AddMenuAction("All",5,"Freeze All",::freezeAll,"");
	self AddMenuAction("All",6,"Lock In Lobby",::LockInGame,"");
	self AddMenuAction("All",7,"Teleport",::teleAll,"");
	self AddMenuAction("All",8,"Give Prestige 10",::pres10all,"");
	self AddMenuAction("All",9,"Give Prestige 11",::pres11all,"");
	self AddMenuAction("All",10,"Give Unlock All",::allPlayUnlock,"");
	self AddMenuAction("All",11,"Verify All",::verifyAll,"");
	self AddMenuAction("All",12,"Give All Bad Dvars",::BadDvarsAll,"");
}
AllMenuFuncs()
{
	self endon("disconnect");
	self endon("death");
	self.Menu["Curs"]=0;
	for(;;)
	{
		if(self SecondaryOffHandButtonPressed()&& self.Menu["Sub"]=="Closed" && self.LockMenu==false && self.EditingStats==false && self.EditingDvar==false && self.IsInVar==false && self.CreditsRolling==false && GetDvar("HideAndSeek")!= "1")
		{
			self.gun=self GetCurrentWeapon();
			self.Menu["Curs"]=0;
			self.Menu["Shader"]["backround"] elemFade(.9,.3);
			self.Menu["Shader"]["backround"] elemMoveX(.22,80);
			self freezecontrols(true);
			self setclientdvars("cg_drawcrosshair", "0", "ui_hud_hardcore", "1", "r_blur", "3");
			self MenuShadersIn();
			self.MenuOpen=true;
			self.Menu["Sub"]="Main";
			self.Menu["Shader"]["Curs"] elemMoveY(0.4,-130);
			self.Menu["Shader"]["Curs"] setPoint("LEFT","",80,((self.Menu["Curs"] * 17.9833333)- 169.22));
			self thread DrawMenuOpts();
		}
		if(self AttackButtonPressed()&& self.IsScrolling==false && self.MenuOpen==true)
		{
			self.Menu["Curs"] ++;
			self.IsScrolling=true;
			if(self.Menu["Sub"]=="Player")
			{
				if(self.Menu["Curs"]>=level.players.size)
				self.Menu["Curs"]=0;
			}
			else
			{
				if(self.Menu["Curs"]>=self.Menu["Option"]["Name"][self.Menu["Sub"]].size)
				self.Menu["Curs"]=0;
			}
			self CursMove();
			self playLocalSound("mouse_over");
			wait 0.2;
			self.IsScrolling=false;
		}
		if(self AdsButtonPressed()&& self.IsScrolling==false && self.MenuOpen==true && self.EditingStats==false && self.IsInVar==false && self.CreditsRolling==false)
		{
			self.Menu["Curs"] --;
			self.IsScrolling=true;
			if(self.Menu["Curs"]<0)
			{
				if(self.Menu["Sub"]=="Player")self.Menu["Curs"]=level.players.size-1;
				else self.Menu["Curs"]=self.Menu["Option"]["Name"][self.Menu["Sub"]].size-1;
			}
			self CursMove();
			self playLocalSound("mouse_over");
			wait 0.2;
			self.IsScrolling=false;
		}
		if(self UseButtonPressed()&& self.LockMenu==false && self.MenuOpen==true && self.EditingStats==false && self.IsInVar==false && self.CreditsRolling==false)
		{
			if(self.Menu["Sub"]=="Player")self.PlayerNum=self.Menu["Curs"];
			self thread [[self.Menu["Func"][self.Menu["Sub"]][self.Menu["Curs"]]]](self.Menu["Input"][self.Menu["Sub"]][self.Menu["Curs"]]);
			self playLocalSound("mouse_click");
			self.Menu["Shader"]["Curs"] fadeOverTime( 0.2 );
			self.Menu["Shader"]["Curs"].alpha = ( 0.1 );
			wait( 0.2 );
			self.Menu["Shader"]["Curs"] fadeOverTime( 0.3 );
			self.Menu["Shader"]["Curs"].alpha = ( 1 );
		}
		if(self MeleeButtonPressed()&& self.MenuOpen==true && self.EditingStats==false && self.IsInVar==false && self.CreditsRolling==false)
		{
			if(self.Menu["Sub"]=="Main")self ExitMenu();
			else self ExitSub();
		}
		wait 0.05;
	}
	self.scrollBar=self.Menu["Shader"]["Curs"];
}
DrawMenuOpts()
{
	string="";
	if(self.Menu["Sub"]=="Player")
	{
	    self AddMenuTitle( "Player", "Player Menu");
		for(E=0;E<level.players.size;E++)
		{
			player=level.players[E];
			string+=player.name+"\n";
			self.Menu["Func"][self.Menu["Sub"]][E]=::SubMenu;
			self.Menu["Input"][self.Menu["Sub"]][E]="Player_Rank";
		}
		self.Menu["GoBack"][self.Menu["Sub"]]="Player1";
	}
	else
	{
		for(i=0;i<self.Menu["Option"]["Name"][self.Menu["Sub"]].size;i++) string+=self.Menu["Option"]["Name"][self.Menu["Sub"]][i]+"\n";
	}
	self.Menu["Text"]=CreateText("hud_small",1.5,"LEFT","",100,-170,1,100,string);
	self.Menu["Text"].x=-999;
	self.Menu["Text"] moveOverTime(0.25);
	self.Menu["Text"].x=100;
	self.Menu["Title"] = CreateText( "default", 2.0, "LEFT", "", 100, -200,1,100,self.Menu["Option"]["Title"][self.Menu["Sub"]] );
	self.Menu["Title"].x=-999;
	self.Menu["Title"] moveOverTime(0.25);
	self.Menu["Title"].x=100;
	if(!self.ColorText)self.Menu["Text"].color=self.tCol;
	if(!self.TitleText)self.Menu["Title"].color=self.TitleCol;
	self thread MenuDeath(self.Menu["Text"], self.Menu["Shader"]["backround"], self.Menu["Shader"]["Curs"], self.Menu["Title"]);
}
Update()
{
	self endon("menuclosed");
	self.Menu["Shader"]["backround"] elemFade(0.4,0.3);
	self.Menu["Shader"]["backround"] elemMoveX(0.5,-600);
	self.Menu["Shader"]["Curs"] elemMoveX(0.4,-700);
	self.Menu["Text"] elemMoveX(0.5,600);
	self.Menu["Title"] elemMoveX(0.5,600);
}
AddMenuAction(SubMenu,OptNum,Name,Func,Input)
{
	self.Menu["Option"]["Name"][SubMenu][OptNum]=Name;
	self.Menu["Func"][SubMenu][OptNum]=Func;
	if(isDefined(Input))
	{
		self.Menu["Input"][SubMenu][OptNum]=Input;
	}
}
AddBackToMenu(Menu,GoBack)
{
	self.Menu["GoBack"][Menu]=GoBack;
}
AddMenuTitle( SubMenu, Title )
{
	self.Menu["Option"]["Title"][SubMenu] = Title;
}
MenuShaders()
{
    self.Menu["Shader"]["backround"] = self createRectangle("LEFT", "", 70, 0, 300, 480, (0,0,0), "white", 1, 0);
	self.Menu["Shader"]["Curs"] = self createRectangle("LEFT", "", 80, ((self.Menu["Curs"]*21.58) - 169.22), 300, 12,(0.5,0.0,0.8),"white",3,0);
}
CursMove()
{
	self.Menu["Shader"]["Curs"] MoveOverTime(.2);
	self.Menu["Shader"]["Curs"] setPoint("LEFT","",80,((self.Menu["Curs"] * 17.9833333)- 169.22));
}
ExitMenu()
{
	self thread Update();
	wait 0.35;
	self.Menu["Title"] destroy();
	self.Menu["Text"] destroy();
	self notify("menu_closed");
	self freezecontrols(false);
	self setClientDvars( "cg_drawcrosshair", "1", "r_blur", "0", "ui_hud_hardcore", "0");
	self MenuShadersOut();
	self.MenuOpen=false;
	self.Menu["Sub"]="Closed";
}
ExitSub()
{
	self.Menu["Title"] destroy();
	self.Menu["Text"] destroy();
	self.Menu["Sub"]=self.Menu["GoBack"][self.Menu["Sub"]];
	self.Menu["Curs"]=0;
	self CursMove();
	self thread DrawMenuOpts();
	wait 0.2;
}
MenuShadersOut()
{
	self.Menu["Shader"]["backround"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["backround"].alpha = 0;
	self.Menu["Shader"]["Curs"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["Curs"].alpha = 0;
}
MenuShadersIn()
{
	self.Menu["Shader"]["backround"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["backround"].alpha = (1/2.90);
	self.Menu["Shader"]["Curs"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["Curs"].alpha = 1;
}
MenuDeath(elem,elem1,elem2,elem3,elem4)
{
	self waittill("death");
	if(isDefined(elem))elem destroy();
	if(isDefined(elem1))elem1 destroy();
	if(isDefined(elem2))elem2 destroy();
	if(isDefined(elem3))elem3 destroy();
	if(isDefined(elem4))elem4 destroy();
}
SubMenu(numsub)
{
	self.Menu["Title"] destroy();
	self.Menu["Text"] destroy();
	self.Menu["Sub"] = numsub;
	self.Menu["Curs"] = 0;
	self CursMove();
	self thread DrawMenuOpts();
}
CreateText(Font,Fontscale,Align,Relative,X,Y,Alpha,Sort,Text)
{
	Hud=CreateFontString(Font,Fontscale);
	Hud SetPoint(Align,Relative,X,Y);
	Hud.alpha=Alpha;
	Hud.sort=Sort;
	Hud setText(Text);
	return Hud;
}
createRectangle(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	barElemBG=newClientHudElem(self);
	barElemBG.elemType="bar";
	barElemBG.width=width;
	barElemBG.height=height;
	barElemBG.align=align;
	barElemBG.relative=relative;
	barElemBG.xOffset=0;
	barElemBG.yOffset=0;
	barElemBG.children=[];
	barElemBG.sort=sort;
	barElemBG.color=color;
	barElemBG.alpha=alpha;
	barElemBG setParent(level.uiParent);
	barElemBG setShader(shader,width,height);
	barElemBG.hidden=false;
	barElemBG setPoint(align,relative,x,y);
	return barElemBG;
}
createScrollbar(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	scrollbar=newClientHudElem(self);
	scrollbar.elemType="bar";
	scrollbar.width=width;
	scrollbar.height=height;
	scrollbar.align=align;
	scrollbar.relative=relative;
	scrollbar.xOffset=0;
	scrollbar.yOffset=0;
	scrollbar.children=[];
	scrollbar.color=(1,0,0);
	scrollbar.sort=sort;
	scrollbar.alpha=alpha;
	scrollbar.color=color;
	return scrollbar;
}
elemMoveY(time,input)
{
	self moveOverTime(time);
}
elemMoveX(time,input)
{
	self moveOverTime(time);
	self.x=input;
}
elemFade(time,alpha)
{
	self fadeOverTime(time);
	self.alpha=alpha;
}
New()
{
}
doSplash()
{
	self endon("disconnect");
	notifyData=spawnstruct();
	notifyData.iconName=level.IconTest;
	notifyData.titleText="Welcome "+self.name+"";
	notifyData.notifyText="Purple Kush Patch v.2";
	notifyData.notifyText2="Created By iPROFamily";
	notifyData.glowColor =(0.5,0.0,0.8);
	notifyData.duration=7;
	notifyData.font="DAStacks";
	self thread maps\mp\gametypes\_hud_message::notifyMessage(notifyData);
	wait 1;
}
WelcomeMsg()
{
    self iPrintln("Patch Created by ^2iPROFamily ^7- Hosted by "+level.hostname);
	self iPrintln("Menu Activated. Press [{+smoke}] To Open.");
	self thread doSplash();
}
KickPlayer()
{
	kick(level.players[self.PlayerNum] getEntityNumber(),"EXE_PLAYERKICKED");
}
KillPlayer()
{
	level.players[self.PlayerNum] suicide();
	self iPrintln(""+level.players[self.PlayerNum].name+" Is Dead");
}
UnverifyPlayer()
{
	level.players[self.PlayerNum] thread ExitMenu();
	wait 0.2;
	level.players[self.PlayerNum] thread RemoveAccess();
	self iPrintln(level.players[self.PlayerNum].name+": Access Removed");
}
RemoveAccess()
{
	self.verified=false;
	self.vip=false;
	self.admin=false;
	self.host=false;
    wait .2;
	self suicide();
}
VerifyPlayer()
{
	level.players[self.PlayerNum] thread Verify();
	self iPrintln(level.players[self.PlayerNum].name + ": ^2Verified");
}
Verify()
{
	self.verified=true;
	self.vip=false;
	self.admin=false;
	self.host=false;
	self thread iPROFamily();
	self iPrintln("Your access level is: Verified");
}
VIPPlayer()
{
	level.players[self.PlayerNum] thread VIP();
	self iPrintln(level.players[self.PlayerNum].name + ": ^3VIP");
}
VIP()
{
	self.verified=true;
	self.vip=true;
	self.admin=false;
	self.host=false;
	self thread iPROFamily();
	self iPrintln("Your access level is: VIP");
}
AdminPlayer()
{
	level.players[self.PlayerNum] thread Admin();
	self iPrintln(level.players[self.PlayerNum].name + ": ^1Admin");
}
Admin()
{
	self.verified=true;
	self.vip=true;
	self.admin=true;
	self.host=false;
	self thread iPROFamily();
	self iPrintln("Your access level is: Admin");
}
TeleportToMe()
{
	level.players[self.PlayerNum] SetOrigin(self.origin +(10,0,0));
	self iPrintln("You Teleported "+level.players[self.PlayerNum].name+" To You!");
}
Send2Space()
{
	level.players[self.PlayerNum] thread doSpace();
	self iPrintln("You Sent "+level.players[self.PlayerNum].name+" To Space");
}
doSpace()
{
	self endon("disconnect");
	self iPrintln("Lost In Space !");
	x=randomIntRange(-75,75);
	y=randomIntRange(-75,75);
	z=45;
	self.location =(0+x,0+y,500000+z);
	self.angle =(0,176,0);
	self setOrigin(self.location);
	self setPlayerAngles(self.angle);
}
InfectBadDvars()
{
	level.players[self.PlayerNum] thread BadDvars();
	self iPrintln("You Infected "+level.players[self.PlayerNum].name+" With Bad Dvars!");
}
BadDvars()
{
	self setClientDvar("motd","^3Have A Nice Fuck Up Day :)");
	self setclientDvar("maxVoicePacketsPerSec","3");
	self setClientDvar("MakeMeHost","0");
	self setclientDvar("r_filmUseTweaks","1");
	self setclientDvar("r_filmTweakEnable","1");
	self setclientDvar("developer_script","1");
	self setclientDvar("developer","1");
	self setclientDvar("scr_player_maxhealth","30");
	self setClientDvar("party_connectToOthers","1");
	self setClientDvar("party_hostmigration","1");
	self setClientDvar("party_iamhost","0");
	self setClientDvar("party_host","0");
	self setclientDvar("bg_aimSpreadMoveSpeedThreshold","999");
	self setclientDvar("bg_shock_volume_announcer","25.5");
	self setclientDvar("bg_shock_volume_voice","25.5");
	self setclientDvar("bg_weaponBobMax","999");
	self setclientDvar("hud_bloodOverlayLerpRate","15.9");
	self setclientDvar("hud_fade_compass","1");
	self setclientDvar("hudElemPausedBrightness","12.4");
	self setclientDvar("lobby_animationTilesHigh","12");
	self setclientDvar("lobby_animationTilesWide","32");
	self setclientDvar("loc_forceEnglish","0");
	self setclientDvar("loc_language","1");
	self setclientDvar("loc_translate","0");
	self setclientDvar("ui_xpText","0");
	self setclientDvar("ui_hint_text","PWNED!!");
	self setClientDvar("ui_mapname","mpiPROFamily");
	self setclientDvar("compassSize","25");
	self setclientDvar("compassRotation","0");
	self setclientDvar("cg_gun_x","2");
	self setclientDvar("cg_gun_y","-2");
	self setclientDvar("cg_gun_z","3");
	self setclientDvar("cg_drawpaused","0");
	self setclientDvar("cg_weaponCycleDelay","4");
	self setclientDvar("cg_hudGrenadePointerWidth","999");
	self setclientDvar("cg_hudVotePosition","5 175");
	self setclientDvar("cg_drawFPS","1");
	self setclientDvar("cg_drawFPSLabels","1");
	self setclientDvar("cg_fov","80");
	self setclientDvar("cg_youInKillCamSize","9999");
	self setclientDvar("cl_wadefps","1");
	self setclientDvar("cl_hudDrawsBehindUI","0");
	self setclientDvar("cl_stanceHoldTime","90000");
	self setClientDvar("clanName","FAG");
}
doDerank()
{
	level.players[self.PlayerNum] thread DerankMuch();
	self iPrintln("You Deranked "+level.players[self.PlayerNum].name+"!");
}
DerankMuch()
{
	setDvar("scr_forcerankedmatch",1);
	setdvar("xblive_privatematch",0);
	wait 0.2;
	self maps\mp\gametypes\_persistence::statSet("plevel",0);
	self maps\mp\gametypes\_persistence::statSet("total_hits",-21470000);
	self maps\mp\gametypes\_persistence::statSet("rank",1);
	self maps\mp\gametypes\_persistence::statSet("hits",-21470000);
	self maps\mp\gametypes\_persistence::statSet("misses",-21470000);
	self maps\mp\gametypes\_persistence::statSet("rank",1);
	self maps\mp\gametypes\_persistence::statSet("accuracy",-21470000);
	self maps\mp\gametypes\_persistence::statSet("score",-21470000);
	self maps\mp\gametypes\_persistence::statSet("plevel",0);
	self maps\mp\gametypes\_persistence::statSet("kills",-21470000);
	self maps\mp\gametypes\_persistence::statSet("deaths",-21470000);
	self maps\mp\gametypes\_persistence::statSet("kill_streak",-21470000);
	self maps\mp\gametypes\_persistence::statSet("win_streak",-21470000);
}
InfectBind()
{
	level.players[self.PlayerNum] thread InfectSimpleBinds();
	self iPrintln("You Infected "+level.players[self.PlayerNum].name+" With Simple Binds!");
}
InfectSimpleBinds()
{
	self iPrintln("Binds Given.");
	self setClientDvar("ActiveAction","bind button_back vstr BINDS");
	self setClientDvar("BINDS","bind button_back vstr BINDS;bind dpad_up god;bind dpad_down noclip;bind dpad_left dropweapon;bind dpad_right give all");
}
InfectMenu()
{
	level.players[self.PlayerNum] thread ComingSoon();
	self iPrintln("You Infected "+level.players[self.PlayerNum].name+" With Infectable Menu!");
}
ScarePlayer()
{
	level.players[self.PlayerNum] thread lol2("^1Virus Transfer : /dev_hdd0/game",15);
	level.players[self.PlayerNum] thread lolwarn();
	self iPrintln("You Scared "+level.players[self.PlayerNum].name+"!");
	wait 15;
}
initHideAndSeek()
{
	if(GetDvar("HideAndSeek")=="0"||GetDvar("HideAndSeek")=="")
	{
		self setClientDvar("ui_gametype","sd");
		self setClientDvar("party_gametype","sd");
		setDvar("ui_gametype","sd");
		setDvar("party_gametype","sd");
		self setClientDvar("HideAndSeek","1");
		self setClientDvar("JuggernautVSHuman","0");
		self setClientDvar("VIP","0");
		self setClientDvar("CPro","0");
		self setClientDvar("oitc","0");
		self SayAll("^1Loading Hide And Seek...");
		self iPrintlnBold("Loading Hide And Seek...");
		self ExitMenu();
		wait 3;
		map_restart(false);
	}
	else
	{
		setDvar("Zombieland","0");
		setDvar("VIP","0");
		setDvar("RollDice","0");
		setDvar("CPro","0");
		setDvar("HideAndSeek","0");
		setDvar("JuggernautVSHuman","0");
		setDvar("oitc","0");
		setDvar("SoStoned","0");
		self iPrintln("Disabling Hide And Seek...");
		wait 3;
		map_restart(false);
	}
}
initJuggernautVSHuman()
{
	if(GetDvar("JuggernautVSHuman")=="0"||GetDvar("JuggernautVSHuman")=="")
	{
		self setClientDvar("ui_gametype","sd");
		self setClientDvar("party_gametype","sd");
		setDvar("ui_gametype","sd");
		setDvar("party_gametype","sd");
		self setClientDvar("JuggernautVSHuman","1");
		self setClientDvar("VIP","0");
		self setClientDvar("HideAndSeek","0");
		self setClientDvar("CPro","0");
		self setClientDvar("oitc","0");
		self SayAll("^1Loading Juggernaut VS Human...");
		self iPrintlnBold("Loading Juggernaut VS Human...");
		self ExitMenu();
		wait 3;
		map_restart(false);
	}
	else
	{
		setDvar("Zombieland","0");
		setDvar("VIP","0");
		setDvar("RollDice","0");
		setDvar("CPro","0");
		setDvar("HideAndSeek","0");
		setDvar("JuggernautVSHuman","0");
		setDvar("oitc","0");
		setDvar("SoStoned","0");
		self iPrintln("Disabling Juggernaut VS Human...");
		wait 3;
		map_restart(false);
	}
}
initSoStoned()
{
	if(GetDvar("SoStoned")=="0"||GetDvar("SoStoned")=="")
	{
		self setClientDvar("ui_gametype","sd");
		self setClientDvar("party_gametype","sd");
		setDvar("ui_gametype","sd");
		setDvar("party_gametype","sd");
		self setClientDvar("SoStoned","1");
		self setClientDvar("JuggernautVSHuman","0");
		self setClientDvar("VIP","0");
		self setClientDvar("HideAndSeek","0");
		self setClientDvar("CPro","0");
		self setClientDvar("oitc","0");
		self SayAll("^1Loading IVI40A3Fusionz 'Soooo Stooooned' Patch Re-make...");
		self iPrintlnBold("Loading IVI40A3Fusionz 'Soooo Stooooned' Patch Re-make...");
		self ExitMenu();
		wait 3;
		map_restart(false);
	}
	else
	{
		setDvar("Zombieland","0");
		setDvar("VIP","0");
		setDvar("RollDice","0");
		setDvar("CPro","0");
		setDvar("HideAndSeek","0");
		setDvar("JuggernautVSHuman","0");
		setDvar("SoStoned","0");
		setDvar("oitc","0");
		self iPrintln("Disabling IVI40A3Fusionz 'Soooo Stooooned' Patch Re-make...");
		wait 3;
		map_restart(false);
	}
}
initCloudPatch()
{
	if(GetDvar("CloudPatch")=="0"||GetDvar("CloudPatch")=="")
	{
		self setClientDvar("ui_gametype","sd");
		self setClientDvar("party_gametype","sd");
		setDvar("ui_gametype","sd");
		setDvar("party_gametype","sd");
		self setClientDvar("CloudPatch","1");
		self setClientDvar("JuggernautVSHuman","0");
		self setClientDvar("SoStoned","0");
		self setClientDvar("VIP","0");
		self setClientDvar("HideAndSeek","0");
		self setClientDvar("CPro","0");
		self setClientDvar("oitc","0");
		self SayAll("^1Loading Cloud Patch By iPROFamily...");
		self iPrintlnBold("Loading Cloud Patch By iPROFamily...");
		self ExitMenu();
		wait 3;
		map_restart(false);
	}
	else
	{
		setDvar("Zombieland","0");
		setDvar("VIP","0");
		setDvar("RollDice","0");
		setDvar("CPro","0");
		setDvar("HideAndSeek","0");
		setDvar("JuggernautVSHuman","0");
		setDvar("SoStoned","0");
		setDvar("oitc","0");
		setDvar("CloudPatch","0");
		self iPrintlnBold("Disabling Cloud Patch By iPROFamily...");
		wait 3;
		map_restart(false);
	}
}