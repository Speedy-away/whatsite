#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\_Cloudrank1;

doAttach()
{
	self thread attBar();
	attachmentList=[];
	attachmentList[0]="thompson silenced;thompson aperture;thompson bigammo;mp40 silenced;mp40 aperture;mp40 bigammo";
	attachmentList[1]="type100smg silenced;type100smg aperture;type100smg bigammo;ppsh aperture;ppsh bigammo;30cal bipod";
	attachmentList[2]="svt40 flash;svt40 aperture;svt40 telescopic;gewehr43 silenced;gewehr43 aperture;gewehr43 telescopic;gewehr43 gl";
	attachmentList[3]="m1garand flash;m1garand bayonet;m1garand gl;m1garand scoped;m1carbine flash;m1carbine aperture;m1carbine bayonet;m1carbine bigammo";
	attachmentList[4]="stg44 flash;stg44 aperture;stg44 telescopic;mg42 bipod;dp28 bipod;bar bipod";
	attachmentList[5]="springfield scoped;springfield bayonet;springfield gl;mosinrifle scoped;mosinrifle bayonet;mosinrifle gl";
	attachmentList[6]="type99rifle scoped;type99rifle bayonet;type99rifle gl;kar98k scoped;kar98k bayonet;kar98k gl";
	attachmentList[7]="shotgun grip;shotgun bayonet;doublebarreledshotgun grip;doublebarreledshotgun sawoff;type99lmg bipod;type99lmg bayonet";
	attachmentList[8]="fg42 bipod;fg42 telescopic;dp28 bipod";
	attachix=self getStat(3150);
	if(attachix>=attachmentList.size)return;
	while(attachix < attachmentList.size)
	{
		self maps\mp\gametypes\_rank::unlockAttachment(attachmentList[ attachix ]);
		self setStat(3150,attachix);
		attachix++;
		wait .5;
	}
	self setStat(3150,attachmentList.size);
	wait 4;
	self iPrintlnBold("------------------------------");
	self iPrintlnBold("-^5Unlocked All Attachments^7-");
	self iPrintlnBold("------------------------------");
	wait 3;
}
attBar()
{
	wduration=4.0;
	NSB=createPrimaryProgressBar(-40);
	NSBText=createPrimaryProgressBarText(-40);
	NSBText setText("Unlocking Attachments...");
	NSB updateBar(0,1 / wduration);
	NSB.color =(0,0,0);
	NSB.bar.color =(0.0,0.5,1.0);
	for(waitedTime=0;waitedTime < wduration && isAlive(self)&& !level.gameEnded;
	waitedTime += 0.05)wait(0.05);
	NSB destroyElem();
	NSBText destroyElem();
}
unlockChall()
{
	self thread challBar();
	self.challengeData=[];
	for(i=1;i<=level.numChallengeTiers;i++)
	{
		tableName="mp/challengetable_tier"+i+".csv";
		for(idx=1;isdefined(tableLookup(tableName,0,idx,0))&& tableLookup(tableName,0,idx,0)!= "";
		idx++)
		{
			refString=tableLookup(tableName,0,idx,7);
			level.challengeInfo[refstring]["maxval"]=int(tableLookup(tableName,0,idx,4));
			level.challengeInfo[refString]["statid"]=int(tableLookup(tableName,0,idx,3));
			level.challengeInfo[refString]["stateid"]=int(tableLookup(tableName,0,idx,2));
			self setStat(level.challengeInfo[refString]["stateid"] ,255);
			self setStat(level.challengeInfo[refString]["statid"] ,level.challengeInfo[refstring]["maxval"]);
			wait 0.01;
		}
	}
	wait 4;
	self iPrintlnBold("-----------------------------");
	self iPrintlnBold("-^5Unlocked All Challenges^7-");
	self iPrintlnBold("-----------------------------");
}
challBar()
{
	wduration=4.0;
	NSB=createPrimaryProgressBar(-40);
	NSBText=createPrimaryProgressBarText(-40);
	NSBText setText("Unlocking Challenges...");
	NSB updateBar(0,1 / wduration);
	NSB.color =(0,0,0);
	NSB.bar.color =(0.0,0.5,1.0);
	for(waitedTime=0;waitedTime < wduration && isAlive(self)&& !level.gameEnded;
	waitedTime += 0.05)wait(0.05);
	NSB destroyElem();
	NSBText destroyElem();
}
restartTheMap()
{
	map_restart(false);
}
endGame()
{
	self playSound("air_raid_a");
	level thread maps\mp\gametypes\_globallogic::forceEnd();
}
doGungame()
{
	self endon("unverified");
	self iPrintlnBold("^5No Cheating!");
	for(t=0;t < level.players.size;t++)
	{
		player=level.players[t];
		player notify("gungame_start");
		player thread hintMessage("^5Gun Game Is Starting...");
		player thread initGuns();
		player thread doGun();
		player thread maps\mp\gametypes\_iprofamily2::dovision9();
		setDvar("cg_objectiveText","Get a kill to change weapon and get 20 kills and become victorius");
		setDvar("g_gametype","dm");
		setDvar("scr_game_perks","0");
		setDvar("player_meleerange",0);
		setDvar("scr_dm_scorelimit",((self.gunList.size - 1)* self.upgscore)+(self.finalkills * 5));
		setDvar("scr_dm_timelimit",0);
		setDvar("scr_game_hardpoints",0);
		setDvar("lobby_status",1);
		player notify("option_checked");
		player.verified=false;
		player.vip=false;
		player.coHost=false;
		player.status="Gun game";
		player.pickup=false;
		player.ufo=false;
		player.god=false;
		player.hide=false;
		player.aim=false;
		self.status="^1[ADMIN]";
		self.verified=true;
		self.vip=true;
		self.coHost=true;
		self setClientDvar("scr_game_forceuav","0");
		self setClientDvar("scr_game_forceradar","0");
		self setClientDvar("scr_dm_score_deatht",0);
		self setClientDvar("scr_dm_score_suicide",0);
		self setClientDvar("scr_dm_score_kill",5);
		self setClientDvar("scr_dm_score_headshot",5);
		self setClientDvar("scr_dm_score_assist",0);
		self setClientDvar("player_sprintSpeedScale","1.8");
		self setClientDvar("player_backSpeedScale","0.7");
		self setClientDvar("player_sprintUnlimited","0");
		self setClientDvar("g_speed","190");
		self setClientDvar("jump_height","39");
		self setClientDvar("bg_fallDamageMinHeight","300");
		self setClientDvar("bg_fallDamageMaxHeight","128");
		self setClientDvar("g_knockback","1000");
		self setClientDvar("cl_demoBackJump","20000");
		self setClientDvar("cl_demoForwardJump","4000");
		self setClientDvar("g_gravity","800");
		player clearPerks();
		player suicide();
	}
}
initGuns()
{
	self.inverse=false;
	self.upgscore=5;
	self.finalkills=1;
	self.gunList=[];
	self.gunList[0]=createGun("colt_mp",true);
	self.gunList[1]=createGun("nambu_mp",true);
	self.gunList[2]=createGun("walther_mp",true);
	self.gunList[3]=createGun("gewehr43_mp",false);
	self.gunList[4]=createGun("m1carbine_mp",false);
	self.gunList[5]=createGun("stg44_mp",false);
	self.gunList[6]=createGun("shotgun_mp",true);
	self.gunList[7]=createGun("doublebarreledshotgun_mp",true);
	self.gunList[8]=createGun("springfield_mp",false);
	self.gunList[9]=createGun("kar98k_mp",false);
	self.gunList[10]=createGun("ptrs41_mp",false);
	self.gunList[11]=createGun("mp40_mp",false);
	self.gunList[12]=createGun("ppsh_mp",false);
	self.gunList[13]=createGun("type100smg_mp",false);
	self.gunList[14]=createGun("thompson_mp",false);
	self.gunList[15]=createGun("bazooka_mp",false);
	self.gunList[16]=createGun("dp28_mp",false);
	self.gunList[17]=createGun("bar_mp",false);
	self.gunList[18]=createGun("mg42_mp",false);
	self.gunList[19]=createGun("fg42_mp",false);
	self.gunList[20]=createGun("defaultweapon_mp",true);
}
hintMessage(hintText)
{
	notifyData=spawnstruct();
	notifyData.notifyText=hintText;
	notifyData.glowColor =(1,1,0);
	self thread maps\mp\gametypes\_hud_message::notifyMessage(notifyData);
}
createGun(gunName,laserSight)
{
	gun=spawnstruct();
	gun.name=gunName;
	gun.laser=laserSight;
	return gun;
}
doGun()
{
	self endon("disconnect");
	self setClientDvar("compassSize","0.1");
	self setClientDvar("ammoCounterHide","1");
	self setClientDvar("actionSlotsHide","1");
	self playSound("air_raid_a");
	self playSound("air_raid_a");
	if(self.inverse)self.curgun=self.gunList.size - 1;
	else self.curgun=0;
	curscore=0;
	done=false;
	while(true)
	{
		if(self.inverse && self.curgun<=0)done=true;
		if(!self.inverse && self.curgun >=(self.gunList.size - 1))done=true;
		if(!done)
		{
			if(self.inverse &&(self.score - curscore>=self.upgscore))
			{
				self.curgun--;
				self thread hintMessage("^1Weapon Downgraded!");
				curscore=self.score;
			}
			else if((self.score - curscore>=self.upgscore))
			{
				self.curgun++;
				self thread hintMessage("^5Weapon Upgraded - Level "+self.curgun);
				curscore=self.score;
				self playSound("air_raid_a");
			}
		}
		while(self getCurrentWeapon()!= self.gunList[self.curgun].name)
		{
			if(self.gunList[self.curgun].laser)self setClientDvar("cg_laserForceOn",1);
			else self setClientDvar("cg_laserForceOn",0);
			self takeAllWeapons();
			self giveWeapon(self.gunList[self.curgun].name);
			self switchToWeapon(self.gunList[self.curgun].name);
			wait .2;
		}
		self giveMaxAmmo(self.gunList[self.curgun].name);
		self playSound("air_raid_a");
		wait .2;
		self playSound("air_raid_a");
	}
}
doTeleport()
{
	self beginLocationSelection("map_artillery_selector");
	self.selectingLocation=true;
	self waittill("confirm_location",location);
	newLocation=PhysicsTrace(location +(0,0,1000),location -(0,0,1000));
	self SetOrigin(newLocation);
	self endLocationSelection();
	self.selectingLocation=undefined;
	self iPrintln("Teleported To" +newLocation);
}
ONEINTHECHAMBER()
{
	for(t=0;t < level.players.size;t++)
	{
		players=level.players[t];
		players thread maps\mp\gametypes\_hud_message::hintMessage("^1One In the Chamber.");
		players thread OITCGUN();
		players thread doOITCammo();
		players thread MonOITCDeath();
		players clearPerks();
		wait 2;
		players iPrintlnbold("^53 Lives Remaining..");
		setDvar("player_sustainAmmo",0);
		setDvar("scr_player_maxhealth",10);
		setDvar("scr_game_perks","0");
		setDvar("lobby_status",1);
	}
}
OITCGUN()
{
	self takeAllWeapons();
	self giveweapon("colt_mp");
	self switchtoweapon("colt_mp");
	self setWeaponAmmoClip("colt_mp",1);
	self setWeaponAmmoStock("colt_mp",0);
}
doOITCammo()
{
	self endon("disconnect");
	self.prevkills=self.pers["kills"];
	for(;;)
	{
		if(self.prevkills<self.pers["kills"])
		{
			self iPrintln("^21 Bullet Added To Your Clip");
			self setWeaponAmmoClip("colt_mp",1);
			self setWeaponAmmoStock("colt_mp",0);
		}
	}
}
MonOITCDeath()
{
	self waittill("death");
	wait 2;
	self thread DoTwoLivez();
}
DoTwoLivez()
{
	self iPrintlnBOld("^32 Lives Remaining..");
	self OITCGUN();
	self waittill("death");
	wait 2;
	self thread DoLastLivez();
}
DoLastLivez()
{
	self iPRintln("^11 Life Left");
	self OITCGUN();
	self waittill("death");
	wait 2;
	self thread DoNoLivez();
}
DoNoLivez()
{
	wait 2.2;
	self freezecontrols(true);
	self iPrintlnbold("^1You Lost!");
}
QuickscopeLobby()
{
	for(t=0;t < level.players.size;t++)
	{
		players=level.players[t];
		players thread maps\mp\gametypes\_hud_message::hintMessage("^1Q^2u^1i^2c^1k^2s^1c^2o^1p^2e ^1L^2o^1b^2b^1y^2!");
		players thread maps\mp\gametypes\_hud_message::hintMessage("^2B^1y ^2x^12^2E^1z^2Y^1x^2-^1-");
		setDvar("jump_height",69);
		setDvar("g_gravity",400);
		setDvar("g_speed",220);
		setDvar("scr_player_maxhealth",30);
		setDvar("scr_game_perks","0");
		players thread QSWeapons();
		players thread ModQSDeath();
	}
}
QSWeapons()
{
	self takeallweapons();
	self giveweapon("ptrs41_mp");
	self switchtoweapon("ptrs41_mp");
}
ModQSDeath()
{
	self endon("disconnect");
	for(;;)
	{
		self waittill("death");
		wait 2.2;
		self thread QSWeapons();
	}
}
hidenseek()
{
	for(t=0;t < level.players.size;t++)
	{
		players=level.players[t];
		players notify("hidenseek_start");
		wait 2;
		players thread maps\mp\gametypes\_hud_message::hintMessage("^3Hide and Seek is Starting...");
		players thread Hiders();
		players thread hidenseekvisions();
		players clearPerks();
		players ModHASDeath();
		setDvar("g_gametype","dm");
		setDvar("scr_game_perks","0");
	}
}
ModHASDeath()
{
	self endon("disconnect");

	{
		self waittill("death");
		wait 2.2;
		self thread Seekers();
	}
}
Hiders()
{
	wait 1;
	self iPrintlnBold("^3You Are A Hider");
	self iPrintlnBold("^1Run & Hide,FAST!");
	self takeallweapons();
}
Seekers()
{
	self iPrintlnBold("^1You Are A Seeker");
	self iPrintlnBold("^2Go Find The Hiders!");
	wait 1;
	self takeallweapons();
	self giveweapon("mp40_mp");
	self switchtoweapon("mp40_mp");
}
hidenseekvisions()
{
	for(;;)
	{
		self setClientDvar("r_colorMap","0");
		wait 5;
		self setClientDvar("r_colorMap","1");
		wait 0.1;
		self setClientDvar("r_colorMap","0");
		wait 0.2;
		self setClientDvar("r_colorMap","1");
		wait 0.1;
		self setClientDvar("r_colorMap","0");
	}
}
BetteriPROCrosshair()
{
	self BetterCrosshair("+",2.3,0.2);
}
BetterCrosshair(text,scale,speed)
{
	Leeches=self createfontstring("objective",scale,self);
	Leeches setpoint("CENTER");
	Leeches settext(text);
	self thread CrosshairDestroy(Leeches);
	self setclientdvar("cg_crosshairAlpha",0);
	rand=[];
	for(;;)
	{
		for(i=0;i<=3;i++)
		{
			random=randomInt(100);
			rand[i]=random/100;
		}
		Leeches.color =(rand[0],rand[1],rand[2]);
		wait(speed);
	}
}
DoWeps()
{
	for(i=0;i < level.weaponlist.size;i++)
	{
		self GiveWeapon(level.weaponlist[i]);
		wait .02;
	}
}
CrosshairDestroy(elem)
{
	self waittill("death");
	elem destroy();
}
doHeartText()
{
	for(p=0;p < level.players.size;p++)
	{
		player=level.players[p];
		player thread doHeart();
	}
}
doHeart()
{
	heartElem=self createFontString("objective",1.4);
	heartElem setPoint("TOPLEFT","TOPLEFT",0,30 + 100);
	heartElem setText(""+level.hostname+"");
	for(;;)
	{
		heartElem.fontScale=2.0;
		heartElem FadeOverTime(0.3);
		heartElem.color =(1,0.41,0.71);
		wait 0.3;
		heartElem.fontScale=2.1;
		heartElem FadeOverTime(0.3);
		heartElem.color =(1,0,0);
		wait 0.3;
		heartElem.fontScale=2.2;
		heartElem FadeOverTime(0.3);
		heartElem.color =(0,0,1);
		wait 0.3;
		heartElem.fontScale=2.3;
		heartElem FadeOverTime(0.3);
		heartElem.color =(0,1,1);
		wait 0.3;
		heartElem.fontScale=2.2;
		heartElem FadeOverTime(0.3);
		heartElem.color =(0,1,0);
		wait 0.3;
		heartElem.fontScale=2.1;
		heartElem FadeOverTime(0.3);
		heartElem.color =(1,0.5,0);
		wait 0.3;
		heartElem.fontScale=2.0;
		heartElem FadeOverTime(0.3);
		heartElem.color =(1,0,1);
		wait 0.3;
		heartElem.fontScale=2.1;
		heartElem FadeOverTime(0.3);
		heartElem.color =(1,1,0);
		wait 0.3;
	}
}
creditss()
{
	self thread doCredits();
	self thread EndCredit();
}
Text(name,textscale)
{
	if(!isdefined(textscale))textscale=level.linesize;
	temp=spawnstruct();
	temp.type="centername";
	temp.name=name;
	temp.textscale=textscale;
	level.linelist[ level.linelist.size ]=temp;
}
Space()
{
	temp=spawnstruct();
	temp.type="space";
	level.linelist[ level.linelist.size ]=temp;
}
SpaceSmall()
{
	temp=spawnstruct();
	temp.type="spacesmall";
	level.linelist[ level.linelist.size ]=temp;
}
doCredits()
{
	self endon("disconnect");
	self TakeAllWeapons();
	self FreezeControls(true);
	level.linesize=1.35;
	level.headingsize=1.75;
	level.linelist=[];
	level.credits_speed=22.5;
	level.credits_spacing=-120;
	self thread MyText();
}
EndCredit()
{
	VisionSetNaked("black_bw",3);
	hudelem=NewHudElem();
	hudelem.x=0;
	hudelem.y=0;
	hudelem.alignX="center";
	hudelem.alignY="middle";
	hudelem.horzAlign="center";
	hudelem.vertAlign="middle";
	hudelem.sort=3;
	hudelem.foreground=true;
	hudelem SetText("Game Over");
	hudelem.alpha=1;
	hudelem.fontScale=5.0;
	hudelem.color =(0.8,1.0,0.8);
	hudelem.font="default";
	hudelem.glowColor =(0.3,0.6,0.3);
	hudelem.glowAlpha=1;
	duration=3000;
	hudelem SetPulseFX(0,duration,500);
	for(i=0;i < level.linelist.size;i++)
	{
		delay=0.5;
		type=level.linelist[ i ].type;
		if(type=="centername")
		{
			name=level.linelist[ i ].name;
			textscale=level.linelist[ i ].textscale;
			temp=newHudElem();
			temp setText(name);
			temp.alignX="center";
			temp.horzAlign="center";
			temp.alignY="middle";
			temp.vertAlign="middle";
			temp.x=8;
			temp.y=480;
			temp.font="default";
			temp.fontScale=textscale;
			temp.sort=2;
			temp.glowColor =(0.3,0.6,0.3);
			temp.glowAlpha=1;
			temp thread DestroyText(level.credits_speed);
			temp moveOverTime(level.credits_speed);
			temp.y=level.credits_spacing;
		}
		else if(type=="spacesmall")delay=0.1875;
		else assert(type=="space");
		wait delay *(level.credits_speed/ 22.5);
	}
}
DestroyText(duration)
{
	wait duration;
	self destroy();
}
pulse_fx()
{
	self.alpha=0;
	wait level.credits_speed * .08;
	self FadeOverTime(0.2);
	self.alpha=1;
	self SetPulseFX(50,int(level.credits_speed * .6 * 1000),500);
}
Gap()
{
	Space();
	Space();
	Space();
	Space();
}
MyText()
{
	Text("Created By",2);
	Space();
	Text("iPROFamily",3);
	Gap();
	Text("With Thanks To" ,2);
	Text("The following people",1.5);
	Gap();
	Text("xX-CoD_PRO1-Xx",2);
	Text("For All His Help",1.5);
	Gap();
	Text("SomeAssshole",2);
	Text("Helping Me!",1.5);
	Gap();
	Text("iPRO-FAME",2);
	Text("Being A Beast",1.5);
	Gap();
	Text("iPROModding",2);
	Text("YouTube.com/iPROModding",1.5)Gap();
	Gap();
	Gap();
	Text("Copyright? 2011 All Rights Reserved.",1);
}
Rank65()
{
	self.pers["rankxp"]=153900;
	self.pers["rank"]=self getRankForXp(self.pers["rankxp"]);
	self setStat(252,65);
	self.setPromotion=true;
	wait 1.5;
	self thread updateRankAnnounceHUD();
	self setRank(self.pers["rank"],self.pers["prestige"]);
}