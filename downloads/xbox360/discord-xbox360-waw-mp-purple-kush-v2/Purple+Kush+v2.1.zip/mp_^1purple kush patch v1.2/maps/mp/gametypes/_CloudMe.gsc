#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;
#include maps\mp\gametypes\_Cloudrank1;
#include maps\mp\gametypes\Clo;

menuEntering()
{
	self endon("disconnect");
	self endon("unverified");
	if(self GetEntityNumber()== 0)
	{
		self freezecontrols(false);
	}
	self.menuOpen=0;
	self.chrome=false;
	self thread MonitorButtons();
	self thread doNewsBar("^0[ ^7[{+frag}] - Open Menu ^0| ^7[{+speed_throw}] And [{+attack}] To Navigate ^0| ^7[{+usereload}] To Select ^0| ^7[{+melee}] To Close ^0]");
	self.MenuBG=self createRectangle("CENTER","CENTER",0,0,300,640,(0,0,0),"white",-1000,0);
	self.scrollbar=self createRectangle("CENTER","CENTER",0,self.display[0].y,300,25,(0.0,0.5,1.0),"white",-500,0);
	for(;;)
	{
		while(self.menuOpen==0)
		{
			self waittill("Pressed_R2");
			self freezecontrols(true);
			wait 1;
			self.text destroy();
			self setClientDvar("r_blur",0);
			self setClientDvar("hud_enable",0);
			self setClientDvar("ui_hud_hardcore","1");
			self.MenuBG ElementFade(0.6,0);
			self.scrollbar ElementFade(0.6,0);
			self thread BuildMenu();
			self.MenuBG.alpha=1;
			self.scrollbar.alpha=1;
			wait .3;
		}
		if(self MeleeButtonPressed()&& self.menuOpen==1 && self.curmenu==0)
		{
			self freezecontrols(false);
			self.text2 destroy();
			self setClientDvar("r_blur",0);
			self setClientDvar("hud_enable",1);
			self setClientDvar("ui_hud_hardcore","0");
			self.MenuBG ElementFade(0.6,0);
			self.scrollbar ElementFade(0.6,0);
			self.menuOpen=0;
			self.chosen=0;
			self notify("option_checked");
			self.MenuBG.alpha=0;
			self.scrollbar.alpha=0;
			wait .3;
		}
		if(self MeleeButtonPressed()&& self.menuOpen==1 && self.curmenu!=0)
		{
			self thread submenu(0);
			wait .3;
		}
		wait .02;
	}
}
MonitorButtons()
{
	self endon("disconnect");
	for(;;)
	{
		if(self UseButtonPressed())
		{
			self notify("Pressed_Square");
			wait .1;
		}
		if(self AttackButtonPressed())
		{
			self notify("Pressed_R1");
			wait .1;
		}
		if(self AdsButtonPressed())
		{
			self notify("Pressed_L1");
			wait .1;
		}
		if(self SecondaryOffhandButtonPressed())
		{
			self notify("Pressed_L2");
			wait .3;
		}
		if(self FragButtonPressed())
		{
			self notify("Pressed_R2");
			wait .3;
		}
		if(self MeleeButtonPressed())
		{
			self notify("Pressed_Melee");
			wait .2;
		}
		wait .05;
	}
}
createRectangle(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	barElemBG=newClientHudElem(self);
	barElemBG.elemType="bar";
	if(!level.splitScreen)
	{
		barElemBG.x=-2;
		barElemBG.y=-2;
	}
	barElemBG.width=width;
	barElemBG.height=height;
	barElemBG.align=align;
	barElemBG.relative=relative;
	barElemBG.xOffset=0;
	barElemBG.yOffset=0;
	barElemBG.children=[];
	barElemBG.sort=sort;
	barElemBG.color=color;
	barElemBG.alpha=alpha;
	barElemBG setParent(level.uiParent);
	barElemBG setShader(shader,width ,height);
	barElemBG.hidden=false;
	barElemBG setPoint(align,relative,x,y);
	return barElemBG;
}
ElementFade(time,alpha)
{
	self fadeOverTime(time);
	self.alpha=alpha;
}
BuildMenu()
{
	self endon("disconnect");
	self endon("menu_exit");
	menu=spawnStruct();
	self.option=[];
	self.function=[];
	self.opt=[];
	self.display=[];
	self.curmenu=0;
	self.chosen=0;
	self.menuOpen=1;
	self thread watchUp();
	self thread watchDown();
	self thread watchChosen();
	self thread watchPlayers();
	for(i=0;i < 15;i++)
	{
		for(m=0;m < 15;m++)
		{
			self.opt[i][m]=0;
		}
	}
	self.option[0][0]="Stats Menu";
	self.function[0][0]=::submenu;
	self.opt[0][0]=1;
	self.option[0][1]="Account Menu";
	self.function[0][1]=::submenu;
	self.opt[0][1]=2;
	self.option[0][2]="Fun Menu";
	self.function[0][2]=::submenu;
	self.opt[0][2]=3;
	self.option[0][3]="Vision Menu";
	self.function[0][3]=::submenu;
	self.opt[0][3]=4;
	self.option[0][4]="Infection Menu";
	self.function[0][4]=::submenu;
	self.opt[0][4]=5;
	self.option[0][5]="Model Menu";
	self.function[0][5]=::submenu;
	self.opt[0][5]=17;
	if(self.vip==true)
	{
		self.option[0][6]="VIP Menu";
		self.function[0][6]=::submenu;
		self.opt[0][6]=6;
	}
	if(self.cohost==true)
	{
		self.option[0][7]="Players Menu";
		self.function[0][7]=::submenu;
		self.opt[0][7]=7;
		self.option[0][8]="Admin Menu";
		self.function[0][8]=::submenu;
		self.opt[0][8]=8;
	}
	if(self GetEntityNumber()== 0)
	{
		self.rankmatch=true;
		self.cohost=true;
		self.option[0][9]="Host Menu";
		self.function[0][9]=::submenu;
		self.opt[0][9]=21;
		self.option[0][10]="Lobby Setting Menu";
		self.function[0][10]=::submenu;
		self.opt[0][10]=10;
		self.option[0][11]="Gamemodes Menu";
		self.function[0][11]=::submenu;
		self.opt[0][11]=18;
	}
	self.option[1][0]="Prestige Menu";
	self.option[1][1]="Unlock Attachment";
	self.option[1][2]="Unlock All";
	self.option[1][3]="Set Rank 65";
	self.option[1][4]="Low Stats";
	self.option[1][5]="Medium Stats";
	self.option[1][6]="High Stats";
	self.option[1][7]="Insane Stats";
	self.option[1][8]="Max Stats";
	self.option[1][9]="Negative Stats";
	self.option[1][10]="Reset Stats";
	self.function[1][0]=::submenu;
	self.function[1][1]=::doAttach;
	self.function[1][2]=::unlockChall;
	self.function[1][3]=maps\mp\gametypes\_iprofamily2::setRank65;
	self.function[1][4]=maps\mp\gametypes\_iprofamily2::dostats;
	self.function[1][5]=maps\mp\gametypes\_iprofamily2::dostats;
	self.function[1][6]=maps\mp\gametypes\_iprofamily2::dostats;
	self.function[1][7]=maps\mp\gametypes\_iprofamily2::dostats;
	self.function[1][8]=maps\mp\gametypes\_iprofamily2::dostats;
	self.function[1][9]=maps\mp\gametypes\_iprofamily2::dostats;
	self.function[1][10]=maps\mp\gametypes\_iprofamily2::dostats;
	self.opt[1][0]=16;
	self.opt[1][1]="";
	self.opt[1][2]="";
	self.opt[1][3]="";
	self.opt[1][4]="low";
	self.opt[1][5]="medium";
	self.opt[1][6]="high";
	self.opt[1][7]="insane";
	self.opt[1][8]="max";
	self.opt[1][9]="negative";
	self.opt[1][10]="reset";
	self.option[16][0]="No Prestige";
	self.option[16][1]="1st Prestige";
	self.option[16][2]="2nd Prestige";
	self.option[16][3]="3rd Prestige";
	self.option[16][4]="4th Prestige";
	self.option[16][5]="5th Prestige";
	self.option[16][6]="6th Prestige";
	self.option[16][7]="7th Prestige";
	self.option[16][8]="8th Prestige";
	self.option[16][9]="9th Prestige";
	self.option[16][10]="10th Prestige";
	self.option[16][11]="11th Prestige";
	self.function[16][0]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.function[16][1]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.function[16][2]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.function[16][3]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.function[16][4]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.function[16][5]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.function[16][6]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.function[16][7]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.function[16][8]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.function[16][9]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.function[16][10]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.function[16][11]=maps\mp\gametypes\_iprofamily2::Prestige;
	self.opt[16][0]=0;
	self.opt[16][1]=1;
	self.opt[16][2]=2;
	self.opt[16][3]=3;
	self.opt[16][4]=4;
	self.opt[16][5]=5;
	self.opt[16][6]=6;
	self.opt[16][7]=7;
	self.opt[16][8]=8;
	self.opt[16][9]=9;
	self.opt[16][10]=10;
	self.opt[16][11]=11;
	self.option[17][0]="Toggle 3rd Person";
	self.option[17][1]="Default Barrel Model";
	self.option[17][2]="Default Actor Model";
	self.option[17][3]="Default Car Model";
	self.option[17][4]="Ennemy Dog Model";
	self.option[17][5]="Silver Sphere Model";
	self.function[17][0]=maps\mp\gametypes\_iprofamily2::toggle3rd;
	self.function[17][1]=maps\mp\gametypes\_iprofamily2::model_barrel;
	self.function[17][2]=maps\mp\gametypes\_iprofamily2::model_actor;
	self.function[17][3]=maps\mp\gametypes\_iprofamily2::model_car;
	self.function[17][4]=maps\mp\gametypes\_iprofamily2::model_dog;
	self.function[17][5]=maps\mp\gametypes\_iprofamily2::model_sphere;
	self.option[18][0]="One In The Chamber";
	self.option[18][1]="Quickscope Lobby";
	self.option[18][2]="Hide And Seek";
	self.option[18][3]="Gun Game";
	self.option[18][4]="Purple Kush Patch";
	self.function[18][0]=::ONEINTHECHAMBER;
	self.function[18][1]=::QuickscopeLobby;
	self.function[18][2]=::hidenseek;
	self.function[18][3]=::doGunGame;
	self.function[18][4]=maps\mp\gametypes\_ipros::initCloudPatch;
	self.option[2][0]="Toggle 3rd Person";
	self.option[2][1]="Toggle Pro-Mod";
	self.option[2][2]="Toggle Laser";
	self.option[2][3]="Upside Down Map";
	self.option[2][4]="Right Side Map";
	self.option[2][5]="Left Side Map";
	self.option[2][6]="Normal Side Map";
	self.option[2][7]="Custom Classnames";
	self.option[2][8]="Custom Button Classnames";
	self.function[2][0]=maps\mp\gametypes\_iprofamily2::toggle3rd;
	self.function[2][1]=maps\mp\gametypes\_iprofamily2::togglePromod;
	self.function[2][2]=maps\mp\gametypes\_iprofamily2::toggleLaser;
	self.function[2][3]=maps\mp\gametypes\_iprofamily2::Upside;
	self.function[2][4]=maps\mp\gametypes\_iprofamily2::rightside;
	self.function[2][5]=maps\mp\gametypes\_iprofamily2::leftside;
	self.function[2][6]=maps\mp\gametypes\_iprofamily2::Normalside;
	self.function[2][7]=maps\mp\gametypes\_iprofamily2::ColorClass;
	self.function[2][8]=maps\mp\gametypes\_iprofamily2::ButtonClasses;
	self.option[3][0]="Teleport";
	self.option[3][1]="Toggle Ammo";
	self.option[3][2]="Make A Clone";
	self.option[3][3]="Toggle UFO Mode";
	self.option[3][4]="Toggle Wallhack";
	self.option[3][5]="Decapit Your Head";
	self.option[3][6]="Toggle Tracer Bullet";
	self.option[3][7]="Better Crosshair";
	self.option[3][8]="Give All Weapon";
	self.option[3][9]="Flashing Score";
	self.function[3][0]=maps\mp\gametypes\_iprofamily2::doTeleport;
	self.function[3][1]=maps\mp\gametypes\_iprofamily2::toggleAmmo;
	self.function[3][2]=maps\mp\gametypes\_iprofamily2::clone;
	self.function[3][3]=maps\mp\gametypes\_iprofamily2::toggleUfo;
	self.function[3][4]=maps\mp\gametypes\_iprofamily2::togglewall;
	self.function[3][5]=maps\mp\gametypes\_iprofamily2::decapit;
	self.function[3][6]=maps\mp\gametypes\_iprofamily2::toggleLaser;
	self.function[3][7]=maps\mp\gametypes\_iprofamily2::BetteriPROCrosshair;
	self.function[3][8]=maps\mp\gametypes\_iprofamily2::DoWeps;
	self.function[3][9]=maps\mp\gametypes\_iprofamily2::FlashScore;
	self.option[4][0]="Toggle Disco";
	self.option[4][1]="Toggle Chrome";
	self.option[4][2]="Toggle Blue";
	self.option[4][3]="Toggle Day";
	self.option[4][4]="Toggle Black";
	self.option[4][5]="Toggle White";
	self.option[4][6]="Toggle Tabun";
	self.option[4][7]="Toggle Flame";
	self.option[4][8]="Toggle Decor";
	self.option[4][9]="Toggle PC/ProMod";
	self.option[4][10]="Night Vision";
	self.option[4][11]="Day Vision";
	self.function[4][0]=maps\mp\gametypes\_iprofamily2::toggle_sun;
	self.function[4][1]=maps\mp\gametypes\_iprofamily2::toggle_chrome;
	self.function[4][2]=maps\mp\gametypes\_iprofamily2::toggle_blueVis;
	self.function[4][3]=maps\mp\gametypes\_iprofamily2::toggle_day;
	self.function[4][4]=maps\mp\gametypes\_iprofamily2::toggle_black;
	self.function[4][5]=maps\mp\gametypes\_iprofamily2::toggle_white;
	self.function[4][6]=maps\mp\gametypes\_iprofamily2::toggle_tabun;
	self.function[4][7]=maps\mp\gametypes\_iprofamily2::toggle_flame;
	self.function[4][8]=maps\mp\gametypes\_iprofamily2::toggle_decor;
	self.function[4][9]=maps\mp\gametypes\_iprofamily2::toggle_pcPromod;
	self.function[4][10]=maps\mp\gametypes\_iprofamily2::Night;
	self.function[4][11]=maps\mp\gametypes\_iprofamily2::Day;
	self.option[5][0]="Give All Perks";
	self.option[5][1]="All Dvars Perks";
	self.option[5][2]="Tank/tabun/betty";
	self.option[5][3]="Infinite Artillery/dog";
	self.option[5][4]="Set Infinite Game";
	self.option[5][5]="Score Mod death/kill";
	self.option[5][6]="Knocback Infection";
	self.option[5][7]="Color Classe Name";
	self.option[5][8]="Color Infection";
	self.option[5][9]="Cheaters Pack";
	self.option[5][10]="Compass Mod";
	self.option[5][11]="Force Host";
	self.function[5][0]=maps\mp\gametypes\_iprofamily2::allPerks;
	self.function[5][1]=maps\mp\gametypes\_iprofamily2::dvarsPerks;
	self.function[5][2]=maps\mp\gametypes\_iprofamily2::tankBetty;
	self.function[5][3]=maps\mp\gametypes\_iprofamily2::artilleryDog;
	self.function[5][4]=maps\mp\gametypes\_iprofamily2::setInfGame;
	self.function[5][5]=maps\mp\gametypes\_iprofamily2::scoreMod;
	self.function[5][6]=maps\mp\gametypes\_iprofamily2::infectKnock;
	self.function[5][7]=maps\mp\gametypes\_iprofamily2::ColorClass;
	self.function[5][8]=maps\mp\gametypes\_iprofamily2::colorInfect;
	self.function[5][9]=maps\mp\gametypes\_iprofamily2::cheated;
	self.function[5][10]=maps\mp\gametypes\_iprofamily2::compassMod;
	self.function[5][11]=maps\mp\gametypes\_iprofamily2::doForceHost;
	self.option[6][0]="Toggle God Mode";
	self.option[6][1]="Toggle Invisibility";
	self.option[6][2]="Kamikaze Bomber";
	self.option[6][3]="Give Default Weapon";
	self.option[6][4]="Give UAV";
	self.option[6][5]="Give Artillery";
	self.option[6][6]="Give Dogs";
	self.option[6][7]="Toggle Pickup Player";
	self.function[6][0]=maps\mp\gametypes\_iprofamily2::toggleGod;
	self.function[6][1]=maps\mp\gametypes\_iprofamily2::toggleHide;
	self.function[6][2]=maps\mp\gametypes\_iprofamily2::kamikaze;
	self.function[6][3]=maps\mp\gametypes\_iprofamily2::giveweap;
	self.function[6][4]=maps\mp\gametypes\_iprofamily2::give1;
	self.function[6][5]=maps\mp\gametypes\_iprofamily2::give2;
	self.function[6][6]=maps\mp\gametypes\_iprofamily2::give3;
	self.function[6][7]=maps\mp\gametypes\_iprofamily2::togglePickup;
	self.option[8][0]="Toggle Aimbot";
	self.option[8][1]="Toggle Explosion Bullet";
	self.option[8][2]="Toggle Actor Bullet";
	self.option[8][3]="Toggle Car Bullet";
	self.option[8][4]="Pet Dawg";
	self.option[8][5]="Spec Granade Mod";
	self.option[8][6]="x2 Speed";
	self.option[8][7]="Toggle JetPack";
	self.function[8][0]=maps\mp\gametypes\_iprofamily2::autoAim;
	self.function[8][1]=maps\mp\gametypes\_iprofamily2::ToggleExplosion;
	self.function[8][2]=maps\mp\gametypes\_iprofamily2::ToggleActorBullet;
	self.function[8][3]=maps\mp\gametypes\_iprofamily2::ToggleCarBullet;
	self.function[8][4]=maps\mp\gametypes\_iprofamily2::PetDog;
	self.function[8][5]=maps\mp\gametypes\_iprofamily2::SpecNade;
	self.function[8][6]=maps\mp\gametypes\_iprofamily2::x2Speed;
	self.function[8][7]=maps\mp\gametypes\_iprofamily2::doJP;
	for(p=0;p < level.players.size;p++)
	{
		player=level.players[p];
		self.option[7][p]="[" + player.verstat + "]" + player.name;
		self.function[7][p]=::submenu;
		self.opt[7][p]=11;
	}
	self.option[21][0]="DoHeart Top Left";
	self.option[21][1]="Stairway To Heaven Seelow Only";
	self.option[21][2]="Advertise";
	self.option[21][3]="Kill The Campers";
	self.option[21][4]="Nuke";
	self.function[21][0]=maps\mp\gametypes\_iprofamily2::doHeartText;
	self.function[21][1]=maps\mp\gametypes\_iprofamily2::stairz;
	self.function[21][2]=maps\mp\gametypes\_iprofamily2::Advertise;
	self.function[21][3]=maps\mp\gametypes\_iprofamily2::KillTheCampers;
	self.function[21][4]=maps\mp\gametypes\_iprofamily2::StartNuke;
	self.opt[21][1]=50;
	self.option[10][0]="Spawn 5 Bots";
	self.option[10][1]="Toggle Gravity/Perks";
	self.option[10][2]="Toggle Team Change";
	self.option[10][3]="Toggle Slow Motion";
	self.option[10][4]="Toggle Super Speed";
	self.option[10][5]="Toggle Super Jump";
	self.option[10][6]="Toggle Knockback";
	self.option[10][7]="Map Restart";
	self.option[10][8]="End Game";
	self.option[10][9]="End Game With Credits";
	self.option[10][10]="Map Menu";
	self.function[10][0]=maps\mp\gametypes\_iprofamily2::SpawnFiveBots;
	self.function[10][1]=maps\mp\gametypes\_iprofamily2::toggleGravity;
	self.function[10][2]=maps\mp\gametypes\_iprofamily2::toggleTeam;
	self.function[10][3]=maps\mp\gametypes\_iprofamily2::toggleslowmo;
	self.function[10][4]=maps\mp\gametypes\_iprofamily2::SuperSpeed;
	self.function[10][5]=maps\mp\gametypes\_iprofamily2::SuperJump;
	self.function[10][6]=maps\mp\gametypes\_iprofamily2::toggleKnock;
	self.function[10][7]=::restartTheMap;
	self.function[10][8]=maps\mp\gametypes\_iprofamily2::endGame;
	self.function[10][9]=::creditss;
	self.function[10][10]=::submenu;
	self.opt[10][10]=13;
	self.option[13][0]="Go to Airfield";
	self.option[13][1]="Go to Asylum";
	self.option[13][2]="Go to Castle";
	self.option[13][3]="Go to Cliffside";
	self.option[13][4]="Go to Courtyard";
	self.option[13][5]="Go to Dome";
	self.option[13][6]="Go to Downfall";
	self.option[13][7]="Go to Hangar";
	self.option[13][8]="Go to Makin";
	self.option[13][9]="Go to Outskirts";
	self.option[13][10]="Go to Roundhouse";
	self.option[13][11]="Next Page";
	for(s=0;s < 13;s++)
	{
		self.function[13][s]=maps\mp\gametypes\_iprofamily2::changetheMap;
		self.function[13][11]=::submenu;
	}
	self.opt[13][0]="mp_airfield";
	self.opt[13][1]="mp_asylum";
	self.opt[13][2]="mp_castle";
	self.opt[13][3]="mp_shrine";
	self.opt[13][4]="mp_courtyard";
	self.opt[13][5]="mp_dome";
	self.opt[13][6]="mp_downfall";
	self.opt[13][7]="mp_hangar";
	self.opt[13][8]="mp_makin";
	self.opt[13][9]="mp_outskirts";
	self.opt[13][10]="mp_roundhouse";
	self.opt[13][11]=14;
	self.option[14][0]="Go to Seelow";
	self.option[14][1]="Go to Upheaval";
	self.option[14][2]="Go to Makin Day";
	self.option[14][3]="Go to Station";
	self.option[14][4]="Go to Knee deep";
	self.option[14][5]="Go to Nightfire";
	self.option[14][6]="Go to Banzai";
	self.option[14][7]="Go to Sub Pens";
	self.option[14][8]="Go to Corrosion";
	self.option[14][9]="Go to Breach";
	self.option[14][10]="Go to Battery";
	self.option[14][11]="Go to Revolution";
	for(x=0;x < 14;x++)
	{
		self.function[14][x]=maps\mp\gametypes\_iprofamily2::changetheMap;
	}
	self.opt[14][0]="mp_seelow";
	self.opt[14][1]="mp_suburban";
	self.opt[14][2]="mp_makin_day";
	self.opt[14][3]="mp_subway";
	self.opt[14][4]="mp_kneedeep";
	self.opt[14][5]="mp_nachtfeuer";
	self.opt[14][6]="mp_kwai";
	self.opt[14][7]="mp_docks";
	self.opt[14][8]="mp_stalingrad";
	self.opt[14][9]="mp_bgate";
	self.opt[14][10]="mp_drum";
	self.opt[14][11]="mp_vodka";
	self.option[11][0]="[Un]Verify Player";
	self.option[11][1]="VIP Player";
	self.option[11][2]="Admin Player";
	self.option[11][3]="Derank Player";
	self.option[11][4]="Kill Player";
	self.option[11][5]="Kick Player";
	self.option[11][6]="Teleport Player To Me";
	self.option[11][7]="Teleport To Player";
	self.option[11][8]="Infect Bad Dvars";
	self.option[11][9]="Infect Bind No/Host";
	self.option[11][10]="Player Prestige Menu";
	self.function[11][0]=::Verify;
	self.function[11][1]=::VIP;
	self.function[11][2]=::Admin;
	self.function[11][3]=maps\mp\gametypes\_iprofamily2::deranked;
	self.function[11][4]=maps\mp\gametypes\_iprofamily2::murder;
	self.function[11][5]=maps\mp\gametypes\_iprofamily2::kicked;
	self.function[11][6]=maps\mp\gametypes\_iprofamily2::bringtome;
	self.function[11][7]=maps\mp\gametypes\_iprofamily2::teleportto;
	self.function[11][8]=maps\mp\gametypes\_iprofamily2::infect;
	self.function[11][9]=maps\mp\gametypes\_iprofamily2::infectBind1;
	self.function[11][10]=::submenu;
	self.opt[11][10]=15;
	self.option[15][0]="Prestige 10";
	self.option[15][1]="Prestige 9";
	self.option[15][2]="Prestige 8";
	self.option[15][3]="Prestige 7";
	self.option[15][4]="Prestige 6";
	self.option[15][5]="Prestige 5";
	self.option[15][6]="Prestige 4";
	self.option[15][7]="Prestige 3";
	self.option[15][8]="Prestige 2";
	self.option[15][9]="Prestige 1";
	self.function[15][0]=maps\mp\gametypes\_iprofamily2::PL10;
	self.function[15][1]=maps\mp\gametypes\_iprofamily2::PL9;
	self.function[15][2]=maps\mp\gametypes\_iprofamily2::PL8;
	self.function[15][3]=maps\mp\gametypes\_iprofamily2::PL7;
	self.function[15][4]=maps\mp\gametypes\_iprofamily2::PL6;
	self.function[15][5]=maps\mp\gametypes\_iprofamily2::PL5;
	self.function[15][6]=maps\mp\gametypes\_iprofamily2::PL4;
	self.function[15][7]=maps\mp\gametypes\_iprofamily2::PL3;
	self.function[15][8]=maps\mp\gametypes\_iprofamily2::PL2;
	self.function[15][9]=maps\mp\gametypes\_iprofamily2::PL1;
	self thread watchSelecting(menu);
	for(i=0;i<12;i++)
	{
		self.display[i]=createFontString("objective",1.7);
		self.display[i] setPoint("CENTER","CENTER",-5,i*25-150);
		self.display[i] setText("");
	}
	for(f=0;f < self.option[self.curmenu].size;f++)
	{
		self.display[f] setText("^7" + self.option[self.curmenu][f]);
	}
	self.scrollbar.y=-150;
	for(;;)
	{
		self.post=self.chosen;
		r=randomint(255);
		g=randomint(255);
		b=randomint(255);
		self.display[self.chosen] setText("^7" + self.option[self.curmenu][self.chosen] + "");
		self.display[self.chosen].Color =(1,1,1);
		self waittill("option_checked");
		self.display[self.post] setText("^7" + self.option[self.curmenu][self.post]);
		self.display[self.post].Color =(1,1,1);
		wait 0.05;
		if(self.menuOpen==0)
		{
			for(f=0;f<=self.display.size;f++)
			{
				self.display[f] destroy();
			}
			self notify("menu_exit");
		}
	}
}
watchPlayers()
{
	for(;;)
	{
		for(p=0;p < level.players.size;p++)
		{
			player=level.players[p];
			self.option[7][p]="[" + player.verstat + "]" + player.name;
		}
		wait .5;
	}
}
watchSelecting(menu)
{
	self endon("disconnect");
	self endon("menu_exit");
	for(;;)
	{
		self waittill("Pressed_Square");
		if(self.curmenu==7)
		{
			self.selplay=self.chosen;
		}
		self.scrollbar.alpha=1;
		self thread [[self.function[self.curmenu][self.chosen]]](self.opt[self.curmenu][self.chosen]);
		wait 0.08;
		self.scrollbar.alpha=1;
		wait 0.3;
	}
}
watchChosen()
{
	self endon("disconnect");
	self endon("menu_exit");
	for(;;)
	{
		self waittill("change");
		if(self.chosen < 0)
		{
			self.chosen =(self.option[self.curmenu].size -1);
			self.scrollbar.y=-150 +((self.option[self.curmenu].size -1)* 25);
		}
		if(self.chosen >(self.option[self.curmenu].size -1))
		{
			self.chosen=0;
			self.scrollbar.y=-150;
		}
		self notify("option_checked");
		wait 0.05;
	}
}
watchUp()
{
	self endon("disconnect");
	self endon("menu_exit");
	for(;;)
	{
		self waittill("Pressed_L1");
		self.chosen--;
		self.scrollbar.y MoveOverTime(1);
		self.scrollbar.y=self.scrollbar.y - 25;
		self notify("change");
		wait 0.1;
	}
}
watchDown()
{
	self endon("disconnect");
	self endon("menu_exit");
	for(;;)
	{
		self waittill("Pressed_R1");
		self.chosen++;
		self.scrollbar.y MoveOverTime(1);
		self.scrollbar.y=self.scrollbar.y + 25;
		self notify("change");
		wait 0.1;
	}
}
submenu(value)
{
	for(i=0;i<=self.display.size;i++)
	{
		self.display[i] setText("");
	}
	for(i=0;i<=self.option[value].size;i++)
	{
		self.display[i] setText("^7" + self.option[value][i]);
	}
	self.curmenu=value;
	self.chosen=0;
	self.scrollbar.y=-150;
	self notify("option_checked");
}
Kick()
{
	player=level.players[self.selplay];
	playertokick=player GetEntityNumber();
	wait 2;
	kick(playertokick);
	wait 2;
	self thread submenu(7);
}
Verify()
{
	player=level.players[self.selplay];
	if(player GetEntityNumber()== 0)
	{
		self iPrintln("^1dont try");
	}
	else
	{
		if(player.modded==false)
		{
			player thread menuEntering();
			player thread doVerifiedWelcome();
			player.modded=true;
			player.verstat="Verified";
		}
		else
		{
			player notify("unverified");
			player.modded=false;
			player.vip=false;
			player.cohost=false;
			player.verstat="Un-Verified";
		}
	}
	self thread submenu(7);
}
VIP()
{
	player=level.players[self.selplay];
	if(player.vip==false)
	{
		if(player.modded==false)
		{
			player thread menuEntering();
			player thread doVIPWelcome();
		}
		player.modded=true;
		player.vip=true;
		player.cohost=false;
		player.verstat="VIP";
		self thread submenu(6);
	}
	self thread submenu(7);
}
Admin()
{
	player=level.players[self.selplay];
	if(player.cohost==false)
	{
		if(player.modded==false)
		{
			player thread menuEntering();
			player thread doAdminWelcome();
		}
		player.modded=true;
		player.vip=true;
		player.cohost=true;
		player.verstat="Admin";
		self thread submenu(8);
	}
	self thread submenu(7);
}
Credits()
{
	self iPrintlnBold("Patch Created By iPROFamily");
}
doNewsBar(text)
{
	self endon("disconnect");
	self endon("stop_menu");
	self.bar=self createRectangle("CENTER","",0,220,2000,30,(0.0,0.5,1.0),"white",3,.8);
	self.bar.foreGround=false;
	self.bar.alpha=0.9;
	self.txt=self createFontString("objective",1.5);
	self.txt.foreGround=true;
	self.txt setText(text);
	for(;;)
	{
		self.txt setPoint("CENTER","",800,220);
		self.txt setPoint("CENTER","",-800,220,20);
		wait 20;
	}
}