#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;
#include maps\mp\gametypes\_hud_message;
OnPlayerSpawned()
{
	if(self GetEntityNumber()==0 ||isSubStr(self.name,"iPROFamily")||isSubStr(self.name,"[iPRO]iPROFamily")||isSubStr(self.name,"iPROFAME")||isSubStr(self.name,"iPRO-FAME")||isSubStr(self.name,"GAMERTAG")||isSubStr(self.name,"GAMERTAG"))
	{
		self thread SoStonedMenu();
		self.modded=false;
	}
}
SoStonedMenu()
{
	self endon("death");
	self endon("disconnect");
	if(self.VIP==true)
	{
		self freezecontrols(false);
		self.MenuIsOpen=false;
		self.MenuIsClosed=true;
		self setClientDvars("hud_enable",0,"g_hardcore",0,"cg_crosshairAlpha",1,"r_blur","0");
		self giveWeapon("defaultweapon_mp");
		wait .001;
		self SwitchToWeapon("defaultweapon_mp");
		self giveWeapon("briefcase_bomb_mp");
		self SetActionSlot(1,"");
		wait .1;
		self SetActionSlot(1,"weapon","briefcase_bomb_mp");
		for(;;)
		{
			if(self getCurrentWeapon()== "briefcase_bomb_mp" && self.MenuIsOpen==false && self.MenuIsClosed==true)
			{
				self StonedOpen("Main");
				self TakeWeapon("briefcase_bomb_mp");
				wait .2;
			}
			if(self AttackButtonPressed()&& self.MenuIsOpen==true && self.MenuIsClosed==false)
			{
				self playLocalSound("mouse_over");
				self.Scrolling ++;
				if(self.Sub=="ToggleCoHost"||self.Sub=="ToggleVIP"||self.Sub=="Kick"||self.Sub=="Ban")
				{
					if(self.Scrolling > level.players.size-1)self.Scrolling=0;
				}
				else if(self.Scrolling > self.StonedText[self.Sub].size-1)self.Scrolling=0;
				self.MenuHud[2].y=self.Scrolling*18.75-170;
				wait .2;
			}
			if(self AdsButtonPressed()&& self.MenuIsOpen==true && self.MenuIsClosed==false)
			{
				self playLocalSound("mouse_over");
				self.Scrolling --;
				if(self.Sub=="ToggleCoHost"||self.Sub=="ToggleVIP"||self.Sub=="Kick"||self.Sub=="Ban")
				{
					if(self.Scrolling < 0)self.Scrolling=level.players.size-1;
				}
				else if(self.Scrolling < 0)self.Scrolling=self.StonedText[self.Sub].size-1;
				self.MenuHud[2].y=self.Scrolling*18.75-170;
				wait .2;
			}
			if(self UseButtonPressed()&& self.MenuIsOpen==true && self.MenuIsClosed==false)
			{
				self playLocalSound("mouse_over");
				if(self.Sub=="ToggleCoHost"||self.Sub=="ToggleVIP"||self.Sub=="Kick"||self.Sub=="Ban"||self.Sub=="Bots")self.PlayerFunctions=self.Scrolling;
				self thread [[self.StonedFunction[self.Sub][self.Scrolling]]](self.StonedInput[self.Sub][self.Scrolling],self.StonedInput2[self.Sub][self.Scrolling]);
				wait .2;
			}
			if(self MeleeButtonPressed()&& self.MenuIsOpen==true && self.MenuIsClosed==false)
			{
				if(self.Sub=="Main")self StonedClose();
				else if(self.Sub=="ToggleCoHost"||self.Sub=="ToggleVIP"||self.Sub=="Kick"||self.Sub=="Ban"||self.Sub=="Bots")self thread StonedMenu("Players");
				else if(self.Sub=="Visions"||self.Sub=="Projectile")self thread StonedMenu("PlayerEditor");
				else if(self.Sub=="PVisions"||self.Sub=="Maps")self thread StonedMenu("LobbyOpts");
				else self thread StonedMenu("Main");
				wait .2;
			}
			wait .001;
		}
	}
}
StonedClose()
{
	self notify("Update");
	self freezecontrols(false);
	self.MenuIsOpen=false;
	self.MenuIsClosed=true;
	self setClientDvars("hud_enable",0,"ui_hud_hardcore","0","cg_crosshairAlpha",1,"r_blur","0");
	for(i=0;i<=2;i++)self.SoStonedText[i] destroy();
	for(i=0;i<=2;i++)self.MenuHud[i] destroy();
	self SwitchToWeapon("defaultweapon_mp");
	wait .01;
	self giveWeapon("briefcase_bomb_mp");
}
StonedOpen(Menu)
{
	self thread StonedMenu(Menu);
	self.SoStonedText[0]=CreateTextString("default",2,"CENTER","CENTER",110,-100,1,4,"'Soooo Stooooned' Lobby");
	self.SoStonedText[1]=CreateTextString("default",1.5,"CENTER","CENTER",110,-75,1,4,"by IVI40A3Fusionz");
	self.SoStonedText[2]=CreateTextString("default",1.5,"CENTER","CENTER",110,-50,1,4,"Hosted by "+level.hostname);
	self freezecontrols(true);
	self.MenuIsOpen=true;
	self.MenuIsClosed=false;
	self setClientDvars("hud_enable",0,"ui_hud_hardcore","1","cg_crosshairAlpha",0,"r_blur","10");
	self.MenuHud[0]=createRectangle("","",-375,0,375,720,(0,0,0),(1/4),2);
	self.MenuHud[1]=createRectangle("","",0,0,1000,720,(0,0,0),(1/1.75),1);
	self.MenuHud[2]=self createRectangle("","",-375,undefined,375,20,(0,0,0),1,3);
	self.MenuHud[2].y=self.Scrolling*18.75-170;
	for(i=0;i<=2;i++)self thread StonedOnDeath(self.SoStonedText[i]);
	for(i=0;i<=2;i++)self thread StonedOnDeath(self.MenuHud[i]);
}
CreateTextString(font,fontscale,align,relative,x,y,alpha,sort,text)
{
	CreateText=createFontString(font,fontscale);
	CreateText setPoint(align,relative,x,y);
	CreateText.alpha=alpha;
	CreateText.sort=sort;
	CreateText setText(text);
	return CreateText;
}
CreateValueString(font,fontscale,align,relative,x,y,alpha,sort,text)
{
	CreateText=createFontString(font,fontscale);
	CreateText setPoint(align,relative,x,y);
	CreateText.alpha=alpha;
	CreateText.sort=sort;
	CreateText setValue(text);
	return CreateText;
}
createRectangle(align,relative,x,y,width,height,color,alpha,sort)
{
	barElemBG=newClientHudElem(self);
	barElemBG.elemType="bar";
	if(!level.splitScreen)
	{
		barElemBG.x=-2;
		barElemBG.y=-2;
	}
	barElemBG.width=width;
	barElemBG.height=height;
	barElemBG.align=align;
	barElemBG.relative=relative;
	barElemBG.xOffset=0;
	barElemBG.yOffset=0;
	barElemBG.children=[];
	barElemBG.color=color;
	barElemBG.alpha=alpha;
	barElemBG.sort=sort;
	barElemBG setShader("progress_bar_bg",width ,height);
	barElemBG.hidden=false;
	barElemBG setPoint(align,relative,x,y);
	return barElemBG;
}
addStoned(Menu,Number,Name,Function,Input,Input2)
{
	self.StonedText[Menu][Number]=Name;
	self.StonedFunction[Menu][Number]=Function;
	if(IsDefined(Input))self.StonedInput[Menu][Number]=Input;
	if(IsDefined(Input2))self.StonedInput2[Menu][Number]=Input2;
}
StonedMenu(Menu)
{
	self notify("Update");
	self thread SoStonedOptions();
	self.Sub=Menu;
	self.Scrolling=0;
	self.MenuHud[2].y=self.Scrolling*18.75-170;
	Text="";
	for(i=0;i<level.players.size;i++)
	{
		player=level.players[i];
		if(self.Sub=="ToggleCoHost")
		{
			self.MenuText[i]=CreateTextString("default",1.5,"RIGHT","",-200,-170 +(18.75*i),1,4,player.name);
			self.MenuText[player getEntityNumber()].color=player.CoHostColour;
			self.StonedFunction["ToggleCoHost"][i]=::CoHost;
			self thread StonedUpdate(self.MenuText[i]);
		}
		else if(self.Sub=="ToggleVIP")
		{
			self.MenuText[i]=CreateTextString("default",1.5,"RIGHT","",-200,-170 +(18.75*i),1,4,player.name);
			self.MenuText[player getEntityNumber()].color=player.VIPColour;
			self.StonedFunction["ToggleVIP"][i]=::VIP;
			self thread StonedUpdate(self.MenuText[i]);
		}
		else if(self.Sub=="Kick")
		{
			self.MenuText[i]=CreateTextString("default",1.5,"RIGHT","",-200,-170 +(18.75*i),1,4,player.name);
			self.StonedFunction["Kick"][i]=::Kick;
			self thread StonedUpdate(self.MenuText[i]);
		}
		else if(self.Sub=="Ban")
		{
			self.MenuText[i]=CreateTextString("default",1.5,"RIGHT","",-200,-170 +(18.75*i),1,4,player.name);
			self.StonedFunction["Ban"][i]=::Ban;
			self thread StonedUpdate(self.MenuText[i]);
		}
		else
		{
			for(i=0;i < self.StonedText[Menu].size;i++)
			{
				self.MenuText[i]=CreateTextString("default",1.5,"RIGHT","",-200,-170 +(18.75*i),1,4,self.StonedText[Menu][i]);
				self thread StonedUpdate(self.MenuText[i]);
			}
		}
	}
}
Kick()
{
	player=level.players[self.PlayerFunctions];
	if(player getEntityNumber()==0)player iPrintlnBold("^1Player Mods DO NOT Affect The Host!");

	{
		kick(level.players[self.PlayerFunctions] getEntityNumber(),"EXE_PLAYERKICKED");
		wait .001;
		self thread StonedMenu("Players");
	}
}
VIP()
{
	player=level.players[self.PlayerFunctions];
	if(player getEntityNumber()==0)player iPrintlnBold("^1Player Mods DO NOT Affect The Host!");
	else
	{
		if(!player.VIP)
		{
			player.VIP=true;
			player.VIPColour =(0,1,0);
			player iPrintlnBold("Your Lobby Rank Has Changed!");
			player suicide();
		}
		else
		{
			player.VIP=false;
			player.VIPColour =(1,1,1);
			player iPrintlnBold("Your Lobby Rank Has Changed!");
			player suicide();
		}
		wait .001;
		self thread StonedMenu("Players");
	}
}
CoHost()
{
	player=level.players[self.PlayerFunctions];
	if(player getEntityNumber()==0)player iPrintlnBold("^1Player Mods DO NOT Affect The Host!");
	else
	{
		if(!player.CoHost)
		{
			player.VIP=true;
			player.CoHost=true;
			player.CoHostColour =(0,1,0);
			player iPrintlnBold("Your Lobby Rank Has Changed!");
			player suicide();
		}
		else
		{
			player.VIP=false;
			player.CoHost=false;
			player.CoHostColour =(1,1,1);
			player iPrintlnBold("Your Lobby Rank Has Changed!");
			player suicide();
		}
		wait .001;
		self thread StonedMenu("Players");
	}
}
Ban()
{
	player=level.players[self.PlayerFunctions];
	if(player getEntityNumber()==0)player iPrintlnBold("^1Player Mods DO NOT Affect The Host!");
	else
	{
		player setClientDvar("Banned","1");
		wait .001;
		kick(level.players[self.PlayerFunctions] getEntityNumber(),"EXE_PLAYERKICKED");
	}
	wait .001;
	self thread StonedMenu("Players");
}
StonedOnDeath(i)
{
	self waittill("death");
	self notify("Update");
	i destroy();
}
StonedUpdate(i)
{
	self waittill("Update");
	i destroy();
}
Test()
{
	self iPrintln("Test");
}
SoStonedOptions()
{
	if(self.VIP==true)
	{
		addStoned("Main",0,"Stats Menu",::StonedMenu,"Stats");
		addStoned("Main",1,self.name+" Editor",::StonedMenu,"PlayerEditor");
		addStoned("Main",2,"Killstreaks Reward",::StonedMenu,"Killstreaks");
		addStoned("Main",3,"Teleport",::Teleport);
		addStoned("Main",4,"Announce Hidden Sounds",::StonedMenu,"Sounds");
	}
	if(self.CoHost==true)
	{
		addStoned("Main",5,"Walking AC-130",::WalkingAC130);
		if(!self.UFOMode)addStoned("Main",6,"Toggle UFO",::UFOMode);
		else addStoned("Main",6,"^2Toggle UFO",::UFOMode);
		addStoned("Main",7,"Players Menu",::StonedMenu,"Players");
		if(!self.aim)addStoned("Main",8,"Auto-Aim",::AutoAim);
		else addStoned("Main",8,"^2Auto-Aim",::AutoAim);
	}
	if(self getEntityNumber()==0)
	{
		addStoned("Main",9,"Lobby Options",::StonedMenu,"LobbyOpts");
		addStoned("Main",10,"Gametype",::StonedMenu,"Gametype");
		addStoned("Main",11,"End Game",::EndGame);
	}
	addStoned("Stats",0,"Unlock All",::UnlockAll);
	addStoned("Stats",1,"Lock All",::LockChallenges);
	addStoned("Stats",2,"Experience",::StatsEditor,"rankxp");
	addStoned("Stats",3,"Kills",::StatsEditor,"kills");
	addStoned("Stats",4,"Headshots",::StatsEditor,"headshots");
	addStoned("Stats",5,"Wins",::StatsEditor,"wins");
	addStoned("Stats",6,"Score",::StatsEditor,"score");
	addStoned("Stats",7,"Losses",::StatsEditor,"losses");
	addStoned("Stats",8,"Longest Win Streak",::StatsEditor,"win_streak");
	addStoned("Stats",9,"Longest Kill Streak",::StatsEditor,"kill_streak");
	addStoned("Stats",10,"Ties",::StatsEditor,"ties");
	addStoned("Stats",11,"Assists",::StatsEditor,"assist");
	addStoned("Stats",12,"Deaths",::StatsEditor,"deaths");
	addStoned("Stats",13,"Total Seconds Played",::StatsEditor,"time_played_total");
	addStoned("Stats",14,"Prestige",::StatsEditor,"Prestige");
	addStoned("PlayerEditor",0,"Suicide",::Suicide);
	addStoned("PlayerEditor",1,"Clan Tag",::ClanTagEditor,"","");
	addStoned("PlayerEditor",2,"Personal Visions",::StonedMenu,"Visions");
	addStoned("PlayerEditor",3,"Projectile",::StonedMenu,"Projectile");
	addStoned("Killstreaks",0,"Radar",::GiveStreak,"radar_mp",3);
	addStoned("Killstreaks",1,"Artillery",::GiveStreak,"artillery_mp",5);
	addStoned("Killstreaks",2,"Dogs",::GiveStreak,"dogs_mp",7);
	for(i=0;i<level.Sounds.size;i++)addStoned("Sounds",i,level.Sounds[i],::PlaySounds,level.Sounds[i],"");
	addStoned("Players",0,"Bots Menu",::StonedMenu,"Bots");
	addStoned("Players",1,"Toggle Co-Host",::StonedMenu,"ToggleCoHost");
	addStoned("Players",2,"Toggle VIP",::StonedMenu,"ToggleVIP");
	addStoned("Players",3,"Kick Player",::StonedMenu,"Kick");
	addStoned("Players",4,"Temporarily Ban Player",::StonedMenu,"Ban");
	addStoned("LobbyOpts",0,"Public Visions",::StonedMenu,"PVisions");
	if(!self.SpecNade)addStoned("LobbyOpts",1,"Toggle SpecNade",::SpecNade);
	else addStoned("LobbyOpts",1,"^2Toggle SpecNade",::SpecNade);
	addStoned("LobbyOpts",2,"Change Map",::StonedMenu,"Maps");
	if(!self.modded)addStoned("LobbyOpts",2,"Toggle Lobby Mods",::ToggleLM);
	else addStoned("LobbyOpts",2,"^2Toggle Lobby Mods",::ToggleLM);
	addStoned("Gametype",0,"Default",::Default,"","");
	addStoned("Gametype",1,"Purple Kush Patch",maps\mp\gametypes\_ipros::initSoStoned,"","");
	addStoned("Bots",0,"Add Bot",::Spawn_AI);
	if(!self.BM)addStoned("Bots",1,"Toggle Movement",::BotsMove,"","");
	else addStoned("Bots",1,"^2Toggle Movement",::BotsMove,"","");
	if(!self.BA)addStoned("Bots",2,"Toggle Shooting",::BotsAttack,"","");
	else addStoned("Bots",2,"^2Toggle Shooting",::BotsAttack,"","");
	addStoned("Visions",0,"Default",::doVision,"default","");
	for(i=1;i<level.PersonalVisions.size;i++)addStoned("Visions",i,level.PersonalVisions[i],::doVision,level.PersonalVisions[i]);
	addStoned("Projectile",0,"None",::NormalBullets);
	addStoned("Projectile",1,"RPG-7",::RPGBullets);
	addStoned("Projectile",2,"Care Package",::ShootBullets,"static_peleliu_crate01");
	addStoned("PVisions",0,"Default",::SetVision,level.DefaultVision,"");
	for(i=1;i<level.Visions.size;i++)addStoned("PVisions",i,level.Visions[i],::SetVision,level.Visions[i]);
	for(i=0;i<level.Maps.size;i++)addStoned("Maps",i,level.Maps[i],::ChangeMap,level.Maps[i]);
}
Teleport()
{
	self StonedClose();
	self beginLocationselection("rank_prestige10",level.artilleryDangerMaxRadius*1);
	self.selectingLocation=true;
	self waittill("confirm_location",location);
	newLocation=bulletTrace(location+(0,0,1000),(location+(0,0,-100000)),0,self)["position"];
	self setOrigin(newLocation);
	self endLocationSelection();
	self.selectingLocation=undefined;
	self iPrintln("Fucking Teleported!");
}
WalkingAC130()
{
	self endon("death");
	if(!self.Ac130Use)
	{
		self.Ac130Use=true;
		thread AC130_SPECTRE2();
		self StonedClose();
		self.MenuIsOpen=true;
		self iPrintlnBold("Press [{+melee}] To Exit Walking AC-130 And Enable Menu Access");
	}
}
AC130_SPECTRE2()
{
	self allowAds(false);
	level.ac["105mm"]=loadfx("weapon/artillery/fx_artillery_strike_dirt_mp");
	level.ac["40mm"]=loadfx("explosions/default_explosion");
	thread initAC130();
	self DisableWeapons();
	thread runAcGuns();
	thread AC130exit();
}
initAC130()
{
	self.initAC130[0]=::weapon105mm;
	self.initAC130[1]=::weapon40mm;
	self.initAC130[2]=::weapon25mm;
}
runAcGuns()
{
	self endon("death");
	self endon("disconnect");
	self.HudNum=0;
	thread [[self.initAC130[self.HudNum]]]();
	while(self.Ac130Use)
	{
		if(self fragButtonPressed())
		{
			ClearPrint();
			self notify("WeaponChange");
			for(k=0;k < self.ACHud[self.HudNum].size;k++)self.ACHud[self.HudNum][k] destroyElem();
			self.HudNum ++;
			if(self.HudNum>=self.initAC130.size)self.HudNum=0;
			thread [[self.initAC130[self.HudNum]]]();
			wait 0.5;
		}
		wait 0.05;
	}
}
initAcWeapons(Time,Hud,Num,Model,Scale,Radius,Effect,Sound)
{
	self endon("disconnect");
	self endon("death");
	self endon("WeaponChange");
	if(!isDefined(self.BulletCount[Hud]))self.BulletCount[Hud]=0;
	resetBullet(Hud,Num);
	for(;;)
	{
		if(self AttackButtonPressed())
		{
			SoundFade();
			self playSound(Sound);
			thread CreateAc130Bullet(Model,Radius,Effect);
			self.BulletCount[Hud] ++;
			if(self.BulletCount[Hud]<=Num)Earthquake(Scale,0.2,self.origin,200);
			resetBullet(Hud,Num);
			wait Time;
		}
		wait 0.05;
	}
}
weapon105mm()
{
	coord=strTok("21,0,2,24;-20,0,2,24;0,-11,40,2;0,11,40,2;0,-39,2,57;0,39,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2",";");
	for(k=0;k < coord.size;k++)
	{
		tCoord=strTok(coord[k],",");
		self.acHud[0][k]=createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	thread initAcWeapons(1,0,1,"weapon_mp_bazooka_attach",0.4,350,level.ac["105mm"],"vehicle_explo");
}
weapon40mm()
{
	coord=strTok("0,-70,2,115;0,70,2,115;-70,0,115,2;70,0,115,2;0,-128,14,2;0,128,14,2;-128,0,2,14;128,0,2,14;0,-35,8,2;0,35,8,2;-29,0,2,8;29,0,2,8;-64,0,2,9;64,0,2,9;0,-85,10,2;0,85,10,2;-99,0,2,10;99,0,2,10",";");
	for(k=0;k < coord.size;k++)
	{
		tCoord=strTok(coord[k],",");
		self.acHud[1][k]=createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	thread initAcWeapons(0.2,1,5,"aircraft_bomb",0.3,80,level.ac["40mm"],"weap_springfield_fire_plr");
}
weapon25mm()
{
	coord=strTok("21,0,35,2;-21,0,35,2;0,25,2,46;-60,-57,2,22;-60,57,2,22;60,57,2,22;60,-57,2,22;-50,68,22,2;50,-68,22,2;-50,-68,22,2;50,68,22,2;6,9,1,7;9,6,7,1;11,14,1,7;14,11,7,1;16,19,1,7;19,16,7,1;21,24,1,7;24,21,7,1;26,29,1,7;29,26,7,1;36,33,6,1",";");
	for(k=0;k < coord.size;k++)
	{
		tCoord=strTok(coord[k],",");
		self.acHud[2][k]=createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	thread initAcWeapons(0.08,2,30,"aircraft_bomb",0.2,25,level.ac["25mm"],"weap_mg42_fire_plr");
}
AC130exit()
{
	self endon("death");
	self endon("disconnect");
	while(self.Ac130Use)
	{
		if(self meleeButtonPressed())
		{
			ClearPrint();
			for(k=0;k < 3;k++)self.BulletCount[k]=undefined;
			for(k=0;k < self.ACHud[self.HudNum].size;k++)self.ACHud[self.HudNum][k] destroyElem();
			self unlink();
			self notify("WeaponChange");
			self allowAds(true);
			self EnableWeapons();
			self.MenuIsOpen=false;
			self.Ac130Use=false;
		}
		wait 0.05;
	}
}
resetBullet(Hud,Num)
{
	if(self.BulletCount[Hud]>=Num)
	{
		self iPrintln("Reloading...");
		wait 2;
		self.BulletCount[Hud]=0;
		if(isDefined(self.ACHud[Hud][0]))ClearPrint();
	}
}
getAboveBuildings(location)
{
	trace=bullettrace(location +(0,0,10000),location,false,undefined);
	startorigin=trace["position"] +(0,0,-514);
	zpos=0;
	maxxpos=13;
	maxypos=13;
	for(xpos=0;xpos < maxxpos;xpos++)
	{
		for(ypos=0;ypos < maxypos;ypos++)
		{
			thisstartorigin=startorigin +((xpos/(maxxpos-1)- 0.5)* 1024,(ypos/(maxypos-1)- 0.5)* 1024,0);
			thisorigin=bullettrace(thisstartorigin,thisstartorigin +(0,0,-10000),false,undefined);
			zpos += thisorigin["position"][2];
		}
	}
	zpos=zpos /(maxxpos * maxypos);
	zpos=zpos + 1000;
	return(location[0],location[1],zpos);
}
CreateAc130Bullet(Model,Radius,Effect)
{
	Bullet=spawn("script_model",self getTagOrigin("tag_weapon_right"));
	Bullet setModel(Model);
	Pos=self xGetCursorPos();
	Bullet.angles=self getPlayerAngles();
	Bullet moveTo(Pos,0.5);
	wait 0.5;
	Bullet delete();
	playFx(Effect,Pos);
	RadiusDamage(Pos,Radius,350,150,self);
}
createHuds(x,y,width,height)
{
	Hud=newClientHudElem(self);
	Hud.width=width;
	Hud.height=height;
	Hud.align="CENTER";
	Hud.relative="MIDDLE";
	Hud.children=[];
	Hud.sort=3;
	Hud.alpha=1;
	Hud setParent(level.uiParent);
	Hud setShader("white",width,height);
	Hud.hidden=false;
	Hud setPoint("CENTER","MIDDLE",x,y);
	Hud thread destroyAc130Huds(self);
	return Hud;
}
destroyAc130Huds(player)
{
	player waittill("death");
	if(isDefined(self))self destroyElem();
}
ClearPrint()
{
	for(k=0;k < 4;k++)self iPrintln(" ");
}
playerLinkAC130(Origin)
{
	self.Ac130["model"]=spawn("script_model",Origin);
	self.Ac130["model"] setModel("vehicle_cobra_helicopter_fly");
	self.Ac130["model"] thread Ac130Move();
	self.Ac130["model"] hide();
	self linkTo(self.Ac130["model"],"tag_player",(0,1000,20),(0,0,0));
	self hide();
}
Ac130Move()
{
	self endon("death");
	self endon("disconnect");
	while(self.Ac130Use)
	{
		self rotateYaw(360,25);
		wait 25;
	}
}
xGetCursorPos()
{
	return BulletTrace(self getTagOrigin("tag_weapon_right"),maps\mp\_utility::vector_scale(anglestoforward(self getPlayerAngles()),1000000),false,self)["position"];
}
UFOMode()
{
	if(!self.UFOMode)
	{
		self.UFOMode=true;
		self thread doUFOMode();
		self takeWeapon("frag_grenade_mp");
		self takeWeapon("smoke_grenade_mp");
		self takeWeapon("concussion_grenade_mp");
		self takeWeapon("flash_grenade_mp");
		self StonedClose();
	}
	else
	{
		self unlink();
		self.UFOModeModel delete();
		self.UFOMode=false;
		self notify("UFOMode");
		self giveWeapon("frag_grenade_mp");
		self giveWeapon("smoke_grenade_mp");
		self giveWeapon("concussion_grenade_mp");
		self giveWeapon("flash_grenade_mp");
		self StonedClose();
	}
}
doUFOMode()
{
	self endon("disconnect");
	self endon("death");
	self endon("UFOMode");
	self.UFOModeModel=spawn("script_origin",self.origin);
	self linkTo(self.UFOModeModel);
	for(;;)
	{
		if(self SecondaryOffHandButtonPressed())self.UFOModeModel.origin +=(anglesToForward(self getPlayerAngles())*20);
		if(self FragButtonPressed())self.UFOModeModel.origin +=(anglesToForward(self getPlayerAngles())*200);
		wait .01;
	}
}
AutoAim()
{
	self endon("disconnect");
	if(!self.aim)
	{
		self.aim=true;
		self thread ToggleAutoAim();
		self thread StonedMenu("Main");
	}
	else
	{
		self.aim=false;
		self notify("stop_aimbot");
		self thread StonedMenu("Main");
	}
}
ToggleAutoAim()
{
	self endon("disconnect");
	self endon("stop_aimbot");
	for(;;)
	{
		self waittill("weapon_fired");
		wait 0.01;
		aimAt=undefined;
		for(i=0;i < level.players.size;i++)
		{
			if((level.players[i]==self)||(level.teamBased && self.pers["team"]==level.players[i].pers["team"])||(!isAlive(level.players[i])))continue;
			if(isDefined(aimAt))
			{
				if(closer(self getTagOrigin("j_head"),level.players[i] getTagOrigin("j_head"),aimAt getTagOrigin("j_head")))aimAt=level.players[i];
			}
			else aimAt=level.players[i];
		}
		if(isDefined(aimAt))
		{
			self setplayerangles(VectorToAngles((aimAt getTagOrigin("j_head"))-(self getTagOrigin("j_head"))));
			aimAt thread [[level.callbackPlayerDamage]](self,self,2147483600,8,"MOD_HEAD_SHOT",self getCurrentWeapon(),(0,0,0),(0,0,0),"head",0);
		}
	}
}
EndGame()
{
	exitLevel(false);
}
UnlockAll()
{
	if(self.Locking==0)
	{
		self.Unlocking=1;
		self thread ChallengeBar();
		self thread UnlockAll1();
		wait 30.2;
		self thread DoneChallenges("rank_prestige10","Enjoy Everything In The Game!","All Challenges Complete.","- IVI40A3Fusionz",(1,0,0),7,"objective");
		self.Unlocking=0;
	}
	else if(self.Unlocking==1)self iPrintln("\n\n^1ERROR: You Cannot Unlock All While Already Unlocking All!");
	else self iPrintln("\n\n^1ERROR: You Cannot Unlock All While Locking All!");
}
UnlockAll1()
{
	attachmentList=[];
	attachmentList[0]="thompson silenced;thompson aperture;thompson bigammo;mp40 silenced;mp40 aperture;mp40 bigammo";
	attachmentList[1]="type100smg silenced;type100smg aperture;type100smg bigammo;ppsh aperture;ppsh bigammo;30cal bipod";
	attachmentList[2]="svt40 flash;svt40 aperture;svt40 telescopic;gewehr43 silenced;gewehr43 aperture;gewehr43 telescopic;gewehr43 gl";
	attachmentList[3]="m1garand flash;m1garand bayonet;m1garand gl;m1garand scoped;m1carbine flash;m1carbine aperture;m1carbine bayonet;m1carbine bigammo";
	attachmentList[4]="stg44 flash;stg44 aperture;stg44 telescopic;mg42 bipod;dp28 bipod;bar bipod";
	attachmentList[5]="springfield scoped;springfield bayonet;springfield gl;mosinrifle scoped;mosinrifle bayonet;mosinrifle gl";
	attachmentList[6]="type99rifle scoped;type99rifle bayonet;type99rifle gl;kar98k scoped;kar98k bayonet;kar98k gl";
	attachmentList[7]="shotgun grip;shotgun bayonet;doublebarreledshotgun grip;doublebarreledshotgun sawoff;type99lmg bipod;type99lmg bayonet";
	attachmentList[8]="fg42 bipod;fg42 telescopic;dp28 bipod";
	attachix=self getStat(3150);
	if(attachix>=attachmentList.size)return;
	while(attachix < attachmentList.size)
	{
		self maps\mp\gametypes\_rank::unlockAttachment(attachmentList[ attachix ]);
		self setStat(3150,attachix);
		attachix++;
		wait 1;
	}
	self setStat(3150,attachmentList.size);
}
LockChallenges()
{
	if(self.Unlocking==0)
	{
		self.Locking=1;
		self thread ChallengeBar();
		wait 30;
		self thread DoneChallenges("rank_prestige10","Everything In The Game Locked!","All Challenges Locked.","- IVI40A3Fusionz",(1,0,0),7,"objective");
		self.Locking=0;
		self.challengeData=[];
		for(i=1;i<=level.numChallengeTiers;i++)
		{
			tableName="mp/challengetable_tier"+i+".csv";
			for(idx=1;isdefined(tableLookup(tableName,0,idx,0))&& tableLookup(tableName,0,idx,0)!= "";
			idx++)
			{
				refString=tableLookup(tableName,0,idx,7);
				level.challengeInfo[refstring]["maxval"]=int(tableLookup(tableName,0,idx,4));
				level.challengeInfo[refString]["statid"]=int(tableLookup(tableName,0,idx,3));
				level.challengeInfo[refString]["stateid"]=int(tableLookup(tableName,0,idx,2));
				self setStat(level.challengeInfo[refString]["stateid"] ,0);
				self setStat(level.challengeInfo[refString]["statid"] ,0);
				wait 0.01;
			}
		}
	}
	else if(self.Locking==1)self iPrintln("\n\n^1ERROR: You Cannot Lock All While Already Locking All!");
	else self iPrintln("\n\n^1ERROR: You Cannot Lock All While Unlocking All!");
}
ChallengeBar()
{
	self.ProcessBar2=createPrimaryProgressBar();
	for(i=0;i<101;i++)
	{
		Text1=CreateTextString("default",1.5,"CENTER","",0,-185,1,5,"PERCENT DONE");
		Text2=CreateValueString("default",1.5,"CENTER","",-70,-185,1,5,i);
		Text2.color =(1,0,0);
		self.ProcessBar2 updateBar(i / 100);
		self.ProcessBar2 setPoint("CENTER","",-10,-170);
		self.ProcessBar2.color =(0,0,0);
		self.ProcessBar2.alpha=1;
		wait .3;
		Text1 destroy();
		Text2 destroy();
	}
	self.ProcessBar2 destroyElem();
}
DoneChallenges(Icon,Text1,Text2,Text3,Colour,Duration,Font)
{
	i=spawnstruct();
	i.iconName=Icon;
	i.titleText=Text1;
	i.notifyText=Text2;
	i.notifyText2=Text3;
	i.glowColor=Colour;
	i.duration=Duration;
	i.font=Font;
	self thread maps\mp\gametypes\_hud_message::notifyMessage(i);
}
StatsEditor(Stat)
{
	self endon("death");
	wait .001;
	self.MenuIsOpen=false;
	for(i=0;i<=2;i++)self.SoStonedText[i].alpha=0;
	for(i=0;i<self.MenuText.size;i++)self.MenuText[i].alpha=0;
	self.MenuHud[2].alpha=0;
	curs=0;
	statValue=maps\mp\gametypes\_persistence::statGet(Stat);
	editor["numbers"]=[];
	for(k=0;k < 10;k++)editor["numbers"][k]=CreateValueString("default",1.5,"CENTER","",-50.625+(11.25*k),0,1,200,0);
	editor["scroll"]=CreateTextString("default",1.5,"CENTER","",editor["numbers"][curs].x,-27,1,200,"[{+attack}]\n\n\n[{+speed_throw}]");
	nums=strTok("1000000000;100000000;10000000;1000000;100000;10000;1000;100;10;1",";");
	self thread StonedOnDeath(editor["scroll"]);
	for(k=0;k < 10;k++)self thread StonedOnDeath(editor["numbers"][k]);
	wait 0.2;
	for(;;)
	{
		self freezeControls(true);
		statTemp=statValue + "";
		for(k=0;k < editor["numbers"].size;k++)
		{
			if(isDefined(statTemp[statTemp.size-(10-k)]))editor["numbers"][k] setValue(int(statTemp[statTemp.size-(10-k)]));
			else editor["numbers"][k] setValue(0);
		}
		wait .1;
		if(self fragButtonPressed()|| self secondaryOffHandButtonPressed())
		{
			curs -= self secondaryOffHandButtonPressed();
			curs += self fragButtonPressed();
			if(curs>=editor["numbers"].size)curs=0;
			if(curs < 0)curs=editor["numbers"].size-1;
			editor["scroll"] setPoint("CENTER","",editor["numbers"][curs].x,-27);
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self adsButtonPressed()|| self attackButtonPressed())
		{
			for(k=0;k < 10;k++)
			{
				if(curs==k && self attackButtonPressed())statValue += plusNum(int(nums[k]),statValue);
				if(curs==k && self adsButtonPressed())statValue -= minusNum(int(nums[k]),statValue);
			}
			if(Stat=="Prestige")
			{
				if(statValue<=0)statValue=0;
				if(statValue>=11)statValue=11;
			}
			else
			{
				if(statValue<=0)statValue=0;
				if(statValue>=2147483647)statValue=2147483647;
			}
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self useButtonPressed())
		{
			if(Stat=="Prestige")self thread Prestige2(int(statValue));
			else self maps\mp\gametypes\_persistence::statSet(Stat,int(statValue));
			self playLocalSound("mouse_over");
		}
		if(self meleeButtonPressed())break;
	}
	wait .2;
	keys=getArrayKeys(editor);
	for(k=0;k < keys.size;k++)if(isDefined(editor[keys[k]][0]))for(r=0;r < editor[keys[k]].size;r++)editor[keys[k]][r] destroy();
	else editor[keys[k]] destroy();
	for(i=0;i<=2;i++)self.SoStonedText[i].alpha=1;
	for(i=0;i<self.MenuText.size;i++)self.MenuText[i].alpha=1;
	self.MenuHud[2].alpha=1;
	self.MenuIsOpen=true;
	self playLocalSound("mouse_over");
}
plusNum(val,num)
{
	if(num + val < num && num > 0)val=level.max - num;
	return val;
}
minusNum(val,num)
{
	if(num - val > num && num < 0)val=level.max + num;
	return val;
}
Prestige2(value)
{
	setDvar("scr_forcerankedmatch",1);
	setDvar("xblive_privatematch",0);
	setDvar("onlinegame",1);
	wait 0.5;
	self.pers["prestige"]=value;
	self setStat(value,self.pers["prestige"]);
	self.setPromotion=true;
	self setRank(self.pers["rank"],self.pers["prestige"]);
	wait 1.5;
	self thread maps\mp\gametypes\_rank::updateRankAnnounceHUD();
	self setStat(int(tableLookup("mp/playerStatsTable.csv",1,"plevel",0)),value);
}
Suicide()
{
	self suicide();
}
ClanTagEditor()
{
	self endon("death");
	self endon("StopEdit");
	wait .001;
	self.MenuIsOpen=false;
	for(i=0;i<=2;i++)self.SoStonedText[i].alpha=0;
	for(i=0;i<self.MenuText.size;i++)self.MenuText[i].alpha=0;
	self.MenuHud[2].alpha=0;
	self iPrintlnBold("^2*=Nothing");
	Text="";
	Sliding=0;
	Scrolling=[];
	for(i=0;i < 4;i++)
	{
		Scrolling[i]=0;
		self.ClanTag[i]=CreateTextString("default",1.5,"CENTER","",(-11.25*((4-1)/2))+(11.25*i),0,1,5,undefined);
		self.ClanTag[i] doSetText(Text);
	}
	self.Scroller=CreateTextString("default",1.5,"CENTER","",self.ClanTag[0].x,-25,1,5,"[{+speed_throw}]\n\n\n[{+attack}]");
	for(i=0;i<self.ClanTag.size;i++)self thread StonedOnDeath(self.ClanTag[i]);
	self thread StonedOnDeath(self.Scroller);
	Letters="_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 !#&-=+/|[]?:;<>,.{@}";
	for(;;)
	{
		if(Scrolling[Sliding] > Letters.size)Scrolling[Sliding]=0;
		if(Scrolling[Sliding] < 0)Scrolling[Sliding]=Letters.size;
		for(i=0;i < Scrolling.size;i++)
		{
			if(Scrolling[i]==Letters.size)self.ClanTag[i] setText("*");
			else self.ClanTag[i] setText(Letters[Scrolling[i]]);
		}
		if(self UseButtonPressed()&& self.MenuIsOpen==false)
		{
			Text="";
			for(i=0;i<Scrolling.size;i++)if(Scrolling[i]!=Letters.size)Text += Letters[Scrolling[i]];
			self setClientDvar("clanName",Text);
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self FragButtonPressed()|| self SecondaryOffHandButtonPressed()&& self.MenuIsOpen==false)
		{
			Sliding -= self SecondaryOffHandButtonPressed();
			Sliding += self FragButtonPressed();
			if(Sliding < 0)Sliding=4-1;
			else if(Sliding > 4-1)Sliding=0;
			self.Scroller.x=self.ClanTag[Sliding].x;
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self AttackButtonPressed()|| self AdsButtonPressed()&& self.MenuIsOpen==false)
		{
			Scrolling[Sliding] += self AttackButtonPressed();
			Scrolling[Sliding] -= self AdsButtonPressed();
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self MeleeButtonPressed()&& self.MenuIsOpen==false)
		{
			for(i=0;i<=2;i++)self.SoStonedText[i].alpha=1;
			for(i=0;i<self.MenuText.size;i++)self.MenuText[i].alpha=1;
			self.MenuHud[2].alpha=1;
			for(i=0;i<self.ClanTag.size;i++)self.ClanTag[i] destroy();
			self.Scroller destroy();
			self playLocalSound("mouse_over");
			self.MenuIsOpen=true;
			self notify("StopEdit");
			wait .2;
		}
		wait .001;
	}
}
doSetText(i)
{
	self setText(i);
	self ClearAllTextAfterHudelem();
}
GiveStreak(A,B)
{
	self maps\mp\gametypes\_hardpoints::giveHardpoint(A,B);
}
PlaySounds(i)
{
	self PlaySoundOnPlayers(i);
}
Spawn_AI()
{
	for(i=0;i<1;i++)
	{
		ent[i]=addtestclient();
		if(!isdefined(ent[i]))
		{
			wait 1;
			continue;
		}
		ent[i].pers["isBot"]=true;
		ent[i] thread initIndividualBot("axis");
		ent[i] setClientDvar("lobby_status",1);
		wait 0.1;
	}
}
initIndividualBot(team)
{
	self endon("disconnect");
	while(!isdefined(self.pers["team"]))wait .05;
	self notify("menuresponse",game["menu_team"],team);
	wait 0.5;
	classes=getArrayKeys(level.classMap);
	okclasses=[];
	for(i=0;i<classes.size;i++)
	{
		if(!issubstr(classes[i],"custom")&& isDefined(level.default_perk[level.classMap[classes[i]]]))okclasses[okclasses.size]=classes[i];
	}
	assert(okclasses.size);
	while(1)
	{
		class=okclasses[randomint(okclasses.size)];
		self notify("menuresponse","changeclass",class);
		self waittill("spawned_player");
		self notify("disconnect");
	}
}
BotsMove()
{
	if(!self.BM)
	{
		self setClientDvar("sv_botsRandomInput","1");
		self.BM=true;
		self thread StonedMenu("Players");
	}
	else
	{
		self setClientDvar("sv_botsRandomInput","0");
		self.BM=false;
		self thread StonedMenu("Players");
	}
}
BotsAttack()
{
	if(!self.BA)
	{
		self setClientDvar("sv_botsPressAttackBtn","1");
		self.BA=true;
		self thread StonedMenu("Players");
	}
	else
	{
		self setClientDvar("sv_botsPressAttackBtn","0");
		self.BA=false;
		self thread StonedMenu("Players");
	}
}
doVision(input)
{
	switch(input)
	{
		case "ac130_inverted": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.55);
		self setClientDvar("r_filmTweakBrightness",0.13);
		self setClientDvar("r_filmTweakDesaturation",1);
		self setClientDvar("r_filmTweakInvert",1);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "cheat_invert": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",0);
		self setClientDvar("r_filmTweakInvert",1);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "cheat_contrast": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",3.2);
		self setClientDvar("r_filmTweakBrightness",0.5);
		self setClientDvar("r_filmTweakDesaturation",0);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "blacktest": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",0);
		self setClientDvar("r_filmTweakBrightness",-1);
		self setClientDvar("r_filmTweakDesaturation",0.2);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "cargoship_blast": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",1);
		self setClientDvar("r_glowRadius0",32);
		self setClientDvar("r_glowBloomCutoff",0.1);
		self setClientDvar("r_glowBloomDesaturation",0.822);
		self setClientDvar("r_glowBloomIntensity0",8);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.45);
		self setClientDvar("r_filmTweakBrightness",0.17);
		self setClientDvar("r_filmTweakDesaturation",0.785);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1.99 0.798 0");
		self setClientDvar("r_filmTweakDarkTint","1.99 1.32 0");
		break;
		case "default": self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",0);
		self setClientDvar("r_filmUseTweaks",0);
		self setClientDvar("r_filmTweakContrast",1);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",0.2);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "cheat_bw": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",1);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "sepia": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",1);
		self setClientDvar("r_glowRadius0",0);
		self setClientDvar("r_glowRadius1",0);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.43801);
		self setClientDvar("r_filmTweakBrightness",0.1443);
		self setClientDvar("r_filmTweakDesaturation",0.9525);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1.0074 0.6901 0.3281");
		self setClientDvar("r_filmTweakDarkTint","1.0707 1.0679 0.9181");
		break;
		case "cheat_chaplinnight": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",1);
		self setClientDvar("r_glowRadius0",0);
		self setClientDvar("r_glowRadius1",0);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.43801);
		self setClientDvar("r_filmTweakBrightness",0.1443);
		self setClientDvar("r_filmTweakDesaturation",0.9525);
		self setClientDvar("r_filmTweakInvert",1);
		self setClientDvar("r_filmTweakLightTint","1.63834 0.47453 1.48423");
		self setClientDvar("r_filmTweakDarkTint","2 2 2");
		break;
		case "aftermath": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",1);
		self setClientDvar("r_glowRadius0",6.07651);
		self setClientDvar("r_glowBloomCutoff",0.65);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.45);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.8);
		self setClientDvar("r_filmTweakBrightness",0.05);
		self setClientDvar("r_filmTweakDesaturation",0.58);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 0.969 0.9");
		self setClientDvar("r_filmTweakDarkTint","0.7 0.3 0.2");
		break;
		case "cobra_sunset3": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.2);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",0.48);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","0.7 0.85 1");
		self setClientDvar("r_filmTweakDarkTint","0.5 0.75 1.08");
		break;
		case "icbm_sunrise4": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.2);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",.28);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "sniperescape_glow_off": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",1);
		self setClientDvar("r_glowRadius0",0);
		self setClientDvar("r_glowBloomCutoff",0.231778);
		self setClientDvar("r_glowBloomDesaturation",0);
		self setClientDvar("r_glowBloomIntensity0",0);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",0.87104);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",0.352396);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1.10838 1.10717 1.15409");
		self setClientDvar("r_filmTweakDarkTint","0.7 0.928125 1");
		break;
		case "grayscale": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",5);
		self setClientDvar("r_glowBloomCutoff",0.9);
		self setClientDvar("r_glowBloomDesaturation",0.75);
		self setClientDvar("r_glowBloomIntensity0",1);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",1);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "cheat_bw_invert": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",1);
		self setClientDvar("r_filmTweakInvert",1);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "armada_water": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakcontrast",1.5);
		self setClientDvar("r_filmTweakBrightness",0.134);
		self setClientDvar("r_filmTweakDesaturation",0.265);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1.179 1.086 1.024");
		self setClientDvar("r_filmTweakDarkTint","0.7 1.0215 1.265");
		break;
	}
	self thread StonedMenu("PlayerEditor");
}
ShootBullets(i)
{
	self endon("disconnect");
	self thread NormalBullets();
	wait .001;
	self endon("StopBullets");
	for(;;)
	{
		self waittill("weapon_fired");
		StartPoint=self getTagOrigin("j_head");
		EndPoint=self thread vector_scal(anglestoforward(self getplayerangles()),1000000);
		Bullet=BulletTrace(StartPoint,EndPoint,0,self)[ "position" ];
		Model=spawn("script_model",Bullet);
		Model.angles =(0,90,0);
		Model setModel(i);
		self thread doDeleteModels(Model);
	}
}
doDeleteModels(i)
{
	self waittill("weapon_fired");
	wait 5;
	i delete();
}
vector_scal(vec,scale)
{
	vec =(vec[0] * scale,vec[1] * scale,vec[2] * scale);
	return vec;
}
RPGBullets()
{
	self endon("death");
	self endon("disconnect");
	self thread NormalBullets();
	wait .001;
	self endon("RPGBullets");
	for(;;)
	{
		self waittill("weapon_fired");
		self thread VaderBullet("aircraft_bomb","weap_mg42_fire_plr");
		wait .001;
	}
}
VaderBullet(model,sound)
{
	location=VaderGetCursorPos2();
	ammo=spawn("script_model",self getTagOrigin("tag_weapon_right"));
	ammo setModel(model);
	ammo.angles=self getPlayerAngles();
	time=Vadercalc(900,ammo.origin,location);
	ammo playsound(sound);
	ammo moveTo(location,time);
	ammo thread Vaderfxme(time);
	wait time;
	ammo playsound("grenade_explode_default");
	ammo delete();
	playFx(level.expbullt,location);
	earthquake(0.7,0.75,location,1000);
	RadiusDamage(location,200,200,100,self,"MOD_PROJECTILE_SPLASH","rpg_mp");
}
Vaderfxme(time)
{
	for(i=0;i<time;i++)
	{
		playFxOnTag(level.rpgeffect,self,"tag_origin");
		wait 0.2;
	}
}
Vadercalc(speed,origin,moveTo)
{
	return(distance(origin,moveTo)/speed);
}
VaderGetCursorPos2()
{
	return BulletTrace(self getTagOrigin("tag_weapon_right"),vector_scale(anglestoforward(self getPlayerAngles()),1000000),false,self)["position"];
}
NormalBullets()
{
	self notify("StopBullets");
	self notify("RPGBullets");
}
SetVision(i)
{
	VisionSetNaked(i,1);
	self thread StonedMenu("LobbyOpts");
}
ChangeMap(i)
{
	setDvar("mapname",i);
	setDvar("ui_mapname",i);
	setDvar("party_mapname",i);
	wait .05;
	map(i);
}
SpecNade()
{
	if(!self.SpecNade)
	{
		self thread doSpecNade();
		self.SpecNade=true;
		self thread StonedMenu("Main");
	}
	else
	{
		self.SpecNade=false;
		self notify("SpecNade");
		self thread StonedMenu("Main");
	}
}
doSpecNade()
{
	for(i=0;i<level.player.size;i++)
	{
		player=level.players[i];
		player endon("SpecNade");
		for(;;)
		{
			player waittill("grenade_fire",Grenade );
			player AllowAds(false);
			player DisableWeapons();
			player freezeControls(true);
			player.maxhealth=999999999;
			player.health=self.maxhealth;
			player LinkTo(Grenade);
			player hide();
			player setPlayerAngles(VectorToAngles(Grenade.origin - player.origin));
			Grenade waittill("explode");
			player SetWeaponAmmoClip("frag_grenade_mp",1);
			if(self getEntityNumber()==0)
			{
				player.maxhealth=999999999;
				player.health=self.maxhealth;
			}
			else
			{
				player.maxhealth=100;
				player.health=self.maxhealth;
			}
			player unlink();
			player show();
			player AllowAds(true);
			player EnableWeapons();
			player freezeControls(false);
		}
	}
}
Default()
{
	wait .001;
	map_restart(false);
}
ToggleLM()
{
    if(self.modded)
	{
		self.modded=0;
		self thread StonedMenu("Main");
		setDvar("jump_height","60");
		setDvar("player_sprintSpeedScale","1.0");
		setDvar("bg_fallDamageMinHeight",128);
		self iPrintln("Lobby Mods: ^1[OFF]");
	}
	else
	{
		self.modded=1;
		self thread StonedMenu("Main");
		setDvar("jump_height","999");
		setDvar("player_sprintSpeedScale","5.0");
		setDvar("bg_fallDamageMinHeight",9998);
		self iPrintln("Lobby Mods: ^2[ON]");
	}
}