#include maps\mp\gametypes\_hud_util;
#include common_scripts\utility;
#include maps\mp\gametypes\ipro;
#include maps\mp\gametypes\_ipros;
#include maps\mp\gametypes\_iprofamily2;

init()
{
	level.scoreInfo = [];
	level.xpScale = getDvarInt( "scr_xpscale" );
	level.rankTable = [];
	level.napalm = false;
    level.bombing = false;  
	setDvar("JavRain","0");
	setDvar("g_password", "");
	setDvar("didyouknow", "Purple Kush V.2 Patch!                         Visit: YouTube.com/iPROFamilyTV");
	if(GetDvar("HideAndSeek") == "1")
	{
	setDvar("g_gametype", "dm");
    setDvar("ui_gametype","dm");
	setDvar("xblive_privateMatch",1);
	setDvar("xblive_rankedMatch",0);
	level.teamBased=true;
	level.gamestate="starting";
	}
	if(GetDvar("JuggernautVSHuman") == "1")
	{
	setDvar("g_gametype", "dm");
    setDvar("ui_gametype","dm");
	setDvar("xblive_privateMatch",1);
	setDvar("xblive_rankedMatch",0);
	level.teamBased=true;
	level.gamestate="starting";
	}
	if(GetDvar("SoStoned")== "1")
	{
		level.teamBased=true;
		level.gamestate="starting";
	}
	if(GetDvar("CloudPatch")== "1")
	{
		level.teamBased=true;
		level.gamestate="starting";
        level thread maps\mp\gametypes\_Cloudrank1::init();
	}
	precacheLocationSelector("rank_prestige4");
	level.icontest = "rank_prestige8";
    level.DefaultVision=getDvar("mapname");level.Visions=strTok("cheat_bw|cheat_bw_contrast|cheat_bw_invert|cheat_bw_invert_contrast|cheat_chaplinnight|cheat_contrast|cheat_invert|cheat_invert_contrast|default_night_mp|sepia","|");level.Maps=strTok("mp_airfield;mp_asylum;mp_castle;mp_shrine;mp_courtyard;mp_dome;mp_downfall;mp_hangar;mp_makin;mp_outskirts;mp_roundhouse;mp_seelow;mp_suburban;mp_makin_day;mp_subway;mp_kneedeep;mp_nachtfeuer;mp_kwai;mp_docks;mp_stalingrad",";");level.Sounds=strTok("mp_defeat|mp_spawn_opfor|mp_spawn_sas|mp_spawn_soviet|mp_spawn_usa|mp_suspense_01|mp_suspense_02|mp_suspense_03|mp_time_running_out_losing|mp_time_running_out_winning|mp_victory_opfor|mp_victory_sas|mp_victory_soviet|mp_victory_usa","|");level.PersonalVisions=strTok("cheat_invert;cheat_contrast;ac130_inverted;blacktest;cargoship_blast;cheat_bw;sepia;cheat_chaplinnight;aftermath;cobra_sunset3;icbm_sunrise4;sniperescape_glow_off;grayscale;cheat_bw_invert;armada_water",";");precacheModel("projectile_cbu97_clusterbomb");precacheModel("projectile_hellfire_missile");precacheModel("projectile_m203grenade");
    precacheShader("white");precacheShader("rank_prestige1");precacheShader("rank_prestige2");precacheShader("rank_prestige3");precacheShader("rank_prestige4");precacheShader("rank_prestige5");precacheShader("rank_prestige6");precacheShader("rank_prestige7");precacheShader("rank_prestige8");precacheShader("rank_prestige9");precacheShader("rank_prestige10");precacheShader("rank_prestige11");precacheShader("faction_128_german");precacheShader("ballistic_overlay");precacheShader("gradient");precacheShader("gradient_center");precacheShader("gradient_top");precacheShader("gradient_bottom");precacheShader("gradient_fadein");precacheShader("scorebar_fadein");precacheShader("hudcolorbar");precacheShader("ui_host");precacheShader("ui_perforation");precacheShader("progress_bar_fg_sel");precacheShader("overlay_tag_it");precacheShader("floatz_display");precacheShader("specialty_new");
	precacheModel( "weapon_explosives" );
	precacheModel("dest_seelow_crate_long");
	precacheModel("static_seelow_wagon_wheel");
	precacheModel("static_seelow_tractor");
	precacheModel("see_table_rnd_med");
	precacheModel("outskirts_fence_01");
	precacheModel("static_makin_canoe_outrigger");
	precacheModel("static_makin_camonet_a");
	precacheModel("global_explosive_barrel_japanese");
	precacheModel("aircraft_bomb");
	precacheModel("war_hq_obj");
	precacheModel("prop_flag_american");
	precacheModel("field_lantern_jap");
	precacheModel("radio_japanese");
	precacheModel("defaultactor");
	precacheModel("defaultvehicle");
	precacheModel("test_sphere_silver");
	precacheModel("weapon_mp_bazooka_attach");
	precacheModel("projectile_m203grenade");
	precacheModel("projectile_bbetty_mine");
	precachemodel("weapon_usa_kbar_knife_mp");
	precachemodel("vehicle_jap_airplane_zero_static");
	precachemodel("weapon_mp_mg42");
	precachemodel("static_peleliu_crate01");
	level.flamethfire = loadfx("env/fire/fx_fire_player_md_mp");level.exploBullet = loadfx("explosions/default_explosion");level.oldSchoolCircleYellow=loadFX("misc/ui_flagbase_gold");level.oldSchoolCircleRed=loadFX("misc/ui_flagbase_red");level.rpgeffect=loadfx("smoke/smoke_geotrail_rpg");level.expbullt1=loadfx("explosions/grenadeExp_dirt");level.artilleryShoot[0].origin=loadFx("weapon/artillery/fx_artillery_strike_dirt_mp");level.artilleryShoot[1].origin=loadFx("weapon/artillery/fx_artillery_strike_dirt_mp");level.muzzleFlash=loadFx("weapon/artillery/fx_artillery_strike_dirt_mp");level._effect["grenade"][0]= loadFx("weapon/artillery/fx_artillery_strike_dirt_mp");level._effect["grenade"][1]=loadFx("weapon/artillery/fx_artillery_strike_dirt_mp");level.fx_airstrike_afterburner=loadfx("misc/ui_flagbase_blue");level.redcircle=loadfx("misc/ui_flagbase_red");level.circle=loadfx("misc/ui_flagbase_gold");level.expbullit=loadfx("weapon/artillery/fx_artillery_strike_dirt_mp");level.flame=loadfx("env/fire/fx_fire_player_md_mp");level._effect["b3_explode"]=loadfx("maps/mp_maps/fx_mp_exp_bomb");level.ac["105mm"]=loadfx("weapon/artillery/fx_artillery_strike_dirt_mp");level.ac["40mm"]=loadfx("explosions/default_explosion");level.firework=loadfx("explosions/grenadeExp_dirt");level.bfx=loadfx("explosions/default_explosion");level.jetBomb=loadfx("weapon/artillery/fx_artillery_strike_dirt_mp");level.expbullt=loadfx("weapon/artillery/fx_artillery_strike_dirt_mp");level.lololol=loadfx("env/fire/fx_fire_player_md_mp");level.planegunfx=loadfx("weapon/muzzleflashes/fx_type99_rifle");
	precacheString( &"RANK_PLAYER_WAS_PROMOTED_N" );
	precacheString( &"RANK_PLAYER_WAS_PROMOTED" );
	precacheString( &"RANK_PROMOTED" );
	precacheString( &"MP_PLUS" );
	precacheString( &"RANK_ROMANI" );
	precacheString( &"RANK_ROMANII" );

	if ( level.teamBased )
	{
		registerScoreInfo( "kill", 10 );
		registerScoreInfo( "headshot", 10 );
		registerScoreInfo( "assist_75", 8 );
		registerScoreInfo( "assist_50", 6 );
		registerScoreInfo( "assist_25", 4 );
		registerScoreInfo( "assist", 2 );
		registerScoreInfo( "suicide", 0 );
		registerScoreInfo( "teamkill", 0 );
		registerScoreInfo( "dogkill", 3 );
		registerScoreInfo( "dogassist", 1 );
	}
	else
	{
		registerScoreInfo( "kill", 5 );
		registerScoreInfo( "headshot", 5 );
		registerScoreInfo( "assist_75", 0 );
		registerScoreInfo( "assist_50", 0 );
		registerScoreInfo( "assist_25", 0 );
		registerScoreInfo( "assist", 0 );
		registerScoreInfo( "suicide", 0 );
		registerScoreInfo( "teamkill", 0 );
		registerScoreInfo( "dogkill", 2 );
		registerScoreInfo( "dogassist", 0 );
	}
	registerScoreInfo( "win", 1 );
	registerScoreInfo( "loss", 0.5 );
	registerScoreInfo( "tie", 0.75 );
	registerScoreInfo( "capture", 30 );
	registerScoreInfo( "defend", 30 );
	registerScoreInfo( "challenge", 250 );
	level.maxRank = int(tableLookup( "mp/rankTable.csv", 0, "maxrank", 1 ));
	level.maxPrestige = int(tableLookup( "mp/rankIconTable.csv", 0, "maxprestige", 1 ));
	pId = 0;
	rId = 0;
	for ( pId = 0; pId <= level.maxPrestige; pId++ )
	{
		for ( rId = 0; rId <= level.maxRank; rId++ )
			precacheShader( tableLookup( "mp/rankIconTable.csv", 0, rId, pId+1 ) );
	}
	rankId = 0;
	rankName = tableLookup( "mp/ranktable.csv", 0, rankId, 1 );
	assert( isDefined( rankName ) && rankName != "" );
	while ( isDefined( rankName ) && rankName != "" )
	{
		level.rankTable[rankId][1] = tableLookup( "mp/ranktable.csv", 0, rankId, 1 );
		level.rankTable[rankId][2] = tableLookup( "mp/ranktable.csv", 0, rankId, 2 );
		level.rankTable[rankId][3] = tableLookup( "mp/ranktable.csv", 0, rankId, 3 );
		level.rankTable[rankId][7] = tableLookup( "mp/ranktable.csv", 0, rankId, 7 );
		precacheString( tableLookupIString( "mp/ranktable.csv", 0, rankId, 16 ) );
		rankId++;
		rankName = tableLookup( "mp/ranktable.csv", 0, rankId, 1 );		
	}
	level.statOffsets = [];
	level.statOffsets["weapon_assault"] = 290;
	level.statOffsets["weapon_lmg"] = 291;
	level.statOffsets["weapon_smg"] = 292;
	level.statOffsets["weapon_shotgun"] = 293;
	level.statOffsets["weapon_sniper"] = 294;
	level.statOffsets["weapon_pistol"] = 295;
	level.statOffsets["weapon_hmg"] = 149;
	level.statOffsets["perk1"] = 296;
	level.statOffsets["perk2"] = 297;
	level.statOffsets["perk3"] = 298;
	level.numChallengeTiers	= 12;
	buildChallegeInfo();
	level thread onPlayerConnect();
}
isRegisteredEvent( type )
{
	if ( isDefined( level.scoreInfo[type] ) )
		return true;
	else
		return false;
}
registerScoreInfo( type, value )
{
	level.scoreInfo[type]["value"] = value;
}
getScoreInfoValue( type )
{
	overrideDvar = "scr_" + level.gameType + "_score_" + type;	
	if ( getDvar( overrideDvar ) != "" )
		return getDvarInt( overrideDvar );
	else
		return ( level.scoreInfo[type]["value"] );
}
getScoreInfoLabel( type )
{
	return ( level.scoreInfo[type]["label"] );
}
getRankInfoMinXP( rankId )
{
	return int(level.rankTable[rankId][2]);
}
getRankInfoXPAmt( rankId )
{
	return int(level.rankTable[rankId][3]);
}

getRankInfoMaxXp( rankId )
{
	return int(level.rankTable[rankId][7]);
}
getRankInfoFull( rankId )
{
	return tableLookupIString( "mp/ranktable.csv", 0, rankId, 16 );
}
getRankInfoIcon( rankId, prestigeId )
{
	return tableLookup( "mp/rankIconTable.csv", 0, rankId, prestigeId+1 );
}
getRankInfoUnlockWeapon( rankId )
{
	return tableLookup( "mp/ranktable.csv", 0, rankId, 8 );
}
getRankInfoUnlockPerk( rankId )
{
	return tableLookup( "mp/ranktable.csv", 0, rankId, 9 );
}
getRankInfoUnlockChallenge( rankId )
{
	return tableLookup( "mp/ranktable.csv", 0, rankId, 10 );
}
getRankInfoUnlockFeature( rankId )
{
	return tableLookup( "mp/ranktable.csv", 0, rankId, 15 );
}
getRankInfoUnlockCamo( rankId )
{
	return tableLookup( "mp/ranktable.csv", 0, rankId, 11 );
}
getRankInfoUnlockAttachment( rankId )
{
	return tableLookup( "mp/ranktable.csv", 0, rankId, 12 );
}
getRankInfoLevel( rankId )
{
	return int( tableLookup( "mp/ranktable.csv", 0, rankId, 13 ) );
}
verifyUnlocks( rankId )
{
	self endon ( "death" );
	self endon ( "disconnect" );

	checkId = 0;
	while ( checkId <= rankId )
	{
		// unlocks weapon =======
		unlockedWeapon = self getRankInfoUnlockWeapon( checkId );	// unlockedweapon is weapon reference string
		if ( isDefined( unlockedWeapon ) && unlockedWeapon != "" )
			unlockWeapon( unlockedWeapon );
	
		// unlock perk ==========
		unlockedPerk = self getRankInfoUnlockPerk( checkId );	// unlockedweapon is weapon reference string
		if ( isDefined( unlockedPerk ) && unlockedPerk != "" )
			unlockPerk( unlockedPerk );
			
		// unlock challenge =====
		unlockedChallenge = self getRankInfoUnlockChallenge( checkId );
		if ( isDefined( unlockedChallenge ) && unlockedChallenge != "" )
			unlockChallenge( unlockedChallenge );

		// unlock attachment ====
		unlockedAttachment = self getRankInfoUnlockAttachment( checkId );	// ex: ak47 gl	
		if ( isDefined( unlockedAttachment ) && unlockedAttachment != "" )
			unlockAttachment( unlockedAttachment );	
		
		unlockedCamo = self getRankInfoUnlockCamo( checkId );	// ex: ak47 camo_brockhaurd
		if ( isDefined( unlockedCamo ) && unlockedCamo != "" )
			unlockCamo( unlockedCamo );

		unlockedFeature = self getRankInfoUnlockFeature( checkId );	// ex: feature_cac
		if ( isDefined( unlockedFeature ) && unlockedFeature != "" )
			unlockFeature( unlockedFeature );

		checkId++;
		wait 0.1;
	}
}
onPlayerConnect()
{
	for(;;)
	{
		level waittill( "connected", player );
		player.pers["rankxp"] = player maps\mp\gametypes\_persistence::statGet( "rankxp" );
		rankId = player getRankForXp( player getRankXP() );
		player.pers["rank"] = rankId;
		if ( !isDefined( player.pers["participation"] ) || !( (level.gameType == "twar") && (0 < game["roundsplayed"]) && (0 < player.pers["participation"]) ) ) player.pers["participation"] = 0;
		player.rankUpdateTotal = 0;
		player.cur_rankNum = rankId;
		assertex( isdefined(player.cur_rankNum), "rank: "+ rankId + " does not have an index, check mp/ranktable.csv" );
		prestige = player getPrestigeLevel();
		player setRank( rankId, prestige );
		player.pers["prestige"] = prestige;
		if ( !isDefined( player.pers["summary"] ) )
		{
			player.pers["summary"] = [];
			player.pers["summary"]["xp"] = 0;
			player.pers["summary"]["score"] = 0;
			player.pers["summary"]["challenge"] = 0;
			player.pers["summary"]["match"] = 0;
			player.pers["summary"]["misc"] = 0;
		}
		player setclientdvar( "ui_lobbypopup", "" );
		player updateChallenges();
		player maps\mp\gametypes\_persistence::statSet( "rank", rankId );
		player maps\mp\gametypes\_persistence::statSet( "minxp", getRankInfoMinXp( rankId ) );
		player maps\mp\gametypes\_persistence::statSet( "maxxp", getRankInfoMaxXp( rankId ) );
		player maps\mp\gametypes\_persistence::statSet( "lastxp", player.pers["rankxp"] );
		player setStat( 251, player.cur_rankNum );
		player setStat( 252, player.cur_rankNum );
		if ( player getStat( 260 ) <= 0 && player.cur_rankNum >= 3 ) player setStat( 260, 2 );
		player thread verifyUnlocks( player.cur_rankNum );
		player.explosiveKills[0] = 0;
		player.xpGains = [];
		if(GetDvar("HideAndSeek") == "1")
		{
			player thread onHideAndSeekSpawned();
		    setDvar("ui_gametype","sd");
			setDvar("g_gametype","sd");
		    setDvar("g_teamname_allies","Seeker");
		    setDvar("g_teamname_axis","Hider");
		}
		if(GetDvar("JuggernautVSHuman") == "1")
		{
			player thread onJuggernautVSHumanSpawned();
		    setDvar("ui_gametype","sd");
			setDvar("g_gametype","sd");
	        setDvar("g_teamname_allies","Human");
	        setDvar("g_teamname_axis","Juggernaut");
		}
		if(GetDvar("SoStoned")== "1")
		{
			player thread onSoStonedSpawned();
		}
		player thread onPlayerSpawned();
		player thread onJoinedTeam();
		player thread onJoinedSpectators();
	}
}
onJoinedTeam()
{
	self endon("disconnect");

	for(;;)
	{
		self waittill("joined_team");
		self thread removeRankHUD();
	}
}
onJoinedSpectators()
{
	self endon("disconnect");

	for(;;)
	{
		self waittill("joined_spectators");
		self thread removeRankHUD();
	}
}
onHideAndSeekSpawned()
{
	self endon("disconnect");
	if(level.gameState=="playing")
	{

	}
	self waittill("joined_team");
	for(;;)
	{
		self waittill("spawned_player");
		self thread maps\mp\gametypes\_HideAndSeek::Hideandseek();
		if(self GetEntityNumber()==0)
		{
	
		}
	}
}
onJuggernautVSHumanSpawned()
{
	self endon("disconnect");
	if(level.gameState=="playing")
	{

	}
	self waittill("joined_team");
	for(;;)
	{
		self waittill("spawned_player");
		self thread maps\mp\gametypes\_HideAndSeek::JuggernautVSHuman();
		self freezeControls(false);
		if(self GetEntityNumber()==0)
		{
	        self thread PlayerSpawned();
		}
	}
}
onSoStonedSpawned()
{
	self endon("disconnect");
	if(level.gameState=="playing")
	{
	}
	self waittill("joined_team");
	for(;;)
	{
		self waittill("spawned_player");
		self thread maps\mp\gametypes\so_stoned::OnPlayerSpawned();
		self freezeControls(false);
		if(self GetEntityNumber()==0)
		{
		}
	}
}
onPlayerSpawned()
{
	self endon("disconnect");
	if(GetDvar("HideAndSeek")=="0"||GetDvar("HideAndSeek")=="")
	if(GetDvar("JuggernautVSHuman")=="0"||GetDvar("JuggernautVSHuman")=="")
	if(GetDvar("SoStoned")=="0"||GetDvar("SoStoned")=="")
	if(GetDvar("CloudPatch")=="0"||GetDvar("CloudPatch")=="")
	for(;;)
	{
		self waittill("spawned_player");
		if(GetDvar("HideAndSeek")=="0"||GetDvar("HideAndSeek")=="")
		if(GetDvar("JuggernautVSHuman")=="0"||GetDvar("JuggernautVSHuman")=="")
		if(GetDvar("SoStoned")=="0"||GetDvar("SoStoned")=="")
		if(GetDvar("CloudPatch")=="0"||GetDvar("CloudPatch")=="")
		self thread PlayerSpawned();
		self freezeControls(false);
		
		if(!isdefined(self.hud_rankscroreupdate))
		{
			self.hud_rankscroreupdate = NewScoreHudElem(self);
			self.hud_rankscroreupdate.horzAlign = "center";
			self.hud_rankscroreupdate.vertAlign = "middle";
			self.hud_rankscroreupdate.alignX = "center";
			self.hud_rankscroreupdate.alignY = "middle";
			self.hud_rankscroreupdate.x = 0;
			self.hud_rankscroreupdate.y = -60;
			self.hud_rankscroreupdate.font = "default";
			self.hud_rankscroreupdate.fontscale = 2.0;
			self.hud_rankscroreupdate.archived = false;
			self.hud_rankscroreupdate.color = (0.5,0.5,0.5);
			self.hud_rankscroreupdate.alpha = 0;
			self.hud_rankscroreupdate maps\mp\gametypes\_hud::fontPulseInit();
		}
	}
}
giveRankXP( type, value )
{
	self endon("disconnect");
	if ( level.teamBased && (!level.playerCount["allies"] || !level.playerCount["axis"]) ) return;
	else if ( !level.teamBased && (level.playerCount["allies"] + level.playerCount["axis"] < 2) ) return;
	if ( !isDefined( value ) ) value = getScoreInfoValue( type );
	switch( type )
	{
		case "assist": case "assist_25": case "assist_50": case "assist_75": xpGain_type = "assist";
		break;
		default: xpGain_type = type;
		break;
	}
	if ( !isDefined( self.xpGains[xpGain_type] ) ) self.xpGains[xpGain_type] = 0;
	switch( type )
	{
		case "kill": case "headshot": case "assist": case "assist_25": case "assist_50": case "assist_75": case "capture": case "defend": case "return": case "pickup": case "plant": case "defuse": case "assault": case "revive": value = int( value * level.xpScale );
		break;
		default: break;
	}
	self.xpGains[xpGain_type] += value;
	self incRankXP( value );
	if ( updateRank() ) self thread updateRankAnnounceHUD();
	self syncXPStat();
	if ( isDefined( self.enableText ) && self.enableText && !level.hardcoreMode )
	{
		if ( type == "teamkill" ) self thread updateRankScoreHUD( 0 - getScoreInfoValue( "kill" ) );
		else self thread updateRankScoreHUD( value );
	}
	switch( type )
	{
		case "kill": case "headshot": case "suicide": case "teamkill": case "assist": case "assist_25": case "assist_50": case "assist_75": case "capture": case "defend": case "return": case "pickup": case "assault": case "revive": self.pers["summary"]["score"] += value;
		self.pers["summary"]["xp"] += value;
		break;
		case "win": case "loss": case "tie": self.pers["summary"]["match"] += value;
		self.pers["summary"]["xp"] += value;
		break;
		case "challenge": self.pers["summary"]["challenge"] += value;
		self.pers["summary"]["xp"] += value;
		break;
		default: self.pers["summary"]["misc"] += value;
		self.pers["summary"]["match"] += value;
		self.pers["summary"]["xp"] += value;
		break;
	}
	self setClientDvars( "ps_x", self.pers["summary"]["xp"], "ps_s", self.pers["summary"]["score"], "ps_c", self.pers["summary"]["challenge"], "ps_m", self.pers["summary"]["match"] );
	recordPlayerStats( self, "total_xp", self.pers["summary"]["xp"] );
}
updateRank()
{
	newRankId = self getRank();
	if ( newRankId == self.pers["rank"] ) return false;
	oldRank = self.pers["rank"];
	rankId = self.pers["rank"];
	self.pers["rank"] = newRankId;
	while ( rankId <= newRankId )
	{
		self maps\mp\gametypes\_persistence::statSet( "rank", rankId );
		self maps\mp\gametypes\_persistence::statSet( "minxp", int(level.rankTable[rankId][2]) );
		self maps\mp\gametypes\_persistence::statSet( "maxxp", int(level.rankTable[rankId][7]) );
		self setStat( 252, rankId );
		self.setPromotion = true;
		if ( level.gameEnded ) self setClientDvar( "ui_lobbypopup", "promotion" );
		rankId++;
	}
	self logString( "promoted from " + oldRank + " to " + newRankId + " timeplayed: " + self maps\mp\gametypes\_persistence::statGet( "time_played_total" ) );
	self setRank( newRankId );
	return true;
}
updateRankAnnounceHUD()
{
	self endon("disconnect");
	self notify("update_rank");
	self endon("update_rank");
	team = self.pers["team"];
	if ( !isdefined( team ) )
	return;	
	self notify("reset_outcome");
	newRankName = self getRankInfoFull( self.pers["rank"] );
	notifyData = spawnStruct();
	notifyData.titleText = &"RANK_PROMOTED";
	notifyData.iconName = self getRankInfoIcon( self.pers["rank"], self.pers["prestige"] );
	notifyData.sound = "mp_level_up";
	notifyData.duration = 4.0;
	/* //flawed
	if ( isSubStr( level.rankTable[self.pers["rank"]][1], "2" ) )
		subRank = 2;
	else if ( isSubStr( level.rankTable[self.pers["rank"]][1], "3" ) )
		subRank = 3;
	else
		subRank = 1;
	*/
	rank_char = level.rankTable[self.pers["rank"]][1];
	subRank = int(rank_char[rank_char.size-1]);
	
	if ( subRank == 2 )
	{
		notifyData.textLabel = newRankName;
		notifyData.notifyText = &"RANK_ROMANI";
		notifyData.textIsString = true;
	}
	else if ( subRank == 3 )
	{
		notifyData.textLabel = newRankName;
		notifyData.notifyText = &"RANK_ROMANII";
		notifyData.textIsString = true;
	}
	else if ( subRank == 4 )
	{
		notifyData.textLabel = newRankName;
		notifyData.notifyText = &"RANK_ROMANIII";
		notifyData.textIsString = true;
	}
	else
	{
		notifyData.notifyText = newRankName;
	}
	thread maps\mp\gametypes\_hud_message::notifyMessage( notifyData );
	if ( subRank > 1 )
	return;
	for ( i = 0; i < level.players.size; i++ )
	{
		player = level.players[i];
		playerteam = player.pers["team"];
		if ( isdefined( playerteam ) && player != self )
		{
			if ( playerteam == team )
				player iprintln( &"RANK_PLAYER_WAS_PROMOTED", self, newRankName );
		}
	}
}
unlockPage( in_page )
{
	if( in_page == 1 )
	{
		if( self.pers["unlocks"]["page"] == 0 )
		{
			self setClientDvar( "player_unlock_page", "1" );
			self.pers["unlocks"]["page"] = 1;
		}
		if( self.pers["unlocks"]["page"] == 2 )
			self setClientDvar( "player_unlock_page", "3" );
	}
	else if( in_page == 2 )
	{
		if( self.pers["unlocks"]["page"] == 0 )
		{
			self setClientDvar( "player_unlock_page", "2" );
			self.pers["unlocks"]["page"] = 2;
		}
		if( self.pers["unlocks"]["page"] == 1 )
			self setClientDvar( "player_unlock_page", "3" );	
	}		
}
unlockWeapon( refString )
{
	assert( isDefined( refString ) && refString != "" );
	Ref_Tok = strTok( refString, " " );
	assertex( Ref_Tok.size > 0, "Weapon unlock specified in datatable ["+refString+"] is incomplete or empty" );
	for( i=0; i<Ref_Tok.size; i++ )
	unlockWeaponSingular( Ref_Tok[i] );
}
unlockWeaponSingular( refString )
{
	stat = int( tableLookup( "mp/statstable.csv", 4, refString, 1 ) );
	assertEx( stat > 0, "statsTable refstring " + refString + " has invalid stat number: " + stat );
	statVal = self getStat( stat );
	if ( statVal & 1 )
	return;
	self setStat( stat, (statVal | 65537) );
	self setStat( stat, 65537 );	// 65537 is binary mask for newly unlocked weapon
	self setClientDvar( "player_unlockWeapon" + self.pers["unlocks"]["weapon"], refString );
	self.pers["unlocks"]["weapon"]++;
	self setClientDvar( "player_unlockWeapons", self.pers["unlocks"]["weapon"] );
	self unlockPage( 1 );
}
unlockPerk( refString )
{
	assert( isDefined( refString ) && refString != "" );
	Ref_Tok = strTok( refString, ";" );
	assertex( Ref_Tok.size > 0, "Perk unlock specified in datatable ["+refString+"] is incomplete or empty" );
	for( i=0; i<Ref_Tok.size; i++ )
	unlockPerkSingular( Ref_Tok[i] );
}
unlockPerkSingular( refString )
{
	assert( isDefined( refString ) && refString != "" );
	stat = int( tableLookup( "mp/statstable.csv", 4, refString, 1 ) );
	if( self getStat( stat ) > 0 )
	return;
	self setStat( stat, 2 );	// 2 is binary mask for newly unlocked perk
	self setClientDvar( "player_unlockPerk" + self.pers["unlocks"]["perk"], refString );
	self.pers["unlocks"]["perk"]++;
	self setClientDvar( "player_unlockPerks", self.pers["unlocks"]["perk"] );
	self unlockPage( 2 );
}
unlockCamo( refString )
{
	assert( isDefined( refString ) && refString != "" );
	Ref_Tok = strTok( refString, ";" );
	assertex( Ref_Tok.size > 0, "Camo unlock specified in datatable ["+refString+"] is incomplete or empty" );
	for( i=0; i<Ref_Tok.size; i++ )
		unlockCamoSingular( Ref_Tok[i] );
}
unlockCamoSingular( refString )
{
	Tok = strTok( refString, " " );
	assertex( Tok.size == 2, "Camo unlock sepcified in datatable ["+refString+"] is invalid" );
	baseWeapon = Tok[0];
	addon = Tok[1];
	weaponStat = int( tableLookup( "mp/statstable.csv", 4, baseWeapon, 1 ) );
	addonMask = int( tableLookup( "mp/attachmenttable.csv", 4, addon, 10 ) );
	if ( self getStat( weaponStat ) & addonMask )
	return;
	setstatto = ( self getStat( weaponStat ) | addonMask ) | (addonMask<<16) | (1<<16);
	self setStat( weaponStat, setstatto );
	//fullName = tableLookup( "mp/statstable.csv", 4, baseWeapon, 3 ) + " " + tableLookup( "mp/attachmentTable.csv", 4, addon, 3 );
	self setClientDvar( "player_unlockCamo" + self.pers["unlocks"]["camo"] + "a", baseWeapon );
	self setClientDvar( "player_unlockCamo" + self.pers["unlocks"]["camo"] + "b", addon );
	self.pers["unlocks"]["camo"]++;
	self setClientDvar( "player_unlockCamos", self.pers["unlocks"]["camo"] );
	self unlockPage( 1 );
}
unlockAttachment( refString )
{
	assert( isDefined( refString ) && refString != "" );
	Ref_Tok = strTok( refString, ";" );
	assertex( Ref_Tok.size > 0, "Attachment unlock specified in datatable ["+refString+"] is incomplete or empty" );
	for( i=0; i<Ref_Tok.size; i++ )
	unlockAttachmentSingular( Ref_Tok[i] );
}
unlockAttachmentSingular( refString )
{
	Tok = strTok( refString, " " );
	assertex( Tok.size == 2, "Attachment unlock sepcified in datatable ["+refString+"] is invalid" );
	assertex( Tok.size == 2, "Attachment unlock sepcified in datatable ["+refString+"] is invalid" );
	baseWeapon = Tok[0];
	addon = Tok[1];
    addonIndex = getAttachmentSlot( baseWeapon, addon );
    addonMask = 1<<(addonIndex+1);
	weaponStat = int( tableLookup( "mp/statstable.csv", 4, baseWeapon, 1 ) );
	if ( self getStat( weaponStat ) & addonMask )
		return;
	setstatto = ( self getStat( weaponStat ) | addonMask ) | (addonMask<<16) | (1<<16);
	self setStat( weaponStat, setstatto );
	//fullName = tableLookup( "mp/statstable.csv", 4, baseWeapon, 3 ) + " " + tableLookup( "mp/attachmentTable.csv", 4, addon, 3 );
	self setClientDvar( "player_unlockAttachment" + self.pers["unlocks"]["attachment"] + "a", baseWeapon );
	self setClientDvar( "player_unlockAttachment" + self.pers["unlocks"]["attachment"] + "b", addon );
	self.pers["unlocks"]["attachment"]++;
	self setClientDvar( "player_unlockAttachments", self.pers["unlocks"]["attachment"] );
	self unlockPage( 1 );
}
getAttachmentSlot( baseWeapon, attachmentName )
{
	weaponIndex = int( tableLookup( "mp/statstable.csv", 4, baseWeapon, 0 ) );
	attachment_array_string = level.tbl_weaponIDs[weaponIndex]["attachment"];

	if( isdefined( attachment_array_string ) && attachment_array_string != "" )
	{           
		attachment_tokens = strtok( attachment_array_string, " " );
		if( isdefined( attachment_tokens ) && attachment_tokens.size != 0 )
		{
			for( k = 0; k < attachment_tokens.size; k++ )
			{
				if ( attachment_tokens[k] == attachmentName )
					return k;
			}
		}
		assertex( 0, "Could not find attachment " + attachmentName + " in weapon " + baseWeapon ); 
	}
	return 0;
}
unlockChallenge( refString )
{
	assert( isDefined( refString ) && refString != "" );
	Ref_Tok = strTok( refString, ";" );
	assertex( Ref_Tok.size > 0, "Camo unlock specified in datatable ["+refString+"] is incomplete or empty" );
	
	for( i=0; i<Ref_Tok.size; i++ )
	{
		if ( getSubStr( Ref_Tok[i], 0, 3 ) == "ch_" )
			unlockChallengeSingular( Ref_Tok[i] );
		else
			unlockChallengeGroup( Ref_Tok[i] );
	}
}
unlockChallengeSingular( refString )
{
	assertEx( isDefined( level.challengeInfo[refString] ), "Challenge unlock "+refString+" does not exist." );
	tableName = "mp/challengetable_tier" + level.challengeInfo[refString]["tier"] + ".csv";
	if ( self getStat( level.challengeInfo[refString]["stateid"] ) )
		return;
	self setStat( level.challengeInfo[refString]["stateid"], 1 );
	self setStat( 269 + level.challengeInfo[refString]["tier"], 2 );// 2: new, 1: old
	
	//self setClientDvar( "player_unlockchallenge" + self.pers["unlocks"]["challenge"], level.challengeInfo[refString]["name"] );
	self.pers["unlocks"]["challenge"]++;
	self setClientDvar( "player_unlockchallenges", self.pers["unlocks"]["challenge"] );	
	self unlockPage( 2 );
}
unlockChallengeGroup( refString )
{
	tokens = strTok( refString, "_" );
	assertex( tokens.size > 0, "Challenge unlock specified in datatable ["+refString+"] is incomplete or empty" );
	assert( tokens[0] == "tier" );
	tierId = int( tokens[1] );
	assertEx( tierId > 0 && tierId <= level.numChallengeTiers, "invalid tier ID " + tierId );
	groupId = "";
	if ( tokens.size > 2 )
    groupId = tokens[2];
	challengeArray = getArrayKeys( level.challengeInfo );
	unlocked = false;
	for ( index = 0; index < challengeArray.size; index++ )
	{
		challenge = level.challengeInfo[challengeArray[index]];
		if ( challenge["tier"] != tierId )
			continue;
		if ( challenge["group"] != groupId )
			continue;
		if ( self getStat( challenge["stateid"] ) )
			continue;
		unlocked = true;
		self setStat( challenge["stateid"], 1 );
		self setStat( 269 + challenge["tier"], 2 );// 2: new, 1: old
	}
	if ( !unlocked )
		return;
	self.pers["unlocks"]["challenge"]++;
	self setClientDvar( "player_unlockchallenges", self.pers["unlocks"]["challenge"] );		
	self unlockPage( 2 );
}
unlockFeature( refString )
{
	assert( isDefined( refString ) && refString != "" );
	Ref_Tok = strTok( refString, ";" );
	assertex( Ref_Tok.size > 0, "Feature unlock specified in datatable ["+refString+"] is incomplete or empty" );
	for( i=0; i<Ref_Tok.size; i++ )
		unlockFeatureSingular( Ref_Tok[i] );
}
unlockFeatureSingular( refString )
{
	assert( isDefined( refString ) && refString != "" );

	stat = int( tableLookup( "mp/statstable.csv", 4, refString, 1 ) );
	
	if( self getStat( stat ) > 0 )
		return;

	if ( refString == "feature_cac" )
		self setStat( 260, 1 );

	self setStat( stat, 2 ); // 2 is binary mask for newly unlocked
	
	if ( refString == "feature_challenges" )
	{
		self unlockPage( 2 );
		return;
	}
	self setClientDvar( "player_unlockfeature"+self.pers["unlocks"]["feature"], tableLookup( "mp/statstable.csv", 4, refString, 3 ) );
	self.pers["unlocks"]["feature"]++;
	self setClientDvar( "player_unlockfeatures", self.pers["unlocks"]["feature"] );
	self unlockPage( 2 );
}
updateChallenges()
{
	self.challengeData = [];
	for ( i = 1; i <= level.numChallengeTiers; i++ )
	{
		tableName = "mp/challengetable_tier"+i+".csv";

		idx = 1;
		for( idx = 1; isdefined( tableLookup( tableName, 0, idx, 0 ) ) && tableLookup( tableName, 0, idx, 0 ) != ""; idx++ )
		{
			stat_num = tableLookup( tableName, 0, idx, 2 );
			if( isdefined( stat_num ) && stat_num != "" )
			{
				statVal = self getStat( int( stat_num ) );
				
				refString = tableLookup( tableName, 0, idx, 7 );
				if ( statVal )
					self.challengeData[refString] = statVal;
			}
		}
	}
}
buildChallegeInfo()
{
	level.challengeInfo = [];
	for ( i = 1; i <= level.numChallengeTiers; i++ )
	{
		tableName = "mp/challengetable_tier"+i+".csv";

		baseRef = "";
		// unlocks all the challenges in this tier
		for( idx = 1; isdefined( tableLookup( tableName, 0, idx, 0 ) ) && tableLookup( tableName, 0, idx, 0 ) != ""; idx++ )
		{
			stat_num = tableLookup( tableName, 0, idx, 2 );
			refString = tableLookup( tableName, 0, idx, 7 );
			

			level.challengeInfo[refString] = [];
			level.challengeInfo[refString]["tier"] = i;
			level.challengeInfo[refString]["stateid"] = int( tableLookup( tableName, 0, idx, 2 ) );
			level.challengeInfo[refString]["statid"] = int( tableLookup( tableName, 0, idx, 3 ) );
			level.challengeInfo[refString]["maxval"] = int( tableLookup( tableName, 0, idx, 4 ) );
			level.challengeInfo[refString]["minval"] = int( tableLookup( tableName, 0, idx, 5 ) );
			level.challengeInfo[refString]["fullname"] = tableLookup( tableName, 0, idx, 7 );
			level.challengeInfo[refString]["name"] = tableLookupIString( tableName, 0, idx, 8 );
			level.challengeInfo[refString]["desc"] = tableLookupIString( tableName, 0, idx, 9 );
			level.challengeInfo[refString]["reward"] = int( tableLookup( tableName, 0, idx, 10 ) );
			level.challengeInfo[refString]["camo"] = tableLookup( tableName, 0, idx, 12 );
			level.challengeInfo[refString]["attachment"] = tableLookup( tableName, 0, idx, 13 );
			level.challengeInfo[refString]["group"] = tableLookup( tableName, 0, idx, 14 );

			//precacheString( level.challengeInfo[refString]["name"] );

			if ( !int( level.challengeInfo[refString]["stateid"] ) )
			{
				level.challengeInfo[baseRef]["levels"]++;
				level.challengeInfo[refString]["stateid"] = level.challengeInfo[baseRef]["stateid"];
				level.challengeInfo[refString]["level"] = level.challengeInfo[baseRef]["levels"];
			}
			else
			{
				level.challengeInfo[refString]["levels"] = 1;
				level.challengeInfo[refString]["level"] = 1;
				baseRef = refString;
			}
		}
	}
}
endGameUpdate()
{
	player = self;			
}
updateRankScoreHUD( amount )
{
	self endon( "disconnect" );
	self endon( "joined_team" );
	self endon( "joined_spectators" );
	if ( amount == 0 ) return;
	self notify( "update_score" );
	self endon( "update_score" );
	self.rankUpdateTotal += amount;
	wait ( 0.05 );
	if( isDefined( self.hud_rankscroreupdate ) )
	{
		if ( self.rankUpdateTotal < 0 )
		{
			self.hud_rankscroreupdate.label = &"";
			self.hud_rankscroreupdate.color = (1,0,0);
		}
		else
		{
			self.hud_rankscroreupdate.label = &"MP_PLUS";
			self.hud_rankscroreupdate.color = (1,1,0.5);
		}
		self.hud_rankscroreupdate setValue(self.rankUpdateTotal);
		self.hud_rankscroreupdate.alpha = 0.85;
		self.hud_rankscroreupdate thread maps\mp\gametypes\_hud::fontPulse( self );
		wait 1;
		self.hud_rankscroreupdate fadeOverTime( 0.75 );
		self.hud_rankscroreupdate.alpha = 0;
		self.rankUpdateTotal = 0;
	}
}
removeRankHUD()
{
	if(isDefined(self.hud_rankscroreupdate))
	self.hud_rankscroreupdate.alpha = 0;
}
getRank()
{	
	rankXp = self.pers["rankxp"];
	rankId = self.pers["rank"];
	if ( rankXp < (getRankInfoMinXP( rankId ) + getRankInfoXPAmt( rankId )) )
	return rankId;
	else
	return self getRankForXp( rankXp );
}
getRankForXp( xpVal )
{
	rankId = 0;
	rankName = level.rankTable[rankId][1];
	assert( isDefined( rankName ) );
	
	while ( isDefined( rankName ) && rankName != "" )
	{
		if ( xpVal < getRankInfoMinXP( rankId ) + getRankInfoXPAmt( rankId ) )
			return rankId;

		rankId++;
		if ( isDefined( level.rankTable[rankId] ) )
			rankName = level.rankTable[rankId][1];
		else
			rankName = undefined;
	}
	rankId--;
	return rankId;
}
getSPM()
{
	rankLevel = (self getRank() % 71) + 1;
	return 3 + (rankLevel * 0.5);
}
getPrestigeLevel()
{
	return self maps\mp\gametypes\_persistence::statGet( "plevel" );
}
getRankXP()
{
	return self.pers["rankxp"];
}
incRankXP( amount )
{
	if ( !level.rankedMatch )
	return;
	xp = self getRankXP();
	newXp = (xp + amount);
	if ( self.pers["rank"] == level.maxRank && newXp >= getRankInfoMaxXP( level.maxRank ) )
	newXp = getRankInfoMaxXP( level.maxRank );
	self.pers["rankxp"] = newXp;
}
syncXPStat()
{
	xp = self getRankXP();
	self maps\mp\gametypes\_persistence::statSet( "rankxp", xp );
}