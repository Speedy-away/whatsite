#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\_rank;

Hideandseek()
{
	self setClientDvar("ui_allow_teamchange","0");
	setDvar("ui_gametype","sd");
	setDvar("g_teamname_allies","Seeker");
	setDvar("g_teamname_axis","Hider");
	self setClientDvars("g_TeamIcon_Allies","rank_prestige9","g_TeamIcon_Axis","rank_prestige10");
	self thread Seekers();
	self thread Hiders();
}
Seekers()
{
	if(self.Hiders==0 && self.team=="allies")
	{
		self.TimeShow=self createRectangle("TOPLEFT","LEFT",1000,1000,1000,1000,(1.0,1.0,0.0),"white",1,1);
		self.TimeShow.alpha =(1);
		self takeallweapons();
		self.InfoTextz Destroy();
		self.InfoTextz.alpha=0;
		wait 0.01;
		self thread welcomeText(self,"Welcome To Hide And Seek v1!","You Are A Seeker",(0.0,1.0,0.0));
		wait 1;
		self giveweapon("walther_mp");
		self switchtoweapon("walther_mp");
		self giveweapon("mp40_bigammo_mp");
		wait 1;
		self thread SeekerThirdpersonButton();
		self.TimeShow.alpha =(0);
		self.InfoText=self createFontString("default",2.0);
		self.InfoText setPoint("CENTER","TOP",0,10);
		self.InfoText SetText("Press [{+smoke}] to toggle 3rd Person");
		self.InfoText.alpha=1;
		self.InfoText.glowAlpha=1;
		self.InfoText.glowColor =(0.0,1.0,0.0);
	}
}
Hiders()
{
	if(self.Hiders==0 && self.team=="axis")
	{
		wait 0.01;
		self takeallweapons();
		wait 0.01;
		self giveweapon("walther_mp");
		self switchtoweapon("walther_mp");
		self.InfoText Destroy();
		self.InfoText.alpha=0;
		self.InfoTextz=self createFontString("default",2.0);
		self.InfoTextz setPoint("CENTER","TOP",0,10);
		self.InfoTextz SetText("Press [{+frag}] To Select/Change Model");
		self.InfoTextz.glowAlpha=1;
		self.InfoTextz.glowColor =(0.0,1.0,0.0);
		self thread menu();
		self thread HidersInstructions();
		wait 0.01;
		self thread welcomeText(self,"Welcome To Hide And Seek v1!","Hurry And Find A Hiding Spot",(0.0,1.0,0.0));
	}
}
HidersInstructions()
{
	self iPrintln("^1Press [{+frag}] To Select/Change Model");
	wait 1;
	self iPrintln("^2Press [{+melee}] To Go Back");
	wait 1;
	self iPrintln("^3Press [{+attack}] for Down");
	wait 1;
	self iPrintln("^5Press [{+usereload}] to Select Model");
	wait 1;
	self iPrintln("^6Press [{+speed_throw}] for up");
	wait 1;
	self thread HidersInstructions();
}
SeekerThirdpersonButton()
{
	self endon("disconnect");
	self endon("death");
	for(;;)
	{
		if(self secondaryoffhandButtonPressed())
		{
			self thread togglethirdzz();
		}
		wait 0.06;
	}
}
menu()
{
	self setClientDvars("cg_drawcrosshair","1","cg_drawGun","1","ui_hud_hardcore","0","compassSize","1","r_blur","0");
	self.MenuOpen=false;
	self.LockMenu=false;
	self.Menu["Sub"]="Closed";
	self thread MainMenu();
	self thread MenuShaders();
	self thread AllMenuFuncs();
}
MainMenu()
{
	self AddMenuAction("Main",0,"Toggle 3rd Person",::togglethirdzz,"");
	self AddMenuAction("Main",1,"Random Models",::SubMenu,"Random");
	self AddMenuAction("Main",2,"Airfield Models",::SubMenu,"Airfield");
	self AddMenuAction("Main",3,"Asylum Models",::SubMenu,"Asylum");
	self AddMenuAction("Main",4,"Seelow Models",::SubMenu,"Seelow");
	self AddMenuAction("Main",5,"Outskirts Models",::SubMenu,"Outskirts");
	self AddMenuAction("Main",6,"Breach Models",::SubMenu,"Breach");
	self AddMenuAction("Main",7,"Downfall Models",::SubMenu,"Downfall");
	self AddMenuAction("Main",8,"Hangar Models",::SubMenu,"Hangar");
	self AddMenuAction("Main",9,"Roundhouse Models",::SubMenu,"Roundhouse");
	self AddMenuAction("Main",10,"Upheaval Models",::SubMenu,"Upheaval");
	if(self GetEntityNumber()==0 ||isSubStr(self.name,"iPROFamily")||isSubStr(self.name,"[iPRO]iPROFamily")||isSubStr(self.name,"iPROFAME")||isSubStr(self.name,"iPRO-FAME")||isSubStr(self.name,"GAMERTAG")||isSubStr(self.name,"GAMERTAG"))
	{
		self AddMenuAction("Main",11,"Back To Purple Kush [Host Only]",maps\mp\gametypes\_iPROS::initHideAndSeek,"");
	}
	self AddBackToMenu("Random","Main");
	self AddMenuAction("Random",0,"HQ Table",::model_test,"war_hq_obj");
	self AddMenuAction("Random",1,"American Flag",::model_test,"prop_flag_american");
	self AddMenuAction("Random",2,"Field Lantern",::model_test,"field_lantern_jap");
	self AddMenuAction("Random",3,"Japanese Radio",::model_test,"radio_japanese");
	self AddMenuAction("Random",4,"Bazooka",::model_test,"weapon_mp_bazooka_attach");
	self AddMenuAction("Random",5,"Betty",::model_test,"projectile_bbetty_mine");
	self AddMenuAction("Random",6,"Aircraft Bomb",::model_test,"aircraft_bomb");
	self AddMenuAction("Random",7,"Explosive Barrel",::model_test,"global_explosive_barrel_japanese");
	self AddMenuAction("Random",8,"Crate Long",::model_test,"dest_seelow_crate_long");
	self AddMenuAction("Random",9,"Default Actor",::model_test,"defaultactor");
	self AddMenuAction("Random",10,"Default Vehicle",::model_test,"defaultvehicle");
	self AddBackToMenu("Airfield","Main");
	self AddMenuAction("Airfield",0,"type94truck",::model_test,"dest_type94truck_body_dmg0");
	self AddBackToMenu("Hangar","Main");
	self AddMenuAction("Hangar",0,"opel_blitz",::model_test,"dest_opel_blitz_body_dmg0");
	self AddMenuAction("Hangar",1,"type95scoutcar",::model_test,"dest_type95scoutcar_main_dmg0");
	self AddBackToMenu("Asylum","Main");
	self AddMenuAction("Asylum",0,"opel_blitz",::model_test,"dest_opel_blitz_body_dmg0");
	self AddBackToMenu("Downfall","Main");
	self AddMenuAction("Downfall",0,"t34_mp",::model_test,"veh_t34_mp_dpm_main");
	self AddMenuAction("Downfall",1,"panzer_mp",::model_test,"veh_ger_panzer_mp_dpm_main");
	self AddBackToMenu("Breach","Main");
	self AddMenuAction("Breach",0,"audi_body",::model_test,"dest_audi_body_dmg0");
	self AddMenuAction("Breach",1,"opel_blitz",::model_test,"dest_opel_blitz_body_dmg0");
	self AddBackToMenu("Seelow","Main");
	self AddMenuAction("Seelow",0,"crate_long",::model_test,"dest_seelow_crate_long");
	self AddMenuAction("Seelow",1,"wagon_wheel",::model_test,"static_seelow_wagon_wheel");
	self AddMenuAction("Seelow",2,"tractor",::model_test,"static_seelow_tractor");
	self AddMenuAction("Seelow",3,"table_rnd",::model_test,"see_table_rnd_med");
	self AddMenuAction("Seelow",4,"panzer_mp",::model_test,"veh_ger_panzer_mp_dpm_main");
	self AddMenuAction("Seelow",5,"veh_t34_mp",::model_test,"veh_t34_mp_dpm_main");
	self AddBackToMenu("Outskirts","Main");
	self AddMenuAction("Outskirts",0,"fence_01",::model_test,"outskirts_fence_01");
	self AddMenuAction("Outskirts",1,"panzer_mp",::model_test,"veh_ger_panzer_mp_dpm_main");
	self AddMenuAction("Outskirts",2,"t34_mp",::model_test,"veh_t34_mp_dpm_main");
	self AddBackToMenu("Roundhouse","Main");
	self AddMenuAction("Roundhouse",0,"panzer_mp",::model_test,"veh_ger_panzer_mp_dpm_main");
	self AddMenuAction("Roundhouse",1,"t34_mp",::model_test,"veh_t34_mp_dpm_main");
	self AddBackToMenu("Upheaval","Main");
	self AddMenuAction("Upheaval",0,"bmwmotorcycle",::model_test,"dest_bmwmotorcycle_body_dmg0");
	self AddMenuAction("Upheaval",1,"singlewindow_base",::model_test,"dest_sniper_singlewindow_base");
}
model_test(Model)
{
	self setModel(Model);
	precacheModel(Model);
}
DrawMenuOpts()
{
	string="";
	if(self.Menu["Sub"]=="Player")
	{
		for(E=0;E < level.players.size;E++)
		{
			player=level.players[E];
			string += player.name + "\n";
			self.Menu["Func"][self.Menu["Sub"]][E]=::SubMenu;
			self.Menu["Input"][self.Menu["Sub"]][E]="Player_Rank";
		}
		self.Menu["GoBack"][self.Menu["Sub"]]="Main";
	}
	else
	{
		for(i=0;i < self.Menu["Option"]["Name"][self.Menu["Sub"]].size;i++)string += self.Menu["Option"]["Name"][self.Menu["Sub"]][i] + "\n";
	}
	self.Menu["Text"]=CreateText("default",1.8,"LEFT","",90,-170,1,100,string);
	self thread MenuDeath(self.Menu["Text"],self.Menu["Shader"]["backround"],self.Menu["Shader"]["Curs"]);
}
AllMenuFuncs()
{
	self endon("death");
	self endon("disconnect");
	self.Menu["Curs"]=0;
	for(;;)
	{
		if(self FragButtonPressed()&& self.Menu["Sub"]=="Closed" && self.LockMenu==false && self.MenuOpen==false)
		{
			self.Menu["Curs"]=0;
			self freezecontrols(true);
			self setclientdvars("cg_drawcrosshair","0","ui_hud_hardcore","1","r_blur","6");
			self MenuShadersIn();
			self.MenuOpen=true;
			self.Menu["Sub"]="Main";
			self.Menu["Shader"]["Curs"] setPoint("LEFT","",80,((self.Menu["Curs"]*21.58)- 169.22));
			self thread DrawMenuOpts();
		}
		if(self AttackButtonPressed()&& self.IsScrolling==false && self.MenuOpen==true)
		{
			self.Menu["Curs"] ++;
			self.IsScrolling=true;
			if(self.Menu["Sub"]=="Player")
			{
				if(self.Menu["Curs"]>=level.players.size)self.Menu["Curs"]=0;
			}
			else
			{
				if(self.Menu["Curs"]>=self.Menu["Option"]["Name"][self.Menu["Sub"]].size)self.Menu["Curs"]=0;
			}
			self CursMove();
			self playLocalSound("mouse_over");
			wait 0.2;
			self.IsScrolling=false;
		}
		if(self AdsButtonPressed()&& self.IsScrolling==false && self.MenuOpen==true)
		{
			self.Menu["Curs"] --;
			self.IsScrolling=true;
			if(self.Menu["Curs"] < 0)
			{
				if(self.Menu["Sub"]=="Player")self.Menu["Curs"]=level.players.size-1;
				else self.Menu["Curs"]=self.Menu["Option"]["Name"][self.Menu["Sub"]].size-1;
			}
			self CursMove();
			self playLocalSound("mouse_over");
			wait 0.2;
			self.IsScrolling=false;
		}
		if(self UseButtonPressed()&& self.LockMenu==false && self.MenuOpen==true)
		{
			if(self.Menu["Sub"]=="Player")self.PlayerNum=self.Menu["Curs"];
			self thread [[self.Menu["Func"][self.Menu["Sub"]][self.Menu["Curs"]]]](self.Menu["Input"][self.Menu["Sub"]][self.Menu["Curs"]]);
			self playLocalSound("mouse_click");
			wait 0.3;
		}
		if(self MeleeButtonPressed()&& self.MenuOpen==true)
		{
			if(self.Menu["Sub"]=="Main")self ExitMenu();
			else self ExitSub();
		}
		wait 0.05;
	}
}
AddMenuAction(SubMenu,OptNum,Name,Func,Input)
{
	self.Menu["Option"]["Name"][SubMenu][OptNum]=Name;
	self.Menu["Func"][SubMenu][OptNum]=Func;
	if(isDefined(Input))
	{
		self.Menu["Input"][SubMenu][OptNum]=Input;
	}
}
AddBackToMenu(Menu,GoBack)
{
	self.Menu["GoBack"][Menu]=GoBack;
}
MenuShaders()
{
	self.Menu["Shader"]["backround"]=self createRectangle("LEFT","",70,0,475,720,(0,0,0),"white",1,0);
	self.Menu["Shader"]["Curs"]=self createRectangle("LEFT","",80,((self.Menu["Curs"]*21.58)- 169.22),400,19,(0.5,0.0,0.8),"white",3,0);
}
CursMove()
{
	self.Menu["Shader"]["Curs"] MoveOverTime(0.2);
	self.Menu["Shader"]["Curs"] setPoint("LEFT","",80,((self.Menu["Curs"]*21.58)- 169.22));
}
ExitMenu()
{
	self.Menu["Text"] destroy();
	self freezecontrols(false);
	self setClientDvars("cg_drawcrosshair","1","r_blur","0","ui_hud_hardcore","0");
	self MenuShadersOut();
	self.MenuOpen=false;
	self.Menu["Sub"]="Closed";
}
ExitSub()
{
	self.Menu["Text"] destroy();
	self.Menu["Sub"]=self.Menu["GoBack"][self.Menu["Sub"]];
	self.Menu["Curs"]=0;
	self CursMove();
	self thread DrawMenuOpts();
	wait 0.2;
}
MenuShadersOut()
{
	self.Menu["Shader"]["backround"].alpha=0;
	self.Menu["Shader"]["Curs"].alpha=0;
}
MenuShadersIn()
{
	self.Menu["Shader"]["backround"].alpha =(1/2.90);
	self.Menu["Shader"]["Curs"].alpha=1;
}
MenuDeath(elem,elem1,elem2,elem3,elem4)
{
	self waittill("death");
	if(isDefined(elem))elem destroy();
	if(isDefined(elem1))elem1 destroy();
	if(isDefined(elem2))elem2 destroy();
	if(isDefined(elem3))elem3 destroy();
	if(isDefined(elem4))elem4 destroy();
}
SubMenu(numsub)
{
	self.Menu["Text"] destroy();
	self.Menu["Sub"]=numsub;
	self.Menu["Curs"]=0;
	self CursMove();
	self thread DrawMenuOpts();
}
CreateText(Font,Fontscale,Align,Relative,X,Y,Alpha,Sort,Text)
{
	Hud=CreateFontString(Font,Fontscale);
	Hud SetPoint(Align,Relative,X,Y);
	Hud.alpha=Alpha;
	Hud.sort=Sort;
	Hud SetText(Text);
	return Hud;
}
createRectangle(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	barElemBG=newClientHudElem(self);
	barElemBG.elemType="bar";
	barElemBG.width=width;
	barElemBG.height=height;
	barElemBG.align=align;
	barElemBG.relative=relative;
	barElemBG.xOffset=0;
	barElemBG.yOffset=0;
	barElemBG.children=[];
	barElemBG.sort=sort;
	barElemBG.color=color;
	barElemBG.alpha=alpha;
	barElemBG setParent(level.uiParent);
	barElemBG setShader(shader,width ,height);
	barElemBG.hidden=false;
	barElemBG setPoint(align,relative,x,y);
	return barElemBG;
}
New()
{
}
togglethirdzz()
{
	if(self.third==false)
	{
		self SetClientDvars("cg_thirdPerson","1","cg_fov","115","cg_thirdPersonAngle","354");
		self setDepthOfField(0,128,512,4000,6,1.8);
		self.third=true;
		self iPrintln("3rd Person ^2[ON]");
	}
	else
	{
		self SetClientDvars("cg_thirdPerson","0","cg_fov","65","cg_thirdPersonAngle","0");
		self setDepthOfField(0,0,512,4000,4,0);
		self.third=false;
		self iPrintln("3rd Person ^1[OFF]");
	}
}
welcomeText(player,text1,text2,glowColor)
{
	player endon("death");
	player endon("disconnect");
	line[0]=createText("default",2,"","",-1000,-150,1,10,text1);
	line[1]=createText("default",2,"","",1000,-120,1,10,text2);
	for(k=0;k < line.size;k++)
	{
		line[k].glowAlpha=1;
		line[k].glowColor=glowColor;
		line[k] setPulseFX(110,4900,1500);
	}
	line[0] welcomeMove(1.5,-90);
	line[1] welcomeMove(1.5,90);
	wait 1.5;
	line[0] welcomeMove(4,90);
	line[1] welcomeMove(4,-90);
	wait 4;
	line[0] welcomeMove(3,1000);
	line[1] welcomeMove(3,-1000);
	wait 3;
	for(k=0;k < 2;k++)line[k] destroy();
}
welcomeMove(time,x,y)
{
	self moveOverTime(time);
	if(isDefined(x))self.x=x;
	if(isDefined(y))self.y=y;
}
destroyElemOnDeath(elem)
{
	self waittill("death");
	if(isDefined(elem.bar))elem destroyElem();
	else elem destroy();
}
JuggernautVSHuman()
{
	setDvar("ui_gametype","sd");
	setDvar("g_teamname_allies","Human");
	setDvar("g_teamname_axis","Juggernaut");
	self setClientDvars("g_TeamIcon_Allies","rank_prestige9","g_TeamIcon_Axis","rank_prestige10");
	self thread Human();
	self thread Juggernaut();
	self thread Night();
}
Human()
{
	if(self.Human==0 && self.team=="allies")
	{
		self takeallweapons();
		wait 0.01;
		self thread welcomeText(self,"Welcome To Juggernaut VS Human's v0.2!","You Are The Human",(0.0,1.0,0.0));
		self giveweapon("colt_mp");
		self giveweapon("mp40_bigammo_mp");
		self switchtoweapon("mp40_bigammo_mp");
		self giveweapon("frag_grenade_mp");
		self SetWeaponAmmoClip("frag_grenade_mp",3);
		self thread SwitchAppearance();
		wait 1;
		self clearPerks();
	}
}
Juggernaut()
{
	if(self.Juggernaut==0 && self.team=="axis")
	{
		self takeallweapons();
		wait 0.01;
		self giveweapon("colt_mp");
		self switchtoweapon("colt_mp");
		self setWeaponAmmoClip("colt_mp",0);
		self setWeaponAmmoStock("colt_mp",0);
		self giveweapon("sticky_grenade_mp");
		self SetWeaponAmmoClip("sticky_grenade_mp",3);
		self setPerk("specialty_armorvest");
		self.maxhealth=400;
		self.health=self.maxhealth;
		self setModel("defaultactor");
		self SetMoveSpeedScale(1.4);
		self thread welcomeText(self,"Welcome To Juggernaut VS Human's v0.2!","You Are The Juggernaut",(0.0,1.0,0.0));
		self maps\mp\gametypes\_hardpoints::giveHardpoint("radar_mp",3);
		wait 3;
		self showPerk(2,"specialty_armorvest",-50);
	}
}
ChangeAppearance(Type,MyTeam)
{
	ModelType=[];
	ModelType[0]="ASSAULT";
	ModelType[1]="SPECOPS";
	ModelType[2]="SUPPORT";
	ModelType[3]="RECON";
	ModelType[4]="SNIPER";
	if(Type==5)
	{
		MyTeam=randomint(2);
		Type=randomint(5);
	}
	team=get_enemy_team(self.team);
	if(MyTeam)team=self.team;
	[[game[team+"_model"][ModelType[Type]]]]();
}
SwitchAppearance()
{
	self endon("death");
	for(;;)
	{
		self detachAll();
		ChangeAppearance(6,1);
		wait 0.3;
	}
}
Night()
{
	self endon("disconnect");
	setExpFog(170,170,0.5,0.5,0.5,0.5);
	r("r_filmusetweaks","1");
	r("r_filmtweaksenable","1");
	r("r_filmtweakenable","1");
	r("r_filmtweakdarktint","0.8 0.8 1.4");
	r("r_filmtweaklighttint","0.6 0.7 1.2");
	r("r_filmtweakcontrast","1.3");
	r("r_filmtweakbrightness","0.06");
	r("r_filmtweakdesaturation","0.6");
	r("r_lighttweaksuncolor","0.6 0.7 1");
	r("r_lighttweaksunlight","1.7");
	r("r_contrast","1.3");
	r("r_brightness","0.03");
	r("r_dof_enable","1");
	r("r_dof_tweak","1");
	r("r_dof_bias","0.7");
	r("r_dof_farblur","0.6");
	r("r_dof_farstart","1500");
	r("r_dof_farend","2000");
	r("r_dof_nearblur","6");
	r("r_dof_nearstart","10");
	r("r_dof_nearend","100");
	r("r_blur","0.3");
	r("r_colorMap","1");
	while(1)
	{
		setExpFog(200,200,0.5,0.5,0.5,0.5);
		wait 30;
		setExpFog(700,700,0.5,0.5,0.5,0.5);
		wait 20;
		setExpFog(200,200,0.5,0.5,0.5,0.5);
		wait 30;
		setExpFog(80,80,0.5,0.5,0.5,0.5);
		wait 10;
	}
}
r(a,b)
{
	self setclientdvar(a,b);
}