Chronicles V2 | Black Ops 1 Zombies (TU11)
Developer: RainReach

Release Date: 3/26/2026

Platform: Xbox 360 (RGH/JTAG)

[Project Overview]
Chronicles V2 is a complete rebuild of my previous Zm framework, now fully optimized for BO1 Zombies. This project focuses on high-performance rendering and stable Dvar manipulation.

[Update Log - v2.0.0]
Migration: Shifted from MP logic to TU11 Zombies.

Engine: Patched memory at 0x823e2368 and 0x823e2350 to unlock restricted Dvars.

UI/Visuals: * Smooth Sin-Wave Rainbow Ticker (Thanks Zyana).

Alpha Pulse Fade on all HUD elements (Watermark & News Bar).

Fixed sub-menu visibility; FOV, Weapons, and Time menus are now 100% visible.

Lighting: Fixed Time Changer logic. Night and Morning modes now force an exposure update so they actually work on-screen.

PC Visuals: Enabled forced rendering for Occluders, Shadows, and Specular highlights.

Feedback: Integrated SV_GameSendServerCommand for color-coded kill-feed notifications.

[Roadmap | Coming Soon]
Aimbot: Silent-aim logic specifically for zombie head-tags.

Zombie ESP: 2D Box and Snapline visuals to track AI through walls.

Magnet Mods: "Z-Magnet" to snap all active zombies to a single coordinate.

[How to Load]
Place the Chronicles_V2.xex on your HDD or USB.

Load Black Ops 1 (ensure you are on Title Update 11).

Inject or set as a plugin.
Best Way To Use Is To Use Module Loader

Open Menu: Left Trigger + Right Thumbstick.