Instructions: 

Put the folder called "GalaxyMenu" on your HDD  and GalaxyMenu.FREE on the Root of your HDD. 

if it doesn't work as a plugin  inject it with a Module loader.