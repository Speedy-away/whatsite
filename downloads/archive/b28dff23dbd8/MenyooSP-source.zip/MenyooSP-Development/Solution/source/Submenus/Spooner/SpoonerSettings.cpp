/*
* Menyoo PC - Grand Theft Auto V single-player trainer mod
* Copyright (C) 2019  MAFINS
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*/
#include "SpoonerSettings.h"

#include "..\..\macros.h"

//#include "..\..\Menu\Menu.h"
//#include "..\..\Menu\Routine.h"

//#include "..\..\Natives\natives2.h"

namespace sub::Spooner
{
	namespace Settings
	{
//#define GTA_MAX_ENTITIES 2048

		bool bInvertScrollSensitivity = false; // false = left multiplies Scroll Sensitivity, true = right multiplies

		bool bShowModelPreviews = true;
		bool bDisplaySpoonerInfo = true;
		bool bShowBoxAroundSelectedEntity = false;
		bool bSpawnDynamicProps = false;
		bool bSpawnDynamicPeds = true;
		bool bSpawnDynamicVehicles = true;
		bool bFreezeEntityWhenMovingIt = false;
		bool bSpawnInvincibleEntities = false;
		bool bSpawnStillPeds = true;
		bool bAddToDbAsMissionEntities = true;
		bool bKeepPositionWhenAttaching = false;
		
		bool bTeleportToReferenceWhenLoadingFile = true;

		bool bGridSnapEnabled = false; // use SnapPos / SnapRot to get the snapped position / rotation Vector3
		float gridSnapSize = 1.0f;
		float rotationSnapDegrees = 0.0f;
		bool bSnapToGround = false; // use SnapPos to get the snapped position Vector3
		bool bDrawGrid = false;

		bool bAutoSaveDb = false;
		DWORD autoSaveIntervalMs = 180000;
		int autoSaveMaxFiles = 10;
	}

}



