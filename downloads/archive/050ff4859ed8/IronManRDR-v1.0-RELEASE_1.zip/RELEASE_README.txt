================================================================
  IRON MAN RDR  -  by TAMED MODS
  Red Dead Redemption 2 (Story Mode) script mod
================================================================

Fly, fight, and light up the frontier as Iron Man: camera-directed
flight with a superman glide, charged repulsor lightning, an orange
chest unibeam, homing missiles, pulse blasts, slam landings, a
J.A.R.V.I.S. voice, custom sound design, and an animated targeting
reticle.

----------------------------------------------------------------
REQUIREMENTS
----------------------------------------------------------------
- Red Dead Redemption 2 (PC, Story Mode ONLY - never use online)
- ScriptHookRDR2 (Alexander Blade)  http://dev-c.com/rdr2/scripthookrdr2
- Lenny's Mod Loader (LML) for the texture pack

----------------------------------------------------------------
INSTALL
----------------------------------------------------------------
1. Copy IronManRDR.asi and IronManRDR.ini into your RDR2 game
   folder (next to RDR2.exe).
2. Copy the IronManSFX folder into the same game folder.
3. Copy ironman_fx.ytd into lml\stream\
4. Launch story mode and press F5.

----------------------------------------------------------------
DEFAULT CONTROLS  (rebindable in IronManRDR.ini)
----------------------------------------------------------------
F5      Suit up / power down          SPACE   Fly (hold)
LCTRL   Descend                       LSHIFT  Boost
E       Repulsor beam (charges 1.5s)  Q       Unibeam (hold)
R       Missile volley (charges)      F       Pulse blast (charges)
G       Ground slam                   X       Hero landing (midair)
T       Cycle lock-on targets         C       Combat mode
RMB     Free-aim lock                 F7      Diagnostics
F8      Flight yaw calibration

Every key, color, speed, and effect is tunable in IronManRDR.ini.

----------------------------------------------------------------
LICENSE
----------------------------------------------------------------
(c) Tamed Mods. All rights reserved.
Do not redistribute, re-upload, decompile, or repackage this mod
or any of its files. Do not include it in mod packs. Links to the
official page only. Video content made with the mod is welcome
and encouraged - credit "Iron Man RDR by Tamed Mods".

Story mode only. Using mods in Red Dead Online will get your
account banned - do not do it.
