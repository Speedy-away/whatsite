./mupen64plus.app/Contents/MacOS/mupen64plus --gfx mupen64plus-video-glide64mk2 "$@"
