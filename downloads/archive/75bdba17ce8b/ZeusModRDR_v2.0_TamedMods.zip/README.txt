================================================================
  ZEUS MOD RDR  v2.0  -  God of Thunder for Red Dead Redemption 2
  by TamedMods
================================================================

REQUIREMENTS
  - Red Dead Redemption 2 (PC)
  - ScriptHookRDR2 by Alexander Blade  (https://www.dev-c.com/rdr2/scripthookrdr2/)

INSTALL
  1. Install ScriptHookRDR2 (drop ScriptHookRDR2.dll and dinput8.dll
     next to RDR2.exe) if you do not already have it.
  2. Copy ZeusModRDR.asi and ZeusModRDR.ini into the same folder as
     RDR2.exe (the game's root folder, NOT a subfolder).
  3. Launch the game. Press F10 to become the God of Thunder.

  Both files must keep their names and stay next to each other -
  the mod reads the .ini that matches its own filename.

UNINSTALL
  Delete ZeusModRDR.asi and ZeusModRDR.ini.

----------------------------------------------------------------
CONTROLS
----------------------------------------------------------------
  F10 . . . . . Zeus Mode on / off  (everything below needs it ON)

  POWERS
  E . . . . . . SMITE - lightning strikes wherever you aim
  Q . . . . . . CHAIN LIGHTNING - arcs from target to target
  X . . . . . . THUNDERCLAP (on the ground)
                SUPERHERO LANDING (in the air - see FLIGHT)
  G . . . . . . STORM CALL - a barrage of strikes around you
  J . . . . . . DIVINE JUDGMENT - marks your target, then executes
  O . . . . . . WRATH OF OLYMPUS - the ultimate
  V (hold). . . AEGIS - the terror aura; everyone nearby cowers
  C . . . . . . EAGLE OF ZEUS - the Aetos Dios companion
  T . . . . . . STORM WEATHER on / off

  MJOLNIR
  R . . . . . . summon / recall
  LEFT MOUSE. . throw (homes on a locked target) - click again to recall
                Mjolnir is EQUIPPED as a real weapon and ALWAYS returns.

  FLIGHT
  SPACE tap . . flight on / off
  SPACE hold. . ascend
  LEFT CTRL . . descend  (touch down to land)
  W A S D . . . fly, relative to the camera
  LEFT SHIFT. . boost   (tap in mid-air to stack extra speed)
  release all . auto-hover, holding altitude
  X in the air. SUPERHERO LANDING - rocket down and crater the ground

----------------------------------------------------------------
TUNING
----------------------------------------------------------------
  Everything is configurable in ZeusModRDR.ini - delete any line to
  fall back to its default. Highlights:

    BoltSize / BoltBranches / BoltDetail . lightning look
    CamShakeStrength . . . . . . . . . . . one dial for all shake
                                           (CamShake=0 disables it)
    ThrustSpeed / BoostMult / etc . . . . flight feel
    HeroRadius / HeroForce / HeroDamage . superhero landing
    GodMode  . . . . . . . . . . . . . . . invincibility

  A ZeusModRDR.log is written next to the .asi. If something does not
  appear in-game, that file will usually say why.

----------------------------------------------------------------
CREDITS
----------------------------------------------------------------
  Mod . . . . . . . . . . . . TamedMods
  ScriptHookRDR2. . . . . . . Alexander Blade
  RDR2 native database. . . . alloc8or
  Asset & effect name lists . femga (rdr3_discoveries)

  All credit for this mod goes to TamedMods.
  Not affiliated with or endorsed by Rockstar Games or Take-Two.
