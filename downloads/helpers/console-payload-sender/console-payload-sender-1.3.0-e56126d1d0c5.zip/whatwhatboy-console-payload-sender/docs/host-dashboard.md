# PS4 / PS5 host dashboards

The local entry point is `/hosts/`: choose PS4 or PS5, select the installed firmware, configure the console address, then choose Loaders, Payloads, Game mods or Tools. The Game mods tab also filters by game. The console address is user-configured; it is not a public-IP lookup or automatic LAN discovery. Firmware detected from a console browser is shown separately.

Console-browser detection runs automatically and can be repeated with **Detect console**. It recognises PS4 and PS5 user agents, normalises their firmware version, preselects it even if it is not in the known launcher list, and identifies when the visitor opened the other console's page. On a phone or computer it leaves the console firmware as a manual choice. Browser-reported firmware is not a native hardware query, and a spoofed browser identity can hide it. No jailbreak or payload runs during detection.

**Check services** is an explicit read-only request through the paired local sender. It checks PS4 GoldHEN readiness or PS5 Payload Manager's application version and reported IP using fixed endpoints. An application version is never displayed as console firmware, and no running game/version is inferred from a process name. Changing the configured address resets the displayed service verification.

The PS4 GTA V view puts newer game updates first and groups each menu family into one card. Expulsion, Cyprus, Oysters and other families with multiple builds open a **Choose version** popup. Its options identify the game update, separate menu version, format, host build and title IDs where supplied. Selecting an option changes only its preview, requirements and file actions; it never downloads or loads automatically. Unknown menu versions remain **Not provided**. **Show older game builds** is initially enabled following the user's request to expose older menus, and can hide older-only choices. Firmware filtering still applies before grouping.

Ready PRX/SPRX files for game updates 1.56 and 1.57 include Expulsion, Velora, Beach, Cyprus, Explosive, LTS/LRS and Serendipity. These are newer than the original host BIN choices, not a claim to support the newest GTA V retail update. Plugins use their documented native installation flow and are never sent as raw BIN or ELF payloads. Expulsion's direct PRX updates an existing support tree; a first installation also needs its support files.

`host-legacy-menu-actions.json` adds 15 original-host GTA V variants across eight older game updates. Four exact Nazky mappings use its documented GoldHEN HTTP transport; eleven retain Download plus their original host. They are pinned to PS4 firmware 9.00. `host-extra-game-actions.json` adds 34 PS4 and six native PS5 JSON trainer definitions, preserving exact game updates, title IDs and native cheat-manager setup. These data files have no raw-payload Run action. See [legacy source review](host-legacy-menu-review.json) and [other-game trainer guide](host-extra-game-trainers.md).

Expulsion V7 uses an original, labelled **Menu cover** because the previous screenshot showed V5. Explosive also uses a labelled cover rather than an unverified binary-version screenshot. Oysters and North use their source-supplied menu previews. A preview identifies the menu family; it is not evidence of successful execution for the selected bytes. [Artwork review](host-menu-art-review.json) records these boundaries.

## Actions and compatibility

- **Launch / Open host** navigates to a reviewed upstream host in a new tab. Open it on the console to use its exploit chain.
- **Run** uses the documented running console service or the paired desktop sender. It never runs automatically on page load.
- **Download** saves a ready-to-use file through the browser. It does not guarantee a console filesystem destination. The optional download-on-Run checkbox requests a separate browser file copy after a transfer is accepted.
- **Save on PS4 / PS5** opens that console's installed ezRemote companion with the exact file catalogue ID. Confirm the file, destination and transfer there. Install the current companion from the download centre when new file IDs are added; an older installed snapshot may not recognise them. No transfer is submitted merely by clicking the host button.
- PS4 native BIN sends use GoldHEN's HTTP BinLoader on port 9090. The nine direct game-menu actions use the exact BIN mappings reviewed in Nazky's HTTP loader. Three other menu builds retain Download plus Open menu host instead of claiming an equivalent native loading method.
- PS5 direct ELF requests use the official ELF loader's HTTP `?uri=` interface on port 9021. The payload URL uses the actual website origin. A desktop loopback preview cannot be fetched by the console, so it requires a LAN-reachable file host or the paired sender. HTTPS pages provide an explicit console-loader navigation link when mixed-content fetches are blocked.
- The desktop sender transfers verified local ELF bytes over TCP 9021 or verified PS4 BIN bytes through GoldHEN HTTP. See [sender setup](host-payload-sender.md).

Firmware whitelists remain exact. A launcher supporting 13.52 does not establish 13.52 support for a 9.00 game menu. Each menu retains its game update, source, checksum and requirements. The PS5 RDR2 action is a 60FPS runtime patch for the specified PS4 game build running on PS5, not a full mod menu.

**Accepted / sent reports transport only.** Confirm the effect on the console. No downloaded exploit, payload or menu was executed during implementation or verification. Network tests use mocks and temporary fixtures.

File explorers and Payload Manager links require the named native service to be running. A public website cannot access the console disk, create folders, install PKGs or bypass the manager's origin checks. See [service documentation and primary sources](host-console-services.md) and the illustrated [console file guides](guides/README.md).

## Files, payload management and layout

The desktop library uses four compact cards per row, with responsive three-, two- and one-column layouts. Menu previews and labelled game artwork remain separate from payload/project images. Requirements and attribution stay collapsed until opened. PS4's firmware selector includes 14.00 and displays the existing experimental guide and ISO page when selected; no other payload's pinned compatibility is expanded.

The dedicated [PS4 payload management page](../hosts/ps4/payload-manager/index.html) explains native GoldHEN LaunchPad/AutoRun. The [PS5 payload management page](../hosts/ps5/payload-manager/index.html) loads the pinned manager through the existing explicit transport and opens its native installed-payload, autoload, storage, sources and process screens. See the [management setup and primary sources](host-payload-management.md). Install receiver version **2026.11.02.9** from the matching console download centre for the added file IDs; older receiver snapshots and their original file IDs remain preserved. `host-menu-companion-build.json` records exact bytes, hashes and archived locations.

The target console stays explicit when browsing from a PC. Loopback addresses are accepted only inside the matching console browser, so a computer's own service cannot be mistaken for its PS4 or PS5. File-manager controls choose PS4 ezRemote on 8080, PS5 websrv on 8080 `/fs/`, or PS5 ezRemote on 9090. Each service must already be running.

`node scripts/verify-host-payloads.cjs --write` checks curated file sizes, SHA-256 values, sender validation and ELF structure without executing payloads or contacting a console. The report is `qa/host-payload-integrity.json`; it establishes file integrity, not hardware execution.

## Maintain the dashboard

Catalogue data lives in `host-actions-ps4.json`, `host-actions-ps5.json` and `host-game-actions.json` beside this document. Keep publisher source URLs, exact firmware/game compatibility, file sizes and SHA-256 values with each runnable entry. Preserve the original compressed downloads and previous variants in the local archive; expose ready files as separate immutable downloads. Follow [AGENTS.md](../AGENTS.md).

```powershell
node scripts/build-host-selector.cjs
node --test scripts/tests/host-dashboard.test.cjs scripts/tests/host-console-client.test.cjs scripts/tests/console-payload-bridge.test.cjs
node scripts/audit-site.cjs
```

Building local pages does not publish them or make new files available at the public domain. Rebuild the downloadable sender after the final dashboard, catalogue and language changes; its immutable bundle is a snapshot.
