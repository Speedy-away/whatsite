# whatwhatboy console payload sender

Extract this entire ZIP into a new folder. Keep scripts/, assets/, docs/, hosts/ and downloads/ beside this README. Do not run the ZIP in place.

1. Install Node.js 20 or newer from https://nodejs.org/. Node is not included.
2. On Windows, double-click "Start Sender.cmd". On macOS/Linux, open a terminal in this folder and run `node scripts/console-payload-bridge.cjs`.
3. Open http://127.0.0.1:8766/hosts/ on this computer. Enter the fresh pairing token printed in the terminal.
4. Choose PS4 or PS5, enter the console LAN IPv4 address, and select its exact firmware and game update. Start the compatible console loader separately, then choose Load for one compatible payload.
5. Keep the sender running while using it. Ctrl+C stops it.

The server binds only 127.0.0.1; it cannot be opened from a console browser. This computer and the console must reach each other on the same LAN. No payload runs merely by starting the helper or opening its dashboard. A new token is generated each launch and is never stored in this ZIP.

Run sends a curated, checksum-verified BIN to an already running PS4 GoldHEN HTTP loader on 9090, or an ELF to an already running compatible PS4/PS5 TCP loader on 9021. Transfer acceptance is not proof of successful execution. This helper does not jailbreak the console, create console folders, install PKGs or extract archives.

Built-in browser runtimes are public-site features and must be opened directly on a matching console. They are not included in this loopback-only desktop helper. Other hosts stay under a separate collapsed directory and retain accurately labelled external links. Public-site navigation and externally hosted fonts/icons require Internet. Local payload transfers use the files bundled here. Firmware/game compatibility remains pinned in the catalogue.

Every mod menu uses one card and a Choose version popup with version buttons, including single-build entries. Match the separate game update, menu release and original host variant before choosing Download or Load. Selecting a build does not send anything. Unknown menu versions are not inferred from game updates. Unsupported plugin/cheat/source-host-only Load methods stay disabled with their real requirements.

Download uses the configured console receiver, or the viewing device when no console address is set. Its destination is shown beside the actions. The receiver checks its queue and chosen storage before saving; opening it submits no download. Use receiver2026.11.02.11 or newer for current exact file IDs. An invalid destination or missing file is reported without silently downloading another file or switching devices.

The optional copy-on-Load checkbox uses that same exact-file destination during the original click. It does not silently save to the computer or trigger another copy after the loader responds.

Protocol2 Check services reads the loader/manager, downloader queue and standard file-manager pages through fixed, bounded GET requests. A queue count does not verify the installed companion or storage. No generic TCP9020/9021 readiness probe is made.

If an executing request times out or loses its acknowledgement, the result is uncertain. Check the console before clearing its saved transfer warning. The dashboard locks further Load actions for that address across reloads until you explicitly clear the warning; clearing never sends or retries a payload. Other console addresses retain their own state.

Use the console-specific Payload management page for PS4 GoldHEN LaunchPad/AutoRun or PS5 Payload Manager native controls. File-manager links target the entered console address; loopback is reserved for the matching console browser.

Read docs/host-payload-sender.md, docs/host-console-services.md and docs/host-payload-management.md for detailed setup and limits. bundle-manifest.json lists included files, sizes and SHA-256 hashes; THIRD-PARTY.txt retains payload license/source attribution.
