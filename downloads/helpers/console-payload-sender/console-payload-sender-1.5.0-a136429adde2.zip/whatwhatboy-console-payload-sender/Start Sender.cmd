@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 20 or newer from https://nodejs.org/ and try again.
  pause
  exit /b 1
)
node -e "process.exit(Math.max(0,20-Number(process.versions.node.split('.')[0])))"
if errorlevel 1 (
  echo Node.js 20 or newer is required.
  pause
  exit /b 1
)
echo Open the localhost URL printed below in this computer's browser.
echo Keep this window open; press Ctrl+C to stop the sender.
node "%~dp0scripts\console-payload-bridge.cjs"
if errorlevel 1 pause
