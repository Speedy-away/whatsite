(function(){
 'use strict';
 var data=document.getElementById('host-actions-data');if(!data)return;
 var platform=JSON.parse(data.textContent).platform,base='/hosts/'+platform+'/';
 var labels={loaders:'Choose firmware',payloads:'Payloads',mods:'Game mods',tools:'Tools',connection:'Connection & setup',sender:'Desktop sender · connect from a PC'};
 var params=new URL(location.href).searchParams,selected=params.get('view')||params.get('folder')||'loaders';
 if(!Object.prototype.hasOwnProperty.call(labels,selected))selected='loaders';
 var firmwareControl=document.querySelector('.host-firmware-control');
 if(firmwareControl)document.getElementById('host-file-firmware').appendChild(firmwareControl);
 var library=document.getElementById('host-folder-library');
 library.hidden=!selected||selected==='connection'||selected==='sender';
 document.querySelectorAll('[data-host-folder-panel]').forEach(function(panel){panel.hidden=panel.getAttribute('data-host-folder-panel')!==selected;});
 if(selected){
  var button=document.querySelector('[data-host-category="'+selected+'"]');
  var title=document.getElementById('host-folder-title');
    title.textContent=selected==='loaders'?document.querySelector('#host-firmware option').textContent:button?button.textContent:labels[selected];
  document.getElementById('host-folder-path').textContent=' / '+title.textContent;
  var back=document.querySelector('.host-taskbar a');back.href=selected==='loaders'?'/hosts/':base;
  if(button)button.click();
  if(selected==='sender')document.querySelector('.host-sender').open=true;
 }
})();
