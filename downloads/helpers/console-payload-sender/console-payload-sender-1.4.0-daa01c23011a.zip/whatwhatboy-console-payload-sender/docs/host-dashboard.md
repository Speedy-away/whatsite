# PS4 / PS5 host dashboards

The local entry point is `/hosts/`: choose PS4 or PS5, select the installed firmware, configure the console address, then choose Loaders, Payloads, Game mods or Tools. The Game mods tab also filters by game. The console address is user-configured; it is not a public-IP lookup or automatic LAN discovery. Firmware detected from a console browser is shown separately.

Console-browser detection runs automatically and can be repeated with **Detect console**. It recognises PS4 and PS5 user agents, normalises their firmware version, preselects it even if it is not in the known launcher list, and identifies when the visitor opened the other console's page. On a phone or computer it leaves the console firmware as a manual choice. Browser-reported firmware is not a native hardware query, and a spoofed browser identity can hide it. No jailbreak or payload runs during detection.

**Check services** is an explicit read-only request through the paired local sender. It checks PS4 GoldHEN readiness or PS5 Payload Manager's application version and reported IP using fixed endpoints. An application version is never displayed as console firmware, and no running game/version is inferred from a process name. Changing the configured address resets the displayed service verification.

The library starts on **Game mods**, with separate Payloads, Loaders and Tools tabs and no All tab. The PS4 GTA V view puts newer game updates first and groups each menu family into one card. Every mod card, including a single-build menu, opens a **Choose version** popup. Separate buttons identify the game update, menu version, format, original host build and title IDs where supplied; there is no version dropdown. Selecting a button changes only its preview, requirements and file actions. Unknown menu versions remain **Not provided**. **Show older game builds** is initially enabled and can hide older-only choices. Firmware filtering applies before grouping.

Ready PRX/SPRX files for game updates 1.56 and 1.57 include Expulsion, Velora, Beach, Cyprus, Explosive, LTS/LRS and Serendipity. These are newer than the original host BIN choices, not a claim to support the newest GTA V retail update. Plugins use their documented native installation flow and are never sent as raw BIN or ELF payloads. Expulsion's direct PRX updates an existing support tree; a first installation also needs its support files.

`host-legacy-menu-actions.json` adds 15 original-host GTA V variants across eight older game updates. Four exact Nazky mappings use its documented GoldHEN HTTP transport; eleven retain Download plus their original host. They are pinned to PS4 firmware 9.00. `host-extra-game-actions.json` adds 34 PS4 and six native PS5 JSON trainer definitions, preserving exact game updates, title IDs and native cheat-manager setup. These data files have no raw-payload Run action. See [legacy source review](host-legacy-menu-review.json) and [other-game trainer guide](host-extra-game-trainers.md).

Expulsion V7 uses an original, labelled **Menu cover** because the previous screenshot showed V5. Explosive also uses a labelled cover rather than an unverified binary-version screenshot. Oysters and North use their source-supplied menu previews. A preview identifies the menu family; it is not evidence of successful execution for the selected bytes. [Artwork review](host-menu-art-review.json) records these boundaries.

## Actions and compatibility

- **Download** combines the old browser-download and Save controls. With a configured console address (or the matching console browser), it opens that console's installed receiver with the exact file catalogue ID. The receiver checks its queue on opening, then checks the selected destination before submitting a save. Without a console address, the file downloads to the viewing device. The destination is visible beside the actions. An invalid address or missing catalogue ID produces an error, never a silent switch to another device.
- Install the current receiver from the console download centre when new IDs are added. Confirm storage and the exact existing folder in that native page. Opening it does not automatically queue a download.
- **Load** uses the documented running console service or paired desktop sender. It never runs on page load or when selecting a build. The optional download-on-Load checkbox requests an additional browser copy after transfer acceptance.
- A PRX/SPRX plugin, cheat definition, or source-host-only BIN has a disabled **Load** action and an explanation of its native setup or missing verified loading method. A file-manager link or external redirect is never presented as successful loading. Setup files and original sources remain under Requirements.
- PS4 native BIN sends use GoldHEN's HTTP BinLoader on port 9090. Thirteen exact reviewed Nazky game-menu mappings have this transport. Fourteen other BIN variants remain download-only in the first-party action flow; byte identity between differently pinned source builds does not widen compatibility.
- **Open host** remains an accurately labelled external navigation for upstream hosts; built-in browser runtimes are identified separately.
- PS5 direct ELF requests use the official ELF loader's HTTP `?uri=` interface on port 9021. The payload URL uses the actual website origin. A desktop loopback preview cannot be fetched by the console, so it requires a LAN-reachable file host or the paired sender. HTTPS pages provide an explicit console-loader navigation link when mixed-content fetches are blocked.
- The desktop sender transfers verified local ELF bytes over TCP 9021 or verified PS4 BIN bytes through GoldHEN HTTP. See [sender setup](host-payload-sender.md).

Firmware whitelists remain exact. A launcher supporting 13.52 does not establish 13.52 support for a 9.00 game menu. Each menu retains its game update, source, checksum and requirements. The PS5 RDR2 action is a 60FPS runtime patch for the specified PS4 game build running on PS5, not a full mod menu.

The Loaders tab puts two guarded first-party runtimes before a collapsed **Other hosts** directory: PS4 PSFree/Lapse on exact firmware 9.00, and PS5 UMTX on its explicit supported versions below 5.00. Both run from this site's own `/hosts/runtime/` files after a separate Start action in the matching console browser. The PS4 bootstrap starts a raw BIN listener on TCP9020; it does not automatically load GoldHEN or provide GoldHEN's HTTP9090 interface. The PS5 runtime uses native ELF TCP9021. These are distinct protocols, and payload support is not inferred from a successful bootstrap. PS5 5.xx is excluded because upstream reports its bundled loader broken there. Sources, licenses, local dependencies and exact changes are recorded in `host-runtime-builds.json`; separate build/source archives are in `host-runtime-downloads.json`. The PS4 application-cache manifest requires a `text/cache-manifest` server mapping for offline caching. The current local preview lacks that MIME mapping, so offline persistence remains unverified. Online JavaScript modules use verified `text/javascript` responses. The loopback-only desktop helper links these runtimes to their public-site destination rather than pretending they can run in a PC browser.

**Accepted / sent reports transport only.** Confirm the effect on the console. No downloaded exploit, payload or menu was executed during implementation or verification. Network tests use mocks and temporary fixtures.

File explorers and Payload Manager links require the named native service to be running. A public website cannot access the console disk, create folders, install PKGs or bypass the manager's origin checks. See [service documentation and primary sources](host-console-services.md) and the illustrated [console file guides](guides/README.md).

## Files, payload management and layout

The desktop library uses four compact cards per row, with responsive three-, two- and one-column layouts. Menu previews and labelled game artwork remain separate from payload/project images. Requirements and attribution stay collapsed until opened. PS4's firmware selector includes 14.00 and displays the existing experimental guide and ISO page when selected; no other payload's pinned compatibility is expanded.

The dedicated [PS4 payload management page](../hosts/ps4/payload-manager/index.html) explains native GoldHEN LaunchPad/AutoRun. The [PS5 payload management page](../hosts/ps5/payload-manager/index.html) loads the pinned manager through the existing explicit transport and opens its native installed-payload, autoload, storage, sources and process screens. See the [management setup and primary sources](host-payload-management.md). Use the latest receiver from the matching console download centre for the added file IDs; older receiver snapshots and their original file IDs remain preserved. `host-menu-companion-build.json` records exact bytes, hashes and archived locations.

The target console stays explicit when browsing from a PC. Loopback addresses are accepted only inside the matching console browser, so a computer's own service cannot be mistaken for its PS4 or PS5. File-manager controls choose PS4 ezRemote on 8080, PS5 websrv on 8080 `/fs/`, or PS5 ezRemote on 9090. Each service must already be running.

`node scripts/verify-host-payloads.cjs --write` checks curated file sizes, SHA-256 values, sender validation and ELF structure without executing payloads or contacting a console. The report is `qa/host-payload-integrity.json`; it establishes file integrity, not hardware execution.

## Maintain the dashboard

Catalogue data lives in `host-actions-ps4.json`, `host-actions-ps5.json` and `host-game-actions.json` beside this document. Keep publisher source URLs, exact firmware/game compatibility, file sizes and SHA-256 values with each runnable entry. Preserve the original compressed downloads and previous variants in the local archive; expose ready files as separate immutable downloads. Follow [AGENTS.md](../AGENTS.md).

```powershell
node scripts/build-host-selector.cjs
node --test scripts/tests/host-dashboard.test.cjs scripts/tests/host-console-client.test.cjs scripts/tests/console-payload-bridge.test.cjs
node scripts/audit-site.cjs
```

Building local pages does not publish them or make new files available at the public domain. Rebuild the downloadable sender after the final dashboard, catalogue and language changes; its immutable bundle is a snapshot.
