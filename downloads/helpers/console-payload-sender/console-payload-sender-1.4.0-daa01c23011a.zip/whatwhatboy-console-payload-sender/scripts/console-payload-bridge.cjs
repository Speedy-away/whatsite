#!/usr/bin/env node
'use strict';
// Optional desktop sender. Importing this module neither listens nor sends bytes.
// Protocol sources and operation instructions: docs/host-console-services.md.
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const http = require('node:http');
const net = require('node:net');
const dns = require('node:dns/promises');
const crypto = require('node:crypto');
const {normalizeAddress} = require('../assets/host-console-client.js');
const ROOT = path.resolve(__dirname, '..');
const MAX_FILE = 64 * 1024 * 1024;
const CATALOGUES = ['docs/host-actions-ps4.json', 'docs/host-actions-ps5.json', 'docs/host-game-actions.json', 'docs/host-modern-plugin-actions.json', 'docs/host-current-cheat-actions.json', 'docs/host-legacy-menu-actions.json', 'docs/host-extra-game-actions.json'];
const MIME = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.ico':'image/x-icon','.woff2':'font/woff2','.elf':'application/octet-stream','.bin':'application/octet-stream'};
function fail(code, message) { const e = new Error(message); e.code = code; return e; }
function isPrivateIPv4(value) {
  if (net.isIP(value) !== 4) return false;
  const a = value.split('.').map(Number);
  return (a[0] === 10 || a[0] === 192 && a[1] === 168 || a[0] === 172 && a[1] >= 16 && a[1] <= 31) && a[3] !== 0 && a[3] !== 255;
}
async function resolveConsoleAddress(value, lookup = dns.lookup) {
  const name = normalizeAddress(value);
  // Loopback means the computer running this helper, not the console browser.
  if (net.isIP(name)) {
    if (!isPrivateIPv4(name)) throw fail('console-lan-address-required', 'Enter the console LAN IPv4 address. Loopback points to this computer.');
    return name;
  }
  const records = await lookup(name, {all:true, verbatim:true});
  if (!records.length || records.some(r => r.family !== 4 || !isPrivateIPv4(r.address))) throw fail('console-lan-address-required', 'The console hostname must resolve only to private LAN IPv4 addresses.');
  return records[0].address; // Connect to this checked numeric result; do not resolve a second time.
}
function loadActions(root = ROOT) {
  const actions = [], keys = new Set();
  for (const name of CATALOGUES) {
    if (!fs.existsSync(path.join(root, name))) continue;
    const data = JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
    for (const entry of data.actions || []) {
      const a = {...entry, platform: entry.platform || data.platform};
      if (!['ps4','ps5'].includes(a.platform) || !/^[a-z0-9][a-z0-9._-]{0,127}$/i.test(a.id || '')) throw fail('invalid-catalogue', 'Invalid host action identifier or platform in ' + name + '.');
      const key = a.platform + ':' + a.id;
      if (keys.has(key)) throw fail('invalid-catalogue', 'Duplicate host action: ' + key);
      keys.add(key); actions.push(a);
    }
  }
  return actions;
}
function localFileFor(action, root = ROOT, {forRun = true} = {}) {
  const url = action.downloadURL || '';
  if (!/^\/downloads\//.test(url) || /[?#\x00-\x1f\\]/.test(url)) throw fail('local-file-required', 'A locally hosted ready-to-use file is required for the sender.');
  let decoded;
  try { decoded = decodeURIComponent(url); } catch (_) { throw fail('invalid-file', 'Invalid download path.'); }
  if (decoded.split('/').some(p => p === '..' || p === '.') || /[\x00-\x1f\\]/.test(decoded)) throw fail('invalid-file', 'The download path is invalid.');
  const format = String(action.format || '').toUpperCase();
  const formats = forRun ? ['ELF','BIN'] : ['ELF','BIN','PRX','SPRX','JSON','SHN','XML','MC4'];
  if (!formats.includes(format) || path.extname(decoded).toUpperCase() !== '.' + format) throw fail('unsupported-format', 'This action does not contain a supported ready-to-use file.');
  if (!/^[a-f0-9]{64}$/i.test(action.sha256 || '')) throw fail('checksum-required', 'The curated action must include its SHA-256 checksum.');
  const run = action.run || {};
  const supported = (run.type === 'elf-tcp' || run.type === 'elf-http' && action.platform === 'ps5') && format === 'ELF' && run.port === 9021 ||
    run.type === 'goldhen-http' && action.platform === 'ps4' && format === 'BIN' && (!run.port || run.port === 9090);
  if (forRun && !supported)
    throw fail('unsupported-transport', 'No verified sender protocol is available for this action.');
  const downloadRoot = fs.realpathSync(path.join(root, 'downloads'));
  const candidate = path.resolve(root, '.' + decoded);
  const file = fs.realpathSync(candidate);
  if (!file.startsWith(downloadRoot + path.sep)) throw fail('invalid-file', 'The payload file must stay inside the download library.');
  const stat = fs.statSync(file);
  if (!stat.isFile() || stat.size <= 0 || stat.size > (forRun ? MAX_FILE : 512 * 1024 * 1024)) throw fail('invalid-file-size', 'The payload file size is invalid.');
  return {file, bytes:stat.size, format};
}
function availability(action, root) {
  try { const item = localFileFor(action, root); return {id:action.id,platform:action.platform,available:true,format:item.format,bytes:item.bytes}; }
  catch (e) { return {id:action.id,platform:action.platform,available:false,reason:e.code || 'file-unavailable'}; }
}
async function readVerifiedFile(action, root) {
  const item = localFileFor(action, root), data = await fsp.readFile(item.file);
  if (data.length !== item.bytes || data.length > MAX_FILE) throw fail('file-changed', 'The payload file changed while it was being read. Nothing was sent.');
  const digest = crypto.createHash('sha256').update(data).digest('hex');
  if (digest !== action.sha256.toLowerCase()) throw fail('checksum-mismatch', 'The payload checksum does not match the catalogue. Nothing was sent.');
  if (item.format === 'ELF' && (data.length < 64 || !data.subarray(0,4).equals(Buffer.from([0x7f,0x45,0x4c,0x46])))) throw fail('invalid-elf', 'The file does not contain an ELF executable. Nothing was sent.');
  return {data,sha256:digest};
}
// Documented netcat transport: raw ELF bytes followed by EOF on TCP 9021.
// A successful local write is a transfer result, not proof the payload executed.
function sendRawELF(address, data, {connect = net.createConnection, timeoutMs = 15000} = {}) {
  return new Promise((resolve,reject) => {
    const socket = connect({host:address,port:9021});
    let settled = false;
    const timer = setTimeout(() => done(fail('loader-timeout', 'The ELF transfer timed out. The console result is unknown.')), timeoutMs);
    function done(error) {
      if (settled) return; settled = true; clearTimeout(timer); socket.destroy();
      if (error) reject(error);
      else resolve({status:'sent',code:'elf-bytes-sent',message:'ELF bytes sent to the console loader on port 9021. Check the console for the payload result.',bytes:data.length,port:9021});
    }
    socket.once('error', () => done(fail('loader-connection-failed', 'Could not transfer the ELF. Start the compatible network ELF loader on port 9021.')));
    socket.once('connect', () => socket.end(data));
    socket.once('finish', () => done());
    socket.once('close', () => { if (!settled) done(fail('loader-disconnected', 'The loader disconnected before the transfer finished.')); });
  });
}
async function sendGoldHENHTTP(address, data, {fetcher = globalThis.fetch, timeoutMs = 15000} = {}) {
  async function send(route, method, body) {
    let response;
    try { response = await fetcher('http://' + address + ':9090' + route, {method,body,redirect:'error',signal:AbortSignal.timeout(timeoutMs)}); }
    catch (_) { throw fail('loader-connection-failed', 'Could not reach the GoldHEN HTTP loader on port 9090.'); }
    if (!response.ok) throw fail('loader-http-' + response.status, 'The GoldHEN loader returned HTTP ' + response.status + '.');
    return response;
  }
  const status = await (await send('/status','GET')).json();
  if (!status || status.status !== 'ready') throw fail('loader-busy', 'The GoldHEN HTTP loader is busy or not ready.');
  const response = await send('/','POST',data);
  if (response.status !== 200) throw fail('loader-unacknowledged', 'The loader did not acknowledge the payload.');
  return {status:'accepted',code:'goldhen-accepted',message:'GoldHEN accepted the payload bytes. Check the game or console for the result.',bytes:data.length,port:9090};
}
// Read-only discovery of two existing services, never a firmware detector or a
// generic URL proxy. Manager /version is its application version, not system FW.
async function inspectConsoleServices(address, platform, {fetcher = globalThis.fetch, timeoutMs = 4000} = {}) {
  if (!isPrivateIPv4(address)) throw fail('console-lan-address-required','Use the checked console LAN IPv4 address.');
  if (!['ps4','ps5'].includes(platform)) throw fail('invalid-platform','Choose PS4 or PS5.');
  const service = platform === 'ps4' ? 'goldhen' : 'payload-manager';
  const base = 'http://' + address + (platform === 'ps4' ? ':9090' : ':8084');
  async function read(route) {
    let response;
    try {
      // No Origin/Referer forgery, credentials, mutation request, arbitrary port
      // or redirect is used. Native GET restrictions are respected as errors.
      response = await fetcher(base + route,{method:'GET',redirect:'error',signal:AbortSignal.timeout(timeoutMs)});
    } catch (_) { throw fail('service-unavailable','The console service could not be reached or its read request was blocked.'); }
    if (!response || !response.ok) throw fail('service-http-error','The console service rejected its read-only request.');
    const limit = 2048;
    if (response.body && typeof response.body.getReader === 'function') {
      const reader = response.body.getReader(), chunks = []; let size = 0;
      try {
        while (true) {
          const item = await reader.read();
          if (item.done) break;
          size += item.value.byteLength;
          if (size > limit) { await reader.cancel(); throw fail('unexpected-response','The console service response exceeded its metadata limit.'); }
          chunks.push(Buffer.from(item.value));
        }
        return Buffer.concat(chunks).toString('utf8').trim();
      } finally { reader.releaseLock(); }
    }
    const text = String(await response.text());
    if (Buffer.byteLength(text) > limit) throw fail('unexpected-response','The console service response exceeded its metadata limit.');
    return text.trim();
  }
  const common = {address,platform,service,reportedAddress:null,version:null};
  try {
    if (platform === 'ps4') {
      let body;
      try { body = JSON.parse(await read('/status')); } catch (e) { if (e.code) throw e; throw fail('unexpected-response','The service did not return GoldHEN readiness metadata.'); }
      if (!body || !['ready','busy'].includes(body.status)) throw fail('unexpected-response','The service did not return GoldHEN readiness metadata.');
      return {...common,status:'connected',connection:body.status,code:body.status === 'ready' ? 'goldhen-ready' : 'goldhen-busy',message:body.status === 'ready' ? 'GoldHEN HTTP loader responded and is ready. Firmware and game have not been detected.' : 'GoldHEN HTTP loader responded but is busy. Firmware and game have not been detected.'};
    }
    const [version, reported] = await Promise.all([read('/version'),read('/getip')]);
    if (!/^\d+\.\d+\.\d+(?:[-+][a-z0-9.-]+)?$/i.test(version) || reported !== '0.0.0.0' && !isPrivateIPv4(reported)) throw fail('unexpected-response','The service did not return valid Payload Manager metadata.');
    return {...common,status:'connected',connection:'responding',code:'manager-connected',version,reportedAddress:reported === '0.0.0.0' ? null : reported,message:'Payload Manager ' + version + ' responded. This is the app version; firmware and game have not been detected.'};
  } catch (e) {
    const known = typeof e.code === 'string';
    return {...common,status:'unavailable',connection:'unavailable',code:known ? e.code : 'service-unavailable',message:known ? e.message : 'The console service metadata could not be read. No firmware or game was detected.'};
  }
}
function equalToken(expected, received) {
  if (typeof received !== 'string' || received.length !== expected.length) return false;
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(received));
}
function json(res, statusCode, value) {
  res.writeHead(statusCode, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});
  res.end(JSON.stringify(value));
}
function readJSON(req) {
  return new Promise((resolve,reject) => {
    let text = '', oversized = false;
    req.on('data',chunk => { if (oversized) return; if (Buffer.byteLength(text) + chunk.length > 4096) { oversized = true; reject(fail('body-too-large','The request is too large.')); } else text += chunk.toString('utf8'); });
    req.on('end',() => { if (oversized) return; try { const body = JSON.parse(text); if (!body || Array.isArray(body) || typeof body !== 'object') throw Error(); resolve(body); } catch (_) { reject(fail('invalid-json','Send a JSON action request.')); } });
    req.on('error',reject);
  });
}
function staticPath(requestURL) {
  const raw = requestURL.split('?')[0];
  let decoded;
  try { decoded = decodeURIComponent(raw); } catch (_) { return null; }
  if (!decoded.startsWith('/') || /[\x00-\x1f\\]/.test(decoded) || decoded.split('/').some(p => p === '..' || p === '.') || decoded.includes('//')) return null;
  let value = decoded;
  if (value === '/') value = '/hosts/';
  if (value.endsWith('/') && value.startsWith('/hosts/')) value += 'index.html';
  const allowed = /^\/hosts\/(?:ps[45]\/(?:payload-manager\/)?)?index\.html$/.test(value) ||
    /^\/assets\/(?:images\/.+\.(?:png|jpe?g|svg|webp)|[a-z0-9._-]+\.(?:css|js))$/i.test(value) ||
    /^\/languages\/(?:i18n|[a-z-]+)\.js$/i.test(value) ||
    /^\/(?:script\.js|style\.css)$/.test(value) ||
    /^\/docs\/host-(?:actions-ps[45]|game-actions)\.json$/.test(value);
  return allowed ? value : null;
}
function createBridge({root = ROOT, actions = loadActions(root), token = crypto.randomBytes(32).toString('hex'), resolveAddress = resolveConsoleAddress, sendELF = sendRawELF, sendBIN = sendGoldHENHTTP, inspectServices = inspectConsoleServices} = {}) {
  if (!/^[a-f0-9]{64}$/i.test(token)) throw fail('invalid-token', 'The sender token must be 32 random bytes encoded as hexadecimal.');
  root = fs.realpathSync(root);
  const busy = new Set();
  const server = http.createServer(async (req,res) => {
    const port = server.address() && server.address().port;
    const host = req.headers.host;
    if (!['127.0.0.1:' + port,'localhost:' + port].includes(host)) return json(res,403,{status:'error',code:'host-rejected',message:'Use the localhost sender address.'});
    const origin = req.headers.origin, fetchSite = req.headers['sec-fetch-site'];
    if (origin && origin !== 'http://' + host || fetchSite === 'cross-site' || fetchSite === 'same-site' && origin && origin !== 'http://' + host)
      return json(res,403,{status:'error',code:'origin-rejected',message:'Open the sender dashboard on its own localhost address.'});
    if (req.url.startsWith('/api/')) {
      if (!equalToken(token,req.headers['x-whatsite-token'])) return json(res,401,{status:'error',code:'pairing-required',message:'Enter the current sender pairing token.'});
      if (req.method === 'GET' && req.url === '/api/status') return json(res,200,{status:'connected',code:'sender-ready',version:'1.0.0',message:'Local sender connected. No console payload has been run.',actions:actions.map(a => availability(a,root))});
      if (req.method !== 'POST' || !['/api/run','/api/inspect'].includes(req.url)) return json(res,405,{status:'error',code:'method-rejected',message:'Use an explicit POST action.'});
      if (!/^application\/json(?:;|$)/i.test(req.headers['content-type'] || '')) return json(res,415,{status:'error',code:'json-required',message:'The action request must use JSON.'});
      let key, acquired = false;
      try {
        const body = await readJSON(req);
        if (req.url === '/api/inspect') {
          if (Object.keys(body).some(k => !['address','platform'].includes(k))) throw fail('unexpected-field','The service check accepts only an address and platform.');
          if (!['ps4','ps5'].includes(body.platform)) throw fail('invalid-platform','Choose PS4 or PS5.');
          const address = await resolveAddress(body.address);
          return json(res,200,await inspectServices(address,body.platform));
        }
        if (Object.keys(body).some(k => !['actionId','platform','address','firmware','gameVersion'].includes(k))) throw fail('unexpected-field','The request contains an unsupported field.');
        const action = actions.find(a => a.id === body.actionId && a.platform === body.platform);
        if (!action) throw fail('unknown-action','Choose an action from this platform host catalogue.');
        if (action.firmwares && action.firmwares.length && !action.firmwares.includes(body.firmware)) throw fail('firmware-mismatch','Select a firmware supported by this action.');
        const gameVersions = action.gameVersions && action.gameVersions.length ? action.gameVersions : action.gameVersion ? [action.gameVersion] : [];
        if (gameVersions.length && !gameVersions.includes(body.gameVersion)) throw fail('game-version-mismatch','Select the exact game update supported by this menu.');
        const address = await resolveAddress(body.address);
        key = address;
        if (busy.has(key)) throw fail('console-busy','Another payload transfer is still in progress for this console.');
        busy.add(key); acquired = true;
        const file = await readVerifiedFile(action,root);
        const outcome = action.run.type === 'elf-tcp' || action.run.type === 'elf-http' ? await sendELF(address,file.data) : await sendBIN(address,file.data);
        return json(res,200,{...outcome,actionId:action.id,platform:action.platform,address,sha256:file.sha256});
      } catch (e) { return json(res,400,{status:'error',code:e.code || 'sender-failed',message:e.code ? e.message : 'The sender could not complete the action. Nothing has been confirmed on the console.'}); }
      finally { if (acquired) busy.delete(key); }
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') return json(res,405,{status:'error',code:'read-only',message:'This path is read-only.'});
    const localDownload = actions.find(a => a.downloadURL && a.downloadURL === req.url.split('?')[0]);
    let file, extension;
    try {
      if (localDownload) { file = localFileFor(localDownload,root,{forRun:false}).file; extension = path.extname(file).toLowerCase(); }
      else {
        const pathname = staticPath(req.url);
        if (!pathname) throw Error();
        file = await fsp.realpath(path.join(root,pathname));
        if (!file.startsWith(root + path.sep)) throw Error();
        extension = path.extname(file).toLowerCase();
      }
      const stat = await fsp.stat(file);
      if (!stat.isFile()) throw Error();
      let body;
      if (extension === '.html' && file.startsWith(path.join(root,'hosts') + path.sep)) {
        let html = await fsp.readFile(file,'utf8');
        html = html.replace(/(<a\b[^>]*\bhref=")([^"#]+)(")/gi, (all, open, href, close) => {
          if (!href.startsWith('/') || href.startsWith('//')) return all;
          const pathname = href.split(/[?#]/)[0];
          if (staticPath(pathname) || actions.some(action => action.downloadURL === pathname)) return all;
          return open + 'https://whatwhatboy.com' + href + close;
        });
        const marker = '<meta name="whatwhatboy-local-sender" content="true">';
        body = Buffer.from(/<head\b[^>]*>/i.test(html) ? html.replace(/<head\b[^>]*>/i, value => value + marker) : marker + html);
      }
      res.writeHead(200,{'Content-Type':MIME[extension] || 'application/octet-stream','Content-Length':body ? body.length : stat.size,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});
      if (req.method === 'HEAD') return res.end();
      if (body) return res.end(body);
      fs.createReadStream(file).on('error',() => res.destroy()).pipe(res);
    } catch (_) { return json(res,404,{status:'error',code:'not-found',message:'This file is not served by the local sender.'}); }
  });
  server.requestTimeout = 20000;
  server.headersTimeout = 10000;
  return {server,token,actions};
}
function main(args = process.argv.slice(2)) {
  let port = 8766;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--port' && /^\d+$/.test(args[i + 1] || '')) port = Number(args[++i]);
    else throw fail('invalid-option','Usage: node scripts/console-payload-bridge.cjs [--port 8766]. The sender binds 127.0.0.1 only.');
  }
  if (port < 1 || port > 65535) throw fail('invalid-port','Choose a port between 1 and 65535.');
  const {server,token} = createBridge();
  server.once('error',e => { process.stderr.write('Sender could not start: ' + e.message + '\n'); process.exitCode = 1; });
  server.listen(port,'127.0.0.1',() => {
    process.stdout.write('Local console sender: http://127.0.0.1:' + port + '/hosts/\nPairing token (this session only): ' + token + '\nEnter the token in the local dashboard. No payload runs until you choose Run.\n');
  });
  return server;
}
if (require.main === module) { try { main(); } catch (e) { process.stderr.write(e.message + '\n'); process.exitCode = 1; } }
module.exports = {ROOT,loadActions,localFileFor,availability,readVerifiedFile,isPrivateIPv4,resolveConsoleAddress,sendRawELF,sendGoldHENHTTP,inspectConsoleServices,equalToken,staticPath,createBridge,main};
