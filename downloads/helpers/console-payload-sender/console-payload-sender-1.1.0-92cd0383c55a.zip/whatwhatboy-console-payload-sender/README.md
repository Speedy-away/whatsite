# whatwhatboy console payload sender

Extract this entire ZIP into a new folder. Keep scripts/, assets/, docs/, hosts/ and downloads/ beside this README. Do not run the ZIP in place.

1. Install Node.js 20 or newer from https://nodejs.org/. Node is not included.
2. On Windows, double-click "Start Sender.cmd". On macOS/Linux, open a terminal in this folder and run `node scripts/console-payload-bridge.cjs`.
3. Open http://127.0.0.1:8766/hosts/ on this computer. Enter the fresh pairing token printed in the terminal.
4. Choose PS4 or PS5, enter the console LAN IPv4 address, and select its exact firmware and game update. Start the compatible console loader separately, then choose Run for one compatible payload.
5. Keep the sender running while using it. Ctrl+C stops it.

The server binds only 127.0.0.1; it cannot be opened from a console browser. This computer and the console must reach each other on the same LAN. No payload runs merely by starting the helper or opening its dashboard. A new token is generated each launch and is never stored in this ZIP.

Run sends a curated, checksum-verified BIN to an already running PS4 GoldHEN HTTP loader on 9090, or an ELF to an already running compatible PS4/PS5 TCP loader on 9021. Transfer acceptance is not proof of successful execution. This helper does not jailbreak the console, create console folders, install PKGs or extract archives.

Host-launch buttons open the original external exploit site and require Internet access. Public-site navigation and externally hosted fonts/icons also need Internet. Local payload transfers use the files bundled here. Firmware/game compatibility remains pinned in the catalogue.

Read docs/host-payload-sender.md and docs/host-console-services.md for detailed setup and limits. bundle-manifest.json lists included files, sizes and SHA-256 hashes; THIRD-PARTY.txt retains payload license/source attribution.
