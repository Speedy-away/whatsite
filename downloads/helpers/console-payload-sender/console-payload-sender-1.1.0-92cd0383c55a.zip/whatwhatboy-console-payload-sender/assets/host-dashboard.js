(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.HostDashboard = api; api.install(document, root); }
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  function escape(value) { return String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function firmwareNumber(value) { var m = /^(\d+)(?:\.(\d+))?/.exec(String(value)); if (!m) return null; var minor = (m[2] || '0').slice(0, 2); if (minor.length < 2) minor += '0'; return Number(m[1]) * 100 + Number(minor); }
  function firmwareMatches(action, firmware) {
    if (!firmware || !action.firmwares || !action.firmwares.length) return true;
    var selected = firmwareNumber(firmware);
    if (selected === null) return false;
    return action.firmwares.some(function (rule) {
      var range = String(rule).match(/^(\d+(?:\.\d+)?)\s*[-–]\s*(\d+(?:\.\d+)?)/);
      if (range) return selected >= firmwareNumber(range[1]) && selected <= firmwareNumber(range[2]);
      return firmwareNumber(rule) === selected;
    });
  }
  function browserFirmware(ua, platform) {
    var pattern = platform === 'ps4' ? /PlayStation\s*4[ /]+(\d+\.\d+)/i : /PlayStation\s*5[ /]+(\d+\.\d+)/i;
    var match = pattern.exec(ua || '');
    if (!match) return '';
    var parts = match[1].split('.'); return Number(parts[0]) + '.' + (parts[1] + '0').slice(0, 2);
  }
  function detectBrowser(ua) {
    ua = String(ua || '');
    var platform = /PlayStation\s*5\b/i.test(ua) ? 'ps5' : /PlayStation\s*4\b/i.test(ua) ? 'ps4' : '';
    return {platform: platform, firmware: platform ? browserFirmware(ua, platform) : '',
      device: platform ? platform.toUpperCase() : /Android|iPhone|iPad|Mobile/i.test(ua) ? 'Phone / tablet' : 'Computer / other browser',
      source: platform ? 'Console browser' : 'No console browser detected'};
  }
  function compareGameVersions(a, b) {
    var av = String(a.gameVersion || '').split('.').map(Number), bv = String(b.gameVersion || '').split('.').map(Number);
    for (var i = 0; i < Math.max(av.length, bv.length); i++) { var diff = (bv[i] || 0) - (av[i] || 0); if (diff) return diff; }
    return String(a.label || '').localeCompare(String(b.label || ''));
  }
  function firmwareLabel(action) {
    var versions = action.firmwares || [];
    if (!versions.length) return 'See requirements';
    if (versions.length <= 3) return versions.join(', ');
    return versions[0] + ' … ' + versions[versions.length - 1] + ' (' + versions.length + ' listed versions)';
  }
  function requiresFirmware(action) { return Boolean(action.run) || action.category === 'loaders' && Boolean(action.launchURL); }
  function filterActions(actions, category, firmware, query, game, showLegacy) {
    var words = String(query || '').toLowerCase().trim().split(/\s+/).filter(Boolean);
    return actions.filter(function (action) {
      var text = [action.label, action.game, action.gameVersion, action.format, (action.requirements || []).join(' ')].join(' ').toLowerCase();
      return (showLegacy || !action.legacy) && (category === 'all' || action.category === category) && (!game || action.game === game) && firmwareMatches(action, firmware) && words.every(function (word) { return text.indexOf(word) !== -1; });
    }).sort(function (a, b) { return a.game && b.game && a.game === b.game ? compareGameVersions(a, b) : 0; });
  }
  function safeURL(value, base) {
    if (!value || !String(value).trim()) return '';
    try { var url = new URL(value, base); return /^https?:$/.test(url.protocol) && !url.username && !url.password ? url.href : ''; } catch (_) { return ''; }
  }
  function install(doc, win) {
    var chooser = doc.querySelector('#host-auto-detect');
    if (chooser) {
      var browser = detectBrowser(win.navigator.userAgent), detectedLink = doc.querySelector('#host-detected-link');
      chooser.textContent = browser.platform ? 'Detected console: ' + browser.device + (browser.firmware ? ' · Browser firmware: ' + browser.firmware : '') : 'Open this page in your console browser for automatic firmware detection.';
      if (browser.platform && detectedLink) { detectedLink.href = '/hosts/' + browser.platform + '/'; detectedLink.textContent = 'Open ' + browser.device + ' host'; detectedLink.hidden = false; }
    }
    var source = doc.querySelector('#host-actions-data'); if (!source) return;
    var catalog; try { catalog = JSON.parse(source.textContent); } catch (_) { return; }
    var actions = catalog.actions || [], platform = catalog.platform;
    var client = win.HostConsoleClient, category = 'all', bridge = null;
    var firmware = doc.querySelector('#host-firmware'), search = doc.querySelector('#host-search'), game = doc.querySelector('#host-game'), legacy = doc.querySelector('#host-show-legacy');
    var firmwareSource = doc.querySelector('#host-firmware-source'), detection = detectBrowser(win.navigator.userAgent);
    var address = doc.querySelector('#host-console-address'), status = doc.querySelector('#host-status');
    var grid = doc.querySelector('#host-action-grid'), count = doc.querySelector('#host-action-count');
    var bridgeURL = doc.querySelector('#host-bridge-url'), token = doc.querySelector('#host-bridge-token');
    var storageKey = 'whatwhatboy.host.' + platform;
    function each(nodes, callback) { Array.prototype.forEach.call(nodes, callback); }
    function refresh(node) { if (win.__scoobyI18n && win.__scoobyI18n.refresh) win.__scoobyI18n.refresh(node); }
    function tell(message, error) { status.textContent = message; status.setAttribute('data-error', error ? 'true' : 'false'); refresh(status); }
    function currentAddress() {
      if (!client) throw Error('The console connection helper is unavailable. Reload this page.');
      return client.normalizeAddress(address.value);
    }
    function remember() { try { win.localStorage.setItem(storageKey, JSON.stringify({address: address.value, firmware: firmware.value})); } catch (_) {} }
    function actionById(id) { return actions.filter(function (a) { return a.id === id; })[0]; }
    function launchURL(action) {
      var raw = action.launchURL || '';
      if (raw.indexOf('{address}') !== -1) raw = raw.replace(/\{address\}/g, currentAddress());
      return navigationURL(raw);
    }
    function navigationURL(value) {
      var url = safeURL(value, win.location.href);
      if (url && doc.querySelector('meta[name="whatwhatboy-local-sender"]')) {
        var parsed = new URL(url);
        if (parsed.origin === win.location.origin && (/^\/(?:console|guides|docs)\//.test(parsed.pathname) || /^\/downloads\//.test(parsed.pathname) && !actions.some(function (action) { return action.downloadURL === parsed.pathname; }))) return 'https://whatwhatboy.com' + parsed.pathname + parsed.search + parsed.hash;
      }
      return url;
    }
    function downloadCopy(action) {
      var url = safeURL(action.downloadURL, win.location.href); if (!url) return;
      var anchor = doc.createElement('a'); anchor.href = url; anchor.setAttribute('download', ''); anchor.hidden = true;
      doc.body.appendChild(anchor); anchor.click(); doc.body.removeChild(anchor);
    }
    function render() {
      var visible = filterActions(actions, category, firmware.value, search.value, category === 'mods' ? game.value : '', legacy.checked);
      doc.querySelector('#host-game-filter').hidden = category !== 'mods';
      count.textContent = visible.length + ' actions';
      grid.innerHTML = visible.map(function (action) {
        var download = safeURL(action.downloadURL || '', win.location.href);
        var launch = Boolean(action.launchURL);
        var canBridge = bridge && bridge.actions && bridge.actions.some(function (a) { return a.id === action.id && a.platform === platform && a.available; });
        var run = action.run && (action.run.type === 'goldhen-http' || action.run.type === 'elf-http' || action.run.type === 'ps5-manager' || canBridge);
        var needsFirmware = requiresFirmware(action) && !firmware.value;
        var plugin = /^(?:prx|sprx)$/i.test(action.format || '');
        var label = run ? 'Run' : plugin ? 'Open file manager' : launch ? action.launchLabel || 'Launch' : action.run && action.run.type === 'elf-tcp' ? 'Set up sender' : '';
        var meta = [action.gameVersion ? 'Game ' + action.gameVersion : '', action.format ? String(action.format).toUpperCase() : '', firmwareLabel(action)].filter(Boolean).join(' · ');
        var details = (action.requirements || []).map(function (text) { return '<li>' + escape(text) + '</li>'; }).join('');
        var links = [['source','Project source'],['licenseURL','Licence'],['instructionsURL','Instructions'],['sourceArchiveURL','Corresponding source']].map(function (entry) { var url = navigationURL(action[entry[0]]); return url ? '<a href="' + escape(url) + '" target="_blank" rel="noopener noreferrer">' + entry[1] + '</a>' : ''; }).filter(Boolean).join(' · ');
        return '<article class="host-action"><div class="host-action-title"><h3>' + escape(action.label) + '</h3>' + (action.game ? '<span>' + escape(action.game) + '</span>' : '') + '</div><p class="host-action-meta">' + escape(meta) + '</p>' + (action.titleIds && action.titleIds.length ? '<p class="host-action-meta">' + escape(action.titleIds.join(', ')) + '</p>' : '') + (action.supportArchiveURL ? '<p class="host-file-note">Plugin update file. First installation also needs its support files.</p>' : '') + '<div class="host-action-buttons">' +
          (label ? '<button type="button" class="host-launch" data-launch="' + escape(action.id) + '"' + (needsFirmware ? ' disabled title="Choose your installed firmware first"' : '') + '>' + escape(label) + '</button>' : '') +
          (run && launch ? '<button type="button" data-open-action="' + escape(action.id) + '">' + escape(action.launchLabel || 'Open service') + '</button>' : '') +
          (download ? '<a class="host-download" href="' + escape(download) + '" download>Download</a>' : '') + '</div>' +
          (!action.run && action.instructionsURL ? '<a class="host-setup" href="' + escape(navigationURL(action.instructionsURL)) + '" target="_blank" rel="noopener noreferrer">' + (plugin ? 'Plugin setup' : /^(?:json|shn|xml|mc4)$/i.test(action.format || '') ? 'Cheat setup' : 'Instructions') + '</a>' : '') +
          (action.supportArchiveURL ? '<a class="host-setup" href="' + escape(navigationURL(action.supportArchiveURL)) + '">Full setup files</a>' : '') +
          '<details><summary>Requirements</summary><ul>' + details + '</ul>' + (action.firmwares && action.firmwares.length ? '<p>Firmware: ' + escape(action.firmwares.join(', ')) + '</p>' : '') + (action.license ? '<p>' + escape(action.license) + '</p>' : '') + links + '</details></article>';
      }).join('');
      doc.querySelector('#host-empty').hidden = visible.length !== 0;
      refresh(grid); refresh(count);
    }
    function service(name) {
      try { var url = client.serviceURL(currentAddress(), platform === 'ps4' && name === 'files' ? 'ps4-files' : name); win.open(url, '_blank', 'noopener'); tell('Opening the installed service. Its availability has not been verified.'); }
      catch (error) { tell(error.message, true); }
    }
    function result(value) {
      tell(value.message || value.status || 'Request finished.', /error|blocked|unavailable/.test(value.status || ''));
      var url = safeURL(value.launchURL, win.location.href);
      if (url && /^(?:blocked|error)$/.test(value.status || '')) { var link = doc.createElement('a'); link.href = url; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = ' Send using console loader'; status.appendChild(link); refresh(status); }
    }
    function runAction(action) {
      var destination; try { destination = currentAddress(); } catch (error) { tell(error.message, true); return; }
      var bridgeAction = bridge && bridge.actions && bridge.actions.some(function (a) { return a.id === action.id && a.platform === platform && a.available; });
      tell('Sending the selected payload…');
      var request;
      try {
      if (bridgeAction) request = client.runViaBridge(destination, action.id, token.value, platform, {bridgeURL: bridgeURL.value, origin: win.location.origin, firmware: firmware.value, gameVersion: action.gameVersion || ''});
      else if (action.run.type === 'goldhen-http') request = client.sendGoldHEN(destination, action, {origin: win.location.origin});
      else if (action.run.type === 'elf-http') request = client.sendPS5ELF(destination, action, {origin: win.location.origin});
      else if (action.run.type === 'ps5-manager') request = client.launchInstalled(destination, action.run.path, {origin: win.location.origin});
      else { tell('Connect the local sender to run this payload. You can download it now.', true); return; }
      } catch (error) { tell(error.message, true); return; }
      Promise.resolve(request).then(function (value) {
        result(value);
        if (/^(?:sent|accepted|queued)$/.test(value.status || '') && doc.querySelector('#host-download-on-run').checked) downloadCopy(action);
      }).catch(function (error) { tell(error.message, true); });
    }
    grid.addEventListener('click', function (event) {
      var button = event.target;
      while (button && button !== grid && !button.hasAttribute('data-launch') && !button.hasAttribute('data-open-action')) button = button.parentNode;
      if (!button || button === grid) return;
      var action = actionById(button.getAttribute('data-launch') || button.getAttribute('data-open-action')); if (!action) return;
      if (button.hasAttribute('data-open-action')) { try { win.open(launchURL(action), '_blank', 'noopener'); tell('Opening the installed service. Its availability has not been verified.'); } catch (error) { tell(error.message, true); } return; }
      if (requiresFirmware(action) && !firmware.value) { tell('Choose your installed firmware first.', true); return; }
      if (!firmwareMatches(action, firmware.value)) { tell('Choose a payload matching the installed firmware.', true); return; }
      if (action.run && (action.run.type === 'goldhen-http' || action.run.type === 'elf-http' || action.run.type === 'ps5-manager' || bridge)) { runAction(action); return; }
      if (action.run && action.run.type === 'elf-tcp' && !action.launchURL) { doc.querySelector('.host-sender').open = true; tell('Start the local sender, open its host page, and connect with the pairing token to run ELF files.'); return; }
      if (/^(?:prx|sprx)$/i.test(action.format || '') && !action.run) { service('files'); return; }
      var url; try { url = launchURL(action); } catch (error) { tell(error.message, true); return; }
      if (url) { win.open(url, '_blank', 'noopener'); tell('Opening ' + action.label + '. Follow the loader status on that page.'); }
      else service('files');
    });
    function useAddress(event) {
      if (event) event.preventDefault(); try { var value = currentAddress(); address.value = value; remember(); doc.querySelector('#host-address-display').textContent = value; doc.querySelector('#host-service-status').textContent = 'Service: not verified'; tell('Console address configured. Service availability has not been checked.'); render(); refresh(doc.querySelector('.host-connection-info')); } catch (error) { tell(error.message, true); }
    }
    doc.querySelector('#host-address-form').addEventListener('submit', useAddress);
    doc.querySelector('#host-loopback').addEventListener('click', function () { address.value = '127.0.0.1'; useAddress(); });
    each(doc.querySelectorAll('[data-host-category]'), function (button) { button.addEventListener('click', function () { category = button.getAttribute('data-host-category'); each(doc.querySelectorAll('[data-host-category]'), function (item) { item.setAttribute('aria-pressed', item === button ? 'true' : 'false'); }); render(); }); });
    firmware.addEventListener('change', function () { firmwareSource.textContent = 'Firmware selection: manual'; remember(); render(); refresh(firmwareSource); }); search.addEventListener('input', render); game.addEventListener('change', render); legacy.addEventListener('change', render);
    function detectConsole(manualRequest) {
      detection = detectBrowser(win.navigator.userAgent);
      doc.querySelector('#host-detected-device').textContent = detection.device;
      doc.querySelector('#host-browser-firmware').textContent = detection.firmware ? 'Browser firmware: ' + detection.firmware : 'Browser firmware: not detected';
      var other = doc.querySelector('#host-other-console'); other.hidden = !detection.platform || detection.platform === platform;
      if (!other.hidden) { other.href = '/hosts/' + detection.platform + '/'; other.textContent = 'Open ' + detection.platform.toUpperCase() + ' host'; }
      if (detection.platform === platform && detection.firmware) {
        if (!Array.prototype.some.call(firmware.options, function (option) { return option.value === detection.firmware; })) {
          var option = doc.createElement('option'); option.value = detection.firmware; option.textContent = detection.firmware; firmware.appendChild(option);
        }
        firmware.value = detection.firmware;
        firmwareSource.textContent = 'Firmware selection: console browser';
        if (!address.value && !doc.querySelector('meta[name="whatwhatboy-local-sender"]')) address.value = '127.0.0.1';
        if (manualRequest) tell('Console browser firmware detected. Check the matching loader requirements.');
      } else if (manualRequest) tell('Open this page in the console browser to detect its firmware. On a computer or phone, select firmware manually.');
      doc.querySelector('#host-address-display').textContent = address.value || 'Not configured';
      remember(); render(); refresh(doc.querySelector('.host-connection-info'));
    }
    doc.querySelector('#host-detect').addEventListener('click', function () { detectConsole(true); });
    doc.querySelector('#host-check-services').addEventListener('click', function () {
      var target; try { target = currentAddress(); } catch (error) { tell(error.message, true); return; }
      if (!bridge || bridge.status !== 'connected') { doc.querySelector('.host-sender').open = true; tell('Connect the local sender to check console services. This does not run a payload.', true); return; }
      tell('Checking console services…');
      client.inspectConsole(target, platform, {bridgeURL:bridgeURL.value, token:token.value, origin:win.location.origin}).then(function (value) {
        result(value);
        doc.querySelector('#host-service-status').textContent = value.status === 'connected' ? 'Service: ' + value.service + (value.version ? ' ' + value.version : '') : 'Service: not verified';
        if (value.reportedAddress) doc.querySelector('#host-address-display').textContent = value.reportedAddress + ' (service-reported)';
        refresh(doc.querySelector('.host-connection-info'));
      }).catch(function (error) { tell(error.message, true); });
    });
    each(doc.querySelectorAll('[data-open-service]'), function (button) { button.addEventListener('click', function () { service(button.getAttribute('data-open-service')); }); });
    doc.querySelector('#host-connect-bridge').addEventListener('click', function () {
      if (!client) return;
      tell('Checking local sender…');
      client.inspectBridge(bridgeURL.value, token.value, {origin: win.location.origin}).then(function (value) { bridge = value.status === 'connected' ? value : null; result(value); render(); }).catch(function (error) { tell(error.message, true); });
    });
    doc.querySelector('#host-open-bridge').addEventListener('click', function () {
      var url = safeURL(bridgeURL.value, win.location.href); if (!url) { tell('Enter the local sender address.', true); return; }
      var parsed = new URL(url); parsed.pathname = '/hosts/' + platform + '/'; parsed.search = ''; parsed.hash = '';
      win.open(parsed.href, '_blank', 'noopener');
    });
    try { var saved = JSON.parse(win.localStorage.getItem(storageKey) || '{}'); address.value = saved.address || ''; firmware.value = saved.firmware || ''; } catch (_) {}
    firmwareSource.textContent = firmware.value ? 'Firmware selection: saved choice' : 'Firmware selection: not selected';
    if (doc.querySelector('meta[name="whatwhatboy-local-sender"]')) bridgeURL.value = win.location.origin;
    detectConsole(false);
  }
  return {firmwareNumber: firmwareNumber, firmwareMatches: firmwareMatches, firmwareLabel: firmwareLabel, requiresFirmware: requiresFirmware, browserFirmware: browserFirmware, detectBrowser: detectBrowser, compareGameVersions: compareGameVersions, filterActions: filterActions, safeURL: safeURL, install: install};
}));
