/* Standalone local tool package: English UI. Full website translations are supplied by the site. */
