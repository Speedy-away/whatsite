# ps4-trainer web tool

Serve this folder as the web root using a static HTTP server, then open /hosts/tools/ps4-trainer/. HTTPS or localhost is required for Web Serial. Do not open index.html through file://. No application contacts a console or serial device merely by opening. Trainer requires a compatible already-running WebRTE on PS4 HTTP771 and the exact game/title/update. All firmware-dependent services are separate. Flasher requires your own compatible ESP hardware and user-selected BINs/offsets. Original licenses and hash manifests are included.
