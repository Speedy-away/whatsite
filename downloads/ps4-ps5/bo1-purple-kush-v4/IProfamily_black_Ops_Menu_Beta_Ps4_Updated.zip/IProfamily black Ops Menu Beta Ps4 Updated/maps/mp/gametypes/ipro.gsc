#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;
#include maps\mp\gametypes\_hud_message;
#include maps\mp\gametypes\_ipros;
#include maps\mp\gametypes\_iprofamily2;
#include maps\mp\gametypes\_cloudrank1;
#include maps\mp\gametypes\_cloudme;
#include maps\mp\gametypes\so_stoned;
//#include maps\mp\gametypes\_rank;

reaper()
{
	if(!self.reaper)
	{
		self iPrintln("Press [{+frag}] To Exit Reaper");
		self SayTeam("^1REAPER INBOUND!");
		self ExitMenu();
		self.reaper=true;
		self.oldPos=self getOrigin();
		thread reaperHud();
		self.rLoc=getPosition();
		self.maxhealth=9999999;
		self.health=self.maxhealth;
		thread reaperLink();
		thread reaperWeapon();
		self playLocalSound("item_nightvision_on");
	}
}
reaperLink()
{
	thread reaperDeath();
	self.reap["veh"]=spawn("script_model",(self.rLoc[0]+(1150*cos(0)),self.rLoc[1]+(1150*sin(0)),self.rLoc[2]));
	self.reap["veh"] setModel("t5_veh_jet_u2");
	thread reaperMove();
	self linkTo(self.reap["veh"],"tag_player",(0,100,-120),(0,0,0));
	self hide();
	thread reaperExit();
	self disableWeapons();
}
reaperExit()
{
	self endon("death");
	self endon("disconnect");
	while(self.reaper)
	{
		angles=self getPlayerAngles();
		if(angles[0]<=30) self setPlayerAngles((30,angles[1],angles[2]));
		if(self fragButtonPressed())
		{
			self playLocalSound("item_nightvision_off");
			self unlink();
			self setOrigin(self.oldPos);
			for(k=0;k < self.r.size;k++) if(isDefined(self.r[k])) self.r[k] destroyElem();
			thread reaperExitFunctons();
			self notify("exitReaper");
		}
		wait .05;
	}
}
reaperDeath()
{
	self endon("exitReaper");
	self waittill("death");
	thread reaperExitFunctons();
}
reaperExitFunctons()
{
	self.maxhealth=100;
	self.health=self.maxhealth;
	self show();
	self.reap["veh"] delete();
	self.reaper=false;
	self enableWeapons();
	if(isDefined(self.reap["bullet"])) self.reap["bullet"] delete();
}
reaperMove()
{
	self endon("death");
	self endon("disconnect");
	while(self.reaper)
	{
		for(k=0;k < 360;k+=.5)
		{
			if(!self.reaper) break;
			location =(self.rLoc[0]+(1150*cos(k)),self.rLoc[1]+(1150*sin(k)),self.rLoc[2]);
			angles=vectorToAngles(location - self.reap["veh"].origin);
			self.reap["veh"] moveTo(location,.1);
			self.reap["veh"].angles =(angles[0],angles[1],angles[2]-40);
			wait .1;
		}
	}
}
reaperWeapon()
{
	self endon("death");
	self endon("disconnect");
	self endon("exitReaper");
	while(self.reaper)
	{
		if(self attackButtonPressed())
		{
			self.reap["bullet"]=spawn("script_model",self getTagOrigin("tag_weapon_left"));
			self.reap["bullet"] setModel("weapon_mp_bazooka_attach");
			self.reap["bullet"] playSound("weap_hind_missile_fire");
			for(time=0;time < 200;time++)
			{
				if(!self.reaper) break;
				vector=anglesToForward(self.reap["bullet"].angles);
				forward=self.reap["bullet"].origin+(vector[0]*45,vector[1]*45,vector[2]*49);
				collision=bulletTrace(self.reap["bullet"].origin,forward,false,self);
				self.reap["bullet"].angles =(vectorToAngles((getCursorPos()-(0,0,130))- self.reap["bullet"].origin));
				self.reap["bullet"] moveTo(forward,.05);
				playFxOnTag(level.chopper_fx["fire"]["trail"]["medium"],self.reap["bullet"],"tag_origin");
				if(collision["surfacetype"]!="default" && collision["fraction"] < 1 && level.collisions)
				{
					expPos=self.reap["bullet"].origin;
					for(k=0;k < 360;k+=80) playFx(level.chopper_fx["explode"]["large"],(expPos[0]+(150*cos(k)),expPos[1]+(150*sin(k)),expPos[2]+100));
					earthquake(3,1.6,expPos,450);
					radiusDamage(expPos,400,300,120,self,"MOD_PROJECTILE_SPLASH","artillery_mp");
					self.reap["bullet"] playSound("cobra_helicopter_hit");
					break;
				}
				wait .05;
			}
			self.reap["bullet"] delete();
			wait 2;
		}
		wait .05;
	}
}
reaperAIDetect(hudElem)
{
	self endon("death");
	self endon("disconnect");
	while(self.reaper)
	{
		target["enemyTeam"]=false;
		target["myTeam"]=false;
		for(k=0;k < level.players.size;k++)
		{
			if(isAlive(level.players[k]))
			{
				if(distance(getCursorPos(),level.players[k].origin)< 200) if((level.teamBased && self.team!=level.players[k].team)||(!level.teamBased && level.players[k]!=self)) target["enemyTeam"]=true;
				else target["myTeam"]=true;
			}
		}
		for(k=0;k < int(hudElem.size/2);
		k++)
		{
			if(target["myTeam"] && target["enemyTeam"]) hudElem[k].color =(1,(188/255),(43/255));
			else if(target["myTeam"] && !target["enemyTeam"]) hudElem[k].color =(0,.7,0);
			else if(!target["myTeam"] && target["enemyTeam"]) hudElem[k].color =(.7,0,0);
		}
		wait .05;
		for(k=0;k < hudElem.size;k++) hudElem[k].color =(1,1,1);
	}
}
reaperHud()
{
	coord=strTok("21,0,2,24;-20,0,2,24;0,-11,40,2;0,11,40,2;0,-39,2,57;0,39,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2",";");
	for(k=0;k < coord.size;k++)
	{
		tCoord=strTok(coord[k],",");
		self.r[k]=createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	thread reaperAIDetect(self.r);
}
getPosition()
{
	location =(0,0,2000);
	if(isMap("mp_bloc")) location =(1100,-5836,2500);
	else if(isMap("mp_crossfire")) location =(4566,-3162,2300);
	else if(isMap("mp_citystreets")) location =(4384,-469,2100);
	else if(isMap("mp_creek")) location =(-1595,6528,2500);
	else if(isMap("mp_bog")) location =(3767,1332,2300);
	else if(isMap("mp_overgrown")) location =(267,-2799,2600);
	else location =(0,0,2300);
	return location;
}
isMap(map)
{
	if(map==getDvar("mapname")) return true;
	return false;
}
CarePackage()
{
	self iPrintln("^2Press [{+Frag}] to throw marker");
	self giveWeapon("frag_grenade_mp");
	self setWeaponAmmoStock("frag_grenade_mp", 1);
	self thread CarePackageFunc();
}
CarePackageFunc()
{
	self waittill("grenade_fire", grenadeWeapon);
	if (!isDefined(grenadeWeapon)) return;
	self thread GrenadeOriginFollow2(grenadeWeapon);
	grenadeWeapon waittill("explode", grenadePosition);
	if (!isDefined(grenadePosition)) grenadePosition = self.origin;
	self sayTeam("^1Care Package Inbound!");
	self.c = [];
	self.c["Chopper"] = spawn("script_model", (3637, 10373, 750));
	self.c["Chopper"] setModel("t5_veh_helo_hind_killstreak");
	self.c["Chopper"].angles = self.angles;
	self.c["Box"] = spawn("script_model", (3637, 10373, 750));
	self.c["Box"] setModel(level.crateModelFriendly);
	dropTarget = grenadePosition + (-30, 40, 750);
	groundTarget = grenadePosition + (-30, 40, 0);
	self.c["Chopper"] moveTo(dropTarget, 13.5);
	self.c["Box"] moveTo(dropTarget, 13.5);
	wait 13.5;
	self.c["Box"] moveTo(groundTarget, 4);
	wait 4;
	self.c["Chopper"] moveTo((3637, 10373, 750), 10);
	self.c["Chopper"] thread DeleteCareChopper();
	level.Point = newHudElem();
	level.Point.x = self.c["Box"].origin[0];
	level.Point.y = self.c["Box"].origin[1];
	level.Point.z = self.c["Box"].origin[2] + 15;
	level.Point setShader("waypoint_bombsquad", 14, 14);
	level.Point setWaypoint(true, false);
	self thread CareTrigger();
	self.c["Box"] thread DeleteBoxOvertime(self);
}
CareTrigger()
{
	self endon("CarePackOver");
	self.CareGot = false;
	self.killSreaks = [];
	self.killSreaks[0] = "radardirection_mp";
	self.killSreaks[1] = "autoturret_mp";
	self.killSreaks[2] = "supply_drop_mp";
	self.killSreaks[3] = "airstrike_mp";
	self.killSreaks[4] = "dogs_mp";
	self.killSreaks[5] = "radar_mp";
	self.killSreaks[6] = "rcbomb_mp";
	self.killSreaks[7] = "helicopter_comlink_mp";
	self.killSreaks[8] = "helicopter_player_firstperson_mp";
	self.killSreaks[9] = "helicopter_gunner_mp";
	self.killSreaks[10] = "mortar_mp";
	for (;;)
	{
		if (isDefined(self.c["Box"]) && distance(self.origin, self.c["Box"].origin) < 35)
		{
			self.H9nt = "Press & Hold [{+activate}] For CarePackage";
			if (self useButtonPressed())
			{
				self freezeControls(true);
				self thread CreateBoxBar("CENTER", "CENTER", 0, 120, 100, 4, (1, 1, 1), 1.5);
				wait 1.5;
				self.PickedKillSteak = randomInt(self.killSreaks.size);
				if (isDefined(level.hardpoints[self.killSreaks[self.PickedKillSteak]]))
                {
                self maps\mp\gametypes\_hardpoints::giveKillstreak(self.killSreaks[self.PickedKillSteak], 0);
                }
                else
                {
                self giveMaxAmmo(self.primaryWeapon);
                }
				if (isDefined(self.c["Box"])) self.c["Box"] delete();
				if (isDefined(self.Progress["Bar"])) self.Progress["Bar"] destroyElem();
				if (isDefined(level.Point)) level.Point destroy();
				self.CareGot = true;
				if (isDefined(self.c["Chopper"])) self.c["Chopper"] delete();
				self freezeControls(false);
				self notify("CarePackOver");
				break;
			}
		}
		wait 0.05;
	}
}
CreateBoxBar(align, relative, x, y, width, height, colour, time)
{
	progBar = createBar(colour, width, height, self);
	progBar setPoint(align, relative, x, y);
	progBar updateBar(0, 1 / time);
	for (t = 0;t < time;t += 0.05) wait 0.05;
	progBar destroyElem();
}
DeleteBoxOvertime(player)
{
	player endon("CarePackOver");
	for (;;)
	{
		wait 50;
		if (isDefined(self) && !player.CareGot)
		{
			self delete();
			if (isDefined(player.Progress["Bar"])) player.Progress["Bar"] destroyElem();
			if (isDefined(level.Point)) level.Point destroy();
			player notify("CarePackOver");
			player freezeControls(false);
		}
	}
}
DeleteCareChopper()
{
	wait 10;
	if (isDefined(self)) self delete();
}

CareSpeed(speed,origin,moveto)
{
	dist=distance(origin,moveto);
	time =(dist / speed);
	return time;
}
GrenadeOriginFollow2(Gren)
{
	Gren endon("explode");
	for(;;)
	{
		self.Grenade=Gren.origin;
		wait .01;
	}
}
hintTxt()
{
	self endon("disconnect");
	self endon("death");
	self.hint="";
	hintText=createTextString("default",1.4,"","",0,100,1,100,self.hint);
	for(;;)
	{
		hintText maps\mp\gametypes\_rank::setSafeText(self.hint);
		self.hint="";
		wait .1;
	}
}
Orgasm()
{
	self endon("gameStart");
	for(i=0;i<10;i++)
	{
		doSounds("mpl_hit_alert"); // player_pain_small <<< Cod5
		self iPrintlnBold("^2+1 UP");
		wait 1;
	}
}
RedFog()
{
	SetExpFog(256,512,1,0,0,0);
	for(k=0;k < level.players.size;k++)level.players[k] setClientDvar("r_fog","1");
}
PinkFog()
{
	SetExpFog(256,512,1,0.41,0.71,0);
	for(k=0;k < level.players.size;k++)level.players[k] setClientDvar("r_fog","1");
}
BlueFog()
{
	SetExpFog(256,512,0,0,1,0);
	for(k=0;k < level.players.size;k++)level.players[k] setClientDvar("r_fog","1");
}
CyanFog()
{
	SetExpFog(256,512,0,1,1,0);
	for(k=0;k < level.players.size;k++)level.players[k] setClientDvar("r_fog","1");
}
GreenFog()
{
	SetExpFog(256,512,0,1,0,0);
	for(k=0;k < level.players.size;k++)level.players[k] setClientDvar("r_fog","1");
}
OrangeFog()
{
	SetExpFog(256,512,1,0.5,0,0);
	for(k=0;k < level.players.size;k++)level.players[k] setClientDvar("r_fog","1");
}
YellowFog()
{
	SetExpFog(256,512,1,1,0,0);
	for(k=0;k < level.players.size;k++)level.players[k] setClientDvar("r_fog","1");
}
PurpleFog()
{
	SetExpFog(256,512,1,0,1,0);
	for(k=0;k < level.players.size;k++)level.players[k] setClientDvar("r_fog","1");
}
ResetFog()
{
	setExpFog(9000,9001,229/255,165/255,0/255,3);
	for(k=0;k < level.players.size;k++)level.players[k] setClientDvar("r_fog","0");
}
doSounds(s)
{
	self playLocalSound(s);
}
toggleDiscofog()
{
	if(!level.zombieRise)
	{
		if(!level.discoFog)
		{
			level.discoFog=true;
			thread discoModefog();
			self iPrintln("Disco Fog [^2ON^7]");
		}
		else level.discoFog=false;
	}
	else self iPrintln("Please Turn ^1Off ^7Zombie Rise..");
}
discoModefog()
{
	self endon("gameStart");
	for(k=0;k < level.players.size;k++)level.players[k] setClientDvar("r_fog","1");
	while(level.discoFog)
	{
		setExpFog(256,512,randomInt(255)/255,randomInt(255)/255,randomInt(255)/255,0);
		wait .1;
	}
	self iPrintln("Disco Fog [^1OFF^7]");
	for(k=0;k < level.players.size;k++)level.players[k] setClientDvar("r_fog","0");
	setExpFog(800,20000,.580,.631560,.553070,0);
}
zombieRise()
{
	if(!level.discoFog)
	{
		if(!level.zombieRise)
		{
			setExpFog(170,170,.5,.5,.5,.5);
			for(k=0;k < level.players.size;k++) level.players[k] setClientDvars("r_fog","1","r_filmusetweaks","1","r_filmtweakenable","1","r_filmtweakdarktint","1.4 .8 .8","r_filmtweaklighttint","1.2 .6 .6","r_filmtweakcontrast","1.3","r_colorMap","1");
			level.zombieRise=true;
			thread zombieRiseFog();
		}
		else
		{
			setExpFog(800,20000,.580,.631560,.553070,0);
			for(k=0;k < level.players.size;k++) level.players[k] setClientDvars("r_fog","0","r_colormap","1","r_fullbright","0","r_specularmap","0","r_debugShader","0","r_filmTweakEnable","0","r_filmUseTweaks","0","r_filmTweakInvert","0","r_filmtweakLighttint","1.1 1.05 .85","r_filmtweakdarktint",".7 0.85 1");
			level.zombieRise=false;
		}
	}
	else self iPrintln("Please Turn ^1Off ^7Disco Mode..");
}
zombieRiseFog()
{
	self endon("gameStart");
	fogTemp=strTok("200,200;700,700;200,200;80,80",";");
	fogTime=strTok("30;20;30;10",";");
	while(level.zombieRise)
	{
		for(k=0;k < fogTemp.size;k++)
		{
			fogArray=strTok(fogTemp[k],",");
			setExpFog(int(fogArray[0]),int(fogArray[1]),.5,.5,.5,(int(fogTime[k])-9));
			for(k=0;k <(int(fogTime[k])*20);
			k++)
			{
				if(!level.zombieRise) break;
				wait .05;
			}
		}
	}
	self iPrintln("Zombie Rise Fog [^1OFF^7]");
}
createBase()
{
    if(!level.spawningObject)
    {
        if(!level.skyBaseSpawn)
        {
            thread deleteAllModels1();
            level.spawningObject = true;
            level.skyBaseSpawn = true;
            
            // Firing Range Example
            if(isMap("mp_firingrange"))
            {
                level.skyBase["origin"] = (1000.0, 1000.0, 1500.0); // Adjust coordinates for BO1
                pos = level.skyBase["origin"];
                level.box["top_Icon"] = "rank_prestige15"; // BO1 prestige icons go up to 15
                thread skyBaseLights();
                thread telePort((500.0, 500.0, 0.0), ((pos[0]+186), (pos[1]-21), (pos[2]+30)), true);
                thread telePort(((pos[0]+186), (pos[1]-21), (pos[2]+19)), (500.0, 500.0, 0.0), false);
            }
            
            // Summit Example
            if(isMap("mp_summit"))
            {
                level.skyBase["origin"] = (2000.0, 3000.0, 2000.0); // Adjust coordinates for BO1
                pos = level.skyBase["origin"];
                level.box["top_Icon"] = "rank_prestige15";
                thread skyBaseLights();
                thread telePort((1500.0, 1500.0, 200.0), ((pos[0]+186), (pos[1]-21), (pos[2]+30)), true);
                thread telePort(((pos[0]+186), (pos[1]-21), (pos[2]+19)), (1500.0, 1500.0, 200.0), false);
            }
            
            // Nuketown Example
            if(isMap("mp_nuked"))
            {
                level.skyBase["origin"] = (0.0, 0.0, 1200.0); // Adjust coordinates for BO1
                pos = level.skyBase["origin"];
                level.box["top_Icon"] = "rank_prestige15";
                thread skyBaseLights();
                thread telePort((100.0, 200.0, 0.0), ((pos[0]+186), (pos[1]-21), (pos[2]+30)), true);
                thread telePort(((pos[0]+186), (pos[1]-21), (pos[2]+19)), (100.0, 200.0, 0.0), false);
            }
            
            // Unsupported BO1 Maps Exclusion List
            if(isMap("mp_array") || isMap("mp_cracked") || isMap("mp_crisis") || isMap("mp_grid") || isMap("mp_hanoi") || isMap("mp_jungle") || isMap("mp_launch") || isMap("mp_radiation") || isMap("mp_villa") || isMap("mp_wmd"))
            {
                self iPrintln("^1Sorry You Cant Spawn It On This Map");
            }
            else
            {
                s = [];
                s[0] = ::window;
                s[1] = ::constructBase;
                s[2] = ::mystery_box;
                for(k = 0; k < s.size; k++) 
                {
                    thread [[s[k]]]();
                }
                self iPrintln("SkyBase Spawned");
                level.spawningObject = false;
            }
        }
        else
        {
            self iPrintln("skyBase Deleted");
            for(k = 0; k < level.modelEnt.size; k++) 
            {
                if(isDefined(level.modelEnt[k]))
                {
                    level.modelEnt[k] delete();
                }
            }
            for(k = 0; k < level.players.size; k++)
            {
                level.players[k] allowJump(true);
                level.players[k].randumWeapon = false;
            }
            level.sbOpen = false;
            level.skyBaseSpawn = false;
            if(isDefined(level.objective))
            {
                objective_Delete(level.objective);
            }
        }
    }
    else 
    {
        self iPrintln("");
    }
}
deleteAllModels1()
{
	objective_Delete(level.objective);
	if(isDefined(level.modelEnt))for(k=0;k < level.modelEnt.size;k++)level.modelEnt[k] delete();
	if(level.merryGoRound)
	{
		for(k=0;k < level.players.size;k++)
		{
			level.players[k] unlink();
			level.players[k].Occ=false;
		}
		level.merryGoRound=false;
	}
	if(level.skyBaseSpawn)
	{
		for(k=0;k < level.players.size;k++)
		{
			level.players[k] allowJump(true);
			level.players[k].randumWeapon=false;
		}
		level.sbOpen=false;
		level.skyBaseSpawn=false;
	}
	if(level.artilleryGunSpawn)
	{
		level notify("cannon_delete");
		level.controlPannel delete();
		level.spin delete();
		level.tilt delete();
		for(k=0;k < 2;k++)level.artilleryShoot[k] delete();
		level.isUseingGun=false;
		level.artilleryGunSpawn=false;
		for(k=0;k < level.players.size;k++)if(level.players[k].useingCannon)level.players[k] thread exitCannonFunctions(level.players[k].artillery);
	}
}
constructBase()
{
for(z=0;z < 2;z++)for(x=0;x < 8;x++)for(y=0;y < 8;y++)skyBase=spawnModel(level.skyBase["origin"],"mp_supplydrop_ally",(x*30),(y*-50),(z*125),(0,90,0),false);
for(k=0;k < 5;k++)for(r=0;r < 5;r++)skyBase=spawnModel(level.skyBase["origin"],"mp_supplydrop_ally",(r*50),(28),((k*26)+10),(0,0,0),true,55);
wait .05;
for(k=0;k < 5;k++)for(r=0;r < 5;r++)skyBase=spawnModel(level.skyBase["origin"],"mp_supplydrop_ally",(r*50),(-377),((k*26)+10),(0,0,0),true,55);
for(k=0;k < 5;k++)for(r=0;r < 8;r++)skyBase=spawnModel(level.skyBase["origin"],"mp_supplydrop_ally",(235),((r*-50)-5),((k*26)+10),(0,90,0),true,55);
wait .05;
for(k=0;k < 2;k++)for(r=0;r < 8;r++)skyBase=spawnModel(level.skyBase["origin"],"mp_supplydrop_ally",(-29),((r*-50)-10),((k*26)+10),(0,90,0),true,55);
for(k=0;k < 8;k++)skyBase=spawnModel(level.skyBase["origin"],"mp_supplydrop_ally",(-29),((k*-50)+10),(110),(0,90,0),true,55);
}
skyBaseLights()
{
	for(k = 0;k < 4;k++)
	{
		skyBase = spawnModel(level.skyBase["origin"], "p_glo_light_fluorescent", ((k * 63) + 11), (15), (110), (0, 0, 0), false);
	}
	wait 0.05;
	for(k = 0;k < 6;k++)
	{
		skyBase = spawnModel(level.skyBase["origin"], "p_glo_light_fluorescent", (225), ((k * 63) - 336), (110), (0, -90, 0), false);
	}
	wait 0.05;
	for(k = 0;k < 4;k++)
	{
		skyBase = spawnModel(level.skyBase["origin"], "p_glo_light_fluorescent", ((k * 63) + 11), (-365), (110), (0, 180, 0), false);
	}
}

window()
{
    window = [];
    for(k = 0; k < 2; k++)
    {
        for(r = 0; r < 9; r++)
        {
            window[window.size] = spawnModel(level.skyBase["origin"], "com_plastic_case", (-29), ((r * -45) + 10), ((k * 25) + 11), (0, 90, 0), false);
        }
    }
    thread windowTrigger(window);
}
spawnModel(origin,model,xPos,yPos,zPos,angle,argument,solid)
{
	ent=spawn("script_model",(origin[0]+xPos,origin[1]+yPos,origin[2]+zPos));
	ent setModel(model);
	ent.angles=angle;
	destroyArray1(ent);
	if(isSubStr(argument,true))
	{
		entSolid=spawn("trigger_radius",(origin[0]+xPos,origin[1]+yPos,origin[2]+zPos),0,solid,solid);
		entSolid setContents(1);
		entSolid.targetname="script_collision";
		destroyArray1(entSolid);
	}
	return ent;
}
destroyArray1(ent)
{
	if(!isDefined(level.modelEnt))level.modelEnt=[];
	level.modelEnt[level.modelEnt.size]=ent;
}
windowTrigger(ent)
{
controlPanel=spawnModel(level.skyBase["origin"],"aircraft_bomb",(20),(-350),(65),(0,90,0),false);
controlStand=spawnModel(level.skyBase["origin"],"mp_supplydrop_ally",(20),(-370),(37),(-90,180,90),true,50);
	while(level.skyBaseSpawn)
	{
		for(k=0;k < get_players().size;
		k++)
		{
			player=get_players()[k];
			if(distance(player.origin,(level.skyBase["origin"][0]+20,level.skyBase["origin"][1]-360,level.skyBase["origin"][2]+15))< 40)
			{
				player.hint="Press [{+activate}] To Open/Close Window";
				if(player useButtonPressed())
				{
					if(!level.sbOpen)
					{
						level.sbOpen=true;
						for(k=0;k < ent.size;k++)ent[k] moveTo(ent[k].origin+(0,0,50),1.5);
						ent[ent.size-1] waittill("movedone");
					}
					else
					{
						level.sbOpen=false;
						for(k=0;k < ent.size;k++)ent[k] moveTo(ent[k].origin-(0,0,50),1.5);
						ent[ent.size-1] waittill("movedone");
					}
				}
			}
		}
		wait .05;
	}
}
mystery_box()
{
    if(getDvar("mapname") == "mp_firingrange")
    {
        level.weaponBox = spawnModel(level.skyBase["origin"], "com_crate_metal", (200), (-255), (24), (0, -90, 0), true, 50);
        level.weaponIcon = spawnModel(level.skyBase["origin"], level.box["top_Icon"], (215), (-255), (74), (0, -90, 0), false);
    }
    else
    {
        level.weaponBox = spawnModel(level.skyBase["origin"], "com_plastic_case", (200), (-255), (24), (0, -90, 0), true, 50);
        level.weaponIcon = spawnModel(level.skyBase["origin"], level.box["top_Icon"], (215), (-255), (74), (0, -90, 0), false);
    }
    
    wait 2;
    
    while(level.skyBaseSpawn)
    {
        for(k = 0; k < level.players.size; k++)
        {
            guy = level.players[k];
            if(distance(guy.origin, level.weaponBox.origin) < 50)
            {
                guy.hint = "Press [{+activate}] To Use Random Box";
                if(guy useButtonPressed() && !guy gotAllWeapons())
                {
                    level.boxUser = guy;
                    break;
                }
            }
        }
        if(isDefined(level.boxUser)) break;
        wait 0.05;
    }
    
    user = level.boxUser;
    gun = user treasure_chest_weapon_spawn(level.weaponBox.origin);
    thread boxTimeout(user, gun);
    
    while(level.skyBaseSpawn)
    {
        if(distance(user.origin, level.weaponBox.origin) < 50)
        {
            user.hint = "Press [{+activate}] To Take Weapon";
            if(user useButtonPressed())
            {
                user giveWeapon(gun.weap, 0, false);
                user switchToWeapon(gun.weap, 0, false);
                user giveMaxAmmo(gun.weap, 0, false);
                user playSound("oldschool_pickup");
                user notify("weapon_collected");
                break;
            }
        }
        if(isDefined(user.timedOut)) break;
        wait 0.05;
    }
    
    if(isDefined(gun)) gun delete();
    if(isDefined(level.weaponBox)) level.weaponBox delete();
    if(isDefined(level.weaponIcon)) level.weaponIcon delete();
    
    level.boxUser = undefined;
    
    if(level.skyBaseSpawn) 
    {
        level thread mystery_box();
    }
}
boxTimeout(guy,gun)
{
	guy endon("weapon_collected");
	gun moveTo(gun.origin-(0,0,30),12,(12*.5));
	wait 12;
	guy.timedOut=true;
	wait 0.2;
	guy.timedOut=undefined;
}
treasure_chest_weapon_spawn(loc)
{
	gun=spawn("script_model",loc+(0,0,25));
	gun setModel("");
	gun.angles=level.weaponBox.angles;
	gun moveTo(gun.origin+(0,0,30),3,1.5,1.4);
	weaponArray=[];
	for(k=0;k < level.weaponlist.size;k++)
	{
		if(!self hasWeapon(level.weaponlist[k])) weaponArray[weaponArray.size]=level.weaponlist[k];
	}
	randy=0;
	for(k=0;k < 40;k++)
	{
		if(k < 20)wait .05;
		else if(k < 30)wait .1;
		else if(k < 35)wait .2;
		else if(k < 38)wait .3;
		randy=weaponArray[randomInt(weaponArray.size)];
		gun setModel(getWeaponModel(randy));
		gun.weap=randy;
	}
	return gun;
}
gotAllWeapons()
{
	for(k=0;k < level.weaponlist.size;k++) if(!self hasWeapon(level.weaponlist[k])) return false;
	return true;
}

TogRM()
{
	if(self.RM==false)
	{
		self iPrintln("Raining Model [^2On^7]");
		self thread RainModel("test_sphere_silver");
		self.RM=true;
	}
	else
	{
		self iPrintln("Raining Model [^1Off^7]");
		self notify("Stop_RM");
		self.RM=false;
	}
}
RainModel(model)
{
	self endon("Stop_RM");
	self endon("gameStart");
	lr=maps\mp\gametypes\_spawnlogic::findBoxCenter(level.spawnMins,level.spawnMaxs);
	lc=getAboveBuildingslocation(lr);
	for(;;)
	{
		Z=2000;
		X=randomintrange(-3000,3000);
		Y=randomintrange(-3000,3000);
		l= lr+(x,y,z);
		bomb=spawn("script_model",l);
		bomb setModel(model);
		bomb.angles=bomb.angles+(90,90,90);
		bomb moveto(bomb.origin-(0,0,2012),5,0);
		bomb thread deleteAfterTime(10);
		wait .2;
	}
}

deleteAfterTime(time)
{
	wait time;
	self delete();
}

getAboveBuildingsLocation( startOrigin, heightOverride )
{
	if( !isDefined( heightOverride ) )
	{
		heightOverride = 1500;
	}
	targetAirPoint = startOrigin + ( 0, 0, heightOverride );
	trace = bulletTrace( startOrigin, targetAirPoint, false, undefined );
	if( trace["fraction"] < 1.0 )
	{
		return trace["position"] - ( 0, 0, 50 );
	}
	return targetAirPoint;
}

doDeathMachines()
{
	for(k=0;k < level.players.size;k++)
	{
		level.players[k] ExitMenu();
		wait .6;
		level.players[k] suicide();
		level.players[k] thread resetPlayerDvars();
		level.players[k] thread initMachinesMonitor();
		level.players[k] iPrintlnBold("Death Machines\nMade by x2EzYx--\nPreper For Some Spraying!");
	}
	wait 1;
}
initMachines()
{
	self takeallweapons();
	self giveweapon("minigun_mp");
	self switchtoweapon("minigun_mp");
}
initMachinesMonitor()
{
	self endon("disconnect");
	for(;;)
	{
		self waittill("spawned_player");
		self thread initMachines();
		wait 2;
	}
}
startIntelHunter()
{
	thread deleteAllModels();
	for(k=0;k < level.players.size;k++)
	{
		level.players[k] ExitMenu();
		wait .6;
		level.players[k] suicide();
		level.players[k] thread resetPlayerDvars();
		level.players[k] thread doIntelHunter();
		level.players[k] iPrintlnBold("Intel Hunter\nMade by IELIITEMODZX\nKill Players And Gain Intel To Win The Match");
	}
	wait 1;
}
doIntelHunter()
{
	self clearPerks();
	thread hidePerksAfterTime(.05);
	thread hidePerksOnDeath();
	self.score=0;
	thread initPerkStreaks();
	thread maps\mp\gametypes\_hostmigration::pauseTimer();
	thread initIntelHunterScore();
	thread uploadIntel();
	thread initIntelHunter();
	thread intelHunterHuds();
	thread runPerkStreaks();
}
hidePerksAfterTime( delay )
{
    self endon("disconnect");
    wait delay;
    
    if( isDefined( self.perk_icon ) )
    {
        self.perk_icon fadeOverTime( 2.0 );
        self.perk_icon.alpha = 0;
    }
}
hidePerksOnDeath()
{
    self endon("disconnect");
    self endon("perks_hidden");
    
    self waittill("death");
    
    self openMenu( "perk_hide" ); 
    self notify("perks_hidden");
}
initIntelHunter()
{
	self.hunter["icon"]="hud_suitcase_bomb";
	self.maxIntel=25;
	self.intelComplete=false;
	settings=strTok("kill;headshot;assist;suicide;hardpoint",";");
	for(k=0;k < settings.size;k++) level thread maps\mp\gametypes\_rank::registerScoreInfo(settings[k],0);
	self setClientDvars("player_sustainAmmo","0","r_colormap","1","r_fullbright","0","r_specularmap","1","r_debugShader","0","r_filmTweakEnable","0","r_filmUseTweaks","0","cg_gun_x","0","FOV","30","r_filmTweakInvert","0");
	self setClientDvars("r_filmtweakLighttint","1.1 1.05 .85","r_filmtweakdarktint",".7 .85 1","jump_height","90","g_gravity","720","g_speed","190","bg_fallDamageMaxHeight","455","bg_fallDamageMinHeight","255");
	self.intelPoints=0;
	thread runIntelHunter();
}
initPerkStreaks()
{
	level.perkStreak=[];
	level.perkStreak[0]="specialty_fastreload";
	level.perkStreak[1]="specialty_bulletaccuracy";
	level.perkStreak[2]="specialty_rof";
	level.perkStreak[3]="specialty_bulletpenetration";
	level.perkStreak[4]="specialty_bulletdamage";
	level.perkStreak[5]="specialty_holdbreath";
	level.perkStreak[6]="specialty_grenadepulldeath";
	level.perkStreak[7]="specialty_armorvest";
}
runPerkStreaks()
{
	self.perkUpdate=false;
	self.perkSet=[];
	for(k=0;k < level.perkStreak.size;k++)
	{
		if((self.intelPoints >=((k*3)+2))|| self.intelComplete)
		{
			self.perkSet[k]=level.perkStreak[k];
			self setPerk(level.perkStreak[k]);
		}
	}
	wait .1;
	self.perkUpdate=true;
}
uploadIntel()
{
	level endon("game_ended");
	level.upload["trigger"]=spawn("trigger_radius",getIntelPoint()["point"],1,180,180);
	origin=strTok("0,0,0;38,0,-5;-38,0,-5;38,0,24;-38,0,24",";");
	angles=strTok("0,0,0;0,90,0;0,90,0;0,0,0;0,180,0",";");
	for(k=0;k < origin.size;k++)
	{
		model="war_hq_obj";
		if(k>=1) model="test_sphere_silver";
		if(k>=3) model="aircraft_bomb";
		tOrigin=strTok(origin[k],",");
		level.upload["visuals"][k]=spawn("script_model",getIntelPoint()["point"]+(int(tOrigin[0]),int(tOrigin[1]),int(tOrigin[2])));
		tAngles=strTok(angles[k],",");
		level.upload["visuals"][k].angles =(int(tAngles[0]),int(tAngles[1]),int(tAngles[2]));
		level.upload["visuals"][k] setModel(model);
		level.upload["visuals"][k] linkTo(level.upload["visuals"][0]);
	}
	level.upload["trigger"] linkTo(level.upload["visuals"][0]);
	level.upload["visuals"][0].angles=getIntelPoint()["angle"];
	for(k=0;k < 11;k++)
	{
		level.upload["tRadius"][k]=spawn("trigger_radius",level.upload["visuals"][0].origin+(0,0,((k*55)-40)),1,120,120);
		level.upload["tRadius"][k] setContents(1);
	}
	level.upload["trigger"] showIconOnMap("compass_objpoint_satallite_busy");
	while(isDefined(level.upload["trigger"]))
	{
		level.upload["trigger"] waittill("trigger",player);
		if(player.intelComplete && isDefined(player.intelComplete)&& !level.intelUploaded)
		{
			if(player.intelPoints > 0)
			{
				player playLocalSound("mouse_over");
				player.intelPoints -=.2;
			}
			else player thread intelUploaded();
		}
		wait .05;
	}
}
runIntelHunter()
{
	level endon("game_ended");
	self.visuals=[];
	for(;;)
	{
		self waittill("death");
		next=self.visuals.size;
		self.visuals[next]=spawn("script_model",self getOrigin());
		self.visuals[next] setModel("aircraft_bomb");
		self.trigers[next]=spawn("trigger_radius",self getOrigin(),1,32,32);
		self.trigers[next] thread triggerIntel(self.visuals[next],self);
		self.visuals[next] thread bounceIntelHunter(self.trigers[next]);
		self.visuals[next] thread destroyVisuals(self.trigers[next]);
	}
}
intelUploaded()
{
	level.intelUploaded=true;
	level.upload["trigger"] delete();
	level.upload["visuals"][0] thread maps\mp\gametypes\_globallogic_utils::playTickingSound();
	wait 5;
	level.upload["visuals"][0] setModel("com_bomb_objective_d");
	for(k=1;k < level.upload["visuals"].size;k++) level.upload["visuals"][k] delete();
	explosionOrigin=level.upload["visuals"][0].origin;
	for(k=0;k < level.players.size;k++) if(distance(level.players[k].origin,explosionOrigin)< 412 && level.players[k]!=self) radiusDamage(level.players[k].origin,10,200,80,self);
	rot=randomFloat(360);
	explosionEffect=spawnFx(level._effect["bombexplosion"],explosionOrigin+(0,0,10),(0,0,1),(cos(rot),sin(rot),0));
	triggerFx(explosionEffect);
	thread playSoundInSpace("exp_suitcase_bomb_main",explosionOrigin);
	level.upload["visuals"][0] maps\mp\gametypes\_globallogic_utils::stopTickingSound();
	wait 4;
	level thread maps\mp\gametypes\_globallogic::endGame(self.team,self.name+" Uploaded All His Intel!");
}
bounceIntelHunter(entity)
{
	entity endon("trigger_used");
	level endon("game_ended");
	bottomPos=self.origin+(0,0,25);
	topPos=self.origin+(0,0,45);
	while(isDefined(self))
	{
		self moveTo(topPos,.7,.2,.2);
		self rotateYaw(180,.7);
		wait(.7);
		self moveTo(bottomPos,.7,.2,.2);
		self rotateYaw(180,.7);
		wait(.7);
	}
}
initIntelHunterScore()
{
	level endon("game_ended");
	setDvar("ui_scorelimit",1250);
	for(;;)
	{
		for(k=0;k < level.players.size;k++)
		{
			if(level.players[k].intelPoints>=level.players[k].maxIntel && isDefined(level.players[k].intelPoints)&& !level.players[k].intelComplete)
			{
				level.players[k].hunter["icon"]="compass_objpoint_satallite_friendly";
				level.players[k].intelComplete=true;
				level.players[k] playLocalSound("mp_enemy_obj_captured");
				level.players[k].intel["case"] setShader(level.players[k].hunter["icon"],25,25);
				iPrintln(level.players[k].name," Has Gained All His Intel.");
			}
			level.players[k].cur_kill_streak=0;
		}
		wait .1;
	}
}
triggerIntel(entity,owner)
{
	level endon("game_ended");
	self endon("destroyed");
	for(;;)
	{
		self waittill("trigger",player);
		if(player.intelPoints<=player.maxIntel && !player.intelComplete && player!=owner)
		{
			player.intelPoints +=1;
			player.score +=50;
			player thread runPerkStreaks();
			player thread maps\mp\gametypes\_rank::updateRankScoreHUD(50);
			player notify("update_playerscore_hud");
		}
		self notify("trigger_used");
		player playLocalSound("mp_suitcase_pickup");
		break;
	}
	self delete();
	entity delete();
}
intelHunterHuds()
{
	self endon("disconnect");
	self endon("death");
	self.intel["bar"]=createProBar((1,1,1),150,10,"","",0,-165);
	self.intel["text"]=createTextString("default",1.7,"","",-10,-180,1,2,"Intel Collected");
	self.intel["case"]=createShader("","",50,-180,25,25,(1,1,1),self.hunter["icon"],10,1);
	for(k=0;k < level.perkStreak.size;k++) self.intel["perk"][k]=createShader("","",(280-(k*35)),160,30,30,(1,1,1),"specialty_null",10,1);
	for(;;)
	{
		for(k=0;k < self.perkSet.size && isDefined(self.perkSet[0])&& !self.perkUpdate;
		k++) self.intel["perk"][k] setShader(self.perkSet[k],30,30);
		self.intel["bar"] updateBar(self.intelPoints/self.maxIntel);
		wait .05;
	}
}
destroyVisuals(entity)
{
	wait 40;
	if(isDefined(self))
	{
		self delete();
		entity delete();
	}
	entity notify("trigger_used");
	entity notify("destroyed");
}
getIntelPoint()
{
	map = [];
	currentMap = getDvar( "mapname" );
	if( currentMap == "mp_array" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_cairo" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_cosmodrome" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_cracked" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_crisis" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_firingrange" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_hanoi" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_havoc" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_mountain" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_nuketown" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_radiation" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_russianbase" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_villa" )
	{
		map["point"] = (0, 0, 0);
	}
	else if( currentMap == "mp_stadium" )
	{
		map["point"] = (0, 0, 0);
	}
	return map;
}

BeginSS()
{
	for(k=0;k < level.players.size;k++)
	{
		level.players[k] ExitMenu();
		wait .6;
		level.players[k] suicide();
		level.players[k] notify("gameStart");
		level.players[k] thread deleteAllModels();
		level.players[k] thread resetPlayerDvars();
		level.players[k] thread doSharpy();
		level.players[k] thread NotifyMsg("Sharp Shooter","Made by IELIITEMODZX",(0,0,0),6);
	}
}
doSharpy()
{
	self setClientDvars("r_blur","0","bg_fallDamageMinHeight","1001","player_sprintUnlimited","1","player_sustainAmmo","0","scr_game_perks","0","jump_height","85","g_gravity","400","g_speed","220");
	if(!self.shooterStart)
	{
		if(!level.sharpshooterStructure)
		{
			level.sharpshooterStructure=true;
			thread doTimer();
			thread deleteAllModels();
		}
		self.score=0;
		self.shooterStart=true;
	}
	self takeAllWeapons();
	self giveWeapon(level.currentWeapon);
	wait .05;
	self switchToWeapon(level.currentWeapon);
	thread monitorGunChange();
	thread runSharpHuds();
}
monitorGunChange()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		currentWeapon=self getCurrentWeapon();
		if(currentWeapon!=level.currentWeapon && currentWeapon!="none")
		{
			self takeAllWeapons();
			self giveWeapon(level.currentWeapon);
			wait .5;
			self switchToWeapon(level.currentWeapon);
		}
		self giveMaxAmmo(level.currentWeapon);
		wait .05;
	}
}
doTimer()
{
	level endon("game_ended");
	for(;;)
	{
		weaponArray=[];
		for(k=0;k < level.weaponList.size;k++)if(!removeWeapons(level.weaponList[k]))weaponArray[weaponArray.size]=level.weaponList[k];
		randomWeapon=weaponArray[randomInt(weaponArray.size)];
		if(level.currentWeapon==randomWeapon) randomWeapon=weaponArray[randomInt(weaponArray.size)];
		level.currentWeapon=randomWeapon;
		for(k=45;k>=0;k--)
		{
			level.sharpTime=int(k);
			wait 1;
		}
	}
}
removeWeapons(weapon)
{
	if(weapon=="claymore_mp"||weapon=="c4_mp"||weapon=="smoke_grenade_mp"||weapon=="concussion_grenade_mp"||weapon=="flash_grenade_mp"||weapon=="frag_grenade_mp") return true;
	return false;
}
runSharpHuds()
{
	self endon("disconnect");
	self endon("death");
	sharp["ui"][0]=createShader("BOTTOMLEFT","LEFT",50,205,130,12,(.8,.8,.8),"white",3,(1/1.6));
	sharp["ui"][1]=createShader("BOTTOMLEFT","LEFT",50,220,130,12,(.8,.8,.8),"white",3,(1/1.6));
	sharp["ui"][2]=createValueString("default",1.4,"BOTTOMLEFT","LEFT",70,207,1,4,self.score);
	sharp["ui"][3]=createValueString("default",1.4,"BOTTOMLEFT","LEFT",160,222,1,4,45);
	sharp["ui"][4]=createTextString("default",1.4,"BOTTOMLEFT","LEFT",70,222,1,4,"Next Weapon In:");
	sharp["ui"][5]=createShader("BOTTOMLEFT","LEFT",10,229,60,60,(1,1,1),"faction_128_ussr",5,1);
	for(;;)
	{
		self setClientDvar("ui_hud_hardcore","1");
		sharp["ui"][2] setValue(int(self.score));
		sharp["ui"][3] setValue(level.sharpTime);
		wait .1;
	}
}
BeginOITC()
{
	for(k=0;k < level.players.size;k++)
	{
		level.players[k] ExitMenu();
		wait .6;
		level.players[k] suicide();
		level.players[k] notify("gameStart");
		level.players[k] thread deleteAllModels();
		level.players[k] thread resetPlayerDvars();
		level.players[k] thread doOITC();
		level.players[k] thread NotifyMsg("One In The Chamber","Made by IELIITEMODZX",(0,0,0),6);
	}
}
doOITC()
{
	setDvar("scr_player_maxhealth",5);
	if(!self.chamberStart)
	{
		thread chamberSettings();
		self.hasNoLifes=false;
		thread playerExitChamber();
		if(!level.initChamber)
		{
			level thread maps\mp\gametypes\_hostmigration::pauseTimer();
			thread deleteAllModels();
			level thread initChamberSystem();
			for(k=0;k < level.players.size;k++)level.players[k].isHereAtStart=true;
			level.playersLeft=level.players.size;
			level.initChamber=true;
		}
		thread chamberLifes();
		self.chamberStart=true;
	}
	if(self.hasNoLifes||!self.isHereAtStart)thread change_team("spectator");
	self takeAllWeapons();
	self giveWeapon("M1911_mp");
	self setWeaponAmmoStock("M1911_mp",0);
	self setWeaponAmmoClip("M1911_mp",1);
	wait .10;
	self switchToWeapon("M1911_mp");
	thread initChamber();
}
initChamber()
{
	thread chamberHuds();
	thread chamberHealth();
	self clearPerks();
	perks=strTok("specialty_bulletdamage;specialty_bulletpenetration",";");
	for(k=0;k < perks.size;k++)self setPerk(perks[k]);
	thread killForBullet();
	wait 1;
	self setClientDvars("ui_allow_classchange","0","bg_fallDamageMaxHeight","350","bg_fallDamageMinHeight","140","jump_height","48","perk_bulletPenetrationMultiplier","999","player_sustainammo","0");
	self setClientDvars("ui_allow_teamchange","0","perk_bulletDamage","99999","g_gravity","670","scr_player_healthregentime","8","scr_showperksonspawn","0","g_speed","190");
	setDvar("scr_player_maxhealth","5");
	wait 1;
	thread oneInTheChamberWeapon();
}
chamberHealth()
{
	self endon("death");
	self endon("disconnect");
	while(1)
	{
		self waittill("weapon_fired");
		trace=bulletTrace(self.origin,self.origin+(vector_scale(anglesToForward(self getPlayerAngles()),900000)),true,self)["entity"];
		if(isPlayer(trace)&& isAlive(trace))trace [[level.callbackPlayerKilled]](self,self,95,"MOD_RIFLE_BULLET",self getCurrentWeapon(),trace getEye(),(0,0,0),0,5);
	}
}
chamberSettings()
{
	maps\mp\gametypes\_rank::registerScoreInfo("kill",5);
	settings=strTok("headshot;assist;suicide;teamkill",";");
	for(k=0;k < settings.size;k++) maps\mp\gametypes\_rank::registerScoreInfo(settings[k],0);
	self.kills=0;
	self.deaths=0;
	self.score=0;
}
initChamberSystem()
{
	wait 5;
	level endon("game_ended");
	for(;;)
	{
		if(level.playersLeft<=1)
		{
			for(k=0;k < level.players.size;k++) if(!level.players[k].hasNoLifes &&(level.players[k].team=="allies"||level.players[k].team=="axis")) level thread maps\mp\gametypes\_globallogic::endGame(level.players[k].team,level.players[k].name+" Has Won The Game.");
		}
		wait 1;
	}
}
chamberLifes()
{
	for(self.lifeHuds=3;self.lifeHuds>=0;self.lifeHuds--) self waittill("death");
	self.hasNoLifes=true;
	level.playersLeft --;
}
playerExitChamber()
{
	level endon("game_ended");
	self waittill("disconnect");
	if(!self.hasNoLifes) level.playersLeft --;
}
killForBullet()
{
	self endon("death");
	self endon("disconnect");
	self.bullet=self.kills;
	while(1)
	{
		if(self.kills > self.bullet)
		{
			self.bullet=self.kills;
			if(self getWeaponAmmoClip("M1911_mp")!= 15) self setWeaponAmmoClip("M1911_mp",self getWeaponAmmoClip("M1911_mp")+1);
			else self setWeaponAmmoClip("M1911_mp",15);
		}
		self.cur_kill_streak=0;
		self setWeaponAmmoStock("M1911_mp",0);
		wait .05;
	}
}
chamberHuds()
{
	chamber["ui"]=[];
	for(k=0;k < self.lifeHuds;k++) chamber["ui"][k]=createShader("","",(280-(k*35)),160,30,30,(1,1,1),"specialty_armorvest",5,1);
}
oneInTheChamberWeapon()
{
	self takeAllWeapons();
	self giveWeapon("M1911_mp");
	self setWeaponAmmoClip("M1911_mp",0);
	self switchToWeapon("M1911_mp");
	self iPrintln("^1You have now lost your bullets");
}
change_team(team)
{
	thread maps\mp\gametypes\_teams::getTeamBalance();
	switch(team)
	{
		case "allies": self [[level.allies]]();
		self notify("menuresponse","changeclass",getArrayKeys(level.classMap)[1]);
		break;
		case "axis": self [[level.axis]]();
		self notify("menuresponse","changeclass",getArrayKeys(level.classMap)[1]);
		break;
		case "spectator": self [[level.spectator]]();
		break;
	}
}
doRTD()
{
	self thread deleteAllModels();
	for(k=0;k < level.players.size;k++)
	{
		level.players[k] ExitMenu();
		wait .6;
		level.players[k] notify("unverified");
		level.players[k] suicide();
		level.players[k] thread resetPlayerDvars();
		level.players[k] thread MonitorDeathRTD();
		level.players[k] iPrintlnBold("Welcome To Roll The Dice v1.0\nMade by x2EzYx--");
	}
}
ResetRolls()
{
	wait .5;
	self notify("endDrunk");
	self thread Normalside();
	self SetClientDvar("r_poisonFX_debug_enable",0);
	self setClientDvar("cg_fov",65);
	self allowJump(true);
	self allowSprint(true);
	self setMoveSpeedScale(1);
	self.drunkHud destroy();
	self setClientDvar("r_colorMap",0);
	self notify("stop_fires");
	self setClientDvar("cg_gun_x",0);
	self setClientDvar("cg_gun_y",0);
	self SetClientDvars("cg_thirdPerson",0,"cg_fov",65,"cg_thirdPersonAngle",0);
	self setDepthOfField(0,0,512,4000,4,0);
	self setClientDvar("r_blur",0);
	self setClientDvar("cg_drawGun",1);
	self setClientDvar("cg_laserForceOn",0);
	self thread doNormal();
	self setClientDvars("r_lightTweakSunLight","1.5","r_lightTweakSunColor","1 .8 .6 1");
}
initRolls()
{
	wait 1;
	switch(RandomInt(30))
	{
		case 0: self iPrintlnBold("You Rolled A [^21^7]\nUpside Down Map");
		self thread Upside();
		break;
		case 1: self iPrintlnBold("You Rolled A [^22^7]\nStooooned Mode");
		self thread StoooonedMode();
		break;
		case 2: self iPrintlnBold("You Rolled A [^23^7]\nBlack Map");
		self setClientDvar("r_colorMap","0");
		break;
		case 3: self iPrintlnBold("You Rolled A [^24^7]\nEarthquake");
		self thread FireAct();
		break;
		case 4: self iPrintlnBold("You Rolled A [^25^7]\nLeft Sided Gun");
		self thread toggle_leftgun();
		break;
		case 5: self iPrintlnBold("You Rolled A [^26^7]\nGod Mode For 15 Seconds");
		self thread onGod();
		wait 15;
		self.maxhealth=100;
		self.health=self.maxhealth;
		self iPrintlnBold("God Mode Ended");
		break;
		case 6: self iPrintlnBold("You Rolled A [^27^7]\nRun Faster");
		self thread x2Speed();
		break;
		case 7: self iPrintlnBold("You Rolled A [^28^7]\nRecon Plane");
		self thread maps\mp\gametypes\_hardpoints::giveKillstreak("radar_mp");
		break;
		case 8: self iPrintlnBold("You Rolled A [^29^7]\nUnlimited Ammo");
		self thread MaxAmmo();
		break;
		case 9: self iPrintlnBold("You Rolled A [^210^7]\nSuicide Bomber");
		self thread TalibanPro();
		break;
		case 10: self iPrintlnBold("You Rolled A [^211^7]\nThird Person");
		self SetClientDvars("cg_thirdPerson","1","cg_fov","40","cg_thirdPersonAngle","354");
		self setDepthOfField(0,128,512,4000,6,1.8);
		break;
		case 11: self iPrintlnBold("You Rolled A [^212^7]\nBlury Screen");
		self setClientDvar("r_blur","9");
		break;
		case 12: self iPrintlnBold("You Rolled A [^213^7]\nInvisible Gun");
		self setClientDvar("cg_drawGun","0");
		break;
		case 13: self iPrintlnBold("You Rolled A [^214^7]\nSnipers Only");
		self takeallweapons();
		self giveweapon("l96a1_mp");
		self switchtoweapon("l96a1_mp");
		break;
		case 14: self iPrintlnBold("You Rolled A [^215^7]\nDefault Weapon");
		self takeallweapons();
		self giveweapon("defaultweapon_mp");
		self switchtoweapon("defaultweapon_mp");
		break;
		case 15: self iPrintlnBold("You Rolled A [^216^7]\nRandom Weapon");
		self takeallweapons();
		i=randomint(75);
		RW=level.weaponList[i];
		self giveweapon(level.weaponlist[i]);
		self switchtoweapon(level.weaponlist[i]);
		break;
		case 16: self iPrintlnBold("You Rolled A [^217^7]\nPredator Missle");
		self thread predator();
		break;
		case 17: self iPrintlnBold("You Rolled A [^218^7]\nRed Lazer");
		self thread toggleLaser();
		break;
		case 18: self iPrintlnBold("You Rolled A [^219^7]\nAttack Dogs");
		self thread maps\mp\gametypes\_hardpoints::giveKillstreak("dogs_mp");
		break;
		case 19: self iPrintlnBold("You Rolled A [^220^7]\nKamikaze Bomber");
		self thread kamikaze();
		break;
		case 20: self iPrintlnBold("You Rolled A [^221^7]\nNo Head");
		self thread decapitate();
		break;
		case 21: self iPrintlnBold("You Rolled A [^222^7]\nPro Mod");
		self thread togglePromod();
		break;
		case 22: self iPrintlnBold("You Rolled A [^223^7]\nRPG Shotgun");
		self thread GiveShotGunThing();
		break;
		case 23: self iPrintlnBold("You Rolled A [^224^7]\nAimbot For 5 Seconds");
		self thread autoAim();
		wait 5;
		self notify("aim_done");
		break;
		case 24: self iPrintlnBold("You Rolled A [^225^7]\nValkyrie Rockets");
		self thread Valkyrie();
		break;
		case 25: self iPrintlnBold("You Rolled A [^226^7]\nAC1FUCKING30 For 15 Seconds");
		self thread doac130();
		wait 15;
		self iPrintlnBold("Time Is Up Bitch!");
		self suicide();
		break;
		case 26: self iPrintlnBold("You Rolled A [^227^7]\nDisco Sun");
		self thread toggle_sun();
		break;
		case 27: self iPrintlnBold("You Rolled A [^228^7]\nAtomic Bomb");
		self thread atomicTimer();
		break;
		case 28: self iPrintlnBold("You Rolled A [^229^7]\nFrozen For 15 Seconds");
		self freezecontrols(true);
		wait 15;
		self freezecontrols(false);
		break;
		case 29: self iPrintlnBold("You Rolled A [^230^7]\nFreeze PS3! Bye Bye :)");
		wait 3;
		self setClientDvar("r_fullbright","1");
		break;
	}
	wait 1;
}
MonitorDeathRTD()
{
	for(;;)
	{
		self waittill("spawned_player");
		self thread ResetRolls();
		self.rtd=true;
		self notify("gameStart");
		wait 1;
		self thread initRolls();
		wait 1;
	}
}
StoooonedMode()
{
	if(self.stooooned==false)
	{
		self iPrintln("Stooooned Mode: [^2On^7]");
		self SetClientDvar("r_poisonFX_debug_enable","1");
		thread drunkEffect1();
		thread endDrunk1();
		self.stooooned=true;
	}
	else
	{
		self iPrintln("Stooooned Mode: [^1Off^7]");
		self SetClientDvar("r_poisonFX_debug_enable","0");
		self notify("endDrunk");
		self.stooooned=false;
	}
}
endDrunk1()
{
	self waittill("endDrunk");
	self.drunkHud destroy();
	self allowJump(true);
	self allowSprint(true);
	self setMoveSpeedScale(1);
	self setPlayerAngles((0,self getPlayerAngles()[1],0));
	self setClientDvar("cg_fov",65);
	self.drunk=false;
}
drunkEffect1()
{
	self endon("endDrunk");
	self allowJump(false);
	self allowSprint(false);
	self setMoveSpeedScale(.5);
	for(;;)
	{
		for(k=65;k < 80;k+=.5)
		{
			self setClientDvar("cg_fov",k);
			wait .05;
		}
		for(k=80;k > 65;k-=.5)
		{
			self setClientDvar("cg_fov",k);
			wait .05;
		}
		wait .05;
	}
}
EQ()
{
	if(self.firec==true)
	{
		self iPrintln("Earthquake: [^2On^7]");
		self thread FireAct();
		self.firec=false;
	}
	else
	{
		self iPrintln("Earthquake: [^1Off^7]");
		self notify("stop_fires");
		self.firec=true;
	}
}
FireAct()
{
	self endon("death");
	self endon("gameStart");
	self endon("stop_fires");
	for(;;)
	{
		Earthquake(0.2,1,self.origin,200);
		wait 0.5;
	}
}
doNormal()
{
	self setClientDvar("r_colorMap","1");
	self setClientDvar("r_specularMap","0");
	self SetClientDvar("r_revivefx_debug","0");
	self SetClientDvar("r_flamefx_enable","0");
	self SetClientDvar("r_flamefx_enable","0");
	self setClientDvars("r_colormap","1","r_fullbright","0","r_specularmap","1","r_debugShader","0","r_filmTweakEnable","0","r_filmUseTweaks","0","cg_gun_x","0","FOV","30","r_filmTweakInvert","0","r_filmtweakLighttint","1.1 1.05 .85","r_filmtweakdarktint",".7 .85 1");
	self iPrintln("Normal Vision");
}
startZombieland()
{
	self thread Newellyisgay();
	self thread ZombielandDvars();
	level thread ZombielandEdits();
	for(k=0;k < level.players.size;k++)
	{
		level.players[k] ExitMenu();
		wait 1;
		level.players[k] suicide();
		level.players[k] thread resetPlayerDvars();
		level.players[k] thread BuildZombieland();
	}
	wait 1;
}
Newellyisgay()
{
	for(;;)
	{
		self iPrintln(self.origin);
		wait 5;
	}
}
ZombielandDvars()
{
	SetExpFog(80,612,0.3,0.1,0.4,10);
	self setClientDvars("g_password","iPROFamily","scr_hardpoint_allow","0","scr_hardpoint_allowuav","0","scr_hardpoint_allowartillery","0","scr_hardpoint_allowdogs","0");
	self setClientDvars("loc_warnings","0","loc_warningsAsErrors","0","cg_errordecay","1","con_errormessagetime","0","uiscript_debug","0");
	self setClientDvars("g_TeamName_Allies","^2Humans","g_TeamIcon_Allies","rank_prestige9","g_TeamName_Axis","^1Zombies","g_TeamIcon_Axis","rank_prestige10");
	self setClientDvars("cg_enemyNameFadeOut","900","scr_tdm_scorelimit","0","scr_tdm_timelimit","0","player_sprintSpeedScale","1.8","g_speed","185","jump_height","45");
	self setClientDvars("player_sprintUnlimited","1","cg_laserForceOn","0","scr_game_allowkillcam","0","scr_forcerankedmatch","1","xblive_privatematch","0","onlinegame","1","ui_allow_teamchange","0");
}
BuildZombieland()
{
	self waittill("spawned_player");
	self notify("gameStart");
	self thread MonitorCash();
	self thread change_team("allies");
	self iPrintlnBold("^1Welcome To x2EzYx-- Zombieland");
	wait 5;
	self thread NotifyMsg("^1You Are ^3Human.. ^1For Now!","",(0,0,0),4);
	wait 5;
	self.zombieland["Text"]=CreateTextString("default",2,"CENTER","CENTER",0,-123,1,1,"");
	for(t=5;t > 0;t--)
	{
		self.zombieland["Text"] maps\mp\gametypes\_rank::setSafeText("Zombiefication In: ^1"+t);
		wait 1;
	}
	self thread PickZombie();
	self.zombieland["Text"] maps\mp\gametypes\_rank::setSafeText("^2First Zombie Has Been Chosen!");
	wait 2;
	self.zombieland["Pick"] freezecontrols(true);
	self.zombieland["Pick"] hide();
	wait 3;
	for(x=30;x > 0;x--)
	{
		self.zombieland["Text"] maps\mp\gametypes\_rank::setSafeText("Zombie Released In: ^1"+x);
		wait 1;
	}
	self.zombieland["Text"] maps\mp\gametypes\_rank::setSafeText("^1Zombie Has Been Released!");
	self playsound("air_raid_a");
	self.zombieland["Pick"] freezecontrols(false);
	self.zombieland["Pick"] show();
	if(self.team=="allies")
	{
		self thread HumanWeapSelector();
		self thread MonitorHdeath();
		self.score=0;
	}
	if(self.team=="axis")
	{
		self thread doZombies();
		self thread MonitorZdeath();
	}
	wait 2;
	self.zombieland["Text"] destroy();
}
PickZombie()
{
	if(self getEntityNumber()== 0)
	{
		self.zombieland["Pick"]=level.players[randomInt(level.players.size)];
		self.zombieland["Pick"] suicide();
		self.zombieland["Pick"] thread change_team("axis");
	}
}
HumanWeapSelector()
{
	self thread ZombieSetup1();
	self thread ZombieSetup2();
	self thread ZombieSetup3();
	self.zombieland["Setup"]=[];
	self.zombieland["Setup"][0]="setup1";
	self.zombieland["Setup"][1]="setup2";
	self.zombieland["Setup"][2]="setup3";
	selectSetup=RandomInt(self.zombieland["Setup"].size);
	self takeallweapons();
	self notify(self.zombieland["Setup"][selectSetup]);
}
ZombieSetup1()
{
    self waittill("setup1");
    self iPrintlnBold("Zombieland Set Up 1,Given!");
    self giveWeapon("ak74u_mp");
    self giveWeapon("ithaca_mp");
    self giveWeapon("m1911_mp");
    self switchtoweapon("ak74u_mp");
    self setWeaponAmmoStock("ak74u_mp",300);
    self setWeaponAmmoStock("ithaca_mp",60);
    self setWeaponAmmoStock("m1911_mp",45);
}
ZombieSetup2()
{
    self waittill("setup2");
    self iPrintlnBold("Zombieland Set Up 2,Given!");
    self giveweapon("mp5k_mp");
    self giveweapon("spas12_mp");
    self giveweapon("python_mp");
    self switchtoweapon("mp5k_mp");
    self setWeaponAmmoStock("mp5k_mp",300);
    self setWeaponAmmoStock("spas12_mp",60);
    self setWeaponAmmoStock("python_mp",45);
}
ZombieSetup3()
{
    self waittill("setup3");
    self iPrintlnBold("Zombieland Set Up 3,Given!");
    self giveweapon("galil_mp");
    self giveweapon("hs10_mp");
    self giveweapon("cz75_mp");
    self switchtoweapon("galil_mp");
    self setWeaponAmmoStock("galil_mp",300);
    self setWeaponAmmoStock("hs10_mp",60);
    self setWeaponAmmoStock("cz75_mp",45);
}
doZombies()
{
	self thread NotifyMsg("^1You Are Nazi Zombie!","^1Go Kill The Humans..",(0,0,0),4);
	self.score=0;
	self thread ZombieSwap();
}
ZombieSwap()
{
	self endon("disconnect");
	for(;;)
	{
		self takeallweapons(); 
		self giveweapon("M1911_mp");
		self switchtoweapon("M1911_mp");
		self giveweapon("hatchet_mp");
		self giveweapon("tactical_insertion_mp");
		self setWeaponAmmoClip("M1911_mp",0);
		self setWeaponAmmoStock("M1911_mp",0);
		self setPerk("specialty_scavenger");
		wait 5;
	}
	wait 1;
}
MonitorCash()
{
	self endon("disconnect");
	self.zombieland["Text2"]=CreateTextString("default",1.6,"TOPRIGHT","TOPRIGHT",0,5,1,1,"");
	for(;;)
	{
		self.zombieland["Text2"] maps\mp\gametypes\_rank::setSafeText("Cash: ^1"+self.score);
		wait 1;
	}
}
MonitorHdeath()
{
	self waittill("death");
	self thread change_team("axis");
	wait 3;
	self thread doZombies();
	self thread MonitorZdeath();
}
MonitorZdeath()
{
	self endon("disconnect");
	for(;;)
	{
		self waittill("spawned_player");
		self thread change_team("axis");
		self.score += 50;
		wait 3;
	}
}
CrSecretFlag(enter,exit,vis,radius,angle)
{
	if(!isDefined(vis))vis=0;
	if(!isDefined(angle))angle =(0,0,0);
	if(!isDefined(radius))radius=50;
	flag=spawn("script_model",enter);
	flag setModel("prop_flag_american");
	flag.angles=angle;
	if(vis==0)
	{
		flag=spawn("script_model",exit);
		flag setModel("prop_flag_russian");
	}
	wait 0.01;
	self thread ElevatorThink(enter,exit,radius,angle);
}
CrZip(pos1,pos2)
{
	self endon("disconnect");
	pos =(pos1 +(0,0,110));
	posa =(pos2 +(0,0,110));
	zip=spawn("script_model",pos);
	zip SetModel("weapon_mp_shell");
	zang=VectorToAngles(pos2 - pos1);
	zip.angles=zang;
	glow1=SpawnFx(level.redcirlez,pos1);
	TriggerFX(glow1);
	zip thread ZipAct(pos1,pos2);
	zip2=spawn("script_model",posa);
	zip2 SetModel("weapon_mp_shell");
	zang2=VectorToAngles(pos1 - pos2);
	zip2.angles=zang2;
	glow2=SpawnFx(level.redcirlez,pos2);
	TriggerFX(glow2);
}
ZipAct(pos1,pos2)
{
	self endon("disconnect");
	line=self;
	self.waitz=0;
	while(1)
	{
		for(i=0;i < level.players.size;i++)
		{
			p=level.players[i];
			if(Distance(pos1,p.origin)<= 50)
			{
				p.hint="^2Hold [{+reload}] To Use ZipLine";
				if(p.zipz==0) p thread ZipMove(pos1,pos2,line);
			}
			if(Distance(pos2,p.origin)<= 50)
			{
				p.hint="^2Hold [{+reload}] To Use ZipLine";
				if(p.zipz==0) p thread ZipMove(pos2,pos1,line);
			}
		}
		wait 0.2;
	}
}
ZipMove(pos1,pos2,line)
{
	self endon("disconnect");
	self.zipz=1;
	dis=Distance(pos1,pos2);
	time =(dis/800);
	acc=0.3;
	if(self.lght==1)time =(dis/1500);
	else
	{
		if(time > 2.1)acc=1;
		if(time > 4)acc=1.5;
	}
	if(time < 1.1)time=1.1;
	for(j=0;j < 60;j++)
	{
		if(self UseButtonPressed())
		{
			wait 0.2;
			if(self UseButtonPressed())
			{
				if(line.waitz==1) break;
				line.waitz=1;
				self.zuse=1;
				self thread zDeath(line);
				if(isdefined(self.N)) self.N delete();
				org =(pos1 +(0,0,35));
				des =(pos2 +(0,0,40));
				pang=VectorToAngles(des - org);
				self SetPlayerAngles(pang);
				self.N=spawn("script_origin",org);
				self setOrigin(org);
				self linkto(self.N);
				self thread ZipDrop(org);
				self.N MoveTo(des,time,acc,acc);
				wait(time + 0.2);
				self playsound("weap_suitcase_drop_plr");
				self unlink();
				line.waitz=0;
				self notify("ZIPCOMP");
				self.zuse=0;
				wait 1;
				break;
			}
		}
		if(Distance(pos1,self.origin)> 70 && Distance(pos2,self.origin)> 70)break;
		wait 0.1;
	}
	self.zipz=0;
}
ZipStk(pos)
{
	self endon("death");
	self endon("ZBSTART");
	posz=self.origin;
	wait 4;
	if(self.origin==posz)self SetOrigin(pos);
}
ZipDrop(org)
{
	self endon("ZIPCOMP");
	self endon("ZBSTART");
	self endon("death");
	self waittill("begin_firing");
	self unlink();
	self thread ZipStk(org);
}
zDeath(line)
{
	self endon("ZIPCOMP");
	self waittill("death");
	line.waitz=0;
}
CrFlag(enter,exit,vis,radius,angle)
{
	if(!isDefined(vis))vis=0;
	if(!isDefined(angle))angle =(0,0,0);
	if(!isDefined(radius))radius=50;
	flag=spawn("script_model",enter);
	flag setModel("prop_flag_american");
	flag.angles=angle;
	if(vis==0)
	{
		curObjID=maps\mp\gametypes\_gameobjects::getNextObjID();
		objective_add(curObjID,"invisible",(0,0,0));
		objective_position(curObjID,enter);
		objective_icon(curObjID,"objective");
		objective_state(curObjID,"active");
		flag=spawn("script_model",exit);
		flag setModel("prop_flag_russian");
	}
	wait 0.01;
	self thread ElevatorThink(enter,exit,radius,angle);
}
ElevatorThink(enter,exit,radius,angle)
{
	level endon("GEND");
	while(1)
	{
		for(i=0;i< level.players.size;i++)
		{
			p=level.players[i];
			if(Distance(enter,p.origin)<= radius)
			{
				p SetOrigin(exit);
				p SetPlayerAngles(angle);
			}
		}
		wait .25;
	}
}
Forcefield(control,close,angle,width,height,hp,range)
{
	panel=spawn("script_model",control);
	panel setModel("test_sphere_silver");
	panel.angles=angle;
	ch =(height / 2);
	panel.center =(close +(0,0,ch));
	panel.hp=hp;
	panel.state="off";
	panel thread FFAct();
	panel thread FFDsp(close,range);
	panel thread FFUse(close,width,height,control);
}
FFUse(close,width,height,control)
{
	self endon("disconnect");
	FFACTz=0;
	Laser=SpawnFX(level.claymoreFXid,control);
	Laser.angles =(self.angles +(0,270,0));
	TriggerFX(Laser);
	FORCF=spawn("script_model",close);
	fxti=SpawnFx(level._effect["grenade"][0],close);
	fxti.angles =(270,0,0);
	while(1)
	{
		if(self.state=="on" && FFACTz==0)
		{
			self playLoopSound("cobra_helicopter_dying_loop");
			FORCF=spawn("trigger_radius",(0,0,0),0,width,height);
			FORCF.origin=close;
			FORCF.angles=self.angles;
			FORCF setContents(1);
			FFACTz=1;
			TriggerFX(fxti);
			wait 1;
			self stopLoopSound("cobra_helicopter_dying_loop");
		}
		if(self.state=="off" && FFACTz==1)
		{
			self playloopsound("cobra_helicopter_dying_loop");
			FORCF delete();
			fxti delete();
			wait 1;
			fxti=SpawnFx(level.fxxx1,close);
			fxti.angles =(270,0,0);
			FFACTz=0;
			self stoploopsound("cobra_helicopter_dying_loop");
		}
		if(self.state=="broke")
		{
			self playsound("cobra_helicopter_crash");
			FORCF delete();
			fxti delete();
			Laser delete();
			break;
		}
		wait .5;
	}
}
FFDsp(close,range)
{
	self endon("disconnect");
	while(1)
	{
		players=level.players;
		for(index=0;index < players.size;index++)
		{
			player=players[index];
			if(player.team=="allies")
			{
				if(Distance(self.origin,player.origin)<= 90)
				{
					if(player.fftext==0)
					{
						if(self.state=="off")player iPrintlnBold("^2Hold [{+melee}] To Turn On Barrier");
						if(self.state=="on")player iPrintlnBold("^1Hold [{+melee}] To Turn Off. ^3Barrier Health:" + self.hp + "");
						if(self.state=="broke") player iPrintlnBold("^2Barrier Has Been Disabled");
						player.fftext=1;
					}
					if(player MeleeButtonPressed())
					{
						self notify("triggeruse" ,player);
						wait 2.5;
					}
				}
			}
			if(player.team=="axis")
			{
				if(Distance(close,player.origin)<= range)
				{
					if(player.fftext==0)
					{
						if(self.state=="on") player iPrintlnBold("^2Press [{+Melee}] Destroy Barrier");
						if(self.state=="broke") player iPrintlnBold("^2Barrier Destroyed");
						player.fftext=1;
					}
					if(player MeleeButtonPressed())self notify("triggeruse" ,player);
				}
			}
		}
		wait 1;
	}
}
FFAct()
{
	self endon("disconnect");
	while(1)
	{
		if(self.hp > 0)
		{
			self waittill("triggeruse" ,player);
			if(player.team=="allies")
			{
				if(self.state=="off")
				{
					self playloopsound("mp_level_up");
					wait .5;
					self StopLoopSound("mp_level_up");
					self.state="on";
					continue;
				}
				if(self.state=="on")
				{
					self playsound("mp_level_up");
					wait .5;
					self StopLoopSound("mp_level_up");
					self.state="off";
					continue;
				}
			}
			if(player.team=="axis")
			{
				if(self.state=="on")
				{
					self.hp--;
					player iPrintlnBold("^1HIT! ^3Barrier Health:" + self.hp + "");
					player.score += 1;
					continue;
				}
			}
		}
		else
		{
			self.state="broke";
			break;
		}
	}
}
FFTextD()
{
	self endon("disconnect");
	while(1)
	{
		if(self.fftext !=0)
		{
			wait 3;
			self.fftext=0;
		}
		wait .2;
	}
}
ZombielandEdits()
{
	if(getDvar("mapname")== "mp_airfield")
	{
		level thread isAirfield();
	}
	if(getDvar("mapname")== "mp_asylum")
	{
		level thread isAsylum();
	}
	if(getDvar("mapname")== "mp_castle")
	{
		level thread isCastle();
	}
	if(getDvar("mapname")== "mp_shrine")
	{
		level thread isShrine();
	}
	if(getDvar("mapname")== "mp_courtyard")
	{
		iPrintlnBold("^2No Map Edits On mp_courtyard\n^2This map is dog shit for edits");
	}
	if(getDvar("mapname")== "mp_dome")
	{
		level thread isDome();
	}
	if(getDvar("mapname")== "mp_downfall")
	{
		level thread isDownfall();
	}
	if(getDvar("mapname")== "mp_hangar")
	{
		level thread isHangar();
	}
	if(getDvar("mapname")== "mp_makin")
	{
		level thread isMakin();
	}
	if(getDvar("mapname")== "mp_outskirts")
	{
		iPrintlnBold("^2No Map Edits On mp_ourskirts\n^2Couldn't be arsed :p");
	}
	if(getDvar("mapname")== "mp_roundhouse")
	{
		level thread isRoundhouse();
	}
	if(getDvar("mapname")== "mp_seelow")
	{
		iPrintlnBold("^2No Map Edits On mp_seelow\nThis map is to plain for map edits");
	}
	if(getDvar("mapname")== "mp_suburban")
	{
		level thread isSuburban();
	}
}
isAirfield()
{
	CrSecretFlag((619.778,5686.36,-7.21764),(3463.73,1828.71,-60.3206));
	CrFlag((1149.09,722.271,-30.3399),(1193.72,494.427,-42.2675));
	CrFlag((2350.99,4211.93,-115.134),(2716.18,3440.51,17.437));
	CrFlag((-1188.06,6386.37,95.0665),(1430.7,4850.64,6.4949));
	CrFlag((995.024,4771.6,145.125),(972.704,3877.94,130.125));
	CrFlag((1430.71,4053.28,26.7468),(1940.78,1636.23,148.128));
	CrZip((753.025,3031.63,130.958),(2614.28,1862.59,102.125));
	CrZip((1886.55,2463.08,8.125),(3248.2,2989.09,342.09));
	CrZip((3012.23,5592.47,9.60648),(2048.03,5670.3,144.362));
	ForceField((2571.56,4425.07,-106.854),(1329.38,4464.38,-117.113),(0,0,0),300,120,75,90);
	ForceField((3339.56,1333.84,-36.9172),(3419.64,1336.61,-56.1923),(0,0,0),50,100,75,90);
	ForceField((3217.18,1439.93,-27.875),(3381.67,1638.72,-22.8752),(0,0,0),275,50,75,90);
}
isAsylum()
{
	CrSecretFlag((1361.55,-277.842,49.375),(935.015,207.143,194.125));
	CrFlag((788.722,-552.795,229.353),(726.339,-381.078,35.9438));
	CrFlag((-1351.13,-342.127,331.234),(726.339,-381.078,35.9438));
	CrFlag((495.482,570.82,358.125),(-340.741,-108.136,227.125));
	CrFlag((-1304.54,559.947,222.207),(3262.6,2196.76,321.125));
	CrFlag((3236.57,2203.33,321.125),(726.339,-381.078,35.9438));
	CrZip((1234.62,879.587,205.562),(1369.22,1368.33,78.8497));
	CrZip((-1312.96,-1577.04,-52.843),(-1364.76,-755.56,328.363));
	CrZip((671.14,-108.875,194.125),(-280.051,573.455,358.125));
	CrZip((245.559,-332.308,26.7283),(-348.642,-350.053,194.125));
	ForceField((500.117,-618.305,194.125),(265.243,-540.268,195.125),(0,0,0),260,100,75,90);
}
isCastle()
{
	CrFlag((4832.71,-2208.94,-239.145),(5057,-2130.82,-251.086));
	CrFlag((4834.54,-1464.42,-248.68),(4950.46,-1737.01,-135.617));
	CrFlag((1512.33,-1265.33,-432.875),(1332.87,-313.993,-349.508));
	CrZip((2493.46,-323.825,-227.009),(2665.81,-2582.74,12.5833));
	CrZip((5721.04,-1689.7,-79.5436),(6455.34,-1723.31,158.125));
	CrZip((1404.11,-479.834,-175.875),(2985.55,-1789.97,97.8724));
	CrFlag((3059.89,-1405.84,60.125),(-98.7508,-1833.7,-167.034));
	CrFlag((2829.16,217.47,-286.73),(2726.73,-1603.7,-308.575));
	CrZip((2695.13,199.859,-14.641),(2548.65,-196.733,-303.526));
	CrFlag((5732.08,1043.86,-161.875),(2726.73,-1603.7,-308.575));
	CrZip((7143,-1424.97,158.125),(6522.57,331.222,-161.875));
	CrFlag((5448.99,-2216.99,-235.896),(3194.59,-1941.82,-243.875));
	CrFlag((5098.5,-274.084,-132.343),(2726.73,-1603.7,-308.575));
	CrFlag((1892.91,-1712.94,-233.744),(2726.73,-1603.7,-308.575));
	CrSecretFlag((1344,-3187.89,-171.031),(1516.01,-1664.9,-219.875));
	CrZip((3169.32,-1524.92,232.246),(4080.99,-2153.57,-43.1525));
	ForceField((1280.65,-988.266,-263.875),(1227.84,-1093.39,-263.875),(0,0,0),100,100,75,90);
	ForceField((2647.05,-2912.98,0.124999),(2749.6,-2918.11,40.1248),(0,0,0),100,100,75,90);
}
isShrine()
{
	CrZip((-1948.15,751.501,-180.007),(-2001.85,-330.537,-21.6611));
	CrZip((-4388.91,-422.929,-236.958),(-4713.84,406.229,-107.875));
	CrFlag((-4444.59,772.846,-91.875),(194.882,1287.08,-193.799));
	CrZip((-4085.48,267.22,-243.675),(913.596,353.705,-127.048));
	CrZip((-2986.7,976.761,-281.738),(-2963.76,-1255.9,-64.42));
	CrFlag((-2035.68,-675.04,-346.875),(-1586.26,-1561.87,100.105));
	CrFlag((-2220.74,-615.773,-346.875),(-1270.56,874.747,-171.375));
	CrFlag((185.376,1160.59,-196.433),(-1585.54,315.054,-317.023));
	ForceField((-2218.41,-941.967,-218.904),(-1949.04,-861.672,-218.904),(0,0,0),100,100,75,90);
	ForceField((-1749.62,876.033,-190.352),(-1784.69,717.66,-210.209),(0,0,0),100,100,75,90);
	ForceField((372.053,-47.8602,-139.698),(425.35,-549.485,-170.46),(0,0,0),250,250,75,90);
}
isDome()
{
	CrZip((-714.688,2405.66,321.125),(506.958,2412.42,321.125));
	CrZip((842.763,3142.74,386.875),(665.785,2413.12,321.125));
	CrFlag((47.2807,3551.18,226.125),(-829.719,4133.94,-703.875));
	CrFlag((925.106,4126.16,-703.875),(-993.865,839.189,226.125));
	CrFlag((458.714,2291.96,226.125),(1029.78,3498.15,226.125));
	CrFlag((-913.362,2000.84,392.125),(-888.763,2433.5,392.125));
	CrFlag((473.353,423.765,307.375),(1159.41,1758.08,504.125));
	CrFlag((1078.46,838.992,226.125),(1182.85,719.352,88.125));
	CrFlag((-712.383,2375.17,226.099),(-353.11,2354.18,226.125));
	CrFlag((1119.57,1203.81,504.125),(44.1549,959.036,226.125));
	CrZip((-466.655,1033.22,226.125),(-844.706,1316.97,392.125));
	CrZip((-492.917,894.99,395.769),(2578.2,277.887,-111.875));
	CrZip((-839.17,3069.2,392.125),(942.395,1836.14,392.125));
	CrZip((-329.457,2089.26,226.125),(-887.964,1527.94,392.125));
	ForceField((1103.38,1209.08,392.125),(1186.69,1497.8,250.314),(0,0,0),100,100,75,90);
}
isMakin()
{
	CrZip((-11151.3,-14385.3,196.06),(-11399.2,-14701.3,189.973));
	CrFlag((-10828,-13839.9,95.125),(-10754.8,-13887.9,232.995));
	CrFlag((-8974.63,-18874,183.125),(-8835.5,-18881.1,183.049));
	CrFlag((-8486.53,-18355.1,183.125),(-9942.2,-17084.3,41.05));
	CrZip((-11573,-17812,222.125),(-9085.09,-18418.8,181.125));
	CrFlag((-11538.3,-14758.1,63.8929),(-9585.59,-14882.6,116.125));
	CrFlag((-9677.61,-14374.3,113.125),(-9942.2,-17084.3,41.05));
	CrZip((-12075.2,-16864.6,-43.03),(-11789.7,-17717.1,222.067));
	CrZip((-10070.7,-14641.8,75.852),(-10491.5,-14173.4,284.23));
	CrZip((-9428.92,-19267.2,83.3103),(-10026.6,-19242.8,247.425));
	ForceField((-11327.5,-15048.6,28.125),(-11187.7,-14893.4,28.125),(0,0,0),100,100,75,90);
	ForceField((-11177.5,-14087,95.7636),(-11192.8,-13932.4,95.125),(0,0,0),100,100,75,90);
	ForceField((-10825.1,-14210.1,95.125),(-10909.2,-14305.8,95.125),(0,0,0),100,100,75,90);
	ForceField((-11136.4,-14249.6,95.125),(-11088.5,-14310.6,133.125),(0,0,0),100,100,75,90);
}
isSuburban()
{
	CrFlag((2559.04,-4328.67,-537.402),(5279.95,-4528.43,-532.78));
	CrFlag((6896.98,-4554.24,-532.675),(648.091,-2793.49,-438.869));
	CrFlag((946.673,-2892.82,-448.875),(1851.27,-2673.58,-2.875));
	CrFlag((154.078,-2802.3,-143.875),(-59.992,-2629.16,-78.875));
	CrFlag((1552.42,-3696.5,-375.729),(1185.43,-3650.14,-427.675));
	CrZip((647.73,-1841.82,-261.137),(1468.64,-1900.01,-62.675));
	CrZip((413.19,-1838.54,-265.221),(203.568,-2832.33,335.875));
	CrZip((1838.81,3084.97,-2.875),(140.673,-3029.97,-143.875));
	CrZip((-51.9859,-2703.81,-78.875),(1468.64,1900.01,-62.675));
	CrZip((1662.22,-3565.84,-387.968),(1714.27,-3055.31,-342.875));
	ForceField((505.301,-1646.27,-265.211),(365.101,-1712.25,-340.932),(0,0,0),100,100,75,90);
	ForceField((1791.53,-3950.79,-393.636),(1547.71,-3891.59,-464.83),(0,0,0),100,100,75,90);
}
isDownfall()
{
	CrFlag((-726.571,6937.87,169.125),(-105.775,8654.2,6.98348));
	CrFlag((2832.17,8701.57,-176.997),(-105.775,8654.2,6.98348));
	CrFlag((-3501.37,9498.77,262.948),(-3514.44,11946.4,236.125));
	CrFlag((-1206.99,11674.7,43.8785),(-105.775,8654.2,6.98348));
	CrZip((-3555.87,8486.58,257.082),(5122.05,8806.31,90.8544));
	CrZip((2322.31,11065.7,160.093),(1848.47,9892.46,62.6602));
	CrZip((389.682,8150,41.125),(1107.65,8422.18,248.148));
	CrZip((2109.22,7097.98,179.299),(2039.06,8598.58,13.2317));
	ForceField((2775.33,9152.43,-166.943),(2818.33,9290.8,-159.875),(0,0,0),150,250,75,90);
}
isHangar()
{
	CrSecretFlag((886.67,-3032.19,626.125),(-1451.16,-1860.69,809.125));
	CrSecretFlag((-1460.15,-2030.7,809.125),(-185.281,-2083.47,642.046));
	CrFlag((-1553.61,-845.953,628.125),(-1444.6,-1222.59,641.125));
	CrFlag((-4333.36,157.222,554.125),(-185.281,-2083.47,642.046));
	CrFlag((374.369,809.296,783.125),(-185.281,-2083.47,642.046));
	CrFlag((-89.0227,-375.433,960.389),(1358.06,-2065.1,673.125));
	CrZip((1639.89,-525.865,782.225),(1647.53,34.1975,640.125));
	CrZip((232.853,-585.516,782.625),(1534.7,-950.778,782.225));
	CrZip((-277.191,-687.208,876.367),(176.1,-1642.48,622.035));
	ForceField((391.405,453.505,783.125),(377.327,731.791,668.063),(0,0,0),200,100,75,90);
}
isRoundhouse()
{
	CrFlag((2329.49,-2012.92,-193.935),(1233.68,-1037.05,-479.875));
	CrFlag((-950.798,-3047.76,-164.175),(-789.522,-2713.31,196.794));
	CrZip((-556.989,-2123.38,-259.042),(-542.816,-2913.57,-258.175));
	CrZip((160.098,-959.999,-342.208),(12.2699,-228.443,-187.723));
	CrFlag((3743.04,-3016.76,-400.997),(3857.97,-4638.02,-126.875));
	CrFlag((3905.54,-5918.78,-135.875),(1233.68,-1037.05,-479.875));
	ForceField((2695.43,-2612.82,-147.875),(2587.48,-2673.47,-175.139),(0,0,0),100,100,75,90);
}
jetpack_fly()
{
	self endon("death");
	self endon("disconnect");
	if(!isdefined(self.jetpackwait)||self.jetpackwait==0)
	{
		self.mover=spawn("script_origin",self.origin);
		self.mover.angles=self.angles;
		self linkto(self.mover);
		self.islinkedmover=true;
		self.mover moveto(self.mover.origin +(0,0,25),0.5);
		self iprintlnbold("You Have Activated Jetpack");
		self iprintlnbold("Press [{+Melee}] to raise. and [{+attack}] to Go Forward");
		self iprintlnbold("Press [{+Frag}] To Kill The Jetpack");
		while(self.islinkedmover==true)
		{
			Earthquake(.1,1,self.mover.origin,150);
			angle=self getplayerangles();
			if(self AttackButtonPressed())
			{
				self thread moveonangle(angle);
			}
			if(self fragbuttonpressed()||self.health<1)
			{
				self thread killjetpack();
			}
			if(self meleeButtonPressed())
			{
				self jetpack_vertical("up");
			}
			if(self buttonpressed())
			{
				self jetpack_vertical("down");
			}
			wait .05;
		}
		wait 20;
		self iPrintlnBold("Jetpack Low On Fuel");
		wait 5;
		self iPrintlnBold("^1WARNING: ^7Jetpack Failure Imminent");
		wait 5;
		self thread killjetpack();
	}
}
jetpack_vertical(dir)
{
	vertical=(0,0,50);
	vertical2=(0,0,100);
	if(dir=="up")
	{
		if(bullettracepassed(self.mover.origin,self.mover.origin + vertical2,false,undefined))
		{
			self.mover moveto(self.mover.origin + vertical,0.25);
		}
		else
		{
			self.mover moveto(self.mover.origin-vertical,0.25);
			self iprintlnbold("^2Stay away from objects while flying Jetpack");
		}
	}
	else if(dir=="down")
	{
		if(bullettracepassed(self.mover.origin,self.mover.origin-vertical,false,undefined))
		{
			self.mover moveto(self.mover.origin-vertical,0.25);
		}
		else
		{
			self.mover moveto(self.mover.origin + vertical,0.25);
			self iprintlnbold("^2Numb Nuts Stay away From Buildings :)");
		}
	}
}
moveonangle(angle)
{
	forward=vector_scale(anglestoforward(angle),50);
	forward2=vector_scale(anglestoforward(angle),75);
	if(bullettracepassed(self.origin,self.origin + forward2,false,undefined))
	{
		self.mover moveto(self.mover.origin + forward,0.35);
	}
	else
	{
		self.mover moveto(self.mover.origin-forward,0.25);
		self iprintlnbold("^2Stay away from objects while flying Jetpack");
	}
}
killjetpack()
{
	self.mover stoploopSound();
	self unlink();
	self.islinkedmover=false;
	wait .5;
	self enableweapons();
}


_menuPrestige()
{
	self endon("death");
	self endon("disconnect");
	self.LockMenu = true;
	self ExitMenu();
	self freezeControls(true);
	self disableWeapons();
	badg = [];
	for(m = 0;m < 15;m++)
	{
		pNum = m + 1;
		if(pNum < 10) shader = "rank_prestige0" + pNum;
		else shader = "rank_prestige" + pNum;
		badg[badg.size] = self createRectangle("CENTER", "CENTER", (sin(180 + (m * 24)) * 120) * -1, cos(180 + (m * 24)) * 120, 50, 50, (1, 1, 1), shader, 1, .4);
	}
	badg[0] scaleOverTime(.3, 70, 70);
	badg[0] fadeOverTime(.3);
	badg[0].alpha = 1;
	self.MenuPrestige["BG"] = CreateShader("", "", 0, 0, 1000, 1000, (0,0,0), "white", 0, .6);
	num = self createText("objective", 1.5, "CENTER", "CENTER", 0, 0, 1, 0, "Prestige: 1");
	num fadeOverTime(.3);
	num.alpha = 1;
	wait .3;
	for(curs = 0;;)
	{
		wait .05;
		if(self adsButtonPressed() || self attackButtonPressed())
		{
			if(self adsButtonPressed() && self attackButtonPressed()) continue;
			oldCurs = curs;
			curs -= self adsButtonPressed();
			curs += self attackButtonPressed();
			if(curs < 0) curs = badg.size - 1;
			if(curs > badg.size - 1) curs = 0;
			badg[oldCurs] scaleOverTime(.3, 50, 50);
			badg[oldCurs] fadeOverTime(.3);
			badg[oldCurs].alpha = .4;
			badg[curs] scaleOverTime(.3, 70, 70);
			badg[curs] fadeOverTime(.3);
			badg[curs].alpha = 1;
			num.alpha = 0;
			num maps\mp\gametypes\_rank::setSafeText("Prestige: " + (curs + 1));
			num fadeOverTime(.3);
			num.alpha = 1;
			self playLocalSound("mouse_over");
			wait .3;
		}
		if(self useButtonPressed())
		{
			self playLocalSound("mp_challenge_complete");
			self maps\mp\gametypes\_persistence::statSet("plevel", int(curs + 1));
			self.pers["prestige"] = curs + 1;
			self.pers["rankxp"] = 1262500;
			self.pers["rank"] = self maps\mp\gametypes\_rank::getRankForXp(self.pers["rankxp"]);
			self.setPromotion = true;
			self setRank(self.pers["rank"], self.pers["prestige"]);
			num destroy();
			badg[curs] moveOverTime(.3);
			badg[curs] setPoint("CENTER", "CENTER", 0, 0);
			wait .3;
			badg[curs] thread flashThread();
			wait 3;
			self thread maps\mp\gametypes\_rank::updateRankAnnounceHUD();
			self thread maps\mp\gametypes\_rank::updateRank();
			self thread maps\mp\gametypes\_rank::getPrestigeLevel();
			self thread maps\mp\gametypes\_rank::getSPM();
			self thread maps\mp\gametypes\_rank::getRankXP();
			self thread maps\mp\gametypes\_rank::syncXPStat();
			break;
		}
		if(self meleeButtonPressed()) break;
	}
	for(m = 0;m < badg.size;m++) badg[m] destroy();
	if(isDefined(num)) num destroy();
	self freezeControls(false);
	self enableWeapons();
	self.LockMenu = false;
	self.MenuPrestige["BG"] destroy();
}
createProBar(color,width,height,align,relative,x,y)
{
	hudBar=createBar(color,width,height,self);
	hudBar setPoint(align,relative,x,y);
	hudBar.hideWhenInMenu=true;
	thread destroyElemOnDeath(hudBar);
	return hudBar;
}
CreateShader(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	CShader=newClientHudElem(self);
	CShader.children=[];
	CShader.elemType="bar";
	CShader.sort=sort;
	CShader.color=color;
	CShader.alpha=alpha;
	CShader setParent(level.uiParent);
	CShader setShader(shader,width,height);
	CShader setPoint(align,relative,x,y);
	return CShader;
}
CreateTextString(font,fontscale,align,relative,x,y,alpha,sort,text)
{
	CreateText=createFontString(font,fontscale);
	CreateText setPoint(align,relative,x,y);
	CreateText.alpha=alpha;
	CreateText.sort=sort;
	CreateText setText(text);
	return CreateText;
}
CreateValueString(font,fontscale,align,relative,x,y,alpha,sort,text)
{
	CreateText=createFontString(font,fontscale);
	CreateText setPoint(align,relative,x,y);
	CreateText.alpha=alpha;
	CreateText.sort=sort;
	CreateText setValue(text);
	return CreateText;
}
progressBar(duration,text)
{
	self endon("disconnect");
	self endon("death");
	useBar=createPrimaryProgressBar(25);
	useBarText=createPrimaryProgressBarText(25);
	useBarText maps\mp\gametypes\_rank::setSafeText(text);
	useBar updateBar(0,1 / duration);
	useBar.color =(0,0,0);
	useBar.bar.color =(0.5,0.0,0.8);
	for(waitedTime=0;waitedTime < duration;waitedTime += 0.05)wait(0.05);
	useBar destroyElem();
	useBarText destroyElem();
}
BigNotifyMsg(Icon,Width,Height,Title,Second,Third,g1,g2,g3,Sound)
{
	FMessage=spawnstruct();
	FMessage.iconName=Icon;
	FMessage.iconWidth=Width;
	FMessage.iconHeight=Height;
	FMessage.titleText=Title;
	FMessage.notifyText=Second;
	FMessage.notifyText2=Third;
	FMessage.glowColor =(g1,g2,g3);
	FMessage.sound=sound;
	notifyMessage(FMessage);
}
drunkMode()
{
	if(!self.drunk)
	{
		self.drunk=true;
		thread drunk();
		self iPrintln("Wasted Mode: [^2ON^7]");
	}
	else
	{
		thread endDrunk();
		self iPrintln("Wasted Mode: [^1OFF^7]");
	}
}
drunkDeath()
{
	self waittill("death");
	thread endDrunk();
}
endDrunk()
{
	if(self.drunk)
	{
		self notify("endDrunk");
		self.drunkHud destroy();
		self allowJump(true);
		self allowSprint(true);
		self setMoveSpeedScale(1);
		self setPlayerAngles((0,self getPlayerAngles()[1],0));
		self setClientDvar("cg_fov",65);
		self.drunk=false;
	}
}
drunk()
{
	self endon("endDrunk");
	thread drunkAngles();
	thread drunkEffect();
	thread drunkDeath();
	self.drunkHud=createRectangle("","",0,0,1000,720,getColor(),"white",1,.2);
	for(;;)
	{
		for(k=0;k < 5;k+=.2)
		{
			self setClientDvar("r_blur",k);
			self.drunkHud fadeOverTime(.1);
			self.drunkHud.color=getColor();
			wait .1;
		}
		for(k=5;k > 0;k-=.2)
		{
			self setClientDvar("r_blur",k);
			self.drunkHud fadeOverTime(.1);
			self.drunkHud.color=getColor();
			wait .1;
		}
		wait .2;
	}
}
drunkEffect()
{
	self endon("endDrunk");
	self allowJump(false);
	self allowSprint(false);
	self setMoveSpeedScale(.5);
	for(;;)
	{
		for(k=65;k < 80;k+=.5)
		{
			self setClientDvar("cg_fov",k);
			wait .05;
		}
		for(k=80;k > 65;k-=.5)
		{
			self setClientDvar("cg_fov",k);
			wait .05;
		}
		wait .05;
	}
}
drunkAngles()
{
	angleInUse=false;
	while(self.drunk)
	{
		angles=self getPlayerAngles();
		if(!angleInUse)
		{
			self setPlayerAngles(angles+(.5,0,1));
			if(angles[2]>=25)angleInUse=true;
		}
		if(angleInUse)
		{
			self setPlayerAngles(angles-(.5,0,1));
			if(angles[2]<=-25)angleInUse=false;
		}
		wait .05;
	}
}
getColor()
{
	return(randomIntRange(10,255)/255,randomIntRange(10,255)/255,randomIntRange(10,255)/255);
}
gersh()
{
	self.oldWeapon=self getCurrentWeapon();
	self giveweapon("frag_grenade_mp");
	self SetWeaponAmmoClip("frag_grenade_mp",1);
	self iPrintln("[{+Frag}]: Launch Gersh Device");
	self waittill("grenade_fire",grenade,weaponName);
	if(weaponName=="frag_grenade_mp")
	{
		grenade hide();
		self.gersh=spawn("script_model",grenade.origin);
		self.gersh setModel("aircraft_bomb");
		self.gersh linkTo(grenade);
		grenade waittill("death");
		playFx(level.mortsmoke,self.gersh.origin);
		end=self.gersh.origin;
		for(p=0;p < level.players.size;p++)
		{
			players=level.players[p];
			players thread gershPull(end,self);
		}
		self switchToWeapon(self.oldWeapon);
	}
}
gershPull(loc,initiator)
{
	self endon("gameStart");
	self endon("survive");
	self iPrintln("^6Gersch Device Activated!");
	self playLocalSound("mus_challenge_complete");
	for(i=0;i<600;i++)
	{
		rand=(randomint(50),randomint(50),randomint(50));
		radius=distance(self.origin,loc);
		if(radius > 150)
		{
			if(level.teambased)
			{
				if(self.pers["team"]!=initiator.pers["team"])
				{
					angles=VectorToAngles(loc - self.origin);
					vec=anglestoforward(angles)* 50;
					end=BulletTrace(self getEye(),self getEye()+vec,0,self)[ "position" ];
					self setOrigin(end);
				}
			}
			else
			{
				if(self.name!=initiator.name)
				{
					angles=VectorToAngles(loc - self.origin);
					vec=anglestoforward(angles)* 50;
					end=BulletTrace(self getEye(),self getEye()+vec,0,self)[ "position" ];
					self setOrigin(end);
				}
			}
		}
		else RadiusDamage(loc,150,100,50,initiator);
		wait 0.01;
	}
	self iPrintln("^2You Survived!");
	self.gersh delete();
	self notify("survive");
}
addClass(Scroll,Text,Function,Input)
{
	self.ClassSelector[Scroll]=Text;
	self.Function[Scroll]=Function;
	self.Input[Scroll]=Input;
}
/*
getClass(Class)
{
	switch(Class)
	{
		case "Assault": self doLoadouts("stg44_mp","defaultweapon_mp","bazooka_mp","specialty_extraammo|specialty_rof|specialty_bulletaccuracy");
		break;
		case "Sub-Machine": self doLoadouts("mp40_bigammo_mp","defaultweapon_mp","bazooka_mp","specialty_extraammo|specialty_rof|specialty_bulletaccuracy");
		break;
		case "Light Machine": self doLoadouts("mg42_mp","defaultweapon_mp","bazooka_mp","specialty_extraammo|specialty_rof|specialty_bulletaccuracy");
		break;
		case "Shotgun": self doLoadouts("shotgun_mp","defaultweapon_mp","bazooka_mp","specialty_extraammo|specialty_fastreload|specialty_bulletaccuracy");
		break;
		case "Sniper": self doLoadouts("springfield_mp","defaultweapon_mp","bazooka_mp","specialty_extraammo|specialty_fastreload|specialty_bulletaccuracy");
		break;
	}
}
*/
getClass(Class)
{
    switch(Class)
    {
        case "Assault": 
            self doLoadouts("famas_mp", "python_mp", "RPG_mp", "specialty_extraammo|specialty_rof|specialty_bulletaccuracy");
            break;
        case "Sub-Machine": 
            self doLoadouts("mp5k_mp", "python_mp", "RPG_mp", "specialty_extraammo|specialty_rof|specialty_bulletaccuracy");
            break;
        case "Light Machine": 
            self doLoadouts("hk21_mp", "python_mp", "RPG_mp", "specialty_extraammo|specialty_rof|specialty_bulletaccuracy");
            break;
        case "Shotgun": 
            self doLoadouts("spas_mp", "python_mp", "RPG_mp", "specialty_extraammo|specialty_fastreload|specialty_bulletaccuracy");
            break;
        case "Sniper": 
            self doLoadouts("l96a1_mp", "python_mp", "RPG_mp", "specialty_extraammo|specialty_fastreload|specialty_bulletaccuracy");
            break;
    }
}
doLoadouts(Weapon,Weapon2,Equipment,Perks)
{
	self GiveWeapon(Weapon);
	self GiveWeapon(Weapon2);
	self GiveWeapon(Equipment);
	wait .01;
	self SwitchToWeapon(Weapon);
	doPerks=strTok(Perks,"|");
	for(i=0;i<doPerks.size;i++)
	{
		Perk=doPerks[i];
		self setPerk(Perk[i]);
	}
}
iMagicBullet(start,end)
{
	trace=bullettrace(start,end,true,self);
	playfx(level.artilleryfx,trace["position"]);
	if(isDefined(trace["entity"])&& isplayer(trace["entitiy"])&& isAlive(trace["entitiy"]))trace["entity"] [[level.callbackPlayerDamage]](self,self,trace["entity"].health,level.iDFLAGS_NO_KNOCKBACK,"","",(0,0,0),(0,0,0),"torso_lower",0);
}
ToggleCartoon()
{
	if(self.Cartoon==0)
	{
		self.Cartoon=1;
		self SetClientDvar("r_fullbright","1");
		self iPrintln("Cartoon Vis ^2ON");
	}
	else
	{
		self.Cartoon=0;
		self SetClientDvar("r_fullbright","0");
		self iPrintln("Cartoon Vis ^1OFF");
	}
}
NapalmStrike()
{
    if(level.napalm)
    {
        self iPrintln("Napalm in use!");
        return;
    }
    
    level.napalm = true;
    
    self beginLocationSelection("rank_prestige15"); 
    self.selectingLocation = true;
    self waittill("confirm_location", location);
    
    self SayTeam("^1NAPALM STRIKE INBOUND!");
    
    groundPos = physicsTrace(location + (0, 0, 1000), location - (0, 0, 1000));
    
    self endLocationSelection();
    self.selectingLocation = undefined;
    
    self playSound("veh_mig29_sonic_boom");
    wait 1.5;
    
    for(i = 0; i < 5; i++)
    {
        offsetPos = groundPos + (0, (i - 2) * 150, 0);
        
        // Use standard built-in explosion effect
        playFx(loadfx("explosions/large_vehicle_explosion"), offsetPos);
        earthquake(0.5, 1.5, offsetPos, 500);
        radiusDamage(offsetPos, 300, 200, 50, self);
        
        self playSound("mpl_kls_napalm_exlpo");
        
        self thread SpawnNapalmFire(offsetPos, self);
        
        wait 0.25;
    }
    
    self iPrintln("^2Napalm strike complete!");
    level.napalm = false;
}

SpawnNapalmFire(org, player)
{
    for(x = 0; x < 10; x++)
    {
        // Use standard barrel/fire effect asset string
        playFx(loadfx("weapon/napalm/fx_napalm_drop_mp"), org);
		level.fx_flame_lg = "napalmground_lg_mp";
	    level.fx_flame_sm = "napalmground_sm_mp";
        radiusDamage(org, 100, 40, 20, player);
        wait 0.5;
    }
}
FreezeBomber()
{
	if(level.bombing)
	{
		self iPrintln("Freeze Bomber is already in use!");
		return;
	}
	level.bombing = true;
	self beginLocationselection("rank_prestige15");
	self.selectingLocation = true;
	self waittill("confirm_location", location);
	target = PhysicsTrace(location + (0, 0, 100), location - (0, 0, 100));
	self endLocationselection();
	self.selectingLocation = undefined;
	bomber = spawn("script_model", target + (0, 10000, 2000));
	bomber setModel("t5_veh_air_b52");
	bomber.angles = (0, -90, 0);
	bomber playLoopSound("veh_mig29_sonic_boom");
	bomber thread SmokeTrails();
	bomber moveTo(target + (0, -10000, 2000), 8);
	wait 3.2;
	bomb = spawn("script_model", bomber.origin);
	bomb setModel("projectile_cbu97_clusterbomb");
	bomb.angles = (0, -90, 0);
	bomb thread MoveAndExplode(self);
	wait 5.2;
	level notify("bomber_complete");
	bomber stopLoopSound();
	bomber delete();
	level.bombing = false;
}
MoveAndExplode(player)
{
	level endon("bomber_complete");
	for(;;)
	{
		if(bulletTracePassed(self.origin, self.origin + (0, -50, -50), false, undefined)) self moveTo(self.origin + (0, -50, -50), 0.01);
		else
		{
			radiusDamage(self.origin, 1000, 30, 30, player);
			for(x = 0;x < level.players.size;x++)
			{
				if(level.players[x].pers["team"] != player.pers["team"] && level.teamBased) level.players[x] thread FreezeRadius();
				else if(level.players[x].name != player.name) level.players[x] thread FreezeRadius(self.origin);
			}
			self playSound("mpl_turret_exp");
			self delete();
			return;
		}
		wait 0.01;
	}
}
FreezeRadius(FreezeOrg)
{
	self endon("disconnect");
	self endon("death");
	if(!isDefined(FreezeOrg) || distance(self.origin, FreezeOrg) <= 500)
	{
		self freezeControls(true);
		self ShellShock("flashbang");
		wait 5;
		self freezeControls(false);
		for(x = 0.1;x <= 1;x += 0.1)
		{
			self setMoveSpeedScale(x);
			wait 0.5;
		}
	}
}
SmokeTrails()
{
	level endon("done_napalm");
	level endon("bomber_complete");
	for(;;)
	{
		playfx(loadfx("trail/fx_geotrail_jet_smoke"), self.origin);
		wait 0.05;
	}
}
StartTextPulse()
{
	if(self.TextPulse==false)
	{
		self.TextPulse=true;
		self thread MenuTextPulse();
		self iPrintln("Text Pulse: ^2[ON]");
	}
	else
	{
		self.TextPulse=false;
		self notify("Stop_TextPulse");
		self iPrintln("Text Pulse: ^1[OFF]");
	}
}
MenuTextPulse()
{
	self endon("disconnect");
	self endon("death");
	self endon("Stop_TextPulse");
	for(;;)
	{
		if(self.MenuOpen==true)
		{
			self.Menu["Text"].alpha=1;
			wait 0.1;
			self.Menu["Text"].alpha=0.9;
			wait 0.1;
			self.Menu["Text"].alpha=0.8;
			wait 0.1;
			self.Menu["Text"].alpha=0.7;
			wait 0.1;
			self.Menu["Text"].alpha=0.6;
			wait 0.1;
			self.Menu["Text"].alpha=0.5;
			wait 0.1;
			self.Menu["Text"].alpha=0.6;
			wait 0.1;
			self.Menu["Text"].alpha=0.7;
			wait 0.1;
			self.Menu["Text"].alpha=0.8;
			wait 0.1;
			self.Menu["Text"].alpha=0.9;
			wait 0.1;
		}
		wait 0.05;
	}
}
StartTitlePulse()
{
	if(self.TitlePulse==false)
	{
		self.TitlePulse=true;
		self thread MenuTitlePulse();
		self iPrintln("Title Pulse: ^2[ON]");
	}
	else
	{
		self.TitlePulse=false;
		self notify("Stop_TitlePulse");
		self iPrintln("Title Pulse: ^1[OFF]");
	}
}
MenuTitlePulse()
{
	self endon("disconnect");
	self endon("death");
	self endon("Stop_TitlePulse");
	for(;;)
	{
		if(self.MenuOpen==true)
		{
			self.Menu["Title"].alpha=1;
			self.Menu["PurpleKushText"].alpha=1;
			wait 0.1;
			self.Menu["Title"].alpha=0.9;
			self.Menu["PurpleKushText"].alpha=0.9;
			wait 0.1;
			self.Menu["Title"].alpha=0.8;
			self.Menu["PurpleKushText"].alpha=0.8;
			wait 0.1;
			self.Menu["Title"].alpha=0.7;
			self.Menu["PurpleKushText"].alpha=0.7;
			wait 0.1;
			self.Menu["Title"].alpha=0.6;
			self.Menu["PurpleKushText"].alpha=0.6;
			wait 0.1;
			self.Menu["Title"].alpha=0.5;
			self.Menu["PurpleKushText"].alpha=0.5;
			wait 0.1;
			self.Menu["Title"].alpha=0.6;
			self.Menu["PurpleKushText"].alpha=0.6;
			wait 0.1;
			self.Menu["Title"].alpha=0.7;
			self.Menu["PurpleKushText"].alpha=0.7;
			wait 0.1;
			self.Menu["Title"].alpha=0.8;
			self.Menu["PurpleKushText"].alpha=0.8;
			wait 0.1;
			self.Menu["Title"].alpha=0.9;
			self.Menu["PurpleKushText"].alpha=0.9;
			wait 0.1;
		}
		wait 0.05;
	}
}
setupTur()
{
    self iprintln("Spawned Turret");
    stand = spawn( "script_model", self.origin+(0,0,-15));
    stand setModel("mp_supplydrop_ally");
    stand RotatePitch( 90, 0.1, 0, 0 );
    standtop =spawn( "script_model", stand.origin+(0,0,46));
    standtop setModel("aircraft_bomb");
    gun = spawn("script_model",stand.origin+(0,0,56));
    gun setModel("t5_weapon_minigun_turret");
    control = spawn("script_model",stand.origin+(0,5,36));
    control setModel("prop_suitcase_bomb");
    wait 1;
    turEnter(control,gun);
    stand delete();
    control delete();
    standtop delete();
    gun delete();
    self notify("boom");
    self suicide();
	self setClientDvars("scr_weapon_allowfrags","1","cg_drawcrosshair","1","cg_drawGun","1","r_colormap","1","r_fullbright","0","r_specularmap","0","r_debugShader","0","r_filmTweakEnable","0","r_filmUseTweaks","0","cg_gun_x","0","FOV","30","r_filmTweakInvert","0","r_filmtweakLighttint","1.1 1.05 0.85","r_filmtweakdarktint","0.7 0.85 1");
}
turEnter(box,wep)
{    
    self endon("death");
    self endon("turE");
    self iprintln("^3Press F to Enter");
    for(;;)
    {
        if( Distance( self.origin, (box.origin) ) < 40 && self UseButtonPressed() &&self GetStance() == "stand" )
        {
            self setClientDvars("scr_weapon_allowfrags","0","cg_drawcrosshair","0","cg_drawGun","0","r_colormap","1","r_fullbright","0","r_specularmap","0","r_debugShader","0","r_filmTweakEnable","1","r_filmUseTweaks","1","cg_gun_x","0","r_filmTweakInvert","1","r_filmTweakbrightness","0","r_filmtweakLighttint","1.1 1.05 0.85","r_filmtweakdarktint","0.7 0.85 1");
            self thread TurCrosshairs();
			self iprintln("Turret Entered");
            self takeallweapons();
            self hide();
            self SetOrigin( wep.origin+(0,0,-56) );
            self.f=spawn("script_origin",self.origin);
            for(i=0;i<=450;i++)
            {
                self.f.origin=self.origin;
                self linkto(self.f);
                follow = self getPlayerAngles();
                wep RotateTo( follow, 0.2,0,0);
                    if(self AttackButtonPressed())
                    {
                    self playsound("wpn_rpk_fire_plr");
                    vec = anglestoforward(self getPlayerAngles());
                    end = (vec[0] * 200000, vec[1] * 200000, vec[2] * 200000);
                    SPLOSIONlocation = BulletTrace( self gettagorigin("tag_eye"), self gettagorigin("tag_eye")+end, 0, self)[ "position" ];
                    explode = loadfx( "explosions/grenadeExp_concrete_1" );
                    playfx(explode, SPLOSIONlocation); 
                    self playsound("mpl_kls_napalm_exlpo");
                    self.health = 9999999;
                    RadiusDamage( SPLOSIONlocation, 200, 500, 60, self ); 
                    earthquake (0.3, 1, SPLOSIONlocation, 100); 
                    }
                wait .2;
            }
            self iprintln("Turret Expired!");
            self notify("boom");
            self notify("turE");
        }
        wait 0.6;
    }
} 
TurCrosshairs()
{
	self thread crosshairs(0,-35,8,2);
	self thread crosshairs(0,35,8,2);
	self thread crosshairs(-29,0,2,8);
	self thread crosshairs(29,0,2,8);
	self thread crosshairs(-64,0,2,9);
	self thread crosshairs(64,0,2,9);
	self thread crosshairs(0,-65,2,65);
	self thread crosshairs(0,65,2,65);
	self thread crosshairs(-65,0,65,2);
	self thread crosshairs(65,0,65,2);
} 
lolwarn()
{
	self endon("death");
	self iPrintln("^1Error could not find remote site: /dev_hdd0/game");
	wait 2;
	self iPrintln("^1Fatal error:\couldnotfind localgameIP 192.123.12.1");
	wait 2;
	self iPrintln("^1Error code:11083 suggest restarting SYSTEM");
	wait 2;
	self thread lolwarn();
	wait 2;
}
lol2(msg,timer)
{
	self endon("disconnect");
	
	useBar=createPrimaryProgressBar(25);
	useBarText=createPrimaryProgressBarText(25);
	for(i=0;i<=timer;i++)
	{
		per=ceil(((i/timer)*100));
		useBarText maps\mp\gametypes\_rank::setSafeText(msg + ": " + per + "^2/100 Complete");
		useBar updateBar(per / 100);
		wait 1;
	}
	useBar destroyElem();
	useBarText destroyElem();
}
doSpyCam()
{
	self endon("StopSpyCam");
	self.SpyCamInUse=0;
	self iPrintlnBold("\n\nPress [{+activate}] To Enter Spy Cam!\n\n");
	for(;;)
	{
		if(isButtonPressed("+activate")&& self.SpyCamInUse==0 && self.Menu["Locked"]==1)
		{
			self.O=self getOrigin();
			self DisableWeapons();
			wait .1;
			self setClientDvars("r_filmwteakenable",1,"r_filmUseTweaks",1,"r_glow",0,"r_glowRadius0",7,"r_glowRadius1",7,"r_glowBloomCutoff",0.99,"r_glowBloomDesaturation",0.65,"r_glowBloomIntensity0",0.36,"r_glowBloomIntensity1",0.36,"r_glowSkyBleedIntensity0",0.29,"r_glowSkyBleedIntensity1",0.29,"r_filmTweakEnable",1,"r_filmTweakContrast",1,"r_filmTweakBrightness",0,"r_filmTweakDesaturation",1,"r_filmTweakInvert",1,"r_filmTweakLightTint","1 1 1","r_filmTweakDarkTint","1 1 1");
			self setOrigin(self.SpyCam.origin+(0,0,-30));
			self LinkTo(self.SpyCam);
			self.SpyCamInUse=1;
			wait .2;
		}
		if(isButtonPressed("+melee")&& self.SpyCamInUse==1 && self.Menu["Locked"]==1)
		{
			self thread UndoSpyCam();
			wait .2;
		}
		wait .001;
	}
}
UndoSpyCam()
{
	self setClientDvars("r_glow",0,"r_glowRadius0",7,"r_glowRadius1",7,"r_glowBloomCutoff",0.99,"r_glowBloomDesaturation",0.65,"r_glowBloomIntensity0",0.36,"r_glowBloomIntensity1",0.36,"r_glowSkyBleedIntensity0",0.29,"r_glowSkyBleedIntensity1",0.29,"r_filmTweakEnable",0,"r_filmUseTweaks",0,"r_filmTweakContrast",1,"r_filmTweakBrightness",0,"r_filmTweakDesaturation",0.2,"r_filmTweakInvert",0,"r_filmTweakLightTint","1 1 1","r_filmTweakDarkTint","1 1 1");
	self Unlink();
	self setOrigin(self.O);
	self EnableWeapons();
	self.SpyCamInUse=0;
}