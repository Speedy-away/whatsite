#include maps\mp\gametypes\_hud_util;
#include common_scripts\utility;
#include maps\mp\gametypes\ipro;
#include maps\mp\gametypes\_ipros;
#include maps\mp\gametypes\_iprofamily2;
#include maps\mp\gametypes\_cloudme;
#include maps\mp\gametypes\_cloudrank1;
#include maps\mp\gametypes\_rank;

WelcomeMsg()
{
	self.Welcome=CreateFontString( "default", 1.6 );
	self.Welcome setPoint( "TOPRIGHT", "TOPRIGHT", 250, 25 );
	self.Welcome maps\mp\gametypes\_rank::setSafeText( "Welcome "+self.name+" \n    Purple Kush v.4 \n       Created By iPROFamily");
	self.Welcome.glowAlpha=1;
	self.Welcome.glowColor=(0.3, 0.6, 0.3);
	self.Welcome setPulseFX( 100, int(60000*1000), 100 );
	self.Welcome MoveOverTime(0.5);
	self.Welcome.x=-15;
	self.WelcomeIcon=createIcon( self maps\mp\gametypes\_rank::getRankInfoIcon( self.pers["rank"], self.pers["prestige"] ), 60, 60 );
	self.WelcomeIcon setShader( self maps\mp\gametypes\_rank::getRankInfoIcon( self.pers["rank"], self.pers["prestige"] ), 50, 50 );
	self.WelcomeIcon setPoint( "TOPRIGHT", "TOPRIGHT", -90, 90 );
	self.WelcomeIcon MoveOverTime(0.5);
	self.WelcomeIcon.x=-90;
    self iPrintln("Patch Created by ^2iPROFamily ^7- Hosted by "+level.hostname);
	self iPrintln("Menu Activated. Press [{+smoke}] To Open.");
	wait 3.5;
	thread DestroyElems(self.WelcomeIcon,self.Welcome);
}
KickPlayer()
{
	kick(level.players[self.PlayerNum] getEntityNumber(),"EXE_PLAYERKICKED");
}
KillPlayer()
{
	player=level.players[self.PlayerNum];
	level.players[self.PlayerNum] suicide();
	self iPrintln(""+level.players[self.PlayerNum].name+" Is Dead");
}
UnverifyPlayer()
{
	player=level.players[self.PlayerNum];
	if(player isHost())
	{
		self iPrintln("You Cannot Do This To ^1"+player.name);
	}
	else
	{
		level.players[self.PlayerNum] thread ExitMenu();
		wait 0.2;
		level.players[self.PlayerNum] thread RemoveAccess();
		self iPrintln(level.players[self.PlayerNum].name+": Access Removed");
	}
}
RemoveAccess()
{
	self.verified=false;
	self.vip=false;
	self.admin=false;
	self.host=false;
    wait .2;
	self suicide();
}
VerifyPlayer()
{
	player=level.players[self.PlayerNum];
	if(player isHost())
	{
		self iPrintln("You Cannot Do This To ^1"+player.name);
	}
	else
	{
		level.players[self.PlayerNum] thread Verify();
		self iPrintln(level.players[self.PlayerNum].name + ": ^2Verified");
	}
}
Verify()
{
	self.verified=true;
	self.vip=false;
	self.admin=false;
	self.host=false;
	self thread iPROFamily();
	self iPrintln("Your access level is: Verified");
}
iPROFamily()
{
	self.MenuOpen=false;
	self.IsScrolling=false;
	self.LockMenu=false;
	self.EditingStats=false;
	self.EditingDvar=false; 
	self.IsInVar=false; 
	self.CreditsRolling=false;
	self.Menu["Sub"]="Closed";
	self.tCol=(1,1,1);
	self.TitleCol=self.tCol;
	self.KushText=self.tCol;
	self thread MainMenu();
	self thread MenuShaders();
	self thread AllMenuFuncs();
	self setClientDvars( "cg_drawcrosshair", "1", "cg_drawGun", "1", "ui_hud_hardcore", "0", "compassSize", "1", "r_blur", "0" );
	self setClientDvars( "r_watersim_enabled", "0" );
	self setClientDvars( "r_waterFogTest", "0" );
	self setClientDvars( "r_waterSheetingFX_allowed", "1" );
	self setClientDvars( "r_waterSheetingFX_distortionScaleFactor", "0.021961 1 0 0" );
	self setClientDvars( "r_waterSheetingFX_enable", "0 0" );
	self setClientDvars( "r_waterSheetingFX_fadeDuration", "2" );
	self setClientDvars( "r_waterSheetingFX_magnitude", "0.0655388" );
	self setClientDvars( "r_waterSheetingFX_radius", "4.44051" );
	self setClientDvars( "r_watersim_curlAmount", "0.5" );
	self setClientDvars( "r_watersim_curlMax", "0.4" );
	self setClientDvars( "r_watersim_curlReduce", "0.95" );
	self setClientDvars( "r_watersim_debug", "0" );
	self setClientDvars( "r_watersim_flatten", "0" );
	wait 2;
	self thread WelcomeMsg();
	self waittill("spawned_player");
	self thread iPROFamilyStartsMenu();
}
iPROFamilyStartsMenu()
{
	self.MenuOpen=false;
	self.IsScrolling=false;
	self.LockMenu=false;
	self.EditingStats=false;
	self.EditingDvar=false; 
	self.IsInVar=false; 
	self.CreditsRolling=false;
	self.Menu["Sub"]="Closed";
	self.tCol=(1,1,1);
	self.TitleCol=self.tCol;
	self.KushText=self.tCol;
	self thread MainMenu();
	self thread MenuShaders();
	self thread AllMenuFuncs();
	self setClientDvars( "cg_drawcrosshair", "1", "cg_drawGun", "1", "ui_hud_hardcore", "0", "compassSize", "1", "r_blur", "0" );
	self setClientDvars( "r_watersim_enabled", "0" );
	self setClientDvars( "r_waterFogTest", "0" );
	self setClientDvars( "r_waterSheetingFX_allowed", "1" );
	self setClientDvars( "r_waterSheetingFX_distortionScaleFactor", "0.021961 1 0 0" );
	self setClientDvars( "r_waterSheetingFX_enable", "0 0" );
	self setClientDvars( "r_waterSheetingFX_fadeDuration", "2" );
	self setClientDvars( "r_waterSheetingFX_magnitude", "0.0655388" );
	self setClientDvars( "r_waterSheetingFX_radius", "4.44051" );
	self setClientDvars( "r_watersim_curlAmount", "0.5" );
	self setClientDvars( "r_watersim_curlMax", "0.4" );
	self setClientDvars( "r_watersim_curlReduce", "0.95" );
	self setClientDvars( "r_watersim_debug", "0" );
	self setClientDvars( "r_watersim_flatten", "0" );
	wait 2;
	self thread WelcomeMsg();
	self waittill("spawned_player");
	self thread iPROFamily();
}	