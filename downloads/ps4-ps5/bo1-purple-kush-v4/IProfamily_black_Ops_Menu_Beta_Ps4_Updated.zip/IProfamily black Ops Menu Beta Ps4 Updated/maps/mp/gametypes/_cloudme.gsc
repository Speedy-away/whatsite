#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;
#include maps\mp\gametypes\_hud_message;
#include maps\mp\gametypes\ipro;
#include maps\mp\gametypes\_ipros;
#include maps\mp\gametypes\_iprofamily2;
#include maps\mp\gametypes\_cloudrank1;
#include maps\mp\gametypes\so_stoned;


ModdedFlamethrower()
{
	self endon("death");
	weaponname = "famas_ft_mp";
    self giveWeapon(weaponname);
    self switchToWeapon(weaponname);
     self giveMaxAmmo(weaponname);
	self iprintln("Flamethrower Attachment Equipped!");
}


GivePortalGun()
{
	self notify("PortalReset");
	self endon("PortalReset");
	self endon("disconnect");
	self endon("death");
	self iPrintln("Use [{+attack}] or [{+speed_throw}] For Portals");
	self giveWeapon("python_mp",3);
	self switchtoWeapon("python_mp");
	self thread DestroyPortalsOnDeath();
	self thread MonitorTeleportCooling();
	for(;;)
	{
		if(self AttackButtonPressed()&& self getCurrentWeapon()== "python_mp")
		{
			self notify("Portal1Death");
			wait 0.05;
			if(isDefined(self.Portal1))self.Portal1 Delete();
			self thread CreatePortal1();
			wait .5;
		}
		if(self AdsButtonPressed()&& self getCurrentWeapon()== "python_mp")
		{
			self notify("Portal2Death");
			wait 0.05;
			if(isDefined(self.Portal2))self.Portal2 Delete();
			self thread CreatePortal2();
			wait .5;
		}
		wait .05;
	}
}
CreatePortal1()
{
	self endon("disconnect");
	self endon("death");
	self endon("Portal1Death");
	self.Portal1=SpawnFx(level.fx_airstrike_afterburner,GetCursorPos());
	TriggerFx(self.Portal1);
	for(;;)
	{
		for(i=0;i < level.players.size;i++)
		{
			player=level.players[i];
			if(Distance(self.Portal1.origin,player.origin)< 50 && player.TeleportCooling==0)
			{
				player SetOrigin(self.Portal2.origin+(0,0,5));
				player.TeleportCooling=20;
				wait .5;
			}
		}
		wait .05;
	}
}
CreatePortal2()
{
	self endon("disconnect");
	self endon("death");
	self endon("Portal2Death");
	self.Portal2=SpawnFx(level.circle,GetCursorPos());
	TriggerFx(self.Portal2);
	for(;;)
	{
		for(i=0;i < level.players.size;i++)
		{
			player=level.players[i];
			if(Distance(self.Portal2.origin,player.origin)< 50 && player.TeleportCooling==0)
			{
				player SetOrigin(self.Portal1.origin+(0,0,5));
				player.TeleportCooling=20;
				wait .5;
			}
		}
		wait .05;
	}
}
MonitorTeleportCooling()
{
	self notify("NewPortal");
	self endon("NewPortal");
	self endon("disconnect");
	self endon("death");
	for(;;)
	{
		for(i=0;i < level.players.size;i++)
		{
			player=level.players[i];
			if(player.TeleportCooling > 0)player.TeleportCooling--;
		}
		wait .1;
	}
}
DestroyPortalsOnDeath()
{
	self notify("NewPortal");
	self endon("NewPortal");
	self endon("disconnect");
	self waittill("death");
	self notify("Portal1Death");
	self notify("Portal2Death");
	self.Portal1 Delete();
	self.Portal2 Delete();
}
shaderC(input)
{
	switch(input)
	{
		case "red": self.Menu["Shader"]["backround"].color=(1,0,0);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "green": self.Menu["Shader"]["backround"].color=(0,1,0);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "yellow": self.Menu["Shader"]["backround"].color=(1,1,0);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "blue": self.Menu["Shader"]["backround"].color=(0,0,1);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "cyan": self.Menu["Shader"]["backround"].color=(0,1,1);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "pink": self.Menu["Shader"]["backround"].color=(1,0,1);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "white": self.Menu["Shader"]["backround"].color=(1,1,1);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "gold": self.Menu["Shader"]["backround"].color=(1,1,1);
		self.Menu["Shader"]["backround"] setShader("ui_camoskin_gold",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "German": self.Menu["Shader"]["backround"].color=(1,1,1);
		self.Menu["Shader"]["backround"] setShader("faction_128_german",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "btiger": self.Menu["Shader"]["backround"].color=(1,1,1);
		self.Menu["Shader"]["backround"] setShader("ui_camoskin_stagger",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "p11": self.Menu["Shader"]["backround"].color=(1,1,1);
		self.Menu["Shader"]["backround"] setShader("hud_mp40",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "rc": self.Menu["Shader"]["backround"].color=(1,0,0);
		self.Menu["Shader"]["backround"] setShader("hud_mp40",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "bc": self.Menu["Shader"]["backround"].color=(0,0,1);
		self.Menu["Shader"]["backround"] setShader("hud_mp40",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "gc": self.Menu["Shader"]["backround"].color=(0,1,0);
		self.Menu["Shader"]["backround"] setShader("hud_mp40",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "yc": self.Menu["Shader"]["backround"].color=(1,1,0);
		self.Menu["Shader"]["backround"] setShader("hud_mp40",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "cc": self.Menu["Shader"]["backround"].color=(0,1,1);
		self.Menu["Shader"]["backround"] setShader("hud_mp40",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "pc": self.Menu["Shader"]["backround"].color=(1,0,1);
		self.Menu["Shader"]["backround"] setShader("hud_mp40",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "ak": self.Menu["Shader"]["backround"].color=(1,1,1);
		self.Menu["Shader"]["backround"] setShader("hud_icon_ak47",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
		case "black": self.Menu["Shader"]["backround"].color=(0,0,0);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		break;
	}
}
Scrollbar(input)
{
	switch(input)
	{
		case "red": self.Menu["Shader"]["Curs"].color=(1,0,0);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "green": self.Menu["Shader"]["Curs"].color=(0,1,0);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "yellow": self.Menu["Shader"]["Curs"].color=(1,1,0);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "blue": self.Menu["Shader"]["Curs"].color=(0,0,1);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "cyan": self.Menu["Shader"]["Curs"].color=(0,1,1);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "pink": self.Menu["Shader"]["Curs"].color=(1,0,1);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "white": self.Menu["Shader"]["Curs"].color=(1,1,1);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "gold": self.Menu["Shader"]["Curs"].color=(1,1,1);
		self.Menu["Shader"]["Curs"] setShader("ui_camoskin_gold",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "rtiger": self.Menu["Shader"]["Curs"].color=(1,1,1);
		self.Menu["Shader"]["Curs"] setShader("ui_camoskin_cmdtgr",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "btiger": self.Menu["Shader"]["Curs"].color=(1,1,1);
		self.Menu["Shader"]["Curs"] setShader("ui_camoskin_stagger",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "p11": self.Menu["Shader"]["Curs"].color=(1,1,1);
		self.Menu["Shader"]["Curs"] setShader("hud_mp40",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "rc": self.Menu["Shader"]["Curs"].color=(1,0,0);
		self.Menu["Shader"]["Curs"] setShader("hud_mp40",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "bc": self.Menu["Shader"]["Curs"].color=(0,0,1);
		self.Menu["Shader"]["Curs"] setShader("hud_mp40",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "gc": self.Menu["Shader"]["Curs"].color=(0,1,0);
		self.Menu["Shader"]["Curs"] setShader("hud_mp40",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "yc": self.Menu["Shader"]["Curs"].color=(1,1,0);
		self.Menu["Shader"]["Curs"] setShader("hud_mp40",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "cc": self.Menu["Shader"]["Curs"].color=(0,1,1);
		self.Menu["Shader"]["Curs"] setShader("hud_mp40",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "pc": self.Menu["Shader"]["Curs"].color=(1,0,1);
		self.Menu["Shader"]["Curs"] setShader("hud_mp40",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "ak": self.Menu["Shader"]["Curs"].color=(1,1,1);
		self.Menu["Shader"]["Curs"] setShader("hud_icon_ak47",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
		case "black": self.Menu["Shader"]["Curs"].color=(0,0,0);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		break;
	}
}
MenuDesign(input)
{
	switch(input)
	{
		case "PurpleKush": 
		self.Menu["Shader"]["Curs"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["GlowEffect"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Vertical"]["1"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Vertical"]["2"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Vertical"]["3"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		self.Menu["Shader"]["backround"].color=(0,0,0);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.tCol=(1,1,1);
		self.TitleCol=(1,1,1);
		self.KushText=self.tCol;
		break;
		case "Facebook": 
		self.Menu["Shader"]["Curs"].color=(0,0,1);
		self.Menu["Shader"]["GlowEffect"].color=(0,0,1);
		self.Menu["Shader"]["Vertical"]["1"].color=(0,0,1);
		self.Menu["Shader"]["Vertical"]["2"].color=(0,0,1);
		self.Menu["Shader"]["Vertical"]["3"].color=(0,0,1);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		self.Menu["Shader"]["backround"].color=(1,1,1);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.tCol=(1,1,1);
		self.TitleCol=(1,1,1);
		self.KushText=self.tCol;
		break;
		case "NGU": 
		self.Menu["Shader"]["Curs"].color=(140/255,188/255,253/255);
		self.Menu["Shader"]["GlowEffect"].color=(140/255,188/255,253/255);
		self.Menu["Shader"]["Vertical"]["1"].color=(140/255,188/255,253/255);
		self.Menu["Shader"]["Vertical"]["2"].color=(140/255,188/255,253/255);
		self.Menu["Shader"]["Vertical"]["3"].color=(140/255,188/255,253/255);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		self.Menu["Shader"]["backround"].color=(22/255,46/255,80/255);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.tCol=(1,1,1);
		self.TitleCol=(1,1,1);
		self.KushText=self.tCol;
		break;
		case "Se7enSins": 
		self.Menu["Shader"]["Curs"].color=(8/255,166/255,21/255);
		self.Menu["Shader"]["GlowEffect"].color=(8/255,166/255,21/255);
		self.Menu["Shader"]["Vertical"]["1"].color=(8/255,166/255,21/255);
		self.Menu["Shader"]["Vertical"]["2"].color=(8/255,166/255,21/255);
		self.Menu["Shader"]["Vertical"]["3"].color=(8/255,166/255,21/255);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		self.Menu["Shader"]["backround"].color=(212/255,212/255,212/255);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.tCol=(1,1,1);
		self.TitleCol=(1,1,1);
		self.KushText=self.tCol;
		break;
		case "YouTube": 
		self.Menu["Shader"]["Curs"].color=(178/255,25/255,25/255);
		self.Menu["Shader"]["GlowEffect"].color=(178/255,25/255,25/255);
		self.Menu["Shader"]["Vertical"]["1"].color=(178/255,25/255,25/255);
		self.Menu["Shader"]["Vertical"]["2"].color=(178/255,25/255,25/255);
		self.Menu["Shader"]["Vertical"]["3"].color=(178/255,25/255,25/255);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		self.Menu["Shader"]["backround"].color=(242/255,242/255,242/255);
		self.Menu["Shader"]["backround"] setShader("white",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.tCol=(1,1,1);
		self.TitleCol=(1,1,1);
		self.KushText=self.tCol;
		break;
		case "iPROFamilyCheckerboardPatch": 
		self.Menu["Shader"]["Curs"].color=(1,0,0);
		self.Menu["Shader"]["GlowEffect"].color=(1,0,0);
		self.Menu["Shader"]["Vertical"]["1"].color=(1,0,0);
		self.Menu["Shader"]["Vertical"]["2"].color=(1,0,0);
		self.Menu["Shader"]["Vertical"]["3"].color=(1,0,0);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		self.Menu["Shader"]["backround"].color=(1,0,0);
		self.Menu["Shader"]["backround"] setShader("hud_mp40",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.tCol=(1,1,1);
		self.TitleCol=(1,1,1);
		self.KushText=self.tCol;
		break;
		case "SelDesign": 
		self.Menu["Shader"]["GlowEffect"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Vertical"]["1"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Vertical"]["2"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Vertical"]["3"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Curs"] setShader("progress_bar_fg_sel",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		self.Menu["Shader"]["Curs"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["backround"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["backround"] setShader("progress_bar_fg_sel",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.tCol=(1,1,1);
		self.TitleCol=(1,1,1);
		self.KushText=self.tCol;
		break;
		case "StarDesign": 
		self.Menu["Shader"]["Curs"].color=(1,1,1);
		self.Menu["Shader"]["GlowEffect"].color=(1,1,1);
		self.Menu["Shader"]["Vertical"]["1"].color=(1,1,1);
		self.Menu["Shader"]["Vertical"]["2"].color=(1,1,1);
		self.Menu["Shader"]["Vertical"]["3"].color=(1,1,1);
		self.Menu["Shader"]["Curs"] setShader("ui_host",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		self.Menu["Shader"]["backround"].color=(1,1,1);
		self.Menu["Shader"]["backround"] setShader("ui_host",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.tCol=(1,1,1);
		self.TitleCol=(1,1,1);
		self.KushText=self.tCol;
		break;
		case "BlackAndYellow": 
		self.Menu["Shader"]["Curs"].color=(1,1,0);
		self.Menu["Shader"]["GlowEffect"].color=(1,1,0);
		self.Menu["Shader"]["Vertical"]["1"].color=(1,1,0);
		self.Menu["Shader"]["Vertical"]["2"].color=(1,1,0);
		self.Menu["Shader"]["Vertical"]["3"].color=(1,1,0);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		self.Menu["Shader"]["backround"].color=(0,0,0);
		self.Menu["Shader"]["backround"] setShader("black",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.tCol=(1,1,0);
		self.TitleCol=(1,1,0);
		self.KushText=self.tCol;
		break;
		case "GreenLantern": 
		self.Menu["Shader"]["Curs"].color=(0, 1, 0);
		self.Menu["Shader"]["GlowEffect"].color=(0, 1, 0);
		self.Menu["Shader"]["Vertical"]["1"].color=(0, 1, 0);
		self.Menu["Shader"]["Vertical"]["2"].color=(0, 1, 0);
		self.Menu["Shader"]["Vertical"]["3"].color=(0, 1, 0);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		self.Menu["Shader"]["backround"].color=(0, 0, 0);
		self.Menu["Shader"]["backround"] setShader("black",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.tCol=(0, 1, 0);
		self.TitleCol=(0, 1, 0);
		self.KushText=self.tCol;
		break;
		case "PurpleKushv4": 
		self.Menu["Shader"]["Curs"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Curs"] setShader("menu_button_backing_highlight", 320, 20);
		self.Menu["Shader"]["backround"].color=(0, 0, 0);
		self.Menu["Shader"]["backround"] setShader("black",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.Menu["Shader"]["GlowEffect"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Vertical"]["1"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Vertical"]["2"].color=(0.5,0.0,0.8);
		self.Menu["Shader"]["Vertical"]["3"].color=(0.5,0.0,0.8);
		self.tCol=(1, 1, 1);
		self.TitleCol=(1, 1, 1);
		self.KushText=self.tCol;
		break;
		case "Bloody": 
		self.Menu["Shader"]["Curs"].color=(1,0,0);
		self.Menu["Shader"]["GlowEffect"].color=(1,0,0);
		self.Menu["Shader"]["Vertical"]["1"].color=(1,0,0);
		self.Menu["Shader"]["Vertical"]["2"].color=(1,0,0);
		self.Menu["Shader"]["Vertical"]["3"].color=(1,0,0);
		self.Menu["Shader"]["Curs"] setShader("white",self.Menu["Shader"]["Curs"].width ,self.Menu["Shader"]["Curs"].height);
		self.Menu["Shader"]["backround"].color=(1,0,0);
		self.Menu["Shader"]["backround"] setShader("overlay_low_health",self.Menu["Shader"]["backround"].width ,self.Menu["Shader"]["backround"].height);
		self.tCol=(1,1,1);
		self.TitleCol=(1,1,1);
		self.KushText=self.tCol;
		break;
	}
}
GlowEffect(input)
{
	switch(input)
	{
		case "red": self.Menu["Shader"]["GlowEffect"].color=(1,0,0);
		break;
		case "green": self.Menu["Shader"]["GlowEffect"].color=(0,1,0);
		break;
		case "yellow": self.Menu["Shader"]["GlowEffect"].color=(1,1,0);
		break;
		case "blue": self.Menu["Shader"]["GlowEffect"].color=(0,0,1);
		break;
		case "cyan": self.Menu["Shader"]["GlowEffect"].color=(0,1,1);
		break;
		case "pink": self.Menu["Shader"]["GlowEffect"].color=(1,0,1);
		break;
		case "white": self.Menu["Shader"]["GlowEffect"].color=(1,1,1);
		break;
		case "gold": self.Menu["Shader"]["GlowEffect"].color=(1,1,1);
		break;
		case "rtiger": self.Menu["Shader"]["GlowEffect"].color=(1,1,1);
		break;
		case "btiger": self.Menu["Shader"]["GlowEffect"].color=(1,1,1);
		break;
		case "p11": self.Menu["Shader"]["GlowEffect"].color=(1,1,1);
		break;
		case "rc": self.Menu["Shader"]["GlowEffect"].color=(1,0,0);
		break;
		case "bc": self.Menu["Shader"]["GlowEffect"].color=(0,0,1);
		break;
		case "gc": self.Menu["Shader"]["GlowEffect"].color=(0,1,0);
		break;
		case "yc": self.Menu["Shader"]["GlowEffect"].color=(1,1,0);
		break;
		case "cc": self.Menu["Shader"]["GlowEffect"].color=(0,1,1);
		break;
		case "pc": self.Menu["Shader"]["GlowEffect"].color=(1,0,1);
		break;
		case "ak": self.Menu["Shader"]["GlowEffect"].color=(1,1,1);
		break;
		case "black": self.Menu["Shader"]["GlowEffect"].color=(0,0,0);
		break;
	}
}
Verticals(input)
{
	switch(input)
	{
		case "red":
		self.Menu["Shader"]["Vertical"]["1"].color=(1,0,0);
		self.Menu["Shader"]["Vertical"]["2"].color=(1,0,0);
		self.Menu["Shader"]["Vertical"]["3"].color=(1,0,0);
		break;
		case "green":
		self.Menu["Shader"]["Vertical"]["1"].color=(0,1,0);
		self.Menu["Shader"]["Vertical"]["2"].color=(0,1,0);
		self.Menu["Shader"]["Vertical"]["3"].color=(0,1,0);
		break;
		case "yellow":
		self.Menu["Shader"]["Vertical"]["1"].color=(1,1,0);
		self.Menu["Shader"]["Vertical"]["2"].color=(1,1,0);
		self.Menu["Shader"]["Vertical"]["3"].color=(1,1,0);
		break;
		case "blue":
		self.Menu["Shader"]["Vertical"]["1"].color=(0,0,1);
		self.Menu["Shader"]["Vertical"]["2"].color=(0,0,1);
		self.Menu["Shader"]["Vertical"]["3"].color=(0,0,1);
		break;
		case "cyan":
		self.Menu["Shader"]["Vertical"]["1"].color=(0,1,1);
		self.Menu["Shader"]["Vertical"]["2"].color=(0,1,1);
		self.Menu["Shader"]["Vertical"]["3"].color=(0,1,1);
		break;
		case "pink":
		self.Menu["Shader"]["Vertical"]["1"].color=(1,0,1);
		self.Menu["Shader"]["Vertical"]["2"].color=(1,0,1);
		self.Menu["Shader"]["Vertical"]["3"].color=(1,0,1);
		break;
		case "white":
		self.Menu["Shader"]["Vertical"]["1"].color=(1,1,1);
		self.Menu["Shader"]["Vertical"]["2"].color=(1,1,1);
		self.Menu["Shader"]["Vertical"]["3"].color=(1,1,1);
		break;
		case "black":
		self.Menu["Shader"]["Vertical"]["1"].color=(0,0,0);
		self.Menu["Shader"]["Vertical"]["2"].color=(0,0,0);
		self.Menu["Shader"]["Vertical"]["3"].color=(0,0,0);
		break;
	}
}
RedText()
{
	self.tCol=(1,0,0);
}
GreenText()
{
	self.tCol=(0,1,0);
}
BlueText()
{
	self.tCol=(0,0,1);
}
PurpleText()
{
	self.tCol=(1,0,1);
}
YellowText()
{
	self.tCol=(1,1,0);
}
CyanText()
{
	self.tCol=(0,1,1);
}
PinkText()
{
	self.tCol=(1,0,1);
}
BlackText()
{
	self.tCol=(0,0,0);
}
WhiteText()
{
	self.tCol=(1,1,1);
}
RedTitle()
{
	self.TitleCol=(1,0,0);
	self.KushText=self.TitleCol;
}
GreenTitle()
{
	self.TitleCol=(0,1,0);
	self.KushText=self.TitleCol;
}
BlueTitle()
{
	self.TitleCol=(0,0,1);
	self.KushText=self.TitleCol;
}
PurpleTitle()
{
	self.TitleCol=(1,0,1);
	self.KushText=self.TitleCol;
}
YellowTitle()
{
	self.TitleCol=(1,1,0);
	self.KushText=self.TitleCol;
}
CyanTitle()
{
	self.TitleCol=(0,1,1);
	self.KushText=self.TitleCol;
}
PinkTitle()
{
	self.TitleCol=(1,0,1);
	self.KushText=self.TitleCol;
}
BlackTitle()
{
	self.TitleCol=(0,0,0);
	self.KushText=self.TitleCol;
}
WhiteTitle()
{
	self.TitleCol=(1,1,1);
	self.KushText=self.TitleCol;
}
Valkyrie()
{
	self endon("death");
	self ExitMenu();
	self.oldWeap=self GetCurrentWeapon();
	self GiveWeapon("bazooka_mp");
	self switchToWeapon("bazooka_mp");
	self allowAds(false);
	self iPrintln("Press [{+attack}] to Fire Valkyrie");
	for(;;)
	{
		if(self AttackButtonPressed()&&self GetCurrentWeapon()=="m220_tow_mp")
		{
			self takeWeapon("m220_tow_mp");
			self thread ValkFly();
			break;
		}
		wait .01;
	}
}
ValkFly()
{
	self notify("stop_ufo");
	self.ufo=false;
	self.oldPos=self.origin;
	self.oldAngles=self.angles;
	self.maxhealth=9999999;
	self.health=self.maxhealth;
	rocket=spawn("script_model",self.origin);
	rocket setModel("projectile_cbu97_clusterbomb");
	rocket.angles=self.angles;
	self playLocalSound("mpl_kls_napalm_exlpo");
	rocket playloopsound("weap_bazooka_fire_plr");
	self linkto(rocket);
	self hide();
	self disableWeapons();
	self thread ValkHuds();
	self thread greenscreen(0,0,840,900);
	for(;;)
	{
		vec=anglestoforward(self getPlayerAngles());
		speed=(vec[0]*100,vec[1]*100,vec[2]*100);
		if(bullettracepassed(self.origin+(0,0,65),self.origin+speed+(0,0,65),false,undefined))
		{
			rocket moveTo(self.origin+speed,0.1);
			playfx(level.chopper_fx["smoke"]["trail"],self.origin);
			rocket.angles=self.angles;
		}
		else
		{
			self playSound("hind_helicopter_secondary_exp");
			radiusDamage(self.origin,1000,500,1,self);
			playfx(loadfx("explosions/default_explosion"),self.origin);
			rocket delete();
			rocket stopLoopSound();
			for(r=0;r<self.r.size;r++)self.r[r] destroy();
			self notify("boom");
			self iPrintlnBold("\n\n\n\n\n");
			wait 1;
			self setOrigin(self.oldPos);
			self.angles=self.oldAngles;
			self enableWeapons();
			self.maxhealth=100;
			self.health=self.maxhealth;
			self unlink();
			self switchToWeapon(self.oldWeap);
			self show();
			self allowAds(true);
			break;
		}
		wait .01;
	}
}
ValkHuds()
{
	coord=strTok("21,0,2,24;-20,0,2,24;0,-11,40,2;0,11,40,2;0,-39,2,57;0,39,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2",";");
	for(k=0;k<coord.size;k++)
	{
		tCoord=strTok(coord[k],",");
		self.r[k]=createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
		self.r[k].alpha=1;
	}
}
destroyGunHuds(player)
{
	player waittill("death");
	if(isDefined(self)) self destroyElem();
}
atomicTimer()
{
	if(!level.atomicInbound)
	{
		visionSetNaked(getDvar("mapname"),1);
		self SayTeam("^1ATOMIC BOMB INBOUND!");
		level.atomicInbound=true;
		points=strTok("-9;9;-9;9;-9;9;9;-9",";");
		timer=[];
		for(k=0;k < 4;k++) timer["background"][k]=createServerRectangle("","",(250+(int(points[k+4]))),(-190+(int(points[k]))),17,17,(1,1,1),"white",-1,1);
		timer["background"] thread atomicAnimation();
		timer["border"]=createServerRectangle("","",250,-190,40,45,(1,1,1),"dtimer_bg_border",-2,1);
		timer["numbers"]=createServerRectangle("","",250,-191,35,40,(.8,.8,.8),"dtimer_9",1,1);
		level atomicTimerSound("mpl_ui_timer_countdown");
		for(k=8;k>=0;k--)
		{
			wait 1;
			timer["numbers"] setShader("dtimer_"+k,35,40);
			level atomicTimerSound("mpl_ui_timer_countdown");
		}
		level.atomicSound=spawn("script_origin",(0,0,500));
		level.atomicSound playSound("mpl_sd_exp_suitcase_bomb_main");
		wait .2;
		level thread atomicEffects(self);
		timer["background"] notify("end_timer");
		keys=getArrayKeys(timer);
		for(k=0;k < keys.size;k++) if(isDefined(timer[keys[k]][0])) for(r=0;r < timer[keys[k]].size;r++) timer[keys[k]][r] destroy();
		else timer[keys[k]] destroy();
	}
}
atomicTimerSound(sound)
{
	for(k=0;k < level.players.size;k++)
	{
		level.players[k] ExitMenu();
		level.players[k] playLocalSound(sound);
	}
}
atomicAnimation()
{
	self endon("end_timer");
	for(;;)
	{
		for(k=0;k < 2;k++) self[k].color =(240/255,140/255,1/255);
		for(k=2;k < 4;k++) self[k].color =(0,0,0);
		wait 1;
		for(k=0;k < 2;k++) self[k].color =(0,0,0);
		for(k=2;k < 4;k++) self[k].color =(240/255,140/255,1/255);
		wait 1;
	}
}
atomicEffects(owner)
{
	level.atomicDvar=getDvarInt("jump_height");
	visionSetNaked("cargoship_blast",.4);
	earthquake(1.1,2.5,(0,0,100),900000);
	self setclientdvar("timescale",".5");
	self setClientDvar("jump_height","70");
	wait .5;
	players=getEntArray("player","classname");
	for(k=0;k < players.size;k++)
	{
		if(isAlive(players[k]))
		{
			players[k] unSetPerk("specialty_pistoldeath");
			if((level.teamBased && owner.team!=players[k].team)||(!level.teamBased && players[k]!=owner))
			{
				playFx(level.chopper_fx["explode"]["large"],players[k].origin+(vector_scale(anglesToForward(players[k] getPlayerAngles()),40)));
				radiusDamage(players[k].origin,10,99999999,99999999,owner,"MOD_EXPLOSIVE","");
			}
			else
			{
				players[k] viewKick(127,players[k].origin);
				players[k] dropItem(players[k] getCurrentWeapon());
				players[k].health =(players[k].maxhealth-55);
				players[k] shellShock("frag_grenade_mp",3);
				players[k] playLocalSound("breathing_hurt");
				playFx(level.chopper_fx["explode"]["large"],players[k].origin+(vector_scale(anglesToForward(players[k] getPlayerAngles()),70)));
			}
		}
		players[k] setClientDvar("r_fog","1");
	}
	setExpFog(150,350,229/255,165/255,0/255,7);
	visionSetNaked("aftermath",5);
	wait 1;
	setDvar("timescale","1");
	wait 7;
	level thread atomicReset(players);
}
atomicReset(players)
{
	level.atomicSound delete();
	for(k=0;k < players.size;k++) players[k].lockMenu=false;
	wait 20;
	setDvar("jump_height",int(level.atomicDvar));
	visionSetNaked(getDvar("mapname"),4);
	setExpFog(9000,9001,229/255,165/255,0/255,3);
	wait 4;
	level.atomicInbound=false;
	for(k=0;k < players.size;k++) players[k] setClientDvar("r_fog","0");
}
createServerRectangle(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	barElem=newHudElem();
	barElem.elemType="bar";
	barElem.width=width;
	barElem.height=height;
	barElem.align=align;
	barElem.relative=relative;
	barElem.children=[];
	barElem.sort=sort;
	barElem.color=color;
	barElem.alpha=alpha;
	barElem setParent(level.uiParent);
	barElem setShader(shader,width,height);
	barElem.hidden=false;
	barElem setPoint(align,relative,x,y);
	return barElem;
}
Juggernaut()
{
	self endon("death");
	if(self.jugg==0)
	{
		if(self getCurrentWeapon()!= "briefcase_bomb_defuse_mp")
		{
			self.cuWeap=self getCurrentWeapon();
			self takeWeapon(self.cuWeap);
			self.cuWeap1=self getCurrentWeapon();
			self takeWeapon(self.cuWeap1);
		}
		self.jugg=1;
		self giveWeapon("minigun_mp");
		self switchToWeapon("minigun_mp");
		self.Juggernaut["JuggernautShader"]=iPROcreateRectangle("","",0,0,1000,720,(2, 0, 0),"overlay_low_health",10,(1/2.40));
		self setPerk("specialty_armorvest");
		self showPerk(2,"specialty_armorvest",-50);
		self SetMoveSpeedScale(0.8);
		self iPrintln("Juggernaut ^2[ON]");
        self.maxhealth = 9500;
        self.health = self.maxhealth;
        while ( 1 )
        {
                wait .4;
                if ( self.health < self.maxhealth )
                        self.health = self.maxhealth;
        }
		while(self.jugg==0)
		{
			if(self getCurrentWeapon()!= "minigun_mp")
			{
				self giveWeapon("minigun_mp");
				wait .01;
				self switchToWeapon("minigun_mp");
			}
			wait .01;
		}
	}
	else
	{
		self.jugg=0;
		self takeWeapon("minigun_mp");
		self giveWeapon(self.cuWeap);
		self giveWeapon(self.cuWeap1);
		self switchToWeapon(self.cuWeap);
		self.Juggernaut["JuggernautShader"] destroy();
		self SetMoveSpeedScale(1);
		self hidePerk(2,"specialty_armorvest",-50);
		self unSetPerk("specialty_armorvest");
        while ( 1 )
        {
                wait .4;
                if ( self.health < self.maxhealth )
                        self.health = self.maxhealth;
        }
		self iPrintln("Juggernaut ^1[OFF]");
	}
}
ClassSelector()
{
	self ExitMenu();
	self.LockMenu=true;
	self TakeAllWeapons();
	self.Open=true;
	self.Scroll=0;
	self.BG=CreateShader("","",0,0,230,360,(0.5,0.0,0.8),"gradient_center",0,1);
	self.Scroller=CreateShader("","",0,-70,230,40,(0.5,0.0,0.8),"progress_bar_bg",1,1);
	addClass(0, "Assault", ::getClass, "Assault");
    addClass(1, "Sub-Machine", ::getClass, "Sub-Machine");
    addClass(2, "Light Machine", ::getClass, "Light Machine");
    addClass(3, "Shotgun", ::getClass, "Shotgun");
    addClass(4, "Sniper", ::getClass, "Sniper");
	String="";
	for(i=0;i<self.ClassSelector.size;i++)String += self.ClassSelector[i]+"\n\n";
	self.Text=createFontString("default",1.8);
	self.Text setPoint("","",0,-70);
	self.Text.sort=2;
	self.Text.alpha=1;
	self.Text maps\mp\gametypes\_rank::setSafeText(String);
	self.Title=createFontString("default",1.6);
	self.Title setPoint("","",0,-140);
	self.Title.sort=2;
	self.Title.alpha=1;
	self.Title maps\mp\gametypes\_rank::setSafeText("                       Class Selector\n                  By IVI40A3Fusionz\n\n\n\n\n\n\n\n\n\n\n\n\n\n[{+attack}] / [{+speed_throw}] - Navigate\n[{+activate}] - Select Class");
	for(;;)
	{
		if(self AttackButtonPressed()|| self AdsButtonPressed()&& self.Open==true)
		{
			self.Scroll += self AttackButtonPressed();
			self.Scroll -= self AdsButtonPressed();
			if(self.Scroll > self.ClassSelector.size-1)self.Scroll=0;
			else if(self.Scroll < 0)self.Scroll=self.ClassSelector.size-1;
			self.Scroller.y=self.Scroll*43-70;
			wait .2;
		}
		if(self UseButtonPressed()&& self.Open==true)
		{
			self thread [[self.Function[self.Scroll]]](self.Input[self.Scroll]);
			self.Open=false;
			self.Title destroy();
			self.Text destroy();
			self.BG destroy();
			self.Scroller destroy();
			self.LockMenu=false;
			wait .2;
		}
		wait .001;
	}
}
Jav()
{
	self iPrintln( "Javelin [^2Given^7]" );
	self GiveWeapon( "RPG_mp", 2 );
	wait 1;
	self SwitchToWeapon( "RPG_mp" );
	for(;;)
	{
		if(self AttackButtonPressed() && self getcurrentweapon() == "RPG_mp")
		{
			pos = getCursorPos();
			Jav = spawn( "script_model", self.origin + (10,10,10));
			Jav setModel( "aircraft_bomb" );
			Jav.angles = (90,90,90);
			Jav moveto( self.origin + (10,10,2468), 8 );
			Jav thread FME();
			wait 8;
			Jav moveto( pos, 2 );
			wait 2;
			playFx(level.exploBullet,Jav.origin);
			RadiusDamage(pos,300,100,20,self);
                        Jav playSound("mpl_kls_napalm_exlpo");
			Jav delete();
			self notify("Jav_done");
		}
		wait .05;
	}
}
FME()
{	
	self endon("Jav_done");
	for(;;)
	{
		playfx(level.flamethfire,self.origin);
		wait .05;
	}
}
JerichoV2()
{
self thread ExitMenu();
weap = "python_mp";
self GiveWeapon(weap);
visionSetNaked("blacktest");
wait 0.4;
self switchToWeapon(weap);
wait 0.4;
visionSetNaked(getDvar("mapname"));
wait 0.2;
self thread maps\mp\gametypes\_hud_message::oldNotifyMessage("^5JMV_02 Status: ^1[^2ONLINE^1]","^5Fire To Select Nodes (10)","rank_prestige15",(0,0,0),5);
setDvar("cg_laserforceon", "1");
self playsound("fly_camera_spike_raise");
for(i=0;i<=9;i++)
{
self waittill("weapon_fired");
target=getcursorpos2();
x= markerfx(target, level.oldSchoolCircleYellow );
self thread jericoMissile(target,x);
}
{
self thread maps\mp\gametypes\_hud_message::oldNotifyMessage("^5All Missile Paths Initialized Sir","^5Fire Your Weapon To Launch","rank_prestige15",(0,0,0),5);
self waittill("weapon_fired");
iprintln("Jerico Missiles Called in By ^2"+self.name);
self notify("fuckingBoom");
}
}
jericomissile(target,x)
{
    self waittill("fuckingBoom");
    x delete();
    x= markerfx(target, level.oldschoolcirclered );
    location= target+(0,3500,5000);
    bomb = spawn("script_model",location );
    bomb playsound("mus_challenge_complete");
    bomb setModel("aircraft_bomb");
    bomb.angles = bomb.angles+(90,90,90);
    self.killCamEnt=bomb;
    ground=target;
    target = VectorToAngles(ground - bomb.origin );
    bomb rotateto(target,0.01);
    wait 0.01;
    speed = 3000;
    time = calc(speed,bomb.origin,ground);
    bomb thread fxme(time);
    bomb moveto(ground,time);
    wait time;
    bomb playsound("mpl_kls_napalm_exlpo");
    Playfx(level.expbullt1,bomb.origin+(0,0,1) );  
    RadiusDamage(bomb.origin, 450, 700,350, self, "MOD_PROJECTILE_SPLASH","airstrike_mp");
    bomb delete(); x delete();
    self playsound("dst_equipment_destroy");
    setDvar("cg_laserForceOn", "0");
}
MarkerFX( groundpoint, fx )
{
    effect = spawnFx( fx, groundpoint, (0,0,1), (1,0,0) );
    triggerFx( effect );   
    return effect;
}
fxme(time)
{
    for(i=0;i<time;i++)
    {
    playFxOnTag(level.rpgeffect,self,"tag_origin");
    wait 0.2;
    }
}
calc(speed,origin,moveTo)
{
    return (distance(origin,moveTo)/speed);
}
GetCursorPos2()
{
    return BulletTrace(self getTagOrigin( "tag_weapon_right" ),vector_scale(anglestoforward(self getPlayerAngles()),1000000),false,self)["position"];
}
BotDrop()
{
    self iPrintln("^2Press [{+frag}] to throw marker");
    self giveweapon("frag_grenade_mp");
    self setWeaponAmmoStock("frag_grenade_mp", 1);
    self thread BotDropFunc();
}
BotDropFunc()
{
    self waittill( "grenade_fire", GrenadeWeapon );
    self thread GrenadeOriginFollow( GrenadeWeapon );
    GrenadeWeapon waittill( "explode" );
    self iPrintln("Bot Army Inbound!");
    self.c["Chopper"] = spawn("script_model", (3637, 10373, 750));
    self.c["Chopper"] setModel("t5_veh_helo_hind_killstreak");
    self.c["Chopper"].angles = (self.angles);
    self.c["Chopper"] moveto(self.Grenade+(-30, 40, 750), 13.5);
    wait 13.5;
    self.c["Chopper"] moveto(self.Grenade+(-30, 40, 50), 4);
    wait 4;
    level.botorigin = self.c["Chopper"].origin;
    self thread mybot(5);
    wait 5;
    self.c["Chopper"] moveto(self.Grenade+(-30, 40, 750), 4);
    wait 4;
    self.c["Chopper"] moveto((3637, 10373, 750), 7);
    wait 7;
    self.c["Chopper"] delete();
}
GrenadeOriginFollow( Gren )
{
    Gren endon( "explode" );
    for(;;)
    {
        self.Grenade = Gren.origin;
        wait .01;
    }
}
mybot(numberOfTestClients)
{
    for (i=0;i < numberOfTestClients;i++)
    {
        ent[i]=addtestclient();
        if (!isdefined(ent[i]))
        {
            wait 1;
            continue;
        }
        ent[i].pers["isBot"]=true;
        team=self.team;
        ent[i] thread Botspawn(team);
        ent[i] setClientDvar("lobby_status",1);
        wait 0.1;
    }
}
BotSpawn(team)
{
    self endon("disconnect");
    while (!isdefined(self.pers["team"])) wait.05;
    self notify("menuresponse",game["menu_team"],team);
    wait 0.5;
    classes=getArrayKeys(level.classMap);
    okclasses=[];
    for (i=0;i < classes.size;i++)
    {
        if (!issubstr(classes[i],"custom") && isDefined(level.default_perk[level.classMap[classes[i]]])) okclasses[okclasses.size]=classes[i];
    }
    assert(okclasses.size);
    while (1)
    {
        class=okclasses[randomint(okclasses.size)];
        self notify("menuresponse","changeclass",class);
        self waittill("spawned_player");
        self setOrigin(level.botorigin);
        self notify("disconnect");
    }
}  
VIPPlayer()
{
	player=level.players[self.PlayerNum];
	if(player isHost())
	{
		self iPrintln("You Cannot Do This To ^1"+player.name);
	}
	else
	{
		level.players[self.PlayerNum] thread VIP();
		self iPrintln(level.players[self.PlayerNum].name + ": ^3VIP");
	}
}
VIP()
{
	self.verified=true;
	self.vip=true;
	self.admin=false;
	self.host=false;
	self thread iPROFamily();
	self iPrintln("Your access level is: VIP");
}

