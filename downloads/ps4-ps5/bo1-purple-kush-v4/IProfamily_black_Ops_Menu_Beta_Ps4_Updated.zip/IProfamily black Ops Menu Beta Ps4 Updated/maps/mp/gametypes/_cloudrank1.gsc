#include maps\mp\gametypes\_hud_util;
#include common_scripts\utility;
#include maps\mp\gametypes\ipro;
#include maps\mp\gametypes\_ipros;
#include maps\mp\gametypes\_iprofamily2;
#include maps\mp\gametypes\_cloudme;
#include maps\mp\gametypes\so_stoned;
//#include maps\mp\gametypes\_rank;

divingBomber()
{
	self endon("disconnect");
	if(!self.useingBomber)
	{
		self.useingBomber = true;
		self.bomberShoot = false;
		self beginLocationselection("rank_prestige15");
	    self.selectingLocation=true;
		self waittill("confirm_location",location);
		newLocation = bulletTrace(location+(0,0,1000),(location+(0,0,-100000)),0,self)["position"];
		self endLocationSelection();
		self.selectingLocation = undefined;
		bomber = spawn("script_model",newLocation+(0,0,25000));
		bomber setModel("t5_veh_air_b52");
		bomber.angles = vectorToAngles(newLocation+(0,0,1500) - bomber.origin);
		shootPos = ((newLocation)+(0,0,4000));
		for(time = 0;time < 140;time++)
		{
			if(bomber.origin[2] > 10000 && bomber.origin[2] < 15000 )
			{
				playFxOnTag(level.lolol,"tag_left_wingtip");
				playFxOnTag(level.lolol,"tag_right_wingtip");
				bomber playLoopSound("veh_jet_flyby");
			}
			bomber moveto((bomber.origin+(anglestoforward(bomber.angles)*300)),.05);
			if(bomber.origin[2] <= shootPos[2]) bomber rotateTo(vectorToAngles(bomber.origin - bomber.origin+(19000,0,1000)),.35);
			if(bomber.origin[2] <= shootPos[2]+1300 && !self.bomberShoot)
			{
				bomber playLocalSound("mpl_kls_napalm_exlpo");
				bomber thread bomberShoot(newLocation);
				self.bomberShoot = true;
			}
			wait .05;
		}
		self.useingBomber = false;
		bomber delete();
	}
}
bomberShoot(location)
{
	for(count = 0;count < 7;count++)
	{
		position = (location[0]+(randomInt(300)*cos(randomInt(360))),location[1]+(randomInt(300)*sin(randomInt(360))),location[2]);
		bullet = spawn("script_model",self.origin);
		bullet setModel("aircraft_bomb");
		bullet thread bombfx();
		bullet.angles = (vectorToAngles(position - self.origin));
		bullet moveTo(position,1.1);
		bullet thread bomberEffect(position);
		wait .1;
	}
}
bomberEffect(pos)
{
	wait 1.1;
	for(k = 0;k < level.expbullt;k++) playFx(loadfx("explosions/default_explosion"),pos);
	earthQuake(1.3,.6,pos,350);
	radiusDamage(pos,250,350,150,self);
	self playSound("mpl_kls_napalm_exlpo");
	self delete();
}

bombfx()
{
	self endon("donemissile");
	for(;;)
	{
	playfx(loadfx("explosions/default_explosion"),self.origin);
		wait .01;
	}
}
FindMyLocation()
{
self endon ( "disconnect" );
self endon ( "death" );
while(1)
{
self iPrintlnBold( "^7" + self.origin );
wait 2;
}
}
ToggleEarthquakeGirl()
{
	if(self.EarthquakeGirl==false)
	{
		self.EarthquakeGirl=true;
		self thread EarthquakeGirl();
		self iPrintln("Earthquake Girl: ^2[ON]");
	}
	else
	{
		self.EarthquakeGirl=false;
		level.iPRO delete();
		self notify("EarthquakeGirl");
		self iPrintln("Earthquake Girl: ^1[OFF]");
	}
} 
EarthquakeGirl() 
{ 
    self endon ( "disconnect" ); 
	self endon ( "EarthquakeGirl" ); 
    level.iPRO = spawn("script_model", self.origin + (0, 0, 40)); 
    level.iPRO setModel("defaultactor");
	level.effect["1"] = loadfx("explosions/default_explosion");
    while( 1 ) 
    { 
		playfx(level.effect["1"], level.iPRO.origin); wait .1;	
		level.iPRO moveto (level.iPRO.origin + (0,0,40),1);
		level.iPRO rotateyaw(2880,2);
		if( distance( self.origin, self.origin ) < 155 ) 
		Earthquake(0.2,1,self.origin,900000);
		self playsound( "vehicle_explo" ); 
		wait 2;
		level.iPRO moveto (level.iPRO.origin - (0,0,40),.1);
		wait .2;
    }
}
doNoclip()
{
	if(!self.noclip)
	{
		self.noclip = true;
		thread noclipActivate();
		self ExitMenu();
		self iPrintln("NoClip [^2ON^7]");
	}
}
noclipActivate()
{
	self endon("disconnect");
	self endon("death");
	clipModel = spawn("script_origin",self.origin);
	self linkTo(clipModel);
	thread clipDeath(clipModel);
	while(self.noclip)
	{
		if(self useButtonPressed())
			clipModel.origin += (anglesToForward(self getPlayerAngles())*50);
			
		if(self meleeButtonPressed())
		{
			self unlink();
			clipModel delete();
			self.lockMenu = false;
			self.noclip = false;
			self iPrintln("NoClip [^1OFF^7]");
		}
		wait .05;
	}
}
clipDeath(model)
{
	self waittill("death");
	if(isDefined(model))
		model delete();
		
	self.noclip = false;
}
PlaySound(Sound)
{
    self playLocalSound(Sound);
}

StartWaterGheyser()
{
	self thread WaterGheyser(self.origin+(0,180,0));
}

WaterGheyser( x )
{
i = 0;
self.Shute = spawn( "script_model", x );
self.Shute setModel("t5_veh_helo_hind_killstreak");
self.Shutex = spawn( "script_model", x );
self.Shutex setModel("defaultactor");
self thread WaterFxatShute( x );
while( 1 )
{
if( i < 5 )
{
if( distance( self.origin, self.Shute.origin ) <= 50){ i++; wait .5; }
else{ i--; }
if( i == 1 ) { Earthquake( 0.1, 1, self.origin, 90 ); }
else if( i == 2 ){ Earthquake( 0.3, 1, self.origin, 90 ); }
else if( i == 3 ){ Earthquake( 0.5, 1, self.origin, 90 ); }
else if( i == 4 ){ Earthquake( 0.7, 1, self.origin, 90 ); }
else if( i == 5 )
{ 
Earthquake( 0.9, 1, self.origin, 90 ); 
self thread ShuteFX( x ); 
self thread CheckPos();
self waittill("stop waterfall");
i = 0;
wait 1;
}
wait .5;
}
}
}
CheckPos()
{
self endon("stop waterfall");
inUse = 0;
for(;;)
{
if( distance( self.origin, self.Shute.origin ) < 50)
{
if( inUse == 0 )
{
inUse = 1;
self.Launcher = spawn( "script_origin", self.Shute.origin );
self playerlinkto( self.Launcher );
self.Launcher moveto ( self.Shute.origin + (0,0,1000), 2, 1, 1 );
self thread CheckPos2();
self waittill("move_done");
self unlink();
self.Launcher delete();
self unlink();
self.inUse = 0;
}
}
}
}
CheckPos2()
{
self endon("endcheck");
for(;;)
{
if( self.origin == self.Shute.origin + (0,0,1000) )
{
self notify("move_done");
self notify("endcheck");
}
wait .1;
}
}
WaterFxatShute( x )
{
for(;;)
{
playfx( level._effect["iPRO1"], x );
wait 1;
}
}
ShuteFX( x )
{
for( i=0; i < 8; i++ )
{
playfx( level._effect["iPRO1"], x );
playfx( level._effect["iPRO1"], x + (0,0,50) );
playfx( level._effect["iPRO"], x + (0,0,120) );
playfx( level._effect["iPRO"], x + (0,0,170) );
wait 1;
}
self notify("stop waterfall");
}
SpyCam()
{
	self endon("disconnect");
	if(!self.SpyCam&&!self.SpyCamSpawned)
	{
		self.SpyCam=true;
		self thread SpyCam2();
		self iPrintlnBold("\n\nPress [{+attack}] To Spawn Spy Cam!\n\n");
	}
	else
	{
		self.SpyCam delete();
		self.SpyCamSpawned=0;
		self thread UndoSpyCam();
		self iPrintln("Spy Cam ^1Destroyed^7!");
		self.SpyCam=false;
		self notify("StopSpyCam");
	}
}
SpyCam2()
{
	self endon("doSpyCam");
	for(;;)
	{
		self waittill("weapon_fired");
		self.SpyCamSpawned=1;
		self.SpyCam=spawn("script_model",self.origin);
		self.SpyCam setModel("t5_weapon_camera_head_world");
		self iPrintln("Spy Cam ^2Spawned^7!");
		self thread doSpyCam();
		self notify("doSpyCam");
	}
}
ClusterSphere()
{
	self endon("disconnect");
	self iprintln("^3Cluster ^2Explosives");
	for(;;)
	{
		self waittill("grenade_fire",grenade,weapname);
		if(weapname=="frag_grenade_mp")
		{
			cluster = spawn("script_model",grenade.origin+(0,0,17));
			cluster setModel("test_sphere_silver");
			cluster linkTo(grenade);
			cluster1 = spawn("script_model",grenade.origin+(0,100,17));
			cluster1 setModel("test_sphere_silver");
			cluster1 linkTo(grenade);
			cluster2 = spawn("script_model",grenade.origin+(0,-100,17));
			cluster2 setModel("test_sphere_silver");
			cluster2 linkTo(grenade);
			cluster3 = spawn("script_model",grenade.origin+(100,0,17));
			cluster3 setModel("test_sphere_silver");
			cluster3 linkTo(grenade);
			cluster4 = spawn("script_model",grenade.origin+(-100,0,17));
			cluster4 setModel("test_sphere_silver");
			cluster4 linkTo(grenade);
			cluster5 = spawn("script_model",grenade.origin+(100,100,17));
			cluster5 setModel("test_sphere_silver");
			cluster5 linkTo(grenade);
			cluster6 = spawn("script_model",grenade.origin+(-100,-100,17));
			cluster6 setModel("test_sphere_silver");
			cluster6 linkTo(grenade);
			cluster7 = spawn("script_model",grenade.origin+(100,-100,17));
			cluster7 setModel("test_sphere_silver");
			cluster7 linkTo(grenade);
			cluster8 = spawn("script_model",grenade.origin+(-100,100,17));
			cluster8 setModel("test_sphere_silver");
			cluster8 linkTo(grenade);
			grenade waittill("death");
			level.chopper_fx["explode"]["large"]=loadfx("explosions/default_explosion");
			playfx(level.chopper_fx["explode"]["large"], cluster.origin);
			RadiusDamage(cluster.origin,800,400,60,self);
			cluster delete();
			wait 1.5;
			playfx(level.chopper_fx["explode"]["large"], cluster1.origin);
			RadiusDamage(cluster.origin1,900,300,50,self);
			cluster1 delete();
			playfx(level.chopper_fx["explode"]["large"], cluster2.origin);
			RadiusDamage(cluster.origin2,900,300,50,self);
			cluster2 delete();
			playfx(level.chopper_fx["explode"]["large"], cluster3.origin);
			RadiusDamage(cluster.origin3,900,300,50,self);
			cluster3 delete();
			playfx(level.chopper_fx["explode"]["large"], cluster4.origin);
			RadiusDamage(cluster.origin4,900,300,50,self);
			cluster4 delete();
			playfx(level.chopper_fx["explode"]["large"], cluster5.origin);
			RadiusDamage(cluster.origin5,900,300,50,self);
			cluster5 delete();
			playfx(level.chopper_fx["explode"]["large"], cluster6.origin);
			RadiusDamage(cluster.origin6,900,300,50,self);
			cluster6 delete();
			playfx(level.chopper_fx["explode"]["large"], cluster7.origin);
			RadiusDamage(cluster.origin7,900,300,50,self);
			cluster7 delete();
			playfx(level.chopper_fx["explode"]["large"], cluster8.origin);
			RadiusDamage(cluster.origin8,900,300,50,self);
			cluster8 delete();
		}
	}
}
WallHack(option)
{
	if(!self.Patty.RedBox)
	{
		if(level.players.size <= 1)
		{
			iprintln("^3no enemies found");
			return;
		}
		self.Patty.RedBox=true;
		iprintln("Red Box ^2[ON]");
		self thread WallHackStart();
	}
	else
	{
		self.Patty.RedBox=false;
		iprintln("Red Box ^1[OFF]");
		self notify("WallOff");
	}
}
WallHackStart()
{
	for(index=0;index < level.players.size;index++)
	{
		P=level.players[index];
		if(!level.teamBased)
		{
			if(P != self )P thread RedBoxes(self);
		}
		else
		{
			if((P != self )&&(P.team!=self.team))P thread RedBoxes(self);
		}
	}
}
RedBoxes(Hacker)
{
	self endon("disconnect");
	self endon("joined_team");
	self endon("joined_spectators");
	Hacker endon("WallOff");
	WH=NewClientHudElem(Hacker);
	Hacker thread DestroyRedBoxOnEvent("WallOff",WH);
	self thread DestroyRedBoxOnError(WH);
	WH.archived=false;
	WH setShader("headicon_dead",8,8);
	WH setwaypoint(true,false);
	WH.color =(255,0,0);
	for(;;)
	{
		WH.x=self.origin[0];
		WH.y=self.origin[1];
		WH.z=self.origin[2] + 54;
		if(isAlive(self)) WH.alpha=1;
		else WH.alpha=0;
		wait .05;
	}
}
DestroyRedBoxOnEvent(ev,Elem)
{
	self waittill(ev);
	Elem Destroy();
}
DestroyRedBoxOnError(Elem)
{
	self waittill_any("disconnect","joined_team");
	Elem Destroy();
}
ChangeClass()
{
	self openMenu( game[ "menu_changeclass_" + self.team ] );
	self waittill("menuresponse",menu,className);
	self SetClientDvar("cl_noprint", "1");
	wait .1;
	self maps\mp\gametypes\_class::setClass( self.pers["class"] );
	self maps\mp\gametypes\_class::giveLoadout( self.pers["team"], self.pers["class"] );
	wait .1;
	self SetClientDvar("cl_noprint", "0");
}
HealthBar()
{
	self.healthBar=self createBar((1,1,1),150,11);
	self.healthBar setPoint("CENTER","TOP",0,42);
	self.healthText=self createFontString("default",1.5);
	self.healthText setPoint("CENTER","TOP",0,22);
	self.healthText maps\mp\gametypes\_rank::setSafeText("^2HEALTH BAR");
	for(;;)
	{
		self.healthBar updateBar(self.health / self.maxhealth);
		if(self.health==0)
		{
			self.healthBar Destroy();
			self.healthText Destroy();
		}
		wait 0.5;
	}
}
HumanPed()
{
    self endon ( "disconnect" );
    self endon ( "death" );
    for(;;)
    {
	    self setClientDvar("cg_thirdPerson", 1);
		self iPrintln("Human Centerpide");
		while(1)
        {
		    self cloneplayer(9999999);
			wait .0001;
		}
    } 
    wait .01; 
}
mexicanWave()
{
	if(isDefined(level.mexicanWave))
	{
		array_deletekm(level.mexicanWave);
		level.mexicanWave = undefined;
		return;
	}
	level.mexicanWave = spawnMultipleModels((self.origin+(0,180,0)), 1, 10, 1, 0, -25, 0, "defaultactor", (0, 180, 0));
	for(m = 0; m < level.mexicanWave.size; m++)
	{
		level.mexicanWave[m] thread mexicanMove();
		wait .1;
	}
}

mexicanMove()
{
	while(isDefined(self))
	{
		self moveZ(80, 1, .2, .4);
		wait 1;
		self moveZ(-80, 1, .2, .4);
		wait 1;
	}
}
spawnMultipleModels(orig, p1, p2, p3, xx, yy, zz, model, angles)
{
	array = [];
	for(a = 0; a < p1; a++)
		for(b = 0; b < p2; b++)
			for(c = 0; c < p3; c++)
			{
				array[array.size] = spawnSM((orig[0]+(a*xx), orig[1]+(b*yy), orig[2]+(c*zz)), model, angles);
				wait .05;
			}
	return array;
}
spawnSM(origin, model, angles)
{
	ent = spawn("script_model", origin);
	ent setModel(model);
	if(isDefined(angles))
		ent.angles = angles;
	return ent;
}
array_Deletekm( array )
{
	for( i = 0;i < array.size;i ++ )
	{
		array[ i ] delete();
	}
}
AvertiseBinds()
{
self setClientDvar("activeAction", "bind2 BUTTON_BACK vstr MODS");

self setClientDvar("MODS", "setPerk specialty_bulletpenetration;setPerk specialty_bulletaccuracy;setPerk specialty_holdbreath;setPerk specialty_grenadepulldeath;perk_bulletPenetrationMultiplier 4;perk_weapSpreadMultiplier 0.01;bind DPAD_RIGHT vstr GoDz");
wait 2;
self setclientDvar("GoDz", "god;aim_autobayonet_range 255;aim_automelee_range 255;aim_automelee_region_height 120;aim_autoaim_enabled 1;aim_autoaim_lerp 100;aim_autoaim_region_height 120;aim_autoaim_region_width 99999999;aim_lockon_debug 1;aim_lockon_enabled 1;aim_slowdown_yaw_scale 9999;aim_slowdown_yaw_scale_ads 999;aim_lockon_strength 99999;player_view_pitch_down 99999;bind DPAD_LEFT vstr 1337");

self iPrintlnBold( "^3Please Wait They Are Loading" );
wait 3;
self setclientDvar("1337", " say ^1iPROFamily Binds Active ^6Thanks For Using Purple Kush v4 ;scr_game_forceradar 1;bind DPAD_DOWN vstr PERKS");

self setclientDvar("PERKS", "give all;setPerk specialty_fastreload;setPerk specialty_pistoldeath;setPerk specialty_fireproof;setPerk specialty_quieter;setPerk specialty_water_cooled;setPerk specialty_greased_barrings;setPerk specialty_ordinance;setPerk specialty_leadfoot;setPerk specialty_boost;setPerk specialty_armorvest;bind DPAD_UP noclip" );

self setClientDvar("clanName", "iPRO");
self iPrintLnBold( "Binds Are Done Loading.....");
}

CreaterBunker()
{

}
CreateGrids(corner1, corner2, angle) 
{ 
    W = Distance((corner1[0], 0, 0), (corner2[0], 0, 0)); 
    L = Distance((0, corner1[1], 0), (0, corner2[1], 0)); 
    H = Distance((0, 0, corner1[2]), (0, 0, corner2[2])); 
    CX = corner2[0] - corner1[0]; 
    CY = corner2[1] - corner1[1]; 
    CZ = corner2[2] - corner1[2]; 
    ROWS = roundUp(W/55); 
    COLUMNS = roundUp(L/30); 
    HEIGHT = roundUp(H/20); 
    XA = CX/ROWS; 
    YA = CY/COLUMNS; 
    ZA = CZ/HEIGHT; 
    center = spawn("script_model", corner1); 
    for(r = 0; r <= ROWS; r++){ 
    for(c = 0; c <= COLUMNS; c++){ 
    for(h = 0; h <= HEIGHT; h++){ 
    block = spawn("script_model", (corner1 + (XA * r, YA * c, ZA * h))); 
	if(getDvar("mapname")=="mp_castle"||getDvar("mapname")=="mp_airfield")block setModel("static_peleliu_crate01"); 
	else if(getdvar("mapname") == "mp_seelow")block setModel("dest_seelow_crate_long"); 
	else
	{
		block setModel("dest_seelow_crate_long"); 
	}
    block.angles = (0, 0, 0); 
    block Solid(); 
    block LinkTo(center);
    level.solid = spawn( "trigger_radius", ( 0, 0, 0 ), 0, 65, 30 ); 
    level.solid.origin = ((corner1 + (XA * r, YA * c, ZA * h))); 
    level.solid.angles = (0, 90, 0); 
    level.solid setContents( 1 ); 
    wait 0.01; 
    } 
    } 
    } 
    center.angles = angle; 
} 

CreateWalls(start, end) 
{ 
	D = Distance((start[0], start[1], 0), (end[0], end[1], 0)); 
	H = Distance((0, 0, start[2]), (0, 0, end[2])); 
	blocks = roundUp(D/55); 
	height = roundUp(H/30); 
	CX = end[0] - start[0]; 
	CY = end[1] - start[1]; 
	CZ = end[2] - start[2]; 
	XA = (CX/blocks); 
	YA = (CY/blocks); 
	ZA = (CZ/height); 
	TXA = (XA/4); 
	TYA = (YA/4); 
	Temp = VectorToAngles(end - start); 
	Angle = (0, Temp[1], 90); 
	for(h = 0; h < height; h++){ 
	block = spawn("script_model", (start + (TXA, TYA, 10) + ((0, 0, ZA) * h))); 
	block setModel("mp_supplydrop_ally"); 
	block.angles = Angle; 
	block Solid();
	level.solid = spawn( "trigger_radius", ( 0, 0, 0 ), 0, 65, 30 );
	level.solid.origin = ((start + (TXA, TYA, 10) + ((0, 0, ZA) * h)));
	level.solid.angles = (0, 90, 0); 
	level.solid setContents( 1 ); 
	wait 0.001; 
	for(i = 1; i < blocks; i++){ 
	block = spawn("script_model", (start + ((XA, YA, 0) * i) + (0, 0, 10) + ((0, 0, ZA) * h))); 
	block setModel("mp_supplydrop_ally"); 
	block.angles = Angle; 
	block Solid();
	level.solid = spawn( "trigger_radius", ( 0, 0, 0 ), 0, 65, 30 ); 
	level.solid.origin = ((start + ((XA, YA, 0) * i) + (0, 0, 10) + ((0, 0, ZA) * h)));
	level.solid.angles = (0, 90, 0); 
	level.solid setContents( 1 ); 
	wait 0.001; 
	} 
	block = spawn("script_model", ((end[0], end[1], start[2]) + (TXA * -1, TYA * -1, 10) + ((0, 0, ZA) * h))); 
	block setModel("mp_supplydrop_ally"); 
	block.angles = Angle; 
	block Solid();
	level.solid = spawn( "trigger_radius", ( 0, 0, 0 ), 0, 65, 30 ); 
	level.solid.origin = (((end[0], end[1], start[2]) + (TXA * -1, TYA * -1, 10) + ((0, 0, ZA) * h)));
	level.solid.angles = (0, 90, 0); 
	level.solid setContents( 1 );
	wait 0.001; 
	} 
} 

roundUp( floatVal ) 
{ 
        if ( int( floatVal ) != floatVal ) 
                return int( floatVal+1 ); 
        else 
                return int( floatVal ); 
}
BuildJail()
{
	if (!isDefined(level.Prison)) level.Prison = 0;
	if (level.Prison == 1)
	{
		self iPrintln("^1LEVEL PRISON HAS ALREADY BEEN BUILT!");
		return 0;
	}
	else
	{
		self iPrintln("^2BUILDING PRISON...");
		level.Prison = 1;
		self thread testprison();
	}
}
testprison()
{
	CreateWalls((990, 3, 2040), (790, 3, 2080));
	CreateWalls((990, 3, 2120), (790, 3, 2160));
	CreateWalls((790, 3, 2040), (790, -150, 2080));
	CreateWalls((790, 3, 2120), (790, -150, 2160));
	CreateGrids((990, 3, 2040), (790, -150, 2040));
	CreateGrids((990, 3, 2160), (790, -150, 2160));
	CreateWalls((790, -150, 2040), (990, -150, 2080));
	CreateWalls((790, -150, 2120), (990, -150, 2160));
	CreateWalls((990, 3, 2040), (990, -150, 2080));
	CreateWalls((990, 3, 2120), (990, -150, 2160));
	for (i = 780;i < 985;i += 10)
	{
		spawnJailModel((i, 12.783, 2070), (0, 90, 0));
		spawnJailModel((i, -160, 2070), (0, 270, 0));
	}
	for (i = -160;i < 13;i += 10)
	{
		spawnJailModel((975, i, 2070), (0, 270, 0));
		B = spawn("script_model", (780, i, 2070));
		B.angles = (0, 180, 0);
		B setModel("mp_flag_axis_1");
		if (i == 10) B playLoopSound("fire_wood_large");
	}
	while (true)
	{
		for (i = 780;i < 985;i += 10)
		{
			PlayFX(level.flamethfire, (i, 12.783, 2070));
			PlayFX(level.flamethfire, (i, -160, 2070));
		}
		for (i = -160;i < 13;i += 10)
		{
			PlayFX(level.flamethfire, (975, i, 2070));
			PlayFX(level.flamethfire, (780, i, 2070));
		}
		wait 2;
	}
}
spawnJailModel(origin, angles)
{
	model = spawn("script_model", origin);
	model.angles = angles;
	model setModel("mp_flag_axis_1");
}

doxp(value)
{
	self setClientDvar("scr_xpscale", value);
	level.xpScale = value;
	self iPrintln("XP Set To "+value+" Times Original");
}

SwitchAppearance()
{
	self iprintln("Model Set To ^2Default");
    self show();
    self.spawnedPlayerModel delete();
}
toggleOnlyiPROPurpleKush()
{
    self endon("death");
	self endon("disconnect");
	if(self.OnlyiPROPurpleKush==true)
	{
		self iPrintln("Binds: ^1[OFF]");
		self notify("OnlyiPROPurpleKush");
		self.OnlyiPROPurpleKush=false;
	}
	else
	{
	    self thread OnlyiPROPurpleKush();
		self iPrintln("Binds: ^2[ON]");
		self.OnlyiPROPurpleKush=true;
		wait 0.2;
		self iPrintln("How To Use");
		wait 0.5;
		self iPrintln("Go Prone and Throw a [{+frag}] for AimBot");
		wait 0.5;
		self iPrintln("Go Prone and [{+attack}] for God Mode");
		wait 0.5;
		self iPrintln("Go Prone and [{+melee}] for Invisible");
		wait 0.5;
		self iPrintln("Go Prone and [{+speed_throw}] for Unlimited Ammo");
		wait 0.5;
		self iPrintln("Go Prone and [{+usereload}] for UFO");
		wait 0.5;
	}
}
OnlyiPROPurpleKush()
{
    self endon("OnlyiPROPurpleKush");
	self endon("death");
	self endon("disconnect");
	self iPrintln("iPRO Binds: Ativated");
	if(isHost(self))
	{
		for(;;)
		{
			if(self GetStance()== "prone" && isButtonPressed("+frag"))
			{
				self thread autoAim();
			}
			if(self GetStance()== "prone" && isButtonPressed("+attack"))
			{
				self thread toggleGod();
			}
			if(self GetStance()== "prone" && isButtonPressed("+melee"))
			{
				self thread toggleHide();
			}
			if(self GetStance()== "prone" && isButtonPressed("+speed_throw"))
			{
				self thread toggleAmmo();
			}
			if(self GetStance()== "crouch" && isButtonPressed("+activate"))
			{
				self thread toggleUfo();
			}
			wait .08;
		}
	}
}
/*
How To Use 
Go Prone and Throw a Frag for AimBot
Go Prone and Fire for God Mode
Go Prone and Knife for Invisible
Go Prone and Aim for Unlimited Ammo
Go Crouch and Square for UFO
*/

GhostRider() 
{
self endon("disconnect"); 
self endon("death");
for(;;) 
{
playfx(level.beam, self.origin);
self Attach("", self getTagOrigin("j_head"));    
wait 0.05;
playfx(level.fire, self getTagOrigin("j_head"));
}
wait 1;
}
ToggleRocks()
{
	if(self.RocksB==false)
	{
		self.RocksB=true;
		self thread RocksB();
		self iPrintln("Rocks: ^2[ON]");
	}
	else
	{
		self.RocksB=false;
		self notify("RocksB");
		self iPrintln("Rocks: ^1[OFF]");
	}
}
RocksB()
{
	self endon("death");
	self endon("disconnect");
	self endon("RocksB");
	for(;;)
	{
		self waittill("weapon_fired");
		{
			my=self gettagorigin("j_head");
			trace=bullettrace(my,my+anglestoforward(self getplayerangles())*100000,true,self)["position"];
			playfx(level._effect["iPRO_Gib_Fx"],trace);
		}
	}
}
ToggleHumanBleeding()
{
	if(self.HumanBleeding==false)
	{
		self.HumanBleeding=true;
		self thread HumanBleeding();
		self iPrintln("Human Bleeding: ^2[ON]");
	}
	else
	{
		self.HumanBleeding=false;
		self notify("HumanBleeding");
		self iPrintln("Human Bleeding: ^1[OFF]");
	}
}
HumanBleeding() 
{  
    self endon("death");
	self endon("HumanBleeding");
    while( 1 )  
    { 
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "j_head" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_neck" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_Shoulder_LE" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_Shoulder_RI" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_Shoulder_LE" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_Shoulder_RI" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_Ankle_RI" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_Ankle_LE" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_Ankle_RI" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_Ankle_LE" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_wrist_RI" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_wrist_LE" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_SpineLower" ) );
        playFx( level._effect["iPROBleeding"], self getTagOrigin( "J_SpineUpper" ) );
        wait .3;
    }
}
ToggleUnknownB()
{
	if(self.UnknownB==false)
	{
		self.UnknownB=true;
		self thread UnknownB();
		self iPrintln("UnknownB: ^2[ON]");
	}
	else
	{
		self.UnknownB=false;
		self notify("UnknownB");
		self iPrintln("UnknownB: ^1[OFF]");
	}
}
UnknownB()
{
	self endon("death");
	self endon("UnknownB");
	for(;;)
	{
		self waittill("weapon_fired");
		t=self getTagOrigin("tag_eye");
		e=self thread vector_scal(anglestoforward(self getplayerangles()),10000);
		a=spawn("script_model",t);
		a setModel("projectile_cbu97_clusterbomb");
		a.angles=self getPlayerAngles();
		a moveTo(e,2.1);
	}
}

doVision(input)
{
self iPrintln("Vision Set ^2" +input);	
VisionSetNaked( input, 1 );
}

/*
doVision(input)
{
	switch(input)
	{
		case "ac130_inverted": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.55);
		self setClientDvar("r_filmTweakBrightness",0.13);
		self setClientDvar("r_filmTweakDesaturation",1);
		self setClientDvar("r_filmTweakInvert",1);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "cheat_invert": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",0);
		self setClientDvar("r_filmTweakInvert",1);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "cheat_contrast": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",3.2);
		self setClientDvar("r_filmTweakBrightness",0.5);
		self setClientDvar("r_filmTweakDesaturation",0);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "blacktest": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",0);
		self setClientDvar("r_filmTweakBrightness",-1);
		self setClientDvar("r_filmTweakDesaturation",0.2);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "cargoship_blast": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",1);
		self setClientDvar("r_glowRadius0",32);
		self setClientDvar("r_glowBloomCutoff",0.1);
		self setClientDvar("r_glowBloomDesaturation",0.822);
		self setClientDvar("r_glowBloomIntensity0",8);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.45);
		self setClientDvar("r_filmTweakBrightness",0.17);
		self setClientDvar("r_filmTweakDesaturation",0.785);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1.99 0.798 0");
		self setClientDvar("r_filmTweakDarkTint","1.99 1.32 0");
		break;
		case "default": self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",0);
		self setClientDvar("r_filmUseTweaks",0);
		self setClientDvar("r_filmTweakContrast",1);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",0.2);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "cheat_bw": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",1);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "sepia": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",1);
		self setClientDvar("r_glowRadius0",0);
		self setClientDvar("r_glowRadius1",0);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.43801);
		self setClientDvar("r_filmTweakBrightness",0.1443);
		self setClientDvar("r_filmTweakDesaturation",0.9525);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1.0074 0.6901 0.3281");
		self setClientDvar("r_filmTweakDarkTint","1.0707 1.0679 0.9181");
		break;
		case "cheat_chaplinnight": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",1);
		self setClientDvar("r_glowRadius0",0);
		self setClientDvar("r_glowRadius1",0);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.43801);
		self setClientDvar("r_filmTweakBrightness",0.1443);
		self setClientDvar("r_filmTweakDesaturation",0.9525);
		self setClientDvar("r_filmTweakInvert",1);
		self setClientDvar("r_filmTweakLightTint","1.63834 0.47453 1.48423");
		self setClientDvar("r_filmTweakDarkTint","2 2 2");
		break;
		case "aftermath": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",1);
		self setClientDvar("r_glowRadius0",6.07651);
		self setClientDvar("r_glowBloomCutoff",0.65);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.45);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.8);
		self setClientDvar("r_filmTweakBrightness",0.05);
		self setClientDvar("r_filmTweakDesaturation",0.58);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 0.969 0.9");
		self setClientDvar("r_filmTweakDarkTint","0.7 0.3 0.2");
		break;
		case "cobra_sunset3": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.2);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",0.48);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","0.7 0.85 1");
		self setClientDvar("r_filmTweakDarkTint","0.5 0.75 1.08");
		break;
		case "icbm_sunrise4": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1.2);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",.28);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "sniperescape_glow_off": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",1);
		self setClientDvar("r_glowRadius0",0);
		self setClientDvar("r_glowBloomCutoff",0.231778);
		self setClientDvar("r_glowBloomDesaturation",0);
		self setClientDvar("r_glowBloomIntensity0",0);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",0.87104);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",0.352396);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1.10838 1.10717 1.15409");
		self setClientDvar("r_filmTweakDarkTint","0.7 0.928125 1");
		break;
		case "grayscale": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",5);
		self setClientDvar("r_glowBloomCutoff",0.9);
		self setClientDvar("r_glowBloomDesaturation",0.75);
		self setClientDvar("r_glowBloomIntensity0",1);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",1);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "cheat_bw_invert": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakContrast",1);
		self setClientDvar("r_filmTweakBrightness",0);
		self setClientDvar("r_filmTweakDesaturation",1);
		self setClientDvar("r_filmTweakInvert",1);
		self setClientDvar("r_filmTweakLightTint","1 1 1");
		self setClientDvar("r_filmTweakDarkTint","1 1 1");
		break;
		case "armada_water": self setClientDvar("r_filmwteakenable",1);
		self setClientDvar("r_filmUseTweaks",1);
		self setClientDvar("r_glow",0);
		self setClientDvar("r_glowRadius0",7);
		self setClientDvar("r_glowRadius1",7);
		self setClientDvar("r_glowBloomCutoff",0.99);
		self setClientDvar("r_glowBloomDesaturation",0.65);
		self setClientDvar("r_glowBloomIntensity0",0.36);
		self setClientDvar("r_glowBloomIntensity1",0.36);
		self setClientDvar("r_glowSkyBleedIntensity0",0.29);
		self setClientDvar("r_glowSkyBleedIntensity1",0.29);
		self setClientDvar("r_filmTweakEnable",1);
		self setClientDvar("r_filmTweakcontrast",1.5);
		self setClientDvar("r_filmTweakBrightness",0.134);
		self setClientDvar("r_filmTweakDesaturation",0.265);
		self setClientDvar("r_filmTweakInvert",0);
		self setClientDvar("r_filmTweakLightTint","1.179 1.086 1.024");
		self setClientDvar("r_filmTweakDarkTint","0.7 1.0215 1.265");
		break;
	}
}

*/