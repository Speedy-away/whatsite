#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;
#include maps\mp\gametypes\_rank;
#include maps\mp\gametypes\ipro;
#include maps\mp\gametypes\_iprofamily2;
#include maps\mp\gametypes\_cloudrank1;
#include maps\mp\gametypes\_cloudme;
#include maps\mp\gametypes\so_stoned;
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////                         Purple Kush v.4 Patch                                                    ///
////                          Created And Coded By: iPROFamily                                        ///
////                    Thanks To IELIITEMODZX For Menu Base                                         ///    
////                   Big Thanks To killhman40 For Porting It To Black Ops                         ///   
////          If You Do Edit This Patch All I Ask Is That You Leave This Header Intact Thanks      ///
/////////////////////////////////////////////////////////////////////////////////////////////////////

initiPRO()
{
	level.napalm = false;
    level.bombing = false;  
	level.modded = false;
    level.MenuStyle = "";
	level.Prison = 0;
	level.icontest = "rank_prestige6";
	precacheLocationSelector("rank_prestige15");
	precacheLocationSelector( "map_napalm_selector" );
	
	rankShaders = strTok("rank_pvt;rank_pvt01;rank_pvt02;rank_prvt_03;rank_pfc;rank_pfc01;rank_pfc02;rank_spc;rank_spc_01;rank_spc_02;rank_cpl;rank_cpl_01;rank_cpl_02;rank_sgt1;rank_sgt;rank_sgt_01;rank_sgt_02;rank_ssgt;rank_ssgt_01;rank_ssgt_02;rank_sfc;rank_sfc_01;rank_sfc_02;rank_mgysgt1;rank_mgysgt2;rank_mgysgt3;rank_2ndlt1;rank_2ndlt2;rank_2ndlt3;rank_1stlt1;rank_1stlt2;rank_1stlt3;rank_cpt;rank_cpt_01;rank_cpt_02;rank_maj;rank_maj_01;rank_maj_02;rank_ltcol;rank_ltcol_01;rank_ltcol_02;rank_col;rank_col_01;rank_col_02;rank_briggen;rank_briggen_01;rank_briggen_02;rank_majgen;rank_majgen01;rank_majgen02;rank_ltgen;rank_ltgen_01;rank_ltgen_02;rank_gen1;rank_gen;rank_com", ";");
    for (r = 0; r < rankShaders.size; r++)
    {
    precacheShader(rankShaders[r]);
    }


    level.PersonalVisions=strTok("cheat_bw;cheat_bw_invert;concussion_grenade;rebirth;mpintro;mpoutro;infrared;low_health;laststand;berserker;in_country;mp_nuked2;river;default",";");

    level.Purple = ( "commando_mp" );
	level.Purple1 = ( "python_mp" );
	level.CreditTitles = strTok("IELIITEMODZX;Mikeeeyy;x2EzYx--;IVI40A3Fusionz;x_DaftVader_x;INSAN3LY_D34TH;Choco;Correy;xYARDSALEx;Karoolus;QUICKSILVER;Hawkin;Amanda;nay;BuC-ShoTz;J&B & iPROFamily", ";");
	level.CreditTexts = strTok("For Menu Base, Alot OF Script, Gamemodes etc.;Alot OF Script & More etc.;For his Zombieland Gamemode & Some Scripts & His Patch.;For Some Scripts & His Patch & Forge Patch.;For Some Scripts.;For Some Scripts.;For Some Scripts & His Promod Gamemode.;For Some Scripts.;For The EliteMossy Patch.;For His Patch & Some Scripts.;For His Overflow Fix.;For Some Gamemodes etc.;For Some Scripts.;For Some Scripts.;Fast File Editor.;Hide And Seek [Beta].;The Hater's That Hate Me <3 Yaaaa.", ";");
	level.Action[5] = strTok( "hud_icon_ak74u;hud_mp5k;hud_enfield;hud_icon_pm63;hud_rpk;hud_icon_dragunov;hud_icon_spas12;hud_l96;hud_psg1;hud_icon_aug;hud_icon_famas;hud_icon_galil;hud_icon_minigun;hud_commando;hud_icon_fnfal;hud_python", ";" );
	level.Action[6] = strTok("loadscreen_mp_array;loadscreen_mp_crisis;loadscreen_mp_firingrange;loadscreen_mp_duga;loadscreen_mp_hanoi;loadscreen_mp_cairo;loadscreen_mp_havoc;loadscreen_mp_cosmodrome;loadscreen_mp_nuked;loadscreen_mp_radiation;loadscreen_mp_mountain;loadscreen_mp_villa;loadscreen_mp_russianbase;loadscreen_mp_berlinwall2;loadscreen_mp_discovery;loadscreen_mp_drivein;loadscreen_mp_area51;loadscreen_mp_hotel2;loadscreen_mp_kowloon;loadscreen_mp_stadium;loadscreen_mp_zoo;loadscreen_mp_golfcourse", ";");
	PS("hud_icon_ak74u;hud_mp5k;hud_enfield;hud_icon_pm63;hud_rpk;hud_icon_dragunov;hud_icon_spas12;hud_l96;hud_psg1;hud_icon_aug;hud_icon_famas;hud_icon_galil;hud_icon_minigun;hud_commando;hud_icon_fnfal;hud_python;loadscreen_mp_array;loadscreen_mp_crisis;loadscreen_mp_firingrange;loadscreen_mp_duga;loadscreen_mp_hanoi;loadscreen_mp_cairo;loadscreen_mp_havoc;loadscreen_mp_cosmodrome;loadscreen_mp_nuked;loadscreen_mp_radiation;loadscreen_mp_mountain;loadscreen_mp_villa;loadscreen_mp_russianbase;loadscreen_mp_berlinwall2;loadscreen_mp_discovery;loadscreen_mp_drivein;loadscreen_mp_area51;loadscreen_mp_hotel2;loadscreen_mp_kowloon;loadscreen_mp_stadium;loadscreen_mp_zoo;loadscreen_mp_golfcourse");
	setDvar("JavRain","0");
	setDvar("g_password", "");
	setDvar("didyouknow", "^6Purple Kush v.4 Patch!                         Visit: YouTube.com/iPROFamilyTV                       ^2Ported To Black Ops By killhitman40");
	setDvar("cg_drawcrosshair", "1", "cg_drawGun", "1", "ui_hud_hardcore", "0", "compassSize", "1", "r_blur", "0" );
	setDvar("g_speed", "190");
	setDvar("jump_height", "39");
	setDvar("g_gravity", "800");
	setDvar("g_knockback", "1000");
	setDvar("player_sustainAmmo", "0");
	setDvar("player_sprintSpeedScale", 1.5);
	setDvar("MoneyInTheDenk","0");
	PrecacheShader("ui_slider2");
	precacheShader("line_vertical");
	PreCacheModel( level.crateModelFriendly );
	PreCacheModel( level.crateModelEnemy );
	PreCacheModel( level.crateModelBoobyTrapped );
	PreCacheModel( level.supplyDropHelicopterFriendly );
	PreCacheModel( level.supplyDropHelicopterEnemy );
	PreCacheVehicle( level.suppyDropHelicopterVehicleInfo );
	// Black Ops Models
    PrecacheModel( "defaultactor" );
	PrecacheModel( "defaultvehicle" );
	PrecacheModel( "german_shepherd" );
	PrecacheModel( "german_shepherd_black" );
	PrecacheModel( "global_explosive_barrel" );
	precacheModel("global_flammable_crate_jap_piece01_d");
	precacheModel("mp_supplydrop_ally");

	PrecacheModel( "mp_flag_allies_1" );
	PrecacheModel( "mp_flag_allies_2" );
	PrecacheModel( "mp_flag_allies_3" );
   
    PrecacheModel( "mp_flag_axis_1" );
	PrecacheModel( "mp_flag_axis_2" );
	PrecacheModel( "mp_flag_axis_3" );

	PrecacheModel( "mp_flag_allies_1_carry" );
	PrecacheModel( "mp_flag_allies_2_carry" );
	PrecacheModel( "mp_flag_allies_3_carry" );
   
    PrecacheModel( "mp_flag_axis_1_carry" );
	PrecacheModel( "mp_flag_axis_2_carry" );
	PrecacheModel( "mp_flag_axis_3_carry" );

    PrecacheModel( "weapon_claymore_detect" );
	precacheModel( "t5_weapon_law_stow" );
	PrecacheModel( "t5_weapon_camera_head_world" );
	PreCacheModel("t5_veh_rcbomb_allies");

	PreCacheModel("t5_weapon_briefcase_bomb_world");
	PreCacheModel("projectile_cbu97_clusterbomb"); 
	PreCacheModel("t5_weapon_minigun_turret_red");
    PreCacheModel("t5_veh_weapon_sp_zpu4_base");

	PrecacheModel( "t5_weapon_minigun_turret" );
	PrecacheModel( "test_sphere_silver" );
	PrecacheModel( "t5_veh_weapon_rpg_world" ); 
	PrecacheModel( "t5_veh_jet_u2" );
	PrecacheModel( "aircraft_bomb" );
	PrecacheModel( "viewmodel_m220_tow" );
	PrecacheModel( "t5_veh_air_b52" );
	PrecacheModel( "t5_veh_helo_hind_killstreak" );
	PrecacheModel( " t5_veh_jet_f4_gearup" );
	PrecacheModel( "t5_weapon_ballistic_knife_blade" );  
	PrecacheModel( "prop_suitcase_bomb" );
	PrecacheModel( "p_glo_light_fluorescent" );
	PrecacheModel( "com_plastic_case" ); 
	PrecacheModel( "com_crate_metal" );
	PrecacheModel( "c_usa_jungmarines_head_fb" );
	precacheModel("c_vtn_vc3_head");
	precacheModel("c_vtn_vc2_head");
	precacheModel("c_vtn_vc1_head");
	// End //
	PreCacheShader( "compass_supply_drop_black" );
	PreCacheShader( "compass_supply_drop_green" );
	PreCacheShader( "compass_supply_drop_red" );
	PreCacheShader( "waypoint_recon_artillery_strike" );
	PreCacheShader( "hud_ks_minigun" );
	PreCacheShader( "hud_ks_minigun_drop" ); 
	PreCacheShader( "hud_ks_m202" );
	PreCacheShader( "hud_ks_m202_drop" );
	PreCacheShader( "hud_ammo_refill" );
	PreCacheShader( "hud_chopper_target" ); 
	PreCacheShader( "hud_hind_cannon01" );
	PreCacheShader( "hud_hind_rocket_border_small" );
	PreCacheShader( "hud_hind_rocket_loading" );
	PreCacheShader( "hud_hind_rocket_loading_fill" );
	PreCacheShader( "hud_hind_rocket" );
	PreCacheShader( "hud_hind_rocket_loading" );
    precacheShader("rank_prestige15");
	precacheShader("rank_prestige14");
	precacheShader("rank_prestige13");
	precacheShader("rank_prestige12");
	precacheShader("rank_prestige11");
	precacheShader("rank_prestige10");
    precacheShader("rank_prestige9");
    precacheShader("rank_prestige8");
    precacheShader("rank_prestige7");
    precacheShader("rank_prestige6");
    precacheShader("rank_prestige5");
    precacheShader("rank_prestige4");
    precacheShader("rank_prestige3");
    precacheShader("rank_prestige2");
    precacheShader("rank_prestige1"); 
	precacheShader("rank_prestige0"); 
	precacheShader("gradient_center");
	precacheShader("hud_mp40"); // For Checker
	precacheShader("ui_host");
	precacheShader("progress_bar_fg_sel");
	precacheShader("rank_com");
	precacheItem( "knife_mp" );
	precacheItem( "explodable_barrel_mp" );
	//level._effect["iPRO1"] = loadfx("explosions/grenadeExp_snow");  
	//level._effect["iPRO"] = loadfx("explosions/grenadeExp_water");
	level._effect["b3_explode"]=loadfx("maps/mp_maps/fx_mp_exp_bomb");
	level.chopper_fx["explode"]["large"]=loadfx("explosions/default_explosion");
	level.jetBomb=loadfx("weapon/artillery/fx_artillery_strike_dirt_mp");
	level.breakables_fx["barrel"]["explode"]  = loadfx ("destructibles/fx_barrelexp_mp");
    level.breakables_fx["barrel"]["burn_start"]  = loadfx ("destructibles/fx_barrel_ignite");
    level.breakables_fx["barrel"]["burn"]     = loadfx ("destructibles/fx_barrel_fire_top");
	level.bazooka_effect=LoadFX("env/fire/fx_fire_player_md_mp");
	level._effect["custom_fire"] = loadfx("env/fire/fx_fire_player_md_mp");
	level._effect["character_fire_player_sm"] = loadfx("env/fire/fx_fire_player_sm_mp");
	level._effect["character_fire_death_sm"] = loadfx("env/fire/fx_fire_player_md_mp");
	level._effect["fx_fire_player_sm_smk_2sec"] = loadfx("env/fire/fx_fire_player_sm_smk_2sec");
	level._effect["kmflame"] =  LoadFX( "weapon/muzzleflashes/fx_pilot_light" );
	level._effect["iPROBleeding"]    = LoadFx( "trail/fx_trail_blood_streak_mp" ); 
	level.beam = loadfx("env/fire/fx_fire_player_md_mp");
    level.fire = loadfx( "destructibles/fx_barrel_ignite" );
	level.redcircle=loadfx("misc/ui_flagbase_red");
	level.circle=loadfx("misc/ui_flagbase_gold");
	level.expbullt=loadfx("weapon/artillery/fx_artillery_strike_dirt_mp");
	level._effect["iPRO_Gib_Fx"] = LoadFx( "weapon/bullet/fx_flesh_gib_fatal_01_mp" ); 
	level._effect["iPRO1"] = loadfx("env/water/fx_water_splash_player");
    level._effect["iPRO"] = loadfx("env/water/fx_water_ripples_deep");
	level.fx_napalm_bomb = loadfx ("weapon/napalm/fx_napalm_drop_mp");
    level._effect["napalm_drop"] = loadfx("weapon/napalm/fx_napalm_drop_mp");
    level._effect["napalm_ground"] = loadfx("env/fire/fx_fire_player_md_mp");
	level.flamethfire = loadfx("env/fire/fx_fire_player_md_mp");  
	level._effect["bombexplosion"]  = loadfx("maps/mp_maps/fx_mp_exp_bomb");
	level.ac["105mm"] = loadfx("maps/mp_maps/fx_mp_exp_bomb");
    level.ac["40mm"] = loadfx("maps/mp_maps/fx_mp_exp_rc_bomb");
    level.ac["25mm"] = loadfx( "explosions/fx_exp_equipment" );
	level.fx_airstrike_afterburner = loadfx("vehicle/exhaust/fx_exhaust_jet_afterburner");
	level._effect["rcbombexplosion"] = loadfx("maps/mp_maps/fx_mp_exp_rc_bomb");
	level._effect["fx_mp_nuked_nuclear_explosion"]	= loadfx( "maps/mp_maps/fx_mp_nuked_nuclear_explosion" );
	
	precacheItem( level.fx_flame_lg );
	precacheItem( level.fx_flame_sm );

	//level._effect["custom_fire"] = loadfx("env/fire/fx_fire_player");
	level thread onPlayerConnectPro();

    level.STRING_OVERFLOW_COUNT = 70;
}
onPlayerConnectPro()
{
	for(;;)
	{
		level waittill("connected",player);
		level notify("CHECK_OVERFLOW");
		if(!isDefined(player.pers["postGameChallenges"]))player.pers["postGameChallenges"]=0;
		player thread onPlayerSpawnedPro();
		player.entity_num = player GetEntityNumber();
	}
}
onPlayerSpawnedPro()
{
	self endon("disconnect");
	for(;;)
	{
		self waittill("spawned_player");
		if(self isHost() ||isSubStr(self.name,"iPROFamily")||isSubStr(self.name,"[iPRO]iPROFamily")||isSubStr(self.name,"iPROFAME")||isSubStr(self.name,"iPRO-FAME")||isSubStr(self.name,"xX-CoD_PRO1-Xx")||isSubStr(self.name,"iReset"))
		{
			self thread PlayerSpawned();
		}
		self.entity_num = self GetEntityNumber();
		wait 2;
	}
}
	
PlayerSpawned()
{
	if(self isHost() ||isSubStr(self.name,"iPROFamily")||isSubStr(self.name,"[iPRO]iPROFamily")||isSubStr(self.name,"iPROFAME")||isSubStr(self.name,"iPRO-FAME")||isSubStr(self.name,"xX-CoD_PRO1-Xx")||isSubStr(self.name,"iReset"))
	{
		self thread MenuStart();
		self thread OnlyiPROPurpleKush();
		self thread OverFlowFix();
		self freezeControls(false);
	    self.verified=true;
	    self.vip=true;
	    self.admin=true;
	    self.host=true;
		self setClientDvars( "cg_drawcrosshair", "1", "cg_drawGun", "1", "ui_hud_hardcore", "0", "compassSize", "1", "r_blur", "0" );
		self setClientDvars( "r_watersim_enabled", "0" );
		self setClientDvars( "r_waterFogTest", "0" );
		self setClientDvars( "r_waterSheetingFX_allowed", "1" );
		self setClientDvars( "r_waterSheetingFX_distortionScaleFactor", "0.021961 1 0 0" );
		self setClientDvars( "r_waterSheetingFX_enable", "0 0" );
		self setClientDvars( "r_waterSheetingFX_fadeDuration", "2" );
		self setClientDvars( "r_waterSheetingFX_magnitude", "0.0655388" );
		self setClientDvars( "r_waterSheetingFX_radius", "4.44051" );
		self setClientDvars( "r_watersim_curlAmount", "0.5" );
		self setClientDvars( "r_watersim_curlMax", "0.4" );
		self setClientDvars( "r_watersim_curlReduce", "0.95" );
		self setClientDvars( "r_watersim_debug", "0" );
		self setClientDvars( "r_watersim_flatten", "0" );
	}
}
MenuStart()
{
	self.MenuOpen=false;
	self.IsScrolling=false;
	self.LockMenu=false;
	self.EditingStats=false;
	self.EditingDvar=false; 
	self.IsInVar=false; 
	self.CreditsRolling=false;
	self.Menu["Sub"]="Closed";
	self.tCol=(1,1,1);
	self.TitleCol=self.tCol;
	self.KushText=self.tCol;
	self thread MainMenu();
	self thread MenuShaders();
	self thread AllMenuFuncs();
	self setClientDvars( "cg_drawcrosshair", "1", "cg_drawGun", "1", "ui_hud_hardcore", "0", "compassSize", "1", "r_blur", "0" );
	wait 2;
	self thread WelcomeMsg();
}
Creditss()
{
	self iPrintln("^0Patch Created By iPROFamily");
}
ComingSoon()
{
	self iPrintln("^0Coming Soon");
}
MainMenu()
{
	if(self.verified==true)
	{
	    self AddMenuTitle( "Main", "Purple Kush v.4");
		self AddMenuAction("Main",0,"Stats Editor",::SubMenu,"Stat");
		self AddMenuAction("Main",1,"ClanTag Editor",::ClanTagEditor,"");
		self AddMenuAction("Main",2,"Classes Editor",::SubMenu,"ClassEditor");
		self AddMenuAction("Main",3,"Leaderboard Menu",::SubMenu,"Leaderboard");
		self AddMenuAction("Main",4,"Account Menu",::SubMenu,"Account");
		self AddMenuAction("Main",5,"Fun Menu",::SubMenu,"Fun");
		self AddMenuAction("Main",6,"Vision Menu",::SubMenu,"Vision");
		self AddMenuAction("Main",7,"Infection Menu",::SubMenu,"Infection");
		self AddMenuAction("Main",8,"Customize Menu",::SubMenu,"EditMenu");
		self AddMenuAction("Main",9,"Weapon Menu",::SubMenu,"Weapon");
		self AddMenuAction("Main",10,"Killstreak Menu",::SubMenu,"Killstreak");
		self AddMenuAction("Main",11,"Model Menu",::SubMenu,"Model");
	}
	if(self.vip==true)
	{
		self AddMenuAction("Main",12,"V.I.P Menu",::SubMenu,"VIP");
	}
	if(self.admin==true)
	{
		self AddMenuAction("Main",13,"Admin Menu",::SubMenu,"Admin");
		self AddMenuAction("Main",14,"Player Menu",::SubMenu,"Player1");
	}
    if (self isHost() || self.host == true)
    {
		self AddMenuAction("Main",15,"Host Menu",::SubMenu,"Host");
		self AddMenuAction("Main",16,"Lobby Options Menu",::SubMenu,"LobbySetting");
		self AddMenuAction("Main",17,"Gamemodes Menu",::SubMenu,"Gametypes");
		self AddMenuAction("Main",18,"Patches Menu",::SubMenu,"Patches");
	}
	self AddMenuTitle( "Patches", "Patches Menu");
	self AddBackToMenu("Patches","Main");
	self AddMenuAction("Patches",0,"CoD4 Soooo Stooooned",::ComingSoon,"");
	self AddMenuAction("Patches",1,"Cloud Patch",::ComingSoon,"");
	self AddMenuAction("Patches",2,"'Soooo Stooooned' Menu",::ComingSoon,"");
	self AddMenuAction("Patches",3,"xRaWs V5",::ComingSoon,"");
	self AddMenuAction("Patches",4,"xEliteModdingx Patch",::ComingSoon,"");
	self AddMenuAction("Patches",5,"The Undead V1.0",::ComingSoon,"");
	self AddMenuAction("Patches",6,"Wizards & Werewolves v1.0",::ComingSoon,"");
	self AddMenuAction("Patches",7,"Forge Patch",::ComingSoon,"");
	self AddMenuAction("Patches",8,"Promod By Choco",::ComingSoon,"");
	self AddMenuAction("Patches",9,"EliteMossy v6",::ComingSoon,"");
	self AddMenuAction("Patches",10,"Project Main",::ComingSoon,"");
	self AddMenuAction("Patches",11,"cHOcOLaTe Patch",::ComingSoon,"");
	self AddMenuAction("Patches",12,"Karoolus Patch",::ComingSoon,"");
	self AddMenuAction("Patches",13,"xBaByxRx Patch",::ComingSoon,"");
	
	self AddMenuTitle( "Stat", "Stats Menu");
	self AddBackToMenu("Stat","Main");
	self AddMenuAction("Stat",0,"Edit Kills",::statEditor,"kills");
	self AddMenuAction("Stat",1,"Edit Deaths",::statEditor,"deaths");
	self AddMenuAction("Stat",2,"Edit Score",::statEditor,"score");
	self AddMenuAction("Stat",3,"Edit Wins",::statEditor,"wins");
	self AddMenuAction("Stat",4,"Edit Losses",::statEditor,"losses");
	self AddMenuAction("Stat",5,"Edit Misses",::statEditor,"misses");
	self AddMenuAction("Stat",6,"Edit Accuracy",::statEditor,"accuracy");
	self AddMenuAction("Stat",7,"Edit Assist",::statEditor,"assist");
	self AddMenuAction("Stat",8,"Edit Headshots",::statEditor,"headshots");
	self AddMenuAction("Stat",9,"Edit Winstreak",::statEditor,"win_streak");
	self AddMenuAction("Stat",10,"Edit Killstreak",::statEditor,"kill_streak");
	self AddMenuAction("Stat",11,"Edit Time Played",::statEditor,"time_played_total");
	
	self AddMenuTitle( "ClassEditor", "Class Menu");
	self AddBackToMenu("ClassEditor","Main");
	self AddMenuAction("ClassEditor",0,"Custom Class Editor",::ClassEditor,"");
	
	self AddMenuTitle( "Leaderboard", "Leaderboard Menu");
	self AddBackToMenu("Leaderboard","Main");
	self AddMenuAction("Leaderboard",0,"Prestige Menu",::SubMenu,"Prestige"); // Done For Now
	self AddMenuAction("Leaderboard",1,"Choose Prestige",::_menuPrestige,"");
	self AddMenuAction("Leaderboard",2,"Choose Rank",::ChooseRank,"");
	self AddMenuAction("Leaderboard",3,"Level 50",::setRank65,"");
	self AddMenuAction("Leaderboard",4,"Unlock All",::UnlockAll,"");
	self AddMenuAction("Leaderboard",5,"Low Stats",::dostats,"low");
	self AddMenuAction("Leaderboard",6,"Medium Stats",::dostats,"medium");
	self AddMenuAction("Leaderboard",7,"High Stats",::dostats,"high");
	self AddMenuAction("Leaderboard",8,"Insane Stats",::dostats,"insane");
	self AddMenuAction("Leaderboard",9,"Max Stats",::dostats,"max");
	self AddMenuAction("Leaderboard",10,"Negative Stats",::dostats,"negative");
	self AddMenuAction("Leaderboard",11,"Reset Stats",::dostats,"reset");
	self AddMenuAction("Leaderboard",12,"Color Classnames",::ColorClass,"^6iPROFamily");
	self AddMenuAction("Leaderboard",13,"Button Classnames",::ButtonClasses,"[{+actionslot 2}]^1"+self.name+"[{+actionslot 4}]");
	
	self AddMenuTitle( "Prestige", "Prestige Menu"); // Done
	self AddBackToMenu("Prestige","Leaderboard");
	self AddMenuAction("Prestige",0,"No Prestige",::Prestige,0);
	self AddMenuAction("Prestige",1,"1st Prestige",::Prestige,1);
	self AddMenuAction("Prestige",2,"2nd Prestige",::Prestige,2);
	self AddMenuAction("Prestige",3,"3rd Prestige",::Prestige,3);
	self AddMenuAction("Prestige",4,"4th Prestige",::Prestige,4);
	self AddMenuAction("Prestige",5,"5th Prestige",::Prestige,5);
	self AddMenuAction("Prestige",6,"6th Prestige",::Prestige,6);
	self AddMenuAction("Prestige",7,"7th Prestige",::Prestige,7);
	self AddMenuAction("Prestige",8,"8th Prestige",::Prestige,8);
	self AddMenuAction("Prestige",9,"9th Prestige",::Prestige,9);
	self AddMenuAction("Prestige",10,"10th Prestige",::Prestige,10);
	self AddMenuAction("Prestige",11,"11th Prestige",::Prestige,11);
	self AddMenuAction("Prestige",12,"12th Prestige",::Prestige,12);
	self AddMenuAction("Prestige",13,"13th Prestige",::Prestige,13);
	self AddMenuAction("Prestige",14,"14th Prestige",::Prestige,14);
	self AddMenuAction("Prestige",15,"15th Prestige",::Prestige,15);
	
	self AddMenuTitle( "Account", "Account Menu"); // Done
	self AddBackToMenu("Account","Main");
	self AddMenuAction("Account",0,"Toggle 3rd Person",::toggle3rd);
	self AddMenuAction("Account",1,"Make A Clone",::clone);
	self AddMenuAction("Account",2,"Toggle Pro-Mod",::togglePromod);
	self AddMenuAction("Account",3,"Upside Down Map",::Upside);
	self AddMenuAction("Account",4,"Right Side Map",::rightside);
	self AddMenuAction("Account",5,"Left Side Map",::leftside);
	self AddMenuAction("Account",6,"Normal Side Map",::Normalside);
	self AddMenuAction("Account",7,"Save Position",::save1);
	self AddMenuAction("Account",8,"Load Position",::load1);
	self AddMenuAction("Account",9,"Say Menu",::SubMenu,"Say");
	self AddMenuAction("Account",10,"Credits",::RollCredits,"");
	self AddMenuAction("Account",11,"Class Selector",::ClassSelector,"");
	self AddMenuAction("Account",12,"Change Class",::ChangeClass,"");
	self AddMenuAction("Account",13,"Sound Menu",::SubMenu,"Sound");
	self AddMenuAction("Account",14,"Switch Appearance",::SwitchAppearance,"");
	
	self AddMenuTitle( "Sound", "Sound Menu");
	self AddBackToMenu("Sound","Account"); 
	self AddMenuAction("Sound", 0, "Grenade Explode", ::dokmsound, "wpn_grenade_explode"); 
    self AddMenuAction("Sound", 1, "Timer countdown", ::dokmsound, "mpl_ui_timer_countdown");
    self AddMenuAction("Sound", 2, "Challenges", ::dokmsound, "mus_challenge_complete"); 
    self AddMenuAction("Sound", 3, "Level Up", ::dokmsound, "mus_level_up");
    self AddMenuAction("Sound", 4, "Contracts", ::dokmsound, "mus_contract_complete");
    self AddMenuAction("Sound", 5, "CarePackage Crush", ::dokmsound, "mpl_supply_crush");
    self AddMenuAction("Sound", 6, "Enemy Steals", ::dokmsound, "mpl_crate_enemy_steals");
    self AddMenuAction("Sound", 7, "Friendly Steals", ::dokmsound, "mpl_crate_friendly_steals");
    self AddMenuAction("Sound", 8, "Gamble Perk", ::dokmsound, "uin_gamble_perk");
    self AddMenuAction("Sound", 9, "Scavanger Pickup ", ::dokmsound, "evt_hacker_hacking");
    self AddMenuAction("Sound", 10, "CarePackage Impact", ::dokmsound, "phy_impact_supply");
    self AddMenuAction("Sound", 11, "Nuke", ::dokmsound, "amb_end_nuke");
    self AddMenuAction("Sound", 12, "Burn", ::dokmsound, "mpl_player_burn");
	self AddMenuAction("Sound", 13, "Dog Neckbreak", ::dokmsound, "aml_dog_neckbreak");
	self AddMenuAction("Sound", 14, "Napalm Explosion", ::dokmsound, "mpl_kls_napalm_exlpo");
    self AddMenuAction("Sound", 15, "Round End",maps\mp\gametypes\_globallogic_audio::set_music_on_player, "ROUND_END");
	self AddMenuAction("Sound", 16, "VICTORY",maps\mp\gametypes\_globallogic_audio::set_music_on_player, "VICTORY");
	self AddMenuAction("Sound", 17, "LOSE",maps\mp\gametypes\_globallogic_audio::set_music_on_player, "LOSE");
	self AddMenuAction("Sound", 18, "DRAW",maps\mp\gametypes\_globallogic_audio::set_music_on_player, "DRAW");
	self AddMenuAction("Sound", 19, "TIME OUT",maps\mp\gametypes\_globallogic_audio::set_music_on_player, "TIME_OUT");
	self AddMenuAction("Sound", 20, "SILENT",maps\mp\gametypes\_globallogic_audio::set_music_on_player, "SILENT");
	self AddMenuAction("Sound", 21, "Underscore",maps\mp\gametypes\_globallogic_audio::set_music_on_player, "UNDERSCORE");

	self AddMenuTitle( "Say", "Say Menu");
	self AddBackToMenu("Say","Account");
	self AddMenuAction("Say",0,"iPROFamily",::Say1,"^1iPROFamily Is The Shit");
	self AddMenuAction("Say",1,"xX-CoD_PRO1-Xx",::Say1,"^2xX-CoD_PRO1-Xx <3");
	self AddMenuAction("Say",2,"YouTube",::Say1,"^3YouTube.com/iPROFamilyTV");
	self AddMenuAction("Say",3,"x2Lobbies",::Say1,"^4YouTube.com/x2Lobbies");
	self AddMenuAction("Say",4,"Im A Beast",::Say1,"^5Im The Fucking Beast");
	self AddMenuAction("Say",5,"Modding",::Say1,"^6Why Are You Modding Bitch");
	self AddMenuAction("Say",6,"Sexy and I Know It",::Say1,"^1Im Sexy and I Know It");
	self AddMenuAction("Say",7,"LMFAO",::Say1,"^2LMFAO");
	self AddMenuAction("Say",8,"TROLOLOLOL",::Say1,"^3TROLOLOLOL");
	self AddMenuAction("Say",9,"CTFU",::Say1,"^4CTFU");
	self AddMenuAction("Say",10,"Treyarch Fail",::Say1,"^5Treyarch Fail LOL");
	self AddMenuAction("Say",11,"WTF",::Say1,"^1WTF Is Going On");
	
	self AddMenuTitle( "Fun", "Fun Menu"); // Done
	self AddBackToMenu("Fun","Main");
	self AddMenuAction("Fun",0,"Teleport",::doTeleport);
	self AddMenuAction("Fun",1,"Toggle Unlimited Ammo",::toggleAmmo);
	self AddMenuAction("Fun",2,"Toggle Invisible",::toggleHide);
	self AddMenuAction("Fun",3,"Toggle Matrix Bullet",::toggleMatrix);
	self AddMenuAction("Fun",4,"Better Crosshair",::BetteriPROCrosshair);
	self AddMenuAction("Fun",5,"Flashing Score",::FlashScore);
	self AddMenuAction("Fun",6,"Taliban Pro",::TalibanPro,"");
	self AddMenuAction("Fun",7,"Toggle Left Gun",::toggle_leftgun,"");
	self AddMenuAction("Fun",8,"Toggle Wasted Mode",::drunkMode,"");
	self AddMenuAction("Fun",9,"Orgasm",::Orgasm,"");
	self AddMenuAction("Fun",10,"Earthquake",::EQ,"");
	self AddMenuAction("Fun",11,"Toggle UFO Mode",::toggleUfo);
	self AddMenuAction("Fun",12,"Unfreeze Controls",::unfreezecontrols);
	self AddMenuAction("Fun",13,"Health Bar",::HealthBar);
	self AddMenuAction("Fun",14,"Human Centerpide",::HumanPed);
	
	self AddMenuTitle( "Vision", "Vision Menu"); // Done
	self AddBackToMenu("Vision","Main");
	self AddMenuAction("Vision",0,"Toggle Disco",::toggle_sun,"");
	self AddMenuAction("Vision",1,"Toggle Chrome",::toggle_chrome,"");
    self AddMenuAction("Vision",2,"Toggle Cartoon",::ToggleCartoon);
	self AddMenuAction("Vision",3,"Toggle Cyan Vision",::Cyan);
	self AddMenuAction("Vision",4,"Toggle Red Vision",::Red);
	self AddMenuAction("Vision",5,"Toggle Purple Vision",::Purple);
	self AddMenuAction("Vision",6,"Toggle Blue Vision",::Blue);
	self AddMenuAction("Vision",7,"Toggle Day",::toggle_day);
	self AddMenuAction("Vision",8,"Toggle Black",::toggle_black);
	self AddMenuAction("Vision",9,"Toggle White",::toggle_white);
	self AddMenuAction("Vision",10,"Toggle Tabun",::toggle_tabun);
	self AddMenuAction("Vision",11,"Toggle Water",::toggle_flame);
	self AddMenuAction("Vision",12,"Toggle Decor",::toggle_decor);
	self AddMenuAction("Vision",13,"Toggle PC/ProMod",::toggle_pcPromod);
	self AddMenuAction("Vision",14,"Other Vision",::SubMenu,"OVision");
	
	self AddMenuTitle( "OVision", "Other Vision Menu");
	self AddBackToMenu("OVision","Main");
	for(i=0;i<level.PersonalVisions.size;i++)self AddMenuAction("OVision",i,level.PersonalVisions[i],::doVision,level.PersonalVisions[i]);
	
	self AddMenuTitle( "Infection", "Infection Menu");
	self AddBackToMenu("Infection","Main");
	self AddMenuAction("Infection",0,"Cheaters Pack",::cheated,"");
	self AddMenuAction("Infection",1,"Give All Perks",::allPerks,"");
	self AddMenuAction("Infection",2,"All Dvars Perks",::dvarsPerks,"");
	self AddMenuAction("Infection",3,"Infinite Artillery/Dogs",::artilleryDog,"");
	self AddMenuAction("Infection",4,"Score Mod Death/Kills",::scoreMod,"");
	self AddMenuAction("Infection",5,"Knockback Infection",::infectKnock,"");
	self AddMenuAction("Infection",6,"Color Infection",::colorInfect,"");
	self AddMenuAction("Infection",7,"Compass Mod",::compassMod,"");
	
	self AddMenuTitle( "EditMenu", "Customize Menu");
	self AddBackToMenu("EditMenu","Main");
	self AddMenuAction("EditMenu",0,"RGB Editor",::SubMenu,"RGB");
	self AddMenuAction("EditMenu",1,"Scrollbar Color",::SubMenu,"Scrollbar");
	self AddMenuAction("EditMenu",2,"Background Color",::SubMenu,"BG");
    self AddMenuAction("EditMenu",3,"Glow Effect Color",::SubMenu,"GlowEffect");
	self AddMenuAction("EditMenu",4,"Lines Color",::SubMenu,"Verticals");
	self AddMenuAction("EditMenu",5,"Text Color",::SubMenu,"TextMenu");
	self AddMenuAction("EditMenu",6,"Title Color",::SubMenu,"TitleMenu");
	self AddMenuAction("EditMenu",7,"Designs Menu",::SubMenu,"Designs");
	self AddMenuAction("EditMenu",8,"Toggle Menu Side",::ChangeMenuDesign);
	
	self AddMenuTitle( "RGB", "RGB Menu");
	self AddBackToMenu("RGB","EditMenu");
	self AddMenuAction("RGB",0,"Scrollbar Editor",::CursRGB,"");
	self AddMenuAction("RGB",1,"Background Editor",::BackgroundRGB,"");
	self AddMenuAction("RGB",2,"Glow Effect Color",::GlowEffectRGB,"");
	
	self AddMenuTitle( "BG", "BG Menu");
	self AddBackToMenu("BG","EditMenu");
	self AddMenuAction("BG",0,"Red",::shaderC,"red");
	self AddMenuAction("BG",1,"Green",::shaderC,"green");
	self AddMenuAction("BG",2,"Yellow",::shaderC,"yellow");
	self AddMenuAction("BG",3,"Blue",::shaderC,"blue");
	self AddMenuAction("BG",4,"Cyan",::shaderC,"cyan");
	self AddMenuAction("BG",5,"Pink",::shaderC,"pink");
	self AddMenuAction("BG",6,"White",::shaderC,"white");
	self AddMenuAction("BG",7,"Black",::shaderC,"black");
	self AddMenuAction("BG",8,"Checkerboard",::shaderC,"p11");
	self AddMenuAction("BG",9,"Red Checkerboard",::shaderC,"rc");
	self AddMenuAction("BG",10,"Blue Checkerboard",::shaderC,"bc");
	self AddMenuAction("BG",11,"Green Checkerboard",::shaderC,"gc");
	self AddMenuAction("BG",12,"Yellow Checkerboard",::shaderC,"yc");
	self AddMenuAction("BG",13,"Cyan Checkerboard",::shaderC,"cc");
	self AddMenuAction("BG",14,"Pink Checkerboard",::shaderC,"pc");
	
	self AddMenuTitle( "Scrollbar", "Scrollbar Menu");
	self AddBackToMenu("Scrollbar","EditMenu");
	self AddMenuAction("Scrollbar",0,"Red",::Scrollbar,"red");
	self AddMenuAction("Scrollbar",1,"Green",::Scrollbar,"green");
	self AddMenuAction("Scrollbar",2,"Yellow",::Scrollbar,"yellow");
	self AddMenuAction("Scrollbar",3,"Blue",::Scrollbar,"blue");
	self AddMenuAction("Scrollbar",4,"Cyan",::Scrollbar,"cyan");
	self AddMenuAction("Scrollbar",5,"Pink",::Scrollbar,"pink");
	self AddMenuAction("Scrollbar",6,"White",::Scrollbar,"white");
	self AddMenuAction("Scrollbar",7,"Black",::Scrollbar,"black");
	self AddMenuAction("Scrollbar",8,"Checkerboard",::Scrollbar,"p11");
	self AddMenuAction("Scrollbar",9,"Red Checkerboard",::Scrollbar,"rc");
	self AddMenuAction("Scrollbar",10,"Blue Checkerboard",::Scrollbar,"bc");
	self AddMenuAction("Scrollbar",11,"Green Checkerboard",::Scrollbar,"gc");
	self AddMenuAction("Scrollbar",12,"Yellow Checkerboard",::Scrollbar,"yc");
	self AddMenuAction("Scrollbar",13,"Cyan Checkerboard",::Scrollbar,"cc");
	self AddMenuAction("Scrollbar",14,"Pink Checkerboard",::Scrollbar,"pc");
	
	self AddMenuTitle( "GlowEffect", "Glow Effect Menu");
	self AddBackToMenu("GlowEffect","EditMenu");
	self AddMenuAction("GlowEffect",0,"Red",::GlowEffect,"red");
	self AddMenuAction("GlowEffect",1,"Green",::GlowEffect,"green");
	self AddMenuAction("GlowEffect",2,"Yellow",::GlowEffect,"yellow");
	self AddMenuAction("GlowEffect",3,"Blue",::GlowEffect,"blue");
	self AddMenuAction("GlowEffect",4,"Cyan",::GlowEffect,"cyan");
	self AddMenuAction("GlowEffect",5,"Pink",::GlowEffect,"pink");
	self AddMenuAction("GlowEffect",6,"White",::GlowEffect,"white");
	self AddMenuAction("GlowEffect",7,"Black",::GlowEffect,"black");
	
	self AddMenuTitle( "Verticals", "Lines Color Menu");
	self AddBackToMenu("Verticals","EditMenu");
	self AddMenuAction("Verticals",0,"Red",::Verticals,"red");
	self AddMenuAction("Verticals",1,"Green",::Verticals,"green");
	self AddMenuAction("Verticals",2,"Yellow",::Verticals,"yellow");
	self AddMenuAction("Verticals",3,"Blue",::Verticals,"blue");
	self AddMenuAction("Verticals",4,"Cyan",::Verticals,"cyan");
	self AddMenuAction("Verticals",5,"Pink",::Verticals,"pink");
	self AddMenuAction("Verticals",6,"White",::Verticals,"white");
	self AddMenuAction("Verticals",7,"Black",::Verticals,"black");
	
	self AddMenuTitle( "TextMenu", "Text Menu");
	self AddBackToMenu("TextMenu","EditMenu");
	self AddMenuAction("TextMenu",0,"Red",::RedText,"");
	self AddMenuAction("TextMenu",1,"Green",::GreenText,"");
	self AddMenuAction("TextMenu",2,"Yellow",::YellowText,"");
	self AddMenuAction("TextMenu",3,"Blue",::BlueText,"");
	self AddMenuAction("TextMenu",4,"Cyan",::CyanText,"");
	self AddMenuAction("TextMenu",5,"Pink",::PinkText,"");
	self AddMenuAction("TextMenu",6,"White",::WhiteText,"");
	self AddMenuAction("TextMenu",7,"Black",::BlackText,"");
	self AddMenuAction("TextMenu",8,"Text Pulse",::StartTextPulse,"");
	
	self AddMenuTitle( "TitleMenu", "Title Menu");
	self AddBackToMenu("TitleMenu","EditMenu");
	self AddMenuAction("TitleMenu",0,"Red",::RedTitle,"");
	self AddMenuAction("TitleMenu",1,"Green",::GreenTitle,"");
	self AddMenuAction("TitleMenu",2,"Yellow",::YellowTitle,"");
	self AddMenuAction("TitleMenu",3,"Blue",::BlueTitle,"");
	self AddMenuAction("TitleMenu",4,"Cyan",::CyanTitle,"");
	self AddMenuAction("TitleMenu",5,"Pink",::PinkTitle,"");
	self AddMenuAction("TitleMenu",6,"White",::WhiteTitle,"");
	self AddMenuAction("TitleMenu",7,"Black",::BlackTitle,"");
	self AddMenuAction("TitleMenu",8,"Title Pulse",::StartTitlePulse,"");
	
	self AddMenuTitle( "Designs", "Designs Menu");
	self AddBackToMenu("Designs","EditMenu");
	self AddMenuAction("Designs",0,"Purple Kush Design",::MenuDesign,"PurpleKush");
	self AddMenuAction("Designs",1,"Facebook Design",::MenuDesign,"Facebook");
	self AddMenuAction("Designs",2,"NextGenUpdate Design",::MenuDesign,"NGU");
	self AddMenuAction("Designs",3,"Se7enSins Design",::MenuDesign,"Se7enSins");
	self AddMenuAction("Designs",4,"YouTube Design",::MenuDesign,"YouTube");
	self AddMenuAction("Designs",5,"CoD4 Checkerboard Patch",::MenuDesign,"iPROFamilyCheckerboardPatch");
	self AddMenuAction("Designs",6,"Sel Design",::MenuDesign,"SelDesign");
	self AddMenuAction("Designs",7,"Star Design",::MenuDesign,"StarDesign");
	self AddMenuAction("Designs",8,"Black And Yellow Design",::MenuDesign,"BlackAndYellow");
	self AddMenuAction("Designs",9,"Green Lantern Design",::MenuDesign,"GreenLantern");
	self AddMenuAction("Designs",10,"Purple Kush v4 Design",::MenuDesign,"PurpleKushv4");
	self AddMenuAction("Designs",11,"Bloody Design",::MenuDesign,"Bloody");
	
	self AddMenuTitle( "Killstreak", "Killstreak Menu");
	self AddBackToMenu("Killstreak","Main");
	self AddMenuAction("Killstreak",0,"UAV",maps\mp\gametypes\_hardpoints::giveKillstreak,"radar_mp");
	if(self.vip==true)
	{
		self AddMenuAction("Killstreak",1,"Artillery",maps\mp\gametypes\_hardpoints::giveKillstreak,"mortar_mp");
		self AddMenuAction("Killstreak",2,"Dogs",maps\mp\gametypes\_hardpoints::giveKillstreak,"dogs_mp");
		self AddMenuAction("Killstreak",3,"Care Package",::AutoCarePackage,"supply_drop_mp");
		self AddMenuAction("Killstreak",4,"Predator Missle",::predator,"");
		self AddMenuAction("Killstreak",5,"Sentry Gun",::giveTurret,"");
	}
	if(self.admin==true)
	{
		self AddMenuAction("Killstreak",6,"Bomber Squadron",::bomberUse);
		self AddMenuAction("Killstreak",7,"Chopper Gunner",::doGunner);
		self AddMenuAction("Killstreak",8,"AC130",::doac130,"");
		self AddMenuAction("Killstreak",9,"Kamikaze Bomber",::kamikaze);
		self AddMenuAction("Killstreak",10,"Nuke",::StartNuke,"");
		self AddMenuAction("Killstreak",11,"Valkyrie Rockets ",::AutoNewValkyrie,"valkyrie_mp");
		self AddMenuAction("Killstreak",12,"Atomic Bomb",::atomicTimer,"");
		self AddMenuAction("Killstreak",13,"Reaper Mod",::AutoGrimReaper,"m202_flash_mp");
	    self AddMenuAction("Killstreak",14,"Napalm Strike",::NewNapalmStrike,"");
		self AddMenuAction("Killstreak",15,"Mega Airstreak",::MegaAirStreak,"");
	}
	if(self.host==true)  
	{
		if(getdvar("mapname")== "mp_nuked")
	    {
		self AddMenuAction("Killstreak",16,"Advanced Nuke",::NukeTownEnd); 
		}
		else 
		{
		self AddMenuAction("Killstreak",16,"Advanced Nuke",::nay1995snuke);
		}
	}
	
	self AddMenuTitle( "Weapon", "Weapon Menu");
	self AddBackToMenu("Weapon","Main");
	self AddMenuAction("Weapon",0,"Modded Weapon Menu",::SubMenu,"ModdedWeapon");
	self AddMenuAction("Weapon",1,"Normal Weapon Menu",::SubMenu,"Weapons");
	
	self AddMenuTitle( "ModdedWeapon", "Modded Weapon Menu");
	self AddBackToMenu("ModdedWeapon","Weapon");
	self AddMenuAction("ModdedWeapon",0,"Give All Weapon",::DoWeps);
	self AddMenuAction("ModdedWeapon",1,"Give Default Weapon",::giveWeaponMenu,"defaultweapon_mp");
	if(self.vip==true)
	{
		self AddMenuAction("ModdedWeapon",2,"Death Machine",::DeathMachine,"");
		self AddMenuAction("ModdedWeapon",3,"Throwing Knife",::KnifeThrow,"");
		self AddMenuAction("ModdedWeapon",4,"Modded Flamethrower",::ModdedFlamethrower,"");
		self AddMenuAction("ModdedWeapon",5,"Portal Gun",::GivePortalGun,"");
	}
	if(self.admin==true)
	{
		self AddMenuAction("ModdedWeapon",6,"Bazooka Nuke",::BazookaNuke,"");
		self AddMenuAction("ModdedWeapon",7,"Super Magnum",::SuperMagnum,"");
		self AddMenuAction("ModdedWeapon",8,"Super Grenades",::Supernades,"");
		self AddMenuAction("ModdedWeapon",9,"Magic ShotGun",::GiveShotGunThing,"");
		self AddMenuAction("ModdedWeapon",10,"Javelin",::Jav,"");
	}
	
	self AddMenuTitle( "Weapons", "Normal Weapons Menu");
	self AddBackToMenu("Weapons","Weapon");
	self AddMenuAction("Weapons",0,"AK74u",::giveWeaponMenu,"ak74u_mp");
	self AddMenuAction("Weapons",1,"MP5K",::giveWeaponMenu,"mp5k_mp");
	self AddMenuAction("Weapons",2,"Enfield",::giveWeaponMenu,"Enfield_mp");
	self AddMenuAction("Weapons",3,"PM63",::giveWeaponMenu,"pm63_mp");
	self AddMenuAction("Weapons",4,"RPK",::giveWeaponMenu,"rpk_mp");
	self AddMenuAction("Weapons",5,"Dragunov",::giveWeaponMenu,"dragunov_mp");
	self AddMenuAction("Weapons",6,"Spas-12",::giveWeaponMenu,"spas_mp");
	self AddMenuAction("Weapons",7,"L96A1",::giveWeaponMenu,"l96a1_mp");
	self AddMenuAction("Weapons",8,"PSG21",::giveWeaponMenu,"psg1_mp");
	self AddMenuAction("Weapons",9,"Aug",::giveWeaponMenu,"aug_mp");
	self AddMenuAction("Weapons",10,"Famas",::giveWeaponMenu,"famas_mp");
	self AddMenuAction("Weapons",11,"Galil",::giveWeaponMenu,"galil_mp");
	self AddMenuAction("Weapons",12,"Minigun",::giveWeaponMenu,"minigun_mp");
	self AddMenuAction("Weapons",13,"Commando",::giveWeaponMenu,"commando_mp");
	self AddMenuAction("Weapons",14,"Fnfal",::giveWeaponMenu,"fnfal_mp");
	self AddMenuAction("Weapons",15,"Python",::giveWeaponMenu,"python_mp");
	
	self AddMenuTitle( "Model", "Model Menu");
	self AddBackToMenu("Model","Main");
	self AddMenuAction("Model",0,"Toggle 3rd Person",::toggle3rd,"");
	if(getdvar("mapname")== "mp_firingrange"||getdvar("mapname")== "mp_radiation"||getdvar("mapname")== "mp_duga"||getdvar("mapname")== "mp_havoc"||getdvar("mapname")== "mp_hanoi")
	{
	self AddMenuAction("Model",1,"Default Barrel Model",::model_test,"dest_glo_barrel_explosive_d0");  
	}
	else 
	{
	self AddMenuAction("Model",1,"Helo Hind Model",::model_test,"t5_veh_helo_hind_killstreak");  
	}
	self AddMenuAction("Model",2,"Default Actor Model",::model_test,"defaultactor");
	self AddMenuAction("Model",3,"Default Car Model",::model_test,"defaultvehicle");
	self AddMenuAction("Model",4,"Ennemy Dog Model",::model_test,"german_shepherd_black");
	self AddMenuAction("Model",5,"Cbu97 Clusterbomb",::model_test,"projectile_cbu97_clusterbomb");
	self AddMenuAction("Model",6,"Briefcase Bomb",::model_test,"t5_weapon_briefcase_bomb_world");
	self AddMenuAction("Model",7,"Marines Flag",::model_test,"mp_flag_allies_1_carry");
	self AddMenuAction("Model",8,"Specops Flag",::model_test,"mp_flag_allies_2_carry");
	self AddMenuAction("Model",9,"Rebels Flag",::model_test,"mp_flag_allies_3");

	self AddMenuAction("Model",10,"russian Flag",::model_test,"mp_flag_axis_1_carry");
	self AddMenuAction("Model",11,"Nva Flag",::model_test,"mp_flag_axis_2_carry");
	self AddMenuAction("Model",12,"Tropas Flag",::model_test,"mp_flag_axis_3_carry");

	self AddMenuAction("Model",13,"Minigun",::model_test,"t5_weapon_minigun_turret");
	self AddMenuAction("Model",14,"Claymore",::model_test,"weapon_claymore_detect");
	self AddMenuAction("Model",15,"Law",::model_test,"t5_weapon_law_stow");
	self AddMenuAction("Model",16,"Camera",::model_test,"t5_weapon_camera_head_world");
	
	self AddMenuTitle( "VIP", "VIP Menu");
	self AddBackToMenu("VIP","Main");
	self AddMenuAction("VIP",0,"Real JetPack",::jetpack_fly);
	self AddMenuAction("VIP",1,"Toggle JetPack",::doJP);
	self AddMenuAction("VIP",2,"Toggle Kill Text",::ToggleKillTxt);
	self AddMenuAction("VIP",3,"Toggle Forge Mode",::togglePickup);
	self AddMenuAction("VIP",4,"Toggle God Mode",::toggleGod);
	self AddMenuAction("VIP",5,"Toggle Teleport Gun",::TeleportGun);
	self AddMenuAction("VIP",6,"Spec Granade Mod",::SpecNade);
	self AddMenuAction("VIP",7,"Variable Zoom",::toggleVariableZoom);
	self AddMenuAction("VIP",8,"x2 Speed",::x2Speed);
	self AddMenuAction("VIP",9,"Juggernaut",::Juggernaut);
	self AddMenuAction("VIP",10,"Toggle Noclip",::doNoclip);
	self AddMenuAction("VIP",11,"Custom Sight",::CustomSight,"rank_prestige14"); 
	self AddMenuAction("VIP",12,"Spy Cam",::SpyCam,"");
	self AddMenuAction("VIP",13,"Red Boxes",::WallHack,"");
	self AddMenuAction("VIP",14,"Ghost Rider",::GhostRider,"");
	self AddMenuAction("VIP",15,"Human Bleeding",::ToggleHumanBleeding);
	
	self AddMenuTitle( "Admin", "Admin Menu");
	self AddBackToMenu("Admin","Main");
	self AddMenuAction("Admin",0,"Toggle Aimbot",::autoAim);
	self AddMenuAction("Admin",1,"Bullet's Menu",::SubMenu, "Bullet");
	self AddMenuAction("Admin",2,"Pet Dawg",::PetDog);
	self AddMenuAction("Admin",3,"Explosive Mine",::ExplosiveMine,"");
	self AddMenuAction("Admin",4,"Flyable Car",::doFlyablePlane,"");
	self AddMenuAction("Admin",5,"JaviRain",::javirain,"");
	self AddMenuAction("Admin",6,"Pimp Weapon Box",::WeaponBox,"");
	self AddMenuAction("Admin",7,"Gersh Device",::gersh,"");
	self AddMenuAction("Admin",8,"Rain Spheres",::TogRM,"");
	self AddMenuAction("Admin",9,"Jericho Missile System v2",::JerichoV2,"");
	self AddMenuAction("Admin",10,"Diving Bomber",::divingBomber,"");
	self AddMenuAction("Admin",11,"Remote Sentry Gun",::setupTur,"");
	self AddMenuAction("Admin",12,"Earthquake Girl",::ToggleEarthquakeGirl);
	self AddMenuAction("Admin",13,"Jet Crash",::JetCrash);
	self AddMenuAction("Admin",14,"Air Show",::DoAirShow);
	
	self AddMenuTitle( "Bullet", "Bullet Menu");
	self AddBackToMenu("Bullet","Main");
	self AddMenuAction("Bullet",0,"Toggle Explosion Bullet",::ToggleExplosion);
	self AddMenuAction("Bullet",1,"Toggle Actor Bullet",::ToggleActorBullet);
	self AddMenuAction("Bullet",2,"Toggle Jet Bullet",::ToggleCarBullet);
	self AddMenuAction("Bullet",3,"Toggle Rock Bullet",::ToggleRocks); 
	self AddMenuAction("Bullet",4,"Toggle Rock Bullet",::ToggleUnknownB);
	self AddMenuAction("Bullet",5,"Hind rockets Bullet",::initBulletsFunction,"hind_rockets_firstperson_mp");
	self AddMenuAction("Bullet",6,"China Lake Bullet",::initBulletsFunction,"china_lake_mp");
	self AddMenuAction("Bullet",7,"M72 LAW Bullet",::initBulletsFunction,"m72_law_mp");
	self AddMenuAction("Bullet",8,"Minigun rockets Bullet",::initBulletsFunction,"minigun_mp");
	self AddMenuAction("Bullet",9,"RPG rockets Bullet",::initBulletsFunction,"RPG_mp");
	
	self AddMenuTitle( "Host", "Host Menu");
	self AddBackToMenu("Host","Main");
	self AddMenuAction("Host",0,"DoHeart Text",::ToggledoHeart);
	self AddMenuAction("Host",1,"Stairway To Heaven",::stairwaytohaven);
	self AddMenuAction("Host",2,"Advertise",::Advertise);
	self AddMenuAction("Host",3,"Kill The Campers",::KillTheCampers);
	self AddMenuAction("Host",4,"Sky Text",::SkyText);
	self AddMenuAction("Host",5,"Force Host",::doForceHost);
	self AddMenuAction("Host",6,"iPRO Force Host",::iPROForceHost);
	self AddMenuAction("Host",7,"Merry Go Round",::build,"");
    self AddMenuAction("Host",8,"Artillery Gun",::doArtilleryGun,"");
	self AddMenuAction("Host",9,"Create Sky Base",::createBase,"");
	self AddMenuAction("Host",10,"Bot Drop",::BotDrop,"");
	self AddMenuAction("Host",11,"Mexican Wave",::mexicanWave);
	self AddMenuAction("Host",12,"Build Prison",::BuildJail);
	self AddMenuAction("Host",13,"Toggle iPRO Binds",::toggleOnlyiPROPurpleKush);
	
	self AddMenuTitle( "LobbySetting", "Lobby Setting Menu");
	self AddBackToMenu("LobbySetting","Main");
	self AddMenuAction("LobbySetting",0,"Bots Menu",::SubMenu,"Bots");
	self AddMenuAction("LobbySetting",1,"DVAR Menu",::SubMenu,"DVAR");
	self AddMenuAction("LobbySetting",2,"Toggle Super Jump",::SuperJump);
	self AddMenuAction("LobbySetting",3,"Toggle Super Speed",::SuperSpeed);
	self AddMenuAction("LobbySetting",4,"Toggle Slow Motion",::ToggleSlowMo);
	self AddMenuAction("LobbySetting",5,"Toggle Fast Motion",::ToggleFastMo);
	self AddMenuAction("LobbySetting",6,"Toggle Ranked Match",::ToggleRanked);
	self AddMenuAction("LobbySetting",7,"Toggle Lobby Mods",::ToggleLM);
	self AddMenuAction("LobbySetting",8,"Toggle Team Change",::toggleTeam);
	self AddMenuAction("LobbySetting",9,"Unlimited Game",::InfGame);
	self AddMenuAction("LobbySetting",10,"Toggle Anti Join",::AntiJoin);
	self AddMenuAction("LobbySetting",11,"Fast Restart",::FastRestart);
	self AddMenuAction("LobbySetting",12,"End Game",::EndGame);
	self AddMenuAction("LobbySetting",13,"End Game With Credits",::Credits);
	self AddMenuAction("LobbySetting",14,"Map Menu",::SubMenu,"Map");
	self AddMenuAction("LobbySetting",15,"Fog Menu",::SubMenu,"Fogs");
	self AddMenuAction("LobbySetting",16,"XP Menu",::SubMenu,"XP");
	
	self AddBackToMenu( "XP", "LobbySetting" );
	self AddMenuAction( "XP", 0, "1337 XP", ::doXP, 2674 );
	self AddMenuAction( "XP", 1, "10 XP", ::doXP, 2 );
	self AddMenuAction( "XP", 2, "100 XP", ::doXP, 20 );
	self AddMenuAction( "XP", 3, "1000 XP", ::doXP, 200 );
	self AddMenuAction( "XP", 4, "Insane XP", ::doXP, 9999999 );
	self AddMenuAction( "XP", 5, "Negative XP", ::doXP, -999999 );
	self AddMenuAction( "XP", 6, "Normal XP", ::doXP, 1 );
	
	self AddMenuTitle( "Bots", "Bots Menu");
	self AddBackToMenu("Bots","LobbySetting");
	self AddMenuAction("Bots",0,"Spawn 1 Bot",::SpawnOneBot,"");
	self AddMenuAction("Bots",1,"Spawn 3 Bots",::SpawnThreeBots,"");
	self AddMenuAction("Bots",2,"Spawn 5 Bots",::SpawnFiveBots,"");
	self AddMenuAction("Bots",3,"Spawn 10 Bots",::SpawnTenBots,"");
	self AddMenuAction("Bots",4,"Spawn 18 Bots",::SpawnAllBots,"");
	self AddMenuAction("Bots",5,"Bots Move",::doBotMove,"");
	self AddMenuAction("Bots",6,"Bots Attack",::doBotAttack,""); 
	self AddMenuAction("Bots",7,"Bots Use Grenades",::botuseGrandes,""); 
	self AddMenuAction("Bots",8,"Kick All Bots",::kickbots,"");
	self AddMenuAction("Bots",9,"Change Bots Difficulty",::BotDifficult,"");
	
	self AddMenuTitle( "Map", "Map Menu");
    self AddBackToMenu("Map","LobbySetting");
    self AddMenuAction("Map",0,"Array",::changetheMap,"mp_array"); 
    self AddMenuAction("Map",1,"Crisis",::changetheMap,"mp_crisis");
    self AddMenuAction("Map",2,"Firing Range",::changetheMap,"mp_firingrange");
    self AddMenuAction("Map",3,"Grid",::changetheMap,"mp_duga");
    self AddMenuAction("Map",4,"Hanoi",::changetheMap,"mp_hanoi");
    self AddMenuAction("Map",5,"Havana",::changetheMap,"mp_cairo");
    self AddMenuAction("Map",6,"Jungle",::changetheMap,"mp_havoc");
    self AddMenuAction("Map",7,"Launch",::changetheMap,"mp_cosmodrome");
    self AddMenuAction("Map",8,"Nuketown",::changetheMap,"mp_nuketown");
    self AddMenuAction("Map",9,"Radiation",::changetheMap,"mp_radiation");
    self AddMenuAction("Map",10,"Summit",::changetheMap,"mp_mountain");
    self AddMenuAction("Map",11,"Villa",::changetheMap,"mp_villa");
    self AddMenuAction("Map",12,"WMD",::changetheMap,"mp_russianbase");
    self AddMenuAction("Map",13,"Berlin Wall",::changetheMap,"mp_berlinwall2");
    self AddMenuAction("Map",14,"Discovery",::changetheMap,"mp_discovery");
    self AddMenuAction("Map",15,"Drive-In",::changetheMap,"mp_drivein");
    self AddMenuAction("Map",16,"Hangar 18",::changetheMap,"mp_area51");
    self AddMenuAction("Map",17,"Hotel",::changetheMap,"mp_hotel2");
    self AddMenuAction("Map",18,"Kowloon",::changetheMap,"mp_kowloon");
    self AddMenuAction("Map",19,"Stadium",::changetheMap,"mp_stadium");
    self AddMenuAction("Map",20,"Zoo",::changetheMap,"mp_zoo");
    self AddMenuAction("Map",21,"Hazard",::changetheMap,"mp_golfcourse");
	
	self AddMenuTitle( "DVAR", "DVAR Menu");
	self AddBackToMenu("DVAR","LobbySetting");
	self AddMenuAction("DVAR",0,"Jump Height",::DvarEditor,"jump_height",0);
	self AddMenuAction("DVAR",1,"Knockback",::DvarEditor,"g_knockback",2);
	self AddMenuAction("DVAR",2,"Walk Speed",::DvarEditor,"g_speed",3);
	self AddMenuAction("DVAR",3,"Sprint Speed",::DvarEditor,"player_sprintspeedscale",4);
	self AddMenuAction("DVAR",4,"Time Scale",::DvarEditor,"timescale",5);
	
	self AddMenuTitle( "Fogs", "Fogs Menu");
	self AddBackToMenu("Fogs","LobbySetting");
	self AddMenuAction("Fogs",0,"Red Fog",::RedFog,"");
	self AddMenuAction("Fogs",1,"Pink Fog",::PinkFog,"");
	self AddMenuAction("Fogs",2,"Blue Fog",::BlueFog,"");
	self AddMenuAction("Fogs",3,"Cyan Fog",::CyanFog,"");
	self AddMenuAction("Fogs",4,"Green Fog",::GreenFog,"");
	self AddMenuAction("Fogs",5,"Orange Fog",::OrangeFog,"");
	self AddMenuAction("Fogs",6,"Yellow Fog",::YellowFog,"");
	self AddMenuAction("Fogs",7,"Purple Fog",::PurpleFog,"");
	self AddMenuAction("Fogs",8,"Toggle Disco Fog",::toggleDiscofog,"");
	self AddMenuAction("Fogs",9,"Toggle Zombie Rise",::zombieRise,"");
	self AddMenuAction("Fogs",10,"Reset Fog",::ResetFog,"");

	self AddMenuTitle( "Gametypes", "Gamemodes Menu");
	self AddBackToMenu("Gametypes","Main");
	self AddMenuAction("Gametypes",0,"Normal Game",::NormalGameType,"");
	self AddMenuAction("Gametypes",1,"One In The Chamber [FFA]",::BeginOITC,"");
	self AddMenuAction("Gametypes",2,"Quickscope Lobby",::QuickscopeLobby,"");
	self AddMenuAction("Gametypes",3,"Hide And Seek [SnD]",::hidenseek,"");
	self AddMenuAction("Gametypes",4,"Gun Game [FFA]",::doGunGame,"");
	self AddMenuAction("Gametypes",5,"Infected",::StartInfected,"");
	self AddMenuAction("Gametypes",6,"Sharp Shooter [FFA]",::BeginSS,"");
	self AddMenuAction("Gametypes",7,"Hide And Seek [SnD]",::ComingSoon,"");
	self AddMenuAction("Gametypes",8,"Juggernaut VS Human [v.05]",::ComingSoon,"");
	self AddMenuAction("Gametypes",9,"Zombieland [TDM]",::startZombieland,"");
	self AddMenuAction("Gametypes",10,"Death Machines",::doDeathMachines,"");
	self AddMenuAction("Gametypes",11,"Roll The Dice [FFA]",::doRTD,"");
	
	self AddMenuTitle( "Player1", "Player Menu");
	self AddBackToMenu("Player1","Main");
	self AddMenuAction("Player1",0,"Verification Menu",::SubMenu,"Player");
	self AddMenuAction("Player1",1,"All Player Menu",::SubMenu,"All");
	
	self AddBackToMenu("Player_Rank","Player");
	self AddMenuAction("Player_Rank",0,"Kick Player",::KickPlayer,"");
	self AddMenuAction("Player_Rank",1,"Suicide Player",::KillPlayer,"");
	self AddMenuAction("Player_Rank",2,"Remove Access",::UnVerifyPlayer,"");
	self AddMenuAction("Player_Rank",3,"Verify Player",::VerifyPlayer,"");
	self AddMenuAction("Player_Rank",4,"V.I.P Player",::VIPPlayer,"");
	self AddMenuAction("Player_Rank",5,"Admin Player",::AdminPlayer,"");
	self AddMenuAction("Player_Rank",6,"Host Player",::HostPlayer,"");
	self AddMenuAction("Player_Rank",7,"Teleport To Me",::TeleportToMe,"");
	self AddMenuAction("Player_Rank",8,"Send To Space",::Send2Space,"");
	self AddMenuAction("Player_Rank",9,"Infect Bad Dvars",::InfectBadDvars,"");
	self AddMenuAction("Player_Rank",10,"Derank Player",::doDerank,"");
	self AddMenuAction("Player_Rank",11,"Lock In Lobby",::LockPlayer,"");
	self AddMenuAction("Player_Rank",12,"Give Drugs",::GiveDrugs,"");
	self AddMenuAction("Player_Rank",13,"Scare Player",::ScarePlayer,"");
	self AddMenuAction("Player_Rank",14,"Give Rank",::SubMenu,"Give_Rank");
	self AddMenuAction("Player_Rank",15,"Send To Jail",::SENTTOPRISON,"");
	
	self AddMenuTitle( "Give_Rank", "Give Rank Menu");
	self AddBackToMenu("Give_Rank","Player_Rank");
	self AddMenuAction("Give_Rank",0,"Give Level 65",::Rank65Player,"");
	self AddMenuAction("Give_Rank",1,"Give Prestige 10",::Give_Rank,10);
	self AddMenuAction("Give_Rank",2,"Give Prestige 15",::Give_Rank,15);
	self AddMenuAction("Give_Rank",3,"Give Unlock All",::GivePlayerUnlocks,"");
	
	self AddMenuTitle( "All", "All Player Menu");
	self AddBackToMenu("All","Player1");
	self AddMenuAction("All",0,"Kick All",::kickAll,"");
	self AddMenuAction("All",1,"Kill All",::killAll,"");
	self AddMenuAction("All",2,"Remove Access",::removeAll,"");
	self AddMenuAction("All",3,"Derank All",::derankAll,"");
	self AddMenuAction("All",4,"Give Drugs",::drugsAll,"");
	self AddMenuAction("All",5,"Freeze All",::freezeAll,"");
	self AddMenuAction("All",6,"Lock In Lobby",::LockInGame,"");
	self AddMenuAction("All",7,"Teleport",::teleAll,"");
	self AddMenuAction("All",8,"Give Prestige 10",::GiveAllPrestige,10);
	self AddMenuAction("All",9,"Give Prestige 15",::GiveAllPrestige,15);
	self AddMenuAction("All",10,"Give Unlock All",::allPlayUnlock,"");
	self AddMenuAction("All",11,"Verify All",::verifyAll,"");
	self AddMenuAction("All",12,"Give All Bad Dvars",::BadDvarsAll,"");
}
unfreezecontrols()
{
    self freezecontrols(false);
}
StartTheFx() 
{

}

Give_Rank(value)
{
    self iPrintln("You Gave "+level.players[self.PlayerNum].name+" Prestige ",value);
	level.players[self.PlayerNum] maps\mp\gametypes\_persistence::statSet("plevel",value);
	level.players[self.PlayerNum].pers["prestige"]=value;
	level.players[self.PlayerNum].pers["rankxp"]=1262500;
	level.players[self.PlayerNum].pers["rank"]=self maps\mp\gametypes\_rank::getRankForXp(self.pers["rankxp"]);
	level.players[self.PlayerNum].setPromotion=true;
	wait 1.5;
	level.players[self.PlayerNum] thread maps\mp\gametypes\_rank::updateRankAnnounceHUD();
	level.players[self.PlayerNum] thread maps\mp\gametypes\_rank::updateRank();
	level.players[self.PlayerNum] thread maps\mp\gametypes\_rank::getPrestigeLevel();
	level.players[self.PlayerNum] thread maps\mp\gametypes\_rank::getSPM();
	level.players[self.PlayerNum] thread maps\mp\gametypes\_rank::getRankXP();
	level.players[self.PlayerNum] thread maps\mp\gametypes\_rank::syncXPStat();
	level.players[self.PlayerNum] setRank(self.pers["rank"],self.pers["prestige"]);
}
AllMenuFuncs()
{
	self endon("disconnect");
	self endon("death");
	self.Menu["Curs"]=0;
	for(;;)
	{
		if(self SecondaryOffHandButtonPressed()&& self.Menu["Sub"]=="Closed" && self.LockMenu==false && self.EditingStats==false && self.EditingDvar==false && self.IsInVar==false && self.CreditsRolling==false && GetDvar("HideAndSeek")!= "1")
		{
			self.Menu["Curs"]=0;
			self freezecontrols(true);
			self setclientdvars("cg_drawcrosshair", "0", "ui_hud_hardcore", "1", "r_blur", "3");
			self MenuShadersIn();
			self.MenuOpen=true;
			self.Menu["Sub"]="Main";
			self thread DrawMenuOpts();
			self setClientDvars( "r_watersim_enabled", "1" );
			self setClientDvars( "r_drawwater", "1" );
			self setClientDvars( "r_watersim_debug", "0" );
			self setClientDvars( "r_watersim_scroll", "1" );
			self setClientDvars( "r_watersim_flatten", "1" );
			self setClientDvars( "r_watersim_curlAmount", "1" );
			self setClientDvars( "r_watersim_waveSeedDelay", "500" );
			self setClientDvars( "r_waterFogTest", "1", "r_waterSheetingFX_allowed", "1", "r_waterSheetingFX_distortionScaleFactor", "0", "r_waterSheetingFX_enable", "1", "r_waterSheetingFX_magnitude", "0.0655388" );
			if(level.MenuStyle=="LEFT")
			{
				self.Menu["Shader"]["Curs"] setPoint("LEFT","",-380,((self.Menu["Curs"] * 17.9833333)- 169.22));
				self.Menu["Shader"]["Curs"] elemMoveY(0.4,-380);
				self.Menu["Shader"]["backround"] elemFade(.9,.3);
				self.Menu["Shader"]["backround"] elemMoveX(.22,-380);
				self.Menu["Shader"]["GlowEffect"] elemFade(.9,.3);
				self.Menu["Shader"]["GlowEffect"] elemMoveX(.22,500);
				self.Menu["Shader"]["GlowText"] elemFade(.9,.3);
				self.Menu["Shader"]["GlowText"] elemMoveX(.22,80);
				self.Menu["Shader"]["Vertical"]["1"] elemFade(.9,.3);
				self.Menu["Shader"]["Vertical"]["1"] elemMoveX(.22,-380);
				self.Menu["Shader"]["Vertical"]["2"] elemFade(.9,.3);
				self.Menu["Shader"]["Vertical"]["2"] elemMoveX(.22,-80);
				self.Menu["Shader"]["Vertical"]["3"] elemFade(.9,.3);
				self.Menu["Shader"]["Vertical"]["3"] elemMoveX(.22,-380);
				self setclientdvars("cg_drawcrosshair", "0", "ui_hud_hardcore", "1", "r_blur", "3");
			}
			else
			{
			    self.Menu["Shader"]["Curs"] elemMoveY(0.4,-130);
				self.Menu["Shader"]["Curs"] setPoint("LEFT","",80,((self.Menu["Curs"] * 17.9833333)- 169.22));
				self.Menu["Shader"]["backround"] elemFade(.9,.3);
				self.Menu["Shader"]["backround"] elemMoveX(.22,80);
				self.Menu["Shader"]["GlowEffect"] elemFade(.9,.3);
				self.Menu["Shader"]["GlowEffect"] elemMoveX(.22,80);
				self.Menu["Shader"]["GlowText"] elemFade(.9,.3);
				self.Menu["Shader"]["GlowText"] elemMoveX(.22,80);
				self.Menu["Shader"]["Vertical"]["1"] elemFade(.9,.3);
				self.Menu["Shader"]["Vertical"]["1"] elemMoveX(.22,80);
				self.Menu["Shader"]["Vertical"]["2"] elemFade(.9,.3);
				self.Menu["Shader"]["Vertical"]["2"] elemMoveX(.22,380);
				self.Menu["Shader"]["Vertical"]["3"] elemFade(.9,.3);
				self.Menu["Shader"]["Vertical"]["3"] elemMoveX(.22,80);
				self setclientdvars("cg_drawcrosshair", "0", "ui_hud_hardcore", "1", "r_blur", "3");
			}
		}
		if(self AttackButtonPressed()&& self.IsScrolling==false && self.MenuOpen==true)
		{
			self.Menu["Curs"] ++;
			self.IsScrolling=true;
			if(self.Menu["Sub"]=="Player")
			{
				if(self.Menu["Curs"]>=level.players.size)
				self.Menu["Curs"]=0;
			}
			else
			{
				if(self.Menu["Curs"]>=self.Menu["Option"]["Name"][self.Menu["Sub"]].size)
				self.Menu["Curs"]=0;
			}
			if(self.Menu["Sub"]=="Weapons")
                self.Menu["WeaponShaders"] setShader(getAction(5)[self.Menu["Curs"]],205,132);
			if(self.Menu["Sub"]=="Map")
				self.Menu["MapsShaders"] setShader(getAction(6)[self.Menu["Curs"]],205,132);
			self CursMove();
			self playLocalSound("mouse_over");
			wait 0.2;
			self.IsScrolling=false;
		}
		if(self AdsButtonPressed()&& self.IsScrolling==false && self.MenuOpen==true && self.EditingStats==false && self.IsInVar==false && self.CreditsRolling==false)
		{
			self.Menu["Curs"] --;
			self.IsScrolling=true;
			if(self.Menu["Curs"]<0)
			{
				if(self.Menu["Sub"]=="Player")self.Menu["Curs"]=level.players.size-1;
				else self.Menu["Curs"]=self.Menu["Option"]["Name"][self.Menu["Sub"]].size-1;
			}
			if(self.Menu["Sub"]=="Weapons")
                self.Menu["WeaponShaders"] setShader(getAction(5)[self.Menu["Curs"]],205,132);
			if(self.Menu["Sub"]=="Map")
				self.Menu["MapsShaders"] setShader(getAction(6)[self.Menu["Curs"]],205,132);
			self CursMove();
			self playLocalSound("mouse_over");
			wait 0.2;
			self.IsScrolling=false;
		}
		if(self UseButtonPressed()&& self.LockMenu==false && self.MenuOpen==true && self.EditingStats==false && self.IsInVar==false && self.CreditsRolling==false)
		{
			if(self.Menu["Sub"]=="Player")self.PlayerNum=self.Menu["Curs"];
			self thread [[self.Menu["Func"][self.Menu["Sub"]][self.Menu["Curs"]]]](self.Menu["Input"][self.Menu["Sub"]][self.Menu["Curs"]]);
			self playLocalSound( "mp_ingame_summary" );
			self.Menu["Shader"]["Curs"] fadeOverTime( 0.2 );
			self.Menu["Shader"]["Curs"].alpha = ( 0.1 );
			wait( 0.2 );
			self.Menu["Shader"]["Curs"] fadeOverTime( 0.3 );
			self.Menu["Shader"]["Curs"].alpha = ( 1 );
		}
		if(self MeleeButtonPressed()&& self.MenuOpen==true && self.EditingStats==false && self.IsInVar==false && self.CreditsRolling==false)
		{
			if(self.Menu["Sub"]=="Main")self ExitMenu();
			else self ExitSub();
		}
		wait 0.05;
	}
	self.scrollBar=self.Menu["Shader"]["Curs"];
}
MenuShaders()
{
    if(level.MenuStyle=="LEFT")
    {
		self.Menu["Shader"]["Curs"] = self createRectangle("LEFT", "", -380, ((self.Menu["Curs"]*21.58) - 169.22), 300, 13,(0.5,0.0,0.8),"white",3,0);
		self.Menu["Shader"]["backround"] = self createRectangle("LEFT", "", -380, 0, 300, 480, (0,0,0), "white", 1, 0);
		self.Menu["Shader"]["Vertical"]["1"] = self createRectangle("CENTER","", -380, 0, 2, 720,(0.5,0.0,0.8),"line_vertical", 3, 0);
		self.Menu["Shader"]["Vertical"]["2"] = self createRectangle("CENTER","", -80, 0, 2, 720,(0.5,0.0,0.8),"line_vertical", 3, 0);
		self.Menu["Shader"]["Vertical"]["3"] = self createRectangle("LEFT","", -380, -185, 300, 4,(0.5,0.0,0.8),"line_vertical", 3, 0);
	    if(getdvar("mapname")== "mp_dome"||getdvar("mapname")== "mp_stalingrad"||getdvar("mapname")== "mp_makin_day"||getdvar("mapname")== "mp_makin"||getdvar("mapname")== "mp_nachtfeuer"||getdvar("mapname")== "mp_subway"||getdvar("mapname")== "mp_docks")
	    {
		    self.Menu["Shader"]["GlowEffect"] = self createShadGlow("CENTER", "", 500, 200, 1000, 500, "", (0.5,0.0,0.8), 0, 6);
	    }
	    else
	    {
		    self.Menu["Shader"]["GlowEffect"] = self createShadGlow("CENTER", "", 500, 200, 1000, 500, "sun", (0.5,0.0,0.8), 0, 6);
	    }
    }
	else
	{
		//self.Menu["Shader"]["GlowText"] = self createRectangle("","",0,0,1000,720,(0.5,0.0,0.8),"scope_overlay_mp",1, 0);//
		self.Menu["Shader"]["Vertical"]["1"] = self createRectangle("CENTER","", 80, 0, 2, 720,(0.5,0.0,0.8),"line_vertical", 3, 0);
		self.Menu["Shader"]["Vertical"]["2"] = self createRectangle("CENTER","", 380, 0, 2, 720,(0.5,0.0,0.8),"line_vertical", 3, 0);
		self.Menu["Shader"]["Vertical"]["3"] = self createRectangle("LEFT","", 80, -185, 300, 4,(0.5,0.0,0.8),"line_vertical", 3, 0);
		self.Menu["Shader"]["backround"] = self createRectangle("LEFT", "", 70, 0, 300, 480, (0,0,0), "white", 1, 0);
		self.Menu["Shader"]["Curs"] = self createRectangle("LEFT", "", 80, ((self.Menu["Curs"]*21.58) - 169.22), 300, 13,(0.5,0.0,0.8),"white",3,0);
	    if(getdvar("mapname")== "mp_dome"||getdvar("mapname")== "mp_stalingrad"||getdvar("mapname")== "mp_makin_day"||getdvar("mapname")== "mp_makin"||getdvar("mapname")== "mp_nachtfeuer"||getdvar("mapname")== "mp_subway"||getdvar("mapname")== "mp_docks")
	    {
		    self.Menu["Shader"]["GlowEffect"] = self createShadGlow("CENTER", "", -90, 200, 1000, 500, "", (0.5,0.0,0.8), 0, 6);
	    }
	    else
	    {
		    self.Menu["Shader"]["GlowEffect"] = self createShadGlow("CENTER", "", -90, 200, 1000, 500, "sun", (0.5,0.0,0.8), 0, 6);
	    }
	}
}
Update()
{
	self endon("menuclosed");
	self.Menu["Shader"]["backround"] elemFade(0.4,0.3);
	self.Menu["Shader"]["backround"] elemMoveX(0.5,-900);
	self.Menu["Shader"]["GlowEffect"] elemFade(0.4,0.3);
	self.Menu["Shader"]["GlowEffect"] elemMoveX(0.5,-900);
	self.Menu["Shader"]["GlowText"] elemFade(0.4,0.3);
	self.Menu["Shader"]["GlowText"] elemMoveX(0.5,-900);
	self.Menu["Shader"]["Vertical"]["1"] elemFade(0.4,0.3);
	self.Menu["Shader"]["Vertical"]["1"] elemMoveX(0.5,-900);
	self.Menu["Shader"]["Vertical"]["2"] elemFade(0.4,0.3);
	self.Menu["Shader"]["Vertical"]["2"] elemMoveX(0.5,-900);
	self.Menu["Shader"]["Vertical"]["3"] elemFade(0.4,0.3);
	self.Menu["Shader"]["Vertical"]["3"] elemMoveX(0.5,-900);
	self.Menu["Shader"]["Curs"] elemMoveX(0.5,-900);
	self.Menu["Text"] elemMoveX(0.5,600);
	self.Menu["Title"] elemMoveX(0.5,600);
	self.Menu["PurpleKushText"] elemMoveX(0.5,600);
}
DrawMenuOpts()
{
	string="";
	if(self.Menu["Sub"]=="Player")
	{
	    self AddMenuTitle( "Player", "Player Menu");
		for(E=0;E<level.players.size;E++)
		{
			player=level.players[E];
			string+=player.name+"\n";
			self.Menu["Func"][self.Menu["Sub"]][E]=::SubMenu;
			self.Menu["Input"][self.Menu["Sub"]][E]="Player_Rank";
			self AddMenuTitle( "Player_Rank", "Do what To "+player.name );
		}
		self.Menu["GoBack"][self.Menu["Sub"]]="Player1";
	}
	else
	{
		for(i=0;i<self.Menu["Option"]["Name"][self.Menu["Sub"]].size;i++) string+=self.Menu["Option"]["Name"][self.Menu["Sub"]][i]+"\n";
	}

    if(level.MenuStyle=="LEFT")
    {
		self.Menu["Text"] = CreateText( "default", 1.5, "LEFT", "", -350, -170, 1, 100, string );
	    self.Menu["Text"].x=-999;
		self.Menu["Text"] moveOverTime(0.25);
		self.Menu["Text"].x=-350;
		self.Menu["Title"] = CreateText( "default", 2.0, "LEFT", "", -350, -200,1,100,self.Menu["Option"]["Title"][self.Menu["Sub"]] );
	    self.Menu["Title"].x=-999;
		self.Menu["Title"] moveOverTime(0.25);
		self.Menu["Title"].x=-350;
		self.Menu["PurpleKushText"] = CreateText("default",2.0,"","",100,-175,true,-15,"''Purple Kush v.4'' \n          by iPROFamily");
	    self.Menu["PurpleKushText"].x=-999;
		self.Menu["PurpleKushText"] moveOverTime(0.25);
		self.Menu["PurpleKushText"].x=100;
    }
	else
	{
		self.Menu["Text"]=CreateText("default",1.5,"LEFT","",100,-170,1,100,string);
		self.Menu["Text"].x=-999;
		self.Menu["Text"] moveOverTime(0.25);
		self.Menu["Text"].x=100;
		self.Menu["Text"] maps\mp\gametypes\_hud::fontPulseInit();
		self.Menu["Title"] = CreateText( "default", 2.0, "LEFT", "", 100, -200,1,100,self.Menu["Option"]["Title"][self.Menu["Sub"]] );
		self.Menu["Title"].x=-999;
		self.Menu["Title"] moveOverTime(0.25);
		self.Menu["Title"].x=100;
		self.Menu["PurpleKushText"] = CreateText("default",2.0,"","",0,-175,true,-15,"''Purple Kush v.4'' \n          by iPROFamily");
		self.Menu["PurpleKushText"].x=-999;
		self.Menu["PurpleKushText"] moveOverTime(0.25);
		self.Menu["PurpleKushText"].x=-175;
	}
	self thread MenuDeath(self.Menu["Text"], self.Menu["Shader"]["backround"], self.Menu["Shader"]["Curs"], self.Menu["Title"], self.Menu["WeaponShaders"], self.Menu["Shader"]["GlowEffect"], self.Menu["PurpleKushText"], self.Menu["Shader"]["Vertical"]["1"], self.Menu["Shader"]["Vertical"]["2"], self.Menu["Shader"]["Vertical"]["3"], self.Menu["Shader"]["MapsShaders"]);
	if(!self.ColorText)self.Menu["Text"].color=self.tCol;
	if(!self.KushText)self.Menu["PurpleKushText"].color=self.KushText;
	if(!self.TitleText)self.Menu["Title"].color=self.TitleCol;
}
scaleFontOverTime(size,time)
{
	scaleSize =((size-self.fontScale)/(time*20));
	for(k=0;k <(20*time);k++)
	{
		self.fontScale += scaleSize;
		wait .05;
	}
}
AddMenuAction(SubMenu,OptNum,Name,Func,Input)
{
	self.Menu["Option"]["Name"][SubMenu][OptNum]=Name;
	self.Menu["Func"][SubMenu][OptNum]=Func;
	if(isDefined(Input))
	{
		self.Menu["Input"][SubMenu][OptNum]=Input;
	}
}
AddBackToMenu(Menu,GoBack)
{
	self.Menu["GoBack"][Menu]=GoBack;
}
AddMenuTitle( SubMenu, Title )
{
	self.Menu["Option"]["Title"][SubMenu] = Title;
}
createShadGlow(point, rPoint, x, y, width, height, elem, colour, alpha, sort)
{
    shader = newClientHudElem(self);
    shader.alignX = point;
    shader.alignY = rPoint;
    shader.x = x;
    shader.y = y;
    shader.sort = sort;
    shader.alpha = alpha;
    shader.color = colour;
    shader setShader(elem, width, height);
    return shader;
}
CursMove()
{
    if(level.MenuStyle=="LEFT")
    {
		self.Menu["Shader"]["Curs"] MoveOverTime( 0.09 );
		self.Menu["Shader"]["Curs"] setPoint("LEFT","",-380,((self.Menu["Curs"] * 17.9833333)- 169.22));
    }
	else
	{
		self.Menu["Shader"]["Curs"] MoveOverTime(0.09);
		self.Menu["Shader"]["Curs"] setPoint("LEFT","",80,((self.Menu["Curs"] * 17.9833333)- 169.22));
	}
}
ExitMenu()
{
	self thread Update();
	wait 0.35;
	self.Menu["Title"] destroy();
	self.Menu["Text"] destroy();
	self.Menu["PurpleKushText"] destroy();
	self notify("menu_closed");
	self freezecontrols(false);
	self setClientDvars( "cg_drawcrosshair", "1", "r_blur", "0", "ui_hud_hardcore", "0");
	self MenuShadersOut();
	self.MenuOpen=false;
	self setClientDvars( "r_watersim_enabled", "0" );
	self setClientDvars( "r_waterFogTest", "0" );
	self setClientDvars( "r_waterSheetingFX_allowed", "1" );
	self setClientDvars( "r_waterSheetingFX_distortionScaleFactor", "0.021961 1 0 0" );
	self setClientDvars( "r_waterSheetingFX_enable", "0 0" );
	self setClientDvars( "r_waterSheetingFX_fadeDuration", "2" );
	self setClientDvars( "r_waterSheetingFX_magnitude", "0.0655388" );
	self setClientDvars( "r_waterSheetingFX_radius", "4.44051" );
    self setClientDvars( "r_watersim_curlAmount", "0.5" );
	self setClientDvars( "r_watersim_curlMax", "0.4" );
	self setClientDvars( "r_watersim_curlReduce", "0.95" );
	self setClientDvars( "r_watersim_debug", "0" );
	self setClientDvars( "r_watersim_flatten", "0" );
	self.Menu["Sub"]="Closed";
}
ExitSub()
{
	self.Menu["Title"] destroy();
	self.Menu["Text"] destroy();
	self.Menu["PurpleKushText"] destroy();
	self.Menu["WeaponShaders"] destroy();
	self.Menu["MapsShaders"] destroy();
	self.Menu["Sub"]=self.Menu["GoBack"][self.Menu["Sub"]];
	self.Menu["Curs"]=0;
	self CursMove();
	self thread DrawMenuOpts();
	wait 0.2;
}
MenuShadersOut()
{
	self.Menu["Shader"]["backround"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["backround"].alpha = 0;
	self.Menu["Shader"]["GlowEffect"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["GlowEffect"].alpha = 0;
	self.Menu["Shader"]["Vertical"]["1"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["Vertical"]["1"].alpha = 0;
	self.Menu["Shader"]["Vertical"]["2"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["Vertical"]["2"].alpha = 0;
	self.Menu["Shader"]["Vertical"]["3"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["Vertical"]["3"].alpha = 0;
	self.Menu["Shader"]["Curs"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["Curs"].alpha = 0;
}
MenuShadersIn()
{
	self.Menu["Shader"]["backround"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["backround"].alpha = (1/2.90);
	self.Menu["Shader"]["GlowEffect"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["GlowEffect"].alpha = (1/2.90);
	self.Menu["Shader"]["Vertical"]["1"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["Vertical"]["1"].alpha = (1/2.90);
	self.Menu["Shader"]["Vertical"]["2"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["Vertical"]["2"].alpha = (1/2.90);
	self.Menu["Shader"]["Vertical"]["3"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["Vertical"]["3"].alpha = (1/2.90);
	self.Menu["Shader"]["Curs"] FadeOverTime( 0.5 );
	self.Menu["Shader"]["Curs"].alpha = 1;
}
MenuDeath(elem,elem1,elem2,elem3,elem4,elem5,elem6,elem7,elem8,elem9,elem10,elem11,elem12,elem13,elem14,elem15,elem16)
{
	self waittill("death");
	if(isDefined(elem))elem destroy();
	if(isDefined(elem1))elem1 destroy();
	if(isDefined(elem2))elem2 destroy();
	if(isDefined(elem3))elem3 destroy();
	if(isDefined(elem4))elem4 destroy();
	if(isDefined(elem5))elem5 destroy();
	if(isDefined(elem6))elem6 destroy();
	if(isDefined(elem7))elem7 destroy();
	if(isDefined(elem8))elem8 destroy();
	if(isDefined(elem9))elem9 destroy();
	if(isDefined(elem10))elem10 destroy();
	if(isDefined(elem11))elem11 destroy();
	if(isDefined(elem12))elem12 destroy();
	if(isDefined(elem13))elem13 destroy();
	if(isDefined(elem14))elem14 destroy();
	if(isDefined(elem15))elem15 destroy();
	if(isDefined(elem16))elem16 destroy();
}
SubMenu(numsub)
{
	self.Menu["Title"] destroy();
	self.Menu["Text"] destroy();
	self.Menu["PurpleKushText"] destroy();
	self.Menu["Sub"] = numsub;
	self.Menu["Curs"] = 0;
	self CursMove();
	self thread DrawMenuOpts();
    if(level.MenuStyle=="LEFT")
    {
		if(self.Menu["Sub"]=="Weapons")
        self.Menu["WeaponShaders"] = CreateShader("TOPLEFT","LEFT",500,-140,205,132,(1,1,1),getAction(5)[0],200,.7);
        if(self.Menu["Sub"]=="Map")
        self.Menu["MapsShaders"] = CreateShader("TOPLEFT","LEFT",500,-140,205,132,(1,1,1),getAction(6)[0],200,.7);
    }
	else
	{
		if(self.Menu["Sub"]=="Weapons")
        self.Menu["WeaponShaders"] = CreateShader("TOPLEFT","LEFT",-11,-150,205,132,(1,1,1),getAction(5)[0],200,.7);
        if(self.Menu["Sub"]=="Map")
        self.Menu["MapsShaders"] = CreateShader("TOPLEFT","LEFT",-11,-150,205,132,(1,1,1),getAction(6)[0],200,.7);
	}
}
getAction(Input)
{
	return level.Action[Input];
}
PS(s)
{
	k=strTok(s,";");
	for(i=0;i<k.size;i++)precacheShader(k[i]);
}
CreateText(Font,Fontscale,Align,Relative,X,Y,Alpha,Sort,Text)
{
	Hud=CreateFontString(Font,Fontscale);
	Hud SetPoint(Align,Relative,X,Y);
	Hud.alpha=Alpha;
	Hud.sort=Sort;
	Hud setText(Text);
	return Hud;
}
createRectangle(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	barElemBG=newClientHudElem(self);
	barElemBG.elemType="bar";
	barElemBG.width=width;
	barElemBG.height=height;
	barElemBG.align=align;
	barElemBG.relative=relative;
	barElemBG.xOffset=0;
	barElemBG.yOffset=0;
	barElemBG.children=[];
	barElemBG.sort=sort;
	barElemBG.color=color;
	barElemBG.alpha=alpha;
	barElemBG setParent(level.uiParent);
	barElemBG setShader(shader,width,height);
	barElemBG.hidden=false;
	barElemBG setPoint(align,relative,x,y);
	return barElemBG;
}
createScrollbar(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	scrollbar=newClientHudElem(self);
	scrollbar.elemType="bar";
	scrollbar.width=width;
	scrollbar.height=height;
	scrollbar.align=align;
	scrollbar.relative=relative;
	scrollbar.xOffset=0;
	scrollbar.yOffset=0;
	scrollbar.children=[];
	scrollbar.color=(1,0,0);
	scrollbar.sort=sort;
	scrollbar.alpha=alpha;
	scrollbar.color=color;
	return scrollbar;
}
elemMoveY(time,input)
{
	self moveOverTime(time);
}
elemMoveX(time,input)
{
	self moveOverTime(time);
	self.x=input;
}
elemFade(time,alpha)
{
	self fadeOverTime(time);
	self.alpha=alpha;
}
New()
{
}

dokmsound(sound)
{
	self playLocalSound(sound);
}

removeDeathBarrier()
 {
 	ents=getEntArray();
 	for(index=0;index < ents.size;index++)
 	{
 		if(isSubStr(ents[index].classname, "trigger_hurt"))
 		ents[index].origin=(0,0,9999999);
 	}
 }
 
removeSkyBarrier()
 {
 	entArray = getEntArray();
 	for (index = 0;index < entArray.size;index++)
 	{
 		if(isSubStr(entArray[index].classname, "trigger_hurt") && entArray[index].origin[2] > 180)
 		entArray[index].origin = (0,0, 9999999);
 	}
 }


AutoGrimReaper()
{
    self endon("death");
    self endon("disconnect");
	self ExitMenu();
    self maps\mp\gametypes\_hardpoints::giveKillstreak("m202_flash_mp");
    wait(0.5);
    self thread maps\mp\gametypes\_hardpoints::useKillstreak("m202_flash_mp");
	self giveWeapon("m202_flash_mp");
    self switchToWeapon("m202_flash_mp");
}

AutoNewValkyrie()
{
    self endon("death");
    self endon("disconnect");
	self ExitMenu();
    self maps\mp\gametypes\_hardpoints::giveKillstreak("valkyrie_mp");
    wait(0.5);
    self thread maps\mp\gametypes\_hardpoints::useKillstreak("valkyrie_mp");
	self giveWeapon("m220_tow_mp");
    self switchToWeapon("m220_tow_mp");
}

AutoTriggerValkyrie()
{
	self closeMenu();
	self closeInGameMenu();
	if (!isDefined(self) || self.sessionstate != "playing") return;
	hardpointType = "valkyrie_mp";
	team = self.team;
	if (self maps\mp\_killstreakrules::isKillstreakAllowed(hardpointType, team) == false)
	{
		self iPrintln("Valkyrie is not allowed or active.");
		return;
	}
	if (self maps\mp\_killstreakrules::killstreakStart(hardpointType, team) == false) return;
	self maps\mp\gametypes\_hardpoints::giveKillstreak(hardpointType);
}

AutoCarePackage()
{
    self endon("death");
    self endon("disconnect");
	self ExitMenu();
    self maps\mp\gametypes\_hardpoints::giveKillstreak("supply_drop_mp");
    wait(0.5);
    self thread maps\mp\gametypes\_hardpoints::useKillstreak("supply_drop_mp");
	self giveWeapon("supply_drop_mp");
    self switchToWeapon("supply_drop_mp");
}


NewNapalmStrike()
{
  self thread AutoNapalm();
}

AutoNapalm()
{
	self closeMenu();
	self closeInGameMenu();
	self ExitMenu();
	if (!isDefined(self) || self.sessionstate != "playing") return;
	hardpointType = "napalm_mp";
	team = self.team;
	if (self maps\mp\_killstreakrules::isKillstreakAllowed(hardpointType, team) == false)
	{
		self iPrintln("Napalm is not allowed or active.");
		return;
	}
	if (self maps\mp\_killstreakrules::killstreakStart(hardpointType, team) == false) return;
	playerAngles = self.angles;
	if (isDefined(self.pers) && isDefined(self.pers["angles"]))
	{
		playerAngles = self.pers["angles"];
	}
	forward = anglesToForward(playerAngles);
	targetPos = self.origin + (forward * 1500);
	yaw = playerAngles[1];
	self thread doNapalmkm(targetPos, yaw, self, team);
}

doNapalmkm(origin, yaw, owner, team )
{
	planeHalfDistance = 24000;
	direction = ( 0, yaw, 0 );

	startPoint = origin + vector_scale( anglestoforward( direction ), -1 * planeHalfDistance );
	endPoint = origin + vector_scale( anglestoforward( direction ), planeHalfDistance );

	minHeight = int(maps\mp\_airsupport::getMinimumFlyHeight());
	startPoint = ( startPoint[0], startPoint[1], minHeight );	
	endPoint = ( endPoint[0], endPoint[1], minHeight );
	planeFlyHeight = int( maps\mp\_airsupport::getNoFlyZoneHeightCrossed( startPoint, endPoint, minHeight ) );
	origin = ( origin[0], origin[1], planeFlyHeight );
	startPoint = ( startPoint[0], startPoint[1], planeFlyHeight );	
	endPoint = ( endPoint[0], endPoint[1], planeFlyHeight );

	trace = bullettrace(origin, origin + (0,0,-4000), false, undefined);
	targetpos = trace["position"];
	
	maxs = level.spawnMaxs[2] + 200;
	mins = level.spawnMins[2] - 200;
	
	if ( targetpos[2] > maxs )
	{
		targetpos = ( targetpos[0], targetpos[1], maxs );
	}
	else if ( targetpos[2] < mins )
	{
		targetpos = ( targetpos[0], targetpos[1], mins );
	}
	
	/#
	thread debug_line( origin, targetpos, (1,1,1), 400 );
	thread debug_line( targetpos, trace["position"], (1,0,0), 400 );
	#/
	
	owner maps\mp\gametypes\_hardpoints::playKillstreakStartDialog( "napalm_mp", team );
	owner maps\mp\gametypes\_persistence::statAdd( "NAPALM_USED", 1, false );
	if ( IsDefined( level.globalKillstreaksCalled ) )
	{
		level.globalKillstreaksCalled++;
	}
	self maps\mp\gametypes\_globallogic_score::incItemStatByReference( "killstreak_napalm", 1, "used" );

	if ( !isDefined( owner ) )
	{
		maps\mp\_killstreakrules::killstreakStop( "napalm_mp", team ); 
		return;
	}
	
	owner notify ( "begin_napalm" );
	
	burnNapalmDuration = getDvarFloatDefault("scr_burnNapalmDuration", level.burnNapalmDuration);
	
	influencer_org = targetpos + vector_scale( anglestoforward( direction ), 0 );	
	maps\mp\gametypes\_spawning::create_napalm_fire_influencers( influencer_org, direction, team, level.burnNapalmDuration + 5.5 );
	
	maps\mp\_napalm::callNapalmStrike( owner, targetpos, startPoint, endPoint, yaw, planeFlyHeight );
	maps\mp\_killstreakrules::killstreakStop( "napalm_mp", team ); 
}

initBulletsFunction(input)
    {
        if (self.rpgTog==false)
        {
            self iPrintln("Bullets Set To ^2"+input);
            self thread rpgBullet(input);        
            self.rpgTog=true;
        }
        else
        {
            self iPrintln("Bullets ^1OFF");
             self notify("stopRPG");         
            self.rpgTog=false;
        }
    }

rpgBullet(input)
{
    self endon("disconnect");
    self endon("stopRPG");
    
    for(;;)
    {
        self waittill("weapon_fired");
        forward = anglestoforward(self getplayerangles());
        start = self geteye();
        end = vector_scale(forward, 9999);
        magicbullet(input, start, bullettrace(start, start + end, false, undefined)["position"], self);
    }
}



BotDifficult()
{
	if (!isDefined(self.bot_difficulty)) self.bot_difficulty = 0;
	switch (self.bot_difficulty)
	{
		case 0: self iPrintln("Bots: ^2Veteran");
		setBotConfig("250", "500", "100", "300", "14", "14", "-5", "10", "160", "30", "100", "1", "512");
		break;
		case 1: self iPrintln("Bots: ^2Hard");
		setBotConfig("250", "500", "400", "600", "8", "10", "-5", "10", "100", "400", "700", "0.9", "384");
		break;
		case 2: self iPrintln("Bots: ^2Easy");
		setBotConfig("1000", "2000", "900", "1000", "2", "2.5", "-20", "40", "50", "1200", "1600", "0.1", "256");
		break;
		case 3: self iPrintln("Bots: ^2Normal Rekrut");
		setBotConfig("500", "1000", "600", "800", "4", "5", "-10", "20", "70", "800", "1200", "0.6", "256");
		break;
		case 4: self iPrintln("Bots: ^2Cheater Extrem Hard");
		setBotConfig("1", "1", "1", "1", "100", "100", "-10", "20", "360", "1", "2", "999", "9999");
		break;
	}
	self.bot_difficulty = (self.bot_difficulty + 1) % 5;
}
setBotConfig(minDeath, maxDeath, minFire, maxFire, yaw, yawAds, pitchUp, pitchDown, fov, minReact, maxReact, strafeChance, helpDist)
{
	SetDvar("sv_botMinDeathTime", minDeath);
	SetDvar("sv_botMaxDeathTime", maxDeath);
	SetDvar("sv_botMinFireTime", minFire);
	SetDvar("sv_botMaxFireTime", maxFire);
	SetDvar("sv_botYawSpeed", yaw);
	SetDvar("sv_botYawSpeedAds", yawAds);
	SetDvar("sv_botPitchUp", pitchUp);
	SetDvar("sv_botPitchDown", pitchDown);
	SetDvar("sv_botFov", fov);
	SetDvar("sv_botMinAdsTime", "3000");
	SetDvar("sv_botMaxAdsTime", "5000");
	SetDvar("sv_botMinCrouchTime", "2000");
	SetDvar("sv_botMaxCrouchTime", "4000");
	SetDvar("sv_botTargetLeadBias", "2");
	SetDvar("sv_botMinReactionTime", minReact);
	SetDvar("sv_botMaxReactionTime", maxReact);
	SetDvar("sv_botStrafeChance", strafeChance);
	SetDvar("sv_botMinStrafeTime", "3000");
	SetDvar("sv_botMaxStrafeTime", "6000");
	SetDvar("scr_help_dist", helpDist);
}


botuseGrandes()
{
	if(self.botKill==false)
	{
		setDvar("sv_botAllowGrenades","0");
		self iPrintln("Bots Dont Use Grenades ^2ON");
		self.botKill=true;
	}
	else
	{
		setDvar("sv_botAllowGrenades","1");
		self iPrintln("Bots Dont Use Grenades ^1OFF");
		self.botKill=false;
	}
}


/*

Assault Rifles & Rifles
wpn_m16_fire_plr

wpn_ak47_fire_plr

wpn_galil_fire_plr

wpn_famas_fire_plr

wpn_fal_fire_plr

wpn_commando_fire_plr

wpn_g11_fire_plr

Submachine Guns (SMGs)
wpn_mp5k_fire_plr

wpn_spectre_fire_plr

wpn_mac11_fire_plr

wpn_skorpion_fire_plr

wpn_ak74u_fire_plr

wpn_pm63_fire_plr

Light Machine Guns & Snipers
wpn_mg42_fire_plr

wpn_hk21_fire_plr

wpn_rpk_fire_plr

wpn_m60_fire_plr

wpn_psg1_fire_plr

wpn_dragunov_fire_plr

wpn_l96a1_fire_plr

Pistols & Special Weapons
weap_colt1911_fire_plr

wpn_python_fire_plr

wpn_makarov_fire_plr

wpn_cz75_fire_plr

wpn_raygun_fire_plr (Ray Gun)

wpn_thundergun_fire_plr (Thundergun)

*/


kamikaze()
{
	self thread DoSuicideVeh("t5_veh_air_b52");
}
DoSuicideVeh(kmmodel)
{
	self endon("disconnect");
	startPos = self.origin + (0, 0, 10000);
	K = spawn("script_model", startPos);
	K setModel(kmmodel);
	self beginLocationselection("rank_prestige15");
	self.selectingLocation = true;
	self waittill("confirm_location", location);
	trace = BulletTrace(location + (0,0,1000), location - (0,0,1000), false, K);
	L = trace["position"];
	self endLocationselection();
	self.selectingLocation = undefined;
	K.angles = vectorToAngles(L - K.origin);
	K playLoopSound("mpl_ui_timer_countdown");
	level.fx_airstrike_afterburner = loadfx("vehicle/exhaust/fx_exhaust_jet_afterburner");
	playFxOnTag(level.fx_airstrike_afterburner, K, "tag_engine_left");
	playFxOnTag(level.fx_airstrike_afterburner, K, "tag_engine_right");
	K moveto(L, 5.0);
	wait 4.9;
	K stopLoopSound();
    if(getdvar("mapname")== "mp_nuked")
	{
	K playsound("amb_end_nuke");
	playFX(level._effect["fx_mp_nuked_nuclear_explosion"], L);
    }
    else 
    {
    K playsound("mpl_kls_napalm_exlpo");
	playFX(level._effect["bombexplosion"], L);
    }
	RadiusDamage(L, 500, 1000, 50, self);
	Earthquake(0.6, 3, L, 1000);
	wait 0.1;
	K delete();
}



MegaAirStreak()
{
	self endon("disconnect");
	self iPrintLnBold("^5Mega Attack Force Incoming^0!");
	planeModel = "t5_veh_jet_f4_gearup";
	planes = [];
	startY = -3000;
	for(i = 0;i < 5;i++)
	{
		spawnPos = (10000, startY + (i * 1500), 2500);
		planes[i] = spawn("script_model", spawnPos);
		planes[i] setModel(planeModel);
		planes[i].angles = (0, 180, 0);
		planes[i].owner = self;
		planes[i] playLoopSound("veh_b52_dist_loop");
		endPos = (-10000, startY + (i * 1500), 2500);
		planes[i] moveTo(endPos, 30);
		planes[i] thread planeCleanup(30);
	}
	for(p = 0;p < level.players.size;p++)
	{
		player = level.players[p];
		if(!isDefined(player) || !isAlive(player) || player == self) continue;
		if(level.teamBased && player.pers["team"] == self.pers["team"]) continue;
		player thread startBombingLogic(planes, self);
	}
}
planeCleanup(time)
{
	wait time;
	if(isDefined(self))
	{
		self stopLoopSound();
		self delete();
	}
}
startBombingLogic(planes, attacker)
{
	self endon("death");
	self endon("disconnect");
	projectiles = strTok("cobra_20mm_mp;cobra_20mm_mp;cobra_20mm_mp", ";");
	while(isDefined(attacker))
	{
		for(i = 0;i < planes.size;i++)
		{
			if(!isDefined(planes[i])) continue;
			if(Distance(planes[i].origin, self.origin) < 9999)
			{
				currentProj = projectiles[randomInt(projectiles.size)];
				magicBullet(currentProj, planes[i].origin, self.origin, attacker);
                RadiusDamage(self.origin, 150, 200, 50, attacker);
				wait 0.7;
			}
		}
		wait 1.5;
	}
}

JetCrash() 
{
	self endon("disconnect");
	self endon("death");
	self iprintlnbold("^1!! WAIT AND LOOK THE SKY !!");
	km40 = spawn("script_model",self.origin+(18000,0,2400));
	Dev = spawn("script_model",self.origin+(-18000,0,2400));
	km40 setModel("t5_veh_air_b52");
	Dev setModel("t5_veh_air_b52");
	km40 MoveTo(self.origin+(0,0,2400),10);
	Dev MoveTo(self.origin+(0,0,2400),10);
	km40.angles=(0,180,0);
	Dev.angles=(0,0,0);
	wait 10;
    if(getdvar("mapname")== "mp_nuked")
	{
	PlayFX(level._effect["fx_mp_nuked_nuclear_explosion"],km40.origin);
    }
    else 
    {
	PlayFX(level._effect["rcbombexplosion"],km40.origin);
    }
	self thread PilotCrashFX();
	km40 delete();
	Dev delete();
}


PilotCrashFX(player)
{
self endon("disconnect");
self endon("death");
earthquake( 0.6, 4, self.origin, 100000 );
self playsound("veh_huey_chaff_explo_npc");
player playsound("veh_huey_chaff_explo_npc");
player playsound("amb_end_nuke"); // NukeTouwn Only
}

DoAirShow() // Ported To Bo1 By killhitman40
{

 self thread StartShow("t5_veh_air_b52");
 self iPrintln("^2Air ^1Show ^2ON");

}
PlaneAngles(kmshit)
{
	self endon("disconnect");
	for(kmAwsome = 0;0 < 360;kmAwsome++)
	{
		kmshit.angles=(0,180,kmAwsome);
		wait 0.001;
	}
}

StartShow(model)
{
	self endon("death");
	self endon("disconnect");
	self endon("deleteplane");
	kmModel = spawn("script_model",(18000,0,2400));
	kmModel setModel(model);
	kmModel MoveTo((-18000,0,2400),40);
	self thread PlaneAngles(kmModel);
	wait 40;
	self thread kdeleteAfterTime();
}
kdeleteAfterTime()
{
	self notify("deleteplane");
}

NukeTownEnd() 
{
self ExitMenu();	
self thread CustomNukeKillFeed();
}

CustomNukeKillFeed()
{
	cameraStart = GetStruct("endgame_camera_start", "targetname");
	cameraEnd = GetStruct(cameraStart.target, "targetname");
	bomb = GetEnt("nuked_bomb", "targetname");
	if (!isDefined(bomb) || !isDefined(cameraStart))
	{
		iprintlnBold("Nuketown bomb entities not found on this map!");
		return;
	}
	camera = Spawn("script_model", cameraStart.origin);
	camera.angles = cameraStart.angles;
	camera SetModel("tag_origin");
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (isDefined(player) && player.sessionstate == "playing")
		{
			player CameraSetPosition(camera);
			player CameraSetLookAt();
			player CameraActivate(true);
		}
	}
	camera MoveTo(cameraEnd.origin, 2.5, 0, 0);
	camera RotateTo(cameraEnd.angles, 2.5, 0, 0);
	bomb playSound("amb_end_nuke");
	dest = (bomb.origin[0], bomb.origin[1], bomb.origin[2] - 3700);
	bomb MoveTo(dest, 1.5, 0.75, 0);
	wait 1.5;
	playfx(level._effect["fx_mp_nuked_nuclear_explosion"], bomb.origin);
	wait 0.5;
	level thread waitForGlassBreak();
	cameraForward = anglestoforward(cameraEnd.angles);
	explodePoint = cameraEnd.origin + 20 * cameraForward;
	physicsExplosionSphere(explodePoint, 128, 128, 1);
	camera thread vibrate();
	for (i = 0;i < level.players.size;i++)
	{
		p = level.players[i];
		if (isDefined(p) && isAlive(p) && p != self)
		{
			if (level.teamBased)
			{
				if (p.pers["team"] != self.pers["team"])
				{
					radiusDamage(p.origin, 100, 999999, 999999, self, "MOD_EXPLOSIVE", "harrier_20mm_mp");
				}
			}
			else
			{
				radiusDamage(p.origin, 100, 999999, 999999, self, "MOD_EXPLOSIVE", "harrier_20mm_mp");
			}
		}
	}
	wait 3.0;
	for (i = 0;i < level.players.size;i++)
	{
		player = level.players[i];
		if (isDefined(player))
		{
			player CameraActivate(false);
			VisionSetNaked("mp_nuked", 0);
		}
	}
	camera delete();
}
vibrate()
{
	self endon("death");
	vibrateAmplitude = 2;
	originalAngles = self.angles;
	for (i = 0;i < 10;i++)
	{
		angles0 = (originalAngles[0], originalAngles[1], originalAngles[2] - vibrateAmplitude);
		angles1 = (originalAngles[0], originalAngles[1], originalAngles[2] + vibrateAmplitude);
		self RotateTo(angles0, 0.05);
		self waittill("rotatedone");
		self RotateTo(angles1, 0.05);
		self waittill("rotatedone");
		if (vibrateAmplitude > 0) vibrateAmplitude -= 0.25;
	}
}
waitForGlassBreak()
{
	level notify("glass_smash");
	if (isDefined(level.const_fx_exploder_end_game_glass_shatter)) exploder(level.const_fx_exploder_end_game_glass_shatter);
}
