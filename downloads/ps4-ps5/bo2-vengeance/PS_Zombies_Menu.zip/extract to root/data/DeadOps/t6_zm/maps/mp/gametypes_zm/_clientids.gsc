// =====================================================================
//  [PS4 FIX] builtins not present in the PC/PS4 T6 build replaced (closer, settypewriterfx,
//  setclientfov, freezecontrolsallowlook, movey, println)
//  Hells Vengeance v2 - Black Ops II Zombies - PS4 (DeadOps) SOURCE BUILD - LIGERO
//  [ORIGINS FIX] foreach convertidos a for y variables locales renombradas (v0, v1...)
//  para gastar muchos menos identificadores: Origins se quedaba sin espacio al cargar el menu.
//  Give this TEXT file to DeadOps; it compiles it for PS4 itself.
//  Source: recovered from the PC compiled _clientids.gsc (gsc-tool t6 decompile)
//  Target: PS3 (big-endian T6 bytecode). Load as maps/mp/gametypes_zm/_clientids.gsc
//  Every change is tagged "[PS3 PORT]". See PORT_NOTAS_PS3.md for the full list.
// =====================================================================
#include maps\mp\gametypes_zm\_weapons;
#include maps\mp\gametypes_zm\_hud_message;
#include maps\mp\zombies\_zm_stats;
#include maps\mp\zombies\_zm_weapons;
#include maps\mp\zombies\_zm_utility;
#include maps\mp\gametypes_zm\_hud_util;
#include common_scripts\utility;
#include maps\mp\_utility;

init()
{
    // [ORIGINS FIX] Origins (zm_tomb) does not contain several generic models/materials that the other
    // maps have; precaching them there closes the game while loading. On Origins we only precache
    // assets that the stock Origins scripts use, and hv_model() / hv_shader() swap the rest.
    level.hv_origins = 0;

    if ( getdvar( "mapname" ) == "zm_tomb" )
        level.hv_origins = 1;

    level.hv_origins_fallback = "p6_zm_tm_orb_fire"; // precached unconditionally by zm_tomb level_precache()
    level.hv_origins_badmodels = strtok( "test_sphere_silver,test_sphere_lambert,test_macbeth_chart,test_macbeth_chart_unlit,fx_axis_createfx,fx_cube_createfx,defaultvehicle,defaultactor,zombie_teddybear,zombie_skull,zombie_ammocan,zombie_vending_jugg,zombie_vending_doubletap2,zombie_vending_three_gun_on,p6_anim_zm_buildable_pap,p6_anim_zm_buildable_pap_on,zm_collision_perks1", "," );
    level.hv_origins_okshaders = strtok( "white,hud_chalk_1,hud_chalk_2,hud_chalk_3,hud_chalk_4,hud_chalk_5,specialty_additionalprimaryweapon_zombies,specialty_instakill_zombies,specialty_firesale_zombies,menu_zm_gamertag,zombies_rank_5,zombies_rank_4,zombies_rank_3,zombies_rank_2,zombies_rank_1,damage_feedback,gradient_center,progress_bar_bg,ui_slider2,lui_loader_no_offset", "," ); // menu materials are global UI assets: kept on Origins too (white blocks otherwise)
    level thread onplayerconnect();

    if ( level.hv_origins )
    {
        v0 = level.hv_origins_okshaders;
        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v2 = v0[v1];
            precacheshader( v2 );
        }

        precachemodel( "tag_origin" );
        precachemodel( level.hv_origins_fallback );
    }
    else
    {
    v0 = strtok( "hud_chalk_1,hud_chalk_2,hud_chalk_3,hud_chalk_4,hud_chalk_5,specialty_additionalprimaryweapon_zombies,specialty_instakill_zombies,specialty_firesale_zombies,white,menu_zm_gamertag,zombies_rank_5,zombies_rank_4,zombies_rank_3,zombies_rank_2,zombies_rank_1,damage_feedback,gradient_center,progress_bar_bg,ui_slider2,lui_loader_no_offset", "," );
    for ( v1 = 0; v1 < v0.size; v1++ )
    {
        v2 = v0[v1];
        precacheshader( v2 );
    }

    // [SAFE BUILD] only generic models that exist in every BO2 zombies map are precached.
    // Map-specific models (perk machines, buildable PaP, teddy, skull) and unused ones
    // (zombie_vending_three_gun_on, p6_anim_zm_buildable_pap_on, zm_collision_perks1) were removed:
    // precaching an asset the current map does not have is a fatal error on console.
    // If you want them back on a map that has them, set level.precachemapmodels = 1 below.
    level.precachemapmodels = 0;

    v0 = strtok( "fx_axis_createfx,fx_cube_createfx,test_macbeth_chart,test_macbeth_chart_unlit,test_sphere_lambert,test_sphere_silver,collision_clip_sphere_64,defaultvehicle,defaultactor,tag_origin", "," );
    for ( v1 = 0; v1 < v0.size; v1++ )
    {
        v3 = v0[v1];
        precachemodel( v3 );
    }

    if ( level.precachemapmodels )
    {
        v0 = strtok( "zombie_vending_jugg,zombie_vending_doubletap2,p6_anim_zm_buildable_pap,zombie_teddybear,zombie_skull", "," );
        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v3 = v0[v1];
            precachemodel( v3 );
        }
    }
    }

    // [SAFE BUILD] precacheitem removed: zombie_fists_zm / zombie_knuckle_crack were never used and
    // tazer_knuckles_zm (Galvaknuckles) is not in every map -> "unknown weapon" fatal error.

    level.clientid = 0; // [PS4 FIX] stock _clientids behaviour kept (other ZM scripts use player.clientid)
    level.result = 0;
    level.menuownername = ""; // [PS3 PORT] optional: extra gamertag that always gets Host status
    // [PS3 PORT] was a local variable, so onplayerspawned() never saw it and the overflow fix never started
    level.isfirstspawn = 1;
    level.player_too_many_players_check = 0;
    level.player_too_many_players_check_func = ::player_too_many_players_check;
    level.player_intersection_tracker_override = ::_zm_arena_intersection_override;
    level.modelspwn = [];
    level.spawnedmodels = 0;
    recreatezombiescounter();
    level.varsarray["ranklobbymsg"] = 0;
    level.varsarray["isPlayingInputMsg"] = 0;
    level.varsarray["currentInputMsg"] = "";
}

onplayerconnect()
{
    for (;;)
    {
        level waittill( "connecting", v0 );
        v0.clientid = level.clientid; // [PS4 FIX] stock behaviour
        level.clientid++;
        v0 notify( "stop_player_out_of_playable_area_monitor" );

        if ( isdefined( level.player_out_of_playable_area_monitor ) && level.player_out_of_playable_area_monitor )
            level.player_out_of_playable_area_monitor = 0;

        if ( isdefined( level.player_too_many_weapons_monitor ) && level.player_too_many_weapons_monitor )
            level.player_too_many_weapons_monitor = 0;

        // [PS3 PORT] the original also gave full Host access to the gamertag "TheIronDragonz21" (a stranger).
        // [PS3 PORT] Put your own PSN name in level.menuownername (in init) if you want a second always-Host account.
        if ( v0 ishost() || ( level.menuownername != "" && v0.name == level.menuownername ) )
            v0.status = "Host";
        else
            v0.status = "Unverified";

        v0 thread onplayerspawned();
    }
}

onplayerspawned()
{
    self endon( "disconnect" );
    level endon( "game_ended" );
    self.menuname = "Hells Vengeance v2";
    self.menuxpos = 0;
    self.menuinit = 0;
    self.keyboardvars = [];
    self.keyboardvars["isOpen"] = 0;
    self.keyboardvars["isCaps"] = 0;
    self.keyboardvars["currentResult"] = "";
    self.keyboardvars["keysLow"] = strtok( "0\na\nk\nu\n_;1\nb\nl\nv\n-;2\nc\nm\nw\n.;3\nd\nn\nx\n,;4\ne\no\ny\n=;5\nf\np\nz\n';6\ng\nq\n \n@;7\nh\nr\n?\n#;8\ni\ns\n!\n<;9\nj\nt\n^\n>", ";" );
    self.keyboardvars["keysBig"] = strtok( "0\nA\nK\nU\n_;1\nB\nL\nV\n-;2\nC\nM\nW\n.;3\nD\nN\nX\n,;4\nE\nO\nY\n=;5\nF\nP\nZ\n';6\nG\nQ\n \n@;7\nH\nR\n?\n#;8\nI\nS\n!\n<;9\nJ\nT\n^\n>", ";" );
    self.keyboardvars["fixedKeysLow"] = strtok( "0aku_;1blv-;2cmw.;3dnx,;4eoy=;5fpz';6gq @;7hr?#;8is!<;9jt^>", ";" );
    self.keyboardvars["fixedKeysBig"] = strtok( "0AKU_;1BLV-;2CMW.;3DNX,;4EOY=;5FPZ';6GQ @;7HR?#;8IS!<;9JT^>", ";" );
    self.keyboardvars["infoText"] = "[{+actionslot 1}]/[{+actionslot 2}]/[{+actionslot 3}]/[{+actionslot 4}] = Scroll\n[{+gostand}] = Select Char\n[{+stance}] = Delete Char\n[{+switchseat}] = Toggle Caps\n[{+usereload}] = Send String\n[{+melee}] = Exit";
    self.aimbot = [];
    self.aimbot["toggle"] = 0;
    self.aimbot["boneTag"] = "j_head";

    if ( self ishost() )
        self.aimbot["visibleCheck"] = 1;
    else
        self.aimbot["visibleCheck"] = 0;

    self.aimbot["aimType"] = "required";
    self.aimbot["autoShoot"] = 0;
    self.aimbot["canAutoShoot"] = 0;
    self.aimbot["unfair"] = 0;
    self.infobar = [];
    self.infobar["close"] = "[{+speed_throw}] + [{+melee}] = Open || ^5Subscribe -> Http://www.youtube.com/c/alexibuscusgaming";
    self.infobar["normalOpen"] = "[{+actionslot 1}] / [{+actionslot 2}] = scroll | [{+stance}] = back/close | [{+activate}] = select";
    self.infobar["invertedOpen"] = "[{+actionslot 1}] / [{+actionslot 2}] = scroll | [{+stance}] = back/close | [{+activate}] = select";
    self.originalmodel = self.model;

    for (;;)
    {
        self waittill( "spawned_player" );
        self iprintln( "^3[debug] spawned - script running" ); // [SAFE BUILD] checkpoint

        if ( level.isfirstspawn && self.status == "Host" )
        {
            thread overflowfix();
            self thread homefront();
            level.isfirstspawn = 0;
        }

        if ( self.status == "Host" || self.status == "Co-Host" || ( self.status == "Admin" || self.status == "VIP" ) || self.status == "Verified" )
        {
            if ( !self.menuinit )
            {
                self.menuinit = 1;
                self thread welcomemessage();
                self thread menuinit();
                self thread resetbools();
                self iprintln( "[{+speed_throw}] ^1& [{+melee}] ^6To Open" );
                self thread closemenuondeath();
                self.menu.backgroundinfo = self drawshader( level.icontest, -25, -100, 250, 1000, ( 0, 1, 0 ), 1, 0 );
                self.menu.backgroundinfo.alpha = 0;
            }
        }
    }
}

resetbools()
{
    self.godv4 = 0;
}

drawtext( v0, v1, v2, v3, v4, v5, v6, v7, v8, v9 )
{
    v10 = self createfontstring( v1, v2 );
    v10 setsafetext( v0 ); // [PS3 PORT] counted by overflowfix(); plain settext() overflowed the PS3 string table
    v10.x = v3;
    v10.y = v4;
    v10.color = v5;
    v10.alpha = v6;
    v10.glowcolor = v7;
    v10.glowalpha = v8;
    v10.sort = v9;
    v10.alpha = v6;
    return v10;
}

drawshader( v0, v1, v2, v3, v4, v5, v6, v7 )
{
    v8 = newclienthudelem( self );
    v8.elemtype = "icon";
    v8.color = v5;
    v8.alpha = v6;
    v8.sort = v7;
    v8.children = [];
    v8 setparent( level.uiparent );
    v8 setshader( hv_shader( v0 ), v3, v4 );
    v8.x = v1;
    v8.y = v2;
    return v8;
}

verificationtonum( v0 )
{
    if ( v0 == "Host" )
        return 5;

    if ( v0 == "Co-Host" )
        return 4;

    if ( v0 == "Admin" )
        return 3;

    if ( v0 == "VIP" )
        return 2;

    if ( v0 == "Verified" )
        return 1;
    else
        return 0;
}

verificationtocolor( v0 )
{
    if ( v0 == "Host" )
        return "^2Host";

    if ( v0 == "Co-Host" )
        return "^5Co-Host";

    if ( v0 == "Admin" )
        return "^1Admin";

    if ( v0 == "VIP" )
        return "^4VIP";

    if ( v0 == "Verified" )
        return "^3Verified";
    else
        return "^6Unverified";
}

givemenu()
{
    self.menuinit = 1;
    self thread menuinit();
    self thread welcomemessage();
}

changeverificationmenu( v0, v1 )
{
    if ( v0.status != v1 && !v0 ishost() )
    {
        v0.status = v1;

        if ( v0.status == "Unverified" )
            v0 thread destroymenu( v0 );

        v0 givemenu();
        self iprintln( "Set Access Level For " + ( getplayername( v0 ) + ( " To " + verificationtocolor( v1 ) ) ) );
        v0 iprintln( "Your Access Level Has Been Set To " + verificationtocolor( v1 ) );
    }
    else if ( v0 ishost() )
        self iprintln( "You Cannot Change The Access Level of The " + verificationtocolor( v0.status ) );
    else
        self iprintln( "Access Level For " + ( getplayername( v0 ) + ( " Is Already Set To " + verificationtocolor( v1 ) ) ) );
}

changeverification( v0, v1 )
{
    v0.status = v1;
}

getplayername( v0 )
{
    v1 = getsubstr( v0.name, 0, v0.name.size );

    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        if ( v1[v2] == "]" )
            break;
    }

    if ( v1.size != v2 )
        v1 = getsubstr( v1, v2 + 1, v1.size );

    return v1;
}

iif( v0, v1, v2 )
{
    if ( v0 )
        return v1;
    else
        return v2;
}

booleanreturnval( v0, v1, v2 )
{
    if ( v0 )
        return v2;
    else
        return v1;
}

booleanopposite( v0 )
{
    if ( !isdefined( v0 ) )
        return true;

    if ( v0 )
        return false;
    else
        return true;
}

welcomemessage()
{
    if ( self.status == "Host" || self.status == "Co-Host" || ( self.status == "Admin" || self.status == "VIP" ) || self.status == "Verified" )
    {
        v0 = createfontstring( "hudbig", 1.9 );
        v0.x = 0;
        v0.y = 20.11;
        v0 settext( "^1Welcome To Hells Vengeance v2 \n Your Status: ^2" + ( self.status + ( "\n ^3Enjoy Your Stay " + self.name ) ) );
        v0.glowcolor = ( 0, 0, 1 );
        v0.glowalpha = 1;
        v0.alpha = 1;
        v0 setcod7decodefx( 30, 999999999, 999999999 );
        v0.archived = 0;
        v1 = self drawshader( "lui_loader_no_offset", 0, 80.11, 41, 41, ( 1, 1, 1 ), 0, 0 );
        v1.archived = 0;
        v1.alpha = 1;
        wait 12;
        v0 destroy();
        v1 destroy();
    }
}

updatescrollbar()
{
    self.menu.scroller moveovertime( 0.1 );
    self.menu.scroller.y = 50 + self.menu.curs[self.menu.currentmenu] * 16.8;
}

openmenu()
{
    self freezecontrols( 0 );
    self storetext( self.menuname, self.menuname );
    self.menu.backgroundinfo fadeovertime( 0.3 );
    self.menu.backgroundinfo.alpha = 1;
    self.menu.header fadeovertime( 0.3 );
    self.menu.header.alpha = 2;
    self.menu.scroller fadeovertime( 0.3 );
    self.menu.scroller.alpha = 5;
    self.menu.background fadeovertime( 0.3 );
    self.menu.background.alpha = 0.75;
    self.menu.background1 fadeovertime( 0.03 );
    self.menu.background1.alpha = 0.08;
    self.menu.animbg fadeovertime( 0.3 );
    self.menu.animbg.alpha = 1.2;
    self.swagtext fadeovertime( 0.3 );
    self.swagtext.alpha = 0.9;
    self.menu.line moveovertime( 0.3 );
    self.menu.line.y = -50;
    self.menu.line2 moveovertime( 0.3 );
    self.menu.line2.y = -50;
    self.menu.line.alpha = 1;
    self.menu.line2.alpha = 1;
    self.menu.line3 fadeovertime( 0.3 );
    self.menu.line3.alpha = 1.5;
    self.menu.line4 fadeovertime( 0.3 );
    self.menu.line4.alpha = 1.5;
    self.menu.line5 fadeovertime( 0.3 );
    self.menu.line5.alpha = 1.5;
    self.menu.treyarchlogo fadeovertime( 0.3 );
    self.menu.treyarchlogo.alpha = 5;
    self.infotext4line5 fadeovertime( 0.3 );
    self.infotext4line5.alpha = 2;
    self updatescrollbar();
    self.menu.open = 1;
}

closemenu()
{
    self.menu.options fadeovertime( 0.3 );
    self.menu.options.alpha = 0;
    self.statuss fadeovertime( 0.3 );
    self.statuss.alpha = 0;
    self.tez fadeovertime( 0.3 );
    self.tez.alpha = 0;
    self.menu.header fadeovertime( 0.3 );
    self.menu.header.alpha = 0;
    self.menu.background fadeovertime( 0.3 );
    self.menu.background.alpha = 0;
    self.menu.background1 fadeovertime( 0.3 );
    self.menu.background1.alpha = 0;
    self.menu.animbg fadeovertime( 0.3 );
    self.menu.animbg.alpha = 0;
    self.swagtext fadeovertime( 0.3 );
    self.swagtext.alpha = 0;
    self.menu.title fadeovertime( 0.3 );
    self.menu.title.alpha = 0;
    self.menu.line moveovertime( 0.3 );
    self.menu.line.y = -550;
    self.menu.line2 moveovertime( 0.3 );
    self.menu.line2.y = -550;
    self.menu.line.alpha = 0;
    self.menu.line2.alpha = 0;
    self.menu.line3 fadeovertime( 0.3 );
    self.menu.line3.alpha = 0;
    self.menu.line4 fadeovertime( 0.3 );
    self.menu.line4.alpha = 0;
    self.menu.line5 fadeovertime( 0.3 );
    self.menu.line5.alpha = 0;
    self.menu.treyarchlogo fadeovertime( 0.3 );
    self.menu.treyarchlogo.alpha = 0;
    self.menu.backgroundinfo fadeovertime( 0.3 );
    self.menu.backgroundinfo.alpha = 0;
    self.infotext4line5 fadeovertime( 0.3 );
    self.infotext4line5.alpha = 0;
    self.menu.scroller moveovertime( 0.3 );
    self.menu.scroller.y = -510;
    self.menu.open = 0;
}

destroymenu( v0 )
{
    v0.menuinit = 0;
    closemenu();
    wait 0.3;
    v0.menu.options destroy();
    v0.menu.header destroy();
    v0.menu.background1 destroy();
    v0.menu.background destroy();
    v0.menu.scroller destroy();
    v0.menu.scroller1 destroy();
    v0.infos destroy();
    v0.menu.line destroy();
    v0.menu.line2 destroy();
    v0.menu.line3 destroy();
    v0.menu.line4 destroy();
    v0.menu.line5 destroy();
    v0.infotext4line5 destroy();
    v0.menu.title destroy();
    v0.menu.treyarchlogo destroy();
    v0.tez destroy();
    v0 notify( "destroyMenu" );
}

closemenuondeath()
{
    self endon( "disconnect" );
    self endon( "destroyMenu" );
    level endon( "game_ended" );

    for (;;)
    {
        self waittill( "death" );
        self.menu.closeondeath = 1;
        self submenu( self.menuname, self.menuname );
        closemenu();
        self.menu.closeondeath = 0;
    }
}

scalelol()
{
    self endon( "stopScale" );

    for (;;)
    {
        self.tez.glowcolor = ( 0.1, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.2, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.3, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.4, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.5, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.6, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.7, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.8, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.9, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 1, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.9, 0, 0 );
        wait 1.5;
        self.tez.glowcolor = ( 0.8, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.7, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.6, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.5, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.4, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.3, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.2, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0.1, 0, 0 );
        wait 0.05;
        self.tez.glowcolor = ( 0, 0, 0 );
        wait 0.05;
    }
}

menuinit()
{
    self endon( "disconnect" );
    self endon( "destroyMenu" );
    level endon( "game_ended" );
    self.menu = spawnstruct();
    self.toggles = spawnstruct();
    self.menu.open = 0;
    self storeshaders();
    self createmenu();

    for (;;)
    {
        if ( self meleebuttonpressed() && self adsbuttonpressed() && !self.menu.open )
        {
            openmenu();
            self playsoundtoplayer( "zmb_cha_ching", self );
        }

        if ( self.menu.open )
        {
            if ( self stancebuttonpressed() )
            {
                if ( isdefined( self.menu.previousmenu[self.menu.currentmenu] ) )
                    self submenu( self.menu.previousmenu[self.menu.currentmenu] );
                else
                    closemenu();

                wait 0.2;
            }

            if ( self actionslotonebuttonpressed() || self actionslottwobuttonpressed() )
            {
                self playsoundtoplayer( "uin_alert_lockon_start", self );
                self.menu.curs[self.menu.currentmenu] = self.menu.curs[self.menu.currentmenu] + iif( self actionslottwobuttonpressed(), 1, -1 );
                self.menu.curs[self.menu.currentmenu] = iif( self.menu.curs[self.menu.currentmenu] < 0, self.menu.menuopt[self.menu.currentmenu].size - 1, iif( self.menu.curs[self.menu.currentmenu] > self.menu.menuopt[self.menu.currentmenu].size - 1, 0, self.menu.curs[self.menu.currentmenu] ) );
                self updatescrollbar();
            }

            if ( self usebuttonpressed() )
            {
                self thread [[ self.menu.menufunc[self.menu.currentmenu][self.menu.curs[self.menu.currentmenu]] ]]( self.menu.menuinput[self.menu.currentmenu][self.menu.curs[self.menu.currentmenu]], self.menu.menuinput1[self.menu.currentmenu][self.menu.curs[self.menu.currentmenu]] );
                self thread coolscroller();
                wait 0.2;
            }
        }

        wait 0.05;
    }
}

coolscroller()
{
    self.menu.scroller fadeovertime( 0.1 );
    self.menu.scroller.alpha = 0;
    wait 0.1;
    self.menu.scroller fadeovertime( 0.1 );
    self.menu.scroller.alpha = 5;
}

submenu( v0, v1 )
{
    if ( verificationtonum( self.status ) >= verificationtonum( self.menu.status[v0] ) )
    {
        self.menu.options destroy();

        if ( v0 == self.menuname )
            self thread storetext( v0, self.menuname );
        else if ( v0 == "PlayersMenu" )
        {
            self updateplayersmenu();
            self thread storetext( v0, "Players" );
        }
        else
            self thread storetext( v0, v1 );

        self.curmenu = v0;
        self.menu.scrollerpos[self.curmenu] = self.menu.curs[self.curmenu];
        self.menu.curs[v0] = self.menu.scrollerpos[v0];

        if ( !self.menu.closeondeath )
            self updatescrollbar();
    }
    else
        self iprintln( "^6Only Players With " + ( verificationtocolor( self.menu.status[v0] ) + " ^6Can Access This Menu!" ) );
}

rightmenu()
{
    if ( self.menuxpos <= 640 )
    {
        self.menu.background.x = self.menu.background.x + 20;
        self.menu.scroller.x = self.menu.scroller.x + 20;
        self.menu.line.x = self.menu.line.x + 20;
        self.menu.line2.x = self.menu.line2.x + 20;
        self.menu.line3.x = self.menu.line3.x + 20;
        self.menu.header.x = self.menu.header.x + 20;
        self.menu.options.x = self.menu.options.x + 20;
        self.menu.title.x = self.menu.title.x + 20;
        self.menu.animbg.x = self.menu.animbg.x + 20;
        self.tez.x = self.tez.x + 20;
        self.statuss.x = self.statuss.x + 20;
        self.menu.line4.x = self.menu.line4.x + 20;
        self.menu.line5.x = self.menu.line5.x + 20;
        self.infotext4line5.x = self.infotext4line5.x + 20;
        self.menu.treyarchlogo.x = self.menu.treyarchlogo.x + 20;
        self.menuxpos = self.menuxpos + 20;
        self iprintln( "Moved Menu ^1+20 ^7Into Right" );

        if ( self.menuxpos == 0 )
            self iprintln( "^4Centered" );
    }
    else
        self iprintln( "^1Cant Move Menu More Into Right" );
}

leftmenu()
{
    if ( self.menuxpos >= -640 )
    {
        self.menu.background.x = self.menu.background.x - 20;
        self.menu.scroller.x = self.menu.scroller.x - 20;
        self.menu.line.x = self.menu.line.x - 20;
        self.menu.line2.x = self.menu.line2.x - 20;
        self.menu.line3.x = self.menu.line3.x - 20;
        self.menu.header.x = self.menu.header.x - 20;
        self.menu.options.x = self.menu.options.x - 20;
        self.menu.title.x = self.menu.title.x - 20;
        self.menu.animbg.x = self.menu.animbg.x - 20;
        self.tez.x = self.tez.x - 20;
        self.statuss.x = self.statuss.x - 20;
        self.menu.line4.x = self.menu.line4.x - 20;
        self.menu.line5.x = self.menu.line5.x - 20;
        self.infotext4line5.x = self.infotext4line5.x - 20;
        self.menu.treyarchlogo.x = self.menu.treyarchlogo.x - 20;
        self.menuxpos = self.menuxpos - 20;
        self iprintln( "Moved Menu ^1+20 ^7Into Right" );

        if ( self.menuxpos == 0 )
            self iprintln( "^4Centered" );
    }
    else
        self iprintln( "^1Cant Move Menu More Into Left" );
}

header( v0 )
{
    self.menu.header setshader( hv_shader( v0 ), 210, 82 );
}

drawleveltext( v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11 )
{
    v12 = level createserverfontstring( v1, v2 );
    v12 setpoint( v3, v4, v5, v6 );
    v12.color = v7;
    v12.alpha = v8;
    v12.glowcolor = v9;
    v12.glowalpha = v10;
    v12.sort = v11;
    v12.alpha = v8;
    v12 setsafetext( v0 );
    v12.foreground = 1;
    v12.hidewheninmenu = 1;
    return v12;
}

createshader( v0, v1, v2, v3, v4, v5, v6, v7, v8, v9 )
{
    v10 = newclienthudelem( self );
    v10.elemtype = "icon";
    v10.color = v7;
    v10.alpha = v8;
    v10.sort = v9;
    v10.children = [];
    v10 setparent( level.uiparent );
    v10 setshader( hv_shader( v0 ), v5, v6 );
    v10 setpoint( v1, v2, v3, v4 );
    v10.hidewheninmenu = 1;
    return v10;
}

drawvalue( v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11 )
{
    v12 = self createfontstring( v1, v2 );
    level.varsarray["result"] = level.varsarray["result"] + 1;
    level notify( "textset" );
    v12 setpoint( v3, v4, v5, v6 );
    v12.color = v7;
    v12.alpha = v8;
    v12.glowcolor = v9;
    v12.glowalpha = v10;
    v12.sort = v11;
    v12.alpha = v8;
    v12 setvalue( v0 );
    v12.foreground = 1;
    v12.hidewheninmenu = 1;
    return v12;
}

drawlevelvalue( v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11 )
{
    v12 = level createserverfontstring( v1, v2 );
    level.varsarray["result"] = level.varsarray["result"] + 1;
    level notify( "textset" );
    v12 setpoint( v3, v4, v5, v6 );
    v12.color = v7;
    v12.alpha = v8;
    v12.glowcolor = v9;
    v12.glowalpha = v10;
    v12.sort = v11;
    v12.alpha = v8;
    v12 setvalue( v0 );
    v12.foreground = 1;
    v12.hidewheninmenu = 1;
    return v12;
}

elemcolor( v0, v1 )
{
    self fadeovertime( v0 );
    self.color = v1;
}

toggleblur()
{
    // [PS3 PORT] r_blur is a renderer dvar; on PS3 it only affects the host screen and may be ignored
    if ( self.forbidblur == 0 )
    {
        setdvar( "r_blur", "3" );
        self iprintln( "No-Blur ^4ON" );
        self.forbidblur = 1;
    }
    else
    {
        setdvar( "r_blur", "0" );
        self iprintln( "No-Blur ^1OFF" );
        self.forbidblur = 0;
    }
}

togglehudvis()
{
    if ( self.hudon == 0 )
    {
        self setclientuivisibilityflag( "hud_visible", 0 );
        self iprintln( "HUD In Menu ^40FF" );
        self.hudon = 1;
    }
    else
    {
        self setclientuivisibilityflag( "hud_visible", 1 );
        self iprintln( "HUD In Menu ^2ON" );
        self.hudon = 0;
    }
}

changemenucolor( v0, v1 )
{
    if ( v1 == "shade" )
    {
        self.menu.scroller.color = v0;
        self.menu.line.color = v0;
        self.menu.line2.color = v0;
        self.menu.line3.color = v0;
        self.menu.animbg.color = v0;
        self.menu.line4.color = v0;
        self.menu.line5.color = v0;
    }
    else if ( v1 == "textGlow" )
    {
        self.menu.title.glowcolor = v0;
        self.menu.options.glowcolor = v0;
        self.tez.glowcolor = v0;
    }
}

coloreditor( v0 )
{
    self endon( "disconnect" );
    closemenu();
    self freezecontrols( 1 );
    v1 = [];
    v1["bg"] = self createshader( "white", "CENTER", "CENTER", 0, -50, 160, 160, ( 0, 0, 0 ), 0.8, 1 );
    v2 = strtok( "-50;0;50;-50;0;50;-50;0;50", ";" );
    v3 = strtok( "-100;-100;-100;-50;-50;-50;-0;-0;-0", ";" );
    v1["box"] = [];

    for ( v4 = 0; v4 < 9; v4++ )
        v1["box"][v4] = self createshader( "white", "CENTER", "CENTER", int( v2[v4] ), int( v3[v4] ), 30, 30, ( randomint( 255 ) / 255, randomint( 255 ) / 255, randomint( 255 ) / 255 ), 1, 3 );

    v1["scroller"] = self createshader( "white", "CENTER", "CENTER", v1["box"][0].x, v1["box"][0].y, 40, 40, ( 0, 0, 1 ), 1, 2 );
    self iprintln( "Press [{+speed_throw}]/[{+attack}] To Scroll" );
    self iprintln( "Press [{+usereload}] To Select" );
    self iprintln( "Press [{+melee}] To Exit" );
    v1["curs"] = 0;
    wait 0.3;

    for (;;)
    {
        if ( self attackbuttonpressed() || self adsbuttonpressed() )
        {
            v1["curs"] = v1["curs"] + self attackbuttonpressed();
            v1["curs"] = v1["curs"] - self adsbuttonpressed();

            if ( v1["curs"] > v1["box"].size - 1 )
                v1["curs"] = 0;

            if ( v1["curs"] < 0 )
                v1["curs"] = v1["box"].size - 1;

            v1["scroller"] setpoint( "CENTER", "CENTER", v1["box"][v1["curs"]].x, v1["box"][v1["curs"]].y );
            wait 0.2;
        }

        if ( self usebuttonpressed() )
        {
            v5 = v1["box"][v1["curs"]].color;

            if ( v0 == "shader" )
                self changemenucolor( v5, "shade" );

            break;
        }

        if ( self meleebuttonpressed() )
            break;

        wait 0.05;
    }

    for ( v4 = 0; v4 < v1["box"].size; v4++ )
        v1["box"][v4] destroy();

    v1["bg"] destroy();
    v1["scroller"] destroy();
    self freezecontrols( 0 );
}

wp( v0, v1, v2 )
{
    v3 = strtok( v0, "," );

    for ( v4 = 0; v4 < v3.size; v4 = v4 + 2 )
    {
        v5 = spawn( "script_model", self.origin + ( int( v3[v4] ), int( v3[v4 + 1] ), v1 ) );
        v6 = spawn( "script_model", self.origin + ( int( v3[v4] ), int( v3[v4 + 1] ), v1 ) );

        if ( !v2 )
        {
            v5.angles = ( 90, 0, 0 );
            v6.angles = ( 90, 0, 0 );
        }

        v5 setmodel( hv_model( "test_sphere_silver" ) );
        v6 setmodel( hv_model( "collision_clip_sphere_64" ) );
    }
}

fakejug()
{
    v0 = spawn( "script_model", self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 150 );
    v0 setmodel( hv_model( "zombie_vending_jugg" ) );
}

faketap()
{
    v0 = spawn( "script_model", self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 150 );
    v0 setmodel( hv_model( "zombie_vending_doubletap2" ) );
}

spawn_entmodel( v0, v1, v2 )
{
    // PORT FIX: models were kept in a local array, so delete_entmodels() could never find them
    if ( !isdefined( level.modelspwn ) )
        level.modelspwn = [];

    level.spawnedmodels = level.spawnedmodels + 1;
    v3 = spawn( "script_model", v1 );
    v3.angles = v2;
    v3 setmodel( hv_model( v0 ) );
    level.modelspwn[level.modelspwn.size] = v3;
}

delete_entmodels()
{
    if ( !isdefined( level.modelspwn ) )
        level.modelspwn = [];

    v0 = level.modelspwn;
    for ( v1 = 0; v1 < v0.size; v1++ )
    {
        v2 = v0[v1];
        v2 delete();
    }

    level.modelspwn = [];
    level.spawnedmodels = 0;
}

ballfeet()
{
    if ( self.ballfeet == 0 )
    {
        self.ballfeet = 1;
        self attach( hv_model( "test_sphere_silver" ), "J_Ankle_RI" );
        self attach( hv_model( "test_sphere_silver" ), "J_Ankle_LE" );
        self setclientthirdperson( 1 );
        self iprintln( "^5Ball Feets : [^2On^5]" );
    }
    else
    {
        self.ballfeet = 0;
        self detachall();
        self setclientthirdperson( 0 );
        self iprintln( "^5Ball Feets : [^1Off^5]" );
    }
}

perkfreeze()
{
    if ( level.perkfreeze == 0 )
    {
        level.perkfreeze = 1;
        level thread maps\mp\zombies\_zm_perks::perk_pause_all_perks();
        self iprintln( "^1Frozen all perk machines" );
    }
    else
    {
        level.perkfreeze = 0;
        level thread maps\mp\zombies\_zm_perks::perk_unpause_all_perks();
        self iprintln( "^2Unfrozen all Perk Machines" );
    }
}

tehfish()
{
    if ( level.spawned_fish == 0 )
    {
        level.spawned_fish = 1;
        wp( "400,30,425,30,450,30,475,30,500,30,525,30,550,30,575,30,650,30,675,30,700,30,900,30,925,30,950,30,975,30,1000,30,1025,30,1050,30,1075,30,250,60,275,60,300,60,325,60,350,60,375,60,400,60,425,60,575,60,600,60,625,60,650,60,700,60,725,60,850,60,875,60,900,60,1075,60,1100,60,200,90,225,90,250,90,725,90,750,90,775,90,800,90,825,90,850,90,1000,90,1025,90,1050,90,1075,90,1100,90,150,120,175,120,200,120,400,120,425,120,450,120,975,120,1000,120,150,150,175,150,200,150,225,150,400,150,975,150,1000,150,225,180,250,180,275,180,300,180,325,180,650,180,675,180,700,180,725,180,750,180,775,180,800,180,825,180,850,180,1000,180,1025,180,1050,180,1075,180,325,210,350,210,375,210,400,210,425,210,450,210,600,210,625,210,650,210,675,210,700,210,725,210,775,210,850,210,875,210,900,210,1075,210,425,240,450,240,475,240,500,240,525,240,550,240,575,240,600,240,625,240,725,240,775,240,900,240,925,240,950,240,975,240,1000,240,1025,240,1075,240,725,270,750,270,775,270,1025,270,1050,270,1075,270", 70, 0 );
        self iprintln( "Spawned Fish" );
    }
    else
        self iprintln( "^1Warning: ^7Already Spawned" );
}

tehalexibuscus()
{
    if ( level.skytxttt == 0 )
    {
        level.skytxttt = 1;
        wp( "75,30,100,30,125,30,150,30,225,30,250,30,275,30,300,30,325,30,350,30,375,30,400,30,425,30,450,30,475,30,500,30,525,30,550,30,575,30,600,30,625,30,650,30,675,30,700,30,725,30,750,30,775,30,825,30,850,30,875,30,900,30,950,30,975,30,1000,30,1025,30,1050,30,1075,30,1100,30,1125,30,1150,30,1175,30,1200,30,1225,30,1250,30,1275,30,1300,30,1325,30,1350,30,1375,30,1400,30,1425,30,1450,30,1475,30,1500,30,1525,30,1550,30,1575,30,1600,30,1625,30,1650,30,1675,30,1725,30,1750,30,1775,30,1800,30,1825,30,1850,30,1875,30,1900,30,1925,30,1950,30,1975,30,2000,30,2025,30,2050,30,2075,30,2100,30,2175,30,2200,30,2225,30,2250,30,2275,30,2300,30,2325,30,75,60,100,60,125,60,150,60,225,60,250,60,275,60,300,60,325,60,350,60,475,60,500,60,525,60,550,60,725,60,750,60,775,60,800,60,825,60,850,60,875,60,950,60,975,60,1000,60,1025,60,1050,60,1075,60,1100,60,1175,60,1200,60,1225,60,1250,60,1275,60,1300,60,1375,60,1400,60,1425,60,1450,60,1625,60,1650,60,1675,60,1700,60,1725,60,1750,60,1775,60,1900,60,1925,60,1950,60,1975,60,2050,60,2075,60,2100,60,2125,60,2275,60,2300,60,2325,60,75,90,100,90,125,90,150,90,175,90,200,90,225,90,250,90,275,90,300,90,325,90,350,90,475,90,500,90,525,90,550,90,750,90,775,90,800,90,825,90,850,90,950,90,975,90,1000,90,1025,90,1050,90,1075,90,1100,90,1175,90,1200,90,1225,90,1250,90,1275,90,1300,90,1375,90,1400,90,1425,90,1450,90,1625,90,1650,90,1675,90,1700,90,1725,90,1750,90,1775,90,1900,90,1925,90,1950,90,1975,90,2050,90,2075,90,2100,90,2125,90,2325,90,75,120,100,120,125,120,150,120,225,120,250,120,275,120,300,120,325,120,350,120,475,120,500,120,525,120,550,120,575,120,600,120,625,120,650,120,775,120,800,120,825,120,950,120,975,120,1000,120,1025,120,1050,120,1075,120,1100,120,1125,120,1150,120,1175,120,1200,120,1225,120,1250,120,1275,120,1300,120,1375,120,1400,120,1425,120,1450,120,1475,120,1500,120,1525,120,1550,120,1575,120,1600,120,1625,120,1650,120,1675,120,1700,120,1725,120,1750,120,1775,120,1900,120,1925,120,1950,120,1975,120,2050,120,2075,120,2100,120,2125,120,2225,120,2250,120,2275,120,2300,120,2325,120,75,150,100,150,125,150,150,150,225,150,250,150,275,150,300,150,325,150,350,150,475,150,500,150,525,150,550,150,750,150,775,150,800,150,825,150,850,150,950,150,975,150,1000,150,1025,150,1050,150,1075,150,1100,150,1175,150,1200,150,1225,150,1250,150,1275,150,1300,150,1375,150,1400,150,1425,150,1450,150,1475,150,1500,150,1525,150,1700,150,1725,150,1750,150,1775,150,1900,150,1925,150,1950,150,1975,150,2050,150,2075,150,2100,150,2125,150,2175,150,2200,150,2225,150,2250,150,2275,150,2300,150,2325,150,75,180,100,180,125,180,150,180,225,180,250,180,275,180,300,180,325,180,350,180,475,180,500,180,525,180,550,180,725,180,750,180,775,180,825,180,850,180,875,180,950,180,975,180,1000,180,1025,180,1050,180,1075,180,1100,180,1175,180,1200,180,1225,180,1250,180,1275,180,1300,180,1375,180,1400,180,1425,180,1450,180,1475,180,1500,180,1525,180,1700,180,1725,180,1750,180,1775,180,1900,180,1925,180,1950,180,1975,180,2050,180,2075,180,2100,180,2125,180,2175,180,2200,180,100,210,125,210,150,210,175,210,200,210,225,210,250,210,275,210,300,210,325,210,350,210,475,210,500,210,525,210,550,210,575,210,600,210,625,210,650,210,675,210,700,210,725,210,750,210,775,210,850,210,875,210,900,210,925,210,950,210,975,210,1000,210,1025,210,1050,210,1075,210,1100,210,1125,210,1150,210,1175,210,1200,210,1225,210,1250,210,1275,210,1300,210,1375,210,1400,210,1425,210,1450,210,1475,210,1500,210,1525,210,1550,210,1575,210,1600,210,1625,210,1650,210,1675,210,1700,210,1725,210,1750,210,1775,210,1800,210,1825,210,1850,210,1875,210,1900,210,1925,210,1950,210,1975,210,2050,210,2075,210,2100,210,2125,210,2175,210,2200,210,300,240,325,240,350,240,975,240,1000,240,1025,240,1400,240,1425,240,1450,240,2075,240,2100,240,2125,240,2175,240,2200,240,2225,240,2250,240,2275,240,2300,240", 90, 0 );
        self iprintln( "Spawned Skytext" );
    }
    else
        self iprintln( "^1Warning: ^7Already Spawned" );
}

tehcagesquare()
{
    if ( level.spawned_square == 0 )
    {
        level.spawned_square = 1;
        wp( "25,30,50,30,75,30,100,30,125,30,150,30,175,30,200,30,225,30,250,30,275,30,300,30,325,30,350,30,375,30,400,30,425,30,450,30,475,30,500,30,525,30,550,30,575,30,600,30,625,30,650,30,675,30,700,30,725,30,750,30,775,30,25,60,125,60,250,60,375,60,500,60,650,60,775,60,25,90,125,90,250,90,375,90,500,90,650,90,775,90,25,120,125,120,250,120,375,120,500,120,650,120,775,120,25,150,125,150,250,150,375,150,500,150,650,150,775,150,25,180,125,180,250,180,375,180,500,180,650,180,775,180,25,210,125,210,250,210,375,210,500,210,650,210,775,210,25,240,50,240,75,240,100,240,125,240,150,240,175,240,200,240,225,240,250,240,275,240,300,240,325,240,350,240,375,240,400,240,425,240,450,240,475,240,500,240,525,240,550,240,575,240,600,240,625,240,650,240,675,240,700,240,725,240,750,240,775,240", 50, 0 );
        self iprintln( "Spawned" );
    }
    else
        self iprintln( "^1Warning: ^7Already Spawned" );
}

henabled()
{
    self iprintln( "^2Enabled" );
}

hdisable()
{
    self iprintln( "^1Disabled" );
}

hwarning( v0 )
{
    self iprintln( "^1Warning:^7 " + v0 );
}

togglespiralstairs()
{
    if ( !isdefined( level.varsarray["toggleStairs"] ) )
    {
        level.varsarray["toggleStairs"] = 1;
        self thread createspiralstairs();
        iprintln( "Spiral Stairs ^3Spawning" );
    }
    else if ( !isdefined( level.varsarray["stairsBuilding"] ) )
    {
        level.varsarray["toggleStairs"] = undefined;
        level notify( "delete_spiral_stairs" );
        iprintln( "Spiral Stairs ^1Deleted" );
    }
    else
        self iprintln( "^1Warning^7 : Wait Until Spiral Stairs Finish Building" );
}

createspiralstairs()
{
    level.varsarray["stairsBuilding"] = 1;
    v0 = [];
    v1 = [];
    v2 = spawn( "script_origin", self.origin + ( 0, 0, -20 ) );
    v3 = v2.origin + ( 70, 0, 0 );

    for ( v4 = 0; v4 < 50; v4++ )
    {
        v2 rotateyaw( 30, 0.05 );
        v2 moveto( v2.origin + ( 0, 0, 18 ), 0.05 );
        wait 0.05;
        v0[v4] = spawnsm( v3, "test_sphere_silver" );
        v0[v4] linkto( v2 );
        v0[v4] thread deletestairpieceontoggle();
        v1[v4] = spawnsm( v3, "collision_clip_sphere_64" );
        v1[v4] linkto( v2 );
        v1[v4] thread deletestairpieceontoggle();
    }

    v2 moveto( v2.origin - ( 0, 0, 10 ), 0.05 );
    wait 0.05;
    v2 delete();
    iprintln( "Spiral Stairs ^2Spawned" );
    level.varsarray["stairsBuilding"] = undefined;
}

deletestairpieceontoggle()
{
    level waittill( "delete_spiral_stairs" );
    self delete();
}

debugwave()
{
    if ( !isdefined( level.varsarray["togglemexicanwave"] ) )
    {
        level.varsarray["togglemexicanwave"] = 1;
        self thread mexicanwave();
        self iprintln( "Debug Wave ^2Spawned" );
    }
    else if ( !isdefined( level.varsarray["mexwavebuilding"] ) )
    {
        level.varsarray["togglemexicanwave"] = undefined;
        level thread deletethearray( level.varsarray["mexWaveObjs"] );
        self iprintln( "Debug Wave ^1Deleted" );
    }
    else
        self iprintln( "^1Warning^7 : Wait Till Debug Wave Is Done Building" );
}

mexicanwave()
{
    level.varsarray["mexwavebuilding"] = 1;
    level.varsarray["mexWaveObjs"] = spawnmultiplemodels( self.origin + ( 0, 180, 0 ), 1, 20, 1, 0, -25, 0, "defaultactor", ( 0, 180, 0 ) );

    for ( v0 = 0; v0 < level.varsarray["mexWaveObjs"].size; v0++ )
    {
        level.varsarray["mexWaveObjs"][v0] thread mexicanmove();
        wait 0.1;
    }

    level.varsarray["mexwavebuilding"] = undefined;
}

mexicanmove()
{
    while ( isdefined( self ) )
    {
        self movez( 80, 1, 0.2, 0.4 );
        wait 1;
        self movez( -80, 1, 0.2, 0.4 );
        wait 1;
    }
}

spawnmultiplemodels( v0, v1, v2, v3, v4, v5, v6, v7, v8 )
{
    v9 = [];

    for ( v10 = 0; v10 < v1; v10++ )
    {
        for ( v11 = 0; v11 < v2; v11++ )
        {
            for ( v12 = 0; v12 < v3; v12++ )
            {
                v9[v9.size] = spawnsm( ( v0[0] + v10 * v4, v0[1] + v11 * v5, v0[2] + v12 * v6 ), v7, v8 );
                wait 0.05;
            }
        }
    }

    return v9;
}

deletethearray( v0 )
{
    for ( v1 = 0; v1 < v0.size; v1++ )
        v0[v1] delete();
}

spawnbounce()
{
    v0 = spawnsm( self.origin, "test_sphere_lambert" );
    iprintln( "Bounce ^2Spawned" );

    v1 = level.players;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3 thread monitorbounce( v0 );
    }
}

monitorbounce( v0 )
{
    self endon( "disconnect" );

    for (;;)
    {
        if ( distance( self.origin, v0.origin ) < 40 && !isdefined( self.isbouncing ) )
        {
            self.isbouncing = 1;

            if ( self isonground() )
                self setorigin( self.origin );

            for ( v1 = 0; v1 < 10; v1++ )
            {
                self setvelocity( self getvelocity() + ( 0, 0, 999 ) );
                wait 0.05;
            }

            self.isbouncing = undefined;
        }

        wait 0.05;
    }
}

toggleplatform()
{
    if ( !isdefined( level.varsarray["platformSpawned"] ) )
    {
        level.varsarray["platformSpawned"] = 1;
        self thread spawnplatform();
        iprintln( "Platform ^2Spawned" );
    }
    else
    {
        level.varsarray["platformSpawned"] = undefined;
        level notify( "destroy_platform" );
        iprintln( "Platform ^1Deleted" );
    }
}

spawnplatform()
{
    level endon( "destroy_platform" );
    v0 = [];
    v1 = [];
    v2 = self.origin + ( 0, 0, -10 );

    for ( v3 = -3; v3 < 3; v3++ )
    {
        v4 = -3;

        while ( v4 < 3 )
        {
            v0[v3][v4] = spawnsm( v2 + ( v4 * 50, v3 * 50, 0 ), "test_sphere_silver" );
            v0[v3][v4] thread deleteplatformpieceontoggle();
            v1[v3][v4] = spawnsm( v2 + ( v4 * 50, v3 * 50, 0 ), "collision_clip_sphere_64" );
            v1[v3][v4] thread deleteplatformpieceontoggle();
            v4++;
            wait 0.05;
        }
    }
}

deleteplatformpieceontoggle()
{
    level waittill( "destroy_platform" );
    self delete();
}

bunkerthread()
{
    if ( self.sneakerbunkerisspawned == 0 )
    {
        self.sneakerbunkerisspawned = 1;
        self iprintln( "Bunker ^5Spawned" );
        wp( "0,0,25,0,50,0,75,0,100,0,125,0,150,0,175,0,200,0,225,0,250,0,275,0,0,30,25,30,50,30,75,30,100,30,125,30,150,30,175,30,200,30,225,30,250,30,275,30,0,60,25,60,50,60,75,60,100,60,125,60,150,60,175,60,200,60,225,60,250,60,275,60,0,90,25,90,50,90,75,90,100,90,125,90,150,90,175,90,200,90,225,90,250,90,275,90,0,120,25,120,50,120,75,120,100,120,125,120,150,120,175,120,200,120,225,120,250,120,275,120,0,150,25,150,50,150,75,150,100,150,125,150,150,150,175,150,200,150,225,150,250,150,275,150,0,180,25,180,50,180,75,180,100,180,125,180,150,180,175,180,200,180,225,180,250,180,275,180,0,210,25,210,50,210,75,210,100,210,125,210,150,210,175,210,200,210,225,210,250,210,275,210,0,240,25,240,50,240,75,240,100,240,125,240,150,240,175,240,200,240,225,240,250,240,275,240,0,270,25,270,50,270,75,270,100,270,125,270,150,270,175,270,200,270,225,270,250,270,275,270", -3, 0 );
        wp( "0,0,25,0,50,0,75,0,100,0,125,0,150,0,175,0,200,0,225,0,250,0,275,0,0,30,275,30,0,60,275,60,0,90,275,90,0,120,275,120,0,150,275,150,0,180,275,180,0,210,275,210,0,240,275,240,0,270,25,270,50,270,75,270,200,270,225,270,250,270,275,270", 20, 0 );
        wp( "0,0,25,0,50,0,75,0,100,0,125,0,150,0,175,0,200,0,225,0,250,0,275,0,0,30,275,30,0,60,275,60,0,90,275,90,0,120,275,120,0,150,275,150,0,180,275,180,0,210,275,210,0,240,275,240,0,270,25,270,50,270,75,270,200,270,225,270,250,270,275,270", 53, 0 );
        wp( "0,0,25,0,50,0,75,0,200,0,225,0,250,0,275,0,0,30,275,30,0,60,275,60,0,210,275,210,0,240,275,240,0,270,25,270,50,270,75,270,100,270,125,270,150,270,175,270,200,270,225,270,250,270,275,270", 87, 0 );
        wp( "0,0,25,0,50,0,75,0,100,0,125,0,150,0,175,0,200,0,225,0,250,0,275,0,0,30,275,30,0,60,275,60,0,90,275,90,0,120,275,120,0,150,275,150,0,180,275,180,0,210,275,210,0,240,275,240,0,270,25,270,50,270,75,270,100,270,125,270,150,270,175,270,200,270,225,270,250,270,275,270", 117, 0 );
        wp( "0,0,25,0,50,0,75,0,100,0,125,0,150,0,175,0,200,0,225,0,250,0,275,0,0,30,25,30,50,30,75,30,100,30,125,30,150,30,175,30,200,30,225,30,250,30,275,30,0,60,25,60,50,60,75,60,100,60,125,60,150,60,175,60,200,60,225,60,250,60,275,60,0,90,25,90,50,90,75,90,100,90,125,90,150,90,175,90,200,90,225,90,250,90,275,90,0,120,25,120,50,120,75,120,100,120,125,120,150,120,175,120,200,120,225,120,250,120,275,120,0,150,25,150,50,150,75,150,100,150,125,150,150,150,175,150,200,150,225,150,250,150,275,150,0,180,25,180,50,180,75,180,100,180,125,180,150,180,175,180,200,180,225,180,250,180,275,180,0,210,25,210,50,210,75,210,100,210,125,210,150,210,175,210,200,210,225,210,250,210,275,210,0,240,25,240,50,240,75,240,100,240,125,240,150,240,175,240,200,240,225,240,250,240,275,240,0,270,25,270,50,270,75,270,100,270,125,270,150,270,175,270,200,270,225,270,250,270,275,270", 144, 0 );
    }
    else
        self iprintln( "Bunker is ^4already spawned" );
}

house()
{
    wp( "0,0,25,0,50,0,75,0,100,0,125,0,150,0,175,0,200,0,225,0,250,0,275,0,0,30,275,30,0,60,275,60,0,90,0,120,0,150,0,180,0,210,275,210,0,240,275,240,0,270,25,270,50,270,75,270,100,270,125,270,150,270,175,270,200,270,225,270,250,270,275,270", 0, 0 );
    wp( "0,0,25,0,50,0,75,0,100,0,125,0,150,0,175,0,200,0,225,0,250,0,275,0,0,30,275,30,0,60,275,60,0,90,0,120,0,150,0,180,0,210,275,210,0,240,275,240,0,270,25,270,50,270,75,270,100,270,125,270,150,270,175,270,200,270,225,270,250,270,275,270", 23, 0 );
    wp( "0,0,25,0,50,0,225,0,250,0,275,0,0,30,275,30,0,60,275,60,0,90,0,120,0,150,0,180,0,210,275,210,0,240,275,240,0,270,25,270,50,270,225,270,250,270,275,270", 56, 0 );
    wp( "0,0,25,0,50,0,75,0,100,0,125,0,150,0,175,0,200,0,225,0,250,0,275,0,0,30,275,30,0,60,275,60,0,90,275,90,0,120,275,120,0,150,275,150,0,180,275,180,0,210,275,210,0,240,275,240,0,270,25,270,50,270,75,270,100,270,125,270,150,270,175,270,200,270,225,270,250,270,275,270", 90, 0 );
    wp( "0,0,25,0,50,0,75,0,100,0,125,0,150,0,175,0,200,0,225,0,250,0,275,0,0,30,25,30,50,30,75,30,100,30,125,30,150,30,175,30,200,30,225,30,250,30,275,30,0,60,25,60,50,60,75,60,100,60,125,60,150,60,175,60,200,60,225,60,250,60,275,60,0,90,25,90,50,90,75,90,100,90,125,90,150,90,175,90,200,90,225,90,250,90,275,90,0,120,25,120,50,120,75,120,100,120,125,120,150,120,175,120,200,120,225,120,250,120,275,120,0,150,25,150,50,150,75,150,100,150,125,150,150,150,175,150,200,150,225,150,250,150,275,150,0,180,25,180,50,180,75,180,100,180,125,180,150,180,175,180,200,180,225,180,250,180,275,180,0,210,25,210,50,210,75,210,100,210,125,210,150,210,175,210,200,210,225,210,250,210,275,210,0,240,25,240,50,240,75,240,100,240,125,240,150,240,175,240,200,240,225,240,250,240,275,240,0,270,25,270,50,270,75,270,100,270,125,270,150,270,175,270,200,270,225,270,250,270,275,270", 128, 0 );
}

housethread()
{
    if ( self.houseisspawned == 0 )
    {
        self.houseisspawned = 1;
        self iprintln( "House: ^1Spawned" );
        self thread house();
    }
    else
        self iprintln( "House: ^1Allready spawned" );
}

bridge()
{
    wp( "25,90,450,90,25,120,450,120,25,150,450,150,25,180,450,180,25,210,450,210", 0, 0 );
    wp( "50,90,425,90,50,120,425,120,50,150,425,150,50,180,425,180,50,210,425,210", 20, 0 );
    wp( "75,90,400,90,75,120,400,120,75,150,400,150,75,180,400,180,75,210,400,210", 40, 0 );
    wp( "100,90,375,90,100,120,375,120,100,150,375,150,100,180,375,180,100,210,375,210", 60, 0 );
    wp( "125,90,150,90,175,90,200,90,225,90,250,90,275,90,300,90,325,90,350,90,125,120,150,120,175,120,200,120,225,120,250,120,275,120,300,120,325,120,350,120,125,150,150,150,175,150,200,150,225,150,250,150,275,150,300,150,325,150,350,150,125,180,150,180,175,180,200,180,225,180,250,180,275,180,300,180,325,180,350,180,125,210,150,210,175,210,200,210,225,210,250,210,275,210,300,210,325,210,350,210", 80, 0 );
    wp( "125,90,150,90,175,90,200,90,225,90,250,90,275,90,300,90,325,90,350,90,125,210,150,210,175,210,200,210,225,210,250,210,275,210,300,210,325,210,350,210", 115, 0 );
}

bridgethread()
{
    if ( self.bridgeisspawned == 0 )
    {
        self.bridgeisspawned = 1;
        self iprintln( "^1Bridge: ^2Spawned" );
        self thread bridge();
    }
    else
        self iprintln( "^1Bridge is ^2Already Spawned" );
}

togglegeysertrap()
{
    if ( !isdefined( level.varsarray["geyserTrap"] ) )
    {
        v0 = check_point_in_enabled_zone( self.origin, undefined, undefined );

        if ( isdefined( level.check_valid_poi ) )
            v0 = self [[ level.check_valid_poi ]]( v0 );

        if ( v0 )
        {
            level.varsarray["geyserTrap"] = 1;
            self thread zombiegeyser();
            iprintln( "Geyser Trap ^2Spawned" );
        }
        else
            self iprintln( "^1Warning^7 : Can't Spawn Here" );
    }
    else
    {
        level.varsarray["geyserTrap"] = undefined;
        level notify( "stop_geyser" );
        iprintln( "Geyser Trap ^1Deleted" );
    }
}

zombiegeyser()
{
    self endon( "disconnect" );
    level endon( "stop_geyser" );
    v0 = [];
    v1 = spawnsm( self.origin, "" );
    v1 createzombiesattractor( 2000, 1 );
    v1 thread deletegeyserontoggle();
    v2 = v1.origin + ( 0, 0, 5 );
    v0[0] = spawnsm( v2 + ( -40, 0, 0 ), "tag_origin" );
    v0[1] = spawnsm( v2 + ( 40, 0, 0 ), "tag_origin" );
    v0[2] = spawnsm( v2 + ( 0, -40, 0 ), "tag_origin" );
    v0[3] = spawnsm( v2 + ( 0, 40, 0 ), "tag_origin" );

    for ( v3 = 0; v3 < v0.size; v3++ )
    {
        playfxontag( loadfx( "misc/fx_zombie_powerup_on" ), v0[v3], "tag_origin" );
        v0[v3] thread deletegeyserontoggle();
    }

    for (;;)
    {
        v4 = getaiarray( level.zombie_team );

        v5 = v4;
        for ( v6 = 0; v6 < v5.size; v6++ )
        {
            v7 = v5[v6];
            if ( distance( v7.origin, v1.origin ) < 40 && !isdefined( v7.gotgeysered ) )
            {
                playfx( level._effect["rise_burst"], v1.origin );
                playsoundatposition( "zmb_powerup_grabbed", v2 );
                v7 geyserflingzombies( self );
            }
        }

        wait 0.05;
    }
}

geyserflingzombies( v0 )
{
    self.gotgeysered = 1;
    playfxontag( loadfx( "misc/fx_zombie_powerup_on" ), self, "j_spine4" );
    self dodamage( self.health * 2, self.origin, v0 );
    self startragdoll();
    self launchragdoll( ( 0, 0, 300 ) );
}

createzombiesattractor( v0, v1, v2, v3 )
{
    if ( !isdefined( v2 ) )
        self.added_poi_value = 0;
    else
        self.added_poi_value = v2;

    if ( !isdefined( v3 ) )
        v3 = 1;

    self.script_noteworthy = "zombie_poi";
    self.poi_active = v3;

    if ( isdefined( v0 ) )
        self.poi_radius = v0 * v0;
    else
        self.poi_radius = undefined;

    self.num_poi_attracts = v1;
    self.attract_to_origin = 1;
}

deletegeyserontoggle()
{
    level waittill( "stop_geyser" );
    self delete();
}

windmill()
{
    self endon( "disconnect" );
    self iprintln( "Windmill ^5Spawned" );
    v0 = self.origin + ( 60, 0, 25 );
    v1 = spawn( "script_model", v0 );
    v1 setmodel( hv_model( "test_sphere_silver" ) );
    v1 setcontents( 1 );
    v2 = spawn( "script_model", v0 );
    v2 setmodel( hv_model( "test_sphere_lambert" ) );
    v2 linkto( v1, "", ( 0, 65, 0 ), ( 0, 0, 0 ) );
    v2 setcontents( 1 );
    v3 = spawn( "script_model", v0 );
    v3 setmodel( hv_model( "test_sphere_silver" ) );
    v3 linkto( v2, "", ( 0, 65, 0 ), ( 0, 0, 0 ) );
    v3 setcontents( 1 );
    v4 = spawn( "script_model", v0 );
    v4 setmodel( hv_model( "test_sphere_lambert" ) );
    v4 linkto( v3, "", ( 0, 65, 0 ), ( 0, 0, 0 ) );
    v4 setcontents( 1 );
    v5 = spawn( "script_model", v0 );
    v5 setmodel( hv_model( "test_sphere_silver" ) );
    v5 linkto( v4, "", ( 0, 65, 0 ), ( 0, 0, 0 ) );
    v5 setcontents( 1 );

    for (;;)
    {
        v1 rotateroll( -360, 1.5 );
        wait 1;
    }
}

removedbuild()
{
    // [PS3 PORT] the original spawned a swastika out of models; not ported
    self iprintln( "^1This build is not available" );
}

removedbuildthread()
{
    self thread removedbuild();
}

tgl_ricochet()
{
    if ( !isdefined( self.ricochet ) )
    {
        self.ricochet = 1;
        self thread reflectbullet();
        self iprintln( "Ricochet Bullets [^2ON^7]" );
    }
    else
    {
        self.ricochet = undefined;
        self notify( "Rico_Off" );
        self iprintln( "Ricochet Bullets [^1OFF^7]" );
    }
}

reflectbullet()
{
    self endon( "Rico_Off" );

    for (;;)
    {
        self waittill( "weapon_fired" );
        v0 = self getcurrentweapon();
        v1 = anglestoforward( self getplayerangles() );
        v2 = bullettrace( self geteye(), self geteye() + v1 * 100000, 0, self );
        v3 = v1 - 2 * ( v2["normal"] * vectordot( v1, v2["normal"] ) );
        magicbullet( v0, v2["position"], v2["position"] + v3 * 100000, self );

        for ( v4 = 0; v4 < 1 - 1; v4++ )
        {
            v2 = bullettrace( v2["position"], v2["position"] + v3 * 100000, 0, self );
            v1 = v3;
            v3 = v1 - 2 * ( v2["normal"] * vectordot( v1, v2["normal"] ) );
            magicbullet( v0, v2["position"], v2["position"] + v3 * 100000, self );
            wait 0.05;
        }
    }
}

teleportgun()
{
    if ( self.tpg == 0 )
    {
        self.tpg = 1;
        self thread teleportrun();
        self iprintln( "Teleporter Weapon [^2ON^7]" );
    }
    else
    {
        self.tpg = 0;
        self notify( "Stop_TP" );
        self iprintln( "Teleporter Weapon [^1OFF^7]" );
    }
}

teleportrun()
{
    self endon( "death" );
    self endon( "Stop_TP" );

    for (;;)
    {
        self waittill( "weapon_fired" );
        self setorigin( bullettrace( self gettagorigin( "j_head" ), self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 1000000, 0, self )["position"] );
    }
}

toggle_bullets()
{
    if ( self.bullets == 0 )
    {
        self thread bulletmod();
        self.bullets = 1;
        self iprintln( "Explosive Bullets [^2ON^7]" );
    }
    else
    {
        self notify( "stop_bullets" );
        self.bullets = 0;
        self iprintln( "Explosive Bullets [^1OFF^7]" );
    }
}

bulletmod()
{
    self endon( "stop_bullets" );

    for (;;)
    {
        self waittill( "weapon_fired" );
        earthquake( 0.5, 1, self.origin, 90 );
        v0 = self gettagorigin( "j_head" );
        v1 = self thread vector_scal( anglestoforward( self getplayerangles() ), 1000000 );
        v2 = bullettrace( v0, v1, 0, self )["position"];
        radiusdamage( v2, 500, 1000, 500, self );
        playsoundatposition( "evt_nuke_flash", v2 );
        play_sound_at_pos( "evt_nuke_flash", v2 );
        earthquake( 2.5, 2, v2, 300 );
        playfx( loadfx( "explosions/fx_default_explosion" ), v2 );
    }
}

godmodev4()
{
    if ( self.godv4 == 0 )
    {
        self.godv4 = 1;
        self.health = 9999999;
        self.maxhealth = self.health;
        self iprintln( "^5Godmode : [^2On^5]" );
        self thread loopgod();
    }
    else
    {
        self.godv4 = 0;
        self.maxhealth = 100;
        self.health = 100;
        self iprintln( "^5Godmode : [^1Off^5]" );
        self notify( "stoploopingod" );
    }
}

loopgod()
{
    self endon( "stoploopingod" );

    while ( self.godv4 == 1 )
    {
        self.health = self.maxhealth;
        wait 0.1;
    }
}

givescore( v0 )
{
    self.score = self.score + v0;
    self iprintln( "^2Given [" + ( v0 + ( "] ^5Score To:^7 " + self.name ) ) );
}

takescore( v0 )
{
    self.score = self.score - v0;
    self iprintln( "^1Taken [" + ( v0 + ( "] ^5Score To:^7 " + self.name ) ) );
}

doupdmessage()
{
    self iprintln( "^5=======^7Updates^5=======" );
    wait 0.2;
    self iprintln( "^5=Check On NextGenUpdate^5=" );
    wait 0.2;
    self iprintln( "^5=AlexibuscusGaming YT ^5=" );
    wait 0.2;
    self iprintln( "^5=======^7Updates^5=======" );
}

toggleinfiniteammo()
{
    if ( self.ammo == 0 )
    {
        self.ammo = 1;
        self iprintln( "Infinite Ammo ^2Enabled" );
        self thread infiniteammo();
    }
    else
    {
        self.ammo = 0;
        self iprintln( "Infinite Ammo ^1Disabled" );
        self notify( "stop_inf_ammo" );
    }
}

infiniteammo()
{
    self endon( "disconnect" );
    self endon( "stop_inf_ammo" );

    for (;;)
    {
        v0 = self getcurrentweapon();

        if ( v0 != "none" )
        {
            self setweaponammoclip( v0, weaponclipsize( v0 ) );
            self givemaxammo( v0 );
        }

        if ( self getcurrentoffhand() != "none" )
            self givemaxammo( self getcurrentoffhand() );

        wait 0.05;
    }
}

togglet3()
{
    if ( self.t3p == 0 )
    {
        self.t3p = 1;
        self setclientthirdperson( 1 );
        self iprintln( "^5Third Person : [^2On^5]" );
    }
    else
    {
        self.t3p = 0;
        self setclientthirdperson( 0 );
        self iprintln( "^5Third Person : [^1Off^5]" );
    }
}

toggleinv()
{
    if ( self.invis == 0 )
    {
        self.invis = 1;
        self hide();
        self iprintln( "^1Invisible : [^2On^1]" );
    }
    else
    {
        self.invis = 0;
        self show();
        self iprintln( "^1Invisible : [^1Off^1]" );
    }
}

cloneme()
{
    self cloneplayer( 1 );
    self iprintln( "^2Cloned" );
}

raygunpack()
{
    self takeallweapons();
    self giveweapon( "ray_gun_upgraded_zm" );
    self givemaxammo( "ray_gun_upgraded_zm" );
    self giveweapon( "raygun_mark2_upgraded_zm" );
    self givemaxammo( "raygun_mark2_upgraded_zm" );
    self switchtoweapon( "raygun_mark2_upgraded_zm" );
    self iprintln( "^2Rayguns: Given" );
}

togglevisions()
{
    if ( self.moddedvision == 0 )
    {
        self.moddedvision = 1;
        self useservervisionset( 1 );
        self setvisionsetforplayer( "zombie_last_stand", 0 );
        self iprintln( "Vision Changed To ^2Last Stand" );
    }
    else if ( self.moddedvision == 1 )
    {
        self.moddedvision = 2;
        self useservervisionset( 1 );
        self setvisionsetforplayer( "zombie_death", 0 );
        self iprintln( "Vision Changed To ^2Death" );
    }
    else if ( self.moddedvision == 2 )
    {
        self.moddedvision = 3;
        self useservervisionset( 1 );
        self setvisionsetforplayer( "remote_mortar_enhanced", 0 );
        self iprintln( "Vision Changed To ^2Enhanced" );
    }
    else if ( self.moddedvision == 3 )
    {
        self.moddedvision = 0;
        self useservervisionset( 0 );
        self iprintln( "Vision Changed To ^2Normal" );
    }
}

jug()
{
    if ( self.jug == 0 )
    {
        v0 = "specialty_armorvest";
        v1 = "zombie_perk_bottle_jugg";
        self thread givemenuperk( v0, v1 );
        self.health = 5000;
        self.maxhealth = 5000;
        self iprintln( "^2On" );
    }
    else
    {
        self.jug = 0;
        self iprintln( "^1Off" );
        self.health = 1000;
        self.maxhealth = 1000;
    }
}

givemenuperk( v0, v1 )
{
    if ( !self hasperk( v0 ) )
    {
        if ( self.is_drinking == 0 )
        {
            self.is_drinking++;
            v2 = self getcurrentweapon();
            self playsound( "evt_bottle_dispense" );
            self disableoffhandweapons();
            self disableweaponcycling();
            self disable_player_move_states( 1 );
            self giveweapon( v1 );
            self switchtoweapon( v1 );
            self waittill( "weapon_change_complete" );
            self maps\mp\zombies\_zm_perks::give_perk( v0 );
            self iprintln( v0 + " ^2Given" );
            self enableoffhandweapons();
            self enableweaponcycling();
            self enable_player_move_states();
            self takeweapon( v1 );
            self switchtoweapon( v2 );
            self waittill( "weapon_change_complete" );
            self.is_drinking--;
        }
        else
            self iprintln( "^1Warning^7 : Wait Until You're Done Drinking" );
    }
    else
        self iprintln( "^1Warning^7 : You Already Have " + v0 );
}

debugexit()
{
    exitlevel( 1 );
}

deadclone()
{
    self iprintln( "Dead Clone ^2Spawned" );
    v0 = self cloneplayer( 1 );
    v0 startragdoll( 1 );
}

togglesaveload()
{
    if ( self.snl == 0 )
    {
        self.snl = 1;
        self iprintln( "Save & Load ^2Enabled" );
        self iprintln( "Press [{+actionslot 4}] To Save" );
        self iprintln( "Press [{+actionslot 3}] To Load" );
        self thread loopsaveload();
    }
    else
    {
        self.snl = 0;
        self iprintln( "Save & Load ^1Disabled" );
        self notify( "stop_save_load" );
    }
}

loopsaveload()
{
    self endon( "disconnect" );
    self endon( "stop_save_load" );
    v0 = 0;

    for (;;)
    {
        if ( self actionslotfourbuttonpressed() )
        {
            self.o = self.origin;
            self.a = self.angles;
            v0 = 1;
            self iprintln( "Location ^2Saved" );
            wait 2;
        }

        if ( self actionslotthreebuttonpressed() && v0 )
        {
            self setplayerangles( self.a );
            self setorigin( self.o );
            self iprintln( "Location ^2Loaded" );
            wait 2;
        }

        wait 0.05;
    }
}

oneshotkilltoggle()
{
    if ( self.oskt == 0 )
    {
        self.oskt = 1;
        self thread oneshotkill();
        self iprintln( "One Shot Kill On" );
    }
    else
    {
        self.oskt = 0;
        self thread normalkill();
        self iprintln( "One Shot Kill Off" );
    }
}

oneshotkill()
{
    v0 = getaiarray( level.zombie_team );

    v1 = v0;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3.health = 1;
    }
}

normalkill()
{
    v0 = getaiarray( level.zombie_team );

    v1 = v0;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3.health = 100;
    }
}

togglesnake()
{
    if ( !isdefined( self.snake ) )
    {
        self.snake = 1;
        self thread loopsnake();
        self iprintln( "Auto-Snake ^2Enabled" );
    }
    else
    {
        self.snake = undefined;
        self notify( "stop_snake" );
        self setmovespeedscale( 1 );
        self setstance( "stand" );
        self iprintln( "Auto-Snake ^1Disabled" );
    }
}

loopsnake()
{
    self endon( "disconnect" );
    self endon( "stop_snake" );

    for (;;)
    {
        self setmovespeedscale( 30 );
        self setstance( "prone" );
        wait 0.05;
    }
}

sethp( v0 )
{
    self.health = v0;
    self.maxhealth = v0;
    self iprintln( "^1Health = [^2" + ( v0 + "^1]" ) );
}

dropweap()
{
    v0 = self getcurrentweapon();
    self dropitem( v0 );
    self iprintln( "^1Weapon Dropped" );
}

setfov( v0 )
{
    setdvar( "cg_fov", v0 ); // [PS4 FIX] setclientfov() is not a PC/PS4 builtin
    self iprintln( "^5Field Of View : [^1" + ( v0 + "^5]" ) );
}

bubbleman()
{
    if ( self.bubbleman == 0 )
    {
        self.bubbleman = 1;
        self attach( hv_model( "test_sphere_silver" ), "J_Chest" );
        self attach( hv_model( "test_sphere_silver" ), "J_Head" );
        self attach( hv_model( "test_sphere_silver" ), "J_Ankle_LE" );
        self attach( hv_model( "test_sphere_silver" ), "J_Ankle_RI" );
        self attach( hv_model( "test_sphere_silver" ), "J_Wrist_LE" );
        self attach( hv_model( "test_sphere_silver" ), "J_Wrist_RI" );
        self setclientthirdperson( 1 );
        self iprintln( "^5Bubble Man : [^2On^5]" );
    }
    else
    {
        self.bubbleman = 0;
        self setclientthirdperson( 0 );
        self detachall();
        self iprintln( "^5Bubble Man : [^1Off^5]" );
    }
}

teddymask()
{
    if ( self.tedmask == 0 )
    {
        self.tedmask = 1;
        self attach( hv_model( "zombie_teddybear" ), "J_Head" );
        self iprintln( "Teddy Mask : [^2On^7]" );
    }
    else
    {
        self.tedmask = 0;
        self detach( hv_model( "zombie_teddybear" ), "J_Head" );
        self iprintln( "Teddy Mask : [^1Off^7]" );
    }
}

quickmods()
{
    if ( self.quickmods == 0 )
    {
        self.quickmods = 1;
        self thread godmodev4();
        self thread toggleinfiniteammo();
        self thread togglesaveload();
        self iprintlnbold( "Quick Mods : [^2Set^7]" );
    }
    else
        self iprintln( "^1Already Set" );
}

jugman()
{
    if ( self.jugman == 0 )
    {
        self.jugman = 1;
        self setmodel( hv_model( "zombie_vending_jugg" ) );
        self attach( hv_model( "zombie_teddybear" ), "J_Head" );
        self setclientthirdperson( 1 );
        self iprintln( "Juggernog Man : [^2On^7]" );
    }
    else
    {
        self.jugman = 0;
        self setmodel( hv_model( self.originalmodel ) );
        self detach( hv_model( "zombie_teddybear" ), "J_Head" );
        self setclientthirdperson( 0 );
        self iprintln( "Juggernog Man : [^1Off^7]" );
    }
}

domsg( v0 )
{
    v1 = level.players;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3.msg = [];
        v3.msg[v0] = v3 createfontstring( "hudbig", 2.3 );
        v3.msg[v0] setpoint( "CENTER", "", 0, 5 );
        level.result = level.result + 1;
        v3.msg[v0] settext( v0 );
        v3.msg[v0].glowcolor = ( 1, 1, 1 );
        v3.msg[v0].glowalpha = 1;
        level notify( "textset" );
        v3.msg[v0] setcod7decodefx( 50, 99999, 99999 );
        wait 6.5;
        v3.msg[v0] destroy();
    }
}

explosiveman()
{
    if ( self.explosiveman == 0 )
    {
        self.explosiveman = 1;
        self thread explosivem();
        self iprintln( "^1Explosive Man : [^2On^1]" );
    }
    else
    {
        self.explosiveman = 0;
        self notify( "stopexp" );
        self iprintln( "^1Explosive Man : [^1Off]" );
    }
}

explosivem()
{
    self endon( "disconnect" );
    self endon( "game_ended" );
    self endon( "stopexp" );

    while ( self.explosiveman == 1 )
    {
        playfx( level._effect["divetonuke_groundhit"], self gettagorigin( "J_Spine4" ) );
        wait 0.3;
    }
}

startnoclip()
{
    self endon( "disconnect" );
    self enableinvulnerability();
    self disableweapons();
    self iprintln( "No Clip ^2Enabled" );
    self iprintln( "Hold [{+frag}] To Move" );
    self iprintln( "Press [{+melee}] To Exit" );
    v0 = spawn( "script_origin", self.origin );
    v0.angles = self.angles;
    self playerlinkto( v0 );

    for (;;)
    {
        if ( self fragbuttonpressed() )
        {
            v1 = anglestoforward( self getplayerangles() );
            v2 = vectorscale( v1, 25 );
            v3 = self.origin + v2;
            v0.origin = v3;
        }

        if ( self meleebuttonpressed() )
            break;

        wait 0.05;
    }

    v0 delete();
    self enableweapons();
    self iprintln( "No Clip ^1Disabled" );
}

togglephd()
{
    if ( !isdefined( self.flopp ) )
    {
        self.flopp = 1;
        self iprintln( "PHD Flopper ^2Enabled" );
        self thread loopphd();
    }
    else
    {
        self.flopp = undefined;
        self iprintln( "PHD Flopper ^1Disabled" );
        self notify( "stop_phd" );
    }
}

loopphd()
{
    self endon( "disconnect" );
    self endon( "stop_phd" );

    for (;;)
    {
        if ( isdefined( self.divetoprone ) && self.divetoprone )
        {
            if ( self isonground() )
            {
                self explodephd();
                wait 0.3;
            }
        }

        wait 0.05;
    }
}

explodephd()
{
    if ( level.script == "zm_tomb" || level.script == "zm_buried" )
        v0 = level._effect["divetonuke_groundhit"];
    else
        v0 = loadfx( "explosions/fx_default_explosion" );

    self playsound( "zmb_phdflop_explo" );
    playfx( v0, self.origin );
    self damagezombiesinrange( 310, self, "kill" );
}

damagezombiesinrange( v0, v1, v2 )
{
    v3 = getaiarray( level.zombie_team );

    v4 = v3;
    for ( v5 = 0; v5 < v4.size; v5++ )
    {
        v6 = v4[v5];
        if ( distance( v6.origin, v1.origin ) < v0 )
        {
            if ( v2 == "kill" )
            {
                v6 dodamage( v6.health * 2, v6.origin, self );
                continue;
            }

            v6 dodamage( v2, v6.origin, self );
        }
    }
}

spawnsolidsphere()
{
    v0 = spawn( "script_model", self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 150 );
    v0 setmodel( hv_model( "test_sphere_silver" ) );
    v0 = spawn( "script_model", self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 150 );
    v0 setmodel( hv_model( "collision_clip_sphere_64" ) );
}

toggledeathskull()
{
    if ( !isdefined( self.deathskull ) )
    {
        self.deathskull = 1;
        self iprintln( "Death Skull ^2Spawned" );
        self thread deathskull();
    }
    else
    {
        self.deathskull = undefined;
        self iprintln( "Death Skull ^1Deleted" );
        self notify( "stop_death_skull" );
    }
}

deathskull()
{
    self endon( "disconnect" );
    self endon( "stop_death_skull" );

    if ( level.script == "zm_tomb" || level.script == "zm_buried" )
        v0 = level._effect["divetonuke_groundhit"];
    else
        v0 = loadfx( "explosions/fx_default_explosion" );

    v1 = spawnsm( self.origin + ( 0, 0, 40 ), "zombie_skull" );
    playfxontag( loadfx( "misc/fx_zombie_powerup_on" ), v1, "tag_origin" );
    self thread mondskulltoggle( v1 );

    for (;;)
    {
        playfx( v0, v1.origin );
        v1 playsound( "zmb_phdflop_explo" );
        wait 0.1;
        playfx( v0, v1.origin );
        v1 playsound( "zmb_phdflop_explo" );
        wait 0.1;
        v1 moveto( v1.origin + ( 0, 0, 40 ), 1 );
        v1 rotateyaw( 2880, 2 );
        wait 2;
        v1 moveto( v1.origin - ( 0, 0, 40 ), 0.1 );
        v2 = getaiarray( level.zombie_team );

        v3 = v2;
        for ( v4 = 0; v4 < v3.size; v4++ )
        {
            v5 = v3[v4];
            if ( distance( v5.origin, v1.origin ) < 200 )
                v5 dodamage( v5.health + 666, v5.origin );
        }
    }
}

mondskulltoggle( v0 )
{
    self waittill( "stop_death_skull" );
    v0 delete();
}

toggleadvforge()
{
    if ( !isdefined( self.advforge ) )
    {
        self.advforge = 1;
        self iprintln( "Forge Mode ^2Enabled" );
        self iprintln( "Hold [{+speed_throw}] To Move Objects/Players/Zombies" );
        self iprintln( "Hold [{+smoke}]/[{+frag}] To Rotate Objects" );
        self thread advancedforgemode();
    }
    else
    {
        self.advforge = undefined;
        self notify( "stop_adv_forge" );
        self iprintln( "Forge Mode ^1Disabled" );
    }
}

advancedforgemode()
{
    self endon( "disconnect" );
    self endon( "stop_adv_forge" );

    for (;;)
    {
        v0 = bullettrace( self gettagorigin( "j_head" ), self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 1000000, 1, self );

        if ( self adsbuttonpressed() )
        {
            while ( self adsbuttonpressed() )
            {
                v0["entity"] forceteleport( self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 200 );
                v0["entity"] setorigin( self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 200 );
                v0["entity"].origin = self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 200;
                wait 0.01;
            }
        }

        if ( self fragbuttonpressed() )
        {
            while ( self fragbuttonpressed() )
            {
                v0["entity"] rotateyaw( 1, 0.01 );
                wait 0.01;
            }
        }

        if ( self secondaryoffhandbuttonpressed() )
        {
            while ( self secondaryoffhandbuttonpressed() )
            {
                v0["entity"] rotateroll( 1, 0.01 );
                wait 0.01;
            }
        }

        wait 0.05;
    }
}

skytrip()
{
    if ( !isdefined( self.skytrip ) )
    {
        self.skytrip = 1;
        closemenu();
        v0 = self.origin;
        v1 = spawnsm( self.origin, "test_sphere_lambert" );
        self iprintln( "Sky Trip ^2Started" );
        self playerlinkto( v1 );
        v1 moveto( v0 + ( 0, 0, 2500 ), 4 );
        wait 6;
        v1 moveto( v0 + ( 0, 4800, 2500 ), 4 );
        wait 6;
        v1 moveto( v0 + ( 4800, 2800, 2500 ), 4 );
        wait 6;
        v1 moveto( v0 + ( -4800, -2800, 7500 ), 4 );
        wait 6;
        v1 moveto( v0 + ( 0, 0, 2500 ), 4 );
        wait 6;
        v1 moveto( v0 + ( 25, 25, 60 ), 4 );
        wait 4;
        v1 moveto( v0 + ( 0, 0, 20 ), 1 );
        wait 1;
        v1 delete();
        self iprintln( "Sky Trip ^1Finished" );
        self.skytrip = undefined;
    }
    else
        self iprintln( "Wait For The Current ^1Sky Trip^7 To Finish" );
}

togglejetpack()
{
    if ( !isdefined( self.jetpack ) )
    {
        self.jetpack = 1;
        self thread loopjetpack();
        self iprintln( "Jet-Pack ^2Enabled" );
        self iprintln( "Press [{+gostand}] To Use" );
    }
    else
    {
        self.jetpack = undefined;
        self notify( "stop_jetpack" );
        self iprintln( "Jet-Pack ^1Disabled" );
    }
}

loopjetpack()
{
    self endon( "disconnect" );
    self endon( "stop_jetpack" );
    self.jetboots = 100;
    v0 = 0;

    for (;;)
    {
        if ( self jumpbuttonpressed() && self.jetboots > 0 )
        {
            playfx( level._effect["character_fire_death_sm"], self gettagorigin( "J_Ankle_RI" ) );
            playfx( level._effect["character_fire_death_sm"], self gettagorigin( "J_Ankle_LE" ) );
            self.jetboots--;

            if ( self getvelocity()[2] < 300 )
                self setvelocity( self getvelocity() + ( 0, 0, 60 ) );
        }

        if ( self.jetboots < 100 && !self jumpbuttonpressed() )
            self.jetboots++;

        wait 0.05;
        v0++;
    }
}

toggleskull4head()
{
    if ( !isdefined( self.ghosthead ) )
    {
        self.ghosthead = 1;
        self iprintln( "Skull Head ^2Spawned" );
        self attach( hv_model( "zombie_skull" ), "J_Eyeball_LE", 1 );
    }
    else
    {
        self.ghosthead = undefined;
        self iprintln( "Skull Head ^1Deleted" );
        self detach( hv_model( "zombie_skull" ), "J_Eyeball_LE", 1 );
    }
}

valkyriemissiles()
{
    self endon( "disconnect" );

    if ( level.script == "zm_tomb" || level.script == "zm_buried" )
        v0 = level._effect["divetonuke_groundhit"];
    else
        v0 = loadfx( "explosions/fx_default_explosion" );

    closemenu();
    self disableweapons();
    v1 = self.origin;
    v2 = strtok( "15;0;2;30;-15;0;2;30;0;-15;30;2;0;15;30;2;25;0;20;2;-25;0;20;2;0;25;2;20;0;-25;2;20;87;100;26;2;100;87;2;26;-87;100;26;2;100;-87;2;26;87;-100;26;2;-100;87;2;26;-87;-100;26;2;-100;-87;2;26", ";" );
    v3 = [];

    for ( v4 = 0; v4 < v2.size; v4 = v4 + 4 )
        v3[v3.size] = self createshader( "white", "CENTER", "CENTER", int( v2[v4] ), int( v2[v4 + 1] ), int( v2[v4 + 2] ), int( v2[v4 + 3] ), ( 1, 1, 1 ), 1, 1 );

    self iprintln( "Press [{+attack}] To ^2Launch" );
    self iprintln( "Press [{+melee}] To ^1Exit" );
    v5 = 0;

    for (;;)
    {
        if ( self attackbuttonpressed() )
        {
            v5++;
            v6 = spawnsm( self gettagorigin( "j_spine4" ), "zombie_bomb", vectortoangles( lookpos() - ( 0, 0, 70 ) - self gettagorigin( "j_spine4" ) ) );
            v6 setinvisibletoplayer( self );
            self playsound( "zmb_phdflop_explo" );
            self hide();
            self playerlinkto( v6 );

            for (;;)
            {
                v7 = anglestoforward( v6.angles );
                v8 = v6.origin + ( v7[0] * 45, v7[1] * 45, v7[2] * 45 );
                v9 = bullettrace( v6.origin, v8, 0, self );
                v6.angles = vectortoangles( lookpos() - ( 0, 0, 70 ) - v6.origin );
                v6 moveto( v8, 0.05 );
                wait 0.05;

                if ( v9["surfacetype"] != "default" && v9["fraction"] < 1 )
                {
                    v10 = v6.origin;

                    for ( v11 = 0; v11 < 360; v11 = v11 + 80 )
                        playfx( v0, ( v10[0] + 200 * cos( v11 ), v10[1] + 200 * sin( v11 ), v10[2] ) );

                    v12 = getaiarray( level.zombie_team );

                    v13 = v12;
                    for ( v14 = 0; v14 < v13.size; v14++ )
                    {
                        v15 = v13[v14];
                        if ( distance( v15.origin, v6.origin ) < 500 )
                            v15 dodamage( v15.health * 2, v15.origin, self );
                    }

                    v6 playsound( "zmb_phdflop_explo" );
                    v6 delete();
                    break;
                }
            }

            self setorigin( v1 );
        }

        if ( v5 == 2 )
            break;

        if ( self meleebuttonpressed() )
            break;

        wait 0.05;
    }

    for ( v16 = 0; v16 < v3.size; v16++ )
        v3[v16] destroy();

    if ( !isdefined( self.isinvisiblemod ) )
        self show();

    self enableweapons();
    self setorigin( v1 );
}

lookpos()
{
    v0 = self geteye();
    v1 = anglestoforward( self getplayerangles() );
    v2 = ( v1[0] * 100000000, v1[1] * 100000000, v1[2] * 100000000 );
    v3 = bullettrace( v0, v2, 0, self )["position"];
    return v3;
}

togglenukenades()
{
    if ( !isdefined( self.nukenades ) )
    {
        self.nukenades = 1;
        self iprintln( "Nuke Nades ^2Enabled" );
        self thread loopnukenades();
    }
    else
    {
        self.nukenades = undefined;
        self iprintln( "Nuke Nades ^1Disabled" );
        self notify( "stop_nuke_nades" );
    }
}

loopnukenades()
{
    self endon( "disconnect" );
    self endon( "stop_nuke_nades" );
    self setweaponammoclip( "frag_grenade_zm", 4 );

    for (;;)
    {
        self waittill( "grenade_fire", v1, v2 );

        if ( v2 == "frag_grenade_zm" )
        {
            self givemaxammo( "frag_grenade_zm" );
            self setweaponammoclip( "frag_grenade_zm", 4 );
            v1 hide();
            v0 = spawnsm( v1.origin, "zombie_bomb" );
            v0 linkto( v1 );
            v0.angles = v1.angles + ( 0, 0, 40 );
            playfxontag( loadfx( "misc/fx_zombie_powerup_on" ), v0, "tag_origin" );
            playfxontag( level._effect["monkey_glow"], v0, "tag_origin" );
            v1 resetmissiledetonationtime();
            v0 thread processnukenades();
        }
    }
}

processnukenades()
{
    if ( level.script == "zm_tomb" || level.script == "zm_buried" )
        v0 = level._effect["divetonuke_groundhit"];
    else
        v0 = loadfx( "explosions/fx_default_explosion" );

    wait 2;
    playfx( level._effect["lightning_dog_spawn"], self.origin );
    wait 1;
    playsoundatposition( "pre_spawn", self.origin );
    playsoundatposition( "bolt", self.origin );
    wait 0.5;
    playsoundatposition( "nuke_flash", self.origin );
    playfx( v0, self.origin + ( 0, 0, 30 ) );
    playfx( loadfx( "misc/fx_zombie_mini_nuke_hotness" ), self.origin + ( 0, 0, 30 ) );
    playfx( level._effect["powerup_grabbed"], self.origin );
    playfx( level._effect["powerup_grabbed_wave"], self.origin );
    v1 = getaiarray( level.zombie_team );

    v2 = v1;
    for ( v3 = 0; v3 < v2.size; v3++ )
    {
        v4 = v2[v3];
        if ( distance( v4.origin, self.origin ) < 310 )
            v4 dodamage( v4.health * 2, v4.origin );
    }

    self delete();
}

toggleforcefield()
{
    if ( !isdefined( self.force ) )
    {
        self.force = 1;
        self thread loopforcefield();
        self iprintln( "Forcefield ^2Enabled" );
    }
    else
    {
        self.force = undefined;
        self notify( "stop_forcefield" );
        self iprintln( "Forcefield ^1Disabled" );
    }
}

loopforcefield()
{
    self endon( "disconnect" );
    self endon( "stop_forcefield" );
    v0 = spawnsm( self.origin + ( 0, 0, 20 ), "tag_origin", ( 0, 115, 0 ) );
    v0 hide();
    v1 = spawnsm( self.origin + ( 0, 0, 20 ), "tag_origin", ( 0, -115, 0 ) );
    v1 hide();
    self thread monball( v0 );
    self thread monball( v1 );
    self thread monplyr();
    self thread monzomb();
    v2 = spawnsm( v0.origin, "test_sphere_silver" );
    v2 linkto( v0, "tag_origin", ( 0, 150, -50 ), ( 0, 0, 0 ) );
    v3 = spawnsm( v0.origin, "test_sphere_silver" );
    v3 linkto( v1, "tag_origin", ( 0, -150, -50 ), ( 0, 0, 0 ) );
    self thread dod_toggle( v0 );
    self thread dod_toggle( v1 );
    self thread dod_toggle( v2 );
    self thread dod_toggle( v3 );

    for (;;)
    {
        v0 rotateyaw( -360, 2 );
        v1 rotateyaw( 360, 2 );

        for ( v4 = 0; v4 < 10; v4++ )
        {
            playfx( level._effect["powerup_grabbed"], v2.origin );
            wait 0.1;
            playfx( level._effect["powerup_grabbed"], v3.origin );
            wait 0.1;
        }
    }
}

monball( v0 )
{
    self endon( "disconnect" );
    self endon( "stop_forcefield" );

    while ( true )
    {
        v0.origin = self.origin + ( 0, 0, 90 );
        wait 0.01;
    }
}

monplyr()
{
    self endon( "disconnect" );
    self endon( "stop_forcefield" );

    while ( true )
    {
        v0 = level.players;
        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v2 = v0[v1];
            if ( distance( self.origin, v2.origin ) <= 200 )
            {
                v3 = anglestoforward( self getplayerangles() );

                if ( v2 != self )
                    v2 setvelocity( v2 getvelocity() + ( v3[0] * ( 300 * 2 ), v3[1] * ( 300 * 2 ), ( v3[2] + 0.25 ) * ( 300 * 2 ) ) );
            }
        }

        wait 0.01;
    }
}

monzomb()
{
    self endon( "disconnect" );
    self endon( "stop_forcefield" );

    for (;;)
    {
        v0 = getaiarray( level.zombie_team );

        v1 = v0;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            if ( distance( v3.origin, self.origin ) < 200 && !isdefined( v3.gotforceflinged ) )
                v3 forceflingzombie( self );
        }

        wait 0.05;
    }
}

forceflingzombie( v0 )
{
    v1 = anglestoforward( v0 getplayerangles() );
    self.gotforceflinged = 1;
    self dodamage( self.health * 2, self.origin, v0 );
    self startragdoll();
    self launchragdoll( ( v1[0] * 200, v1[1] * 200, 0 ) );
}

dod_toggle( v0 )
{
    self waittill( "stop_forcefield" );
    v0 delete();
}

zmdebug( v0 )
{
    level endon( "stop_debug_zm" );

    for (;;)
    {
        v1 = getaiarray( level.zombie_team );

        v2 = v1;
        for ( v3 = 0; v3 < v2.size; v3++ )
        {
            v4 = v2[v3];
            if ( v4.model != v0 )
                v4 setmodel( hv_model( v0 ) );
        }

        wait 0.05;
    }
}

flyablecar()
{
    self endon( "disconnect" );

    if ( level.script == "zm_tomb" || level.script == "zm_buried" )
        v0 = level._effect["divetonuke_groundhit"];
    else
        v0 = loadfx( "explosions/fx_default_explosion" );

    closemenu();
    v1 = self.origin;
    v2 = [];
    v2["obj"] = spawnsm( self.origin, "defaultvehicle" );
    v2["gun1"] = spawnsm( v2["obj"].origin, "test_sphere_lambert" );
    v2["gun1"] linkto( v2["obj"], "tag_origin", ( 0, 70, 20 ), ( 0, 0, 0 ) );
    v2["gun2"] = spawnsm( v2["obj"].origin, "test_sphere_lambert" );
    v2["gun2"] linkto( v2["obj"], "tag_origin", ( 0, -70, 20 ), ( 0, 0, 0 ) );
    self iprintln( "Flyable Armored Car ^2Spawned" );
    self iprintln( "Press [{+attack}] To Accelerate" );
    self iprintln( "Press [{+smoke}]/[{+frag}] To Shoot" );
    self iprintln( "Press [{+melee}] To Exit" );
    self enableinvulnerability();
    self disableweapons();
    self detachall();
    self hide();
    self setclientthirdperson( 1 );
    self setplayerangles( v2["obj"].angles );
    self playerlinkto( v2["obj"] );
    self thread flyablecarmove( v2["obj"] );

    for (;;)
    {
        if ( self fragbuttonpressed() || self secondaryoffhandbuttonpressed() )
        {
            while ( self fragbuttonpressed() && self secondaryoffhandbuttonpressed() )
                wait 0.05;

            if ( self fragbuttonpressed() )
                self thread spawnlozbullet( "gun", undefined, v2["gun2"].origin, "zombie_bomb", 2000, v0, 3, 2, loadfx( "misc/fx_zombie_powerup_on" ), "once", "zmb_phdflop_explo", "zmb_phdflop_explo", undefined, undefined, undefined, 450, "kill", undefined, undefined );

            if ( self secondaryoffhandbuttonpressed() )
                self thread spawnlozbullet( "gun", undefined, v2["gun1"].origin, "zombie_bomb", 2000, v0, 3, 2, loadfx( "misc/fx_zombie_powerup_on" ), "once", "zmb_phdflop_explo", "zmb_phdflop_explo", undefined, undefined, undefined, 450, "kill", undefined, undefined );

            wait 0.2;
        }

        if ( self meleebuttonpressed() )
        {
            self notify( "stop_flyable_car" );
            break;
        }

        wait 0.05;
    }

    self unlink();
    self enableweapons();

    if ( !isdefined( self.isinvisiblemod ) )
        self show();

    if ( !isdefined( self.t3rd ) )
        self setclientthirdperson( 0 );

    v3 = getarraykeys( v2 );

    v4 = v3;
    for ( v5 = 0; v5 < v4.size; v5++ )
    {
        v6 = v4[v5];
        v2[v6] delete();
    }

    self iprintln( "Flyable Armored Car ^1Deleted" );
    self setorigin( v1 );
}

playeranglestoforward( v0, v1 )
{
    return v0.origin + vectorscale( anglestoforward( v0 getplayerangles() ), v1 );
}

flyablecarmove( v0 )
{
    self endon( "disconnect" );
    self endon( "stop_flyable_car" );
    v1 = 0;

    for (;;)
    {
        v2 = playeranglestoforward( self, 150 + v1 );
        v0 rotateto( self getplayerangles(), 0.25 );

        if ( self attackbuttonpressed() )
        {
            if ( v1 < 0 )
                v1 = 0;

            if ( v1 < 20 )
                v1 = v1 + 0.2;

            v0 moveto( v2, 0.25 );
        }
        else if ( v1 > 0 )
        {
            v1 = v1 - 3;
            v0 moveto( v2, 0.25 );
        }

        wait 0.05;
    }
}

spawnlozbullet( v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18 )
{
    v19 = spawnsm( v2, v3 );

    if ( v0 == "gun" )
        v20 = bullettrace( self geteye(), self geteye() + vectorscale( anglestoforward( self getplayerangles() ), 1000000 ), 1, self )["position"];

    if ( v0 == "ks" )
        v20 = v1;

    v19.angles = vectortoangles( v20 - v19.origin );
    v19 rotateto( vectortoangles( v20 - v19.origin ), 0.05 );

    if ( isdefined( v10 ) )
        self playsound( v10 );

    v21 = calcdistance( v4, v19.origin, v20 );
    v19 moveto( v20, v21 );

    if ( isdefined( v8 ) && isdefined( v9 ) )
        v19 thread traillozbullet( v8, v9 );

    if ( v21 < v6 )
        wait( v21 );
    else
        wait( v7 );

    if ( isdefined( v11 ) )
        v19 playsound( v11 );

    if ( isdefined( v12 ) && isdefined( v13 ) && isdefined( v14 ) )
        earthquake( v12, v13, v19.origin, v14 );

    if ( isdefined( v5 ) )
        playfx( v5, v19.origin + ( 0, 0, 1 ) );

    self damagezombiesinrange( v15, v19, v16 );

    if ( isdefined( v17 ) && isdefined( v18 ) )
    {
        v22 = level.players;
        for ( v23 = 0; v23 < v22.size; v23++ )
        {
            v24 = v22[v23];
            if ( distance( v24.origin, v19.origin ) < v18 )
                v24 playrumbleonentity( v17 );
        }
    }

    v19 delete();
}

traillozbullet( v0, v1 )
{
    if ( v1 == "once" )
        playfxontag( v0, self, "tag_origin" );
    else
    {
        while ( isdefined( self ) )
        {
            playfxontag( v0, self, "tag_origin" );
            wait( v1 );
        }
    }
}

walkingac130()
{
    self endon( "disconnect" );
    closemenu();
    self disableweapons();
    self iprintln( "Walking AC-130 ^2Enabled" );
    self iprintln( "Press [{+attack}] To ^2Shoot" );
    self iprintln( "Press [{+melee}] To ^1Exit" );
    v0 = [];
    v1 = strtok( "21,0,2,24;-20,0,2,24;0,-11,40,2;0,11,40,2;0,-39,2,57;0,39,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2", ";" );

    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = strtok( v1[v2], "," );
        v0[v0.size] = self createshader( "white", "CENTER", "CENTER", int( v3[0] ), int( v3[1] ), int( v3[2] ), int( v3[3] ), ( 1, 1, 1 ), 1, 1 );
    }

    if ( level.script == "zm_tomb" || level.script == "zm_buried" )
        v4 = level._effect["divetonuke_groundhit"];
    else
        v4 = loadfx( "explosions/fx_default_explosion" );

    for (;;)
    {
        if ( self attackbuttonpressed() )
        {
            self thread spawnlozbullet( "gun", undefined, self gettagorigin( "j_spine4" ), "zombie_bomb", 2000, v4, 5, 4, loadfx( "misc/fx_zombie_powerup_on" ), "once", "zmb_phdflop_explo", "zmb_phdflop_explo", undefined, undefined, undefined, 450, "kill", undefined, undefined );
            wait 0.2;
        }

        if ( self meleebuttonpressed() )
            break;

        wait 0.05;
    }

    for ( v5 = 0; v5 < v0.size; v5++ )
        v0[v5] destroy();

    self enableweapons();
    self iprintln( "Walking AC-130 ^1Disabled" );
}

multiplydatvector( v0, v1 )
{
    v0 = ( v0[0] * v1, v0[1] * v1, v0[2] * v1 );
    return v0;
}

spacespherecannon()
{
    self endon( "disconnect" );
    closemenu();
    self disableweapons();
    v0 = self.origin;
    v1 = spawn( "script_model", v0 );
    v1 setmodel( hv_model( "tag_origin" ) );
    v1 thread flyincircle();
    self iprintln( "Space Sphere Cannon ^2Enabled" );
    self iprintln( "Press [{+attack}] To ^2Shoot" );
    self iprintln( "Press [{+melee}] To ^1Exit" );
    v2 = strtok( "0;-70;2;115;0;70;2;115;-70;0;115;2;70;0;115;2;0;-128;14;2;0;128;14;2;-128;0;2;14;128;0;2;14;0;-35;8;2;0;35;8;2;-29;0;2;8;29;0;2;8;-64;0;2;9;64;0;2;9;0;-85;10;2;0;85;10;2;-99;0;2;10;99;0;2;10", ";" );
    v3 = [];

    for ( v4 = 0; v4 < v2.size; v4 = v4 + 4 )
        v3[v3.size] = self createshader( "white", "CENTER", "CENTER", int( v2[v4] ), int( v2[v4 + 1] ), int( v2[v4 + 2] ), int( v2[v4 + 3] ), ( 1, 1, 1 ), 1, 1 );

    if ( level.script == "zm_tomb" || level.script == "zm_buried" )
        v5 = level._effect["divetonuke_groundhit"];
    else
        v5 = loadfx( "explosions/fx_default_explosion" );

    v6 = spawn( "script_model", v1 gettagorigin( "tag_origin" ) );
    v7 = randomint( 360 );
    v8 = randomint( 2000 ) + 2000;
    v9 = cos( v7 ) * v8;
    v10 = sin( v7 ) * v8;
    v11 = vectornormalize( ( v9, v10, 2000 ) );
    v11 = multiplydatvector( v11, 3000 );
    v6 linkto( v1, "tag_origin", v11, ( 0, v7 - 90, 0 ) );
    self playerlinkto( v6 );

    for (;;)
    {
        if ( self attackbuttonpressed() )
        {
            self thread spawnlozbullet( "gun", undefined, self gettagorigin( "j_spine4" ), "test_sphere_lambert", 2000, v5, 6, 5, undefined, undefined, "zmb_phdflop_explo", "zmb_phdflop_explo", undefined, undefined, undefined, 450, "kill", undefined, undefined );
            wait 0.2;
        }

        if ( self meleebuttonpressed() )
            break;

        wait 0.05;
    }

    self unlink();
    v1 delete();
    v6 delete();

    for ( v9 = 0; v9 < v3.size; v9++ )
        v3[v9] destroy();

    self enableweapons();
    self setorigin( v0 );
    self iprintln( "Space Sphere Cannon ^1Disabled" );
}

flyincircle()
{
    while ( isdefined( self ) )
    {
        self rotateyaw( -360, 30 );
        wait 30;
    }
}

dosk8r()
{
    self thread sk8r();
    self iprintln( "^5Ice Skater Spawned!" );
}

sk8r()
{
    v0 = spawn( "script_model", self.origin );
    v0 setmodel( hv_model( "defaultactor" ) );

    for (;;)
    {
        v0 rotateyaw( 9000, 9 );
        v0 moveto( v0.origin + ( 0, -180, 0 ), 1 ); // [PS4 FIX] movey() replaced
        wait 1;
        v0 moveto( v0.origin + ( 0, 180, 0 ), 1 ); // [PS4 FIX] movey() replaced
        wait 1;
        v0 movex( -180, 1 );
        wait 1;
        v0 movex( 180, 1 );
        wait 1;
        v0 movez( 90, 0.5 );
        wait 0.5;
        v0 movez( -90, 0.5 );
        wait 0.5;
        v0 moveto( v0.origin + ( 0, 180, 0 ), 1 ); // [PS4 FIX] movey() replaced
        wait 1;
        v0 moveto( v0.origin + ( 0, -180, 0 ), 1 ); // [PS4 FIX] movey() replaced
        wait 1;
        v0 movex( 180, 1 );
        wait 1;
        v0 movex( -180, 1 );
        wait 1;
    }
}

quake()
{
    self iprintln( "^1Boom Boom Shake The Room!" );
    earthquake( 0.6, 10, self.origin, 100000 );
}

spawnsm( v0, v1, v2 )
{
    v3 = spawn( "script_model", v0 );
    v3 setmodel( hv_model( v1 ) );

    if ( isdefined( v2 ) )
        v3.angles = v2;

    return v3;
}

explodehand()
{
    if ( self.exhand == 0 )
    {
        self.exhand = 1;
        self thread explodehandss();
        self p( "^2Exploding Hands : On" );
    }
    else
    {
        self.exhand = 0;
        self notify( "stopexhands" );
        self p( "^1Exploding Hands : Off" );
    }
}

explodehandss()
{
    self endon( "disconnect" );
    self endon( "game_ended" );
    self endon( "stopexhands" );

    while ( self.exhand == 1 )
    {
        playfx( level._effect["explosions/fx_default_explosion"], self gettagorigin( "j_wrist_le" ) );
        playfx( level._effect["explosions/fx_default_explosion"], self gettagorigin( "j_wrist_ri" ) );
        wait 0.1; // [PS3 PORT] loop had no wait -> "infinite loop" script error freezes the game
    }
}

p( v0 )
{
    iprintln( v0 );
}

calcdistance( v0, v1, v2 )
{
    return distance( v1, v2 ) / v0;
}

toggleshootsemtex()
{
    if ( !isdefined( self.shootsm ) )
    {
        self.shootsm = 1;
        self thread loopshootsemtex();
        self iprintln( "Shoot Semtex ^2Enabled" );
    }
    else
    {
        self.shootsm = undefined;
        self notify( "stop_shoot_semtex" );
        self iprintln( "Shoot Semtex ^1Disabled" );
    }
}

loopshootsemtex()
{
    self endon( "disconnect" );
    self endon( "stop_shoot_semtex" );

    for (;;)
    {
        self waittill( "weapon_fired" );
        v0 = vectornormalize( anglestoforward( self getplayerangles() ) );
        v1 = vectorscale( v0, 5000 );
        self magicgrenadetype( "sticky_grenade_zm", self geteye(), v1, 2 );
    }
}

ghostwalker()
{
    v0 = self get_ahead_ent();
    v1 = undefined;
    v2 = undefined;
    v3 = undefined;
    v4 = undefined;
    v5 = undefined;
    self p( "Press [{+actionslot 3}] to stop" );

    while ( true )
    {
        v0 = self get_ahead_ent();

        if ( isdefined( v0 ) )
        {
            v2 = self get_free_space();

            if ( isdefined( v2 ) )
            {
                v1 = self getgroundzposition( v2 );

                if ( isdefined( v1 ) )
                    v5 = v1[2];
                else
                    v5 = self getorigin()[2];

                v3 = v2[0];
                v4 = v2[1];
                self setorigin( ( v3, v4, v5 ) );
            }

            while ( !self isonground() )
                wait 0.01;

            if ( self actionslotthreebuttonpressed() )
                break;
        }

        wait 0.2;
    }
}

autoreviveself()
{
    if ( self.autorevive == 0 )
    {
        self.autorevive = 1;
        self thread looprevive();
        self p( "^5Auto Revive : [^2On^5]" );
    }
    else
    {
        self.autorevive = 0;
        self notify( "stopautorevive" );
        self p( "^1Auto Revive : [Off]" );
    }
}

looprevive()
{
    self endon( "stopautorevive" );

    while ( self.autorevive == 1 )
    {
        if ( self maps\mp\zombies\_zm_laststand::player_is_in_laststand() )
            self maps\mp\zombies\_zm_laststand::auto_revive( self );

        wait 0.2;
    }
}

get_ahead_ent()
{
    self.ghostvelocity = self getvelocity();

    if ( lengthsquared( self.ghostvelocity ) < 25 )
        return undefined;

    v0 = self geteyeapprox();
    v1 = v0 + self.ghostvelocity * 0.3;
    v2 = ( 0, 1, 0 );
    v3 = ( 0, 1, 0 );
    v4 = physicstrace( v0, v1, vectorscale( ( 0, 1, 0 ), 15 ), vectorscale( ( 0, 1, 0 ), 15 ), self, level.physicstracemaskclip );

    if ( isdefined( v4["entity"] ) )
        return v4["entity"];
    else if ( v4["fraction"] < 0.99 || v4["surfacetype"] != "none" )
        return level;

    return undefined;
}

get_free_space()
{
    v0 = self geteyeapprox();
    v1 = undefined;
    v2 = 2;

    while ( v2 < 50 )
    {
        wait 0.02;
        v1 = v0 + self.ghostvelocity * 0.3;
        v3 = physicstrace( v0, v1, vectorscale( ( 0, 1, 0 ), 15 ), vectorscale( ( 0, 1, 0 ), 15 ), self, level.physicstracemaskclip );

        if ( isdefined( v3["entity"] ) )
        {
            v0 = v1;
            continue;
        }
        else if ( v3["fraction"] < 0.99 || v3["surfacetype"] != "none" )
        {
            v0 = v1;
            continue;
        }

        break;
        v2++;
    }

    if ( v1 != v0 )
        return v1;

    return undefined;
}

_zm_arena_intersection_override( v0 )
{
    self waittill( "forever" );
    return true;
}

player_too_many_players_check()
{

}

getgroundzposition( v0 )
{
    return bullettrace( v0, v0 - ( 0, 0, 10000 ), 0, undefined )["position"];
}

tptotehsky()
{
    self setorigin( self.origin + ( 0, 0, 50 ) );
}

togglesphererain()
{
    if ( level.rainmod == 0 )
    {
        level.rainmod = 1;
        level thread raindeathspheresofdeathlydeath();
        self p( "^1Deadly Raining Spheres : [^2On^1]" );
    }
    else if ( level.rainmod == 1 )
    {
        level.rainmod = 0;
        self p( "^1Deadly Raining Spheres : [OFF]" );
        level notify( "stoptehrain" );
    }
}

raindeathspheresofdeathlydeath()
{
    level endon( "stoptehrain" );

    while ( level.rainmod == 1 )
    {
        v0 = spawn( "script_model", ( self.origin[0] + randomintrange( -1000, 1001 ), self.origin[1] + randomintrange( -1000, 1001 ), self.origin[2] + 2500 ) );
        v0 setmodel( hv_model( "test_sphere_silver" ) );
        v0 thread objectrainthendamage( self );
        wait 0.5;
    }
}

changecost( v0 )
{
    self iprintln( "^5Box Cost Changed To : [" + ( v0 + "]" ) );

    v1 = level.chests;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3.zombie_cost = v0;
    }
}

setalldebriscost( v0 )
{
    v1 = getentarray( "zombie_door", "targetname" );
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3.zombie_cost = v0;
        v3 maps\mp\zombies\_zm_utility::set_hint_string( v3, "default_buy_door", v0 );
    }

    v1 = getentarray( "zombie_airlock_buy", "targetname" );
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3.zombie_cost = v0;
        v3 maps\mp\zombies\_zm_utility::set_hint_string( v3, "default_buy_door", v0 );
    }

    v1 = getentarray( "zombie_debris", "targetname" );
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3.zombie_cost = v0;
        v3 maps\mp\zombies\_zm_utility::set_hint_string( v3, "default_buy_door", v0 );
    }
}

objectrainthendamage( v0 )
{
    self physicslaunch();

    while ( isdefined( self ) && !self isonground() )
        wait 0.1;

    radiusdamage( self getorigin(), 150, 99999, 99999, v0 );

    v1 = level.players;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        if ( v3 != v0 )
            radiusdamage( self getorigin(), 150, 99999, 99999, v3 );
    }

    self delete();
}

changeselfmodel( v0, v1 )
{
    if ( isdefined( self.chaimbot ) || self.aimbot["toggle"] )
        self iprintln( "^1Warning^7 : Disable Aimbot First" );
    else if ( v0 != self.model )
    {
        self.isusingcustommodel = 1;

        if ( !isdefined( self.backupmodel ) )
            self.backupmodel = self.model;

        self setmodel( hv_model( v0 ) );
        self iprintln( "Model Changed To ^2" + v1 );
    }
    else
        self iprintln( "^1Warning^7 : You Already Using This Model" );
}

resetmodel()
{
    if ( isdefined( self.backupmodel ) && self.model != self.backupmodel )
    {
        self setmodel( hv_model( self.backupmodel ) );
        self.isusingcustommodel = undefined;
        self iprintln( "Model ^2Reset" );
    }
    else
        self iprintln( "^1Warning^7 : Model Already Reset" );
}

teletocoords( v0, v1 )
{
    self setorigin( v0 );
    self iprintln( "Teleported To ^2" + v1 );
}

togglebunnyhop()
{
    if ( !isdefined( self.bunnyhop ) )
    {
        self.bunnyhop = 1;
        self thread loopbunnyhop();
        self iprintln( "Bunny Hop Mod ^2Enabled" );
    }
    else
    {
        self.bunnyhop = undefined;
        self notify( "stop_bunny_hop" );
        self iprintln( "Bunny Hop Mod ^1Disabled" );
    }
}

loopbunnyhop()
{
    self endon( "disconnect" );
    self endon( "stop_bunny_hop" );

    for (;;)
    {
        while ( self isonground() && !isdefined( self.revivetrigger ) )
        {
            wait 0.01;
            v0 = self getvelocity();
            self setorigin( self.origin );
            self setvelocity( ( v0[0], v0[1], 999 ) );
            wait 0.01;
        }

        while ( !self isonground() )
            wait 0.05;

        wait 0.05;
    }
}

lozaimbot()
{
    self endon( "disconnect" );
    self endon( "stop_loz_aimbot" );
    self thread monitorunfair();
    self thread monitorautoshoot();

    for (;;)
    {
        if ( !isdefined( self.isinpickweapon ) )
        {
            self.aimbot["victim"] = undefined;
            self.aimbot["canAutoShoot"] = 0;
            v0 = getaiarray( level.zombie_team );

            v1 = v0;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( self.aimbot["visibleCheck"] )
                {
                    if ( bullettracepassed( self geteye(), v3 gettagorigin( self.aimbot["boneTag"] ), 0, self ) )
                    {
                        if ( isdefined( self.aimbot["victim"] ) )
                        {
                            if ( hv_closer( self geteye(), v3 gettagorigin( self.aimbot["boneTag"] ), self.aimbot["victim"] gettagorigin( self.aimbot["boneTag"] ) ) )
                                self.aimbot["victim"] = v3;
                        }
                        else
                            self.aimbot["victim"] = v3;
                    }

                    continue;
                }

                if ( isdefined( self.aimbot["victim"] ) )
                {
                    if ( hv_closer( self geteye(), v3 gettagorigin( self.aimbot["boneTag"] ), self.aimbot["victim"] gettagorigin( self.aimbot["boneTag"] ) ) )
                        self.aimbot["victim"] = v3;

                    continue;
                }

                self.aimbot["victim"] = v3;
            }

            if ( isdefined( self.aimbot["victim"] ) )
            {
                if ( self.aimbot["aimType"] == "not_required" )
                {
                    self.aimbot["canAutoShoot"] = 1;
                    self setplayerangles( vectortoangles( self.aimbot["victim"] gettagorigin( self.aimbot["boneTag"] ) - self geteye() ) );
                }

                if ( self.aimbot["aimType"] == "required" )
                {
                    if ( self adsbuttonpressed() )
                    {
                        self.aimbot["canAutoShoot"] = 1;
                        self setplayerangles( vectortoangles( self.aimbot["victim"] gettagorigin( self.aimbot["boneTag"] ) - self geteye() ) );
                    }
                }
            }
        }

        wait 0.05;
    }
}

toggleunfair()
{
    if ( self.aimbot["toggle"] )
    {
        if ( !self.aimbot["unfair"] )
        {
            self.aimbot["unfair"] = 1;
            self iprintln( "Unfair ^2Enabled" );
        }
        else
        {
            self.aimbot["unfair"] = 0;
            self iprintln( "Unfair ^1Disabled" );
        }
    }
    else
        self iprintln( "^1Warning^7 : Enable Aimbot First" );
}

monitorunfair()
{
    self endon( "disconnect" );
    self endon( "stop_loz_aimbot" );

    for (;;)
    {
        self waittill( "weapon_fired" );

        if ( self.aimbot["unfair"] && self.aimbot["canAutoShoot"] )
            self.aimbot["victim"] dodamage( self.aimbot["victim"].health * 2, self.aimbot["victim"].origin, self );
    }
}

monitorautoshoot()
{
    self endon( "disconnect" );
    self endon( "stop_loz_aimbot" );

    for (;;)
    {
        if ( self.aimbot["autoShoot"] && self.aimbot["canAutoShoot"] )
        {
            v0 = self getcurrentweapon();
            v1 = getweaponindexfromname( v0 );
            v2 = getweaponfiresoundplayer( v1 );
            self playsoundtoplayer( v2, self );
            magicbullet( v0, self gettagorigin( "tag_weapon_right" ) + anglestoforward( self getplayerangles() ) * 75, self.aimbot["victim"] gettagorigin( self.aimbot["boneTag"] ), self );

            if ( self.aimbot["unfair"] )
                self.aimbot["victim"] dodamage( self.aimbot["victim"].health * 2, self.aimbot["victim"].origin, self );

            wait( weaponfiretime( v0 ) );
        }

        wait 0.05;
    }
}

togglelozaimbot()
{
    if ( !self.aimbot["toggle"] )
    {
        if ( isdefined( self.isusingcustommodel ) )
            self iprintln( "^1Warning^7 : Reset Your Model First" );
        else if ( isdefined( self.chaimbot ) )
            self iprintln( "^1Warning^7 : Disable Other Aimbot First" );
        else
        {
            self.aimbot["toggle"] = 1;
            self thread lozaimbot();
            self iprintln( "Aimbot ^2Enabled" );
        }
    }
    else
    {
        self.aimbot["toggle"] = 0;
        self notify( "stop_loz_aimbot" );
        self iprintln( "Aimbot ^1Disabled" );
    }
}

togglebonetag()
{
    if ( self.aimbot["toggle"] )
    {
        if ( self.aimbot["boneTag"] == "j_head" )
            self.aimbot["boneTag"] = "j_spine4";
        else if ( self.aimbot["boneTag"] == "j_spine4" )
            self.aimbot["boneTag"] = "j_mainroot";
        else if ( self.aimbot["boneTag"] == "j_mainroot" )
            self.aimbot["boneTag"] = "j_head";

        self iprintln( "Bone Tag Changed To ^2" + self.aimbot["boneTag"] );
    }
    else
        self iprintln( "^1Warning^7 : Enable Aimbot First" );
}

togglevisiblecheck()
{
    if ( self.aimbot["toggle"] )
    {
        if ( self.aimbot["visibleCheck"] )
        {
            self.aimbot["visibleCheck"] = 0;
            self iprintln( "Visible Check ^1Disabled" );
        }
        else
        {
            self.aimbot["visibleCheck"] = 1;
            self iprintln( "Visible Check ^2Enabled" );
        }
    }
    else
        self iprintln( "^1Warning^7 : Enable Aimbot First" );
}

toggleaimtype()
{
    if ( self.aimbot["toggle"] )
    {
        if ( self.aimbot["aimType"] == "required" )
        {
            self.aimbot["aimType"] = "not_required";
            self iprintln( "Aim Required ^1Disabled" );
        }
        else if ( self.aimbot["aimType"] == "not_required" )
        {
            self.aimbot["aimType"] = "required";
            self iprintln( "Aim Required ^2Enabled" );
        }
    }
    else
        self iprintln( "^1Warning^7 : Enable Aimbot First" );
}

toggleautoshoot()
{
    if ( self.aimbot["toggle"] )
    {
        if ( !self.aimbot["autoShoot"] )
        {
            self.aimbot["autoShoot"] = 1;
            self iprintln( "Auto Shoot ^2Enabled" );
        }
        else
        {
            self.aimbot["autoShoot"] = 0;
            self iprintln( "Auto Shoot ^1Disabled" );
        }
    }
    else
        self iprintln( "^1Warning^7 : Enable Aimbot First" );
}

togglecrosshairaimbot()
{
    if ( !isdefined( self.chaimbot ) )
    {
        if ( isdefined( self.isusingcustommodel ) )
            self iprintln( "^1Warning^7 : Reset Your Model First" );
        else if ( self.aimbot["toggle"] )
            self iprintln( "^1Warning^7 : Disable Other Aimbot First" );
        else
        {
            self.chaimbot = 1;
            self iprintln( "Snipers Crosshair Aimbot ^2Enabled" );
            self thread crosshairaimbot();
        }
    }
    else
    {
        self.chaimbot = undefined;
        self iprintln( "Snipers Crosshair Aimbot ^1Disabled" );
        self notify( "stop_crosshair_aimbot" );
    }
}

crosshairaimbot()
{
    self endon( "disconnect" );
    self endon( "stop_crosshair_aimbot" );

    for (;;)
    {
        v0 = undefined;
        self waittill( "weapon_fired" );

        if ( !self isonground() )
        {
            v1 = getaiarray( level.zombie_team );

            v2 = v1;
            for ( v3 = 0; v3 < v2.size; v3++ )
            {
                v4 = v2[v3];
                if ( isrealistic( v4 ) )
                {
                    if ( isdefined( v0 ) )
                    {
                        if ( hv_closer( self gettagorigin( "j_head" ), v4 gettagorigin( "j_head" ), v0 gettagorigin( "j_head" ) ) )
                            v0 = v4;

                        continue;
                    }

                    v0 = v4;
                }
            }

            if ( isdefined( v0 ) )
            {
                if ( issubstr( self getcurrentweapon(), "dsr50" ) || issubstr( self getcurrentweapon(), "barretm82" ) || ( issubstr( self getcurrentweapon(), "svu" ) || issubstr( self getcurrentweapon(), "ballista" ) ) )
                {
                    v5 = randomint( 10 );

                    if ( v5 == 1 )
                    {
                        v0 dodamage( v0.health * 2, v0.origin, self );
                        v0 maps\mp\zombies\_zm_spawner::zombie_head_gib();
                        magicbullet( self getcurrentweapon(), self gettagorigin( "tag_weapon_right" ) + anglestoforward( self getplayerangles() ) * 75, v0 gettagorigin( "j_head" ), self );
                        playfx( level._effect["zombie_guts_explosion"], v0 gettagorigin( "j_head" ) );
                    }
                    else
                    {
                        v0 dodamage( v0.health * 2, v0.origin, self );
                        magicbullet( self getcurrentweapon(), self gettagorigin( "tag_weapon_right" ) + anglestoforward( self getplayerangles() ) * 75, v0 gettagorigin( "j_spinelower" ), self );
                        playfx( level._effect["zombie_guts_explosion"], v0 gettagorigin( "j_spinelower" ) );
                    }
                }
            }
        }
    }
}

isrealistic( v0 )
{
    v1 = self getplayerangles();
    v2 = vectortoangles( v0 gettagorigin( "j_spinelower" ) - self gettagorigin( "j_spinelower" ) );
    v3 = length( v2 - v1 );

    if ( v3 < 25 )
        return true;
    else
        return false;
}

inithealthbar()
{
    if ( self.hbaron == 0 )
    {
        self.hbaron = 1;
        self iprintln( "Health Bar [^6ON^7]" );
        self thread drawhpbar();
        self thread dohealthbar();
    }
    else
    {
        self.hbaron = 0;
        self iprintln( "Health Bar [^1OFF^7]" );
        self notify( "stop_healthBar" );
        self.healthbar destroyelem();
        self.healthtext destroy();
    }
}

drawhpbar()
{
    self endon( "stop_healthBar" );
    self.healthbar = self createbar( ( 0.08, 0.42, 0.85 ), 150, 11 );
    self.healthbar setpoint( "CENTER", "TOP", 0, 25 );
    self.healthtext = self createfontstring( "default", 1.5 );
    self.healthtext setpoint( "CENTER", "TOP", 0, 5 );
    self.healthtext settext( "^1Health Bar" );
}

dohealthbar()
{
    self endon( "disconnect" );
    self endon( "stop_healthBar" );

    for (;;)
    {
        self.healthbar updatebar( self.health / self.maxhealth );

        if ( self.health == 0 )
        {
            self.healthbar destroyelem();
            self.healthtext destroy();
            self waittill( "spawned_player" );
            self thread drawhpbar();
        }

        wait 0.3;
    }
}

drawbar( v0, v1, v2, v3, v4, v5, v6 )
{
    v7 = createbar( v0, v1, v2, self );
    v7 setpoint( v3, v4, v5, v6 );
    return v7;
}

shesuccme()
{
    if ( level.blowjobzm == 0 && self.bjspawningzm == 0 )
    {
        self.bjspawningzm = 1;
        level.blowjobzm = 1;
        self iprintlnbold( "^5Shoot to spawn in crosshairs!" );
        self waittill( "weapon_fired" );
        v0 = bullettrace( self gettagorigin( "j_head" ), self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 1000000, 0, self )["position"];
        self.bjspawning = 0;
        self doguyb( v0 );
        self dogirlb( v0 );
        level.succgril.angles = ( 0, 180, 0 );
        self endon( "endBlowJob" );
        self iprintlnbold( "^5BlowJob Spawned" );

        for (;;)
        {
            level.succgril rotatepitch( 10, 0.5 );
            wait 0.5;
            level.succgril rotatepitch( -10, 0.5 );
            wait 0.5;
        }
    }
    else
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3 notify( "endBlowJob" );
        }

        level.succguy delete();
        level.succgril delete();
        level.blowjobzm = 0;
    }
}

dogirlb( v0 )
{
    level.succguy = spawn( "script_model", v0 + ( 0, 0, -2 ) );
    level.succguy setmodel( hv_model( "defaultactor" ) );
}

doguyb( v0 )
{
    level.succgril = spawn( "script_model", v0 + ( 15, 0, -32 ) );
    level.succgril setmodel( hv_model( "defaultactor" ) );
}

togglekilltext()
{
    if ( !isdefined( self.killtxt ) )
    {
        self.killtxt = 1;
        self thread loopkilltext();
        self iprintln( "Kill Text ^2Enabled" );
    }
    else
    {
        self.killtxt = undefined;
        self notify( "stop_kill_text" );
        self iprintln( "Kill Text ^1Disabled" );
    }
}

loopkilltext()
{
    self endon( "disconnect" );
    self endon( "stop_kill_text" );
    v0 = [];
    v0[0] = "u Ok?";
    v0[1] = "Aight Aight Aight";
    v0[2] = "Dieee";
    v0[3] = "Lets Go";
    v0[4] = "Wasted";
    v0[5] = "Much Skillz";
    v0[6] = "xXx_420_COD_SCOPE_xXx";
    v0[7] = "shhht";
    v0[8] = "FU Zombie";
    v0[9] = "Owned";
    v0[10] = "Pow Pow Pow";
    v0[11] = "xD";
    v0[12] = "lol";
    v0[13] = "Take This";
    v0[14] = "Im The Best";
    v0[15] = "Hell Yeah";

    for (;;)
    {
        self waittill( "zom_kill" );
        self iprintlnbold( "^2" + v0[randomint( v0.size )] );
    }
}

toggledeathops()
{
    if ( !isdefined( self.viewcam ) )
    {
        self.viewcam = 1;
        self thread loopdeathops();
        self iprintln( "Death Ops Cam ^2Enabled" );
    }
    else
    {
        self.viewcam = undefined;
        self notify( "stop_camera" );
        self setmovespeedscale( 1 );
        self iprintln( "Death Ops Cam ^1Disabled" );
    }
}

loopdeathops()
{
    self endon( "disconnect" );
    self endon( "stop_camera" );
    self setmovespeedscale( 1.2 );
    v0 = spawnsm( self.origin + ( 0, 0, 500 ), "tag_origin" );
    v0.angles = ( 90, 90, 0 );
    self camerasetlookat( v0 );
    self camerasetposition( v0 );
    self cameraactivate( 1 );
    self thread disableontoggle( v0 );
    v1 = 500;

    while ( true )
    {
        v2 = sighttracepassed( self.origin + ( 0, 0, 500 ), self.origin, 0, v0 );

        if ( v2 && v0.origin[2] - ( self.origin[2] < 500 ) )
        {
            v1 = v0.origin[2] - self.origin[2];

            while ( v1 < 500 )
            {
                v1 = v1 + 10;
                v0.origin = self.origin + ( 0, 0, v1 );
                wait 0.01;
            }
        }

        while ( !sighttracepassed( self.origin + ( 0, 0, v1 ), self.origin, 0, v0 ) )
        {
            v1 = v1 - 20;
            v0.origin = self.origin + ( 0, 0, v1 );
            wait 0.01;
        }

        self setplayerangles( self getplayerangles() * ( 0, 1, 0 ) );
        v0.origin = self.origin + ( 0, 0, v1 );
        wait 0.001;
    }
}

disableontoggle( v0 )
{
    self waittill( "stop_camera" );
    self cameraactivate( 0 );
    v0 delete();
}

givetheweapon( v0 )
{
    if ( self getweaponslistprimaries().size > 10 )
        self iprintln( "^1Warning^7 : You Have Too Many Weapons" );
    else if ( self hasweapon( v0 ) )
        self iprintln( "^1Warning^7 : You Already Have " + v0 );
    else
    {
        self giveweapon( v0, 0, self get_pack_a_punch_weapon_options( v0 ) );
        self switchtoweapon( v0 );
        self givemaxammo( v0 );
        self iprintln( v0 + " ^2Given" );
    }
}

newweap( v0 )
{
    v1 = self getcurrentweapon();
    self takeweapon( v1 );
    wait 0.2;
    self giveweapon( v0, 0 );
    self switchtoweapon( v0 );
    self givemaxammo( v0 );
    self p( v0 + " ^2given" );
}

giverayguns()
{
    if ( self hasweapon( "raygun_mark2_upgraded_zm" ) && self hasweapon( "ray_gun_upgraded_zm" ) )
        self iprintln( "^1Warning^7 : You Already Have Both Rayguns" );
    else if ( self hasweapon( "ray_gun_upgraded_zm" ) )
    {
        self giveweapon( "raygun_mark2_upgraded_zm", 0, self get_pack_a_punch_weapon_options( "raygun_mark2_upgraded_zm" ) );
        self switchtoweapon( "raygun_mark2_upgraded_zm" );
        self iprintln( "Raygun Mark 2 ^2Given" );
    }
    else if ( self hasweapon( "raygun_mark2_upgraded_zm" ) )
    {
        self giveweapon( "ray_gun_upgraded_zm", 0, self get_pack_a_punch_weapon_options( "ray_gun_upgraded_zm" ) );
        self switchtoweapon( "ray_gun_upgraded_zm" );
        self iprintln( "Raygun ^2Given" );
    }
    else
    {
        self iprintln( "Both Rayguns ^2Given" );
        v0 = self getcurrentweapon();
        self takeweapon( v0 );
        wait 0.2;
        self giveweapon( "raygun_mark2_upgraded_zm", 0, self get_pack_a_punch_weapon_options( "raygun_mark2_upgraded_zm" ) );
        self giveweapon( "ray_gun_upgraded_zm", 0, self get_pack_a_punch_weapon_options( "ray_gun_upgraded_zm" ) );
        self switchtoweapon( "ray_gun_upgraded_zm" );
    }
}

normalbullets()
{
    self iprintln( "Modded Bullets ^1Disabled" );
    self notify( "stop_bullets" );
}

loopbullets( v0 )
{
    self notify( "stop_bullets" );
    self endon( "disconnect" );
    self endon( "stop_bullets" );
    self iprintln( "Modded Bullets Set To ^2" + v0 );

    for (;;)
    {
        self waittill( "weapon_fired" );

        if ( isdefined( self.moddedbulletsspread ) )
        {
            v1 = lookpos();

            for ( v2 = 0; v2 < 8; v2++ )
            {
                if ( distance( self.origin, v1 ) < 2000 )
                {
                    magicbullet( v0, self gettagorigin( "tag_eye" ), v1 + fakespread( 50 ), self );
                    continue;
                }

                magicbullet( v0, self gettagorigin( "tag_eye" ), self gettagorigin( "tag_eye" ) + anglestoforward( self getplayerangles() ) * 2000 + fakespread( 50 ), self );
            }
        }
        else
            magicbullet( v0, self gettagorigin( "tag_eye" ), lookpos(), self );
    }
}

fakespread( v0 )
{
    v1 = randomintrange( v0 * -1, v0 );
    v2 = randomintrange( v0 * -1, v0 );
    v3 = randomintrange( v0 * -1, v0 );
    return ( v1, v2, v3 );
}

normalbulletsfx()
{
    self iprintln( "Bullets FX ^1Disabled" );
    self notify( "stop_bullets_FX" );
}

loopbulletsfx( v0 )
{
    self notify( "stop_bullets_FX" );
    self endon( "disconnect" );
    self endon( "stop_bullets_FX" );
    self iprintln( "Bullets FX Set To ^2" + v0 );

    for (;;)
    {
        self waittill( "weapon_fired" );
        radiusdamage( lookpos(), 200, 300, 100, self );
        playfx( level._effect[v0], lookpos() );
    }
}

pickrealweapon()
{
    self endon( "disconnect" );
    self.ignoreme = 1;
    closemenu();
    self.isinpickweapon = 1;
    self freezecontrols( 1 );
    self iprintln( "Press [{+speed_throw}]/[{+attack}] To Scroll" );
    self iprintln( "Press [{+reload}] To Select" );
    self iprintln( "Press [{+melee}] To Exit" );
    v0 = [];
    v1 = getarraykeys( level.zombie_weapons_upgraded );

    for ( v2 = 0; v2 < v1.size; v2++ )
        v0[v0.size] = v1[v2];

    v1 = v0;
    v3 = self.origin;
    v4 = array_randomize( v1 );
    self setstance( "stand" );
    self setplayerangles( ( 0, 180, 0 ) );
    v5 = self.angles + ( 0, 90, 0 );
    v6 = [];
    v6[0] = spawnsm( v3 + ( 0, 0, 75 ), getweaponmodel( v4[0] ), v5 );
    v6[1] = spawnsm( v3 + ( 0, 0, 60 ), getweaponmodel( v4[1] ), v5 );
    v6[2] = spawnsm( v3 + ( 0, 0, 40 ), getweaponmodel( v4[2] ), v5 );
    v6[0] movex( -70, 1, 1 );
    v6[1] movex( -70, 1, 1 );
    v6[2] movex( -70, 1, 1 );
    v7 = [];
    v7[0] = v4[0];
    v7[1] = v4[1];
    v7[2] = v4[2];
    wait 1;

    for (;;)
    {
        if ( self adsbuttonpressed() )
        {
            for ( v2 = 0; v2 < v6.size; v2++ )
                v6[v2] hide();

            thread createtempweapon( v6[0].origin, v6[0].origin + ( -50, 0, 0 ), v6[0].model, v5, 0.5, 0.25, 0.25 );
            thread createtempweapon( v6[1].origin, v6[1].origin + ( 0, 0, 15 ), v6[1].model, v5, 0.5, 0.25, 0.25 );
            thread createtempweapon( v6[2].origin, v6[2].origin + ( 0, 0, 20 ), v6[2].model, v5, 0.5, 0.25, 0.25 );

            for (;;)
            {
                v8 = v1[randomint( v1.size )];

                if ( v8 != v7[0] && v8 != v7[1] && v8 != v7[2] )
                    break;

                wait 0.05;
            }

            thread createtempweapon( v3 + ( -70, 0, -5 ), v3 + ( -70, 0, 40 ), getweaponmodel( v8 ), v5, 0.5, 0.25, 0.25 );
            v6[0] setmodel( hv_model( v6[1].model ) );
            v6[1] setmodel( hv_model( v6[2].model ) );
            v6[2] setmodel( hv_model( getweaponmodel( v8 ) ) );
            v7[0] = v7[1];
            v7[1] = v7[2];
            v7[2] = v8;
            wait 0.5;

            for ( v2 = 0; v2 < v6.size; v2++ )
                v6[v2] show();
        }

        if ( self attackbuttonpressed() )
        {
            for ( v2 = 0; v2 < v6.size; v2++ )
                v6[v2] hide();

            thread createtempweapon( v6[0].origin, v6[0].origin + ( 0, 0, -15 ), v6[0].model, v5, 0.5, 0.25, 0.25 );
            thread createtempweapon( v6[1].origin, v6[1].origin + ( 0, 0, -20 ), v6[1].model, v5, 0.5, 0.25, 0.25 );
            thread createtempweapon( v6[2].origin, v6[2].origin + ( -50, 0, 0 ), v6[2].model, v5, 0.5, 0.25, 0.25 );

            for (;;)
            {
                v8 = v1[randomint( v1.size )];

                if ( v8 != v7[0] && v8 != v7[1] && v8 != v7[2] )
                    break;

                wait 0.05;
            }

            thread createtempweapon( v3 + ( -70, 0, 105 ), v3 + ( -70, 0, 75 ), getweaponmodel( v8 ), v5, 0.5, 0.25, 0.25 );
            v6[2] setmodel( hv_model( v6[1].model ) );
            v6[1] setmodel( hv_model( v6[0].model ) );
            v6[0] setmodel( hv_model( getweaponmodel( v8 ) ) );
            v7[2] = v7[1];
            v7[1] = v7[0];
            v7[0] = v8;
            wait 0.5;

            for ( v2 = 0; v2 < v6.size; v2++ )
                v6[v2] show();
        }

        if ( self usebuttonpressed() )
        {
            self playlocalsound( "zmb_cha_ching" );
            v6[1] movex( 60, 1, 1 );
            wait 1;

            for ( v2 = 0; v2 < v6.size; v2++ )
                v6[v2] delete();

            v9 = v7[1];
            self givetheweapon( v9 );
            break;
        }

        if ( self meleebuttonpressed() )
        {
            v6[0] moveto( v6[0].origin + ( 0, 0, -70 ), 0.5, 0.25, 0.25 );
            v6[1] moveto( v6[1].origin + ( 0, 0, -70 ), 0.5, 0.25, 0.25 );
            v6[2] moveto( v6[2].origin + ( 0, 0, -70 ), 0.5, 0.25, 0.25 );
            wait 0.5;

            for ( v2 = 0; v2 < v6.size; v2++ )
                v6[v2] delete();

            break;
        }

        wait 0.01;
    }

    self freezecontrols( 0 );
    self.ignoreme = 0;
    self.isinpickweapon = undefined;
}

createtempweapon( v0, v1, v2, v3, v4, v5, v6 )
{
    v7 = spawnsm( v0, v2, v3 );
    v7 moveto( v1, v4, v5, v6 );
    v7 waittill( "movedone" );
    v7 delete();
}

togglenooverheat()
{
    if ( !isdefined( self.nooverheat ) )
    {
        self.nooverheat = 1;
        self thread loopnooverheat();
        self iprintln( "No Over-Heat ^2Enabled" );
    }
    else
    {
        self.nooverheat = undefined;
        self notify( "stop_no_overheat" );
        self iprintln( "No Over-Heat ^1Disabled" );
    }
}

loopnooverheat()
{
    self endon( "disconnect" );
    self endon( "stop_no_overheat" );

    for (;;)
    {
        if ( issubstr( self getcurrentweapon(), "jetgun" ) || issubstr( self getcurrentweapon(), "slowgun" ) )
            self setweaponoverheating( 0, 0 );

        wait 0.05;
    }
}

enableupgstaffs()
{
    v0 = getarraykeys( level.a_elemental_staffs );

    v1 = v0;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3.charger.charges_received = 999;
        v3.charger.is_inserted = 1;
        v3.charger.full = 1;
    }

    if ( !flag( "staff_air_zm_enabled" ) )
        flag_set( "staff_air_zm_enabled" );

    if ( !flag( "staff_fire_zm_enabled" ) )
        flag_set( "staff_fire_zm_enabled" );

    if ( !flag( "staff_lightning_zm_enabled" ) )
        flag_set( "staff_lightning_zm_enabled" );

    if ( !flag( "staff_water_zm_enabled" ) )
        flag_set( "staff_water_zm_enabled" );

    v4 = getarraykeys( level.a_elemental_staffs_upgraded );

    v1 = v4;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3.charger.charges_received = 9999;
        v3.charger.is_inserted = 1;
        v3.charger.is_charged = 1;
        v3.prev_ammo_clip = weaponclipsize( v3.weapname );
        v3.prev_ammo_stock = weaponmaxammo( v3.weapname );
        v3.charger.full = 1;
    }

    if ( !flag( "staff_air_zm_upgraded_enabled" ) )
        flag_set( "staff_air_zm_upgraded_enabled" );

    if ( !flag( "staff_fire_zm_upgraded_enabled" ) )
        flag_set( "staff_fire_zm_upgraded_enabled" );

    if ( !flag( "staff_lightning_zm_upgraded_enabled" ) )
        flag_set( "staff_lightning_zm_upgraded_enabled" );

    if ( !flag( "staff_water_zm_upgraded_enabled" ) )
        flag_set( "staff_water_zm_upgraded_enabled" );

    level.staffs_charged = 4;
}

giveupgstaffs( v0 )
{
    if ( !isdefined( level.varsarray["firststaffgiven"] ) )
    {
        level.varsarray["firststaffgiven"] = 1;
        level enableupgstaffs();
        wait 0.05;
    }

    if ( self hasweapon( v0 ) )
        self iprintln( "^1Warning^7 : You Already Have " + v0 );
    else
    {
        self giveweapon( v0 );
        self switchtoweapon( v0 );
        self setactionslot( 3, "weapon", "staff_revive_zm" );
        self giveweapon( "staff_revive_zm" );
        self setweaponammostock( "staff_revive_zm", 3 );
        self setweaponammoclip( "staff_revive_zm", 1 );
        self givemaxammo( "staff_revive_zm" );
    }
}

togglesolidspheregun()
{
    if ( !isdefined( self.spheregun ) )
    {
        self.spheregun = 1;
        self iprintln( "Solid Sphere Gun ^2Enabled" );
        self thread solidspheregun();
    }
    else
    {
        self.spheregun = undefined;
        self iprintln( "Solid Sphere Gun ^1Disabled" );
        self notify( "stop_solid_gun" );
    }
}

solidspheregun()
{
    self endon( "disconnect" );
    self endon( "stop_solid_gun" );

    for (;;)
    {
        self waittill( "weapon_fired" );
        self spawnsolidsphere();
        self iprintln( "Solid Sphere ^2Spawned" );
    }
}

teddygun()
{
    if ( self.tedgun == 0 )
    {
        self.tedgun = 1;
        self thread iteddygun();
        self p( "^5Teddy Gun On /n ^1Warning: ^7Creates Overflow" );
    }
    else
    {
        self.tedgun = 0;
        self notify( "stop_ted_gun" );
        self p( "^5Teddy Gun Off" );
    }
}

iteddygun()
{
    self endon( "disconnect" );
    self endon( "game_ended" );
    self endon( "stop_ted_gun" );

    for (;;)
    {
        self waittill( "weapon_fired" );
        self spawnteddy();
    }
}

spawnteddy()
{
    v0 = spawn( "script_model", self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 150 );
    v0 setmodel( hv_model( "zombie_teddybear" ) );
}

togglegrapplegun()
{
    if ( !isdefined( self.grapplegun ) )
    {
        self.grapplegun = 1;
        self thread loopgrapplegun();
        self iprintln( "Grapple Gun ^2Enabled" );
    }
    else
    {
        self.grapplegun = undefined;
        self notify( "stop_grapple_gun" );
        self iprintln( "Grapple Gun ^1Disabled" );
    }
}

loopgrapplegun()
{
    self endon( "disconnect" );
    self endon( "stop_grapple_gun" );

    for (;;)
    {
        self waittill( "weapon_fired" );

        if ( !isdefined( self.skytrip ) )
        {
            v0 = lookpos();
            v1 = spawnsm( self gettagorigin( "tag_weapon_right" ), "tag_origin" );
            v2 = calcdistance( 1000, v1.origin, v0 );
            self playerlinkto( v1 );
            v1 moveto( v0, v2 );
            self thread finishgrapple( v2, v1 );
        }
    }
}

finishgrapple( v0, v1 )
{
    if ( v0 < 3 )
        wait( v0 );
    else
        wait 3;

    v1 delete();
}

toggleflinggun()
{
    if ( !isdefined( self.flinggun ) )
    {
        self.flinggun = 1;
        self thread loopflinggun();
        self iprintln( "Fling Gun ^2Enabled" );
    }
    else
    {
        self.flinggun = undefined;
        self notify( "stop_fling_gun" );
        self iprintln( "Fling Gun ^1Disabled" );
    }
}

loopflinggun()
{
    self endon( "disconnect" );
    self endon( "stop_fling_gun" );

    for (;;)
    {
        self waittill( "weapon_fired" );
        v0 = bullettrace( self gettagorigin( "j_spine4" ), self gettagorigin( "j_spine4" ) + anglestoforward( self getplayerangles() ) * 1000000, 1, self );
        v1 = v0["entity"];

        if ( isdefined( v1.is_zombie ) && v1.is_zombie && ( isalive( v1 ) && !isplayer( v1 ) ) && !isdefined( v1.gotgunflinged ) )
            v1 gunflingzombie( self );
    }
}

gunflingzombie( v0 )
{
    v1 = anglestoforward( v0 getplayerangles() );
    playfxontag( level._effect["monkey_glow"], self, "j_spine4" );
    self.gotgunflinged = 1;
    self dodamage( self.health * 2, self.origin, v0 );
    self startragdoll();
    self launchragdoll( ( v1[0] * 300, v1[1] * 300, 0 ) );
}

togglelamball()
{
    if ( self.lamballgun == 0 )
    {
        self.lamballgun = 1;
        self thread ballgun();
        v0 = self getcurrentweapon();
        self takeweapon( v0 );
        self giveweapon( "dsr50_zm+silencer" );
        self givemaxammo( "dsr50_zm+silencer" );
        self switchtoweapon( "dsr50_zm+silencer" );
        self iprintln( "^7Lambert ^4Ball ^1Gun : ^7[^2On^7]" );
    }
    else
    {
        self.lamballgun = 0;
        self notify( "stopBallGunV2" );
        self iprintln( "^7Lambert ^4Ball ^1Gun : ^7[^2On^7]" );
    }
}

ballgun()
{
    self endon( "stopBallGunV2" );

    for (;;)
    {
        self waittill( "weapon_fired" );

        if ( self hasweapon( "dsr50_zm+silencer" ) )
            self thread spawnlambertball();

        wait 0.2;
    }
}

spawnlambertball()
{
    v0 = spawn( "script_model", self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 150 );
    v0 setmodel( hv_model( "test_sphere_lambert" ) );
    v1 = spawn( "script_model", self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 150 );
    v1 setmodel( hv_model( "collision_clip_sphere_64" ) );
    v0 thread sysdelete();
    v1 thread sysdelete();
}

sysdelete()
{
    wait 7.5;
    self delete();
}

whiteballfeet()
{
    if ( self.whball == 0 )
    {
        self.whball = 1;
        self attach( hv_model( "test_sphere_lambert" ), "J_Ankle_RI" );
        self attach( hv_model( "test_sphere_lambert" ), "J_Ankle_LE" );
        self setclientthirdperson( 1 );
        self iprintln( "^7White Ball Feet : [^2On^7]" );
    }
    else
    {
        self.whball = 0;
        self detach( hv_model( "test_sphere_lambert" ), "J_Ankle_RI" );
        self detach( hv_model( "test_sphere_lambert" ), "J_Ankle_LE" );
        self setclientthirdperson( 0 );
        self iprintln( "^7White Ball Feet : [^1OFF^7]" );
    }
}

givethepowerup( v0 )
{
    self iprintln( v0 + " ^2Given" );
    level thread maps\mp\zombies\_zm_powerups::specific_powerup_drop( v0, self.origin );
}

gravity()
{
    if ( self.grav == 0 )
    {
        self.grav = 1;
        setdvar( "bg_gravity", "100" );
        self p( "^2Gravity is Low : On" );
    }
    else
    {
        self.grav = 0;
        setdvar( "bg_gravity", "800" );
        self p( "^1Gravity is Low : Off" );
    }
}

togglesuperspeed()
{
    if ( getdvar( "g_speed" ) != "400" )
    {
        setdvar( "g_speed", "400" );
        iprintln( "Super Speed ^2Enabled" );
    }
    else
    {
        setdvar( "g_speed", "200" );
        iprintln( "Super Speed ^1Disabled" );
    }
}

togglesuperjump()
{
    if ( !isdefined( level.superjump ) )
    {
        level.superjump = 1;

        v0 = level.players;
        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v2 = v0[v1];
            v2 thread superjump();
        }

        iprintln( "Super Jump ^2Enabled" );
    }
    else
    {
        level.superjump = undefined;

        v0 = level.players;
        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v2 = v0[v1];
            v2 notify( "stop_sj" );
        }

        iprintln( "Super Jump ^1Disabled" );
    }
}

superjump()
{
    self endon( "disconnect" );
    self endon( "stop_sj" );
    v0 = 0;

    for (;;)
    {
        while ( self isonground() && !v0 && !isdefined( self.revivetrigger ) )
        {
            wait 0.05;

            if ( self jumpbuttonpressed() )
            {
                v0 = 1;

                if ( self isonground() )
                    self setorigin( self.origin );

                for ( v1 = 0; v1 < 10; v1++ )
                {
                    self setvelocity( self getvelocity() + ( 0, 0, 999 ) );
                    wait 0.05;
                }

                v0 = 0;
            }
        }

        wait 0.05;
    }
}

toggleknockback()
{
    if ( level.knockb == 0 )
    {
        level.knockb = 1;
        setdvar( "g_knockback", "9999" );
        self iprintln( "Knock Back Lobby On" );
    }
    else
    {
        level.knockb = 0;
        setdvar( "g_knockback", "1" );
        self iprintln( "Knock Back Lobby Off" );
    }
}

openalldoors()
{
    if ( !isdefined( level.varsarray["doors"] ) )
    {
        level.varsarray["doors"] = 1;
        iprintln( "All Doors Are ^2Open" );
        setdvar( "zombie_unlock_all", 1 );
        wait 0.05;
        v0 = strtok( "zombie_doors|zombie_door|zombie_airlock_buy|zombie_debris|flag_blocker|window_shutter|zombie_trap", "|" );

        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v2 = getentarray( v0[v1], "targetname" );

            for ( v3 = 0; v3 < v2.size; v3++ )
                v2[v3] notify( "trigger" );
        }

        wait 0.05;
        setdvar( "zombie_unlock_all", 0 );
    }
    else
        self iprintln( "^1Warning^7 : Doors Already Open" );
}

restartgame()
{
    self iprintlnbold( "^1Restarting Map..." );
    wait 0.6;
    map_restart( 0 );
}

reloadmap()
{
    map_restart( 1 );
}

turnonpower()
{
    if ( !flag( "power_on" ) )
    {
        iprintln( "Power ^2Enabled" );
        v0 = getent( "use_elec_switch", "targetname" );
        v1 = getent( "elec_switch", "targetname" );
        v1 notsolid();
        v0 sethintstring( &"ZOMBIE_ELECTRIC_SWITCH" );
        v0 setvisibletoall();
        v0 notify( "trigger", self );
        v0 setinvisibletoall();
        v1 rotateroll( -90, 0, 3 );
        v1 playsound( "zmb_switch_flip" );
        v1 playsound( "zmb_poweron" );
        level thread maps\mp\zombies\_zm_perks::perk_unpause_all_perks();
        v1 waittill( "rotatedone" );
        playfx( level._effect["switch_sparks"], v1.origin + ( 0, 12, -60 ), anglestoforward( v1.angles ) );
        v1 playsound( "zmb_turn_on" );
        level notify( "electric_door" );
        flag_set( "power_on" );
        level setclientfield( "zombie_power_on", 1 );
    }
    else
        self iprintln( "^1Warning^7 : Power Already Enabled" );
}

drawzombiescounter()
{
    level.zombiescountdisplay = createserverfontstring( "Objective", 1.7 );
    level.zombiescountdisplay setpoint( "RIGHT", "CENTER", 315, 0 ); // [PS3 PORT] y offset was the string "CENTER"
    thread updatezombiescounter();
}

updatezombiescounter()
{
    level endon( "stopUpdatingZombiesCounter" );

    while ( true )
    {
        v0 = get_current_zombie_count();
        if ( isdefined( level.zombiescountdisplay ) ) // [PS3 PORT] init() starts this before the HUD exists
            level.zombiescountdisplay setsafetext( "Zombies: " + v0 );
        waitforzombiecountchanged( "stopUpdatingZombiesCounter" );
    }
}

recreatezombiescounter()
{
    level notify( "stopUpdatingZombiesCounter" );
    thread updatezombiescounter();
}

waitforzombiecountchanged( v0 )
{
    level endon( v0 );
    v1 = get_current_zombie_count();

    while ( true )
    {
        v2 = get_current_zombie_count();

        if ( v1 != v2 )
            return;

        wait 0.05;
    }
}

increasezombieslimit()
{
    level.zombie_ai_limit = 9999;
    level.zombie_actor_limit = 9999;
}

fr3zzzom()
{
    if ( self.fr3zzzom == 0 )
    {
        self iprintln( "Freeze Zombies [^2ON^7]" );
        setdvar( "g_ai", "0" );
        self.fr3zzzom = 1;
    }
    else
    {
        self iprintln( "Freeze Zombies [^1OFF^7]" );
        setdvar( "g_ai", "1" );
        self.fr3zzzom = 0;
    }
}

antiquit()
{
    self endon( "disconnect" );
    self endon( "disableAntiQuit" );

    if ( self ishost() )
    {
        level.antiquit = booleanopposite( level.antiquit );
        self iprintln( booleanreturnval( level.antiquit, "Anti Quit ^4OFF", "Anti Quit ^5ON" ) );

        if ( level.antiquit )
        {
            for (;;)
            {
                v0 = level.players;
                for ( v1 = 0; v1 < v0.size; v1++ )
                {
                    v2 = v0[v1];
                    v2 maps\mp\gametypes_zm\_globallogic_ui::closemenus();
                }

                wait 0.05; // [PS3 PORT] one server frame; 0.02 only added script load
            }
        }
        else
            self notify( "disableAntiQuit" );
    }
    else
        self iprintln( "^1You must be ^2Host ^1to do that" );
}

toggleantijoin()
{
    // [PS3 PORT] g_password is not used by PSN matchmaking; this probably does nothing on PS3
    if ( level.antijoin == 1 )
    {
        setdvar( "g_password", "DISECTIONERRORCANNOTJOIN" );
        iprintln( "Anti-Join ^2ON" );
        level.antijoin = 0;
    }
    else
    {
        setdvar( "g_password", "" ); // [PS3 PORT] original created a dvar called "reset" instead of clearing the password
        iprintln( "Anti-Join ^2OFF" );
        level.antijoin = 1;
    }
}

spintext()
{
    self endon( "disconnect" );
    self endon( "stop_spinText" );
    self thread changespintextcolor();
    self.showspintext = self createfontstring( "default", 3 );
    v0 = 0;
    v1 = 0;
    v2 = 100;
    v3 = 0;
    level notify( "textset" );
    level.result = level.result + 1;

    while ( true )
    {
        v4 = v0 + sin( v3 ) * v2;
        v5 = v1 + cos( v3 ) * v2;
        self.showspintext setpoint( "CENTER", "CENTER", v4, v5 );
        self.showspintext settext( "^5Disection V2 <3" );
        self.showspintext.color = ( 0.26, 0.6, 0.87 );
        self.showspintext.glowcolor = ( 0.12, 0.9, 0.44 );
        wait 0.01;
        v3++;
    }
}

changespintextcolor()
{
    self endon( "disconnect" );
    self endon( "stop_spinText" );

    while ( true )
    {
        self.showspintext.glowalpha = 1;
        self.showspintext.glowcolor = ( randomint( 255 ) / 255, randomint( 255 ) / 255, randomint( 255 ) / 255 );
        self.showspintext setpulsefx( 40, 2000, 600 );
        wait 1;
    }
}

spintextinit()
{
    v0 = level.players;
    for ( v1 = 0; v1 < v0.size; v1++ )
    {
        v2 = v0[v1];
        v2 thread spintext();
    }
}

initspintext()
{
    if ( !isdefined( self.isspinning ) )
    {
        self.isspinning = 1;
        self thread spintextinit();
        self iprintln( "Spin Text ^5ON" );
    }
    else
    {
        self.isspinning = undefined;
        self notify( "stop_spinText" );
        self.showspintext destroy();
        self.showspintext destroyelem();
        self iprintln( "Spin Text ^4OFF" );
    }
}

pause()
{
    level thread maps\mp\gametypes_zm\_hostmigration::callback_hostmigration();
}

toggledeathbarriers()
{
    if ( !level.death_barrier )
    {
        self iprintln( "Death Barriers ^1Removed!" );
        v0 = getentarray( "trigger_hurt", "classname" );

        v1 = v0;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3.origin = v3.origin + ( 0, 0, 9999999 );
        }

        level.death_barrier = 1;
    }
    else
    {
        self iprintln( "Death Barriers ^2Added!" );
        v0 = getentarray( "trigger_hurt", "classname" );

        v1 = v0;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3.origin = v3.origin - ( 0, 0, 9999999 );
        }

        level.death_barrier = 0;
    }
}

hearall()
{
    if ( !isdefined( level.varsarray["lisother"] ) )
    {
        level.varsarray["lisother"] = 1;
        iprintln( "Hear All Players ^2Enabled" );
        setmatchtalkflag( "EveryoneHearsEveryone", 1 );
    }
    else
    {
        level.varsarray["lisother"] = undefined;
        iprintln( "Hear All Players ^1Disabled" );
        setmatchtalkflag( "EveryoneHearsEveryone", 0 );
    }
}

changetimescale()
{
    level.varsarray["currentTimescale"] = level.varsarray["currentTimescale"] + 1;

    if ( level.varsarray["currentTimescale"] == 1 )
    {
        setdvar( "timescale", "1" );
        iprintln( "Timescale Set To ^2Normal" );
    }

    if ( level.varsarray["currentTimescale"] == 2 )
    {
        setdvar( "timescale", "1.5" );
        iprintln( "Timescale Set To ^3Fast" );
    }

    if ( level.varsarray["currentTimescale"] == 3 )
    {
        setdvar( "timescale", "1.7" );
        iprintln( "Timescale Set To ^1Very Fast" );
    }

    if ( level.varsarray["currentTimescale"] == 4 )
    {
        setdvar( "timescale", "0.5" );
        iprintln( "Timescale Set To ^3Slow" );
    }

    if ( level.varsarray["currentTimescale"] == 5 )
    {
        setdvar( "timescale", "0.3" );
        iprintln( "Timescale Set To ^1Very Slow" );
    }

    if ( level.varsarray["currentTimescale"] == 5 )
        level.varsarray["currentTimescale"] = 0;
}

roundslider()
{
    self endon( "disconnect" );
    closemenu();
    self freezecontrols( 1 );

    if ( level.round_number > 250 )
        v0 = 250;
    else
        v0 = level.round_number;

    v1 = 250;
    v2 = 1;
    v3 = 1;
    self iprintln( "Press [{+attack}]/[{+speed_throw}] To Decrease/Increase Value" );
    self iprintln( "Press [{+usereload}] To Confirm" );
    self iprintln( "Press [{+melee}] To Exit" );
    v4 = drawvalue( v0, "objective", 3, "CENTER", "CENTER", 0, 0, ( 1, 1, 1 ), 1, 0, 3 );
    v5 = self createshader( "white", "CENTER", "CENTER", 0, 0, 50, 40, ( 0, 0, 0 ), 0.8, 0 );
    wait 0.3;

    for (;;)
    {
        while ( self attackbuttonpressed() && self adsbuttonpressed() )
            wait 0.05;

        if ( self attackbuttonpressed() && v0 < v1 )
            v0 = v0 + v2;
        else if ( self adsbuttonpressed() && v0 > v3 )
            v0 = v0 - v2;
        else if ( self adsbuttonpressed() && v0 == v3 )
            v0 = v1;
        else if ( self attackbuttonpressed() && v0 == v1 )
            v0 = v3;
        else if ( self usebuttonpressed() )
        {
            level.round_number = v0;
            level.zombie_total = 0;
            level thread maps\mp\zombies\_zm_powerups::specific_powerup_drop( "nuke", self.origin );
            iprintln( "Round Set To ^2" + v0 );
            break;
        }
        else if ( self meleebuttonpressed() )
            break;

        v4 setvalue( v0 );
        wait 0.05;
    }

    v4 destroy();
    v5 destroy();
    self freezecontrols( 0 );
}

callzombieboss()
{
    if ( !isdefined( level.varsarray["spawnedBoss"] ) )
    {
        v0 = getaiarray( level.zombie_team );

        if ( v0.size > 1 )
            self thread startzombieboss();
        else
            self iprintln( "^1Warning^7 : No Zombies Alive" );
    }
    else
        self iprintln( "^1Warning^7 : Zombie Boss Already Spawned" );
}

startzombieboss()
{
    level.varsarray["spawnedBoss"] = 1;
    iprintln( "Zombie Boss ^2Spawned" );
    v0 = getaiarray( level.zombie_team );
    v0[0].health = 100000;
    v0[0] attach( hv_model( "zombie_skull" ), "J_Eyeball_LE", 1 );
    v0[0] attach( hv_model( "zombie_ammocan" ), "J_Wrist_LE", 1 );
    v0[0] attach( hv_model( "zombie_ammocan" ), "J_Wrist_RI", 1 );
    v0[0] maps\mp\zombies\_zm_utility::set_zombie_run_cycle( "sprint" );
    playfxontag( loadfx( "misc/fx_zombie_powerup_on" ), v0[0], "j_head" );
    playfxontag( loadfx( "misc/fx_zombie_powerup_on" ), v0[0], "J_Wrist_LE" );
    playfxontag( loadfx( "misc/fx_zombie_powerup_on" ), v0[0], "J_Wrist_RI" );

    while ( isdefined( v0[0] ) )
    {
        v1 = getaiarray( level.zombie_team );

        for ( v2 = 1; v2 <= v1.size; v2++ )
            v1[v2] delete();

        if ( v0[0].health < 1 )
        {
            v0[0] detachall();
            level.zombie_vars["zombie_drop_item"] = 1;
            level.powerup_drop_count = 0;
            level maps\mp\zombies\_zm_powerups::powerup_drop( v0[0].origin );
            break;
        }

        wait 0.05;
    }

    iprintln( "Zombie Boss ^1Finished" );
    level.varsarray["spawnedBoss"] = undefined;
}

togglerapidfire()
{
    if ( !isdefined( level.varsarray["rfire"] ) )
    {
        level.varsarray["rfire"] = 1;
        setdvar( "perk_weapRateMultiplier", "0.001" );
        setdvar( "perk_weapReloadMultiplier", "0.001" );
        setdvar( "perk_fireproof", "0.001" );
        setdvar( "cg_weaponSimulateFireAnims", "0.001" );

        v0 = level.players;
        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v2 = v0[v1];
            v2 setperk( "specialty_rof" );
            v2 setperk( "specialty_fastreload" );
        }

        iprintln( "Rapid Fire ^2Enabled" );
    }
    else
    {
        level.varsarray["rfire"] = undefined;
        setdvar( "perk_weapRateMultiplier", "1" );
        setdvar( "perk_weapReloadMultiplier", "1" );
        setdvar( "perk_fireproof", "1" );
        setdvar( "cg_weaponSimulateFireAnims", "1" );

        v0 = level.players;
        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v2 = v0[v1];
            v2 unsetperk( "specialty_rof" );
            v2 unsetperk( "specialty_fastreload" );
        }

        iprintln( "Rapid Fire ^1Disabled" );
    }
}

findorigins()
{
    if ( !( self.fangl == 1 ) )
    {
        if ( self.forig == 0 )
        {
            self.forig = 1;
            self thread findor();
        }
        else
        {
            self.forig = 0;
            self notify( "stoporig" );
        }
    }
    else
        self iprintln( "^1Warning: ^7Turn off Angles Finder" );
}

findor()
{
    self endon( "stoporig" );

    while ( self.forig == 1 )
    {
        self iprintln( self.origin );
        wait 0.3;
    }
}

findan()
{
    self endon( "stopangl" );

    while ( self.fangl == 1 )
    {
        self iprintln( self.angles );
        wait 0.3;
    }
}

findangles()
{
    if ( !( self.forig == 1 ) )
    {
        if ( self.fangl == 0 )
        {
            self.fangl = 1;
            self thread findan();
        }
        else
        {
            self.fangl = 0;
            self notify( "stopangl" );
        }
    }
    else
        self iprintln( "^1Warning: ^7Turn off Origins Finder" );
}

playzombiesanimation( v0, v1 )
{
    if ( !level.varsarray["zombiesanim"] )
    {
        level.varsarray["zombiesanim"] = 1;
        level endon( "restore_zombies_anim" );
        self iprintln( "Zombies Playing Animation ^2" + v1 );

        for (;;)
        {
            v2 = getaiarray( level.zombie_team );

            v3 = v2;
            for ( v4 = 0; v4 < v3.size; v4++ )
            {
                v5 = v3[v4];
                v5 thread savethenexecuteanim( v0 );
            }

            wait 0.05;
        }
    }
    else
        self iprintln( "^1Warning^7 : Restore Animation First" );
}

savethenexecuteanim( v0 )
{
    if ( !isdefined( self.isdoinganim ) )
    {
        self.isdoinganim = 1;

        if ( !isdefined( self.savedanim ) )
            self.savedanim = self getanimstatefromasd();

        self setanimstatefromasd( v0 );
        v1 = self getanimlengthfromasd( v0, 0 );
        wait( v1 );
        self.isdoinganim = undefined;
    }
}

stopzombiesanimation()
{
    if ( !level.varsarray["zombiesanim"] )
        self iprintln( "^1Warning^7 : No Animations To Restore" );
    else
    {
        self iprintln( "Zombies Animation ^2Restored" );
        level notify( "restore_zombies_anim" );
        v0 = getaiarray( level.zombie_team );

        v1 = v0;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3 thread restoreanim();
        }

        level.varsarray["zombiesanim"] = 0;
    }
}

restoreanim()
{
    if ( isdefined( self.savedanim ) )
        self setanimstatefromasd( self.savedanim );
}

killallzombies()
{
    self iprintln( "All Zombies ^2Killed" );
    v0 = getaiarray( level.zombie_team );

    v1 = v0;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3 dodamage( v3.health * 2, v3.origin );
    }
}

toggledroppers()
{
    if ( !isdefined( level.varsarray["droppers"] ) )
    {
        level.varsarray["droppers"] = 1;
        self iprintln( "Force Powerup On Death ^2Enabled" );
        level thread droppowerupondeath();
    }
    else
    {
        level.varsarray["droppers"] = undefined;
        level notify( "stop_droppers" );
        self iprintln( "Force Powerup On Death ^1Disabled" );
    }
}

droppowerupondeath()
{
    level endon( "stop_droppers" );

    for (;;)
    {
        v0 = getaiarray( level.zombie_team );

        v1 = v0;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            if ( !v3.isdropper )
                v3 thread waitfordrop();
        }

        wait 0.05;
    }
}

waitfordrop()
{
    self.isdropper = 1;
    self waittill( "death" );
    level.zombie_vars["zombie_drop_item"] = 1;
    level.powerup_drop_count = 0;
    level thread maps\mp\zombies\_zm_powerups::powerup_drop( self.origin );
}

detachnohead()
{
    self iprintln( "All Zombies Head's ^2Detached" );
    v0 = getaiarray( level.zombie_team );

    v1 = v0;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3 detachall();
    }
}

telezombiestome()
{
    self iprintln( "All Zombies ^2Teleported" );
    v0 = getaiarray( level.zombie_team );

    v1 = v0;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        v3 forceteleport( self.origin );
        v3 maps\mp\zombies\_zm_spawner::reset_attack_spot();
    }
}

togglezombiedisable()
{
    if ( !isdefined( level.varsarray["diszm"] ) )
    {
        level.varsarray["diszm"] = 1;
        flag_init( "spawn_zombies", 0 );
        iprintln( "Disable Zombies ^2Enabled" );
    }
    else
    {
        level.varsarray["diszm"] = undefined;
        flag_init( "spawn_zombies", 1 );
        iprintln( "Disable Zombies ^1Disabled" );
    }

    level.zombie_total = 0;
    level thread maps\mp\zombies\_zm_powerups::specific_powerup_drop( "nuke", self.origin );
}

togglezombielowhealth()
{
    if ( !isdefined( level.varsarray["zminv"] ) )
    {
        level.varsarray["zminv"] = 1;
        iprintln( "Low Health Zombies ^2Enabled" );
        level thread zmhp();
    }
    else
    {
        level.varsarray["zminv"] = undefined;
        iprintln( "Low Health Zombies ^1Disabled" );
        level notify( "stop_hp_zm" );
    }
}

zmhp()
{
    level endon( "stop_hp_zm" );

    for (;;)
    {
        v0 = getaiarray( level.zombie_team );

        v1 = v0;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3.maxhealth = 1;
            v3.health = v3.maxhealth;
        }

        wait 0.05;
    }
}

makecrawlers()
{
    iprintln( "Zombies Are Now ^2Crawlers" );
    v0 = getaiarray( level.zombie_team );

    v1 = v0;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        if ( !v3.forcedcrawler )
            v3 thread execcrawlers();
    }
}

execcrawlers()
{
    self.forcedcrawler = 1;
    self.force_gib = 1;
    self.a.gib_ref = "no_legs";
    self.has_legs = 0;
    self allowedstances( "crouch" );
    self.deathanim = self maps\mp\animscripts\zm_utility::append_missing_legs_suffix( "zm_death" );
    self.run_combatanim = level.scr_anim["zombie"]["crawl1"];
    self thread maps\mp\animscripts\zm_run::needsupdate();
    self thread maps\mp\animscripts\zm_death::do_gib();
}

changezombiesrunanim( v0, v1 )
{
    iprintln( "Zombies Speed Changed To ^2" + v1 );
    v2 = getaiarray( level.zombie_team );

    v3 = v2;
    for ( v4 = 0; v4 < v3.size; v4++ )
    {
        v5 = v3[v4];
        v5 maps\mp\zombies\_zm_utility::set_zombie_run_cycle( v0 );
    }
}

togglehitmarkers()
{
    if ( !isdefined( self.hitmarkers ) )
    {
        self.hitmarkers = 1;
        self iprintln( "Friendly Fire ^2Enabled" );
        setdvar( "g_friendlyfireDist", "0" );
        self thread loopfirehitmarkers();
        self thread loopmeleehitmarkers();
    }
    else
    {
        self.hitmarkers = undefined;
        setdvar( "g_friendlyfireDist", "999" );
        self iprintln( "Friendly Fire ^1Disabled" );
        self notify( "stop_hitmarkers" );
    }
}

loopfirehitmarkers()
{
    self endon( "disconnect" );
    self endon( "stop_hitmarkers" );

    for (;;)
    {
        self waittill( "weapon_fired" );
        v0 = bullettrace( self gettagorigin( "j_head" ), self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 1000000, 1, self );
        v1 = v0["entity"];

        if ( isalive( v1 ) )
        {
            self thread createhitmarker();
            v1 dodamage( 20, self.origin, self );
        }
    }
}

loopmeleehitmarkers()
{
    self endon( "disconnect" );
    self endon( "stop_hitmarkers" );

    for (;;)
    {
        v0 = bullettrace( self gettagorigin( "j_head" ), self gettagorigin( "j_head" ) + anglestoforward( self getplayerangles() ) * 50, 1, self );
        v1 = v0["entity"];

        if ( self ismeleeing() && isalive( v1 ) )
        {
            self thread createhitmarker();
            v1 dodamage( 50, self.origin, self );
            wait 0.8;
        }

        wait 0.01;
    }
}

createhitmarker( v0 )
{
    if ( isdefined( v0 ) )
        v1 = self drawhitmarker( v0 );
    else
        v1 = self drawhitmarker();

    v1 fadeovertime( 1 );
    v1.alpha = 0;
    wait 1;
    v1 destroy();
}

drawhitmarker( v0 )
{
    v1 = newdamageindicatorhudelem( self );
    v1.horzalign = "center";
    v1.vertalign = "middle";
    v1.x = -12;
    v1.y = -12;

    if ( isdefined( v0 ) )
        v1.color = v0;

    v1.alpha = 1;
    v1.children = [];
    v1 setshader( hv_shader( "damage_feedback" ), 24, 48 );
    return v1;
}

forcehost()
{
    // [PS3 PORT] party_* dvars exist on PS3; only matters while you are in the pre-game lobby
    if ( getdvar( "party_connectToOthers" ) != "0" || getdvar( "partyMigrate_disabled" ) != "1" || getdvar( "party_mergingEnabled" ) != "0" )
    {
        setdvar( "party_connectToOthers", "0" );
        setdvar( "partyMigrate_disabled", "1" );
        setdvar( "party_mergingEnabled", "0" );
        self iprintln( "Force Host ^2Enabled" );
    }
    else
    {
        setdvar( "party_connectToOthers", "1" );
        setdvar( "partyMigrate_disabled", "0" );
        setdvar( "party_mergingEnabled", "1" );
        self iprintln( "Force Host ^1Disabled" );
    }
}

togglefps()
{
    // [PS3 PORT] cg_drawFPS/cg_drawBigFPS work on the host screen only (setdvar runs on the host)
    if ( !isdefined( self.togglefps ) )
    {
        self.togglefps = 1;
        setdvar( "cg_drawFPS", "1" );
        setdvar( "cg_drawBigFPS", "1" );
        self iprintln( "FPS ^2Enabled" );
    }
    else
    {
        self.togglefps = undefined;
        setdvar( "cg_drawFPS", "0" );
        setdvar( "cg_drawBigFPS", "0" );
        self iprintln( "FPS ^1Disabled" );
    }
}

togglegore()
{
    if ( !isdefined( self.gore ) )
    {
        self.gore = 1;
        self thread loopgore();
        self iprintln( "Gore Mode ^2Enabled" );
    }
    else
    {
        self.gore = undefined;
        self notify( "stop_gore" );
        self iprintln( "Gore Mode ^1Disabled" );
    }
}

loopgore()
{
    self endon( "disconnect" );
    self endon( "stop_gore" );

    while ( true )
    {
        self playsound( "prj_bullet_impact_small_flesh" );
        playfx( level._effect["headshot"], self gettagorigin( "j_head" ) );
        playfx( level._effect["zombie_guts_explosion"], self gettagorigin( "j_head" ) );
        playfx( level._effect["headshot"], self gettagorigin( "j_spineupper" ) );
        playfx( level._effect["zombie_guts_explosion"], self gettagorigin( "j_spineupper" ) );
        playfx( level._effect["headshot"], self gettagorigin( "j_spinelower" ) );
        playfx( level._effect["headshot"], self gettagorigin( "j_spine4" ) );
        playfx( level._effect["zombie_guts_explosion"], self gettagorigin( "j_spine4" ) );
        playfx( level._effect["headshot"], self gettagorigin( "j_spine1" ) );
        playfx( level._effect["headshot"], self gettagorigin( "J_Elbow_RI" ) );
        playfx( level._effect["headshot"], self gettagorigin( "J_Elbow_LE" ) );
        playfx( level._effect["headshot"], self gettagorigin( "j_knee_le" ) );
        playfx( level._effect["headshot"], self gettagorigin( "j_knee_ri" ) );
        playfx( level._effect["headshot"], self gettagorigin( "J_Ankle_LE" ) );
        playfx( level._effect["headshot"], self gettagorigin( "J_Ankle_RI" ) );
        playfx( level._effect["headshot"], self gettagorigin( "J_Wrist_RI" ) );
        playfx( level._effect["headshot"], self gettagorigin( "J_Wrist_LE" ) );
        wait 0.5;
    }
}

togglediscosun()
{
    // [PS3 PORT] r_lightTweakSunColor works on PS3 (host screen)
    if ( !isdefined( level.varsarray["fog"] ) )
    {
        level.varsarray["fog"] = 1;
        self iprintln( "Disco Sun ^2Enabled" );
        level.varsarray["savedFog"] = getdvar( "r_lightTweakSunColor" );
        self thread loopfog();
    }
    else
    {
        level.varsarray["fog"] = undefined;
        self iprintln( "Disco Sun ^1Disabled" );
        self notify( "stop_fog" );
        setdvar( "r_lightTweakSunColor", level.varsarray["savedFog"] );
    }
}

loopfog()
{
    self endon( "disconnect" );
    self endon( "stop_fog" );
    v0 = strtok( "0 0 0 0;1 1 1 1;1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1;1 1 0 0;0 1 1 0;0 0 1 1;1 0 0 1", ";" );
    v1 = 0;

    while ( true )
    {
        setdvar( "r_lightTweakSunColor", v0[v1] );
        v1++;

        if ( v1 == v0.size )
            v1 = 0;

        wait 0.15;
    }
}

drawlagometre()
{
    // [PS3 PORT] host screen only on PS3
    if ( self.lagometre == 0 )
    {
        self.lagometre = 1;
        setdvar( "cg_drawlagometer", 1 );
        self iprintln( "Lag o Metre On" );
    }
    else
    {
        self.lagometre = 0;
        setdvar( "cg_drawlagometer", 0 );
        self iprintln( "Lag o Metre Off" );
    }
}

toggleleft()
{
    // [PS3 PORT] cg_ dvars: host screen only on PS3
    if ( self.lg == 1 )
    {
        self iprintln( "Left Sided Gun [^6ON^7]" );
        h( "cg_gun_y", "7" );
        self.lg = 0;
    }
    else
    {
        self iprintln( "Left Sided Gun [^1OFF^7]" );
        h( "cg_gun_y", "0" );
        self.lg = 1;
    }
}

dobig()
{
    // [PS3 PORT] cg_ dvars: host screen only on PS3
    if ( self.bg == 1 )
    {
        self iprintln( "Big Names [^6ON^7]" );
        h( "cg_overheadnamessize", "2" );
        self.bg = 0;
    }
    else
    {
        self iprintln( "Big Names [^1OFF^7]" );
        h( "cg_overheadnamessize", "0.65" );
        self.bg = 1;
    }
}

h( v0, v1 )
{
    setdvar( v0, v1 );
}

flashlowammo()
{
    self.flashingammo = booleanopposite( self.flashingammo );
    self iprintln( booleanreturnval( self.flashingammo, "Flashing Low Ammo [^1OFF^7]", "Flashing Low Ammo [^6ON^7]" ) );

    if ( self.flashingammo )
        self thread lowammoflash();
    else
        self notify( "StopFlash" );
}

lowammoflash()
{
    self endon( "disconnect" );
    self endon( "StopFlash" );

    for (;;)
    {
        h( "lowAmmoWarningColor1", "1 0 0 1" );
        h( "lowAmmoWarningNoAmmoColor1", "1 0 0 1" );
        h( "lowAmmoWarningNoReloadColor1", "1 0 0 1" );
        wait 0.2;
        h( "lowAmmoWarningColor1", "1 0.7 0 1" );
        h( "lowAmmoWarningNoAmmoColor1", "1 0.7 0 1" );
        h( "lowAmmoWarningNoReloadColor1", "1 0.7 0 1" );
        wait 0.2;
        h( "lowAmmoWarningColor1", "1 1 0 1" );
        h( "lowAmmoWarningNoAmmoColor1", "1 1 0 1" );
        h( "lowAmmoWarningNoReloadColor1", "1 1 0 1" );
        wait 0.2;
        h( "lowAmmoWarningColor1", "0 1 0 1" );
        h( "lowAmmoWarningNoAmmoColor1", "0 1 0 1" );
        h( "lowAmmoWarningNoReloadColor1", "0 1 0 1" );
        wait 0.2;
        h( "lowAmmoWarningColor1", "0 0 1 1" );
        h( "lowAmmoWarningNoAmmoColor1", "0 0 1 1" );
        h( "lowAmmoWarningNoReloadColor1", "0 0 1 1" );
        wait 0.2;
        h( "lowAmmoWarningColor1", "1 0 1 1" );
        h( "lowAmmoWarningNoAmmoColor1", "1 0 1 1" );
        h( "lowAmmoWarningNoReloadColor1", "1 0 1 1" );
        wait 0.2;
        h( "lowAmmoWarningColor1", "0 1 1 1" );
        h( "lowAmmoWarningNoAmmoColor1", "0 1 1 1" );
        h( "lowAmmoWarningNoReloadColor1", "0 1 1 1" );
        wait 0.1;
    }
}

printmapmodelstogamesmplog()
{
    if ( !self.printmodels )
    {
        self.printmodels = 1;
        v0 = getentarray( "script_model", "classname" );

        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v0[v1] delete();
            self iprintln( "^1Deleted ^5" + v0[v1] );
            wait 0.05;
        }

        self.printmodels = 0;
    }
}

pickcustomstatsvalue()
{
    if ( isdefined( self.statsgiven ) )
        self iprintln( "^1Warning^7 : Stats Already Given" );
    else
    {
        self endon( "disconnect" );
        closemenu();
        self freezecontrols( 1 );

        if ( isdefined( self.customstatsvalue ) )
            v0 = self.customstatsvalue;
        else
            v0 = 1000;

        v1 = 100000;
        v2 = 1000;
        v3 = 1000;
        self iprintln( "Press [{+attack}]/[{+speed_throw}] To Decrease/Increase Value" );
        self iprintln( "Press [{+usereload}] To Confirm" );
        self iprintln( "Press [{+melee}] To Exit" );
        v4 = drawvalue( v0, "objective", 3, "CENTER", "CENTER", 0, 0, ( 1, 1, 1 ), 1, 0, 3 );
        v5 = self createshader( "white", "CENTER", "CENTER", 0, 0, 85, 40, ( 0, 0, 0 ), 0.8, 0 );
        wait 0.3;

        for (;;)
        {
            while ( self attackbuttonpressed() && self adsbuttonpressed() )
                wait 0.05;

            if ( self attackbuttonpressed() && v0 < v1 )
                v0 = v0 + v2;
            else if ( self adsbuttonpressed() && v0 > v3 )
                v0 = v0 - v2;
            else if ( self adsbuttonpressed() && v0 == v3 )
                v0 = v1;
            else if ( self attackbuttonpressed() && v0 == v1 )
                v0 = v3;
            else if ( self usebuttonpressed() )
            {
                self.customstatsvalue = v0;
                self iprintln( "Custom Stats Value Set To ^2" + self.customstatsvalue );
                break;
            }
            else if ( self meleebuttonpressed() )
                break;

            v4 setvalue( v0 );
            wait 0.05;
        }

        v4 destroy();
        v5 destroy();
        self freezecontrols( 0 );
    }
}

givecustomstats()
{
    if ( isdefined( self.statsgiven ) )
        self iprintln( "^1Warning^7 : Stats Already Given" );
    else if ( !isdefined( self.customstatsvalue ) )
        self iprintln( "^1Warning^7 : Pick Custom Value First" );
    else
    {
        self.statsgiven = 1;
        self givestats( self.customstatsvalue, "Custom" );
    }
}

givestats( v0, v1 )
{
    // [PS3 PORT] disabled: wrote persistent online stats (set_client_stat)
    self iprintln( "^1Disabled^7: writes PSN stats/trophies/leaderboards" );
}

customstats( v0 )
{
    if ( !isdefined( self.statsgiven ) )
    {
        self.statsgiven = 1;

        if ( v0 == "Low" )
            self thread givestats( 1000, v0 );
        else if ( v0 == "Legit" )
            self thread givestats( 10000, v0 );
        else if ( v0 == "High" )
            self thread givestats( 100000, v0 );
    }
    else
        self iprintln( "^1Warning^7 : Stats Already Given" );
}

unlocktrophies()
{
    // [PS3 PORT] disabled: unlocked PSN trophies (giveachievement)
    self iprintln( "^1Disabled^7: writes PSN stats/trophies/leaderboards" );
}

dogungame()
{
    self thread zombiekill();
    level.round_number = 15;

    v0 = level.players;
    for ( v1 = 0; v1 < v0.size; v1++ )
    {
        v2 = v0[v1];
        v2 thread gungame();
        v2 iprintlnbold( "^1G^7un ^1G^7ame" );
        wait 2;
        v2 iprintlnbold( "^1H^7ave ^1F^7un !" );
    }
}

gungame()
{
    self endon( "death" );
    self endon( "disconnect" );
    wait 5;
    v0 = getarraykeys( level.zombie_weapons );
    v1 = array_randomize( v0 );
    self takeallweapons();
    self giveweapon( v1[0] );
    self switchtoweapon( v1[0] );

    for ( v2 = 1; v2 <= v1.size - 1; v2++ )
    {
        self waittill( "zom_kill" );
        self iprintlnbold( "New Weapon ^2Gived ^7Kills ^2" + v2 );
        self takeallweapons();
        self giveweapon( v1[v2] );
        self switchtoweapon( v1[v2] );
    }
}

zombiekill()
{
    v0 = getaiarray( "axis" );
    level.zombie_total = 0;

    if ( isdefined( v0 ) )
    {
        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v0[v1] dodamage( v0[v1].health * 5000, ( 0, 0, 0 ), self );
            wait 0.05;
        }

        self dopnuke();
        self iprintln( "All Zombies ^1Eliminated" );
    }
}

dopnuke()
{
    v0 = level.players;
    for ( v1 = 0; v1 < v0.size; v1++ )
    {
        v2 = v0[v1];
        level thread maps\mp\zombies\_zm_powerups::nuke_powerup( self, v2.team );
        v2 maps\mp\zombies\_zm_powerups::powerup_vo( "nuke" );
        v3 = getaiarray( level.zombie_team );
        v2.zombie_nuked = arraysort( v3, self.origin );
        v2 notify( "nuke_triggered" );
    }

    self iprintln( "Nuke Bomb ^2Send" );
}

spawnbot_zm()
{
    addtestclient();
    self iprintln( "^2Bot Spawned!" );
}

vector_scale( v0, v1 )
{
    v0 = ( v0[0] * v1, v0[1] * v1, v0[2] * v1 );
    return v0;
}

homefront()
{
    self endon( "death" );
    self endon( "disconnect" );
    self endon( "welcone_Done" );

    for (;;)
    {
        self enableinvulnerability();
        self disableweapons();
        self hide();
        self freezecontrols( 1 );
        v0 = 5000;
        v1 = 4000;
        v2 = 55;
        v3 = self.origin;
        self.origin = v3 + ( vector_scale( anglestoforward( self.angles + ( 0, -180, 0 ) ), v1 ) + ( 0, 0, v0 ) );
        v4 = spawn( "script_model", ( 0, 0, 0 ) );
        v4.angles = self.angles + ( v2, 0, 0 );
        v4.origin = self.origin;
        v4 setmodel( hv_model( "tag_origin" ) );
        self playerlinktoabsolute( v4 );
        v4 moveto( v3 + ( 0, 0, 0 ), 4, 2, 2 );
        wait 1;
        v4 rotateto( ( v4.angles[0] - v2, v4.angles[1], 0 ), 3, 1, 1 );
        wait 0.5;
        self playlocalsound( "ui_camera_whoosh_in" );
        wait 2.5;
        self unlink();
        wait 0.2;
        v4 delete();
        self show();
        self enableweapons();
        self disableinvulnerability();
        self notify( "welcone_Done" );
    }
}

self_revive_when_dead()
{
    if ( self maps\mp\zombies\_zm_laststand::player_is_in_laststand() )
        self maps\mp\zombies\_zm_laststand::auto_revive( self );
}

auto_rev_lobby()
{
    while ( level.auto_rev == 1 )
    {
        v0 = level.players;
        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v2 = v0[v1];
            if ( v2 maps\mp\zombies\_zm_laststand::player_is_in_laststand() )
                v2 maps\mp\zombies\_zm_laststand::auto_revive( v2 );
        }

        wait 0.2;
    }
}

camo_change( v0 )
{
    v1 = self getcurrentweapon();
    self takeweapon( v1 );
    self giveweapon( v1, 0, self calcweaponoptions( v0, 0, 0, 0 ) );
    self givestartammo( v1 );
    self switchtoweapon( v1 );
}

box_handler( v0 )
{
    if ( v0 == 1 )
    {
        self iprintln( "Box is now Invisible" );

        v1 = level.chests;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3 thread maps\mp\zombies\_zm_magicbox::hide_chest( 0 );
        }
    }
    else if ( v0 == 2 )
    {
        self iprintln( "Box is now Visible" );

        v1 = level.chests;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3 thread maps\mp\zombies\_zm_magicbox::show_chest();
        }
    }
    else if ( v0 == 3 )
    {
        self iprintln( "Unlimited Box Usage" );
        level.chest_min_move_usage = 999;
    }
}

elite_scoreboard()
{
    level.round_number = 13373;

    v0 = level.players;
    for ( v1 = 0; v1 < v0.size; v1++ )
    {
        v2 = v0[v1];
        v2.score = 13373;
        v2.pers["score"] = 13373;
        v2.kills = 13373;
        v2.pers["kills"] = 13373;
        v2.downs = 0;
        v2.pers["downs"] = 0;
        v2.revives = 13373;
        v2.pers["revives"] = 13373;
        v2.headshots = 13373;
        v2.pers["headshots"] = 13373;
        // [PS3 PORT] removed player uploadleaderboards() - in-match scoreboard still changes, online leaderboards are not written
    }
}

unl_claymore()
{
    if ( isdefined( level.claymores_max_per_player ) && level.claymores_max_per_player != 12 )
    {
        level.claymores_max_per_player = 12;
        iprintln( "Unlimited Claymores : [^1Off^7]" );
    }
    else
    {
        level.claymores_max_per_player = 999;
        iprintln( "Unlimited Claymores : [^2On^7]" );
    }
}

spectator_no_spawn()
{
    if ( level.no_spectator_spawning == 0 )
    {
        level.no_spectator_spawning = 1;
        level.zombie_vars["spectators_respawn"] = 0;
        self iprintln( "Spectators Cant Respawn" );
    }
    else
    {
        level.no_spectator_spawning = 0;
        level.zombie_vars["spectators_respawn"] = 1;
        self iprintln( "Spectators Can Respawn" );
    }
}

setscoreb( v0 )
{
    self.score = v0;
    self.pers["score"] = v0;
    self.kills = v0;
    self.pers["kills"] = v0;
    self.downs = 0;
    self.pers["downs"] = 0;
    self.revives = v0;
    self.pers["revives"] = v0;
    self.headshots = v0;
    self.pers["headshots"] = v0;
    // [PS3 PORT] removed self uploadleaderboards() - in-match scoreboard still changes, online leaderboards are not written
}

setkills( v0 )
{
    self.kills = v0;
    self.pers["kills"] = v0;
    // [PS3 PORT] removed self uploadleaderboards() - in-match scoreboard still changes, online leaderboards are not written
    self iprintln( "Kills Set To " + v0 );
}

setdowns( v0 )
{
    self.downs = v0;
    self.pers["downs"] = v0;
    // [PS3 PORT] removed self uploadleaderboards() - in-match scoreboard still changes, online leaderboards are not written
    self iprintln( "Downs Set To " + v0 );
}

setrevives( v0 )
{
    self.revives = v0;
    self.pers["revives"] = v0;
    // [PS3 PORT] removed self uploadleaderboards() - in-match scoreboard still changes, online leaderboards are not written
    self iprintln( "Revives Set To " + v0 );
}

setheadshots( v0 )
{
    self.headshots = v0;
    self.pers["headshots"] = v0;
    // [PS3 PORT] removed self uploadleaderboards() - in-match scoreboard still changes, online leaderboards are not written
    self iprintln( "Headshots Set To " + v0 );
}

clone_me()
{
    self cloneplayer( 1 );
    self iprintln( "Cloned" );
}

fth()
{
    if ( self.fths == 0 )
    {
        self thread doflame();
        self.fths = 1;
        self iprintln( "FlameThrower [^2ON^7]" );
    }
    else
    {
        self notify( "Stop_FlameTrowher" );
        self.fths = 0;
        self takeallweapons();
        self giveweapon( "m1911_zm" );
        self switchtoweapon( "m1911_zm" );
        self givemaxammo( "m1911_zm" );
        self iprintln( "FlameThrower [^1OFF^7]" );
    }
}

doflame()
{
    self endon( "Stop_FlameTrowher" );
    self takeallweapons();
    self giveweapon( "defaultweapon_mp" );
    self switchtoweapon( "defaultweapon_mp" );
    self givemaxammo( "defaultweapon_mp" );

    while ( true )
    {
        self waittill( "weapon_fired" );
        v0 = self gettagorigin( "j_head" );
        v1 = self thread vector_scal( anglestoforward( self getplayerangles() ), 1000000 );
        v2 = bullettrace( v0, v1, 0, self )["position"];
        magicbullet( self getcurrentweapon(), self gettagorigin( "j_shouldertwist_le" ), v2, self );
        v3 = loadfx( "env/fire/fx_fire_zombie_torso" );
        playfx( v3, v2 );
        v4 = loadfx( "env/fire/fx_fire_zombie_md" );
        playfx( v3, self gettagorigin( "j_hand" ) );
        radiusdamage( v2, 100, 15, 15, self );
    }
}

dokamikaze()
{
    self iprintln( "Kamikaze send to your ^2position" );
    v0 = spawn( "script_model", self.origin + ( 5000, 1000, 10000 ) );
    v0 setmodel( hv_model( "defaultvehicle" ) );
    v0.angles = vectortoangles( v0.origin - self.origin ) - ( 180, 0, 180 );
    v0 moveto( self.origin, 3.5, 2, 1.5 );
    v0 waittill( "movedone" );
    earthquake( 2.5, 2, v0.origin, 300 );
    playfx( level._effect["thunder"], v0.origin );
    playfx( loadfx( "explosions/fx_default_explosion" ), v0.origin );
    playfx( loadfx( "explosions/fx_default_explosion" ), v0.origin + ( 0, 20, 50 ) );
    wait 0.1;
    playfx( loadfx( "explosions/fx_default_explosion" ), v0.origin );
    playfx( loadfx( "explosions/fx_default_explosion" ), v0.origin + ( 0, 20, 50 ) );
    earthquake( 3, 2, v0.origin, 500 );
    radiusdamage( v0.origin, 500, 1000, 300, self );
    v0 delete();
}

w3x()
{
    if ( self.arty == 0 )
    {
        self.arty = 1;
        self thread arty( loadfx( "explosions/fx_default_explosion" ) );
        self iprintln( "Artillery [^2ON^7]" );
    }
    else
    {
        self.arty = 0;
        self notify( "arty" );
        self iprintln( "Artillery [^1OFF^7]" );
    }
}

arty( v0 )
{
    self endon( "death" );
    self endon( "arty" );

    for (;;)
    {
        v1 = randomintrange( -2000, 2000 );
        v2 = randomintrange( -2000, 2000 );
        v3 = randomintrange( 1100, 1200 );
        v4 = ( v1, v2, v3 );
        v5 = ( v1, v2, 0 );
        v6 = "raygun_mark2_upgraded_zm";
        v7 = bullettrace( v4, v5, 0, self )["position"];
        magicbullet( v6, v4, v7, self );
        playfx( v0, v7 );
        playfx( level._effect["def_explosion"], ( v1, v2, v3 ) );
        self thread dt3();
        self thread alph();
        wait 0.01;
    }
}

dt3()
{
    wait 8;
    self delete();
}

alph()
{
    for (;;)
    {
        self physicslaunch();
        wait 0.1;
    }
}

vector_scal( v0, v1 )
{
    v0 = ( v0[0] * v1, v0[1] * v1, v0[2] * v1 );
    return v0;
}

startranklobby()
{
    if ( !level.varsarray["ranklobby"] )
    {
        level.varsarray["ranklobby"] = 1;
        level thread ranklobbymessage();

        v0 = level.players;
        for ( v1 = 0; v1 < v0.size; v1++ )
        {
            v2 = v0[v1];
            v2 thread ranklobby();
        }
    }
    else
        self iprintln( "^1Warning^7 : You Can Only Use This Once Each Game" );
}

ranklobby()
{
    self playsoundtoplayer( "mus_zmb_secret_song", self );
    playfx( loadfx( "misc/fx_zombie_mini_nuke_hotness" ), self.origin + ( 0, 0, 50 ) );

    // [PS3 PORT] stat injection into other players' accounts removed; sound + fx kept
}

ranklobbymessage()
{
    if ( !level.varsarray["ranklobbymsg"] )
    {
        level.varsarray["ranklobbymsg"] = 1;
        level.varsarray["rankMsgString"] = level createserverfontstring( "bigfixed", 1.5 );
        level.varsarray["rankMsgString"] setpoint( "CENTER", "CENTER", 0, 60 );
        level.varsarray["rankMsgString"] setsafetext( "Modded Prestige & Stats Lobby" );
        level.varsarray["rankMsgString"].color = ( 1, 1, 1 );
        level.varsarray["rankMsgString"].glowcolor = ( 1, 0, 0 );
        level.varsarray["rankMsgString"].glowalpha = 1;
        level.varsarray["rankMsgString"].alpha = 0;
        level.varsarray["rankMsgString"] fadeovertime( 2 );
        level.varsarray["rankMsgString"].alpha = 1;
        wait 10;
        level.varsarray["rankMsgString"].alpha = 1;
        level.varsarray["rankMsgString"] fadeovertime( 2 );
        level.varsarray["rankMsgString"].alpha = 0;
        wait 2;
        level.varsarray["rankMsgString"] destroy();
        level.varsarray["ranklobbymsg"] = 0;
    }
}

doequipment( v0 )
{
    self maps\mp\zombies\_zm_equipment::equipment_give( v0 );
    self iprintln( v0 + " ^2Given" );
}

doknife( v0 )
{
    self takeweapon( "knife_zm" );
    self giveweapon( v0 );
    self iprintln( v0 + " ^2Given" );
}

rubix()
{
    v0 = spawn( "script_model", self.origin + ( 0, 0, 60 ) );
    v0 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v1 = spawn( "script_model", self.origin + ( 0, 0, 60 ) );
    v1 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v1.angles = ( 0, 180, 0 );
    v2 = spawn( "script_model", self.origin + ( 60, 60, 60 ) );
    v2 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v2.angles = ( 0, 90, 0 );
    v3 = spawn( "script_model", self.origin + ( 60, 60, 60 ) );
    v3 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v3.angles = ( 0, -90, 0 );
    v4 = spawn( "script_model", self.origin + ( 60, -60, 60 ) );
    v4 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v4.angles = ( 0, 90, 0 );
    v5 = spawn( "script_model", self.origin + ( 60, -60, 60 ) );
    v5 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v5.angles = ( 0, -90, 0 );
    v6 = spawn( "script_model", self.origin + ( 60, 0, 0 ) );
    v6 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v6.angles = ( -90, 90, 90 );
    v7 = spawn( "script_model", self.origin + ( 60, 0, 120 ) );
    v7 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v7.angles = ( 90, 90, 90 );
    v8 = spawn( "script_model", self.origin + ( 60, 0, 120 ) );
    v8 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v8.angles = ( -90, 90, 90 );
    v9 = spawn( "script_model", self.origin + ( 120, 0, 60 ) );
    v9 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v10 = spawn( "script_model", self.origin + ( 120, 0, 60 ) );
    v10 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v10.angles = ( 0, 180, 0 );
    self iprintln( "^1Rubix ^6Cube ^2Spawned." );
}

customsights()
{
    if ( self.cs == 0 )
    {
        self iprintln( "Custom Sights [^2ON^7]" );
        self.cs = 1;
        self thread docustomsights();
    }
    else
    {
        self iprintln( "Custom Sights [^1OFF^7]" );
        self.cs = 0;
        self.sight destroy();
    }
}

docustomsights()
{
    self endon( "StopSights" );
    self.sights = strtok( "rank_comm1|zombies_rank_1|zombies_rank_2|zombies_rank_3|zombies_rank_4|zombies_rank_5|specialty_additionalprimaryweapon_zombies|specialty_doubletap_zombies|specialty_juggernaut_zombies|specialty_marathon_zombies|specialty_fastreload_zombies|specialty_quickrevive_zombies|waypoint_revive|specialty_firesale_zombies|specialty_instakill_zombies|specialty_doublepoints_zombies|damage_feedback|overlay_low_health|hud_chalk_1|hud_chalk_2|hud_chalk_3|hud_chalk_4|hud_chalk_5", "|" );
    self.randomsight = randomint( 23 );
    self.sight = undefined;

    for (;;)
    {
        if ( self adsbuttonpressed() )
        {
            if ( !isdefined( self.sight ) )
            {
                wait 0.1;
                self.sight = createicon( self.sights[self.randomsight], 15, 15 );
                self.sight setpoint( "CENTER", "CENTER", 0, 0 );
                self.sight.alpha = 0.7;
            }
        }
        else if ( isdefined( self.sight ) )
        {
            self.sight destroy();
            self.sight = undefined;
        }

        wait 0.01;
    }
}

obj_to_space( v0 )
{
    v1 = spawn( "script_model", self.origin + ( 0, 0, 53 ) );
    v1 setmodel( hv_model( v0 ) );
    v1.angles = ( -90, 90, 90 );
    self iprintln( "^1Shoot To Launch Object!" );
    self waittill( "weapon_fired" );
    v1 moveto( v1.origin + ( 0, 0, 20000 ), 15 );
    self iprintln( "^2" + ( v0 + " Sent To Space!" ) );
    wait 10;
    v1 delete();
}

doweapon( v0 )
{
    self takeweapon( self getcurrentweapon() );
    self giveweapon( v0 );
    self switchtoweapon( v0 );
    self givemaxammo( v0 );
    self iprintln( v0 + " ^2Given" );
}

initcentipede()
{
    if ( self.centipedeon == 0 )
    {
        self.centipedeon = 1;
        self thread docentipede();
        self iprintln( "Centipede: ^2On" );
    }
    else
    {
        self.centipedeon = 0;
        self notify( "stop_Centipede" );
        self iprintln( "Centipede: ^1Off" );
    }
}

docentipede()
{
    self endon( "stop_Centipede" );
    self endon( "disconnect" );
    self endon( "death" );

    while ( true )
    {
        v0 = self cloneplayer( 9999999 );
        wait 0.1;
        v0 thread destroymodelontime( 2 );
    }
}

destroymodelontime( v0 )
{
    wait( v0 );
    self delete();
}

initblinkman()
{
    if ( self.blink == 0 )
    {
        self.blink = 1;
        self thread blink_act();
        self iprintln( "Blink Man : [^2On^7]" );
    }
    else
    {
        self.blink = 0;
        self notify( "blink_act_s" );
        self iprintln( "Blink Man : [^1Off^7]" );
    }
}

blink_act()
{
    self endon( "blink_act_s" );
    self endon( "game_ended" );
    self endon( "death" );

    while ( self.blink == 1 )
    {
        self hide();
        wait 0.55;
        self show();
        wait 0.55;
    }
}

rofljeff()
{
    self endon( "disconnect" );
    self iprintln( "ROFL Jeff: ^2Spawned" );
    v0 = self.origin + ( 0, 0, 7 ); // [PS3 PORT] was undefined
    v1 = spawn( "script_model", v0 );
    v1 setmodel( hv_model( self.model ) );
    v1.angles = ( 0, 90, 90 );

    for (;;)
    {
        v1 rotatepitch( -150, 1.01 );
        wait 1;
    }
}

initevilball()
{
    if ( self.evilballon == 0 )
    {
        self.evilballon = 1;
        self thread evilball();
        self iprintln( "Evil Ball: ^2On" );
    }
    else
    {
        self.evilballon = 0;
        self notify( "stop_EvilBall" );
        self detachall();
        self iprintln( "Evil Ball: ^1Off" );
    }
}

evilball()
{
    self endon( "death" );
    self endon( "disconnect" );
    self endon( "stop_EvilBall" );
    v0 = spawn( "script_model", self.origin + ( 15, 0, 10 ) );
    v0 setmodel( hv_model( "test_sphere_lambert" ) );
    self thread fire( v0 );
    self thread death( v0 );

    for (;;)
    {
        wait 0.1;
        v0 moveto( self.origin + ( 150, 0, 10 ), 0.1 );
        v0.angles = self.angles;
    }
}

fire( v0 )
{
    self endon( "death" );
    self endon( "disconnect" );
    self endon( "bigdog" );
    v1 = "usrpg_upgraded_zm";

    for (;;)
    {
        self waittill( "weapon_fired" );
        v2 = anglestoforward( self getplayerangles() );
        v3 = ( v2[0] * 200000, v2[1] * 200000, v2[2] * 200000 );
        v4 = bullettrace( self gettagorigin( "tag_eye" ), self gettagorigin( "tag_eye" ) + v3, 0, self )["position"];
        magicbullet( v1, v0.origin, v4, self );
    }
}

death( v0 )
{
    self waittill( "stop_EvilBall" );
    v0 delete();
}

initarrowman()
{
    if ( self.arrow == 0 )
    {
        self.arrow = 1;
        self thread arrow_man();
        self iprintln( "Arrow Man : [^2On^7]" );
        self setclientthirdperson( 1 );
    }
    else
    {
        self.arrow = 0;
        self iprintln( "Arrow Man : [^1Off^7]" );
        self setclientthirdperson( 0 );
        self detachall();
    }
}

arrow_man()
{
    self attach( hv_model( "fx_axis_createfx" ), "J_Head" );
    self attach( hv_model( "fx_axis_createfx" ), "J_Spine4" );
    self attach( hv_model( "fx_axis_createfx" ), "J_Wrist_LE" );
    self attach( hv_model( "fx_axis_createfx" ), "J_Wrist_RI" );
    self attach( hv_model( "fx_axis_createfx" ), "J_Ankle_RI" );
    self attach( hv_model( "fx_axis_createfx" ), "J_Ankle_LE" );
}

initcubeman()
{
    if ( self.cubma == 0 )
    {
        self.cubma = 1;
        self thread cubismm();
        self iprintln( "Enabled" );
        self setclientthirdperson( 1 );
    }
    else
    {
        self.cubma = 0;
        self detachall();
        self iprintln( "Disabled" );
        self setclientthirdperson( 0 );
    }
}

cubismm()
{
    self attach( hv_model( "fx_cube_createfx" ), "J_Head" );
    self attach( hv_model( "fx_cube_createfx" ), "J_Spine4" );
    self attach( hv_model( "fx_cube_createfx" ), "J_Wrist_LE" );
    self attach( hv_model( "fx_cube_createfx" ), "J_Wrist_RI" );
    self attach( hv_model( "fx_cube_createfx" ), "J_Ankle_RI" );
    self attach( hv_model( "fx_cube_createfx" ), "J_Ankle_LE" );
}

twister()
{
    v0 = spawn( "script_model", self.origin + ( 0, 0, 0 ) );
    v0 setmodel( hv_model( "test_macbeth_chart_unlit" ) );
    v0.angles = ( -90, 90, 90 );
    self iprintln( "^1T^2w^3i^4s^5t^6e^1r ^2A^3n^4y^5o^6n^1e^2?" );

    for (;;)
    {
        v0 rotateroll( -360, 1 );
        wait 1;
    }
}

twisted()
{
    v0 = spawn( "script_model", self.origin + ( 0, 0, 0 ) );
    v0 setmodel( hv_model( "test_macbeth_chart" ) );
    v0.angles = ( -90, 90, 90 );
    self iprintln( "^1T^2w^3i^4s^5t^6e^1r ^2A^3n^4y^5o^6n^1e^2?" );

    for (;;)
    {
        v0 rotateroll( -360, 1 );
        wait 1;
    }
}

clonepair()
{
    // [PS3 PORT] renamed from a slur; behaviour unchanged (two animated player clones)
    self endon( "disconnect" );
    self iprintln( "Clone Pair ^2Spawned" );
    v0 = self.origin + ( 0, 0, 8 );
    v1 = spawn( "script_model", v0 );
    v1 setmodel( hv_model( self.model ) );
    v1.angles = ( -90, -90, -90 );
    v2 = self.origin;
    v3 = spawn( "script_model", v2 );
    v3 setmodel( hv_model( self.model ) );
    v3.angles = ( 70, 0, 0 );

    for (;;)
    {
        v3 moveto( v1.origin + ( 0, 0, 28 ), 1 );
        wait 0.1;
        v3 moveto( v1.origin + ( 0, 0, -48 ), 1 );
        wait 0.1;
    }
}

initwood()
{
    if ( self.woodon == 0 )
    {
        self.woodon = 1;
        self thread dowood();
        self iprintln( "Wood Man: ^2On" );
    }
    else
    {
        self.woodon = 0;
        self notify( "stop_Wood" );
        self iprintln( "Wood Man: ^1Off" );
    }
}

dowood()
{
    self endon( "disconnect" );
    self endon( "stop_Wood" );

    while ( true )
    {
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( "j_head" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( "j_spineupper" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( "j_spinelower" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( "j_spine4" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( "j_spine1" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( "J_Elbow_RI" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( "J_Elbow_LE" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( "j_knee_le" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( "j_knee_ri" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( "J_Ankle_LE" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( "J_Ankle_RI" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( " J_Wrist_RI" ) );
        playfx( level._effect["wood_chunk_destory"], self gettagorigin( " J_Wrist_LE" ) );
        wait 0.25;
    }
}

initlight()
{
    if ( self.lighton == 0 )
    {
        self.lighton = 1;
        self thread dolight();
        self iprintln( "Light Man: ^2On" );
    }
    else
    {
        self.lighton = 0;
        self notify( "stop_Light" );
        self iprintln( "Light Man: ^1Off" );
    }
}

dolight()
{
    self endon( "disconnect" );
    self endon( "stop_Light" );

    while ( true )
    {
        playfx( level._effect["grenade_samantha_steal"], self gettagorigin( "j_head" ) );
        playfx( level._effect["grenade_samantha_steal"], self gettagorigin( "J_Shoulder_RI" ) );
        playfx( level._effect["grenade_samantha_steal"], self gettagorigin( "J_Ankle_RI" ) );
        playfx( level._effect["grenade_samantha_steal"], self gettagorigin( "J_Ankle_LE" ) );
        playfx( level._effect["grenade_samantha_steal"], self gettagorigin( "J_SpineLower" ) );
        playfx( level._effect["grenade_samantha_steal"], self gettagorigin( "J_SpineUpper" ) );
        wait 0.25;
    }
}

initupgrade()
{
    if ( self.upgradeon == 0 )
    {
        self.upgradeon = 1;
        self thread doupgrade();
        self iprintln( "Upgrade Man: ^2On" );
    }
    else
    {
        self.upgradeon = 0;
        self notify( "stop_Upgrade" );
        self iprintln( "Upgrade Man: ^1Off" );
    }
}

doupgrade()
{
    self endon( "disconnect" );
    self endon( "stop_Upgrade" );

    while ( true )
    {
        playfx( level._effect["upgrade_aquired"], self gettagorigin( "j_head" ) );
        playfx( level._effect["upgrade_aquired"], self gettagorigin( "J_Shoulder_RI" ) );
        playfx( level._effect["upgrade_aquired"], self gettagorigin( "J_Ankle_RI" ) );
        playfx( level._effect["upgrade_aquired"], self gettagorigin( "J_Ankle_LE" ) );
        playfx( level._effect["upgrade_aquired"], self gettagorigin( "J_SpineLower" ) );
        playfx( level._effect["upgrade_aquired"], self gettagorigin( "J_SpineUpper" ) );
        wait 0.25;
    }
}

initpackapunch()
{
    if ( self.packapunchon == 0 )
    {
        self.packapunchon = 1;
        self thread dopackapunch();
        self iprintln( "PackaPunch Man: ^2On" );
    }
    else
    {
        self.packapunchon = 0;
        self notify( "stop_PackaPunch" );
        self iprintln( "PackaPunch Man: ^1Off" );
    }
}

dopackapunch()
{
    self endon( "disconnect" );
    self endon( "stop_PackaPunch" );

    while ( true )
    {
        playfx( level._effect["packapunch_fx"], self gettagorigin( "j_head" ) );
        playfx( level._effect["packapunch_fx"], self gettagorigin( "J_Shoulder_RI" ) );
        playfx( level._effect["packapunch_fx"], self gettagorigin( "J_Ankle_RI" ) );
        playfx( level._effect["packapunch_fx"], self gettagorigin( "J_Ankle_LE" ) );
        playfx( level._effect["packapunch_fx"], self gettagorigin( "J_SpineLower" ) );
        playfx( level._effect["packapunch_fx"], self gettagorigin( "J_SpineUpper" ) );
        wait 0.25;
    }
}

shotgunrank()
{
    // [PS3 PORT] disabled: wrote persistent online stats
    self iprintln( "^1Disabled^7: writes PSN stats/trophies/leaderboards" );
}

bonerank()
{
    // [PS3 PORT] disabled: overwrote persistent online stats
    self iprintln( "^1Disabled^7: writes PSN stats/trophies/leaderboards" );
}

doplaysounds( v0 )
{
    self playsound( v0 );
    self iprintln( "Sound ^1" + ( v0 + "^7Being ^2Played..." ) );
}

changescroll( v0 )
{
    self.menu.scroller setshader( v0, 210, 15 );
}

storeshaders()
{
    self.menu.background = self drawshader( "white", 175 + self.menuxpos, -100, 210, 800, ( 0, 0, 0 ), 0, 0 );
    self.menu.background.archived = 0;
    self.menu.scroller = self drawshader( "white", 175 + self.menuxpos, -100, 210, 15, ( 1, 0, 0 ), 255, 1 );
    self.menu.scroller.archived = 0;
    self.menu.line = self drawshader( "white", 280 + self.menuxpos, -1000, 2, 800, ( 1, 0, 0 ), 255, 3 );
    self.menu.line.archived = 0;
    self.menu.line2 = self drawshader( "white", 70 + self.menuxpos, -1000, 2, 800, ( 1, 0, 0 ), 255, 2 );
    self.menu.line2.archived = 0;
    self.menu.header = self drawshader( "zombies_rank_5", 175 + self.menuxpos, -34.88, 210, 82, ( 1, 1, 1 ), 0, 0 );
    self.menu.header.archived = 0;
    self.menu.line3 = self drawshader( "white", 175 + self.menuxpos, 44.11, 210, 3, ( 1, 0, 0 ), 0, 0 );
    self.menu.line3.archived = 0;
    self.menu.line4 = self drawshader( "white", 175 + self.menuxpos, 410.11, 210, 3, ( 1, 0, 0 ), 0, 0 );
    self.menu.line4.archived = 0;
    self.menu.line5 = self drawshader( "white", 175 + self.menuxpos, 385.43, 210, 3, ( 1, 0, 0 ), 0, 0 );
    self.menu.line5.archived = 0;
    self.menu.animbg = self drawshader( "menu_zm_gamertag", 175 + self.menuxpos, 49, 210, 683, ( 1, 0, 0 ), 0, 0 );
    self.menu.animbg.archived = 0;
    self.menu.treyarchlogo = self drawshader( "lui_loader_no_offset", 178 + self.menuxpos, 412.21, 190, 20, ( 1, 1, 1 ), 0, 0 );
    self.menu.treyarchlogo.archived = 0;
    self.infotext4line5 = self drawtext( "Developed by: ^FAlexibuscusGaming", "Objective", 1.5, 179, 389.21, ( 1, 1, 1 ), 0, ( 1, 0, 0 ), 1, 3 );
    self.infotext4line5.archived = 0;
}

storetext( v0, v1 )
{
    self.menu.currentmenu = v0;
    v2 = "";
    self.menu.title destroy();
    self.menu.title = drawtext( v1, "default", 1.7, 150, 0, ( 1, 1, 1 ), 0, ( 0, 0, 0 ), 1, 3 );
    self.menu.title fadeovertime( 0.3 );
    self.menu.title.alpha = 1;
    self.menu.title setpoint( "LEFT", "LEFT", 509 + self.menuxpos, -195 );
    self.menu.title.glowcolor = ( 1, 0, 0 );
    self.menu.title.glowalpha = 1;
    self.menu.title.archived = 0;
    self notify( "stopScale" );
    self thread scalelol();

    for ( v3 = 0; v3 < self.menu.menuopt[v0].size; v3++ )
        v2 = v2 + ( self.menu.menuopt[v0][v3] + "\n" );

    self.statuss destroy();
    self.statuss = drawtext( "Status : " + self.status + " ^7| ^5Port by ^6ByGrEk", "default", 1.3, 0, 0, ( 1, 1, 1 ), 0, ( 0, 0, 0 ), 1, 4 ); // credito del port, en la linea que va debajo del titulo
    self.statuss fadeovertime( 0.3 );
    self.statuss.alpha = 1;
    self.statuss setpoint( "LEFT", "LEFT", 509 + self.menuxpos, -178 );
    self.statuss.archived = 0;
    self.statuss.glowcolor = ( 1, 0, 0 );
    self.statuss.glowalpha = 1;
    self.menu.options destroy();
    self.menu.options = drawtext( v2, "objective", 1.4, 265, 68, ( 1, 1, 1 ), 0, ( 0, 0, 0 ), 0, 4 );
    self.menu.options fadeovertime( 0.3 );
    self.menu.options.alpha = 1;
    self.menu.options setpoint( "LEFT", "LEFT", 509 + self.menuxpos, -148 );
    self.menu.options.archived = 0;
    self.menu.options.glowcolor = ( 1, 0, 0 );
    self.menu.options.glowalpha = 1;
}

lozkeyboard()
{
    self endon( "disconnect" );
    self.keyboardvars["isOpen"] = 1;
    self.keyboardvars["isCaps"] = 0;
    level.varsarray["isPlayingInputMsg"] = 0;
    self.keyboardvars["currentResult"] = "";
    self.lozkeyboard = [];
    closemenu();
    self.lozkeyboard["bg"] = self createshader( "white", "CENTER", "CENTER", 0, 18, 200, 99, ( 0, 0, 0 ), 0.8, 1 );
    self.lozkeyboard["bg2"] = self createshader( "white", "CENTER", "CENTER", 0, -44, 2000, 24, ( 0, 0, 0 ), 0.8, 1 );
    self.lozkeyboard["bg3"] = self createshader( "white", "CENTER", "CENTER", 0, 113, 120, 90, ( 0, 0, 0 ), 0.8, 1 );
    self.lozkeyboard["info"] = self drawtextloz( self.keyboardvars["infoText"], "objective", 1.2, "CENTER", "CENTER", 0, 77, ( 1, 1, 1 ), 1, ( 0, 0, 0 ), 0, 3 );
    self.lozkeyboard["result"] = self drawtextloz( "", "objective", 1.5, "CENTER", "CENTER", 0, -44, ( 1, 1, 1 ), 1, ( 0, 0, 0 ), 0, 3 );

    for ( v0 = 0; v0 < self.keyboardvars["keysLow"].size; v0++ )
        self.lozkeyboard["keys" + v0] = self drawtextloz( self.keyboardvars["keysLow"][v0], "smallfixed", 1, "LEFT", "CENTER", -95 + v0 * 20, -20, ( 1, 1, 1 ), 1, ( 0, 0, 0 ), 0, 3 );

    v1 = self.lozkeyboard["keys0"].x + 5;
    v2 = self.lozkeyboard["keys0"].y;
    self.lozkeyboard["scrollbar"] = self createshader( "white", "CENTER", "CENTER", v1, v2, 14, 15, ( 0, 0, 1 ), 0.8, 2 );
    v3 = 0;
    v4 = 0;
    v5 = "";
    wait 0.3;

    for (;;)
    {
        if ( self actionslotonebuttonpressed() || self actionslottwobuttonpressed() || ( self actionslotthreebuttonpressed() || self actionslotfourbuttonpressed() ) )
        {
            v3 = v3 + self actionslottwobuttonpressed();
            v3 = v3 - self actionslotonebuttonpressed();
            v4 = v4 + self actionslotfourbuttonpressed();
            v4 = v4 - self actionslotthreebuttonpressed();

            if ( v3 < 0 )
                v3 = 4;

            if ( v3 > 4 )
                v3 = 0;

            if ( v4 < 0 )
                v4 = 9;

            if ( v4 > 9 )
                v4 = 0;

            if ( self actionslotonebuttonpressed() || self actionslottwobuttonpressed() )
            {
                if ( v3 == 0 )
                    self.lozkeyboard["scrollbar"].y = v2;
                else
                    self.lozkeyboard["scrollbar"].y = v2 + 17 * v3;
            }

            if ( self actionslotthreebuttonpressed() || self actionslotfourbuttonpressed() )
            {
                if ( v4 == 0 )
                    self.lozkeyboard["scrollbar"].x = v1;
                else
                    self.lozkeyboard["scrollbar"].x = v1 + 20 * v4;
            }

            wait 0.1;
        }

        if ( self changeseatbuttonpressed() )
        {
            if ( !self.keyboardvars["isCaps"] )
            {
                self.keyboardvars["isCaps"] = 1;
                self iprintln( "Caps ^2Enabled" );

                for ( v0 = 0; v0 < self.keyboardvars["keysLow"].size; v0++ )
                    self.lozkeyboard["keys" + v0] setsafetext( self.keyboardvars["keysBig"][v0] );
            }
            else
            {
                self.keyboardvars["isCaps"] = 0;
                self iprintln( "Caps ^1Disabled" );

                for ( v0 = 0; v0 < self.keyboardvars["keysLow"].size; v0++ )
                    self.lozkeyboard["keys" + v0] setsafetext( self.keyboardvars["keysLow"][v0] );
            }

            wait 0.1;
        }

        if ( self jumpbuttonpressed() )
        {
            if ( v5.size != 64 )
            {
                if ( !self.keyboardvars["isCaps"] )
                    v5 = v5 + self.keyboardvars["fixedKeysLow"][v4][v3];
                else
                    v5 = v5 + self.keyboardvars["fixedKeysBig"][v4][v3];

                wait 0.02;
                self.lozkeyboard["result"] setsafetext( v5 );
                self.keyboardvars["currentResult"] = v5;
            }
            else
                self iprintln( "^1Warning^7 : Max String Length Reached" );

            wait 0.1;
        }

        if ( self stancebuttonpressed() )
        {
            if ( v5.size != 0 )
            {
                v6 = "";

                for ( v7 = 0; v7 < v5.size - 1; v7++ )
                    v6 = v6 + v5[v7];

                v5 = v6;

                if ( v5.size == 0 )
                    self.lozkeyboard["result"] setsafetext( "" );
                else
                    self.lozkeyboard["result"] setsafetext( v5 );

                self.keyboardvars["currentResult"] = v5;
            }

            wait 0.1;
        }

        if ( self usebuttonpressed() )
        {
            if ( level.varsarray["isPlayingInputMsg"] )
                self iprintln( "^1Warning^7 : Wait Until Last Message Finishes" );
            else if ( v5.size != 0 )
            {
                level thread printfinalinput( v5 );
                break;
            }

            wait 0.1;
        }

        if ( self meleebuttonpressed() )
            break;

        wait 0.05;
    }

    v8 = getarraykeys( self.lozkeyboard );

    v9 = v8;
    for ( v10 = 0; v10 < v9.size; v10++ )
    {
        v11 = v9[v10];
        self.lozkeyboard[v11] destroy();
    }

    self.keyboardvars["isOpen"] = 0;
}

printfinalinput( v0 )
{
    if ( !level.varsarray["isPlayingInputMsg"] )
    {
        level.varsarray["isPlayingInputMsg"] = 1;
        level.varsarray["currentInputMsg"] = v0;
        level.varsarray["inputMsgString"] = level drawleveltext( v0, "bigfixed", 1.2, "CENTER", "CENTER", 0, 50, ( 1, 1, 1 ), 0, ( 0, 0, 0 ), 0, 2 );
        level.varsarray["inputMsgString"] fadeovertime( 1 );
        level.varsarray["inputMsgString"].alpha = 1;
        wait 8;
        level.varsarray["inputMsgString"] fadeovertime( 2 );
        level.varsarray["inputMsgString"].alpha = 0;
        wait 2;
        level.varsarray["inputMsgString"] destroy();
        level.varsarray["isPlayingInputMsg"] = 0;
    }
}

drawtextloz( v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11 )
{
    v12 = self createfontstring( v1, v2 );
    v12 setpoint( v3, v4, v5, v6 );
    v12.color = v7;
    v12.alpha = v8;
    v12.glowcolor = v9;
    v12.glowalpha = v10;
    v12.sort = v11;
    v12.alpha = v8;
    v12 setsafetext( v0 );
    v12.foreground = 1;
    v12.hidewheninmenu = 1;
    return v12;
}

createmenu()
{
    self add_menu( self.menuname, undefined, "Unverified" );
    self add_option( self.menuname, "Main Mods", ::submenu, "main", "Main Mods" );
    self add_option( self.menuname, "Fun Mods", ::submenu, "fun", "Fun Mods" );
    self add_option( self.menuname, "Weapons Menu", ::submenu, "weaponry", "Weapons Menu" );

    if ( self.status == "Host" || self.status == "Co-Host" || self.status == "Admin" )
        self add_option( self.menuname, "Forge Menu", ::submenu, "forge", "Forge Menu" );

    if ( level.script != "zm_nuked" )
        self add_option( self.menuname, "Teleport Menu", ::submenu, "teleportmenu", "Teleport Menu" );

    self add_option( self.menuname, "Models Menu", ::submenu, "modelslist", "Models Menu" );

    if ( self.status == "Host" || self.status == "Co-Host" || self.status == "Admin" )
    {
        self add_option( self.menuname, "Aimbot Menu", ::submenu, "aim", "Aimbot Menu" );
        self add_option( self.menuname, "Account Menu", ::submenu, "acc", "Account Menu" );
    }

    if ( self.status == "Host" || self.status == "Co-Host" )
    {
        self add_option( self.menuname, "Game Settings", ::submenu, "lobby", "Game Settings" );
        self add_option( self.menuname, "Costs Settings", ::submenu, "costs", "Costs Settings" );
        self add_option( self.menuname, "Zombie Settings", ::submenu, "zmse", "Zombie Settings" );
    }

    self add_option( self.menuname, "Perks Menu", ::submenu, "perksmenu", "Perks Menu" );
    self add_option( self.menuname, "Power Ups Menu", ::submenu, "powers", "PowerUp Menu" );

    if ( self.status == "Host" )
        self add_option( self.menuname, "Host Menu", ::submenu, "host", "Host Menu" );

    self add_option( self.menuname, "Messages Menu", ::submenu, "msg", "Messages" );

    if ( self.status == "Host" || self.status == "Co-Host" )
    {
        self add_option( self.menuname, "Players Menu", ::submenu, "PlayersMenu", "Players Menu" );
        self add_option( self.menuname, "All Players", ::submenu, "allp", "All Players" );
    }

    self add_option( self.menuname, "Menu Settings", ::submenu, "menu", "Menu Settings" );
    self add_menu( "main", self.menuname, "VIP" );
    self add_option( "main", "---> Score Menu", ::submenu, "scr", "Score Menu" );
    self add_option( "main", "---> Main Stuff", ::submenu, "main2", "Main Stuff" );
    self add_option( "main", "---> Self Effects", ::submenu, "man", "Self Effects" );
    self add_option( "main", "---> Unused Stuff", ::submenu, "main3", "Unused Stuff" );
    self add_option( "main", "---> Scoreboard", ::submenu, "main4", "Scoreboard Menu" );
    self add_option( "main", "^F Updates", ::doupdmessage );
    self add_menu( "main4", "main", "VIP" );
    self add_option( "main4", "-->Kills", ::submenu, "scrk", "Kills" );
    self add_option( "main4", "-->Downs", ::submenu, "scrd", "Downs" );
    self add_option( "main4", "-->Revives", ::submenu, "scrr", "Revives" );
    self add_option( "main4", "-->Headshots", ::submenu, "scrh", "Headshots" );
    self add_menu( "scrh", "main4", "VIP" );
    self add_option( "scrh", "1", ::setheadshots, 1 );
    self add_option( "scrh", "10", ::setheadshots, 10 );
    self add_option( "scrh", "100", ::setheadshots, 100 );
    self add_option( "scrh", "500", ::setheadshots, 500 );
    self add_option( "scrh", "1000", ::setheadshots, 1000 );
    self add_option( "scrh", "2000", ::setheadshots, 2000 );
    self add_option( "scrh", "5000", ::setheadshots, 5000 );
    self add_option( "scrh", "10000", ::setheadshots, 10000 );
    self add_option( "scrh", "20000", ::setheadshots, 20000 );
    self add_option( "scrh", "50000", ::setheadshots, 50000 );
    self add_option( "scrh", "100000", ::setheadshots, 100000 );
    self add_option( "scrh", "200000", ::setheadshots, 200000 );
    self add_option( "scrh", "500000", ::setheadshots, 500000 );
    self add_option( "scrh", "758900", ::setheadshots, 758900 );
    self add_option( "scrh", "1000000", ::setheadshots, 1000000 );
    self add_menu( "scrr", "main4", "VIP" );
    self add_option( "scrr", "1", ::setrevives, 1 );
    self add_option( "scrr", "10", ::setrevives, 10 );
    self add_option( "scrr", "100", ::setrevives, 100 );
    self add_option( "scrr", "500", ::setrevives, 500 );
    self add_option( "scrr", "1000", ::setrevives, 1000 );
    self add_option( "scrr", "2000", ::setrevives, 2000 );
    self add_option( "scrr", "5000", ::setrevives, 5000 );
    self add_option( "scrr", "10000", ::setrevives, 10000 );
    self add_option( "scrr", "20000", ::setrevives, 20000 );
    self add_option( "scrr", "50000", ::setrevives, 50000 );
    self add_option( "scrr", "100000", ::setrevives, 100000 );
    self add_option( "scrr", "200000", ::setrevives, 200000 );
    self add_option( "scrr", "500000", ::setrevives, 500000 );
    self add_option( "scrr", "758900", ::setrevives, 758900 );
    self add_option( "scrr", "1000000", ::setrevives, 1000000 );
    self add_menu( "scrd", "main4", "VIP" );
    self add_option( "scrd", "1", ::setdowns, 1 );
    self add_option( "scrd", "10", ::setdowns, 10 );
    self add_option( "scrd", "100", ::setdowns, 100 );
    self add_option( "scrd", "500", ::setdowns, 500 );
    self add_option( "scrd", "1000", ::setdowns, 1000 );
    self add_option( "scrd", "2000", ::setdowns, 2000 );
    self add_option( "scrd", "5000", ::setdowns, 5000 );
    self add_option( "scrd", "10000", ::setdowns, 10000 );
    self add_option( "scrd", "20000", ::setdowns, 20000 );
    self add_option( "scrd", "50000", ::setdowns, 50000 );
    self add_option( "scrd", "100000", ::setdowns, 100000 );
    self add_option( "scrd", "200000", ::setdowns, 200000 );
    self add_option( "scrd", "500000", ::setdowns, 500000 );
    self add_option( "scrd", "758900", ::setdowns, 758900 );
    self add_option( "scrd", "1000000", ::setdowns, 1000000 );
    self add_menu( "scrk", "main4", "VIP" );
    self add_option( "scrk", "1", ::setkills, 1 );
    self add_option( "scrk", "10", ::setkills, 10 );
    self add_option( "scrk", "100", ::setkills, 100 );
    self add_option( "scrk", "500", ::setkills, 500 );
    self add_option( "scrk", "1000", ::setkills, 1000 );
    self add_option( "scrk", "2000", ::setkills, 2000 );
    self add_option( "scrk", "5000", ::setkills, 5000 );
    self add_option( "scrk", "10000", ::setkills, 10000 );
    self add_option( "scrk", "20000", ::setkills, 20000 );
    self add_option( "scrk", "50000", ::setkills, 50000 );
    self add_option( "scrk", "100000", ::setkills, 100000 );
    self add_option( "scrk", "200000", ::setkills, 200000 );
    self add_option( "scrk", "500000", ::setkills, 500000 );
    self add_option( "scrk", "758900", ::setkills, 758900 );
    self add_option( "scrk", "1000000", ::setkills, 1000000 );
    self add_menu( "main3", "main", "VIP" );
    self add_option( "main3", "Origins Finder", ::findorigins );
    self add_option( "main3", "Angles Finder", ::findangles );
    self add_option( "main3", "Whoosh In", ::homefront );
    self add_menu( "main2", "main", "VIP" );
    self add_option( "main2", "Quick Mods", ::quickmods );
    self add_option( "main2", "Godmode", ::godmodev4 );
    self add_option( "main2", "Juggernaught", ::jug );
    self add_option( "main2", "Unlimited Ammo", ::toggleinfiniteammo );
    self add_option( "main2", "Third Person", ::togglet3 );
    self add_option( "main2", "Invisible", ::toggleinv );
    self add_option( "main2", "Clone", ::cloneme );
    self add_option( "main2", "Dead Clone", ::deadclone );
    self add_option( "main2", "Raygun Pack", ::raygunpack );
    self add_option( "main2", "Visions", ::togglevisions );
    self add_option( "main2", "Debug Exit", ::debugexit );
    self add_option( "main2", "Save & Load", ::togglesaveload );
    self add_option( "main2", "One Shot Kill", ::oneshotkilltoggle );
    self add_option( "main2", "Snake", ::togglesnake );
    self add_option( "main2", "Drop Item", ::dropweap );
    self add_option( "main2", "Ghostwalker", ::ghostwalker );
    self add_option( "main2", "Revive", ::self_revive_when_dead );
    self add_option( "main2", "--->Health Menu", ::submenu, "hp", "health Menu" );
    self add_option( "main2", "--->FOV Menu", ::submenu, "fov", "fov Menu" );
    self add_menu( "man", "main", "VIP" );
    self add_option( "man", "Bubble Man", ::bubbleman );
    self add_option( "man", "Teddy Mask", ::teddymask );
    self add_option( "man", "Juggernog Man", ::jugman );
    self add_option( "man", "Explosive Man", ::explosiveman );
    self add_option( "man", "Skull Head", ::toggleskull4head );
    self add_option( "man", "Ball Feet", ::ballfeet );
    self add_option( "man", "Whiteball Feet", ::whiteballfeet );
    self add_option( "man", "Human Centipede", ::initcentipede );
    self add_option( "man", "Blink Man", ::initblinkman );
    self add_option( "man", "Arrow Man", ::initarrowman );
    self add_option( "man", "Cube Man", ::initcubeman );
    self add_option( "man", "Light Man", ::initlight );
    self add_option( "man", "Wood Man", ::initwood );
    self add_option( "man", "PAP Man", ::initpackapunch );
    self add_option( "man", "Upgrade Man", ::initupgrade );
    self add_menu( "fov", "main2", "VIP" );
    self add_option( "fov", "Default FOV", ::setfov, 65 );
    self add_option( "fov", "75 Fov", ::setfov, 75 );
    self add_option( "fov", "85 Fov", ::setfov, 85 );
    self add_option( "fov", "95 Fov", ::setfov, 95 );
    self add_option( "fov", "105 Fov", ::setfov, 105 );
    self add_option( "fov", "115 Fov", ::setfov, 115 );
    self add_option( "fov", "125 Fov", ::setfov, 125 );
    self add_option( "fov", "135 Fov", ::setfov, 135 );
    self add_option( "fov", "145 Fov", ::setfov, 145 );
    self add_option( "fov", "155 Fov", ::setfov, 155 );
    self add_menu( "hp", "main2", "VIP" );
    self add_option( "hp", "100 HP", ::sethp, 100 );
    self add_option( "hp", "250 HP", ::sethp, 250 );
    self add_option( "hp", "500 HP", ::sethp, 500 );
    self add_option( "hp", "1000 HP", ::sethp, 1000 );
    self add_option( "hp", "2000 HP", ::sethp, 2000 );
    self add_option( "hp", "3000 HP", ::sethp, 3000 );
    self add_option( "hp", "10000 HP", ::sethp, 10000 );
    self add_option( "hp", "20000 HP", ::sethp, 20000 );
    self add_option( "hp", "30000 HP", ::sethp, 30000 );
    self add_option( "hp", "100000 HP", ::sethp, 100000 );
    self add_option( "hp", "200000 HP", ::sethp, 200000 );
    self add_option( "hp", "300000 HP", ::sethp, 300000 );
    self add_option( "hp", "999999 HP", ::sethp, 999999 );
    self add_option( "hp", "1000000 HP", ::sethp, 1000000 );
    self add_option( "hp", "2500000 HP", ::sethp, 2500000 );
    self add_menu( "scr", "main", "VIP" );
    self add_option( "scr", "+100 Score", ::givescore, 100 );
    self add_option( "scr", "+500 Score", ::givescore, 500 );
    self add_option( "scr", "+1000 Score", ::givescore, 1000 );
    self add_option( "scr", "+2500 Score", ::givescore, 2500 );
    self add_option( "scr", "+5000 Score", ::givescore, 5000 );
    self add_option( "scr", "+10000 Score", ::givescore, 10000 );
    self add_option( "scr", "+25000 Score", ::givescore, 25000 );
    self add_option( "scr", "+50000 Score", ::givescore, 50000 );
    self add_option( "scr", "Max Score", ::givescore, 1000000 );
    self add_option( "scr", "-100 Score", ::takescore, 100 );
    self add_option( "scr", "-500 Score", ::takescore, 500 );
    self add_option( "scr", "-1000 Score", ::takescore, 1000 );
    self add_option( "scr", "-2500 Score", ::takescore, 2500 );
    self add_option( "scr", "-5000 Score", ::takescore, 5000 );
    self add_option( "scr", "-10000 Score", ::takescore, 10000 );
    self add_option( "scr", "-25000 Score", ::takescore, 25000 );
    self add_option( "scr", "-50000 Score", ::takescore, 50000 );
    self add_option( "scr", "Take All Score", ::takescore, 1000000 );
    self add_menu( "fun", self.menuname, "VIP" );
    self add_option( "fun", "Advanced Flymode", ::startnoclip );
    self add_option( "fun", "Jetpack", ::togglejetpack );
    self add_option( "fun", "PHP Flopper", ::togglephd );
    self add_option( "fun", "Death Skull", ::toggledeathskull );
    self add_option( "fun", "Solid Sphere", ::spawnsolidsphere );
    self add_option( "fun", "Advanced Forge", ::toggleadvforge );
    self add_option( "fun", "Sky Trip", ::skytrip );
    self add_option( "fun", "Valkyrie Missiles", ::valkyriemissiles );
    self add_option( "fun", "Nuke Nades", ::togglenukenades );
    self add_option( "fun", "Force Field", ::toggleforcefield );
    self add_option( "fun", "White Zombies", ::zmdebug, "defaultactor" );
    self add_option( "fun", "Ball Zombies", ::zmdebug, "test_sphere_silver" );
    self add_option( "fun", "Flyable Car", ::flyablecar );
    self add_option( "fun", "Earth Quake", ::quake );
    self add_option( "fun", "Ice Skater", ::dosk8r );
    self add_option( "fun", "Sphere Cannon", ::spacespherecannon );
    self add_option( "fun", "Walking AC130", ::walkingac130 );
    self add_option( "fun", "Health Bar", ::inithealthbar );
    self add_option( "fun", "---->Next Page", ::submenu, "fun2", "Fun Paged 2" );
    self add_menu( "fun2", "fun", "VIP" );
    self add_option( "fun2", "Spawn Fake Jug", ::fakejug );
    self add_option( "fun2", "Spawn Fake Tap", ::faketap );
    self add_option( "fun2", "Blow Job", ::shesuccme );
    self add_option( "fun2", "Semtex Gun", ::toggleshootsemtex );
    self add_option( "fun2", "Do A Jump", ::tptotehsky );
    self add_option( "fun2", "Raining Balls", ::togglesphererain );
    self add_option( "fun2", "Bunny Jump", ::togglebunnyhop );
    self add_option( "fun2", "Kill Texts", ::togglekilltext );
    self add_option( "fun2", "Death Ops", ::toggledeathops );
    self add_option( "fun2", "Clone", ::clone_me );
    self add_option( "fun2", "Kamikaze", ::dokamikaze );
    self add_option( "fun2", "Artillery", ::w3x );
    self add_option( "fun2", "Rubiks Cube", ::rubix );
    self add_option( "fun2", "Custom Sights", ::customsights );
    self add_option( "fun2", "Ball To Space", ::obj_to_space, "test_sphere_silver" );
    self add_option( "fun2", "Ted To Space", ::obj_to_space, "zombie_teddybear" );
    self add_option( "fun2", "--> Next Page", ::submenu, "fun3", "Fun Paged 3" );
    self add_menu( "fun3", "fun2", "VIP" );
    self add_option( "fun3", "Jeff", ::rofljeff );
    self add_option( "fun3", "Evil Ball", ::initevilball );
    self add_option( "fun3", "Twister", ::twister );
    self add_option( "fun3", "Unlimited Twister", ::twisted );
    self add_option( "fun3", "Clone Pair", ::clonepair );
    self add_menu( "camo", "weaponry", "Verified" );
    self add_option( "camo", "Default", ::camo_change, 0 );
    self add_option( "camo", "PAP 1", ::camo_change, 39 );
    self add_option( "camo", "PAP 2", ::camo_change, 40 );
    self add_option( "camo", "PAP 3", ::camo_change, 45 );
    self add_menu( "weaponry", self.menuname, "Verified" );
    self add_option( "weaponry", "UnPaP guns", ::submenu, "non", "UnPaP guns" );
    self add_option( "weaponry", "PaP Guns", ::submenu, "pap", "PaP Guns" );
    self add_option( "weaponry", "Weapon Camos", ::submenu, "camo", "Weapon Camos" );
    self add_option( "weaponry", "Equip & Melee", ::submenu, "weaponsm", "Equip & Melee" );

    if ( self.status == "Host" || self.status == "Co-Host" || self.status == "Admin" )
    {
        self add_option( "weaponry", "Modded Guns", ::submenu, "mwep", "Modded Guns" );
        self add_option( "weaponry", "Modded Bullets", ::submenu, "bulletsmenu", "Bullets Menu" );
        self add_option( "weaponry", "Bullets Fx", ::submenu, "bulletsfxmenu", "Bullets FX" );

        if ( level.script == "zm_tomb" )
            self add_option( "weaponry", "Origins Staffs", ::submenu, "weaponslist", "Origins Staff" );
    }

    self add_option( "weaponry", "Weapon Selector", ::pickrealweapon );
    self add_option( "weaponry", "Rayguns", ::giverayguns );

    if ( level.script == "zm_prison" )
        self add_option( "weaponry", "Afterlife Hands", ::givetheweapon, "lightning_hands_zm" );

    self add_option( "weaponry", "JetGun", ::givetheweapon, "jetgun_zm" );
    self add_option( "weaponry", "Unlimited Jetgun", ::togglenooverheat );
    self add_menu( "weaponsm", "weaponry", "Verified" );
    self add_option( "weaponsm", "Riot Shield", ::doweapon, "riotshield_zm" );
    self add_option( "weaponsm", "Emp Grenade", ::doweapon, "emp_grenade_zm" );
    self add_option( "weaponsm", "Galva Knuckles", ::doknife, "tazer_knuckles_zm" );
    self add_option( "weaponsm", "Turbine", ::doequipment, "equip_turbine_zm" );
    self add_option( "weaponsm", "Electric Trap", ::doequipment, "equip_electrictrap_zm" );
    self add_option( "weaponsm", "Turret Mower", ::doequipment, "equip_turret_zm" );
    self add_menu( "mwep", "weaponry", "Admin" );
    self add_option( "mwep", "Sphere Gun", ::togglesolidspheregun );
    self add_option( "mwep", "Teddy Gun", ::teddygun );
    self add_option( "mwep", "Grapple Gun", ::togglegrapplegun );
    self add_option( "mwep", "Valkery Missiles", ::valkyriemissiles );
    self add_option( "mwep", "Fling Gun", ::toggleflinggun );
    self add_option( "mwep", "Lambert Ball Gun", ::togglelamball );
    self add_option( "mwep", "Teleport Gun", ::teleportgun );
    self add_option( "mwep", "Ricochet Gun", ::tgl_ricochet );
    self add_option( "mwep", "Explosive Gun", ::toggle_bullets );
    self add_option( "mwep", "Flamethrower", ::fth );
    self add_menu( "weaponslist", "weaponry", "Admin" );
    self add_option( "weaponslist", "staff_air_upgraded_zm", ::giveupgstaffs, "staff_air_upgraded_zm" );
    self add_option( "weaponslist", "staff_water_upgraded_zm", ::giveupgstaffs, "staff_water_upgraded_zm" );
    self add_option( "weaponslist", "staff_lightning_upgraded_zm", ::giveupgstaffs, "staff_lightning_upgraded_zm" );
    self add_option( "weaponslist", "staff_fire_upgraded_zm", ::giveupgstaffs, "staff_fire_upgraded_zm" );
    self add_option( "weaponslist", "staff_air_zm", ::givetheweapon, "staff_air_zm" );
    self add_option( "weaponslist", "staff_water_zm", ::givetheweapon, "staff_water_zm" );
    self add_option( "weaponslist", "staff_lightning_zm", ::givetheweapon, "staff_lightning_zm" );
    self add_option( "weaponslist", "staff_fire_zm", ::givetheweapon, "staff_fire_zm" );
    self add_menu( "bulletsfxmenu", "weaponry", "Admin" );
    self add_option( "bulletsfxmenu", "Reset Bullets FX", ::normalbulletsfx );
    self add_option( "bulletsfxmenu", "Zombie Gib", ::loopbulletsfx, "zomb_gib" );
    self add_option( "bulletsfxmenu", "Debris", ::loopbulletsfx, "grenade_samantha_steal" );
    self add_option( "bulletsfxmenu", "Powerup", ::loopbulletsfx, "powerup_grabbed" );
    self add_option( "bulletsfxmenu", "Fire", ::loopbulletsfx, "character_fire_death_sm" );
    self add_option( "bulletsfxmenu", "Blood Explosion", ::loopbulletsfx, "zombie_guts_explosion" );
    self add_option( "bulletsfxmenu", "Rise", ::loopbulletsfx, "rise_burst" );

    if ( level.script == "zm_transit" )
    {
        self add_option( "bulletsfxmenu", "Turbine", ::loopbulletsfx, "turbine_on" );
        self add_option( "bulletsfxmenu", "Avogadro", ::loopbulletsfx, "avogadro_health_half" );
        self add_option( "bulletsfxmenu", "Lava", ::loopbulletsfx, "lava_burning" );
        self add_option( "bulletsfxmenu", "Screecher", ::loopbulletsfx, "screecher_death" );
        self add_option( "bulletsfxmenu", "Electric Trap", ::loopbulletsfx, "etrap_on" );
        self add_option( "bulletsfxmenu", "Jetgun Kill", ::loopbulletsfx, "jetgun_meat_grinder" );
    }
    else if ( level.script == "zm_buried" )
    {
        self add_option( "bulletsfxmenu", "Petrifier Exp.", ::loopbulletsfx, "zombie_slowgun_explosion_ug" );
        self add_option( "bulletsfxmenu", "Barrier Break", ::loopbulletsfx, "barrier_break" );
        self add_option( "bulletsfxmenu", "Petrifier Sizzle", ::loopbulletsfx, "zombie_slowgun_sizzle_ug" );
        self add_option( "bulletsfxmenu", "Subwoofer", ::loopbulletsfx, "subwoofer_audio_wave" );
        self add_option( "bulletsfxmenu", "Time Bomb Kill", ::loopbulletsfx, "time_bomb_kills_enemy" );
        self add_option( "bulletsfxmenu", "T.Bomb Set", ::loopbulletsfx, "time_bomb_set" );
    }
    else if ( level.script == "zm_tomb" )
    {
        self add_option( "bulletsfxmenu", "Teleporter", ::loopbulletsfx, "teleport_3p" );
        self add_option( "bulletsfxmenu", "Electric", ::loopbulletsfx, "tesla_elec_kill" );
        self add_option( "bulletsfxmenu", "Flame", ::loopbulletsfx, "mech_wpn_flamethrower" );
        self add_option( "bulletsfxmenu", "Digging", ::loopbulletsfx, "digging" );
        self add_option( "bulletsfxmenu", "Wall Drop", ::loopbulletsfx, "crypt_wall_drop" );
        self add_option( "bulletsfxmenu", "Capture", ::loopbulletsfx, "capture_complete" );
    }
    else if ( level.script == "zm_prison" )
    {
        self add_option( "bulletsfxmenu", "Cherry Explode", ::loopbulletsfx, "electric_cherry_explode" );
        self add_option( "bulletsfxmenu", "Brutus", ::loopbulletsfx, "brutus_death" );
        self add_option( "bulletsfxmenu", "Electric", ::loopbulletsfx, "elec_torso" );
        self add_option( "bulletsfxmenu", "Cherry Large", ::loopbulletsfx, "electric_cherry_reload_large" );
        self add_option( "bulletsfxmenu", "Tomahawk Blue", ::loopbulletsfx, "tomahawk_charge_up_ug" );
        self add_option( "bulletsfxmenu", "Tomahawk Red", ::loopbulletsfx, "tomahawk_charge_up" );
    }
    else if ( level.script == "zm_highrise" )
    {
        self add_option( "bulletsfxmenu", "Sliq Splatter", ::loopbulletsfx, "slipgun_explode" );
        self add_option( "bulletsfxmenu", "Poltergeist", ::loopbulletsfx, "poltergeist" );
        self add_option( "bulletsfxmenu", "Dragon Breath", ::loopbulletsfx, "fx_highrise_dragon_breath_max" );
        self add_option( "bulletsfxmenu", "Sliq Explode", ::loopbulletsfx, "slipgun_explode" );
        self add_option( "bulletsfxmenu", "Leap Death", ::loopbulletsfx, "leaper_death" );
        self add_option( "bulletsfxmenu", "Electric", ::loopbulletsfx, "elec_torso" );
    }

    self add_menu( "bulletsmenu", "weaponry", "Admin" );
    self add_option( "bulletsmenu", "Reset Bullets", ::normalbullets );
    self add_option( "bulletsmenu", "Raygun", ::loopbullets, "ray_gun_zm" );
    self add_option( "bulletsmenu", "Raygun PAP", ::loopbullets, "ray_gun_upgraded_zm" );
    self add_option( "bulletsmenu", "Raygun Mark 2", ::loopbullets, "raygun_mark2_zm" );
    self add_option( "bulletsmenu", "Raygun Mark 2 PAP", ::loopbullets, "raygun_mark2_upgraded_zm" );
    self add_option( "bulletsmenu", "DSR-50", ::loopbullets, "dsr50_upgraded_zm" );

    if ( level.script == "zm_transit" )
    {
        self add_option( "bulletsmenu", "RPG", ::loopbullets, "usrpg_upgraded_zm" );
        self add_option( "bulletsmenu", "Mustang & Sally", ::loopbullets, "m1911_upgraded_zm" );
    }
    else if ( level.script == "zm_buried" )
    {
        self add_option( "bulletsmenu", "RPG", ::loopbullets, "usrpg_upgraded_zm" );
        self add_option( "bulletsmenu", "Mustang & Sally", ::loopbullets, "m1911_upgraded_zm" );
    }
    else if ( level.script == "zm_tomb" )
    {
        self add_option( "bulletsmenu", "Kimat's Bite", ::loopbullets, "staff_lightning_upgraded3_zm" );
        self add_option( "bulletsmenu", "K.Blood", ::loopbullets, "staff_fire_upgraded3_zm" );
        self add_option( "bulletsmenu", "Ull's Arrow", ::loopbullets, "staff_water_upgraded3_zm" );
        self add_option( "bulletsmenu", "Air Staff", ::loopbullets, "staff_air_zm" );
        self add_option( "bulletsmenu", "Boomhilda", ::loopbullets, "c96_upgraded_zm" );
    }
    else if ( level.script == "zm_prison" )
    {
        self add_option( "bulletsmenu", "Mustang & Sally", ::loopbullets, "m1911_upgraded_zm" );
        self add_option( "bulletsmenu", "Blundersplat", ::loopbullets, "blundersplat_bullet_zm" );
        self add_option( "bulletsmenu", "Minigun", ::loopbullets, "minigun_alcatraz_upgraded_zm" );
    }
    else if ( level.script == "zm_highrise" )
    {
        self add_option( "bulletsmenu", "RPG", ::loopbullets, "usrpg_upgraded_zm" );
        self add_option( "bulletsmenu", "Mustang & Sally", ::loopbullets, "m1911_upgraded_zm" );
    }

    self add_menu( "non", "weaponry", "VIP" );
    self add_option( "non", "Raygun", ::newweap, "ray_gun_zm" );
    self add_option( "non", "Raygun Mark 2", ::newweap, "raygun_mark2_zm" );
    self add_option( "non", "Default Gun", ::newweap, "defaultweapon_mp" );
    self add_option( "non", "Knife Ballistic", ::newweap, "knife_ballistic_zm" );
    self add_option( "non", "Galil", ::newweap, "galil_zm" );
    self add_option( "non", "Monkey Bomb", ::newweap, "cymbal_monkey_zm" );
    self add_option( "non", "JetGun", ::newweap, "jetgun_zm" );
    self add_option( "non", "RPG", ::newweap, "usrpg_zm" );
    self add_option( "non", "DSR50", ::newweap, "dsr50_zm" );
    self add_option( "non", "M1911", ::newweap, "m1911_zm" );
    self add_option( "non", "Python", ::newweap, "python_zm" );
    self add_option( "non", "Hamr", ::newweap, "hamr_zm" );
    self add_option( "non", "B23R", ::newweap, "beretta93r_zm" );
    self add_option( "non", "Remington", ::newweap, "870mcs_zm" );
    self add_option( "non", "Five Sevens", ::newweap, "fiveseven_dw_zm" );
    self add_option( "non", "Kap 40", ::newweap, "kard_zm" );
    self add_option( "non", "Grenade Launcher", ::newweap, "m32_zm" );
    self add_option( "non", "LSAT", ::newweap, "lsat_zm" );
    self add_option( "non", "Next Page-->", ::submenu, "non2", "Normal Guns 2" );
    self add_menu( "non2", "non", "VIP" );
    self add_option( "non2", "Ballista", ::newweap, "ballista_zm" );
    self add_option( "non2", "KSG", ::newweap, "ksg_zm" );
    self add_option( "non2", "PDW 57", ::newweap, "pdw57_zm" );
    self add_option( "non2", "Scar-H", ::newweap, "scar_zm" );
    self add_option( "non2", "Skorpion", ::newweap, "evoskorpion_zm" );
    self add_option( "non2", "Mtar", ::newweap, "tar21_zm" );
    self add_option( "non2", "Type 25", ::newweap, "type95_zm" );
    self add_option( "non2", "SVU Sniper", ::newweap, "svu_zm" );
    self add_menu( "pap", "weaponry", "VIP" );
    self add_option( "pap", "Raygun", ::givetheweapon, "raygun_upgraded_zm" );
    self add_option( "pap", "Raygun Mark 2", ::givetheweapon, "raygun_mark2_upgraded_zm" );
    self add_option( "pap", "Knife Ballistic", ::givetheweapon, "knife_ballistic_upgraded_zm" );
    self add_option( "pap", "Galil", ::givetheweapon, "galil_upgraded_zm" );
    self add_option( "pap", "RPG", ::givetheweapon, "usrpg_upgraded_zm" );
    self add_option( "pap", "DSR50", ::givetheweapon, "dsr50_upgraded_zm" );
    self add_option( "pap", "M1911", ::givetheweapon, "m1911_upgraded_zm" );
    self add_option( "pap", "Cobra", ::givetheweapon, "python_upgraded_zm" );
    self add_option( "pap", "Hamr", ::givetheweapon, "hamr_upgraded_zm" );
    self add_option( "pap", "B23R", ::givetheweapon, "beretta93r_upgraded_zm" );
    self add_option( "pap", "Remington", ::givetheweapon, "870mcs_upgraded_zm" );
    self add_option( "pap", "Five Sevens", ::givetheweapon, "fiveseven_dw_upgraded_zm" );
    self add_option( "pap", "Kap 40", ::givetheweapon, "kard_upgraded_zm" );
    self add_option( "pap", "Grenade launcher", ::givetheweapon, "m32_upgraded_zm" );
    self add_option( "pap", "LSAT", ::givetheweapon, "lsat_upgraded_zm" );
    self add_option( "pap", "Ballista", ::givetheweapon, "ballista_upgraded_zm" );
    self add_option( "pap", "KSG", ::givetheweapon, "ksg_upgraded_zm" );
    self add_option( "pap", "Next Page -->", ::submenu, "pap2", "Pap Guns 2" );
    self add_menu( "pap2", "pap", "VIP" );
    self add_option( "pap2", "PDW 57", ::givetheweapon, "pdw57_upgraded_zm" );
    self add_option( "pap2", "Scar-H", ::givetheweapon, "scar_upgraded_zm" );
    self add_option( "pap2", "Mtar", ::givetheweapon, "tar21_upgraded_zm" );
    self add_option( "pap2", "Type 25", ::givetheweapon, "type95_upgraded_zm" );
    self add_option( "pap2", "SVU Sniper", ::givetheweapon, "svu_upgraded_zm" );
    self add_menu( "forge", self.menuname, "Admin" );
    self add_option( "forge", "Spawn Models", ::submenu, "spml", "Spawn Models" );
    self add_option( "forge", "Adv. Forge", ::toggleadvforge );
    self add_option( "forge", "Spiral Stairs", ::togglespiralstairs );
    self add_option( "forge", "Debug Wave", ::debugwave );
    self add_option( "forge", "Bounce Spawn", ::spawnbounce );
    self add_option( "forge", "Platform", ::toggleplatform );
    self add_option( "forge", "Bunker", ::bunkerthread );
    self add_option( "forge", "Bridge", ::bridgethread );
    self add_option( "forge", "House", ::housethread );
    self add_option( "forge", "Geyser Trap", ::togglegeysertrap );
    self add_option( "forge", "Windmill", ::windmill );
    self add_option( "forge", "Removed", ::removedbuildthread );
    self add_option( "forge", "Fish", ::tehfish );
    self add_option( "forge", "Sky text", ::tehalexibuscus );
    self add_option( "forge", "Lined Rectangle", ::tehcagesquare );
    self add_menu( "spml", "forge", "Admin" );
    self add_option( "spml", "Silver Sphere", ::spawnmodel, "test_sphere_silver" );
    self add_option( "spml", "White Sphere", ::spawnmodel, "test_sphere_lambert" );
    self add_option( "spml", "Fake Jug", ::spawnmodel, "zombie_vending_jugg" );
    self add_option( "spml", "Buildable Pap", ::spawnmodel, "p6_anim_zm_buildable_pap" );
    self add_option( "spml", "White Car", ::spawnmodel, "defaultvehicle" );
    self add_option( "spml", "White Man", ::spawnmodel, "defaultactor" );
    self add_option( "spml", "Teddy", ::spawnmodel, "zombie_teddybear" );
    self add_option( "spml", "Skull", ::spawnmodel, "zombie_skull" );
    self add_menu( "teleportmenu", self.menuname, "VIP" );

    if ( level.script == "zm_transit" )
    {
        self add_option( "teleportmenu", "Town", ::teletocoords, ( 1137.65, -118.551, -55.875 ), "Town" );
        self add_option( "teleportmenu", "Power Cabin", ::teletocoords, ( 10921.9, 7517.21, -588.588 ), "Power Cabin" );
        self add_option( "teleportmenu", "Nacht", ::teletocoords, ( 13936.2, -635.859, -44.875 ), "Nacht" );
        self add_option( "teleportmenu", "Farm", ::teletocoords, ( 8117.78, -6214.3, 249.098 ), "Farm" );
        self add_option( "teleportmenu", "Diner", ::teletocoords, ( -4963.28, -7402, -62.5062 ), "Diner" );
        self add_option( "teleportmenu", "Bus Depot", ::teletocoords, ( -6843.47, 4953.65, -54.5058 ), "Bus Depot" );
        self add_option( "teleportmenu", "Wood Cabin", ::teletocoords, ( 5146.29, 6853.49, -24.875 ), "Wood Cabin" );
    }
    else if ( level.script == "zm_highrise" )
    {
        self add_option( "teleportmenu", "Spawn", ::teletocoords, ( 1607.48, 1448.55, 3392.13 ), "Spawn" );
        self add_option( "teleportmenu", "Slide", ::teletocoords, ( 2147.2, 2556.88, 3041.31 ), "Slide" );
        self add_option( "teleportmenu", "Broken Elevator", ::teletocoords, ( 3434.13, 1809.39, 3060.12 ), "Broken Elevator" );
        self add_option( "teleportmenu", "Red Room", ::teletocoords, ( 3216.85, 1416.01, 1307.19 ), "Red Room" );
        self add_option( "teleportmenu", "Bank/Power", ::teletocoords, ( 2160, 312.291, 1296.13 ), "Bank/Power" );
        self add_option( "teleportmenu", "Roof", ::teletocoords, ( 1921.88, 50.4671, 2880.13 ), "Roof" );
        self add_option( "teleportmenu", "Main Room", ::teletocoords, ( 2079.77, 1356.32, 3040.13 ), "Main Room" );
    }
    else if ( level.script == "zm_buried" )
    {
        self add_option( "teleportmenu", "Spawn", ::teletocoords, ( -2403.78, -394.211, 1360.13 ), "Spawn" );
        self add_option( "teleportmenu", "Under Spawn", ::teletocoords, ( -2466.17, -477.139, 1243.73 ), "Under Spawn" );
        self add_option( "teleportmenu", "Bank", ::teletocoords, ( -418.484, -68.7916, 8.125 ), "Bank" );
        self add_option( "teleportmenu", "Leroy Cell", ::teletocoords, ( -1037.55, 812.772, 8.125 ), "Leroy Cell" );
        self add_option( "teleportmenu", "Bar Saloon", ::teletocoords, ( 1000.82, -1217.33, 56.125 ), "Bar Saloon" );
        self add_option( "teleportmenu", "Middle Maze", ::teletocoords, ( 5006.54, 572.425, 4.125 ), "Middle Maze" );
        self add_option( "teleportmenu", "Power", ::teletocoords, ( 668.865, -470.07, 139.582 ), "Power" );
    }
    else if ( level.script == "zm_tomb" )
    {
        self add_option( "teleportmenu", "Out Of Map", ::teletocoords, ( -1944.79, 1424.31, 153.099 ), "Out Of Map" );
        self add_option( "teleportmenu", "Spawn", ::teletocoords, ( 2468.62, 4649.14, -307.633 ), "Spawn" );
        self add_option( "teleportmenu", "Top PAP", ::teletocoords, ( -136.254, 5.79077, 320.125 ), "Top PAP" );
        self add_option( "teleportmenu", "Church", ::teletocoords, ( 539.586, -2651.5, 365.578 ), "Church" );
        self add_option( "teleportmenu", "Bottom PAP", ::teletocoords, ( 7.89998, -3.12169, -751.875 ), "Bottom PAP" );
        self add_option( "teleportmenu", "Dead Robot", ::teletocoords, ( -275.809, 5529.84, -347.542 ), "Dead Robot" );
    }
    else if ( level.script == "zm_prison" )
    {
        self add_option( "teleportmenu", "Spawn", ::teletocoords, ( 1332.91, 10592.3, 1336.13 ), "Spawn" );
        self add_option( "teleportmenu", "Dog 1", ::teletocoords, ( 877.817, 9665.62, 1443.13 ), "Dog 1" );
        self add_option( "teleportmenu", "Dog 2", ::teletocoords, ( 3741.54, 9685.4, 1528.13 ), "Dog 2" );
        self add_option( "teleportmenu", "Dog 3", ::teletocoords, ( 97.1212, 6110.39, 23.9622 ), "Dog 3" );
        self add_option( "teleportmenu", "Sniper Tower", ::teletocoords, ( -26.0855, 5583.48, 600.503 ), "Sniper Tower" );
        self add_option( "teleportmenu", "Roof", ::teletocoords, ( 1460.43, 9368.6, 1704.13 ), "Roof" );
    }

    self add_menu( "modelslist", self.menuname, "Verified" );
    self add_option( "modelslist", "Third Person", ::togglet3 );
    self add_option( "modelslist", "Reset Model", ::resetmodel );
    self add_option( "modelslist", "Default Actor", ::changeselfmodel, "defaultactor", "Default Actor" );

    if ( level.script == "zm_transit" )
    {
        self add_option( "modelslist", "Reporter", ::changeselfmodel, "c_zom_player_reporter_fb", "Reporter" );
        self add_option( "modelslist", "Engineer", ::changeselfmodel, "c_zom_player_engineer_fb", "Engineer" );
        self add_option( "modelslist", "Farm Girl", ::changeselfmodel, "c_zom_player_farmgirl_fb", "Farm Girl" );
        self add_option( "modelslist", "Old Man", ::changeselfmodel, "c_zom_player_oldman_fb", "Old Man" );
        self add_option( "modelslist", "Avogadro", ::changeselfmodel, "c_zom_avagadro_fb", "Avogadro" );
        self add_option( "modelslist", "Bus Driver", ::changeselfmodel, "p6_anim_zm_bus_driver", "Bus Driver" );
        self add_option( "modelslist", "Zombie 1", ::changeselfmodel, "c_zom_zombie1_body01", "Zombie 1" );
        self add_option( "modelslist", "Zombie 2", ::changeselfmodel, "c_zom_zombie1_body02", "Zombie 2" );
    }
    else if ( level.script == "zm_buried" )
    {
        self add_option( "modelslist", "Engineer", ::changeselfmodel, "c_zom_player_engineer_fb", "Engineer" );
        self add_option( "modelslist", "Farm Girl", ::changeselfmodel, "c_zom_player_farmgirl_fb", "Farm Girl" );
        self add_option( "modelslist", "Old Man", ::changeselfmodel, "c_zom_player_oldman_fb", "Old Man" );
        self add_option( "modelslist", "Ghost", ::changeselfmodel, "c_zom_zombie_buried_ghost_woman_fb", "Ghost" );
        self add_option( "modelslist", "Leroy", ::changeselfmodel, "c_zom_buried_sloth_fb", "Leroy" );
        self add_option( "modelslist", "Female Zombie 1", ::changeselfmodel, "c_zom_zombie_buried_sgirl_body1", "Female Zombie 1" );
        self add_option( "modelslist", "Female Zombie 2", ::changeselfmodel, "c_zom_zombie_buried_sgirl_body2", "Female Zombie 2" );

        for ( v0 = 1; v0 < 6; v0++ )
            self add_option( "modelslist", "Male Zombie " + v0, ::changeselfmodel, "c_zom_zombie_buried_civilian_body" + v0, "Male Zombie " + v0 );
    }
    else if ( level.script == "zm_tomb" )
    {
        self add_option( "modelslist", "Dempsey", ::changeselfmodel, "c_zom_tomb_dempsey_fb", "Dempsey" );
        self add_option( "modelslist", "Nikolai", ::changeselfmodel, "c_zom_tomb_nikolai_fb", "Nikolai" );
        self add_option( "modelslist", "Richtofen", ::changeselfmodel, "c_zom_tomb_richtofen_fb", "Richtofen" );
        self add_option( "modelslist", "Takeo", ::changeselfmodel, "c_zom_tomb_takeo_fb", "Takeo" );
        self add_option( "modelslist", "Panzer", ::changeselfmodel, "c_zom_mech_body", "Panzer" );
        self add_option( "modelslist", "Zombie", ::changeselfmodel, "c_zom_tomb_german_body2", "Zombie" );
    }
    else if ( level.script == "zm_prison" )
    {
        self add_option( "modelslist", "Arlington", ::changeselfmodel, "c_zom_player_arlington_fb", "Arlington" );
        self add_option( "modelslist", "deLuca", ::changeselfmodel, "c_zom_player_deluca_fb", "deLuca" );
        self add_option( "modelslist", "Handsome", ::changeselfmodel, "c_zom_player_handsome_fb", "Handsome" );
        self add_option( "modelslist", "Olearly", ::changeselfmodel, "c_zom_player_oleary_fb", "Olearly" );
        self add_option( "modelslist", "Brutus", ::changeselfmodel, "c_zom_cellbreaker_fb", "Brutus" );
        self add_option( "modelslist", "Zombie 1", ::changeselfmodel, "c_zom_guard_body", "Zombie 1" );
        self add_option( "modelslist", "Zombie 2", ::changeselfmodel, "c_zom_inmate_body1", "Zombie 2" );
        self add_option( "modelslist", "Zombie 3", ::changeselfmodel, "c_zom_inmate_body2", "Zombie 3" );
    }
    else if ( level.script == "zm_highrise" )
    {
        self add_option( "modelslist", "Reporter", ::changeselfmodel, "c_zom_player_reporter_dlc1_fb", "Reporter" );
        self add_option( "modelslist", "Engineer", ::changeselfmodel, "c_zom_player_engineer_dlc1_fb", "Engineer" );
        self add_option( "modelslist", "Farm Girl", ::changeselfmodel, "c_zom_player_farmgirl_dlc1_fb", "Farm Girl" );
        self add_option( "modelslist", "Old Man", ::changeselfmodel, "c_zom_player_oldman_dlc1_fb", "Old Man" );
        self add_option( "modelslist", "Leaper", ::changeselfmodel, "c_zom_leaper_body", "Leaper" );
        self add_option( "modelslist", "Zombie 1", ::changeselfmodel, "c_zom_zombie_civ_shorts_body", "Zombie 1" );

        for ( v0 = 2; v0 < 7; v0++ )
            self add_option( "modelslist", "Zombie " + v0, ::changeselfmodel, "c_zom_zombie_civ_shorts_body" + v0, "Zombie " + v0 );
    }
    else if ( level.script == "zm_nuked" )
    {
        self add_option( "modelslist", "CDC", ::changeselfmodel, "c_zom_player_cdc_fb", "CDC" );
        self add_option( "modelslist", "CIA", ::changeselfmodel, "c_zom_player_cia_fb", "CIA" );
        self add_option( "modelslist", "Zombie 1", ::changeselfmodel, "c_zom_dlc0_zom_haz_body1", "Zombie 1" );
        self add_option( "modelslist", "Zombie 2", ::changeselfmodel, "c_zom_dlc0_zom_haz_body2", "Zombie 2" );
    }

    self add_menu( "aim", self.menuname, "Admin" );
    self add_option( "aim", "Aimbot", ::togglelozaimbot );
    self add_option( "aim", "Aim Required", ::toggleaimtype );
    self add_option( "aim", "Change Bone Tag", ::togglebonetag );

    if ( self ishost() )
        self add_option( "aim", "Visible Check", ::togglevisiblecheck );

    self add_option( "aim", "Unfair", ::toggleunfair );
    self add_option( "aim", "Auto Shoot", ::toggleautoshoot );
    self add_option( "aim", "Sniper Crosshair Aimbot", ::togglecrosshairaimbot );
    self add_menu( "acc", self.menuname, "Admin" );
    self add_option( "acc", "Pick Custom Value", ::pickcustomstatsvalue );
    self add_option( "acc", "Custom Stats", ::givecustomstats );
    self add_option( "acc", "Low Stats", ::customstats, "Low" );
    self add_option( "acc", "Legit Stats", ::customstats, "Legit" );
    self add_option( "acc", "High Stats", ::customstats, "High" );
    self add_option( "acc", "Trophies", ::unlocktrophies );
    self add_option( "acc", "Shotgun Rank", ::shotgunrank );
    self add_option( "acc", "Bone Rank", ::bonerank );
    self add_menu( "lobby", self.menuname, "Co-Host" );
    self add_option( "lobby", "Gravity", ::gravity );
    self add_option( "lobby", "Knockback Lobby", ::toggleknockback );
    self add_option( "lobby", "Super Speed", ::togglesuperspeed );
    self add_option( "lobby", "Super Jump", ::togglesuperjump );
    self add_option( "lobby", "Open All Doors", ::openalldoors );
    self add_option( "lobby", "Restart Game", ::restartgame );
    self add_option( "lobby", "Reload Game", ::reloadmap );
    self add_option( "lobby", "Turn On Power", ::turnonpower );
    self add_option( "lobby", "Zombies Counter", ::drawzombiescounter );
    self add_option( "lobby", "9999 Zombies Limit", ::increasezombieslimit );
    self add_option( "lobby", "Freeze Zombies", ::fr3zzzom );
    self add_option( "lobby", "Pause Game", ::pause );
    self add_option( "lobby", "hear All Players", ::hearall );
    self add_option( "lobby", "Time Scale", ::changetimescale );
    self add_option( "lobby", "Round Editor", ::roundslider );
    self add_option( "lobby", "Gun Game", ::dogungame );
    self add_option( "lobby", "---> Next Page", ::submenu, "lobby2", "Lobby Paged 2" );
    self add_menu( "lobby2", "lobby", "Co-Host" );
    self add_option( "lobby2", "Perks Freezer", ::perkfreeze );
    self add_option( "lobby2", "Zombie Boss", ::callzombieboss );
    self add_option( "lobby2", "Rapid Fire", ::togglerapidfire );
    self add_option( "lobby2", "Spin Text", ::initspintext );
    self add_option( "lobby2", "Remove Deathbarriers", ::toggledeathbarriers );
    self add_option( "lobby2", "Anti-Join", ::toggleantijoin );
    self add_option( "lobby2", "Anti-Quit", ::antiquit );
    self add_option( "lobby2", "Spawn Bot", ::spawnbot_zm );
    self add_option( "lobby2", "Hide Box", ::box_handler, 1 );
    self add_option( "lobby2", "Show Box", ::box_handler, 2 );
    self add_option( "lobby2", "Unlimited Box", ::box_handler, 3 );
    self add_option( "lobby2", "Infinite Claymore", ::unl_claymore );
    self add_option( "lobby2", "Spectate No Spwn", ::spectator_no_spawn );
    self add_menu( "perksmenu", self.menuname, "VIP" );
    self add_option( "perksmenu", "Juggernog", ::givemenuperk, "specialty_armorvest", "zombie_perk_bottle_jugg" );
    self add_option( "perksmenu", "Quick Reload", ::givemenuperk, "specialty_fastreload", "zombie_perk_bottle_sleight" );
    self add_option( "perksmenu", "Double Tap", ::givemenuperk, "specialty_rof", "zombie_perk_bottle_doubletap" );

    if ( level.script == "zm_transit" )
    {
        self add_option( "perksmenu", "Quick Revive", ::givemenuperk, "specialty_quickrevive", "zombie_perk_bottle_revive" );
        self add_option( "perksmenu", "Marathon", ::givemenuperk, "specialty_longersprint", "zombie_perk_bottle_marathon" );
    }
    else if ( level.script == "zm_buried" )
    {
        self add_option( "perksmenu", "Quick Revive", ::givemenuperk, "specialty_quickrevive", "zombie_perk_bottle_revive" );
        self add_option( "perksmenu", "Marathon", ::givemenuperk, "specialty_longersprint", "zombie_perk_bottle_marathon" );
        self add_option( "perksmenu", "Vulture Aid", ::givemenuperk, "specialty_nomotionsensor", "zombie_perk_bottle_vulture" );
        self add_option( "perksmenu", "Mulekick", ::givemenuperk, "specialty_additionalprimaryweapon", "zombie_perk_bottle_additionalprimaryweapon" );
    }
    else if ( level.script == "zm_tomb" )
    {
        self add_option( "perksmenu", "Quick Revive", ::givemenuperk, "specialty_quickrevive", "zombie_perk_bottle_revive" );
        self add_option( "perksmenu", "Marathon", ::givemenuperk, "specialty_longersprint", "zombie_perk_bottle_marathon" );
        self add_option( "perksmenu", "Mulekick", ::givemenuperk, "specialty_additionalprimaryweapon", "zombie_perk_bottle_additionalprimaryweapon" );
        self add_option( "perksmenu", "Electric Cherry", ::givemenuperk, "specialty_grenadepulldeath", "zombie_perk_bottle_cherry" );
        self add_option( "perksmenu", "PHD Flopper", ::givemenuperk, "specialty_flakjacket", "zombie_perk_bottle_nuke" );
        self add_option( "perksmenu", "Deadshot", ::givemenuperk, "specialty_deadshot", "zombie_perk_bottle_deadshot" );
    }
    else if ( level.script == "zm_prison" )
    {
        self add_option( "perksmenu", "Electric Cherry", ::givemenuperk, "specialty_grenadepulldeath", "zombie_perk_bottle_cherry" );
        self add_option( "perksmenu", "Deadshot", ::givemenuperk, "specialty_deadshot", "zombie_perk_bottle_deadshot" );
    }
    else if ( level.script == "zm_highrise" )
    {
        self add_option( "perksmenu", "Who's Who", ::givemenuperk, "specialty_finalstand", "zombie_perk_bottle_whoswho" );
        self add_option( "perksmenu", "Quick Revive", ::givemenuperk, "specialty_quickrevive", "zombie_perk_bottle_revive" );
        self add_option( "perksmenu", "Mulekick", ::givemenuperk, "specialty_additionalprimaryweapon", "zombie_perk_bottle_additionalprimaryweapon" );
    }
    else if ( level.script == "zm_nuked" )
        self add_option( "perksmenu", "Quick Revive", ::givemenuperk, "specialty_quickrevive", "zombie_perk_bottle_revive" );

    self add_menu( "powers", self.menuname, "VIP" );
    v1 = getarraykeys( level.zombie_include_powerups );

    for ( v0 = 0; v0 < v1.size; v0++ )
        self add_option( "powers", v1[v0], ::givethepowerup, v1[v0] );

    self add_menu( "costs", self.menuname, "Co-Host" );
    self add_option( "costs", "Box Costs", ::submenu, "costs2", "Box Costs" );
    self add_option( "costs", "Debris & Doors Cost", ::submenu, "costs3", "Debris & Doors" );
    self add_menu( "costs3", "costs", "Co-Host" );
    self add_option( "costs3", "Free", ::setalldebriscost, 0 );
    self add_option( "costs3", "1", ::setalldebriscost, 1 );
    self add_option( "costs3", "10", ::setalldebriscost, 10 );
    self add_option( "costs3", "100", ::setalldebriscost, 100 );
    self add_option( "costs3", "1000", ::setalldebriscost, 1000 );
    self add_option( "costs3", "10000", ::setalldebriscost, 10000 );
    self add_option( "costs3", "100000", ::setalldebriscost, 100000 );
    self add_option( "costs3", "200000", ::setalldebriscost, 200000 );
    self add_option( "costs3", "500000", ::setalldebriscost, 500000 );
    self add_option( "costs3", "1000000", ::setalldebriscost, 1000000 );
    self add_option( "costs3", "2500000", ::setalldebriscost, 2500000 );
    self add_option( "costs3", "5000000", ::setalldebriscost, 5000000 );
    self add_option( "costs3", "9999999", ::setalldebriscost, 9999999 );
    self add_option( "costs3", "214763421", ::setalldebriscost, 214763421 );
    self add_menu( "costs2", "costs", "Co-Host" );
    self add_option( "costs2", "Default Cost", ::changecost, 950 );
    self add_option( "costs2", "Free", ::changecost, 0 );
    self add_option( "costs2", "1 Cost", ::changecost, 1 );
    self add_option( "costs2", "10 Cost", ::changecost, 10 );
    self add_option( "costs2", "100 Cost", ::changecost, 100 );
    self add_option( "costs2", "500 Cost", ::changecost, 500 );
    self add_option( "costs2", "1000 Cost", ::changecost, 1000 );
    self add_option( "costs2", "2000 Cost", ::changecost, 2000 );
    self add_option( "costs2", "3000 Cost", ::changecost, 3000 );
    self add_option( "costs2", "6000 Cost", ::changecost, 6000 );
    self add_option( "costs2", "10000 Cost", ::changecost, 10000 );
    self add_option( "costs2", "25000 Cost", ::changecost, 25000 );
    self add_option( "costs2", "50000 Cost", ::changecost, 50000 );
    self add_option( "costs2", "100000 Cost", ::changecost, 100000 );
    self add_option( "costs2", "200000 Cost", ::changecost, 200000 );
    self add_option( "costs2", "999999 Cost", ::changecost, 999999 );
    self add_option( "costs2", "21476145 Cost", ::changecost, 21476145 );
    self add_menu( "zmse", self.menuname, "Co-Host" );
    self add_option( "zmse", "Animation Menu", ::submenu, "animationsmenu", "Animations" );
    self add_option( "zmse", "Speed Menu", ::submenu, "speedmenu", "Speed" );
    self add_option( "zmse", "kill All Zombies", ::killallzombies );
    self add_option( "zmse", "Zombie Drops", ::toggledroppers );
    self add_option( "zmse", "Headless Zombies", ::detachnohead );
    self add_option( "zmse", "Zombies -> Me", ::telezombiestome );
    self add_option( "zmse", "Disable Spawn", ::togglezombiedisable );
    self add_option( "zmse", "Low Health", ::togglezombielowhealth );
    self add_option( "zmse", "Create Crawlers", ::makecrawlers );
    self add_menu( "animationsmenu", "zmse", "Co-Host" );
    self add_option( "animationsmenu", "Restore Animation", ::stopzombiesanimation );
    self add_option( "animationsmenu", "Inert", ::playzombiesanimation, "zm_inert", "Inert" );
    self add_option( "animationsmenu", "Inert Crawling", ::playzombiesanimation, "zm_inert_crawl", "Inert Crawling" );
    self add_option( "animationsmenu", "Melee Walking", ::playzombiesanimation, "zm_walk_melee", "Melee Walking" );
    self add_option( "animationsmenu", "Melee Running", ::playzombiesanimation, "zm_run_melee", "Melee Running" );
    self add_option( "animationsmenu", "Idle", ::playzombiesanimation, "zm_idle", "Idle" );

    if ( level.script != "zm_tomb" )
    {
        self add_option( "animationsmenu", "Falling Loop", ::playzombiesanimation, "zm_faller_fall_loop", "Falling Loop" );
        self add_option( "animationsmenu", "Falling Land", ::playzombiesanimation, "zm_faller_land", "Falling Land" );
    }

    self add_menu( "speedmenu", "zmse", "Co-Host" );
    self add_option( "speedmenu", "Walk", ::changezombiesrunanim, "walk", "Walking" );
    self add_option( "speedmenu", "Run", ::changezombiesrunanim, "run", "Running" );
    self add_option( "speedmenu", "Sprint", ::changezombiesrunanim, "sprint", "Sprinting" );
    self add_option( "speedmenu", "Super Sprint", ::changezombiesrunanim, "super_sprint", "Super Sprinting" );

    if ( level.script == "zm_transit" )
        self add_option( "speedmenu", "Bus Chase", ::changezombiesrunanim, "chase_bus", "Bus Chase" );

    self add_menu( "host", self.menuname, "Host" );
    self add_option( "host", "Rank Lobby", ::startranklobby );
    self add_option( "host", "Friendly Fire", ::togglehitmarkers );
    self add_option( "host", "Force Host", ::forcehost );
    self add_option( "host", "Toggle FPS", ::togglefps );
    self add_option( "host", "Disco Sun", ::togglediscosun );
    self add_option( "host", "Gore Mode", ::togglegore );
    self add_option( "host", "Lag O Metre", ::drawlagometre );
    self add_option( "host", "Left Gun", ::toggleleft );
    self add_option( "host", "Low Ammo Flash", ::flashlowammo );
    self add_option( "host", "Delete Models", ::printmapmodelstogamesmplog );
    self add_menu( "msg", self.menuname, "Verified" );
    self add_option( "msg", "Custom MSG", ::lozkeyboard );
    self add_option( "msg", "Creator", ::domsg, "^5AlexibuscusGaming Created This Menu" );
    self add_option( "msg", "ReplayModding", ::domsg, "^1ReplayModdingTeam <3" );
    self add_option( "msg", "ItZzDivine", ::domsg, "^4ItZz^5Divine ^1<3" );
    self add_option( "msg", "Host Is <3", ::domsg, "^2" + ( level.hostname + " ^5is Awesome ^1<3" ) );
    self add_option( "msg", "What Menu", ::domsg, "I Am Using Hell's Vengeance V1" );
    self add_option( "msg", "Yes", ::domsg, "Yes" );
    self add_option( "msg", "No", ::domsg, "no" );
    self add_option( "msg", "Hack Lobby", ::domsg, "^2Hacking Lobby.... \n Retrieving Passwords & Emails..." );
    self add_option( "msg", "NGU", ::domsg, "^5Next^7Gen^4Update ^1<3" );
    self add_option( "msg", "Shut Up Squeaker", ::domsg, "^1Shut Up ^7Squeaker \n^2Or How About A ^1Derank!" );
    self add_option( "msg", "Youtube", ::domsg, "^1Youtube.com/c/alexibuscusgaming" );
    self add_option( "msg", "Skype", ::domsg, "^7Alexmodz_alexibuscus <-- Skype" );
    self add_menu( "menu", self.menuname, "Verified" );
    self add_option( "menu", "Menu Theme", ::submenu, "theme", "Menu Themes" );
    self add_option( "menu", "Header Shader", ::submenu, "head", "header Shader" );
    self add_option( "menu", "Color Editor", ::coloreditor, "shader" );
    self add_option( "menu", "Scroller", ::submenu, "scrl", "Scroller" );
    self add_option( "menu", "Move Menu Right", ::rightmenu );
    self add_option( "menu", "Move Menu Left", ::leftmenu );
    self add_option( "menu", "Toggle HUD", ::togglehudvis );
    self add_option( "menu", "Toggle Blur", ::toggleblur );
    self add_menu( "scrl", "menu", "Verified" );
    self add_option( "scrl", "Default", ::changescroll, "white" );
    self add_option( "scrl", "Curved", ::changescroll, "ui_slider2" );
    self add_option( "scrl", "Shotgun", ::changescroll, "zombies_rank_5" );
    self add_option( "scrl", "Knife", ::changescroll, "zombies_rank_4" );
    self add_option( "scrl", "Skull", ::changescroll, "zombies_rank_3" );
    self add_option( "scrl", "Two Bone", ::changescroll, "zombies_rank_2" );
    self add_option( "scrl", "Bone", ::changescroll, "zombies_rank_1" );
    self add_option( "scrl", "Gradient", ::changescroll, "gradient_center" );
    self add_option( "scrl", "Bar", ::changescroll, "progress_bar_bg" );
    self add_option( "scrl", "Chalk 1", ::changescroll, "hud_chalk_1" );
    self add_option( "scrl", "Chalk 2", ::changescroll, "hud_chalk_2" );
    self add_option( "scrl", "Chalk 3", ::changescroll, "hud_chalk_3" );
    self add_option( "scrl", "Treyarch", ::changescroll, "lui_loader_no_offset" );
    self add_menu( "head", "menu", "Verified" );
    self add_option( "head", "Default", ::header, "zombies_rank_5" );
    self add_option( "head", "Knife Skull", ::header, "zombies_rank_4" );
    self add_option( "head", "Skull", ::header, "zombies_rank_3" );
    self add_option( "head", "Crossbones", ::header, "zombies_rank_2" );
    self add_option( "head", "Bone", ::header, "zombies_rank_1" );
    self add_option( "head", "Damage", ::header, "damage_feedback" );
    self add_option( "head", "Insta Kill", ::header, "specialty_instakill_zombies" );
    self add_option( "head", "Fire Sale", ::header, "specialty_firesale_zombies" );
    self add_option( "head", "Mule Kick", ::header, "specialty_additionalprimaryweapon_zombies" );
    self add_menu( "theme", "menu", "Verified" );
    self add_option( "theme", "Blue Theme", ::changemenucolor, ( 0, 0, 1 ), "shade" );
    self add_option( "theme", "Red Theme", ::changemenucolor, ( 1, 0, 0 ), "shade" );
    self add_option( "theme", "Orange Theme", ::changemenucolor, ( 1, 0.503, 0 ), "shade" );
    self add_option( "theme", "Yellow Theme", ::changemenucolor, ( 1, 1, 0 ), "shade" );
    self add_option( "theme", "Aqua Theme", ::changemenucolor, ( 0, 0.4, 1.2 ), "shade" );
    self add_option( "theme", "Purple Theme", ::changemenucolor, ( 0.5, 0, 0.5 ), "shade" );
    self add_option( "theme", "Pink Theme", ::changemenucolor, ( 1, 0, 1 ), "shade" );
    self add_option( "theme", "Green Theme", ::changemenucolor, ( 0, 1, 0 ), "shade" );
    self add_option( "theme", "White Theme", ::changemenucolor, ( 255, 255, 255 ), "shade" );
    self add_option( "theme", "Black Theme", ::changemenucolor, ( 0, 0, 0 ), "shade" );
    self add_menu( "allp", self.menuname, "Co-Host" );
    self add_option( "allp", "Godmode", ::all_handler, 1 );
    self add_option( "allp", "Infinite Ammo", ::all_handler, 2 );
    self add_option( "allp", "Third Person", ::all_handler, 3 );
    self add_option( "allp", "Speed x2", ::all_handler, 4 );
    self add_option( "allp", "Rayguns", ::all_handler, 5 );
    self add_option( "allp", "Kick All", ::all_handler, 6 );
    self add_option( "allp", "Invisible", ::all_handler, 7 );
    self add_option( "allp", "+50k Points", ::all_handler, 8 );
    self add_option( "allp", "-5k Points", ::all_handler, 9 );
    self add_option( "allp", "Max Points", ::all_handler, 10 );
    self add_option( "allp", "All Ballfeet", ::all_handler, 11 );
    self add_option( "allp", "Freeze All", ::all_handler, 12 );
    self add_option( "allp", "Skytrip", ::all_handler, 13 );
    self add_option( "allp", "TP -> Prison", ::all_handler, 14 );
    self add_option( "allp", "Semtex Gun", ::all_handler, 15 );
    self add_option( "allp", "Auto Revive", ::auto_revive_lobby );
    self add_option( "allp", "Unlimited Sprint", ::all_handler, 16 );
    self add_option( "allp", "Elite Scoreboard", ::elite_scoreboard );
    self add_option( "allp", "--->Next Page", ::submenu, "allp2", "All Players" );
    self add_menu( "allp2", "allp", "Co-Host" );
    self add_option( "allp2", "Revive Spectators", ::all_handler, 17 );
    self add_option( "allp2", "All To Me", ::all_handler, 18 );
    self add_option( "allp2", "Forge Mode", ::all_handler, 19 );
    self add_option( "allp2", "-99999999 Points", ::all_handler, 20 );
    self add_option( "allp2", "All Bubble Man", ::all_handler, 21 );
    self add_option( "allp2", "All Whoosh In", ::all_handler, 22 );
    self add_option( "allp2", "Custom Sights", ::all_handler, 23 );
    self add_menu( "PlayersMenu", self.menuname, "Co-Host" );

    for ( v0 = 0; v0 < 12; v0++ )
        self add_menu( "pOpt " + v0, "PlayersMenu", "Co-Host" );
}

updateplayersmenu()
{
    self.menu.menucount["PlayersMenu"] = 0;

    for ( v0 = 0; v0 < 12; v0++ )
    {
        v1 = level.players[v0];
        v2 = getplayername( v1 );
        v3 = level.players.size - 1;

        if ( self.menu.curs["PlayersMenu"] > v3 )
        {
            self.menu.scrollerpos["PlayersMenu"] = v3;
            self.menu.curs["PlayersMenu"] = v3;
        }

        self add_option( "PlayersMenu", "[" + ( verificationtocolor( v1.status ) + ( "^7] " + v2 ) ), ::submenu, "pOpt " + v0, "[" + ( verificationtocolor( v1.status ) + ( "^7] " + v2 ) ) );
        v4 = "pOpt " + ( v0 + "_S" );
        v5 = "pOpt " + ( v0 + "_P" );
        v6 = "pOpt " + ( v0 + "_O" );
        v7 = "pOpt " + ( v0 + "_Q" );
        self add_menu_alt( "pOpt " + v0, "PlayersMenu" );
        self add_option( "pOpt " + v0, "Player Status", ::submenu, v4, "Status" );
        self add_option( "pOpt " + v0, "Player Options", ::submenu, v5, "Options" );
        self add_menu( v5, "pOpt " + v0 );
        self add_option( v5, "Godmode", ::player_handler, v1, 1 );
        self add_option( v5, "Infinite Ammo", ::player_handler, v1, 2 );
        self add_option( v5, "Third Person", ::player_handler, v1, 3 );
        self add_option( v5, "Kick Player", ::player_handler, v1, 4 );
        self add_option( v5, "Ban Player", ::player_handler, v1, 5 );
        self add_option( v5, "Forge Mode", ::player_handler, v1, 6 );
        self add_option( v5, "Rayguns", ::player_handler, v1, 7 );
        self add_option( v5, "Speed x2", ::player_handler, v1, 8 );
        self add_option( v5, "Invisible", ::player_handler, v1, 9 );
        self add_option( v5, "Set 1 HP", ::player_handler, v1, 10 );
        self add_option( v5, "Give Jug", ::player_handler, v1, 11 );
        self add_option( v5, "Freeze Player", ::player_handler, v1, 12 );
        self add_option( v5, "Force Field", ::player_handler, v1, 13 );
        self add_option( v5, "Say is Noob", ::player_handler, v1, 14 );
        self add_option( v5, "Low Stats", ::player_handler, v1, 15 );
        self add_option( v5, "High Stats", ::player_handler, v1, 16 );
        self add_option( v5, "Bunny Jump", ::player_handler, v1, 17 );
        self add_option( v5, "---> Next Page", ::submenu, v6, "Options" );
        self add_menu( v6, v5 );
        self add_option( v6, "Bubble Feet", ::player_handler, v1, 18 );
        self add_option( v6, "Fake Hack", ::player_handler, v1, 19 );
        self add_option( v6, "Fake Virus", ::player_handler, v1, 20 );
        self add_option( v6, "+50k Score", ::player_handler, v1, 21 );
        self add_option( v6, "-50K Score", ::player_handler, v1, 22 );
        self add_option( v6, "+500 Score", ::player_handler, v1, 23 );
        self add_option( v6, "-500 Score", ::player_handler, v1, 24 );
        self add_option( v6, "Take Weapons", ::player_handler, v1, 25 );
        self add_option( v6, "All Trophies", ::player_handler, v1, 26 );
        self add_option( v6, "Jail Player", ::jailplayer, v1 );
        self add_option( v6, "Low Scoreboard", ::player_handler, v1, 27 );
        self add_option( v6, "Revive Player", ::player_handler, v1, 28 );
        self add_option( v6, "ShotGun Rank", ::player_handler, v1, 29 );
        self add_option( v6, "Bone Rank", ::player_handler, v1, 30 );
        self add_option( v6, "Blink Man", ::blinkm_player, v1 );
        self add_option( v6, "TP -> Him", ::tele_to_him, v1 );
        self add_option( v6, "TP -> Me", ::tele_to_me, v1 );
        self add_option( v6, "Next Page", ::submenu, v7, "Options" );
        self add_menu( v7, v6 );
        self add_option( v7, "TP To Space", ::player_handler, v1, 32 );
        self add_option( v7, "GhostWalker", ::player_handler, v1, 33 );
        self add_option( v7, "Whoosh In", ::player_handler, v1, 34 );
        self add_option( v7, "Custom Sights", ::player_handler, v1, 35 );
        self add_menu( v4, "pOpt " + v0 );
        self add_option( v4, "Give Co-Host", ::changeverificationmenu, v1, "Co-Host" );
        self add_option( v4, "Give Admin", ::changeverificationmenu, v1, "Admin" );
        self add_option( v4, "Give VIP", ::changeverificationmenu, v1, "VIP" );
        self add_option( v4, "Verify", ::changeverificationmenu, v1, "Verified" );
        self add_option( v4, "Unverify", ::changeverificationmenu, v1, "Unverified" );
    }
}

add_menu_alt( v0, v1 )
{
    self.menu.getmenu[v0] = v0;
    self.menu.menucount[v0] = 0;
    self.menu.previousmenu[v0] = v1;
}

add_menu( v0, v1, v2 )
{
    self.menu.status[v0] = v2;
    self.menu.getmenu[v0] = v0;
    self.menu.scrollerpos[v0] = 0;
    self.menu.curs[v0] = 0;
    self.menu.menucount[v0] = 0;
    self.menu.previousmenu[v0] = v1;
}

add_option( v0, v1, v2, v3, v4 )
{
    v0 = self.menu.getmenu[v0];
    v5 = self.menu.menucount[v0];
    self.menu.menuopt[v0][v5] = v1;
    self.menu.menufunc[v0][v5] = v2;
    self.menu.menuinput[v0][v5] = v3;
    self.menu.menuinput1[v0][v5] = v4;
    self.menu.menucount[v0] = self.menu.menucount[v0] + 1;
}

recreatetext()
{
    self endon( "disconnect" );
    self endon( "death" );
    v0 = self.curmenu;
    v1 = self.curtitle;
    self thread submenu( v0, v1 );
}

overflowfix()
{
    level endon( "game_ended" );
    level.test = createserverfontstring( "default", 1.5 );
    level.test settext( "xTUL" );
    level.test.alpha = 0;

    if ( level.varsarray["isPlayingInputMsg"] )
        level.varsarray["inputMsgString"] setsafetext( level.varsarray["currentInputMsg"] );

    for (;;)
    {
        level waittill( "textset" );

        if ( level.result >= 45 ) // [PS3 PORT] lower threshold for console headroom (was 50)
        {
            level.test clearalltextafterhudelem();
            level.result = 0;

            v0 = level.players;
            for ( v1 = 0; v1 < v0.size; v1++ )
            {
                v2 = v0[v1];
                if ( isdefined( v2.menu ) && isdefined( v2.menu.open ) && v2.menu.open == 1 ) // [PS3 PORT] unverified players have no menu struct
                    v2 recreatetext();

                if ( isdefined( v2.infotext4line5 ) ) // [PS3 PORT] was self (= level) so it never ran
                    v2.infotext4line5 setsafetext( "Developed by: ^FAlexibuscusGaming" );

                if ( isdefined( v2.keyboardvars ) && v2.keyboardvars["isOpen"] )
                {
                    v2.lozkeyboard["info"] setsafetext( v2.keyboardvars["infoText"] );
                    v2.lozkeyboard["result"] setsafetext( v2.keyboardvars["currentResult"] );

                    if ( !v2.keyboardvars["isCaps"] )
                    {
                        for ( v3 = 0; v3 < v2.keyboardvars["keysLow"].size; v3++ )
                            v2.lozkeyboard["keys" + v3] setsafetext( v2.keyboardvars["keysLow"][v3] );

                        continue;
                    }

                    for ( v3 = 0; v3 < v2.keyboardvars["keysLow"].size; v3++ )
                        v2.lozkeyboard["keys" + v3] setsafetext( v2.keyboardvars["keysBig"][v3] );
                }
            }
        }

        wait 0.01;
    }
}

setsafetext( v0 )
{
    level.result = level.result + 1;
    self settext( v0 );
    level notify( "textset" );
}

isverified()
{
    if ( self.status == "Host" || self.status == "Co-Host" || ( self.status == "Admin" || self.status == "VIP" ) || self.status == "Verified" )
        return true;
    else
        return false;
}

player_handler( v0, v1 )
{
    if ( !v0 ishost() || !v0 isverified() )
    {
        if ( v1 == 1 )
        {
            if ( v0.god == 0 )
            {
                v0.god = 1;
                v0 thread godmodev4();
                self iprintln( "Given ^3" + ( v0.name + " ^2Godmode" ) );
            }
            else
            {
                v0.god = 0;
                v0 thread godmodev4();
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Godmode" ) );
            }
        }
        else if ( v1 == 2 )
        {
            if ( v0.ammo == 0 )
            {
                v0.ammo = 1;
                v0 thread toggleinfiniteammo();
                self iprintln( "Given ^3" + ( v0.name + " ^2Infinite Ammo" ) );
            }
            else
            {
                v0.ammo = 0;
                v0 thread toggleinfiniteammo();
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Infinite Ammo" ) );
            }
        }
        else if ( v1 == 3 )
        {
            if ( v0.t3p == 0 )
            {
                v0.t3p = 1;
                v0 setclientthirdperson( 1 );
                self iprintln( "Given ^3" + ( v0.name + " ^2Third Person" ) );
            }
            else
            {
                v0.t3p = 0;
                v0 setclientthirdperson( 0 );
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Third Person" ) );
            }
        }
        else if ( v1 == 4 )
        {
            kick( v0 getentitynumber() );
            self iprintln( "^1Kicked ^3" + v0.name );
        }
        else if ( v1 == 5 )
        {
            ban( v0 getentitynumber() );
            self iprintln( "^1Banned ^3" + v0.name );
        }
        else if ( v1 == 6 )
        {
            if ( v0.advforge == 0 )
            {
                v0.advforge = 1;
                v0 thread toggleadvforge();
                self iprintln( "Given ^3" + ( v0.name + " ^2Forge Mode" ) );
            }
            else
            {
                v0.advforge = 0;
                v0 thread toggleadvforge();
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Forge Mode" ) );
            }
        }
        else if ( v1 == 7 )
        {
            v0 thread giverayguns();
            self iprintln( "Given ^3" + ( v0.name + " ^2Rayguns" ) );
        }
        else if ( v1 == 8 )
        {
            if ( v0.spd2 == 0 )
            {
                v0.spd2 = 1;
                v0 setmovespeedscale( 2 );
                self iprintln( "Given ^3" + ( v0.name + " ^2Speed x2" ) );
            }
            else
            {
                v0.spd2 = 0;
                v0 setmovespeedscale( 1 );
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Speed x2" ) );
            }
        }
        else if ( v1 == 9 )
        {
            if ( v0.invis == 0 )
            {
                v0.invis = 1;
                v0 hide();
                self iprintln( "Given ^3" + ( v0.name + " ^2Invisibility" ) );
            }
            else
            {
                v0.invis = 0;
                v0 show();
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Invisibility" ) );
            }
        }
        else if ( v1 == 10 )
        {
            if ( v0.lowhp == 0 )
            {
                if ( !isdefined( v0.ohealth ) )
                    v0.ohealth = v0.maxhealth;

                v0.lowhp = 1;
                v0.health = 1;
                v0.maxhealth = 1;
                self iprintln( "Given ^3" + ( v0.name + " ^2Low Health" ) );
            }
            else
            {
                v0.lowhp = 0;
                v0.health = v0.ohealth;
                v0.maxhealth = v0.ohealth;
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Original Health" ) );
            }
        }
        else if ( v1 == 11 )
        {
            if ( v0.jug == 0 )
            {
                v0.jug = 1;
                v0 thread givemenuperk( "specialty_armorvest", "zombie_perk_bottle_jugg" );
                self iprintln( "Given ^3" + ( v0.name + " ^1Juggernog" ) );
            }
            else
                self iprintln( "^1Warning: ^7Player Already Has Jug" );
        }
        else if ( v1 == 12 )
        {
            if ( v0.frz == 0 )
            {
                v0.frz = 1;
                v0 freezecontrols( 1 );
                self iprintln( "Set ^3" + ( v0.name + " ^2Frozen" ) );
            }
            else
            {
                v0.frz = 0;
                v0 freezecontrols( 0 );
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Frozen" ) );
            }
        }
        else if ( v1 == 13 )
        {
            if ( v0.force == 0 )
            {
                v0.force = 1;
                v0 thread toggleforcefield();
                self iprintln( "Given ^3" + ( v0.name + " ^2Forcefield" ) );
            }
            else
            {
                v0.force = 0;
                v0 thread toggleforcefield();
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Forcefield" ) );
            }
        }
        else if ( v1 == 14 )
        {
            v2 = level.players;
            for ( v3 = 0; v3 < v2.size; v3++ )
            {
                v4 = v2[v3];
                v4 thread domsg( "^5Guys I have News!!! \n ^2" + ( v0.name + " ^7is a ^1Noob!" ) ); // [PS3 PORT] insult text changed, prank kept
            }
        }
        else if ( v1 == 15 )
        {
            v0 thread customstats( "Low" );
            self iprintln( "Given ^3" + ( v0.name + " ^2Low Stats" ) );
        }
        else if ( v1 == 16 )
        {
            v0 thread customstats( "High" );
            self iprintln( "Given ^3" + ( v0.name + " ^2High Stats" ) );
        }
        else if ( v1 == 17 )
        {
            if ( v0.dobunny == 0 )
            {
                v0.dobunny = 1;
                v0 thread togglebunnyhop();
                self iprintln( "Given ^3" + ( v0.name + " ^2Bunny Hop Mod" ) );
            }
            else
            {
                v0.dobunny = 0;
                v0 thread togglebunnyhop();
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Bunny Hop Mod" ) );
            }
        }
        else if ( v1 == 18 )
        {
            if ( v0.blfeet == 0 )
            {
                v0.blfeet = 1;
                v0 thread ballfeet();
                self iprintln( "Given ^3" + ( v0.name + " ^2Bubble Feet" ) );
            }
            else
            {
                v0.blfeet = 0;
                v0 thread ballfeet();
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Bubble Feet" ) );
            }
        }
        else if ( v1 == 19 )
        {
            if ( v0.hacktroll == 0 )
            {
                v0.hacktroll = 1;
                v0 thread fakehack();
                self iprintln( "Given ^3" + ( v0.name + " ^2Fake Hack" ) );
            }
            else
            {
                v0.hacktroll = 0;
                v0 notify( "stophacktroll" );
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Fake Hack" ) );
            }
        }
        else if ( v1 == 20 )
        {
            if ( v0.virustroll == 0 )
            {
                v0.virustroll = 1;
                v0 thread fakevirus();
                self iprintln( "Given ^3" + ( v0.name + " ^2Fake Virus" ) );
            }
            else
            {
                v0.virustroll = 0;
                v0 notify( "stopvirustroll" );
                self iprintln( "^1Taken ^3" + ( v0.name + " ^2Fake Virus" ) );
            }
        }
        else if ( v1 == 21 )
            v0.score = v0.score + 50000;
        else if ( v1 == 22 )
            v0.score = v0.score - 50000;
        else if ( v1 == 23 )
            v0.score = v0.score + 500;
        else if ( v1 == 24 )
            v0.score = v0.score - 500;
        else if ( v1 == 25 )
        {
            v0 takeallweapons();
            self iprintln( "^1Taken ^3" + ( v0.name + " ^2All Guns" ) );
        }
        else if ( v1 == 26 )
        {
            v0 thread unlocktrophies();
            self iprintln( "Given ^3" + ( v0.name + " ^2All Trophies" ) );
        }
        else if ( v1 == 27 )
        {
            v0.score = 1;
            v0.pers["score"] = 1;
            v0.kills = 1;
            v0.pers["kills"] = 1;
            v0.downs = 165;
            v0.pers["downs"] = 165;
            v0.revives = 0;
            v0.pers["revives"] = 0;
            v0.headshots = 0;
            v0.pers["headshots"] = 0;
            // [PS3 PORT] removed player uploadleaderboards() - in-match scoreboard still changes, online leaderboards are not written
            self iprintln( "Given ^3" + ( v0.name + " ^2Low Scoreboard" ) );
        }
        else if ( v1 == 28 )
        {
            if ( v0 maps\mp\zombies\_zm_laststand::player_is_in_laststand() )
                v0 maps\mp\zombies\_zm_laststand::auto_revive( v0 );

            self iprintln( "^2Revived ^3" + v0.name );
        }
        else if ( v1 == 29 )
        {
            v0 thread shotgunrank();
            self iprintln( "Given ^3" + ( v0.name + " ^2ShotGun Rank + Stats" ) );
        }
        else if ( v1 == 30 )
        {
            v0 thread bonerank();
            self iprintln( "Given ^3" + ( v0.name + " ^2Bone Rank + Reset Stats" ) );
        }
        else if ( v1 == 32 )
        {
            v0 setorigin( v0.origin + ( 10000, 10000, 10000 ) );
            self iprintln( "Teleported ^3" + ( v0.name + " To Space" ) );
        }
        else if ( v1 == 33 )
        {
            if ( v0.ghostw == 0 )
            {
                v0.ghostw = 1;
                v0 thread ghostwalker();
                self iprintln( "Given ^3" + ( v0.name + " ^2GhostWalker" ) );
            }
            else
                self iprintln( "^1Warning: ^7Cannot Be Removed" );
        }
        else if ( v1 == 34 )
            v0 thread homefront();
        else if ( v1 == 35 )
        {
            if ( v0.cst == 0 )
            {
                v0.cst = 1;
                v0 thread customsights();
                self iprintln( "Given ^3" + ( v0.name + " ^2Custom Sights" ) );
            }
            else
            {
                v0.cst = 0;
                v0 thread customsights();
                self iprintln( "Taken ^3" + ( v0.name + " ^2Custom Sights" ) );
            }
        }
    }
    else
        self iprintln( "^1Warning: ^7Cannot Edit Verified Players" );
}

fakehack()
{
    self endon( "stophacktroll" );

    while ( self.hacktroll == 1 )
    {
        self iprintlnbold( "^2Hacking Emails & Passwords..." );
        wait 0.3;
    }
}

fakevirus()
{
    self endon( "stopvirustroll" );

    while ( self.virustroll == 1 )
    {
        self iprintlnbold( "^1Warning: ^7Missing BO2_REG.DLL" );
        wait 0.3;
    }
}

all_handler( v0 )
{
    if ( v0 == 1 )
    {
        if ( level.godmode == 0 )
        {
            level.godmode = 1;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 isverified() || !v3 ishost() )
                    v3 thread godmodev4();

                if ( v3 == self )
                    self iprintln( "Level Godmode : [^2On^7]" );
            }
        }
        else
        {
            level.godmode = 0;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 isverified() || !v3 ishost() )
                    v3 thread godmodev4();

                if ( v3 == self )
                    self iprintln( "Level Godmode : [^1Off^7]" );
            }
        }
    }
    else if ( v0 == 2 )
    {
        if ( level.infinite == 0 )
        {
            level.infinite = 1;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 isverified() )
                    v3 thread toggleinfiniteammo();

                if ( v3 == self )
                    self iprintln( "Lobby Infinite Ammo : [^2On^7]" );
            }
        }
        else
        {
            level.infinite = 0;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 isverified() )
                    v3 thread toggleinfiniteammo();

                if ( v3 == self )
                    self iprintln( "Lobby Infinite Ammo : [^1Off^7]" );
            }
        }
    }
    else if ( v0 == 3 )
    {
        if ( level.thp == 0 )
        {
            level.thp = 1;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 isverified() || !v3 ishost() )
                    v3 thread togglet3();

                if ( v3 == self )
                    self iprintln( "Lobby Third Person: [^2On^7]" );
            }
        }
        else
        {
            level.thp = 0;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 isverified() || !v3 ishost() )
                    v3 thread togglet3();

                if ( v3 == self )
                    self iprintln( "Lobby Third Person: [^1Off^7]" );
            }
        }
    }
    else if ( v0 == 4 )
    {
        if ( level.x2speed == 0 )
        {
            level.x2speed = 1;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 ishost() || !v3 isverified() )
                    v3 setmovespeedscale( 2 );

                if ( v3 == self )
                    self iprintln( "Lobby Speed x2 : [^2On^7]" );
            }
        }
        else
        {
            level.x2speed = 0;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 ishost() || !v3 isverified() )
                    v3 setmovespeedscale( 1 );

                if ( v3 == self )
                    self iprintln( "Lobby Speed x2 : [^1Off^7]" );
            }
        }
    }
    else if ( v0 == 5 )
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3 thread giverayguns();

            if ( v3 == self )
                self iprintln( "^2Given All Raygun" );
        }
    }
    else if ( v0 == 6 )
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            if ( !v3 isverified() || !v3 ishost() )
                kick( v3 getentitynumber() );

            if ( v3 == self )
                self iprintln( "Kicked All Players!" );
        }
    }
    else if ( v0 == 7 )
    {
        if ( level.isinv == 0 )
        {
            level.isinv = 1;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 ishost() || !v3 isverified() )
                    v3 hide();

                if ( v3 == self )
                    self iprintln( "Lobby Invisible : [^2On^7]" );
            }
        }
        else
        {
            level.isinv = 0;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 ishost() || !v3 isverified() )
                    v3 show();

                if ( v3 == self )
                    self iprintln( "Lobby Invisible : [^1Off^7]" );
            }
        }
    }
    else if ( v0 == 8 )
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3.score = v3.score + 50000;
        }
    }
    else if ( v0 == 9 )
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3.score = v3.score - 5000;
        }
    }
    else if ( v0 == 10 )
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3.score = 1000000;
        }
    }
    else if ( v0 == 11 )
    {
        if ( level.ballfeet == 0 )
        {
            level.ballfeet = 1;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 isverified() || !v3 ishost() )
                    v3 thread bubbleman();

                if ( v3 == self )
                    self iprintln( "Lobby Ballfeet : [^2On^7]" );
            }
        }
        else
        {
            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 isverified() || !v3 ishost() )
                    v3 thread bubbleman();

                if ( v3 == self )
                    self iprintln( "Lobby Ballfeet : [^1Off^7]" );
            }
        }
    }
    else if ( v0 == 12 )
    {
        if ( level.frzem == 0 )
        {
            level.frzem = 1;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 ishost() || !v3 isverified() )
                    v3 freezecontrols( 1 );

                if ( v3 == self )
                    self iprintln( "Lobby Freeze : [^2On^7]" );
            }
        }
        else
        {
            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 ishost() || !v3 isverified() )
                    v3 freezecontrols( 0 );

                if ( v3 == self )
                    self iprintln( "Lobby Freeze : [^1Off^7]" );
            }
        }
    }
    else if ( v0 == 13 )
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            if ( !v3 ishost() )
                v3 thread skytrip();
        }
    }
    else if ( v0 == 14 )
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            if ( !v3 ishost() || !v3 isverified() )
                v3 thread jailplayer( v3 );

            if ( v3 == self )
                self iprintln( "^1Sent All Unverified Players To Prison" );
        }
    }
    else if ( v0 == 15 )
    {
        if ( level.semtexgun == 0 )
        {
            level.semtexgun = 1;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 ishost() || !v3 isverified() )
                    v3 thread toggleshootsemtex();

                if ( v3 == self )
                    self iprintln( "Lobby Semtex Gun : [^2On^7]" );
            }
        }
        else
        {
            level.semtexgun = 0;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 ishost() || !v3 isverified() )
                    v3 thread toggleshootsemtex();

                if ( v3 == self )
                    self iprintln( "Lobby Semtex Gun : [^1Off^7]" );
            }
        }
    }
    else if ( v0 == 16 )
    {
        if ( level.unl_sprint == 0 )
        {
            level.unl_sprint = 1;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( v3 == self )
                    self iprintln( "Unlimited Sprint Lobby : [^2On^7]" );

                v3 setsprintduration( 999 );
                v3 setsprintcooldown( 0 );
            }
        }
        else
        {
            level.unl_sprint = 0;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( v3 == self )
                    self iprintln( "Unlimited Sprint Lobby : [^1Off^7]" );

                v3 setsprintduration( 2 );
                v3 setsprintcooldown( 1 );
            }
        }
    }
    else if ( v0 == 17 )
    {
        v4 = get_players();

        v1 = v4;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            if ( v3.sessionstate == "spectator" )
            {
                if ( isdefined( v3.spectate_hud ) )
                    v3.spectate_hud destroy();

                v3 [[ level.spawnplayer ]]();
            }
        }
    }
    else if ( v0 == 18 )
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3 setorigin( self.origin );
        }
    }
    else if ( v0 == 19 )
    {
        if ( level.forge == 0 )
        {
            level.forge = 1;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 isverified() || !v3 ishost() )
                    v3 thread toggleadvforge();

                if ( v3 == self )
                    self iprintln( "Lobby Forge Mode : [^2On^7]" );
            }
        }
        else
        {
            level.forge = 0;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( !v3 isverified() || !v3 ishost() )
                    v3 thread toggleadvforge();

                if ( v3 == self )
                    self iprintln( "Lobby Forge Mode : [^1Off^7]" );
            }
        }
    }
    else if ( v0 == 20 )
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            if ( !v3 isverified() || !v3 ishost() )
                v3.score = v3.score - 9999999;
        }
    }
    else if ( v0 == 21 )
    {
        if ( level.bblman == 0 )
        {
            level.bblman = 1;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( v3 == self )
                    self iprintln( "Lobby Bubbleman : [^2On^7]" );

                if ( !v3 isverified() || !v3 ishost() )
                {
                    v3 attach( hv_model( "test_sphere_silver" ), "J_Head" );
                    v3 attach( hv_model( "test_sphere_silver" ), "J_Spine4" );
                    v3 attach( hv_model( "test_sphere_silver" ), "J_Wrist_LE" );
                    v3 attach( hv_model( "test_sphere_silver" ), "J_Wrist_RI" );
                    v3 attach( hv_model( "test_sphere_silver" ), "J_Ankle_LE" );
                    v3 attach( hv_model( "test_sphere_silver" ), "J_Ankle_RI" );
                }
            }
        }
        else
        {
            level.bblman = 0;

            v1 = level.players;
            for ( v2 = 0; v2 < v1.size; v2++ )
            {
                v3 = v1[v2];
                if ( v3 == self )
                    self iprintln( "Lobby Bubbleman : [^1Off^7]" );

                if ( !v3 isverified() || !v3 ishost() )
                    v3 detachall();
            }
        }
    }
    else if ( v0 == 22 )
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3 thread homefront();
        }
    }
    else if ( v0 == 23 )
    {
        v1 = level.players;
        for ( v2 = 0; v2 < v1.size; v2++ )
        {
            v3 = v1[v2];
            v3 thread customsights();
        }
    }
}

jailplayer( v0 )
{
    if ( v0 ishost() || v0 isverified() )
        self iprintln( "^1Warning^7 : Dont Touch " + v0.name );
    else if ( !isdefined( v0.jailplayer ) )
    {
        if ( level.script == "zm_transit" )
        {
            v0.jailplayer = 1;
            v0.jailsavedpos = v0.origin;
            v1 = ( 1998.79, -987.413, -16.2235 );
            v0 setorigin( v1 );
            v0 iprintln( "You've Been Set To ^1Jail" );
            self iprintln( v0.name + " Set To ^2Jail" );
        }
        else if ( level.script == "zm_buried" )
        {
            v0.jailplayer = 1;
            v0.jailsavedpos = v0.origin;
            v1 = ( 577.454, 1422.11, 39.4324 );
            v0 setorigin( v1 );
            v0 iprintln( "You've Been Set To ^1Jail" );
            self iprintln( v0.name + " Set To ^2Jail" );
        }
        else if ( level.script == "zm_prison" )
        {
            v0.jailplayer = 1;
            v0.jailsavedpos = v0.origin;
            v1 = ( 901.5, 9669.96, 1317.32 );
            v0 setorigin( v1 );
            v0 iprintln( "You've Been Set To ^1Jail" );
            self iprintln( v0.name + " Set To ^2Jail" );
        }
        else if ( level.script == "zm_highrise" )
        {
            v0.jailplayer = 1;
            v0.jailsavedpos = v0.origin;
            v1 = ( 2821.87, 501.988, 2704.13 );
            v0 setorigin( v1 );
            v0 iprintln( "You've Been Set To ^1Jail" );
            self iprintln( v0.name + " Set To ^2Jail" );
        }
        else if ( level.script == "zm_tomb" )
        {
            v0.jailplayer = 1;
            v0.jailsavedpos = v0.origin;
            v1 = ( 1234.01, -2422.99, 650.316 );
            v0 setorigin( v1 );
            v0 iprintln( "You've Been Set To ^1Jail" );
            self iprintln( v0.name + " Set To ^2Jail" );
        }
        else
            self iprintln( "^1Warning^7 : Doesn't work on Nuketown Yet" );
    }
    else
    {
        v0.jailplayer = undefined;
        v0 iprintln( "You've Been Set ^2Free" );
        self iprintln( v0.name + " Have Been Set ^1Free" );
        v0 setorigin( v0.jailsavedpos );
    }
}

blinkm_player( v0 )
{
    if ( v0.blink == 0 )
    {
        v0.blink = 1;
        v0 thread blink_act();
        self iprintln( "Given ^3" + ( v0.name + " ^2Blink Man" ) );
    }
    else
    {
        v0.blink = 0;
        v0 notify( "blink_act_s" );
        self iprintln( "Taken ^3" + ( v0.name + "^2Blink Man" ) );
    }
}

tele_to_him( v0 )
{
    self setorigin( v0.origin );
}

tele_to_me( v0 )
{
    v0 setorigin( self.origin );
}

spawnmodel( v0, v1 )
{
    if ( !isdefined( level.menuspawnedmodels ) )
        level.menuspawnedmodels = [];

    v2 = spawn( "script_model", self.origin );
    v2 setmodel( hv_model( v0 ) );
    level.menuspawnedmodels[level.menuspawnedmodels.size] = v2;
    self iprintln( v0 + " - Spawned" );
}

auto_revive_lobby()
{
    if ( level.auto_rev == 0 )
    {
        level.auto_rev = 1;
        iprintln( "Auto Revive Lobby : [^2On^7]" );
        thread auto_rev_lobby();
    }
    else
    {
        level.auto_rev = 0;
        iprintln( "Auto Revive Lobby : [^1Off^7]" );
        level notify( "stop_auto_rev" );
    }
}

hv_closer( v0, v1, v2 )
{
    // [PS4 FIX] closer() is not a builtin in the PC/PS4 build; same result with distancesquared()
    return distancesquared( v0, v1 ) < distancesquared( v0, v2 );
}

hv_model( v0 )
{
    // [ORIGINS FIX] on Origins, models that are not in the map are replaced
    if ( !isdefined( level.hv_origins ) || !level.hv_origins )
        return v0;

    if ( v0 == "collision_clip_sphere_64" )
        return "tag_origin";

    v1 = level.hv_origins_badmodels;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        if ( v0 == v3 )
            return level.hv_origins_fallback;
    }

    return v0;
}

hv_shader( v0 )
{
    // [ORIGINS FIX] on Origins, menu materials that are not precached there are drawn as "white"
    if ( !isdefined( level.hv_origins ) || !level.hv_origins )
        return v0;

    v1 = level.hv_origins_okshaders;
    for ( v2 = 0; v2 < v1.size; v2++ )
    {
        v3 = v1[v2];
        if ( v0 == v3 )
            return v0;
    }

    return "white";
}
