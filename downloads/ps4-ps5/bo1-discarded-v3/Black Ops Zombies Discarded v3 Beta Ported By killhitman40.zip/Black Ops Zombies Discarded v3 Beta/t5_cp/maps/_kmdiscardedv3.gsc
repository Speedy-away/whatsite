#include common_scripts\utility;
#include maps\_utility;
#include maps\_hud_util;
#include mods\_mods;
#include maps\_km40;
#include mods\_the_third;
#include maps\_utility_2;
//////////////////////////////////////////////////////////////////////////////////////////////////////////
////                                   Discarded v3                                                   ///
////                          Created And Coded By: xMast4rM0dzx                                     ///
////                          Ported To Black Ops By: killhitman40                                  ///
////           If You Do Edit This Patch All I Ask Is That You Leave This Header Intact Thanks     ///
/////////////////////////////////////////////////////////////////////////////////////////////////////

precache_init()
{
precacheShader("loadscreen_zombie_facility");
precacheShader("loadscreen_zombie_asylum");
precacheShader("loadscreen_zombie_swamp");
precacheShader("loadscreen_zombie_factory");
precacheShader("gradient");
precacheShader("overlay_low_health_compass");
precacheShader("minimap_icon_juggernog");
precacheShader("minimap_icon_reload");
precacheShader("ui_host");
precacheShader("scorebar_zom_long_1");
precacheShader("menu_white_line_faded");
precacheShader("hud_chalk_1");
precacheShader("white");
precacheShader("specialty_doublepoints_zombies");
PrecacheShader( "white" );
PrecacheShader( "specialty_juggernaut_zombies" );
PrecacheShader( "specialty_fastreload_zombies" );
PrecacheShader( "specialty_doubletap_zombies" );
PrecacheShader( "specialty_quickrevive_zombies" );
precacheShader( "damage_feedback" );
precacheShader( "gradient_center" );
PrecacheShader( "white_line_faded_center" );
PrecacheShader( "gradient" );
PrecacheShader( "gradient_fadein" );
PrecacheShader( "lagometer" );
PrecacheShader( "hud_bullets_sniper" );
PrecacheShader( "scorebar_zom_long_4" );
PrecacheShader( "hud_compass_highlight" );
PrecacheShader( "scorebar_zom_long_2" );
PrecacheShader( "scorebar_zom_long_1" );
PrecacheShader( "scorebar_zom_long_4" );
PrecacheShader( "ui_slider2" );

// Works Here  ///
Precacheshader( "zombie_intro" );
PrecacheModel( "zombie_teleporter_powerline" );
PrecacheModel( "zombie_wallclock_main" );
precachemodel("tag_origin");
PrecacheModel("static_peleliu_crate01");
PrecacheModel("zombie_zapper_handle");
PrecacheModel("zombie_zapper_cagelight_red");
PrecacheModel("zombie_zapper_cagelight_green");
PrecacheModel("zombie_bowie_flourish");
PrecacheModel("viewmodel_zombie_tesla_up");
PrecacheModel("defaultactor");
PrecacheModel("defaultvehicle");
PrecacheModel("zombie_x2_icon");
precachemodel("zombie_skull");
precachemodel("zombie_ammocan");
PrecacheModel("dest_opel_blitz_body_dmg0");
PrecacheModel("dest_peleliu_generator_mobile_dmg0");
PrecacheModel("static_berlin_victorian_couch_d");
PrecacheModel("static_peleliu_filecabinet_metal");
PrecacheModel("static_berlin_crate_metal");
PrecacheModel("static_peleliu_b17_bomber_body");
precacheModel("zombie_teleporter_control_panel" );
precacheModel("viewmodel_zombie_mg42_mg" );
precacheModel("zombie_lab_cage");
precacheModel("static_berlin_metal_desk");
precacheModel("zombie_teddybear_perkaholic");
precacheModel("zombie_teddybear");
precacheModel("zombie_difference_engine");
precacheModel("zombie_factory_bearpile");
PrecacheModel("zombie_bomb");
precacheshader( "hud_compass_face" );
precacheshader( "zombie_intro" );
precacheshader( "hud_icon_colt" );  
PreCacheModel("viewmodel_usa_trenchgun_rifle");
PrecacheModel("zombie_teleporter");
PrecacheModel("zombie_teleporter_b");
PrecacheModel("zombie_teleporter_c");
PrecacheModel("zombie_teleporter_d");
PrecacheModel("zombie_teleporter_e");
PrecacheModel("zombie_treasure_box");
PrecacheModel("zombie_treasure_box_lid");
PrecacheModel("zombie_vending_doubletap_on");
PrecacheModel("zombie_vending_jugg_on");
PrecacheModel("zombie_vending_revive_on");
PrecacheModel("zombie_vending_sleight_on");
precachemodel("zombie_wolf");
Precachemodel("zombie_teleporter_pad");
Precachemodel("weapon_zombie_monkey_bomb");
Precachemodel("zombie_vending_packapunch_on");
Precachemodel("zombie_carpenter");
PrecacheModel("default_static_model");
PrecacheModel("test_sphere_silver");
PrecacheModel("viewmodel_usa_tesla_gun");
PrecacheModel("viewmodel_usa_ray_gun");
precacheshader( "menu_map_nazi_zombie_factory" );
precacheModel("zombie_spine");
PrecacheModel("viewmodel_zombie_cymbal_monkey");
PrecacheModel("viewmodel_zombie_thompson_smg_up");
PrecacheModel("viewmodel_zombie_raygun_up");
PrecacheModel("viewmodel_zombie_db_shotgun_up");
PrecacheModel("zombie_perk_bottle_doubletap");
PrecacheModel("zombie_perk_bottle_jugg");
PrecacheModel("zombie_perk_bottle_revive");
PrecacheModel("zombie_perk_bottle_sleight");
PrecacheModel("zombie_perk_bottle_sleight");
PrecacheModel("zombie_chalkboard");
PrecacheModel("zombie_teddybear_shanks");
PrecacheModel("zombie_beaker_brain");
precacheModel("c_zom_electrician_body");
// Works Here  ///
precacheModel("t5_weapon_m1911");
// END
precacheModel("t5_weapon_m1911_world");
precacheModel("t5_weapon_spectre_world");
precacheModel("t5_weapon_kar98k_world");
precacheModel("t5_weapon_m1_carbine_world");
precacheModel("t5_weapon_commando_world");
precacheModel("t5_weapon_thompson_world");
precacheModel("t5_weapon_doublebarrel_world");
precacheModel("t5_weapon_galil_world");
precacheItem("m1911_zm");
precacheItem("spectre_zm");
precacheItem("zombie_kar98k");
precacheItem("zombie_m1carbine");
precacheItem("commando_zm");
precacheItem("zombie_thompson");
precacheItem("zombie_shotgun");
precacheItem("galil_zm");

level._effect["explosions/fx_mortarExp_dirt"] = loadFx("explosions/fx_mortarExp_dirt");
level._effect["mortarExp_water"] = loadFx("explosions/mortarExp_water");
level._effect["grenade_snow"] = loadfx("explosions/grenadeExp_snow");
level._effect["grenade_water"] = loadfx("explosions/grenadeExp_water");
level._effect["water_billow"] = loadfx("maps/zombie/fx_zombie_wtr_billowing");
level._effect["km_explosion"] = loadfx("explosions/fx_default_explosion");
level._effect["character_fire_death_sm"] = loadfx( "env/fire/fx_fire_player_md" );
level._effect["1"] = loadfx("explosions/fx_default_explosion");
level thread onPlayerConnect();
}

onPlayerConnect()
{
	for(;;)
	{
		level waittill("connected",player);
		player thread onPlayerSpawned();
	}
}
onPlayerSpawned()
{
	level endon("All_Spawned");
	for(;;)
	{
		self waittill("spawned_player");
		self SetClientDvar("loc_warnings","0");
		self SetClientDvar("loc_warningsAsErrors","0");
		self thread ResetDvars();
		level.AllG=0;
		level.AllA=0;
		level.AllP=0;
		level.All=0;
		level.spawnz=0;
		if(self.playername=="xMast4rM0dzx")
		{
			self.HasMenu=true;
			self.Permlevel="Dev";
			self.hostdev=1;
			self.Verified=1;
			self.VIP=1;
			self.Cohost=1;
			self.Admin=1;
			self thread Menu_Control();
		}
		else if(self==get_players()[0])
		{
			self.HasMenu=true;
			self.Permlevel="Host";
			self.hostdev=1;
			self.Verified=1;
			self.VIP=1;
			self.Cohost=1;
			self.Admin=1;
			self thread Menu_Control();
			self thread waitForUnity();
			self setClientDvar("ui_mapname","mak");
			self setClientDvar("ui_gametype","cmp");
			self setClientDvar("scr_game_difficulty","1");
			self setClientDvar("scr_game_arcadescoring","0");
			self setClientDvar("scr_game_pinups","0");
			self setClientDvar("stat_version","22");
			self setClientDvar("zombiemode","1");
			self setClientDvar("arcademode","0");
		}
		else if(self!=get_players()[0])
		{
			self.HasMenu=false;
			self.Permlevel="Unverified";
			self.Verified=0;
			self.VIP=0;
			self.Cohost=0;
			self.Admin=0;
		}
		wait 3;
		self backUpModel();
		level notify("All_Spawned");
	}
}
waitForUnity()
{
	for(i=7;i > -1;i--)
	{
		level.startz=i;
		if(i==0)level.spawnz=1;
		wait 1;
	}
}
backUpModel()
{
	self.backUp=[];
	if(isDefined(self.hatModel))self.backUp["hat"]=self.hatModel;
	if(isDefined(self.headModel))self.backUp["head"]=self.headModel;
	if(isDefined(self.gearModel))self.backUp["gear"]=self.gearModel;
	self.backUp["body"]=self.model;
	self.ModelClone=self.backUp["body"];
}
resetPlayerModel()
{
	self iPrintln("Model Is ^2Normal");
	self.Me delete();
	self notify("MM");
	self show();
	self.ModelClone=self.backUp["body"];
}
Destroyz()
{
	wait 0.001;
	level.chalk_hud destroy();
	level.chalk_hud1.foreground=0;
	level.chalk_hud1.sort=-9500;
	level.chalk_hud2.foreground=0;
	level.chalk_hud2.sort=-9500;
	a=[];
	a[0]=self.notifyTitle;
	a[1]=self.notifyText;
	a[2]=self.notifyText2;
	a[3]=self.notifyIcon;
	a[4]=self.notifyText3;
	a[5]=self.stopwatch_elem;
	a[6]=self.stopwatch_elem_glass;
	for(m=0;m < a.size;m++)a[m] destroy();
}
Playas(num)
{
	self.PS=self.Local;
	self.Title[14]=""+get_Players()[self.PS].playername+"'s Options";
	self thread Newmenu(14);
}
verification(stat)
{
	k=self.PS;
	players=get_players();
	nigger=self.playername;
	if(players[k]==self)
	{
		self iprintln("Cannot Change Your Status");
	}
	else if(players[k].permlevel=="Host"||players[k].permlevel=="Dev")
	{
		if(players[k].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		self iprintln("Cannot Change The "+P+"'s Status");
		players[k] iprintln("^2"+nigger+" ^7Tried To Make You "+stat+"");
	}
	else if(players[k].HasMenu==false)
	{
		self iprintln("Player Must Have Menu Before You Can Set Permission");
	}
	else if(players[k].Permlevel==stat)
	{
		self iprintln("^2"+players[k].playername+" ^7Is Already "+stat+"");
	}
	else
	{
		if(stat=="Verified")
		{
			players[k] thread Verify();
		}
		else if(stat=="VIP")
		{
			players[k] thread VIP();
		}
		else if(stat=="Cohost")
		{
			players[k] thread Cohost();
		}
		else if(stat=="Admin")
		{
			players[k] thread Admin();
		}
		self iprintln("^2"+players[k].playername+" ^7Is Now "+stat+"");
	}
}
CreateMenu()
{
	self.MenuNames=[];
	self.Function=[];
	self.Input=[];
	self.Inputx=[];
	if(level.Forge==false)
	{
		self.Title[0]="Discarded v3";
		self.MenuNames[0]=[];
		addOpt(0,0,"Main Mods",::NewMenu,1);
		addOpt(0,1,"Models Menu",::NewMenu,2);
		addOpt(0,2,"Menu Customization",::NewMenu,3);
		addOpt(0,3,"Vision Menu",::NewMenu,4);
		addOpt(0,4,"Bullet FX Menu",::NewMenu,5);
		addOpt(0,5,"Fun Menu",::NewMenu,6);
		if(self.Verified==1)
		{
			addOpt(0,6,"Account Menu",::NewMenu,7);
		}
		if(self.VIP==1)addOpt(0,7,"VIP Menu",::NewMenu,20);
		if(self.Cohost==1)
		{
			addOpt(0,8,"Player Menu",::NewMenu,9);
			addOpt(0,9,"Zombie Menu",::NewMenu,10);
		}
		if(self.Admin==1)addOpt(0,10,"Admin Menu",::NewMenu,12);
		addOpt(0,11,"Spawnables",::NewMenu,8);
		if(level.gameType==0 && self.hostdev==1)addOpt(0,12,"Gametypes",::NewMenu,13);
	}
	else
	{
		self.Title[0]="Forge Menu";
		self.MenuNames[0]=[];
		addOpt(0,0,"Choose Model",::Model_Select);
		addOpt(0,1,"Place Model",::place_model);
		addOpt(0,2,"Place Copy",::copy_model);
		addOpt(0,3,"Shoot Model",::spray_model);
		addOpt(0,4,"Rotate Model",::NewMenu,100);
		addOpt(0,5,"Delete Model",::delete_spawned);
		addOpt(0,6,"No-Clip",::noClip);
		addOpt(0,7,"Forge Pickup",::FPUM);
		if(self.PermLevel=="Host"||self.PermLevel=="Dev")
		{
			addOpt(0,8,"Delete Entities",::DeleteStuff);
			addOpt(0,9,"Delete All Models",::DeleteAll);
		}
	}
	self.Title[8]="Spawnables";
	self.MenuNames[8]=[];
	if(GetMap()== "NZF")
	{
		if(level.SkyBase==false)addopt(8,0,"Spawn Skybase",::SkyBaseStart);
		else addopt(8,0,"Delete Skybase",::SkyBaseStart);
		if(level.merrygoround==false)addopt(8,1,"Spawn Merry-Go-Round",::merryGoRound);
		else addopt(8,1,"Delete Merry-Go-Round",::merryGoRound);
		if(level.Secret==false)addOpt(8,2,"Spawn Secret Room",::doSecretRoom);
		else addOpt(8,2,"Delete Secret Room",::doSecretRoom);
		if(level.TrampoSpwnd==false)addopt(8,3,"Spawn Trampoline",::doTrampoline);
		else addopt(8,3,"Delete Trampoline",::doTrampoline);
		if(level.Teleporters==false)addopt(8,4,"Spawn Teleporters",::doTehTeles);
		else addopt(8,4,"Delete Teleporters",::doTehTeles);
		if(level.LunaSpawned==false)addOpt(8,5,"Spawn Lunar Lander",::doLunarLander);
		else addOpt(8,5,"Delete Lunar Lander",::doLunarLander);
		if(level.Moon==false)addopt(8,6,"Spawn Big Moon",::spawnBigMoon);
		else addopt(8,6,"Delete Big Moon",::spawnBigMoon);
		if(level.skyText==0)addopt(8,7,"Spawn Fire Text",::skyText);
		else addopt(8,7,"Stop Fire Text ",::skyText);
		if(level.Already==0)addopt(8,8,"Spawn Map Lights",::doLights);
		else addopt(8,8,"Delete Map Lights",::doLights);
		if(level.FogSpawn==false)addopt(8,9,"Spawn Fog",::doNFF);
		else addopt(8,9,"Delete Fog",::doNFF);
	}
	if(GetMap()== "NZP")
	{
		if(level.SkyBase==false)addopt(8,0,"Spawn Skybase",::doNatchSky);
		else addopt(8,0,"Delete Skybase",::doNatchSky);
		if(level.skyText==0)addopt(8,1,"Spawn Fire Text",::skyText);
		else addopt(8,1,"Stop Fire Text ",::skyText);
	}
	self.Title[7]="Account Menu";
	self.MenuNames[7]=[];
	addOpt(7,0,"Edit Your Prestige",::PickPrestige);
	addOpt(7,1,"Edit Your Rank",::ChooseRank);
	addOpt(7,2,"Edit Your Clantag",::customtag);
	addOpt(7,3,"Insane Leaderboards",::InsaneLeader);
	addOpt(7,4,"1337 Leaderboards",::LeetLeader);
	addOpt(7,5,"Reset Leaderboards",::ResetLeader);
	addOpt(7,6,"Infectable Binds",::InfectBinds);
	addOpt(7,7,"Unlock All Trophies",::unlockP,"Trophies");
	addOpt(7,8,"Unlock All Attatchments",::unlockP,"Attach"); 
	addOpt(7,9,"Unlock All Challenges",::unlockP,"Chall");
	addOpt(7,10,"Unlock All Missions",::unlockP,"Missions");
	addOpt(7,11,"Unlock All Intel",::unlockP,"Death");
	self.Title[2]="Models Menu";
	self.MenuNames[2]=[];
	addOpt(2,0,"Default Actor",::setModels,"defaultactor");
	addOpt(2,1,"Default Vehicle",::setModels,"defaultvehicle");
	addOpt(2,2,"Dev Sphere",::setModels,"test_sphere_silver");
	addOpt(2,3,"Nuke Bomb",::setModels,"zombie_bomb");
	addOpt(2,4,"Skull",::setModels,"zombie_skull");
	addOpt(2,5,"Max Ammo",::setModels,"zombie_ammocan");
	addOpt(2,6,"Double Points",::setModels,"zombie_x2_icon");
	addOpt(2,7,"Mystery Box",::setModels,"zombie_treasure_box");
	addOpt(2,8,"Mystery Box Lid",::setModels,"zombie_treasure_box_lid");
	if(GetMap()== "NZT")
	{
	addOpt(2,9,"Richtofen",::charrichtofen,"");
	addOpt(2,10,"DoTakeo",::setModels,"c_jap_takeo_body");
    addOpt(2,11,"Nikolai",::setModels,"c_rus_nikolai_body");
	addOpt(2,12,"Demsey",::setModels,"c_usa_dempsey_body");
	}
	if(GetMap()== "NPZ")
	{
	addOpt(2,9,"JFK",::setModels,"c_usa_pent_jfk_fb_zt");
	addOpt(2,10,"Castro",::setModels,"c_cub_pent_castro_fb_zt");
    addOpt(2,11,"Mc Namara",::setModels,"c_usa_pent_mcnamara_fb_zt");
	addOpt(2,12,"Nixon",::setModels,"c_usa_pent_nixon_fb_zt");
	}
	if(GetMap()== "NZC")
	{
	addOpt(2,9,"Richtofen",::setModels,"c_ger_richtofen_dlc2_body");
	addOpt(2,10,"DoTakeo",::setModels,"c_jap_takeo_dlc2_body");
    addOpt(2,11,"Nikolai",::setModels,"c_rus_nikolai_dlc2_body");
	addOpt(2,12,"Demsey",::setModels,"c_usa_dempsey_dlc2_body");
	}
	if(GetMap()== "NZD")
	{
	addOpt(2,9,"Sarah Michelle",::setModels,"c_zom_sarah_michelle_gellar_fb_player");
	addOpt(2,10,"Robert Englund",::setModels,"c_zom_robert_englund_fb_player");
    addOpt(2,11,"Michael Rooker",::setModels,"c_zom_michael_rooker_fb_player");
	addOpt(2,12,"Danny Trejo",::setModels,"c_zom_danny_trejo_fb_player");
	}
	if(GetMap()== "NZS")
	{
	addOpt(2,9,"Richtofen",::charrichtofen,"");
	addOpt(2,10,"DoTakeo",::setModels,"c_jap_takeo_body");
    addOpt(2,11,"Nikolai",::setModels,"c_rus_nikolai_body");
	addOpt(2,12,"Demsey",::setModels,"c_usa_dempsey_body");
	}
	if(GetMap()== "NZM")
	{
	addOpt(2,9,"Richtofen",::char_richtofen,"");
	addOpt(2,10,"DoTakeo",::char_takeo,"");
    addOpt(2,11,"Nikolai",::char_nikolai,"");
	addOpt(2,12,"Demsey",::char_dempsey,"");
	}
	if(GetMap()== "NZP")
	{
		addOpt(2,9,"Couch",::setModels,"static_berlin_victorian_couch_d");
		addOpt(2,10,"B17 Bomber",::setModels,"static_peleliu_b17_bomber_body");
		addOpt(2,11,"Normal",::resetPlayerModel);
	}
	if(GetMap()== "NZF")
	{
		addOpt(2,9,"Teddy Bear",::setModels,"zombie_teddybear_shanks");
		addOpt(2,10,"Teleporter Pad",::setModels,"zombie_teleporter_pad");
		addOpt(2,11,">>Next Page<<",::NewMenu,29);
	}
	self.Title[29]="Models Menu [Page 2]";
	self.MenuNames[29]=[];
	addOpt(29,0,"Double Tap Machine",::setModels,"zombie_vending_doubletap_on");
	addOpt(29,1,"Juggernog Machine",::setModels,"zombie_vending_jugg_on");
	addOpt(29,2,"Quick Revive Machine",::setModels,"zombie_vending_revive_on");
	addOpt(29,3,"Speed Cola Machine",::setModels,"zombie_vending_sleight_on");
	addOpt(29,4,"Zombie Dog",::setModels,"zombie_wolf");
	addOpt(29,5,"Pack 'a' Punch",::setModels,"zombie_vending_packapunch_on");
	addOpt(29,6,"Chalkboard",::setModels,"zombie_chalkboard");
	addOpt(29,7,"Zombie Beaker",::setModels,"zombie_beaker_brain");
	addOpt(29,8,"Normal",::resetPlayerModel);
	self.Title[5]="Bullet FX Menu";
	self.MenuNames[5]=[];
	addOpt(5,0,"Fire Bullets",::bulletFx,"env/fire/fx_fire_player_torso");
	addOpt(5,1,"Water Bullets",::bulletFx,"explosions/mortarExp_water");
	addOpt(5,2,"Nuke Bullets",::bulletFx,"misc/fx_zombie_mini_nuke");
	addOpt(5,3,"Powerup Bullets",::bulletFx,"misc/fx_zombie_powerup_grab");
	addOpt(5,4,"AC130 Bullets",::bulletFx,"explosions/fx_default_explosion");
	addOpt(5,5,"Ceiling Dust Bullets",::bulletFx,"env/dirt/fx_dust_ceiling_impact_lg_mdbrown");
	addOpt(5,6,"Dirt Explosion Bullets",::bulletFx,"env/dirt/fx_ks_dirt_lg_impact");
	addOpt(5,7,"Snow Bullets",::bulletFx,"maps/zombie/fx_mp_zombie_hand_snow_burst");
	addOpt(5,8,"Couch FX Bullets",::bulletFx,"misc/fx_zombie_couch_effect");

	if(GetMap()== "NZP")addOpt(5,9,"Normal Bullets",::normal_bullets);
	if(GetMap()== "NZF")
	{
		addOpt(5,9,"Steam Bullets",::bulletFx,"maps/zombie/fx_zombie_mainframe_steam");
		addOpt(5,10,"Orbital Bullets",::bulletFx,"maps/zombie/fx_zombie_mainframe_link_all");
		addOpt(5,11,">>Next Page<<",::NewMenu,30);
	}
	self.Title[30]="Bullet FX Menu [Page 2]";
	self.MenuNames[30]=[];
	addOpt(30,0,"Zombie Rise Bullets",::bulletFx,"maps/mp_maps/fx_mp_zombie_hand_dirt_burst");
	addOpt(30,1,"Dog Spawn Bullets",::bulletFx,"maps/zombie/fx_zombie_dog_lightning_buildup");
	addOpt(30,2,"Tele Start Bullets",::bulletFx,"maps/zombie/fx_transporter_pad_start");
	addOpt(30,3,"PaP Bullets",::bulletFx,"maps/zombie/fx_zombie_packapunch");
	addOpt(30,4,"Normal Bullets",::normal_bullets);
	self.Title[4]="Vision Menu";
	self.MenuNames[4]=[];
	addOpt(4, 0, "Zombie Stop", ::ChangeVision, "zombie_stop");
    addOpt(4, 1, "Zombie Turned", ::ChangeVision, "zombie_death");
    addOpt(4, 2, "default Night", ::ChangeVision, "default_night");
    addOpt(4, 3, "Contrast", ::ChangeVision, "cheat_contrast");
    addOpt(4, 4, "Black And White", ::ChangeVision, "cheat_bw");
    addOpt(4, 5, "Cheat Bw Contrast", ::ChangeVision, "cheat_bw_contrast");
    addOpt(4, 6, "cheat bw invert", ::ChangeVision, "cheat_bw_invert");
	addOpt(4, 7, "Flash Grenade", ::ChangeVision, "flash_grenade");
	addOpt(4, 8, "infrared", ::ChangeVision, "infrared");
	addOpt(4, 9, "infrared snow", ::ChangeVision, "infrared_snow");
	addOpt(4, 10, "laststand", ::ChangeVision, "laststand");
	addOpt(4, 11, "low health", ::ChangeVision, "low_health");
	addOpt(4, 12, "Default", ::ChangeVision, "default");
	self.Title[9]="Player Menu";
	self.MenuNames[9]=[];
	player=get_players();
	for(i=0;i < player.size;i++)
	{
		addOpt(9,i,""+player[i].playername+" [^2"+player[i].Permlevel+"^7]",::Playas);
	}
	self.MenuNames[14]=[];
	addOpt(14,0,"Verify Player",::verification,"Verified");
	addOpt(14,1,"Vip Player",::verification,"VIP");
	addOpt(14,2,"Cohost Player",::verification,"Cohost");
	addOpt(14,3,"Admin Player",::verification,"Admin");
	addOpt(14,4,"Kick Player",::NewMenu,15);
	addOpt(14,5,"Toggle Jail",::togglejail);
	addOpt(14,6,"Derank Player",::derank);
	addOpt(14,7,"Give Bad Dvars",::InfectBad);
	addOpt(14,8,"Toggle Freeze",::pfreeze);
	addOpt(14,9,"Summon Player",::summon);
	addOpt(14,10,"Toggle Weapons",::playerweaps);
	addOpt(14,11,">>More Options<<",::NewMenu,16);
	self.Title[15]="Kick How?";
	self.MenuNames[15]=[];
	addOpt(15,0,"Kick From Lobby",::Kick);
	addOpt(15,1,"Kick To Singleplayer",::KickS);
	addOpt(15,2,"Kick To Multiplayer",::KickM);
	addOpt(15,3,"Kick To Dashboard/XMB",::KickD);
	self.Title[16]="More Options";
	self.MenuNames[16]=[];
	addOpt(16,0,"Give Menu Secretly",::menuSecret);
	addOpt(16,1,"Toggle Menu",::lockPlayer);
	addOpt(16,2,"Give Binds",::infectplayer);
	addOpt(16,3,"Remove Binds",::defect);
	addOpt(16,4,"Edit Prestige",::NewMenu,17);
	addOpt(16,5,"Edit Score",::Score,"Other");
	addOpt(16,6,"Kill Player",::killP);
	addOpt(16,7,"Revive Player",::reviveP);
	addOpt(16,8,"Unlock Trophies",::UnlockT);
	addOpt(16,9,"Unlock Attachments",::UnlockA);
	addOpt(16,10,"Unlock Challenges",::UnlockC);
	addOpt(16,11,"Unlock Deathcards",::UnlockD);
	self.Title[17]="Edit Prestige";
	self.MenuNames[17]=[];
	addOpt(17,0,"Prestige 0",::PlayerPres,0);
	addOpt(17,1,"Prestige 1",::PlayerPres,1);
	addOpt(17,2,"Prestige 2",::PlayerPres,2);
	addOpt(17,3,"Prestige 3",::PlayerPres,3);
	addOpt(17,4,"Prestige 4",::PlayerPres,4);
	addOpt(17,5,"Prestige 5",::PlayerPres,5);
	addOpt(17,6,"Prestige 6",::PlayerPres,6);
	addOpt(17,7,"Prestige 7",::PlayerPres,7);
	addOpt(17,8,"Prestige 8",::PlayerPres,8);
	addOpt(17,9,"Prestige 9",::PlayerPres,9);
	addOpt(17,10,"Prestige 10",::PlayerPres,10);
	addOpt(17,11,"Prestige 11",::PlayerPres,11);
	self.Title[3]="Menu Customization";
	self.MenuNames[3]=[];
	addOpt(3,0,"Edit Scroller",::CustomS,"Scroller");
	addOpt(3,1,"Edit Scroller Icon",::CustomSI);
	addOpt(3,2,"Edit Background",::CustomS,"Background");
	addOpt(3,3,"Edit Scroller Color",::CustomC,"Scroller");
	addOpt(3,4,"Edit Background Color",::CustomC,"Background");
	addOpt(3,5,"Edit Text Color",::CustomC,"Text");
	addOpt(3,6,"Edit Title Color",::CustomC,"Title");
	if(self.SStyle=="DV3")addOpt(3,7,"Menu Style: ^3Discarded v2",::ScrollStyle,"DV2");
	else addOpt(3,7,"Menu Style: ^3Discarded v3",::ScrollStyle,"DV3");
	if(self.MenuPos=="Right")addOpt(3,8,"Menu Position: ^3Middle",::MenuPosition,"Middle");
	else addOpt(3,8,"Menu Position: ^3Right",::MenuPosition,"Right");
	self.MenuNames[21]=[];
	addOpt(21,0,"Gradient",::CustomSS,"gradient");
    addOpt(21,1,"Health Compass",::CustomSS,"overlay_low_health_compass");
    addOpt(21,2,"Perk Machine Icon",::CustomSS,"minimap_icon_juggernog");
    addOpt(21,3,"Minimap Reload",::CustomSS,"minimap_icon_reload");
    addOpt(21,4,"Ui Host",::CustomSS,"ui_host");
    addOpt(21,5,"Scorebar Long",::CustomSS,"scorebar_zom_long_1");
    addOpt(21,6,"Faded Line",::CustomSS,"menu_white_line_faded");
    addOpt(21,7,"Hud Chalk",::CustomSS,"hud_chalk_1");
    addOpt(21,8,"Rectangle",::CustomSS,"white");
    addOpt(21,9,"Doublepoints",::CustomSS,"specialty_doublepoints_zombies");
	if(GetMap()== "NZF")addOpt(21,10,"Der Riese Map",::CustomSS,"menu_map_nazi_zombie_factory");
	else addOpt(21,10,"Zombie Intro",::CustomSS,"zombie_intro");
	self.MenuNames[22]=[];
	addOpt(22,0,"Black",::CustomCC,(0,0,0));
	addOpt(22,1,"Pink",::CustomCC,(1,0.41,0.71));
	addOpt(22,2,"Red",::CustomCC,(1,0,0));
	addOpt(22,3,"Cyan",::CustomCC,(0,1,1));
	addOpt(22,4,"Blue",::CustomCC,(0,0,1));
	addOpt(22,5,"Green",::CustomCC,(0,1,0));
	addOpt(22,6,"Orange",::CustomCC,(1,0.5,0));
	addOpt(22,7,"Purple",::CustomCC,(1,0,1));
	addOpt(22,8,"Yellow",::CustomCC,(1,1,0));
	addOpt(22,9,"White",::CustomCC,(255,255,255));
	self.Title[1]="Main Mods";
	self.MenuNames[1]=[];
	addOpt(1,0,"God Mode",::toggle_God);
	addOpt(1,1,"Noclip",::noClip);
	addOpt(1,2,"No Target",::noTarget);
	addOpt(1,3,"Choose Weapon",::ChooseWeapon);
	addOpt(1,4,"All Weapons",::AllWeapons);
	addOpt(1,5,"Give Perks",::NewMenu,43);
	addOpt(1,6,"Unlimited Ammo",::unlimAmmo);
	addOpt(1,7,"Move In Menu",::Moveyy);
	addOpt(1,8,"Edit Score",::Score,"Self");
	addOpt(1,9,"Requests Menu",::NewMenu,42);
	self.Title[43]="Give Perks";
	self.MenuNames[43]=[];
	addOpt(43,0,"Give Double Tap",::PerkDecide,"specialty_rof");
	addOpt(43,1,"Give Speed Cola",::PerkDecide,"specialty_fastreload");
	addOpt(43,2,"Give Quick Revive",::PerkDecide,"specialty_quickrevive");
	addOpt(43,3,"Give Juggernog",::PerkDecide,"specialty_armorvest");
	addOpt(43,4,"Give PHD",::PerkDecide,"specialty_flakjacket");
	addOpt(43,5,"Give Stamin",::PerkDecide,"specialty_longersprint");
	addOpt(43,6,"Give Deadshot",::PerkDecide,"specialty_deadshot");
	addOpt(43,7,"Give MuleKick",::PerkDecide,"specialty_additionalprimaryweapon");

	self.Title[42]="Request What?";
	self.MenuNames[42]=[];
	addOpt(42,0,"Request VIP",::Req,"VIP Status");
	addOpt(42,1,"Request Cohost",::Req,"Cohost Status");
	addOpt(42,2,"Request Admin",::Req,"Admin Status");
	addOpt(42,3,"Request Trophies",::Req,"Trophies");
	addOpt(42,4,"Request Challenges",::Req,"Challenges");
	addOpt(42,5,"Request Attachments",::Req,"Attachments");
	addOpt(42,6,"Request Deathcards",::Req,"Deathcards");
	addOpt(42,7,"Request 10th Prestige",::Req,"10th Prestige");
	addOpt(42,8,"Request 11th Prestige",::Req,"11th Prestige");
	self.Title[23]="Edit Current Score";
	self.MenuNames[23]=[];
	addOpt(23,0,"Max Out Score",::DoScore,2114748370);
	addOpt(23,1,"+1,000,000",::DoScore,1000000);
	addOpt(23,2,"+100,000",::DoScore,100000);
	addOpt(23,3,"+10,000",::DoScore,10000);
	addOpt(23,4,"+1,000",::DoScore,1000);
	addOpt(23,5,"+500",::DoScore,500);
	addOpt(23,6,"Reset Score",::ResetScore);
	addOpt(23,7,"-500",::DoScore,-500);
	addOpt(23,8,"-1,000",::DoScore,-1000);
	addOpt(23,9,"-10,000",::DoScore,-10000);
	addOpt(23,10,"-100,000",::DoScore,-100000);
	addOpt(23,11,"-1,000,000",::DoScore,-1000000);
	self.Title[6]="Fun Menu";
	self.MenuNames[6]=[];
	addOpt(6,0,"Invisible",::invis);
	addOpt(6,1,"Kamikaze",::DoKam);
	addOpt(6,2,"Edit Fog/Sun",::NewMenu,41);
	addOpt(6,3,"Dolphin Dive",::DolphinDive);
	addOpt(6,4,"Make A Clone",::clone);
	addOpt(6,5,"Third Person",::toggle_third);
	addOpt(6,6,"Ice Skater",::IceSkater);
	addOpt(6,7,"Upside Down Map",::upside);
	addOpt(6,8,"Right Side Map",::rightside);
	addOpt(6,9,"Left Side Map",::leftside);
	addOpt(6,10,"Normal Map",::normalside);
	addOpt(6,11,">>Next Page<<",::NewMenu,32);
	self.Title[41]="Edit Fog/Sun";
	self.MenuNames[41]=[];
	addOpt(41,0,"Fog Editor",::RGBSlider,"Fog");
	addOpt(41,1,"Sun Editor",::RGBSlider,"Sun");
	addOpt(41,2,"^5D^1i^2s^3c^6o ^7Fog",::disco_fog);
	addOpt(41,3,"^5D^1i^2s^3c^6o ^7Sun",::disco_sun);
	self.Title[32]="Fun Menu [Page 2]";
	self.MenuNames[32]=[];
	addOpt(32,0,"Zombify Yourself",::Tgl_Zombify);
	addOpt(32,1,"Drunk Mode",::doSooWasted);
	addOpt(32,2,"Pro Mod Editor",::EditDvar,"cg_fov");
	addOpt(32,3,"Gore Mode",::toggle_gore);
	addOpt(32,4,"Gun On Left Side",::toggle_gunleft);
	addOpt(32,5,"Flashing Player",::toggle_visibility);
	addOpt(32,6,"Auto Tea-bag",::autoTeaBag);
	addOpt(32,7,"Ninja Mode",::DoNinja);
	addOpt(32,8,"Spec-Nade",::SpecNade);
	addOpt(32,9,"Water Drizzle",::Drizzling);
	addOpt(32,10,"Decapitate Head",::Decap);
	addOpt(32,11,"Teleport To Crosshair",::TOCH);
	self.Title[20]="VIP Menu";
	self.MenuNames[20]=[];
	addOpt(20,0,"Aimbot",::toggle_aimbot);
	addOpt(20,1,"Forge Pickup",::FPUM);
	addOpt(20,2,"Ghost Rider",::Ghosty);
	addOpt(20,3,"Gaurdian Angel",::Angel);
	addOpt(20,4,"Orbital Strike",::Orbit);
	addOpt(20,5,"Jetpack",::jetpack);
	addOpt(20,6,"Gersch Device",::gerschDevice);
	addOpt(20,7,"Nuke Nades",::doSupaNades);
	addOpt(20,8,"Death Skull",::CDS);
	addOpt(20,9,"New Death Skull",::deathSkull);
	addOpt(20,10,"Spawn All Weapons",::dropWeaponsAtChs);
	addOpt(20,11,">>Next Page<<",::NewMenu,33);
	self.Title[33]="VIP Menu [Page 2]";
	self.MenuNames[33]=[];
	addOpt(33,0,"Custom Crosshair",::NewMenu,34);
	addOpt(33,1,"Zombie Counter",::zombCount);
	addOpt(33,2,"Drivable Car",::DoCar);
	addOpt(33,3,"Attack Helicopter",::HeliCopter);
	addOpt(33,4,"Shoot Powerups",::toggle_spawnpu);
	if(self.CHOP=="Reg")addOpt(33,5,"Chopper Gunner[^2Regular^7]",::ChopperGunner);
	else addOpt(33,5,"Chopper Gunner[^2Walking^7]",::WalkingCG);
	if(self.AC=="Reg")addOpt(33,6,"AC130[^2Regular^7]",::initAC130);
	else addOpt(33,6,"AC130[^2Walking^7]",::initAC130,true);
	if(self.REAP=="Reg")addOpt(33,7,"Mw3 Reaper[^2Regular^7]",::Reaper,true);
	else addOpt(33,7,"Mw3 Reaper[^2Walking^7]",::Reaper,false);
	addOpt(33,8,"Valkyrie Missle",::valkyrieMissile);
	addOpt(33,9,"Modded Weapons",::NewMenu,44);
	if( IsSubStr( level.script, "zombie_cod5_factory" ) )
	{
		addOpt(33,10,"Attack UFO",::UFO);
		addOpt(33,11,"Flyable UFO",::flyableUfo);
	}
	self.Title[44]="Modded Weapons";
	self.MenuNames[44]=[];
	addOpt(44,0,"Thunder M1911",::doThunderColt);
	addOpt(44,1,"RPG Python",::doRPGMagnum);
	addOpt(44,2,"Delete Gun",::doDG);
	addOpt(44,3,"Water Gun",::doWaterGun);
	self.Title[34]="Custom Crosshair";
	self.MenuNames[34]=[];
	addOpt(34,0,"Toggle Custom",::CrossHairzz);
	addOpt(34,1,"<3",::CustomCH,"<3");
	addOpt(34,2,"+",::CustomCH,"+");
	addOpt(34,3,"(O.o)",::CustomCH,"(O.o)");
	addOpt(34,4,"(|)",::CustomCH,"(|)");
	addOpt(34,5,"8==D",::CustomCH,"8==D");
	addOpt(34,6,":)",::CustomCH,":)");
	addOpt(34,7,"(/^_^)/",::CustomCH,"(/^_^)/");
	addOpt(34,8,"$$$",::CustomCH,"$$$");
	addOpt(34,9,"O'RLY?",::CustomCH,"O'RLY?");
	addOpt(34,10,"Lol",::CustomCH,"Lol");
	addOpt(34,11,"xMasterModzx",::CustomCH,"xMasterModzx");
	self.Title[25]="Lobby Settings";
	self.MenuNames[25]=[];
	addOpt(25,0,"Jump Height",::EditDvar,"jump_height");
	addOpt(25,1,"Gravity",::EditDvar,"g_gravity");
	addOpt(25,2,"Game Speed",::EditDvar,"g_speed");
	addOpt(25,3,"Melee Range",::EditDvar,"player_meleeRange");
	addOpt(25,4,"Revive Radius",::EditDvar,"revive_trigger_radius");
	addOpt(25,5,"Double Tap Rate",::EditDvar,"perk_weapRateMultiplier");
	addOpt(25,6,"Speed Cola Rate",::EditDvar,"perk_weapReloadMultiplier");
	addOpt(25,7,"Unlimited Ammo",::AllAmmo);
	self.Title[26]="Rain Objects";
	self.MenuNames[26]=[];
	addOpt(26,0,"Default Vehicles",::doRain,"defaultvehicle");
	addOpt(26,1,"Default Actors",::doRain,"defaultactor");
	addOpt(26,2,"Dev Spheres",::doRain,"test_sphere_silver");
	addOpt(26,3,"Nuke Bombs",::doRain,"zombie_bomb");
	addOpt(26,4,"Skulls",::doRain,"zombie_skull");
	addOpt(26,5,"Couches",::doRain,"static_berlin_victorian_couch_d");
	addOpt(26,6,"Max Ammos",::doRain,"zombie_ammocan");
	addOpt(26,7,"Mystery Boxes",::doRain,"zombie_treasure_box");
	addOpt(26,8,"Mystery Box Lids",::doRain,"zombie_treasure_box_lid");
	if(GetMap()== "NZP")
	{
		addOpt(26,9,"Exploding Spheres",::doBombRain);
		addOpt(26,10,"Short Crates",::doRain,"static_peleliu_crate01_short");
		addOpt(26,11,"Turn Raining Off",::RainOff);
	}
	if(GetMap()== "NZF")
	{
		addOpt(26,9,"Wallclocks",::doRain,"zombie_wallclock_main");
		addOpt(26,10,"Double Tap Machines",::doRain,"zombie_vending_doubletap_on");
		addOpt(26,11,">>Next Page<<",::NewMenu,31);
	}
	self.Title[31]="Rain Objects [Page 2]";
	self.MenuNames[31]=[];
	addOpt(31,0,"Juggernog Machines",::doRain,"zombie_vending_jugg_on");
	addOpt(31,1,"Quick Revive Machines",::doRain,"zombie_vending_revive_on");
	addOpt(31,2,"Speed Cola Machines",::doRain,"zombie_vending_sleight_on");
	addOpt(31,3,"Zombie Wolfs",::doRain,"zombie_wolf");
	addOpt(31,4,"Pack 'a' Punch",::doRain,"zombie_vending_packapunch_on");
	addOpt(31,5,"Chalkboards",::doRain,"zombie_chalkboard");
	addOpt(31,6,"Teddy Bears",::doRain,"zombie_teddybear_shanks");
	addOpt(31,7,"Zombie Beakers",::doRain,"zombie_beaker_brain");
	addOpt(31,8,"Exploding Spheres",::doBombRain);
	addOpt(31,9,"Wunder Waffles",::doWunder);
	addOpt(31,10,"Turn Off Raining",::RainOff);
	self.Title[12]="Admin Menu";
	self.MenuNames[12]=[];
	addOpt(12,0,"Lobby Settings",::NewMenu,25);
	addOpt(12,1,"Rain Objects",::NewMenu,26);
	addOpt(12,2,"Bullet Tracers",::bulletTracers);
	addOpt(12,3,"Messages",::NewMenu,24);
	addOpt(12,4,"Zombie Boss",::Boss);
	addOpt(12,5,"Force Host",::ForceHost);
	addOpt(12,6,"Edit Round",::StartRound);
	addOpt(12,7,"Round Text",::NewMenu,27);
	addOpt(12,8,"Advertise Lobby",::doAdvert);
	addOpt(12,9,"Anti-Cheat",::antiCheat);
	addOpt(12,10,"Anti-Leave",::antiLeave);
	addOpt(12,11,">>Next Page<<",::NewMenu,28);
	self.Title[28]="Admin Menu [Page 2]";
	self.MenuNames[28]=[];
	addOpt(28,0,"News Bar",::toggle_bar);
	addOpt(28,1,"All To Crosshair",::toggle_doTeleAll);
	addOpt(28,2,"Play Secret Song",::EggSong);
	addOpt(28,3,"Shoot To Revive",::collectible_shootrevive);
	addOpt(28,4,"Paintball Bullets",::collectible_paint);
	addOpt(28,5,"Enable Double Points",::doublePoints);
	addOpt(28,6,"Enable Insta Kill",::instaKill);
	addOpt(28,7,"Restart Lobby",::quickRestart);
	addOpt(28,8,"Open All Doors",::openAllDoor);
	if(GetMap()== "NZT")
	{
	 addOpt(28,9,"Turn On Power",::zombiePower);
	 addOpt(28,10,">>Next Page<<",::NewMenu,35);
	}
	if(GetMap()== "NPZ")
	{
	addOpt(28,9,"Turn On Power",::zombiePower);
	addOpt(28,10,">>Next Page<<",::NewMenu,35);
	}
	if(GetMap()== "NZC")
	{
	addOpt(28,9,"Turn On Power",::zombiePower);
	addOpt(28,10,">>Next Page<<",::NewMenu,35);
	}
	if(GetMap()== "NZD")
	{
	addOpt(28,9,"Turn On Power",::zombiePower);
	addOpt(28,10,">>Next Page<<",::NewMenu,35);
	}
	if(GetMap()== "NZS")
	{
	addOpt(28,9,"Turn On Power",::zombiePower);
	addOpt(28,10,">>Next Page<<",::NewMenu,35);
	}
	if(GetMap()== "NZM")
	{
	addOpt(28,9,"Turn On Power",::zombiePower);
	addOpt(28,10,">>Next Page<<",::NewMenu,35);
	}
	if(GetMap()== "NZP")
	{
		addOpt(28,9,"Auto Revive",::autoRevive);
		addOpt(28,10,"Timed Lobby",::NewMenu,1337);
		addOpt(28,11,">>Next Page<<",::NewMenu,35);
		self.parent[1337]=28;
	}
	if(GetMap()== "NZF")
	{
		addOpt(28,9,"Turn On Power",::zombiePower);
		addOpt(28,10,"Link All Teleporters",::linkTeles);
		addOpt(28,11,">>Next Page<<",::NewMenu,35);
	}
	self.Title[35]="Admin Menu [Page 3]";
	self.MenuNames[35]=[];
	if(GetMap()== "NZP")
	{
		addOpt(35,0,"Forced Powerups",::Forceall);
		addOpt(35,1,"Nuke Powerup",::doPowerupz,"nuke");
		addOpt(35,2,"Insta-Kill Powerup",::doPowerupz,"insta_kill");
		addOpt(35,3,"Double Points Powerup",::doPowerupz,"double_points");
		addOpt(35,4,"Max Ammo Powerup",::doPowerupz,"full_ammo");
		addOpt(35,5,"Friendly Fire",::Tgl_Friendly);
		addOpt(35,6,"Fake Derank",::doFake);
		addOpt(35,7,"Watch Videos",::NewMenu,39);
		addOpt(35,8,"End Game Nuke",::MOAB);
		addOpt(35,9,"End Game Credits",::creditz);
	}
	if(GetMap()== "NZF")
	{
		addOpt(35,0,"Timed Lobby",::NewMenu,1337);
		addOpt(35,1,"Forced Powerups",::Forceall);
		addOpt(35,2,"Nuke Powerup",::doPowerupz,"nuke");
		addOpt(35,3,"Insta-Kill Powerup",::doPowerupz,"insta_kill");
		addOpt(35,4,"Double Points Powerup",::doPowerupz,"double_points");
		addOpt(35,5,"Max Ammo Powerup",::doPowerupz,"full_ammo");
		addOpt(35,6,"Friendly Fire",::Tgl_Friendly);
		addOpt(35,7,"Auto Revive",::autoRevive);
		addOpt(35,8,"Fake Derank",::doFake);
		addOpt(35,9,"Watch Videos",::NewMenu,39);
		addOpt(35,10,"End Game Nuke",::MOAB);
		addOpt(35,11,"End Game Credits",::creditz);
		self.parent[1337]=35;
	}
	// 1
	if(GetMap()== "NZT")
	{
		addOpt(35,0,"Timed Lobby",::NewMenu,1337);
		addOpt(35,1,"Forced Powerups",::Forceall);
		addOpt(35,2,"Nuke Powerup",::doPowerupz,"nuke");
		addOpt(35,3,"Insta-Kill Powerup",::doPowerupz,"insta_kill");
		addOpt(35,4,"Double Points Powerup",::doPowerupz,"double_points");
		addOpt(35,5,"Max Ammo Powerup",::doPowerupz,"full_ammo");
		addOpt(35,6,"Friendly Fire",::Tgl_Friendly);
		addOpt(35,7,"Auto Revive",::autoRevive);
		addOpt(35,8,"Fake Derank",::doFake);
		addOpt(35,9,"Watch Videos",::NewMenu,39);
		addOpt(35,10,"End Game Nuke",::MOAB);
		addOpt(35,11,"End Game Credits",::creditz);
		self.parent[1337]=35;
	}
	// 2
	if(GetMap()== "NPZ")
	{
		addOpt(35,0,"Timed Lobby",::NewMenu,1337);
		addOpt(35,1,"Forced Powerups",::Forceall);
		addOpt(35,2,"Nuke Powerup",::doPowerupz,"nuke");
		addOpt(35,3,"Insta-Kill Powerup",::doPowerupz,"insta_kill");
		addOpt(35,4,"Double Points Powerup",::doPowerupz,"double_points");
		addOpt(35,5,"Max Ammo Powerup",::doPowerupz,"full_ammo");
		addOpt(35,6,"Friendly Fire",::Tgl_Friendly);
		addOpt(35,7,"Auto Revive",::autoRevive);
		addOpt(35,8,"Fake Derank",::doFake);
		addOpt(35,9,"Watch Videos",::NewMenu,39);
		addOpt(35,10,"End Game Nuke",::MOAB);
		addOpt(35,11,"End Game Credits",::creditz);
		self.parent[1337]=35;
	}
	// 3
	if(GetMap()== "NZC")
	{
		addOpt(35,0,"Timed Lobby",::NewMenu,1337);
		addOpt(35,1,"Forced Powerups",::Forceall);
		addOpt(35,2,"Nuke Powerup",::doPowerupz,"nuke");
		addOpt(35,3,"Insta-Kill Powerup",::doPowerupz,"insta_kill");
		addOpt(35,4,"Double Points Powerup",::doPowerupz,"double_points");
		addOpt(35,5,"Max Ammo Powerup",::doPowerupz,"full_ammo");
		addOpt(35,6,"Friendly Fire",::Tgl_Friendly);
		addOpt(35,7,"Auto Revive",::autoRevive);
		addOpt(35,8,"Fake Derank",::doFake);
		addOpt(35,9,"Watch Videos",::NewMenu,39);
		addOpt(35,10,"End Game Nuke",::MOAB);
		addOpt(35,11,"End Game Credits",::creditz);
		self.parent[1337]=35;
	}
	// 4
	if(GetMap()== "NZD")
	{
		addOpt(35,0,"Timed Lobby",::NewMenu,1337);
		addOpt(35,1,"Forced Powerups",::Forceall);
		addOpt(35,2,"Nuke Powerup",::doPowerupz,"nuke");
		addOpt(35,3,"Insta-Kill Powerup",::doPowerupz,"insta_kill");
		addOpt(35,4,"Double Points Powerup",::doPowerupz,"double_points");
		addOpt(35,5,"Max Ammo Powerup",::doPowerupz,"full_ammo");
		addOpt(35,6,"Friendly Fire",::Tgl_Friendly);
		addOpt(35,7,"Auto Revive",::autoRevive);
		addOpt(35,8,"Fake Derank",::doFake);
		addOpt(35,9,"Watch Videos",::NewMenu,39);
		addOpt(35,10,"End Game Nuke",::MOAB);
		addOpt(35,11,"End Game Credits",::creditz);
		self.parent[1337]=35;
	}
	// 5
	if(GetMap()== "NZS")
	{
		addOpt(35,0,"Timed Lobby",::NewMenu,1337);
		addOpt(35,1,"Forced Powerups",::Forceall);
		addOpt(35,2,"Nuke Powerup",::doPowerupz,"nuke");
		addOpt(35,3,"Insta-Kill Powerup",::doPowerupz,"insta_kill");
		addOpt(35,4,"Double Points Powerup",::doPowerupz,"double_points");
		addOpt(35,5,"Max Ammo Powerup",::doPowerupz,"full_ammo");
		addOpt(35,6,"Friendly Fire",::Tgl_Friendly);
		addOpt(35,7,"Auto Revive",::autoRevive);
		addOpt(35,8,"Fake Derank",::doFake);
		addOpt(35,9,"Watch Videos",::NewMenu,39);
		addOpt(35,10,"End Game Nuke",::MOAB);
		addOpt(35,11,"End Game Credits",::creditz);
		self.parent[1337]=35;
	}
	// 6
	if(GetMap()== "NZM")
	{
		addOpt(35,0,"Timed Lobby",::NewMenu,1337);
		addOpt(35,1,"Forced Powerups",::Forceall);
		addOpt(35,2,"Nuke Powerup",::doPowerupz,"nuke");
		addOpt(35,3,"Insta-Kill Powerup",::doPowerupz,"insta_kill");
		addOpt(35,4,"Double Points Powerup",::doPowerupz,"double_points");
		addOpt(35,5,"Max Ammo Powerup",::doPowerupz,"full_ammo");
		addOpt(35,6,"Friendly Fire",::Tgl_Friendly);
		addOpt(35,7,"Auto Revive",::autoRevive);
		addOpt(35,8,"Fake Derank",::doFake);
		addOpt(35,9,"Watch Videos",::NewMenu,39);
		addOpt(35,10,"End Game Nuke",::MOAB);
		addOpt(35,11,"End Game Credits",::creditz);
		self.parent[1337]=35;
	}
	self.Title[39]="Select A Video";
	self.MenuNames[39]=[];
	addOpt(39,0,"ber1_load",::PlayVid,"");
	addOpt(39,1,"ber2_load",::PlayVid,"");
	addOpt(39,2,"ber3_load",::PlayVid,"");
	addOpt(39,3,"ber3b_load",::PlayVid,"");
	addOpt(39,4,"default",::PlayVid,"");
	addOpt(39,5,"intro_pac_load",::PlayVid,"");
	addOpt(39,6,"mak_load",::PlayVid,"");
	addOpt(39,7,"nazi_zombie_prototype_load",::PlayVid,"");
	addOpt(39,8,"oki2_load",::PlayVid,"");
	addOpt(39,9,"oki3_load",::PlayVid,"");
	addOpt(39,10,"outro_load",::PlayVid,"");
	addOpt(39,11,">>Next Page<<",::NewMenu,40);
	self.Title[40]="Select A Video [Page 2]";
	self.MenuNames[40]=[];
	addOpt(40,0,"pby_fly_load",::PlayVid,"");
	addOpt(40,1,"pel_load",::PlayVid,"");
	addOpt(40,2,"pel1a_load",::PlayVid,"");
	addOpt(40,3,"pel1b_load",::PlayVid,"");
	addOpt(40,4,"pel2_load",::PlayVid,"");
	addOpt(40,5,"see1_load",::PlayVid,"");
	addOpt(40,6,"see2_load",::PlayVid,"");
	addOpt(40,7,"sniper_load",::PlayVid,"");
	addOpt(40,8,"Treyarch",::PlayVid,"");
	addOpt(40,9,"Stop Playing Videos",::StopVid);
	self.Title[27]="Round Text";
	self.MenuNames[27]=[];
	addOpt(27,0,"Discarded v3",::roundEdit,"Discarded v3");
	addOpt(27,1,"xMasterModzx",::roundEdit,"xMasterModzx");
	addOpt(27,2,"Hello Noobz",::roundEdit,"Hello Noobz");
	addOpt(27,3,"u Mad Bro?",::roundEdit,"u Mad Bro?");
	addOpt(27,4,"I Be Trollin' xD",::roundEdit,"I Be Trollin' xD");
	addOpt(27,5,"What The Fuck?",::roundEdit,"What The Fuck?");
	addOpt(27,6,"Who's Hacking?",::roundEdit,"Who's Hacking?");
	addOpt(27,7,"SE[{+gostand}]Y",::roundEdit,"SE[{+gostand}]Y");
	addOpt(27,8,"Fuck You",::roundEdit,"Fuck You");
	addOpt(27,9,"I HAX DA ROUNDZ",::roundEdit,"I HAX DA ROUNDZ");
	addOpt(27,10,""+get_Players()[0].playername+"",::roundEdit,""+get_Players()[0].playername+"");
	addOpt(27,11,"Reset Round",::ResetRound);
	self.Title[13]="Gametypes";
	self.MenuNames[13]=[];
	addOpt(13,0,"Mod Menu Lobby",::SelectGT,"Mod Menu");
	addOpt(13,1,"Hide 'n' Seek",::SelectGT,"Hide");
	addOpt(13,2,"Sharpshooter",::SelectGT,"Sharp");
	addOpt(13,3,"Roll The Dice",::RollDaDice);
	addOpt(13,4,"Nazi Zombies Pro",::NaziPro);
	addOpt(13,5,"In And Out v3.5",::InandOut);
	addOpt(13,6,"Freeze Tag",::freezetag);
	addOpt(13,7,"All The Weapons",::SelectGT,"All Weapons");
	addOpt(13,8,"Forge Lobby",::SelectGT,"Forge");
	if(GetMap()== "NZP")addOpt(13,9,"Unity Campaign",::UnityStart);
	self.Title[36]="Mod Menu Lobby";
	self.MenuNames[36]=[];
	addOpt(36,0,"Everybody ^2Unverified",::doMenu,"Unverified");
	addOpt(36,1,"Everybody ^2Verified",::doMenu,"Verified");
	addOpt(36,2,"Everybody ^2VIP",::doMenu,"VIP");
	addOpt(36,3,"Everybody ^2Cohost",::doMenu,"Cohost");
	addOpt(36,4,"Everybody ^2Admin",::doMenu,"Admin");
	self.Title[45]="Pick A Seeker";
	self.MenuNames[45]=[];
	for(i=0;i < player.size;i++)
	{
		addOpt(45,i,""+player[i].playername+"",::doHidenSeek,i);
	}
	self.Title[37]="Game Options";
	self.MenuNames[37]=[];
	if(level.AllG==0)addOpt(37,0,"God Mode [^1OFF^7]",::Optionz,"God");
	else addOpt(37,0,"God Mode [^2ON^7]",::Optionz,"God");
	if(level.AllA==0)addOpt(37,1,"Unlimited Ammo [^1OFF^7]",::Optionz,"Ammo");
	else addOpt(37,1,"Unlimited Ammo [^2ON^7]",::Optionz,"Ammo");
	if(level.Sharp==false)
	{
		if(level.All==0)addOpt(37,2,"Against [^1Zombies^7]",::Optionz,"Against");
		else addOpt(37,2,"Against [^2Players^7]",::Optionz,"Against");
		addOpt(37,3,"^2Start Game",::AllDaWeapons);
	}
	else addOpt(37,2,"^2Start Game",::Sharpy);
	self.Title[24]="Messages";
	self.MenuNames[24]=[];
	addOpt(24,0,"Hello Noobz",::Message,"Hello Noobz");
	addOpt(24,1,"STFU",::Message,"Shut The Fuck Up Kid");
	addOpt(24,2,"Stop Asking",::Message,"Stop Asking For The Mod Menu!");
	addOpt(24,3,"Don't Spam",::Message,"Don't Fucking Spam Me");
	addOpt(24,4,"Deranked?",::Message,"Wanna Get Deranked?");
	addOpt(24,5,"Yes",::Message,"Yes");
	addOpt(24,6,"No",::Message,"No");
	addOpt(24,7,"Ok",::Message,"Ok");
	addOpt(24,8,"The Boss",::Message,""+get_players()[0].playername+" Is The Fucking Boss!!!");
	addOpt(24,9,"Patch",::Message,"You Are Playing Discarded v3 By xMasterModzx <3");
	addOpt(24,10,"Awesome Message",::Message,"Subscribe > Youtube.com/Homiethefluff");
	addOpt(24,11,"Button Spam",::Buttonz);
	self.Title[10]="Zombie Menu";
	self.MenuNames[10]=[];
	addOpt(10,0,"Eliminate Zombies",::killZombiesWithinDistance,(0,0,0),1000000,"headGib");
	addOpt(10,1,"Freeze/Unfreeze Zombies",::ToggleZF);
	addOpt(10,2,"Gunner Zombies",::GunnerZombs);
	addOpt(10,3,"Zombies To Crosshair",::ZombzCrossH);
	addOpt(10,4,"Zombie Stance: Stand",::zombiestand);
	addOpt(10,5,"Zombie Stance: Crouch",::zombiecrouch);
	addOpt(10,6,"Zombie Stance: Prone",::zombieprone);
	addOpt(10,7,"Make Them Chicks",::ZombChick);
	if(GetMap()== "NZF")
	{
		addOpt(10,8,"Make Them Dogs",::ZombDog);
		addOpt(10,9,"Musical Zombies",::musicZombies);
		addOpt(10,10,"Normal Zombies",::ZombN);
	}
	if(GetMap()== "NZP")addOpt(10,8,"Normal Zombies",::ZombN);
	self.Title[100]="Rotate Model";
	self.MenuNames[100]=[];
	addOpt(100,0,"Lean Forward",::RotPitchPos);
	addOpt(100,1,"Lean Back",::RotPitchNeg);
	addOpt(100,2,"Turn Right",::RotYawPos);
	addOpt(100,3,"Turn Left",::RotYawNeg);
	addOpt(100,4,"Lean +",::RotRollPos);
	addOpt(100,5,"Lean -",::RotRollNeg);
	addOpt(100,6,"Reset Model Angles",::RotReset);
	self.Title[1337]="Timer ["+level.Timer+"]";
	self.MenuNames[1337]=[];
	addOpt(1337,0,"1 Minute",::setLobbyTimer,1);
	addOpt(1337,1,"2 Minutes",::setLobbyTimer,2);
	addOpt(1337,2,"3 Minutes",::setLobbyTimer,3);
	addOpt(1337,3,"4 Minutes",::setLobbyTimer,4);
	addOpt(1337,4,"5 Minutes",::setLobbyTimer,5);
	addOpt(1337,5,"10 Minutes",::setLobbyTimer,10);
	addOpt(1337,6,"30 Minutes",::setLobbyTimer,30);
	addOpt(1337,7,"60 Minutes",::setLobbyTimer,60);
	addOpt(1337,8,"Start Timer",::startLobbyTimer);
}
SelectGT(Type)
{
	if(Type=="Mod Menu")
	{
		self thread NewMenu(36);
	}
	else if(Type=="All Weapons")
	{
		level.Sharp=false;
		self thread NewMenu(37);
	}
	else if(Type=="Hide")
	{
		if(get_players().size<=1)
		{
			self iPrintln("Hide and Seek Is ^1Unavailable ^7in Solo");
			return;
		}
		self thread NewMenu(45);
	}
	else if(Type=="Sharp")
	{
		level.Sharp=true;
		self thread NewMenu(37);
	}
	else if(Type=="Forge")
	{
		level.Forge=true;
		array_thread(get_Players(),::StartForge);
	}
}
CustomSI()
{
	self.ScrollShad++;
	if(self.ScrollShad==12)
	{
		self.ScrollIcon="ui_host";
		self.ScrollShad=-1;
	}
	else if(self.ScrollShad==0)self.ScrollIcon="rank_comm1";
	else self.ScrollIcon="rank_prestige"+self.ScrollShad+"";
	self iPrintln("Scoller Icon Set To: ^2"+self.ScrollIcon+"");
	self.MenuSCC destroy();
	if(self.MenuPos=="Right")self.MenuSCC=self createRectangle("CENTER","CENTER",75,self.MenuSC.y,20,20,(255,255,255),6,0,self.ScrollIcon);
	else self.MenuSCC=self createRectangle("CENTER","CENTER",-147,self.MenuSC.y,20,20,(255,255,255),6,0,self.ScrollIcon);
	self.MenuSCC Entity(0.2,undefined,undefined,0.7);
}
CustomS(bar)
{
	self.SBAR=bar;
	self.Title[21]="Edit "+bar+"";
	self thread Newmenu(21);
}
CustomC(bar)
{
	self.CBAR=bar;
	self.Title[22]="Edit "+bar+" Color";
	self thread Newmenu(22);
}
CustomSS(shdr)
{
	if(self.SBAR=="Background")
	{
		if(self.MenuPos=="Right")
		{
			self.MenuBG destroy();
			self.cSystem["BGs"]=shdr;
			self.MenuBG=self createRectangle("CENTER","CENTER",550,0,320,320,self.cSystem["BGc"],3,0.5,self.cSystem["BGs"]);
			self.MenuBG Entity(0.5,225);
		}
		else
		{
			self.MenuBG destroy();
			self.cSystem["BGs"]=shdr;
			self.MenuBG=self createRectangle("CENTER","CENTER",0,0,320,320,self.cSystem["BGc"],3,0,self.cSystem["BGs"]);
			self.MenuBG Entity(0.5,undefined,undefined,0.5);
		}
	}
	else
	{
		if(self.MenuPos=="Right")
		{
			self.MenuSC destroy();
			self.MenuSCC destroy();
			self.cSystem["Scrolls"]=shdr;
			wait .3;
			if(self.SStyle=="DV3")self.Text[self.Local] thread NotHover();
			else self.Text[self.Local] thread AnimSmall();
			self.MenuSC=self createRectangle("CENTER","CENTER",225,-110,320,17,self.cSystem["Scrollc"],4,0,self.cSystem["Scrolls"]);
			self.MenuSCC=self createRectangle("CENTER","CENTER",75,-110,20,20,(255,255,255),6,0,self.ScrollIcon);
			self.MenuSC Entity(0.2,undefined,undefined,0.7);
			self.MenuSCC Entity(0.2,undefined,undefined,0.7);
			self.local=0;
			if(self.SStyle=="DV3")self.Text[self.Local] thread Hover();
			else self.Text[self.Local] thread AnimBig();
		}
		else
		{
			self.MenuSC destroy();
			self.MenuSCC destroy();
			self.cSystem["Scrolls"]=shdr;
			wait .3;
			if(self.SStyle=="DV3")self.Text[self.Local] thread NotHover();
			else self.Text[self.Local] thread AnimSmall();
			self.MenuSC=self createRectangle("CENTER","CENTER",0,-110,320,17,self.cSystem["Scrollc"],4,0,self.cSystem["Scrolls"]);
			self.MenuSCC=self createRectangle("CENTER","CENTER",-147,-110,20,20,(255,255,255),6,0,self.ScrollIcon);
			self.MenuSC Entity(0.2,undefined,undefined,0.7);
			self.MenuSCC Entity(0.2,undefined,undefined,0.7);
			self.local=0;
			if(self.SStyle=="DV3")self.Text[self.Local] thread Hover();
			else self.Text[self.Local] thread AnimBig();
		}
	}
}
CustomCC(clr)
{
	if(self.CBAR=="Background")
	{
		self.cSystem["BGc"]=clr;
		self.MenuBG thread ColorFade(self.MenuBG,clr);
	}
	else if(self.CBAR=="Scroller")
	{
		self.cSystem["Scrollc"]=clr;
		self.MenuSC thread ColorFade(self.MenuSC,clr);
	}
	else if(self.CBAR=="Text")
	{
		self.cSystem["Textc"]=clr;
		self.Instruct.color=clr;
		for(i=0;i < self.Text.size;i++)
		{
			self.Text[i].color=clr;
		}
	}
	else
	{
		self.cSystem["TLTc"]=clr;
		self.MainT.color=clr;
	}
}
ColorFade(Object,color)
{
	self.New =(color);
	Object FadeHoverSelection(.4,self.New);
	wait .4;
}
FadeHoverSelection(time,color)
{
	self FadeOverTime(time);
	self.color=color;
}
Message(msg)
{
	array_thread(get_Players(),iPrintlnBold("^"+randomIntRange(1,7)+""+msg+""));
	wait 4;
}
Req(Thing)
{
	if(self.spaming==0)
	{
		self.spaming=1;
		self iPrintln("Request Sent To Host");
		get_Players()[0] iPrintln(""+self.playername+": Can I Haz ^2"+Thing+"^7?");
		wait 8;
		self.spaming=0;
	}
	else
	{
		self iPrintln("Please Wait To Request... "+get_Players()[0].playername+" No Likey Spam");
	}
}
parents()
{
	self.parent=[];
	self.parent[0]="none";
	self.parent[1]=0;
	self.parent[2]=0;
	self.parent[3]=0;
	self.parent[4]=0;
	self.parent[5]=0;
	self.parent[6]=0;
	self.parent[7]=0;
	self.parent[8]=0;
	self.parent[9]=0;
	self.parent[10]=0;
	self.parent[12]=0;
	self.parent[13]=0;
	self.parent[14]=9;
	self.parent[15]=14;
	self.parent[16]=14;
	self.parent[17]=16;
	self.parent[18]=12;
	self.parent[19]=0;
	self.parent[20]=0;
	self.parent[21]=3;
	self.parent[22]=3;
	self.parent[24]=12;
	self.parent[25]=12;
	self.parent[26]=12;
	self.parent[27]=12;
	self.parent[28]=12;
	self.parent[29]=2;
	self.parent[30]=5;
	self.parent[31]=26;
	self.parent[32]=6;
	self.parent[33]=20;
	self.parent[34]=33;
	self.parent[35]=28;
	self.parent[36]=13;
	self.parent[37]=13;
	self.parent[38]=13;
	self.parent[39]=35;
	self.parent[40]=39;
	self.parent[41]=6;
	self.parent[42]=1;
	self.parent[43]=1;
	self.parent[44]=33;
	self.parent[45]=13;
	self.parent[100]=0;
}
Menu_Control()
{
	self.cSystem["BGc"] =(0,0,0);
	self.cSystem["BGs"]="white";
	self.cSystem["Textc"] =(255,255,255);
	self.cSystem["TLTc"] =(0,1,0);
	self.cSystem["Scrolls"]="white";
	self.cSystem["Scrollc"] =(0,1,0);
	self.cSystem["Titlec"] =(255,255,255);
	self.local=0;
	self.ScrollShad=-1;
	self.SStyle="DV3";
	self.ScrollIcon="ui_host";
	self.Movement=false;
	self.MenuPos="Right";
	self thread parents();
	self thread WelcomeText();
	self thread CreateMenu();
	wait 0.001;
	self endon("death");
	self endon("disconnect");
	for(;;)
	{
		if(self.MenuIn==false)
		{
			if(self adsButtonPressed()&& self useButtonPressed()&& self.MenuLocked==false)
			{
				if(level.Forge==true)self thread OpenMenu(0,"Forge Menu");
				else self thread OpenMenu(0,"Discarded v3");
				self playLocalSound("zmb_lid_open");
				wait 1;
			}
		}
		else
		{
			if(self.Menu==33 && self fragButtonPressed())
			{
				if(self.Local==5)
				{
					if(self.CHOP=="Reg")self.CHOP="Walk";
					else self.CHOP="Reg";
					self thread Instant(33);
				}
				else if(self.Local==6)
				{
					if(self.AC=="Reg")self.AC="Walk";
					else self.AC="Reg";
					self thread Instant(33);
				}
				else if(self.Local==7)
				{
					if(self.REAP=="Reg")self.REAP="Walk";
					else self.REAP="Reg";
					self thread Instant(33);
				}
				wait .4;
			}
			if(self useButtonPressed())
			{
				self PlayLocalSound("zmb_cha_ching");
				self.Text[self.Local] thread GotSelected();
				self thread [[self.Function[self.Menu][self.local]]](self.Input[self.Menu][self.local],self.Inputx[self.Menu][self.local]);
				wait .4;
			}
			if(self adsButtonPressed()|| self attackButtonPressed())
			{
				self.Old=self.local;
				self PlayLocalSound("zmb_perks_packa_ticktock");
				self.local += self attackButtonPressed();
				self.local -= self adsButtonPressed();
				if(self.local > self.MenuNames[self.Menu].size-1)self.local=0;
				if(self.local < 0)self.local=self.MenuNames[self.Menu].size-1;
				self.MenuSC Entity(0.2,undefined,self.Text[self.local].y);
				self.MenuSCC Entity(0.2,undefined,self.MenuSC.y);
				if(self.SStyle=="DV3")
				{
					self.Text[self.Old] thread NotHover();
					self.Text[self.Local] thread Hover();
				}
				else
				{
					self.Text[self.Old] thread AnimSmall();
					self.Text[self.Local] thread AnimBig();
				}
				wait .2;
			}
			if(self meleebuttonpressed()&& self.CanClose==true)
			{
				if(self.Menu>=1)self newMenu(self.parent[self.Menu]);
				else self thread CloseMenu();
				wait .3;
			}
		}
		wait 0.01;
	}
}
OpenMenu(Num,Name)
{
	if(self.Movement==false)
	{
		self setClientDvar("cg_drawCrosshair",0);
		self setClientDvar("r_blur",2);
		self freezeControls(true);
	}
	else
	{
		self freezeControls(false);
	}
	if(self.MenuPos=="Right")
	{
		self.MenuBG=self createRectangle("CENTER","CENTER",550,0,320,320,self.cSystem["BGc"],3,0.5,self.cSystem["BGs"]);
		self.MenuSC=self createRectangle("CENTER","CENTER",225,-110,320,17,self.cSystem["Scrollc"],4,0,self.cSystem["Scrolls"]);
		self.MenuSCC=self createRectangle("CENTER","CENTER",75,-110,20,20,(255,255,255),6,0,self.ScrollIcon);
		self.MainT=self createText("default",1.8,"CENTER","TOP",215,59,6,0,Name,self.cSystem["TLTc"]);
		self.Linet=self createRectangle("CENTER","CENTER",550,-130,320,2,(255,255,255),5,0.7,"white");
		self.Linet Entity(0.5,225);
		self.MenuBG Entity(0.5,225);
		self.AmOpen=true;
		self.local=0;
		wait 0.5;
		self playLocalSound("zmb_lid_open");
		self.MenuClosed=false;
		self.MainT Entity(0.2,undefined,undefined,0.9);
		self.MenuSC Entity(0.2,undefined,undefined,0.7);
		self.MenuSCC Entity(0.2,undefined,undefined,0.7);
	}
	else
	{
		self.MenuBG=self createRectangle("CENTER","CENTER",0,0,320,320,self.cSystem["BGc"],3,0,self.cSystem["BGs"]);
		self.MenuSC=self createRectangle("CENTER","CENTER",0,-110,320,17,self.cSystem["Scrollc"],4,0,self.cSystem["Scrolls"]);
		self.MenuSCC=self createRectangle("CENTER","CENTER",-147,-110,20,20,(255,255,255),6,0,self.ScrollIcon);
		self.MainT=self createText("default",1.8,"CENTER","CENTER",0,-144,6,0,Name,self.cSystem["TLTc"]);
		self.Linet=self createRectangle("CENTER","CENTER",0,-127,320,2,(255,255,255),5,0,"white");
		self.Linet Entity(0.5,undefined,undefined,0.7);
		self.MenuBG Entity(0.5,undefined,undefined,0.5);
		self.AmOpen=true;
		self.local=0;
		wait 0.5;
		self playLocalSound("zmb_lid_open");
		self.MenuClosed=false;
		self.MainT Entity(0.2,undefined,undefined,0.9);
		self.MenuSC Entity(0.2,undefined,undefined,0.7);
		self.MenuSCC Entity(0.2,undefined,undefined,0.7);
	}
	self thread BuildText(Num);
	wait 0.2;
	self.MenuIn=true;
	wait 0.2;
	self.CanClose=true;
	wait 0.1;
}
PlayerPres(pres)
{
	Me=self.playername;
	//get_players()[self.PS] thread maps\_challenges_coop::statSet("plevel",pres);
	//get_players()[self.PS] thread confirm_rank(65);
	//get_players()[self.PS] iPrintln("Your Prestige Has Been Set To "+pres+" By: "+Me+"");
	self iPrintln(""+get_players()[self.PS].playername+"'s Prestige Set To: ^2"+pres+"");
	self iPrintlnBold("^2Not In This Version!");
}
toggle_god()
{
	if(self.godmode==false)
	{
		self EnableHealthShield(true);
		self EnableInvulnerability();
		self.godmode=true;
		self iPrintln("God Mode ^2[ON]");
	}
	else
	{
		self EnableHealthShield(false);
		self DisableInvulnerability();
		self.godmode=false;
		self iPrintln("God Mode ^1[OFF]");
	}
}
noClip()
{
	self endon("death");
	self endon("disconnect");
	if(!isDefined(self.noClip))self.noClip=false;
	self iPrintln("Press [{+melee}] To Move");
	self iPrintln("Press [{+frag}] To Exit Noclip");
	if(!self.noClip)
	{
		self EnableHealthShield(true);
		self EnableInvulnerability();
		self freezeControls(false);
		self.noClip=true;
		clip=spawn("script_origin",self.origin);
		clip enableLinkTo();
		self playerLinkTo(clip);
		self iPrintln("Noclip ^2[ON]");
		wait 0.001;
		for(;;)
		{
			vec=anglesToForward(self getPlayerAngles());
			end =(vec[0]*25,vec[1]*25,vec[2]*25);
			if(self meleeButtonPressed())clip.origin=clip.origin+end;
			if(self fragButtonPressed())break;
			wait .05;
		}
		wait 0.001;
		self.noClip=undefined;
		self enableWeapons();
		self enableOffHandWeapons();
		self unlink();
		clip delete();
		self iPrintln("Noclip ^1[OFF]");
	}
}
Moveyy()
{
	if(self.Movement==false)
	{
		self setClientDvar("cg_drawCrosshair",1);
		self setClientDvar("r_blur",0);
		self freezeControls(false);
		self iPrintln("Move In Menu ^2[ON]");
		self.Movement=true;
	}
	else
	{
		self setClientDvar("cg_drawCrosshair",0);
		self setClientDvar("r_blur",2);
		self freezeControls(true);
		self iPrintln("Move In Menu ^1[OFF]");
		self.Movement=false;
	}
}
toggle_third()
{
	if(self.third==false)
	{
		self setClientDvar("cg_thirdPerson","1");
		self.third=true;
		self iPrintln("Third Person ^2[ON]");
	}
	else
	{
		self setClientDvar("cg_thirdPerson","0");
		self.third=false;
		self iPrintln("Third Person ^1[OFF]");
	}
}
FPUM()
{
	if(self.forge==false)
	{
		self thread toggle_forge();
		self.forge=true;
		self iPrintln("Forge Pickup ^2[ON]");
		self iPrintln("Press [{+speed_throw}] To Pickup/Release Objects");
	}
	else
	{
		self notify("forgeOff");
		self.forge=false;
		self iPrintln("Forge Pickup ^1[OFF]");
	}
}
toggle_forge()
{
	self endon("death");
	self endon("forgeOff");
	for(;;)
	{
		wait 0.01;
		Trace=bullettrace(self gettagorigin("j_head"),self gettagorigin("j_head")+anglestoforward(self getplayerangles())*1000000,true,self);
		while(self adsbuttonpressed())
		{
			while(self adsbuttonpressed())
			{
				Trace["entity"] freezeControls(true);
				Trace["entity"] ForceTeleport(self GetTagOrigin("j_head")+ AnglesToForward(self GetPlayerAngles())* 200);
				Trace["entity"] SetOrigin(self GetTagOrigin("j_head")+ AnglesToForward(self GetPlayerAngles())* 200);
				Trace["entity"].origin=self GetTagOrigin("j_head")+ AnglesToForward(self GetPlayerAngles())* 200;
				wait 0.005;
			}
			Trace["entity"] freezeControls(false);
			break;
		}
	}
	wait 0.005;
}
unlimAmmo()
{
	if(!isDefined(self.unlimAmmo))
	{
		self.unlimAmmo=true;
		if(self.RollTheDice==true)
		{
		}
		else
		{
			self iPrintln("Unlimited Ammo ^2[ON]");
		}
		while(isDefined(self.unlimAmmo))
		{
			self setWeaponAmmoStock(self getCurrentWeapon(),1000);
			self setWeaponAmmoClip(self getCurrentWeapon(),1000);
			self GiveMaxAmmo("m2_flamethrower_zombie");
			wait .05;
		}
	}
	else
	{
		self.unlimAmmo=undefined;
		if(self.RollTheDice==true)
		{
		}
		else
		{
			self iPrintln("Unlimited Ammo ^1[OFF]");
		}
	}
}
upside()
{
	self setPlayerAngles(self.angles+(0,0,180));
}
rightside()
{
	self setPlayerAngles(self.angles+(0,0,90));
}
leftside()
{
	self setPlayerAngles(self.angles+(0,0,270));
}
normalside()
{
	self setPlayerAngles(self.angles+(0,0,0));
}
invis()
{
	if(self.Invisibility==false)
	{
		self hide();
		self iPrintln("You are ^2Invisible");
		self.Invisibility=true;
	}
	else
	{
		self show();
		self iPrintln("You are ^1Visible");
		self.Invisibility=false;
	}
}


PerkDecide(perk)
{
	if(GetMap()== "NZP")
	{
		self iPrintln("^2Perk Set");
		self setPerk(perk);
	}
	else
	{
		self thread giveMenuPerk(perk);
	}
}
giveMenuPerk(perk)
{
	self endon("disconnect");
	self endon("death");
	if (self hasPerk(perk))
	{
		self playLocalSound("zmb_perks_pap_deny");
		self iprintln("^1You already own this perk!");
		return;
	}
	if (IsDefined(self.is_drinking) && self.is_drinking) return;
	self.is_drinking = true;
	p = [];
	if (perk == "specialty_fastreload") p = strTok("mx_speed_sting specialty_fastreload_zombies zombie_perk_bottle_sleight", " ");
	else if (perk == "specialty_armorvest") p = strTok("mx_jugger_sting specialty_juggernaut_zombies zombie_perk_bottle_jugg", " ");
	else if (perk == "specialty_quickrevive") p = strTok("mx_revive_sting specialty_quickrevive_zombies zombie_perk_bottle_revive", " ");
	else if (perk == "specialty_rof") p = strTok("mx_doubletap_sting specialty_doubletap_zombies zombie_perk_bottle_doubletap", " ");
	else if (perk == "specialty_longsprint") p = strTok("mx_staminup_sting specialty_staminup_zombies zombie_perk_bottle_staminup", " ");
	else if (perk == "specialty_deadshot") p = strTok("mx_deadshot_sting specialty_deadshot_zombies zombie_perk_bottle_deadshot", " ");
	else if (perk == "specialty_flakjacket") p = strTok("mx_phd_sting specialty_phd_zombies zombie_perk_bottle_phd", " ");
	else p = strTok("zmb_cha_ching specialty_fastreload_zombies zombie_perk_bottle_sleight", " ");
	if (!IsDefined(self.perk_hud))
	{
		self.perk_hud = [];
	}
	playSoundAtPosition("evt_bottle_dispense", self.origin);
	if (IsDefined(p[0]))
	{
		self playLocalSound(p[0]);
	}
	self setPerk(perk);
	self thread menuPerk_think(perk);
	self.perk_hud[perk] = self createRectangle("BOTTOMLEFT", "BOTTOMLEFT", (self.perk_hud.size * 30), -70, 24, 24, (1, 1, 1), 0, 0, p[1]);
	self disableOffhandWeapons();
	self disableWeaponCycling();
	self allowLean(false);
	self allowAds(false);
	self allowSprint(false);
	self allowProne(false);
	self allowMelee(false);
	curWeap = self getCurrentWeapon();
	if (IsDefined(p[2]) && self.sessionstate != "spectator")
	{
		self giveWeapon(p[2]);
		self switchToWeapon(p[2]);
	}
	self waittill_any("fake_death", "death", "player_downed", "weapon_change_complete");
	if (IsDefined(p[2]) && self.sessionstate != "spectator")
	{
		self takeWeapon(p[2]);
	}
	if (IsDefined(curWeap) && curWeap != "none")
	{
		self switchToWeapon(curWeap);
	}
	self enableOffhandWeapons();
	self enableWeaponCycling();
	self allowLean(true);
	self allowAds(true);
	self allowSprint(true);
	self allowProne(true);
	self allowMelee(true);
	self setBlur(4, 0.1);
	wait 0.1;
	self setBlur(0, 0.1);
	if (perk == "specialty_armorvest")
	{
		if (IsDefined(level.zombie_vars) && IsDefined(level.zombie_vars["zombie_perk_juggernaut_health"]))
		{
			self.maxhealth = level.zombie_vars["zombie_perk_juggernaut_health"];
		}
		else
		{
			self.maxhealth = 160;
		}
		self.health = self.maxhealth;
	}
	if (IsDefined(self.perk_hud[perk]))
	{
		self.perk_hud[perk].alpha = 1;
	}
	wait 0.4;
	self.is_drinking = undefined;
	self notify("perk_drank");
	self.perk_hud[perk] destroy();
}


menuPerk_think(perk)
{
    self endon("disconnect");
    
    self waittill_any("fake_death", "death", "player_downed");
    
    self unsetPerk(perk);
    self.maxhealth = 100;
    
    if (IsDefined(self.perk_hud) && IsDefined(self.perk_hud[perk]))
    {
        self.perk_hud[perk] destroy();
        self.perk_hud[perk] = undefined;
    }
}

DoScore(plus)
{
	player=get_Players();
	k=self.PS;
	if(self.Myself==true)
	{
		self.score_total=self.score_total + plus;
		self.score=self.score + plus;
		self iPrintln("Score Set To ^2"+self.score+"");
	}
	else
	{
		player[k].score_total=player[k].score_total + plus;
		player[k].score=player[k].score + plus;
		self iPrintln(""+player[k].playername+"'s Score Set To ^2"+player[k].score+"");
	}
}
Score(per)
{
	if(per=="Self")
	{
		self.Myself=true;
		self.parent[23]=1;
	}
	else
	{
		self.Myself=false;
		self.parent[23]=16;
	}
	self thread NewMenu(23);
}
ResetScore()
{
	player=get_Players();
	k=self.PS;
	if(self.Myself==true)
	{
		self iPrintln("Score Has Been ^1Reset");
		self.score=500;
	}
	else
	{
		self iPrintln(""+player[k].playername+"'s Score Has Been ^1Reset");
		player[k].score=500;
	}
}
DoKam()
{
	self endon("disconnect");
	self endon("death");
	self iPrintln("Kamikaze Bomber ^2Inbound");
	kam=spawn("script_model",self.origin+(24000,15000,25000));
	kam setModel("defaultvehicle");
	Angles=vectorToAngles(self.origin -(self.origin+(8000,5000,10000)));
	kam.angles=Angles;
	wait(0.15);
	self thread KillEnt(kam,4);
	wait(0.15);
	kam moveto(self.origin,3.5);
	wait 3.6;
	playfx(loadfx("explosions/fx_default_explosion"),kam.origin);
	playfx(loadfx("explosions/fx_default_explosion"),kam.origin+(0,20,50));
	wait 0.1;
	playfx(loadfx("explosions/fx_default_explosion"),kam.origin);
	self playSound("wpn_grenade_explode");
	Earthquake(0.4,4,Kam.origin,800);
	RadiusDamage(Kam.origin,1000,800,1,self);
}
KillEnt(ent,time)
{
	wait time;
	ent delete();
}
/*
clone()
{
	model=spawn("script_model",self.origin);
	model setModel(self.ModelClone);
	if(self.ModelClone==self.backUp["body"])
	{
		if(isDefined(self.backUp["head"]))
		{
			self.headModel=self.backUp["head"];
			model attach(self.headModel,"",true);
		}
		if(isDefined(self.backUp["hat"]))
		{
			self.hatModel=self.backUp["hat"];
			model attach(self.hatModel);
		}
		if(isDefined(self.backUp["gear"]))
		{
			self.gearModel=self.backUp["gear"];
			model attach(self.gearModel);
		}
	}
	self iPrintln("Clone ^2Spawned");
}
*/
clone(model)
{
	if(!isDefined(self) || !isAlive(self)) return;
	if(isDefined(self.zombclone)) self.zombclone delete();
	clone = self ClonePlayer(1);
	if(!isDefined(clone)) return;
	if(model >= 2) clone startragdoll();
	if(model >= 3) clone launchragdoll((randomintrange(-80, 80), randomintrange(-80, 80), randomintrange(20, 40)));
	self.zombclone = clone;
}

IceSkater()
{
	self endon("death");
	skater=spawn("script_model",self.origin);
	skater setmodel("defaultactor");
	self iPrintln("Iceskater ^2Spawned");
	while(1)
	{
		skater rotateyaw(9000,9);
		skater MoveY(-180,1);
		wait 1;
		skater MoveY(180,1);
		wait 1;
		skater MoveX(-180,1);
		wait 1;
		skater MoveX(180,1);
		wait 1;
		Skater MoveZ(90,.5);
		wait.5;
		skater MoveZ(-90,.5);
		wait.5;
		skater MoveY(180,1);
		wait 1;
		skater MoveY(-180,1);
		wait 1;
		skater MoveX(180,1);
		wait 1;
		skater MoveX(-180,1);
		wait 1;
	}
}
RGBslider(name)
{
	self.menuLocked=true;
	self thread CloseMenu();
	wait 0.3;
	self freezeControls(true);
	self setClientDvar("cg_drawCrosshair","0");
	DvarChange=self createfontstring("default",1.8,self);
	DvarChange setpoint("CENTER","CENTER",0,-88);
	DvarChange settext("Editing: ",name);
	DvarValue=self createfontstring("default",1.7,self);
	DvarValue setpoint("CENTER","CENTER",0,70);
	self.black=self createRectangle("CENTER","CENTER",0,0,2000,2000,(0,0,0),-9999,0.7,"white");
	self.DvarBG=self createRectangle("CENTER","CENTER",0,-58,200,30,(0,0,0),2,1,"white");
	self.redslider=self createRectangle("CENTER","CENTER",0,-30,278,18,(255,255,255),3,1,"ui_slider2");
	self.greenslider=self createRectangle("CENTER","CENTER",0,0,278,18,(255,255,255),3,0.4,"ui_slider2");
	self.blueslider=self createRectangle("CENTER","CENTER",0,30,278,18,(255,255,255),3,0.4,"ui_slider2");
	color="Red";
	bar=[];
	bar["Red"]=self createRectangle("CENTER","CENTER",-128,-30,14,26,(0,1,0),4,1,"ui_sliderbutt_1");
	bar["Green"]=self createRectangle("CENTER","CENTER",-128,0,14,26,(0,1,0),4,0.4,"ui_sliderbutt_1");
	bar["Blue"]=self createRectangle("CENTER","CENTER",-128,30,14,26,(0,1,0),4,0.4,"ui_sliderbutt_1");
	value=[];
	value["Red"]=0;
	value["Green"]=0;
	value["Blue"]=0;
	Max=1;
	Increment=0.02;
	Min=0;
	DvarValue settext(""+color+" Value: "+value[color]+"");
	wait 0.3;
	self endon("DvarEdit_Over");
	for(;;)
	{
		wait 0.001;
		DvarValue settext(""+color+" Value: "+value[color]+"");
		self.DvarBG.color =(value["Red"],value["Green"],value["Blue"]);
		if(self MeleeButtonPressed())
		{
			self.DvarBG Destroy();
			self.black Destroy();
			self.redslider Destroy();
			self.greenslider Destroy();
			self.blueslider Destroy();
			bar["Red"] destroy();
			bar["Green"] destroy();
			bar["Blue"] destroy();
			DvarChange Destroy();
			DvarValue Destroy();
			self.menuLocked=false;
			self freezeControls(false);
			self setClientDvar("cg_drawCrosshair",1);
			self thread OpenMenu(6,"Fun Menu");
			;
			self notify("DvarEdit_Over");
			wait 0.1;
		}
		else if(self fragButtonPressed())
		{
			if(color=="Red")
			{
				color="Green";
				bar["Red"].alpha=0.4;
				self.redslider.alpha=0.4;
				bar[color].alpha=1;
				self.greenslider.alpha=1;
			}
			else if(color=="Green")
			{
				color="Blue";
				bar["Green"].alpha=0.4;
				self.greenslider.alpha=0.4;
				bar[color].alpha=1;
				self.blueslider.alpha=1;
			}
			else if(color=="Blue")
			{
				color="Red";
				bar["Blue"].alpha=0.4;
				self.blueslider.alpha=0.4;
				bar[color].alpha=1;
				self.redslider.alpha=1;
			}
			DvarValue settext(""+color+" Value: "+value[color]+"");
			wait 0.3;
		}
		else if(self AdsButtonPressed()&& value[color]==Min)
		{
			wait 0.001;
			bar[color].x=bar[color].x + 255;
			value[color]=Max;
		}
		else if(self AttackButtonPressed()&& value[color]==Max)
		{
			wait 0.001;
			bar[color].x=bar[color].x - 255;
			value[color]=Min;
		}
		else if(self AttackButtonPressed()&& value[color] < Max)
		{
			wait 0.001;
			bar[color].x=bar[color].x + 5.1;
			value[color]=value[color] + increment;
		}
		else if(self AdsButtonPressed()&& value[color] > Min)
		{
			wait 0.001;
			bar[color].x=bar[color].x - 5.1;
			value[color]=value[color] - increment;
		}
		else if(self UseButtonPressed())
		{
			wait 0.0001;
			if(name=="Fog")
			{
				self notify("disco_done");
				self SetExpFog(256,512,value["Red"],value["Green"],value["Blue"],0);
				self setVolFog(165,835,200,75,value["Red"],value["Green"],value["Blue"],1);
			}
			else
			{
				self notify("stop_sun");
				self setClientDvars("r_lightTweakSunLight","1.7","r_lightTweakSunColor",""+value["Red"]+" "+value["Green"]+" "+value["Blue"]+" 0");
			}
			self setClientDvar("cg_drawCrosshair",1);
			self thread OpenMenu(41,"Edit Fog/Sun");
			self.DvarBG Destroy();
			self.black Destroy();
			self.redslider Destroy();
			self.greenslider Destroy();
			self.blueslider Destroy();
			bar["Red"] destroy();
			bar["Green"] destroy();
			bar["Blue"] destroy();
			DvarChange Destroy();
			DvarValue Destroy();
			self freezeControls(false);
			self notify("DvarEdit_Over");
			wait 0.1;
			self.MenuLocked=false;
		}
	}
}
EggSong(player) // Made By killhitman40
{
	if( !isDefined(self.easterEggDR) ) self.easterEggDR = false;
	if( self.easterEggDR ) return;
	self.easterEggDR = true;
	map = level.script;
	song_wait = 0;
	if( IsSubStr(map, "zombie_pentagon") || IsSubStr(map, "pentagon") )
	{
		self playsound( "evt_doa_unlock" );
	}
	level.music_override = true;
	level thread maps\_zombiemode_audio::change_zombie_music( "egg" );
	wait(4);
	if( IsDefined(player) && !IsSubStr(map, "asylum") && !IsSubStr(map, "prototype") )
	{
		player maps\_zombiemode_audio::create_and_play_dialog( "eggs", "music_activate" );
	}
	if ( IsSubStr(map, "factory") ) song_wait = 236;
	else if ( IsSubStr(map, "sumpf") ) song_wait = 236;
	else if ( IsSubStr(map, "asylum") ) song_wait = 245;
	else if ( IsSubStr(map, "prototype") ) song_wait = 223;
	else if ( IsSubStr(map, "theater") ) song_wait = 236;
	else if ( IsSubStr(map, "zombie_pentagon") || IsSubStr(map, "pentagon") ) song_wait = 265;
	else if ( IsSubStr(map, "cosmodrome") ) song_wait = 367;
	else if ( IsSubStr(map, "coast") ) song_wait = 420;
	else if ( IsSubStr(map, "temple") ) song_wait = 360;
	else if ( IsSubStr(map, "moon") ) song_wait = 199;
	wait( song_wait );
	level.music_override = false;
	self.easterEggDR = false;
	if( !isDefined(level.monkey_intermission) ) level.monkey_intermission = false;
	if( level.monkey_intermission == false && level.music_round_override == false )
	{
		level thread maps\_zombiemode_audio::change_zombie_music( "wave_loop" );
	}
}

/*
zombiepower()
{
	if(level.script=="zombie_cod5_factory")
	{
		target="use_power_switch";
	}
	else
	{
		target="use_master_switch";
	}
	trigger=GetEnt(target,"targetname");
	if(!IsDefined(trigger))
	{
		return;
	}
	trigger notify("trigger",self);
}
*/

zombiepower() // Made By killhitman40 
{
    if(GetDvar("mapname") == "zombie_temple")
	{
		flag_set("left_switch_done");
		flag_set("right_switch_done");
		flag_set("power_on");
		level thread maps\zombie_temple_power::water_start("left_switch_done", 48, 25, false, "evt_waterwheel02");
		level thread maps\zombie_temple_power::water_start("right_switch_done", 49, 26, true, "evt_waterwheel01");
		return;
	}
    power_active = array("use_elec_switch", "use_master_switch", "use_power_switch", "elec_switch", "elec_switch_left", "elec_switch_right");
	for(i = 0;i < power_active.size;i++)
	{
		Power = power_active[i];
		elec = getEnt(Power, "targetname");
		if(isDefined(elec))
		{
			elec notify("trigger", self);
		}
	}
}
RainbowScore()
{
	self SetClientDvar("cg_scoresColor_Zombie","0 0 0 1");
	self.RGB=[];
	for(;;)
	{
		for(i=0;i<4;i++)self.RGB[i]=RandomFloat(1);
		self SetClientDvar("Cg_ScoresColor_Gamertag_0","" + self.RGB[0] + " " + self.RGB[1] + " " + self.RGB[2] + " " + self.RGB[3] + "");
		self SetClientDvar("Cg_ScoresColor_Gamertag_1","" + self.RGB[0] + " " + self.RGB[1] + " " + self.RGB[2] + " " + self.RGB[3] + "");
		self SetClientDvar("Cg_ScoresColor_Gamertag_2","" + self.RGB[0] + " " + self.RGB[1] + " " + self.RGB[2] + " " + self.RGB[3] + "");
		self SetClientDvar("Cg_ScoresColor_Gamertag_3","" + self.RGB[0] + " " + self.RGB[1] + " " + self.RGB[2] + " " + self.RGB[3] + "");
		wait .1;
	}
}
DoTehGuns()
{
	if(IsSubStr(level.script,"zombie_cod5_factory"))
	{
		self giveWeapon("zombie_knuckle_crack");
		self switchToWeapon("zombie_knuckle_crack");
		wait 3;
		self takeWeapon("zombie_knuckle_crack");
		wait.1;
		self giveWeapon("ray_gun_upgraded");
		self giveWeapon("tesla_gun_upgraded");
		self giveWeapon("zombie_melee");
		self giveWeapon("defaultweapon");
		self giveWeapon("zombie_cymbal_monkey");
		self switchToWeapon("tesla_gun_upgraded");
	}
	if(IsSubStr(level.script,"nazi_zombie_asylum")|| IsSubStr(level.script,"nazi_zombie_prototype"))
	{
		self giveWeapon("ray_gun");
		self giveWeapon("zombie_melee");
		self giveWeapon("defaultweapon");
		self switchToWeapon("ray_gun");
	}
	if(IsSubStr(level.script,"nazi_zombie_sumpf"))
	{
		self giveWeapon("tesla_gun");
		self giveWeapon("ray_gun");
		self giveWeapon("zombie_melee");
		self giveWeapon("defaultweapon");
		self switchToWeapon("ray_gun");
	}
}
doMenu(Stat)
{
	array_thread(get_Players(),::doModz,Stat);
	self thread EggSong();
	self thread zombiepower();
	self thread openAllDoor();
	self thread spawnFxkm();
	level.gametype=1;
	wait 0.01;
	self thread linkTeles();
}
doModz(Perm)
{
	self thread IntroText(self,"^2Gametype^7: Mod Menu Lobby","Your Host Today Is "+get_Players()[0].playername+"",(255,255,255));
	PlayFx(level._effect["rise_burst_water"],self.origin);
	PlayFx(level._effect["rise_billow_water"],self.origin);
	PlayFx(loadFx("explosions/mortarExp_water"),self.origin);
	self PlaySound("laugh_child");
	self thread RainbowScore();
	self thread DoTehGuns();
	self setClientDvars("g_gravity","150","jump_height","999","player_sustainAmmo","1","developeruser","1","r_specularMap","2","player_sprintUnlimited",1,"bg_fallDamageMinHeight",999,"bg_fallDamageMaxHeight",1000);
	self EnableHealthShield(true);
	self EnableInvulnerability();
	self.godmode=true;
	self setClientDvar("g_speed","320");
	self setClientDvar("motd","^2Thanks For Playing Discarded v3 Hosted By: "+get_Players()[0].playername+",Subscribe To Youtube.com/Homiethefluff!");
	self setClientDvar("clanName","MM<3");
	self SetClientDvar("player_meleeRange","1000");
	self setClientDvar("lowAmmoWarningColor2","1 0 0 1");
	self setClientDvar("lowAmmoWarningNoAmmoColor1","0 0 1 1");
	self setClientDvar("lowAmmoWarningNoAmmoColor2","1 0 0 1");
	self setClientDvar("ui_playerPartyColor","0 1 0 1");
	self setClientDvar("lobby_searchingPartyColor","0 1 0 1");
	self setClientDvar("UpdateGamerProfile","1");
	if(self.Permlevel=="Host"||self.Permlevel=="Dev")
	{
		self thread CloseMenu();
	}
	else
	{
		self.PermLevel=Perm;
		if(Perm=="Unverified")self.PermLevel=Perm;
		else if(Perm=="Verified")self thread Verify();
		else if(Perm=="VIP")self thread VIP();
		else if(Perm=="Cohost")self thread Cohost();
		else if(Perm=="Admin")self thread Admin();
		if(self.HasMenu==false)
		{
			self thread Menu_Control();
			self.HasMenu=true;
		}
	}
}
Kick()
{
	nigger=self.Playername;
	if(self==get_Players()[self.PS])
	{
		self iPrintln("Lol,Why would you kick yourself? :P");
	}
	else if(get_Players()[self.PS]==get_Players()[0]||get_Players()[self.PS].permlevel=="Dev")
	{
		if(get_Players()[self.PS].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		self iPrintln("Cannot Kick The "+P+"");
		get_Players()[self.PS] iPrintln("^2"+nigger+" ^7Tried To Kick You");
	}
	else
	{
		Ban(self get_Players()[Int(self.PS)] GetEntityNumber());
		self thread CreateMenu();
		wait .1;
		self thread NewMenu(9);
	}
}
KickS()
{
	nigger=self.Playername;
	if(self==get_Players()[self.PS])
	{
		self iPrintln("Lol,Why would you kick yourself? :P");
	}
	else if(self.PS==0||get_Players()[self.PS].permlevel=="Dev")
	{
		if(get_Players()[self.PS].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		self iPrintln("Cannot Kick The "+P+"");
		get_Players()[self.PS] iPrintln("^2"+nigger+" ^7Tried To Kick You To Singleplayer");
	}
	else
	{
		player=get_Players();
		get_players()[self.PS] setClientDvar("activeAction","startSingleplayer");
		self iPrintln("Must Restart Level To Kick "+player[self.PS].playername+" To Singleplayer");
	}
}
KickM()
{
	nigger=self.Playername;
	if(self==get_Players()[self.PS])
	{
		self iPrintln("Lol,Why would you kick yourself? :P");
	}
	else if(self.PS==0||get_Players()[self.PS].permlevel=="Dev")
	{
		if(get_Players()[self.PS].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		self iPrintln("Cannot Kick The "+P+"");
		get_Players()[self.PS] iPrintln("^2"+nigger+" ^7Tried To Kick You To Multiplayer");
	}
	else
	{
		player=get_Players();
		player[self.PS] setClientDvar("activeAction","startMultiplayer");
		self iPrintln("Must Restart Level To Kick "+player[self.PS].playername+" To Multiplayer");
	}
}
KickD()
{
	nigger=self.Playername;
	if(self==get_Players()[self.PS])
	{
		self iPrintln("Lol,Why would you kick yourself? :P");
	}
	else if(self.PS==0||get_Players()[self.PS].permlevel=="Dev")
	{
		if(get_Players()[self.PS].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		self iPrintln("Cannot Kick The "+P+"");
		get_Players()[self.PS] iPrintln("^2"+nigger+" ^7Tried To Kick You To The XMB");
	}
	else
	{
		player=get_Players();
		player[self.PS] setClientDvar("activeAction","quit");
		self iPrintln("Must Restart Level To Kick "+player[self.PS].playername+" To Dashboard/XMB");
	}
}
derank()
{
	k=self.PS;
	players=get_players();
	nigger=self.Playername;
	if(self==players[k])
	{
		self iPrintln("You Deranked Yourself");
		//self maps\_challenges_coop::statSet("rank",1);
		//self maps\_challenges_coop::statSet("plevel",0);
		//self maps\_challenges_coop::statSet("rankxp",-2147483647);
		//self maps\_challenges_coop::incRankXP(-2147483647);
	}
	else if(players[k]==players[0]||players[k].permlevel=="Dev")
	{
		if(players[k].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		self iPrintln("Cannot Derank The "+P+"");
		players[k] iPrintln("^2"+nigger+" ^7Tried To Derank You");
	}
	else
	{
		//players[k] maps\_challenges_coop::statSet("rank",1);
		//players[k] maps\_challenges_coop::statSet("plevel",0);
		//players[k] maps\_challenges_coop::statSet("rankxp",-2147483647);
		//players[k] maps\_challenges_coop::incRankXP(-2147483647);
		self iPrintln("^2"+players[k].playername+" ^7Has Been ^1Deranked");
	}
}
InfectBad()
{
	k=self.PS;
	players=get_players();
	if(players[k]==self)
	{
		self iPrintln("Lol,Why Would You Give Yourself Bad Dvars?");
	}
	else if(players[k].permlevel=="Host"||players[k].permlevel=="Dev")
	{
		if(players[k].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		self iPrintln("Cannot Infect The "+P+" With Bad Dvars");
		players[k] iPrintln("^2"+self.playername+" ^7Tried To Infect You With Bad Dvars");
	}
	else
	{
		players[k] thread BadDvars();
		self iPrintln("Infected ^2"+players[k].playername+" With ^1Bad Dvars");
	}
}
BadDvars()
{
	self setClientDvar("motd","^2YOU'RE A FAG,YOU'RE A FAG,YOU'RE A FAG,YOU'RE A FAG,YOU'RE A FAG,YOU'RE A FAG,YOU'RE A FAG,YOU'RE A FAG,YOU'RE A FAG,YOU'RE A FAG");
	self setclientDvar("maxVoicePacketsPerSec","3");
	self setClientDvar("MakeMeHost","0");
	self setclientDvar("r_filmUseTweaks","1");
	self setclientDvar("r_filmTweakEnable","1");
	self setclientDvar("developer_script","1");
	self setclientDvar("developer","1");
	self setclientDvar("scr_player_maxhealth","30");
	self setClientDvar("party_connectToOthers","1");
	self setClientDvar("party_hostmigration","1");
	self setClientDvar("party_iamhost","0");
	self setClientDvar("party_host","0");
	self setclientDvar("bg_aimSpreadMoveSpeedThreshold","999");
	self setclientDvar("bg_shock_volume_announcer","25.5");
	self setclientDvar("bg_shock_volume_voice","25.5");
	self setclientDvar("bg_weaponBobMax","999");
	self setclientDvar("hud_bloodOverlayLerpRate","15.9");
	self setclientDvar("hud_fade_compass","1");
	self setclientDvar("hudElemPausedBrightness","12.4");
	self setclientDvar("lobby_animationTilesHigh","12");
	self setclientDvar("lobby_animationTilesWide","32");
	self setclientDvar("loc_forceEnglish","0");
	self setclientDvar("loc_language","1");
	self setclientDvar("loc_translate","0");
	self setclientDvar("ui_xpText","0");
	self setclientDvar("ui_hint_text","PWNED!!");
	self setClientDvar("ui_mapname","YOU'RE GAY");
	self setclientDvar("compassSize","25");
	self setclientDvar("compassRotation","0");
	self setclientDvar("cg_gun_x","2");
	self setclientDvar("cg_gun_y","-2");
	self setclientDvar("cg_gun_z","3");
	self setclientDvar("cg_drawpaused","0");
	self setclientDvar("cg_weaponCycleDelay","4");
	self setclientDvar("cg_hudGrenadePointerWidth","999");
	self setclientDvar("cg_hudVotePosition","5 175");
	self setclientDvar("cg_drawFPS","1");
	self setclientDvar("cg_drawFPSLabels","1");
	self setclientDvar("cg_fov","130");
	self setclientDvar("cg_youInKillCamSize","9999");
	self setclientDvar("cl_wadefps","1");
	self setclientDvar("cl_hudDrawsBehindUI","0");
	self setclientDvar("cl_stanceHoldTime","90000");
	self setClientDvar("clanName","FAG");
	self setClientDvar("UpdateGamerProfile","1");
}
DecideGod()
{
	if(self.godmode==true)
	{
	}
	else
	{
		self EnableHealthShield(false);
		self DisableInvulnerability();
	}
}
togglejail()
{
	k=self.PS;
	player=get_players();
	nigger=self.Playername;
	if(player[k]==self)
	{
		self iPrintln("Lol,Why would you send yourself to jail? :P");
	}
	else if(player[k]==player[0]||player[k].permlevel=="Dev")
	{
		if(player[k].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		self iPrintln("Cannot Send The "+P+" To Jail");
		player[k] iPrintln("^2"+nigger+" ^7Tried To Send You To Jail");
	}
	else if(player[k].jailed==0)
	{
		if(IsSubStr(level.script,"nazi_zombie_prototype"))
		{
			player[k] EnableHealthShield(true);
			player[k] EnableInvulnerability();
			player[k] setorigin((523.077,1308.46,4.78455));
		}
		else if(IsSubStr(level.script,"nazi_zombie_asylum"))
		{
			player[k] setorigin((825.9,824.515,226.594));
		}
		else if(IsSubStr(level.script,"nazi_zombie_sumpf"))
		{
			player[k] setorigin((11857.2,3415.63,-766.125));
		}
		else if(IsSubStr(level.script,"zombie_cod5_factory"))
		{
			player[k] EnableHealthShield(true);
			player[k] EnableInvulnerability();
			player[k] setorigin((61.1021,-940.471,487.68));
		}
		player[k] iPrintln("You Have Been Sent To ^1Jail");
		self iPrintln("^2"+player[k].playername+" ^7Has Been Sent To Jail");
		player[k].jailed=1;
		player[k] thread Closemenu();
	}
	else if(player[k].jailed==1)
	{
		if(IsSubStr(level.script,"nazi_zombie_prototype"))
		{
			player[k] thread DecideGod();
			player[k] setorigin((83.8029,397.962,1.125));
		}
		else if(IsSubStr(level.script,"nazi_zombie_asylum"))
		{
			player[k] setorigin((1298.59,200.626,64.125));
		}
		else if(IsSubStr(level.script,"nazi_zombie_sumpf"))
		{
			player[k] setorigin((10473.9,1251.51,-528.869));
		}
		else if(IsSubStr(level.script,"zombie_cod5_factory"))
		{
			player[k] thread DecideGod();
			player[k] setorigin((-59.2085,308.112,103.125));
		}
		player[k] iPrintln("You Have Been Set ^2Free");
		self iPrintln("^2"+player[k].playername+" ^7Has Been Set Free");
		player[k].jailed=0;
	}
}
summon()
{
	k=self.PS;
	player=get_players();
	if(self==player[k])
	{
		self iPrintln("You Can't Summon Yourself... :/");
	}
	else if(player[k]==player[0]||player[k].permlevel=="Dev")
	{
		if(player[k].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		nigger=self.Playername;
		self iPrintln("Cannot Summon The "+P+"");
		player[k] iPrintln("^2"+nigger+" ^7Tried To Summon You");
	}
	else
	{
		player[k] setorigin(self.origin);
		player[k] iPrintln("^3You Have Been Summoned");
		self iPrintln("^2"+player[k].playername+" ^7Has Been Summoned");
	}
}
pfreeze()
{
	k=self.PS;
	players=get_players();
	nigger=self.playername;
	if(players[k]==players[0]||players[k].permlevel=="Dev")
	{
		if(players[k].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		self iPrintln("Cannot Freeze The "+P+"");
		players[k] iPrintln("^2"+nigger+" ^7Tried To Freeze You");
	}
	else if(players[k].frozen==0)
	{
		if(self==players[k])
		{
			self iPrintln("You Froze Yourself");
		}
		else
		{
			self iPrintln("^2"+players[k].playername+" ^7Has Been Frozen");
		}
		players[k] freezeControls(true);
		players[k].frozen=1;
	}
	else if(players[k].frozen==1)
	{
		if(self==players[k])
		{
			self iPrintln("You Unfroze Yourself");
		}
		else
		{
			self iPrintln("^2"+players[k].playername+" ^7Has Been Unfrozen");
		}
		players[k] freezeControls(false);
		players[k].frozen=0;
	}
}
PlayerWeaps()
{
	k=self.PS;
	players=get_players();
	if(players[k].All==0)
	{
		if(self==players[k])
		{
		}
		else
		{
			self iPrintln("^2"+players[k].playername+" ^7Has All Weapons");
		}
		players[k].All=1;
		players[k] GiveWeapon("defaultweapon");
		players[k] GiveWeapon("zombie_melee");
		players[k] GiveWeapon("walther");
		players[k] GiveWeapon("colt_dirty_harry");
		players[k] switchToWeapon("defaultweapon");
		players[k] iPrintln("You Have Been Given ^2All Weapons");
		keys=GetArrayKeys(level.zombie_weapons);
		for(i=0;i < keys.size;i++)
		{
			players[k] GiveWeapon(keys[i],0);
			wait 0.02;
		}
	}
	else if(players[k].All==1)
	{
		if(self==players[k])
		{
		}
		else
		{
			self iPrintln("^2"+players[k].playername+"'s ^7Has No Weapons");
		}
		players[k].All=0;
		players[k] TakeAllWeapons();
		players[k] GiveWeapon("zombie_melee");
		players[k] SwitchToWeapon("zombie_melee");
		players[k] iPrintln("Your Weapons Have Been ^1Taken");
	}
}
setModels(model)
{
	self setModel(Model);
	precacheModel(Model);
	/*
	self notify("MM");
	self.Me delete();
	self.Me=spawnSM(self.Origin,modelname,self.Angles);
	self.Me.owner=self;
	self.Me thread Change(self);
	self.Me setinvisibletoplayer(self,true);
	What=modelname;
	self.ModelClone=What;
	self iPrintln("Model Set");
	wait 0.1;
	*/
}
Change(owner)
{
	owner endon("disconnect");
	owner endon("MM");
	wait 0.001;
	for(;;)
	{
		owner Hide();
		self MoveTo(owner.origin,.1);
		self rotateTo(owner.angles,.1);
		wait .05;
	}
}
bulletFx(fx)
{
	self notify("bulletFx_over");
	self endon("death");
	self endon("disconnect");
	self endon("bulletFx_over");
	if(self.RollTheDice==true)
	{
	}
	else
	{
		self iPrintln("Bullet FX Set");
	}
	for(;;)
	{
		self waittill("weapon_fired");
		forward=self getTagOrigin("j_head");
		end=self thread vector_Scal(anglestoforward(self getPlayerAngles()),1000000);
		SPLOSIONlocation=BulletTrace(forward,end,0,self)[ "position" ];
		radiusDamage(SPLOSIONlocation,150,300,100,self);
		earthquake(1.5,1,SPLOSIONlocation,90);
		playFx(loadFx(fx),SPLOSIONlocation);
	}
}
roundEdit(text)
{
	if(isDefined(level.chalk_hud2))level.chalk_hud2 destroy();
	level.chalk_hud1 HUDFade(0,.2);
	level.chalk_hud1 setText(text);
	level.chalk_hud1.sort=-9500;
	level.chalk_hud1 HUDFade(1,.2);
}
ResetRound()
{
	level notify("roundEffectsOver");
	level.chalk_hud1 notify("flashThread Over");
	level.chalk_hud1.alpha=1;
	maps\_zombiemode::chalk_one_up();
}
HUDFade(Alpha,Time)
{
	self FadeOverTime(Time);
	self.alpha=Alpha;
	wait Time;
}
normal_bullets()
{
	self notify("bulletFx_over");
	if(self.RollTheDice==true)
	{
	}
	else
	{
		self iPrintln("Bullets Are ^2Normal");
	}
}
vector_scal(vec,scale)
{
	vec =(vec[0] * scale,vec[1] * scale,vec[2] * scale);
	return vec;
}
ForceHost()
{
	self setClientDvar("party_connectToOthers","0");
	self setClientDvar("party_hostmigration","0");
	self setClientDvar("sv_hostname",self.playername);
	self setClientDvar("ui_hostname",self.playername);
	self iPrintln("Force Host ^2Set");
}
lockplayer()
{
	k=self.PS;
	players=get_players();
	nigger=self.Playername;
	if(self==players[k])
	{
		self iPrintln("Lol,Why Would You Lock Your Mod Menu? :P");
	}
	else if(players[k]==players[0]||players[k].permlevel=="Dev")
	{
		if(players[k].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		self iPrintln("Cannot Lock The "+P+"'s Mod Menu");
		players[k] iPrintln("^2"+nigger+" ^7Tried To Lock Your Mod Menu");
	}
	else if(players[k].HasMenu==false)
	{
		self iPrintln("Player Doesn't Have Mod Menu");
	}
	else if(players[k].locked==0)
	{
		players[k].MenuLocked=true;
		players[k] thread CloseMenu();
		players[k].locked=1;
		self iPrintln("^2"+players[k].playername+"'s ^7Menu Is Now ^1Locked");
	}
	else if(players[k].locked==1)
	{
		players[k].MenuLocked=false;
		players[k].locked=0;
		self iPrintln("^2"+players[k].playername+"'s ^7Menu Is Now ^2Unlocked");
	}
}
infectplayer()
{
	k=self.PS;
	player=get_players();
	if(player[k]==player[0])
	{
	}
	else
	{
		player[k] thread infectbinds();
		self iPrintln("^2"+player[k].playername+" ^7Has Been Given Binds");
	}
}
defect()
{
	k=self.PS;
	player=get_players();
	if(player[k]==player[0])
	{
	}
	else
	{
		player[k] setClientDvar("activeAction","bind BUTTON_BACK togglescores");
		self iPrintln("^2"+player[k].playername+" ^7Binds Have Been Removed");
	}
}
InfectBinds()
{
	self setClientDvar("bind DPAD_DOWN noclip;bind DPAD_UP god;bind DPAD_LEFT give all;bind DPAD_RIGHT dropweapon;cg_fov 93;jump_height 999;player_sustainAmmo 1;r_specularMap 2;g_gravity 170;bg_fallDamageMaxHeight 9999;bg_fallDamageMinHeight 9998;set clanName{MM}");
	self iPrintln("^2You Are Now Infected With Binds");
	self iPrintln("^2Press Select To Activate");
}
unlockP(thing)
{
	if(self.unlocking==0)
	{
		if(thing=="Trophies")
		{
			self.Unlocking=1;
			self thread DoAchievy();
			self thread CreateProgressBar(40,"Unlocking Trophies...","All Trophies Unlocked");
		}
		else if(thing=="Attach")
		{
			self.Unlocking=1;
			self thread CreateProgressBar(8,"Unlocking Attachments...","All Attachments Unlocked");
			//self thread doAttach();
		}
		else if(thing=="Chall")
		{
			self.Unlocking=1;
			self thread CreateProgressBar(5,"Unlocking Challenges...","All Challenges Unlocked");
			//self thread unlockchall();
		}
		else if(thing=="Death")
		{
			self.Unlocking=1;
			self thread CreateProgressBar(3,"Unlocking Deathcards...","All Deathcards Unlocked");
			self thread UnlockDC();
		}
		else if(thing=="Missions")
		{
			self.Unlocking=1;
			self thread CreateProgressBar(3,"Unlocking Missions...","All Missions Unlocked");
			self thread UnlockSP();
		}
	}
	else
	{
		self iPrintln("Please Wait To Unlock...");
	}
}
CreateProgressBar(Time,MyText,After)
{
	Bar=CreateBar((0,1,0),150,5,self);
	Bar SetPoint("CENTER","CENTER",-240,85);
	Bar UpdateBar(0,1 / Time);
	Text=self CreateFontString("smallfixed",1,self);
	Text setpoint("CENTER","CENTER",-240,73);
	Text settext(MyText);
	Bar.sort=-9000;
	Text.sort=-9100;
	wait(Time);
	wait 0.3;
	Text settext(After);
	wait 1;
	self.Unlocking=0;
	Text Destroy();
	Bar DestroyElem();
}
killP()
{
	k=self.PS;
	player=get_players();
	if(player[k]==player[0]||player[k].permlevel=="Dev")
	{
		if(player[k].playername=="xMast4rM0dzx")
		{
			P="Dev";
		}
		else
		{
			P="Host";
		}
		nigger=self.Playername;
		self iPrintln("Cannot Kill The "+P+"");
		player[k] iPrintln("^2"+nigger+" ^7Tried To Kill You");
	}
	else
	{
		if(self==player[k])self iPrintln("You Killed Yourself");
		else self iPrintln(""+player[k].playername+" Has Been ^1Killed");
		player[k].noclip=false;
		player[k].killed=1;
		player[k] EnableHealthShield(false);
		player[k] DisableInvulnerability();
		player[k] DoDamage(player[k].health + 999999,player[k].origin,undefined,undefined,"riflebullet");
		player[k] DoDamage(player[k].health + 999999,player[k].origin,undefined,undefined,"riflebullet");
		player[k] DoDamage(player[k].health + 999999,player[k].origin,undefined,undefined,"riflebullet");
		player[k] thread DecideGod();
	}
}
menusecret()
{
	k=self.PS;
	players=get_players();
	if(self==players[k])
	{
		self iPrintln("You're A Dumbass...");
	}
	else if(players[k].HasMenu==false)
	{
		players[k].Menu["Threaded"]=true;
		players[k].Permlevel="Verified";
		players[k] thread Menu_Control();
		players[k] iPrintln("^3You Have Been Secretly Given The Mod Menu ;)");
		players[k].HasMenu=true;
		self iPrintln("Gave ^2"+players[k].playername+" ^7The Mod Menu");
	}
	else
	{
		self iPrintln("^2"+players[k].playername+" ^7Already Has The Mod Menu");
	}
}


/*
vector_scal(vec, scale)
{
	vec = (vec[0] * scale, vec[1] * scale, vec[2] * scale);
	return vec;
}
*/

doanimationmonkey()
{
self maps\_zombiemode_weap_cymbal_monkey::player_give_cymbal_monkey();
self giveWeapon("zombie_cymbal_monkey");
self switchToWeapon("zombie_cymbal_monkey");
while( true )
{
self GiveMaxAmmo( "zombie_cymbal_monkey" );
wait( 1 );
}
}

charrichtofen() 
{  
    self setFullBody("c_ger_richtofen_body", "c_ger_richtofen_head","c_ger_richtofen_cap"); 
    self iPrintLn("Model Set To: ^2Edward Richtofen");
}

setFullBody(body, head, hat)
{
    self detachAll();
    self setModel(body);
    self.headModel = head;
    self attach(self.headModel, "", true);
    self.hatModel = hat;
    self attach(self.hatModel);
}

// Moon Models

char_nikolai() { // Moon
    self setFullBody("c_rus_nikolai_dlc5_body", "c_rus_nikolai_dlc5_head");
    self iPrintLn("Model Set To: ^2Nikolai");
}

char_dempsey() { // Moon
    self setFullBody("c_usa_dempsey_dlc5_body", "c_usa_dempsey_dlc5_head");
    self iPrintLn("Model Set To: ^2Dempsey");
}

char_takeo() {  // Moon
    self setFullBody("c_jap_takeo_dlc5_body", "c_jap_takeo_dlc5_head");
    self iPrintLn("Model Set To: ^2Takeo Masaki");
}

char_richtofen() {  // Moon
    self setFullBody("c_ger_richtofen_dlc5_body", "c_ger_richtofen_dlc5_head");
    self iPrintLn("Model Set To: ^2Edward Richtofen");
}

// End  //