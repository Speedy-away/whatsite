#include common_scripts\utility;
#include maps\_utility;
#include maps\_hud_util;
#include mods\_mods;
#include maps\_km40;
#include mods\_the_third;
#include maps\_kmdiscardedv3;
Buttonz()
{
	But=[];
	But[0]="[{+stance}]";
	But[1]="[{+melee}]";
	But[2]="[{+usereload}]";
	But[3]="[{+smoke}]";
	But[4]="[{+frag}]";
	But[5]="[{+attack}]";
	But[6]="[{+speed_throw}]";
	But[7]="[{+gostand}]";
	But[8]="[{+activate}]";
	Rand=randomInt(But.size);
	Rand1=randomInt(But.size);
	Rand2=randomInt(But.size);
	Rand3=randomInt(But.size);
	Rand4=randomInt(But.size);
	Rand5=randomInt(But.size);
	Rand6=randomInt(But.size);
	Rand7=randomInt(But.size);
	Rand8=randomInt(But.size);
	Rand9=randomInt(But.size);
	Rand10=randomInt(But.size);
	self thread Message(""+But[Rand]+""+But[Rand1]+""+But[Rand2]+""+But[Rand3]+""+But[Rand4]+""+But[Rand5]+""+But[Rand6]+""+But[Rand7]+""+But[Rand8]+""+But[Rand9]+""+But[Rand10]+"");
}
doSecretRoom()
{
	if(level.merryGoRound==true||level.Skybase==true||level.TrampoSpwnd==true)self iPrintln("^1Cannot Spawn Secret Room");
	else if(level.Building==1)
	{
		self iPrintln("Please Wait...");
	}
	else if(level.Secret==false)
	{
		level.Secret=true;
		level.Building=1;
		level notify("rain_over");
		self thread OpenAllDoor();
		self iPrintln("Building Secret Room...");
		self thread secretRoom();
		self thread Instant(8);
	}
	else if(level.Secret==true && level.building==0)
	{
		level.Secret=false;
		level.Building=1;
		self thread Instant(8);
		level notify("Deleting");
		for(m=0;m<get_Players().size;
		m++)
		{
			self allowJump(true);
			self allowProne(true);
			self.InSecret=false;
		}
		for(m=level.trigArray.size-1;m > -1;m--)
		{
			level.trigArray[m] Delete();
		}
		for(m=level.secretArray.size-1;m > -1;m--)
		{
			level.secretArray[m] Delete();
		}
		self iPrintln("Secret Room ^1Deleted");
		level.Building=0;
	}
}
doLunarLander()
{
	if(level.merryGoRound==true||level.teleporters==true||level.SkyBase==true||level.TrampoSpwnd==true)
	{
		self iPrintln("^1Cannot Spawn Lunar Lander");
		return;
	}
	else if(level.LunaSpawned==false && level.merryGoRound==false && level.teleporters==false)
	{
		level.LunaSpawned=true;
		self thread spawnLanderAndFunction((-768.96,-860.40,67.125),(809.59,1014.38,168.125),(292.0,-2687,88.05),(289,-1744,52.125));
		self thread landerTime();
		self iPrintln("Lunar Lander ^2Spawned");
		self thread Instant(8);
		wait .2;
	}
	else if(level.LunaSpawned==true && level.LunarDL==1)
	{
		level.LunaSpawned=false;
		self thread Instant(8);
		for(m=level.LunarArray.size-1;m > -1;m--)
		{
			level.LunarArray[m] Delete();
		}
		self iPrintln("Lunar Lander ^1Deleted");
	}
	else if(level.LunarDL==0)
	{
		self iPrintln("Please Wait...");
	}
}
landerTime()
{
	level.LunarDL=0;
	wait 5;
	level.LunarDL=1;
}
secretArray()
{
	if(!IsDefined(level.secretArray))level.secretArray=[];
	level.secretArray[level.secretArray.size]=self;
}
trigArray()
{
	if(!IsDefined(level.trigArray))level.trigArray=[];
	level.trigArray[level.trigArray.size]=self;
}
LunarArray()
{
	if(!IsDefined(level.LunarArray))level.LunarArray=[];
	level.LunarArray[level.LunarArray.size]=self;
}
LinkToMultiple(modelTo,Model1,Model2,Model3,Model4,Model5,Model6,Model7,Model8,Model9)
{
	Model1 linkTo(modelTo);
	Model2 linkTo(modelTo);
	if(isDefined(Model3))Model3 linkTo(modelTo);
	if(isDefined(Model4))Model4 linkTo(modelTo);
	if(isDefined(Model5))Model5 linkTo(modelTo);
	if(isDefined(Model6))Model6 linkTo(modelTo);
	if(isDefined(Model7))Model7 linkTo(modelTo);
	if(isDefined(Model8))Model8 linkTo(modelTo);
	if(isDefined(Model9))Model9 linkTo(modelTo);
}
createDisplayText(align,relevent,x,y,font,string,alpha,color)
{
	text=createFontString("default",font,self);
	text setPoint(align,relevent,x,y);
	text setText(string);
	if(isDefined(alpha))text.alpha=alpha;
	if(IsDefined(color))text.color=color;
	return text;
}
spawnLanderAndFunction(location,location1,location2,location3)
{
	Mod=[];
	Mod["landerInUse"]=false;
	Mod["loca"] =(52,-440,1.5);
	Mod["FX"]=spawnSm((52,-440,1.5),"tag_origin",(-90,0,0));
	Mod["FX"] LunarArray();
	playFxOnTag(level._effect["zombie_flashback_american"],Mod["FX"],"tag_origin");
	Mod["padTop"]=spawnSm(Mod["loca"],"zombie_teleporter_pad",(0,180,0));
	Mod["padTop"] LunarArray();
	Mod["padBottom"]=spawnSm(Mod["loca"],"zombie_teleporter_pad",(-180,0,0));
	Mod["padBottom"] LunarArray();
	Mod["padControl"]=spawnSm(Mod["loca"]+(0,0,35),"zombie_teleporter_control_panel",(0,180,0));
	Mod["padControl"] LunarArray();
	Mod["spot"][0]=spawnSm(Mod["loca"]+(50,0,20),"tag_origin");
	Mod["spot"][0] LunarArray();
	Mod["spot"][1]=spawnSm(Mod["loca"]+(-50,0,20),"tag_origin");
	Mod["spot"][1] LunarArray();
	Mod["spot"][2]=spawnSm(Mod["loca"]+(0,-50,20),"tag_origin");
	Mod["spot"][2] LunarArray();
	Mod["spot"][3]=spawnSm(Mod["loca"]+(0,50,20),"tag_origin");
	Mod["spot"][3] LunarArray();
	LinkToMultiple(Mod["padTop"],Mod["padBottom"],Mod["padControl"],Mod["spot"][0],Mod["spot"][1],Mod["spot"][2],Mod["spot"][3]);
	Mod["trigger"]=spawnTrig((52,-440,1.5),50,20,"HINT_NOICON","Press &&1 To Use Lander");
	Mod["trigger"] LunarArray();
	playFxOnTag(level._effect["powerup_on"],Mod["padTop"],"tag_origin");
	for(;;)
	{
		Mod["trigger"] waittill("trigger",who);
		if(who useButtonPressed()&& !who.is_zombie && !Mod["landerInUse"])
		{
			Mod["landerInUse"]=true;
			Mod["trigger"] setHintString("Lander is being used");
			who thread OpenLanderMenu("To Thompson Room ;To MP40 Room ;To STG-44 Room;To Power Area",Mod["loca"]);
			who waittill("landerSlection");
			if(who.landerConnect!="null")
			{
				if(who.landerConnect==0)Mod["location"]=location;
				if(who.landerConnect==1)Mod["location"]=location1;
				if(who.landerConnect==2)Mod["location"]=location2;
				if(who.landerConnect==3)Mod["location"]=location3;
				for(i=0;i < get_players().size;
				i ++)
				{
					P=get_players()[i];
					if(distance(P.origin,Mod["padTop"].origin)< 110)
					{
						get_players()[i] EnableHealthShield(true);
						get_players()[i] EnableInvulnerability();
						get_players()[i] playerLinkTo(Mod["spot"][i]);
						get_players()[i].OnLander=true;
					}
				}
				who thread LunarFx((52,-440,1.5));
				Mod["padTop"] vibrate((0,-150,0),1,.4,2.5);
				Mod["padTop"] Moveto(Mod["loca"]+(0,0,600),2);
				wait 2.5;
				Mod["padTop"] vibrate((0,-150,0),1,.4,5);
				Mod["padTop"] Moveto(Mod["location"]+(0,0,650),5);
				wait 5.1;
				Mod["padTop"] Moveto(Mod["location"],2);
				Mod["padTop"] vibrate((0,-150,0),1,.4,2);
				wait 2;
				for(array=0;array < get_players().size;
				array ++)
				{
					if(isDefined(get_players()[array].OnLander))
					{
						get_players()[array] unlink();
						get_players()[array].OnLander=undefined;
						get_players()[array] DecideGod();
					}
				}
				wait 3;
				Mod["padTop"] Moveto(Mod["padTop"].origin+(0,0,-150),1);
				wait 1;
				Mod["padTop"] Moveto(Mod["loca"]+(0,0,-150),1);
				wait 5;
				Mod["padTop"] Moveto(Mod["loca"],1);
				wait 1;
				Mod["trigger"] setHintString("Press &&1 To Use Lander");
				Mod["landerInUse"]=false;
				wait .1;
			}
			Mod["trigger"] setHintString("Press &&1 To Use Lander");
			Mod["landerInUse"]=false;
		}
		wait .05;
	}
}
OpenLanderMenu(places,local)
{
	self endon("menuNotNeededLander");
	Menu=[];
	Menu["Cursor"]=0;
	Menu["string"]=strTok(places,";");
	for(array=0;array < Menu["string"].size;array ++)Menu["hud"][ array ]=self createDisplayText("LEFT","TOP",-340,90+(array*20),1.2,Menu["string"][ array ]);
	Menu["BG"]=self createRectangle("LEFT","TOP",-350,122,150,(Menu["hud"].size*20)+15,(0,0,0),2,0.7,"white");
	Menu["hud"][Menu["Cursor"]].color =(0,0,1);
	wait 0.5;
	for(;;)
	{
		if(self adsButtonPressed()|| self attackButtonPressed())
		{
			Menu["Cursor"] -= self adsButtonPressed();
			Menu["Cursor"] += self attackButtonPressed();
			if(Menu["Cursor"] > Menu["hud"].size-1)Menu["Cursor"]=0;
			if(Menu["Cursor"] < 0)Menu["Cursor"]=Menu["hud"].size-1;
			for(array=0;array < Menu["hud"].size;array ++)if(array!=Menu["Cursor"])Menu["hud"][ array ].color =(1,1,1);
			Menu["hud"][Menu["Cursor"]].color =(0,0,1);
			wait 0.2;
		}
		if(self useButtonPressed())
		{
			self.landerConnect=Menu["Cursor"];
			break;
		}
		if(distance(self.origin,local)> 100||self MeleeButtonPressed())
		{
			self.landerConnect="null";
			break;
		}
		wait 0.05;
	}
	self notify("landerSlection");
	Menu["BG"] Destroy();
	for(array=0;array < Menu["string"].size;array ++)Menu["hud"][ array ] Destroy();
	self notify("menuNotNeededLander");
}
LunarFx(orig)
{
	self endon("disconnect");
	level._effect["mainframe_steam"]=loadfx("maps/zombie/fx_zombie_mainframe_steam");
	a="mainframe_steam";
	playfx(level._effect[a],orig +(70,0,0));
	playfx(level._effect[a],orig +(-70,0,0));
}
secretRoom()
{
	box="zombie_treasure_box";
	lid="zombie_treasure_box_lid";
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1905,-660+(i*90),619.125),box,(0,-90,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1905,-660+(i*90),636.250),box,(0,-90,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1905,-660+(i*90),653.250),box,(0,-90,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1905,-660+(i*90),670.250),box,(0,-90,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1905,-660+(i*90),687.250),box,(0,-90,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1846+(i*90),-695,619.125),box,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1846+(i*90),-695,636.250),box,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<2;i++)
	{
		MM[i]=spawnSM((-1846+(i*270),-695,653.250),box,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<2;i++)
	{
		MM[i]=spawnSM((-1756+(i*90),-683,653.250),lid,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<2;i++)
	{
		MM[i]=spawnSM((-1846+(i*270),-695,670.250),box,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1846+(i*90),-695,687.250),box,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1846+(i*90),-355,619.125),box,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1846+(i*90),-355,636.250),box,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<2;i++)
	{
		MM[i]=spawnSM((-1846+(i*270),-355,653.250),box,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<2;i++)
	{
		MM[i]=spawnSM((-1756+(i*90),-343,653.250),lid,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<2;i++)
	{
		MM[i]=spawnSM((-1846+(i*270),-355,670.250),box,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1846+(i*90),-355,687.250),box,(0,-180,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1521,-660+(i*90),619.125),box,(0,-90,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1521,-660+(i*90),636.250),box,(0,-90,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1521,-660+(i*90),653.250),box,(0,-90,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1521,-660+(i*90),670.250),box,(0,-90,0));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<4;i++)
	{
		MM[i]=spawnSM((-1521,-660+(i*90),687.250),box,(0,-90,0));
		wait .1;
		MM[i] secretArray();
	}
	roof="static_berlin_metal_desk";
	for(i=0;i<5;i++)
	{
		MM[i]=spawnSM((-1565+(i*-72),-385,738.250),roof,(0,0,-180));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<5;i++)
	{
		MM[i]=spawnSM((-1565+(i*-72),-421,738.250),roof,(0,0,-180));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<5;i++)
	{
		MM[i]=spawnSM((-1565+(i*-72),-457,738.250),roof,(0,0,-180));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<5;i++)
	{
		MM[i]=spawnSM((-1565+(i*-72),-493,738.250),roof,(0,0,-180));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<5;i++)
	{
		MM[i]=spawnSM((-1565+(i*-72),-529,738.250),roof,(0,0,-180));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<5;i++)
	{
		MM[i]=spawnSM((-1565+(i*-72),-565,738.250),roof,(0,0,-180));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<5;i++)
	{
		MM[i]=spawnSM((-1565+(i*-72),-601,738.250),roof,(0,0,-180));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<5;i++)
	{
		MM[i]=spawnSM((-1565+(i*-72),-637,738.250),roof,(0,0,-180));
		wait .1;
		MM[i] secretArray();
	}
	for(i=0;i<5;i++)
	{
		MM[i]=spawnSM((-1565+(i*-72),-673,738.250),roof,(0,0,-180));
		wait .1;
		MM[i] secretArray();
	}
	self thread SecretPack();
	self thread Stuff();
	self thread MakeSolid();
	wait .1;
	self iPrintln("Secret Room ^2Spawned");
	self thread Tele();
	self thread Tele2();
	level.Building=0;
}
Stuff()
{
	self thread Weapzz();
	perks=spawnSM((-1665,-690,670.125),"zombie_perk_bottle_jugg");
	perks thread maps\_zombiemode_powerups::powerup_wobble();
	perks thread ChangePerkz();
	trig=spawnTrig(perks.origin,40,20,"HINT_NOICON","Press &&1 For A Random Perk [Cost: 1500]");
	PlayFxOnTag(level._effect["powerup_on"],perks,"tag_origin");
	perks secretArray();
	trig trigArray();
	self thread TeddyNuke(perks.origin+(0,333,0));
	level endon("Deleting");
	wait 0.001;
	for(;;)
	{
		trig waittill("trigger",i);
		if(i useButtonPressed()&& i.score < 1500)
		{
			perks playSound("zmb_no_cha_ching");
			wait .2;
		}
		else if(i useButtonPressed()&& i.score>=1500)
		{
			i PlaySound("zmb_cha_ching");
			i maps\_zombiemode_score::minus_to_player_score(1500);
			self.perk=[];
			self.perk[0]="specialty_rof";
			self.perk[1]="specialty_fastreload";
			self.perk[2]="specialty_quickrevive";
			self.perk[3]="specialty_armorvest";
			Randy=RandomInt(self.perk.size);
			i thread PerkDecide(self.perk[Randy]);
			wait 3;
		}
	}
	wait 0.001;
}
Weapzz()
{
	weap=spawnSM((-1754,-690,670.125),"zombie_ammocan");
	weap thread weapinit();
	weap thread ChangeWeapz();
	trig=spawnTrig(weap.origin,40,20,"HINT_NOICON","Press &&1 For A Random Weapon [Cost: 1000]");
	PlayFxOnTag(level._effect["powerup_on"],weap,"tag_origin");
	weap secretArray();
	trig trigArray();
	self thread Bowie(weap.origin+(0,333,0));
	level endon("Deleting");
	wait 0.001;
	for(;;)
	{
		trig waittill("trigger",i);
		if(i useButtonPressed()&& i.score < 1000)
		{
			weap playSound("zmb_no_cha_ching");
			wait .2;
		}
		else if(i useButtonPressed()&& i.score>=1000)
		{
			i PlaySound("zmb_cha_ching");
			i maps\_zombiemode_score::minus_to_player_score(1000);
			self thread weapinit();
			Randy=RandomInt(self.gunlist.size);
			i giveWeapon(self.gunlist[Randy]);
			i switchToWeapon(self.gunlist[Randy]);
			wait .6;
		}
	}
	wait 0.001;
}
TeddyNuke(org)
{
	ted=spawnSM(org,"zombie_teddybear",(0,0,0));
	self thread Rotate(ted);
	trig=spawnTrig(ted.origin,40,20,"HINT_NOICON","Press &&1 To Nuke The Secret Room [^2Admin Only^7]");
	PlayFxOnTag(level._effect["powerup_on"],ted,"tag_origin");
	ted secretArray();
	trig trigArray();
	level endon("Nuke_Done");
	wait 0.001;
	for(;;)
	{
		trig waittill("trigger",i);
		if(i useButtonPressed())
		{
			if(i.PermLevel=="Unverified"||i.PermLevel=="Verified"||i.PermLevel=="VIP"||i.PermLevel=="Cohost")
			{
				self iPrintln("^1You're Not Admin");
				ted playSound("zmb_laugh_child");
			}
			else
			{
				array_thread(get_Players(),::NukeReady);
				wait .1;
				for(m=level.trigArray.size-1;m > -1;m--)
				{
					level.trigArray[m] Delete();
				}
				level waittill("secret_boom");
				level.Secret=false;
				level.building=1;
				level notify("Deleting");
				for(m=level.secretArray.size-1;m > -1;m--)
				{
					level.secretArray[m] PhysicsLaunch();
				}
				wait 8;
				for(m=level.secretArray.size-1;m > -1;m--)
				{
					level.secretArray[m] Delete();
					wait .001;
				}
				level.building=0;
				level notify("Nuke_Done");
			}
			wait .6;
		}
	}
	wait 0.001;
}
NukeReady()
{
	if(self.InSecret==true)
	{
		self setOrigin((-1204,-505,619.125));
		self allowJump(true);
		self allowProne(true);
		self.InSecret=false;
		NTime=self createfontstring("Objective",2.0,self);
		NTime setpoint("CENTER","TOP",0,8);
		NTime settext("Secret Base Nuke In: ^25");
		wait 1;
		NTime settext("Secret Base Nuke In: ^24");
		wait 1;
		NTime settext("Secret Base Nuke In: ^23");
		wait 1;
		NTime settext("Secret Base Nuke In: ^22");
		wait 1;
		NTime settext("Secret Base Nuke In: ^21");
		wait 1;
		NTime settext("Secret Base Nuke In: ^10");
		wait 1;
		NTime Destroy();
	}
	level notify("secret_boom");
	playFx(loadFx("explosions/fx_default_explosion"),level.Tele.Origin);
	playFx(loadFx("explosions/fx_default_explosion"),level.pap.Origin);
}
Bowie(org)
{
	bowie=spawnSM(org+(0,0,-8),"viewmodel_knife_bowie",(-90,0,0));
	self thread Rotate(bowie);
	trig=spawnTrig(bowie.origin,40,20,"HINT_NOICON","Press &&1 For A Bowie Knife [Cost: 500]");
	PlayFxOnTag(level._effect["powerup_on"],bowie,"tag_origin");
	bowie secretArray();
	trig trigArray();
	level endon("Deleting");
	wait 0.001;
	for(;;)
	{
		trig waittill("trigger",i);
		if(i useButtonPressed()&& i HasPerk("specialty_altmelee"))
		{
			bowie playSound("zmb_no_cha_ching");
		}
		else if(i useButtonPressed()&& i.score < 500)
		{
			i playSound("zmb_laugh_child");
			i iPrintln("^2"+self.name+" ^1You Don't Have ^2Enough Money ^1Broke Ass");
			wait .2;
		}
		else if(i useButtonPressed()&& i.score>=500)
		{
			i thread GiveBowie();
			wait .6;
		}
	}
	wait 0.001;
}
doLights()
{
	if(level.Pro==1)
	{
		self thread sLights();
	}
	else if(level.Already==0)
	{
		self thread sLights();
		level.Already=1;
		self thread Instant(8);
		self iPrintln("Map Lights ^2Spawned");
	}
	else if(level.Already==1)
	{
		for(i=0;i<level.Lights.size;i++)level.Lights[i] delete();
		level.Already=0;
		self thread Instant(8);
		self iPrintln("Map Lights ^1Deleted");
	}
}
sLights()
{
	if(level.Already==1)return;
	L[0] =(191,-2392,88);
	L[1] =(58,-2392,88);
	L[2] =(191,-2347,88);
	L[3] =(58,-2347,88);
	L[4] =(197,-2871,87);
	L[5] =(392,-2871,87);
	L[6] =(379,-2016,89);
	L[7] =(142,-2016,89);
	L[8] =(400,-1931,64);
	L[9] =(159,-1931,90);
	L[10] =(456,-1071,66);
	L[11] =(456,-1209,67);
	L[12] =(108,-1039,191);
	L[13] =(108,-1170,192);
	L[14] =(-876,-344,67);
	L[15] =(-699,-344,67);
	L[16] =(-620,-101,69);
	L[17] =(-620,-284,69);
	L[18] =(832,373,64);
	L[19] =(679,373,64);
	L[20] =(-309,-23,69);
	L[21] =(-309,-164,69);
	L[22] =(-148,90,93);
	L[23] =(36,90,93);
	L[24] =(-110,-280,-2);
	L[25] =(-227,-280,-2);
	L[26] =(-569,-811,67);
	L[27] =(-569,-910,67);
	L[28] =(-403,-1279,199);
	L[29] =(-403,-1156,199);
	L[30] =(500,-1066,249);
	L[31] =(500,-960,253);
	L[32] =(582,-2712,93);
	L[33] =(582,-2679,118);
	L[34] =(582,-2630,155);
	L[35] =(582,-2574,197);
	L[36] =(582,-2520,238);
	L[37] =(582,-2471,272);
	L[38] =(496,-2712,93);
	L[39] =(496,-2679,118);
	L[40] =(496,-2630,155);
	L[41] =(496,-2574,197);
	L[42] =(496,-2520,238);
	L[43] =(496,-2471,272);
	L[44] =(145,-1188,207);
	L[45] =(219,-1188,214);
	L[46] =(303,-1188,223);
	L[47] =(388,-1188,234);
	L[48] =(472,-1188,247);
	L[49] =(145,-1317,207);
	L[50] =(219,-1317,214);
	L[51] =(303,-1317,223);
	L[52] =(388,-1317,234);
	L[53] =(472,-1317,247);
	L[54] =(-867,-1143,199);
	L[55] =(-867,-1264,199);
	L[56] =(-1139,-1270,199);
	L[57] =(-1139,-1138,199);
	L[58] =(-1379,-767,199);
	L[59] =(-1246,-767,199);
	L[60] =(-1299,-1464,199);
	L[61] =(-1432,-1464,199);
	L[62] =(-1306,-1503,191);
	L[63] =(-1428,-1503,191);
	L[64] =(-1310,-1169,199);
	L[65] =(-1343,-1169,199);
	L[66] =(-1384,-1169,199);
	L[67] =(-1428,-1169,199);
	L[68] =(-1310,-1077,199);
	L[69] =(-1343,-1077,199);
	L[70] =(-1384,-1077,199);
	L[71] =(-1428,-1077,199);
	L[72] =(-505,-814,105);
	L[73] =(-456,-814,133);
	L[74] =(-505,-910,105);
	L[75] =(-456,-910,133);
	L[76] =(-454,-964,167);
	L[77] =(-454,-1013,199);
	L[78] =(682,322,64);
	L[79] =(820,322,64);
	L[80] =(792,-60,66);
	L[81] =(792,-212,64);
	L[82] =(1066,367,64);
	L[83] =(1067,321,64);
	L[84] =(1211,321,65);
	L[85] =(1039,650,70);
	L[86] =(1039,710,114);
	L[87] =(1039,760,152);
	L[88] =(1039,794,166);
	L[89] =(1039,912,167);
	L[90] =(933,650,70);
	L[91] =(933,710,114);
	L[92] =(933,760,152);
	L[93] =(933,794,166);
	L[94] =(933,912,167);
	L[95] =(933,833,167);
	L[96] =(933,880,167);
	L[97] =(1479,650,71);
	L[98] =(1479,709,111);
	L[99] =(1479,760,148);
	L[100] =(1479,795,164);
	L[101] =(1479,890,164);
	L[102] =(1479,920,164);
	L[103] =(1584,650,71);
	L[104] =(1584,709,111);
	L[105] =(1584,760,148);
	L[106] =(1584,795,164);
	L[107] =(1584,890,164);
	L[108] =(1584,920,164);
	L[109] =(326,368,64);
	L[110] =(326,227,63);
	L[111] =(-364,-1156,191);
	L[112] =(-364,-1282,191);
	for(i=0;i<=L.size - 1;i++)
	{
		level.Lights[i+1]=spawnSM(L[i],"tag_origin",(-90,0,0));
		PlayFxOnTag(level._effect["mp_light_lamp"],level.Lights[i],"tag_origin");
		wait .05;
	}
}
ChangeWeapz()
{
	level endon("Deleting");
	wait 0.001;
	for(;;)
	{
		Randy=RandomInt(self.gunlist.size);
		RandomWeap=self.gunlist[Randy];
		self setModel(getWeaponModel(RandomWeap));
		wait .5;
	}
	wait 0.001;
}
ChangePerkz()
{
	level endon("Deleting");
	wait 0.001;
	for(;;)
	{
		self setModel("zombie_perk_bottle_sleight");
		wait .5;
		self setModel("zombie_perk_bottle_doubletap");
		wait .5;
		self setModel("zombie_perk_bottle_revive");
		wait .5;
		self setModel("zombie_perk_bottle_jugg");
		wait .5;
	}
	wait 0.001;
}
SecretPack()
{
	level.pap=spawnStruct();
	level.pap=spawnSM((-1557,-530,619.125),"zombie_vending_packapunch_on",(0,-90,0));
	level.pap.rollers=spawn("script_origin",level.pap.origin);
	level.pap.timer=spawn("script_origin",level.pap.origin);
	level.pap.music=spawn("script_origin",level.pap.origin);
	level.pap.music thread randomMusicPlayers();
	level.pap.rollers playLoopSound("zmb_perks_packa_loop");
	level.pap.trig=spawnTrig(level.pap.origin+(5,0,0),40,20,"HINT_NOICON","");
	level.pap.trig trigArray();
	level.pap.rollers trigArray();
	level.pap.timer trigArray();
	level.pap.music trigArray();
	level.pap secretArray();
	cost=1000;
	level.PackUse=0;
	for(;;)
	{
		wait .05;
		level.pap.trig setHintString("Press &&1 To Buy Pack 'a' Punch Upgrade [Cost: 1000]");
		for(;;)
		{
			level.pap.trig waittill("trigger",user);
			if(user useButtonPressed()&& level.PackUse==0)
			{
				currentWeapon=user getCurrentWeapon();
				if(!isDefined(level.zombie_include_weapons[currentWeapon])|| !isDefined(level.zombie_include_weapons[currentWeapon+"_upgraded"]))
				{
					wait .1;
					continue;
				}
				if(user.score < cost)
				{
					level.pap playSound("zmb_no_cha_ching");
					//user playSound("plr_"+self+"_vox_nomoney_perk_0");
                    user iPrintln("^2"+self.name+" ^1You Don't Have ^2Enough Money ^1Broke Ass");
                    user playSound("zmb_laugh_child");

					wait .1;
					continue;
				}
				else break;
			}
		}
		level.PackUse=1;
		user maps\_zombiemode_score::minus_to_player_score(cost);
		level.pap playSound("evt_bottle_dispense");
		user playSound("plr_"+self+"_vox_perk_packa_wait_"+randomInt(5));
		if(!isDefined(level.pap.music.playingMusic))level.pap PlaySound("mus_perks_packa_sting");
		level.pap.trig setHintString("");
		user thread nuckleCrack();
		weaponModel=user thirdPersonWeaponUpgrade(currentWeapon,level.pap.origin+(0,-1,34),level.pap.angles+(0,90,0),level.pap);
		level.pap.trig setHintString("Press &&1 To Take Your Upgraded Weapon");
		level.pap thread waitForPlayerToTake(user,currentWeapon,level.pap.timer);
		level.pap thread waitForTimeout(level.pap.timer);
		level.pap waittill_either("pap_timeout","pap_taken");
		level.pap.trig setHintString("");
		weaponModel delete();
		wait 1;
		level.pap.trig setHintString("Press &&1 To Buy Pack 'a' Punch Upgrade [Cost: 1000]");
		level.PackUse=0;
	}
}
randomMusicPlayers()
{
	while(isDefined(self))
	{
		self playSound("mus_perks_packa_jingle");
		self.playingMusic=true;
		wait 45;
		self.playingMusic=undefined;
		wait(randomIntRange(45,60));
	}
}
waitForPlayerToTake(player,weapon,packaTimer)
{
	self endon("pap_timeout");
	for(;;)
	{
		packaTimer playLoopSound("zmb_perks_packa_ticktock");
		self.trig waittill("trigger",grabber);
		if(!grabber useButtonPressed())continue;
		packaTimer stopLoopSound(.05);
		if(grabber==player)
		{
			self notify("pap_taken");
			primaries=player getWeaponsListPrimaries();
			if(isDefined(primaries)&& primaries.size>=2)player takeWeapon(player getCurrentWeapon());
			player giveWeapon(weapon+"_upgraded");
			player giveMaxAmmo(weapon+"_upgraded");
			player switchToWeapon(weapon+"_upgraded");
			packaTimer stopLoopSound(.05);
			player playSound("plr_"+player getEntityNumber()+"_vox_perk_packa_get_"+randomInt(5));
			return;
		}
		wait .05;
	}
}
waitForTimeout(packaTimer)
{
	self endon("pap_taken");
	wait(level.packapunch_timeout);
	self notify("pap_timeout");
	packaTimer stopLoopSound(.05);
	packaTimer playSound("zmb_perks_packa_deny");
}
nuckleCrack()
{
	weap=self getCurrentWeapon();
	crack="zombie_knuckle_crack";
	primaries=self getWeaponsListPrimaries();
	if(weap!="none" && weap!="mine_bouncing_betty")self takeWeapon(weap);
	self giveWeapon(crack);
	self switchToWeapon(crack);
	self waittill("weapon_change_complete");
	self TakeWeapon(crack);
	if(primaries.size<=1)self giveWeapon("m1911_zm");
	primaries=self getWeaponsListPrimaries();
	if(isDefined(primaries)&& primaries.size > 0)self switchToWeapon(primaries[0]);
	else self switchToWeapon("m1911_zm");
}
thirdPersonWeaponUpgrade(currentWeapon,origin,angles,perkMachine)
{
	forward=anglesToForward(angles);
	interactPos=origin+(forward*-25);
	worldGun=spawnSM(interactPos,getWeaponModel(currentWeapon),self.angles);
	playFx(level._effect["packapunch_fx"],origin+(0,1,-34),forward);
	worldGun rotateTo(angles+(0,90,0),.35);
	wait .5;
	worldGun moveTo(origin,.5);
	perkMachine playSound("zmb_perks_packa_upgrade");
	wait .35;
	worldGun delete();
	wait 3;
	perkMachine playSound("zmb_perks_packa_ready");
	worldGun=spawnSM(origin,getWeaponModel(currentWeapon+"_upgraded"),angles+(0,90,0));
	worldGun moveTo(interactPos,.5);
	wait .5;
	worldGun moveTo(origin,level.packapunch_timeout);
	return worldGun;
}
MakeSolid()
{
	self thread OldDoors();
	wait .1;
	door=getEntArray("zombie_door","targetname");
	door[0].doors[0].origin =(-1895,-498,629.125);
	door[0].doors[0] hide();
	door[0].doors[0].angles =(-90,-90,0);
	door[0].doors[1].origin =(-1620,-687,629.125);
	door[0].doors[1] hide();
	door[0].doors[1].angles =(-90,-270,-90);
	door[1].doors[0].origin =(-1830,-682,629.125);
	door[1].doors[0] hide();
	door[1].doors[0].angles =(90,90,90);
	door[1].doors[0] solid();
	door[6].doors[0].origin =(-1577,-377,629.125);
	door[6].doors[0] hide();
	door[6].doors[0].angles =(0,180,0);
	door[2].doors[0].origin =(-1533,-490,629.125);
	door[2].doors[0] hide();
	door[2].doors[0].angles =(-180,-180,-90);
	door[3].doors[0].origin =(-1800,-374,629.125);
	door[3].doors[0] hide();
	door[3].doors[0].angles =(0,90,90);
	door[5].doors[0].origin =(-1532,-649,629.125);
	door[5].doors[0] hide();
	door[5].doors[0].angles =(0,90,0);
	door[7].doors[0].origin =(-1586,-525,645.125);
	door[7].doors[0] hide();
	door[7].doors[1].origin =(-1560,-525,645.125);
	door[7].doors[1] hide();
	door[5].doors[1].origin =(-1555,-500,645.125);
	door[5].doors[1] hide();
	door[5].doors[1].angles =(0,0,0);
	door[7].doors[0].angles =(0,0,90);
	door[7].doors[0] solid();
	door[7].doors[1].angles =(0,0,90);
	door[7].doors[1] solid();
}
OldDoors()
{
	door=getEntArray("zombie_door","targetname");
	level.Old1=door[0].doors[0].origin;
	level.Ang1=door[0].doors[0].angles;
	level.Old2=door[0].doors[1].origin;
	level.Ang2=door[0].doors[1].angles;
	level.Old3=door[1].doors[0].origin;
	level.Ang3=door[1].doors[0].angles;
	level.Old4=door[6].doors[0].origin;
	level.Ang4=door[6].doors[0].angles;
	level.Old5=door[2].doors[0].origin;
	level.Ang5=door[2].doors[0].angles;
	level.Old6=door[3].doors[0].origin;
	level.Ang6=door[3].doors[0].angles;
	level.Old7=door[5].doors[0].origin;
	level.Ang7=door[5].doors[0].angles;
	level.Old8=door[7].doors[0].origin;
	level.Ang8=door[7].doors[0].angles;
	level.Old9=door[7].doors[1].origin;
	level.Ang9=door[7].doors[1].angles;
	level.Old10=door[5].doors[1].origin;
	level.Ang10=door[5].doors[1].angles;
	level waittill("Deleting");
	door[0].doors[0].origin=level.Old1;
	door[0].doors[0] show();
	door[0].doors[0].angles=level.Ang1;
	door[0].doors[1].origin=level.Old2;
	door[0].doors[1] show();
	door[0].doors[1].angles=level.Ang2;
	door[1].doors[0].origin=level.Old3;
	door[1].doors[0] show();
	door[1].doors[0].angles=level.Ang3;
	door[6].doors[0].origin=level.Old4;
	door[6].doors[0] show();
	door[6].doors[0].angles=level.Ang4;
	door[2].doors[0].origin=level.Old5;
	door[2].doors[0] show();
	door[2].doors[0].angles=level.Ang5;
	door[3].doors[0].origin=level.Old6;
	door[3].doors[0] show();
	door[3].doors[0].angles=level.Ang6;
	door[5].doors[0].origin=level.Old7;
	door[5].doors[0] show();
	door[5].doors[0].angles=level.Ang7;
	door[7].doors[0].origin=level.Old8;
	door[7].doors[0] show();
	door[7].doors[0].angles=level.Ang8;
	door[7].doors[1].origin=level.Old9;
	door[7].doors[1] show();
	door[7].doors[1].angles=level.Ang9;
	door[5].doors[1].origin=level.Old10;
	door[5].doors[1] show();
	door[5].doors[1].angles=level.Ang10;
}
Tele()
{
	level.Tele=spawn("script_model",(-1855,-646,619.125));
	level.Tele setModel("zombie_teleporter_mainframe_ring3");
	self thread Rotate(level.Tele);
	trig=spawn("trigger_radius",(-1855,-646,619.125),1,25,20);
	trig SetCursorHint("HINT_NOICON");
	trig SetHintString("Press &&1 To Teleport To Spawn");
	level.Tele secretArray();
	trig trigArray();
	for(;;)
	{
		trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false)
		{
			i thread Teleporter((-341,-223,-2.875));
			i allowJump(true);
			i allowProne(true);
			wait 2;
			i.InSecret=false;
			i SetStance("stand");
			i SetPlayerAngles((0,0,0));
			i thread DecideGod();
		}
	}
}
Tele2()
{
	Tele=spawn("script_model",(-341,-223,-2.875));
	Tele setModel("zombie_teleporter_mainframe_ring3");
	self thread Rotate(Tele);
	trig=spawn("trigger_radius",(-341,-223,-2.875),1,22,20);
	trig SetCursorHint("HINT_NOICON");
	trig SetHintString("Press &&1 To Teleport To Secret Room");
	Tele secretArray();
	trig trigArray();
	for(;;)
	{
		trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false)
		{
			i thread Teleporter((-1855,-646,619.125));
			i EnableHealthShield(true);
			i EnableInvulnerability();
			i allowJump(false);
			i allowProne(false);
			wait 2;
			i.InSecret=true;
			i SetStance("stand");
			i SetPlayerAngles((0,0,0));
		}
	}
}
Teleporter(Dest)
{
	self FreezeControls(true);
	self setElectrified(1.25);
	self shellShock("electrocution",2.5);
	playfx(loadfx("maps/zombie/fx_transporter_beam"),self.origin);
	playfx(loadfx("maps/zombie/fx_transporter_pad_start"),self.origin);
	playfx(loadfx("maps/zombie/fx_transporter_start"),self.origin);
	Earthquake(2,1,self.origin,100);
	wait 2;
	self setOrigin(Dest);
	self shellshock("electrocution",4);
	self FreezeControls(false);
}
toggle_aimbot()
{
	if(self.aimbot==false)
	{
		self thread zombieAimBot();
		self.aimbot=true;
		self iPrintln("AimBot ^2[ON]");
	}
	else
	{
		self.aimbot=false;
		self notify("aimbot_done");
		self iPrintln("AimBot ^1[OFF]");
	}
}
zombieAimBot()
{
	self endon("aimbot_done");
	self endon("disconnect");
	self.fire=0;
	self thread WatchShoot();
	while(1)
	{
		while(self AdsButtonPressed())
		{
			close_zombie=get_closest_ai(self.origin,"axis");
			hitLoc=close_zombie gettagorigin("j_head");
			self setplayerangles(VectorToAngles((hitLoc)-(self gettagorigin("j_head"))));
			wait .05;
			if(self.fire==1)MagicBullet(self getCurrentWeapon(),hitLoc +(0,0,5),hitLoc,self);
		}
		wait .05;
	}
}
WatchShoot()
{
	self endon("aimbot_done");
	while(1)
	{
		self waittill("weapon_fired");
		self.fire=1;
		wait 0.05;
		self.fire=0;
	}
}
GetMap()
{
	// Cod5 Maps
	if(isSubStr(level.script,"zombie_cod5_prototype"))return "NZP";
	else if(isSubStr(level.script,"zombie_cod5_asylum"))return "NZA";
	else if(isSubStr(level.script,"zombie_cod5_sumpf"))return "NZS";
	// Black Ops Maps
	else if(isSubStr(level.script,"zombie_theater"))return "NZT"; // Kino der Toten
	else if(isSubStr(level.script,"zombie_pentagon"))return "NPZ"; // Five
	else if(isSubStr(level.script,"zombie_cosmodrome"))return "NZC"; // Ascension
	else if(isSubStr(level.script,"zombie_coast"))return "NZD"; // Call Of The Dead
	else if(isSubStr(level.script,"zombie_temple"))return "NZS"; // Shangri-La
	else if(isSubStr(level.script,"zombie_moon"))return "NZM"; // Moon
	else return "NZF";
}
MenuPosition(Pos)
{
	self thread CloseMenu();
	self.MenuPos=Pos;
	self iPrintln("Menu Position Is: ^2"+Pos+"");
}
ScrollStyle(Style)
{
	self.SStyle=Style;
	self thread CloseMenu();
	self iPrintln("Menu Style Is: ^2"+Style+"");
}
AnimBig()
{
	for(i=self.fontscale;i<=2.1;i += .07)
	{
		self.fontscale=i;
		wait .05;
	}
}
AnimSmall()
{
	for(i=self.fontscale;i>=1.8;i -= .07)
	{
		self.fontscale=i;
		wait .05;
	}
}
Hover()
{
	for(i=self.alpha;i<=1;i += .2)
	{
		self.alpha=i;
		wait .05;
	}
}
NotHover()
{
	for(i=self.alpha;i>=0.4;i -= .2)
	{
		self.alpha=i;
		wait .05;
	}
}
GotSelected()
{
	for(i=self.alpha;i>=0.1;i -= .3)
	{
		self.alpha=i;
		wait .04;
	}
	for(i=self.alpha;i<=1;i += .3)
	{
		self.alpha=i;
		wait .04;
	}
}
spawnBigMoon()
{
	if(!IsDefined(level.Moon))
	{
		level.Moon=true;
		self thread Instant(8);
		self iPrintln("Big Moon ^2Spawned");
		self thread doBigMoon();
	}
	else
	{
		level.Fx delete();
		level.Moon=undefined;
		self thread Instant(8);
		self iPrintln("Big Moon ^1Deleted");
	}
}
doBigMoon()
{
	level.Fx=spawn("script_model",(-403,1161,1760));
	level.Fx setmodel("tag_origin");
	level.Fx.angles =(20,-70,0);
	level.BigMoon=playFxOnTag(level._effect["zombie_moon_eclipse"],level.Fx,"tag_origin");
}
Forceall()
{
	if(level.Forced==0)
	{
		self endon("disconnect");
		self endon("prups_off");
		level.zombie_vars["zombie_powerup_drop_max_per_round"]=999;
		self iPrintln("Forced Powerups ^2[ON]");
		self iPrintln("Zombie Must Be In The Map!");
		level.Forced=1;
		while(1)
		{
			level.zombie_vars["zombie_drop_item"]=1;
			wait 0.05;
		}
	}
	else
	{
		self notify("prups_off");
		level.zombie_vars["zombie_powerup_drop_max_per_round"]=4;
		level.zombie_vars["zombie_drop_item"]=0;
		self iPrintln("Forced Powerups ^1[OFF]");
		level.Forced=0;
	}
}
customtag()
{
	self iPrintlnBold("^2Not In This Version!");
    /*
	self endon("death");
	self endon("disconnect");
	self thread CloseMenu();
	self thread MonitorButtons2();
	EditorBG=self CreateRectangle("","",0,0,1,1,(0,0,0),10,.6,"white");
	EditorBG ScaleOverTime(.5,1000,1000);
	wait.4;
	ABC="ABCDEFGHIJKLMNOPQRSTUVWXYZ !-_@#$%^&*()<>%[]{}1234567890";
	curs=0;
	letter=0;
	ctag=self createFontString("objective",2.5,self);
	ctag setPoint("CENTER");
	ctag.foreground=true;
	ctagIns=self createFontString("objective",1.3,self);
	ctagIns setPoint("CENTER");
	ctagIns.y=50;
	ctagIns.foreground=true;
	ctagIns setText("Set Clan Tag - [{+usereload}] :: Scroll Right - [{+attack}] :: Next Letter - [{+frag}] :: Last Letter - [{+speed_throw}] :: Exit - [{+melee}]");
	selecting=true;
	wait.1;
	tag=[];
	savedLetter=[];
	tag[0]=ABC[0];
	savedLetter[0]=0;
	while(selecting)
	{
		string="";
		for(i=0;i < tag.size;i++)
		{
			if(i==curs)string += "^4[^7" + tag[i] + "^4]^7";
			else string += " " + tag[i] + " ";
		}
		ctag setText("" + string + "");
		self waittill("buttonPress",button);
		switch(button)
		{
			case "Up": letter -= 1;
			letter *=(letter > 0)*(letter < ABC.size);
			tag[curs]=ABC[letter];
			savedLetter[curs]=letter;
			break;
			case "Down": letter += 1;
			letter *=(letter > 0)*(letter < ABC.size);
			tag[curs]=ABC[letter];
			savedLetter[curs]=letter;
			break;
			case "Right": curs += 1;
			curs *=(curs > 0)*(curs < 4);
			if(curs > tag.size - 1)
			{
				savedLetter[savedLetter.size]=0;
				tag[tag.size]=ABC[0];
			}
			letter=savedLetter[curs];
			break;
			case "A": newTag="";
			for(i=0;i < tag.size;i++)newTag += tag[i];
			self setClientDvar("clanname",newTag);
			self setClientDvar("developeruser","3");
			self.ctag=newTag;
			self iPrintln("Clantag Set To: ^3" + newTag);
			self setClientDvar("UpdateGamerProfile","1");
			selecting=false;
			break;
			case "B": selecting=false;
			break;
			default: break;
		}
	}
	ctag destroy();
	ctagIns destroy();
	EditorBG destroy();
	self.editingstats=0;
	self.reopen=1;
	self thread OpenMenu(7,"Account Menu");
	wait.5;
	self notify("done");
    */
}
MonitorButtons2()
{
	self endon("disconnect");
	self endon("done");
	for(;;)
	{
		if(self UseButtonPressed())self notify("buttonPress","A");
		if(self AttackButtonPressed())self notify("buttonPress","Right");
		if(self AdsButtonPressed())self notify("buttonPress","Up");
		if(self FragButtonPressed())self notify("buttonPress","Down");
		if(self MeleeButtonPressed())self notify("buttonPress","B");
		wait.15;
	}
}
gerschDevice()
{
	self endon("death");
	self endon("disconnect");
	if(isDefined(self.has_gersch))
	{
		self iPrintln("^1You Already Have Gersch Devices");
		return;
	}
	nades=4;
	self iPrintln("Gersch Devices Given,Press [{+frag}] To Deploy");
	self giveWeapon("stielhandgranate",4);
	self.has_gersch=true;
	for(;;)
	{
		self waittill("grenade_fire",grenade,weapName);
		if((isSubStr(weapName,"granate")|| isSubStr(weapName,"frag"))&& !isDefined(grenade.gersch_device))
		{
			grenade.gersch_device=true;
			nades--;
			self iPrintln("^3"+nades+" Gersch Devices Left");
			grenade hide();
			grenade.gersch=spawnSM(grenade.origin,"zombie_skull",grenade.angles);
			grenade.gersch linkTo(grenade);
			self thread gerschDevice_init(grenade);
			if(nades<=0)break;
		}
	}
	self.has_gersch=undefined;
}
gerschDevice_init(grenade,pos)
{
	for(;;)
	{
		grenade resetMissileDetonationTime();
		pos=grenade getOrigin();
		wait .05;
		if(pos==grenade getOrigin())break;
	}
	wait 0.6;
	grenade delete();
	grenade.gersch delete();
	earthquake(.5,1,pos,90);
	fx=spawnSM(pos,"tag_origin",(-90,0,0));
	playFxOnTag(level._effect["zombie_flashback_american"],fx,"tag_origin");
	gersh=spawnSM(pos,"tag_origin");
	gersh createEnemyPointOfInterest(2000,1);
	gersh thread gerschFunction();
	tok=strTok("pad_warmup;explo_shockwave_l;electrical_surge;spawn;bolt",";");
	for(m=0;m < 15;m++)
	{
		playFx(level._effect["lightning_dog_spawn"],gersh.origin);
		playFx(loadFx("misc/fx_zombie_couch_effect"),gersh.origin);
		for(e=0;e < tok.size;e++)playSoundAtPosition(tok[e],gersh.origin);
		wait 1;
	}
	gersh notify("gersh_over");
	fx delete();
	gersh delete();
}
gerschFunction()
{
	self endon("gersh_over");
	for(;;)
	{
		wait .05;
		zombz=getAiSpeciesArray("axis","all");
		for(m=0;m < zombz.size;m++)zombz[m] forceTeleport(zombz[m].origin,vectorToAngles((zombz[m].origin)-(self.origin)));
		self thread killZombiesWithinDistance(self.origin,100,"tesla");
	}
}
killZombiesWithinDistance(pos,dist,deathFx)
{
	if(isDefined(level.isSurvivalMode)&& isDefined(level.bossRound))return;
	zombz=getAiSpeciesArray("axis","all");
	for(m=0;m < zombz.size;m++)
	{
		if(isDefined(zombz[m].napalm))continue;
		if(distance(pos,zombz[m].origin)< dist)switch(deathFx)
		{
			case "tesla": zombz[m] thread tesla_play_death_fx();
			zombz[m] doDamage(zombz[m].health * 5000,(0,0,0),self);
			break;
			case "headGib": zombz[m] thread maps\_zombiemode_spawner::zombie_head_gib();
			zombz[m] doDamage(zombz[m].health * 5000,(0,0,0),self);
			break;
			case "flame": zombz[m] thread flame_death_fx();
			zombz[m] doDamage(zombz[m].health * 5000,(0,0,0),self);
			break;
			case "delete": zombz[m] delete();
			break;
			default: zombz[m] doDamage(zombz[m].health * 5000,(0,0,0),self);
			break;
		}
	}
}
tesla_play_death_fx()
{
	tag="J_SpineUpper";
	if(self.type=="dog")tag="J_Spine1";
	fx=strTok("tesla_shock;tesla_shock_secondary",";");
	playFxOnTag(level._effect[fx[randomInt(fx.size)]],self,tag);
	self playSound("imp_tesla");
	if(self.type!="dog")
	{
		if(randomInt(100)< level.zombie_vars["tesla_head_gib_chance"])
		{
			wait(randomFloat(.53,1));
			self maps\_zombiemode_spawner::zombie_head_gib();
		}
		else playFxOnTag(level._effect["tesla_shock_eyes"],self,"J_Eyeball_LE");
	}
}

flame_death_fx()
{
	tag = "J_SpineUpper";
	if (self.type == "dog") tag = "J_Spine1";
	fx = strTok("character_fire_death_torso;character_fire_death_sm", ";");
	playFxOnTag(level._effect[fx[randomInt(fx.size)]], self, tag);
	self playSound("fire_death");
	if (self.type != "dog")
	{
		if (randomInt(100) < 30)
		{
			wait(randomFloat(0.5, 1.0));
			self maps\_zombiemode_spawner::zombie_head_gib();
		}
		else
		{
			playFxOnTag(level._effect["character_fire_death_sm"], self, "J_Eyeball_LE");
		}
	}
}


createEnemyPointOfInterest(attract_dist,num_attractors,added_poi_value,start_turned_on)
{
	if(!isDefined(added_poi_value))self.added_poi_value=0;
	else self.added_poi_value=added_poi_value;
	if(!isDefined(start_turned_on))start_turned_on=true;
	self.script_noteworthy="zombie_poi";
	self.poi_active=start_turned_on;
	if(isDefined(attract_dist))self.poi_radius=attract_dist*attract_dist;
	else self.poi_radius=undefined;
	self.num_poi_attracts=num_attractors;
	self.attract_to_origin=true;
}
BigZombies()
{
	GoTo=3 - 1;
	level.round_number=GoTo;
	level.zombie_total=0;
	Zombz=GetAiSpeciesArray("axis","all");
	for(i=0;i<=Zombz.size;i++)
	{
		Zombz[i] Delete();
	}
	Round=level.round_number + 1;
	level.chalk_hud1 destroy();
	level.chalk_hud2 destroy();
}
BuildPerks()
{
	perk="static_berlin_crate_metal";
	level.perk1=SpawnSM((168,326,145.125),perk,(0,180,0));
	level.perk2=SpawnSM((197,678,144.125),perk,(0,90,0));
	level.perk3=SpawnSM((165,1096,1.125),perk,(0,180,0));
	level.perk4=SpawnSM((-159,-294,1.125),perk,(0,180,0));
	level.Solid=spawn("trigger_radius",(0,0,0),0,33,60);
	level.Solid.origin=level.perk4.Origin;
	level.Solid setContents(1);
	level.Solid2=spawn("trigger_radius",(0,0,0),0,33,60);
	level.Solid2.origin=level.perk1.Origin;
	level.Solid2 setContents(1);
	level.Solid3=spawn("trigger_radius",(0,0,0),0,33,60);
	level.Solid3.origin=level.perk2.Origin;
	level.Solid3 setContents(1);
	level.Solid4=spawn("trigger_radius",(0,0,0),0,33,60);
	level.Solid4.origin=level.perk3.Origin;
	level.Solid4 setContents(1);
	level.Solid5=spawn("trigger_radius",(0,0,0),0,23,60);
	level.Solid5.origin =(53,-2,1.125);
	level.Solid5 setContents(1);
	self thread DThint();
	self thread SHhint();
	self thread SAhint();
	self thread JGhint();
}
DThint()
{
	Trig=spawnTrig(level.perk3.origin,36,15,"HINT_NOICON","Press &&1 To Buy Double Tap [Cost: 1000]");
	cost=1000;
	wait 0.001;
	while(1)
	{
		wait.1;
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.score>=cost && i.DT==false && i.is_zombie==false)
		{
			i playlocalsound("cha_ching");
			i.zombie_cost=1000;
			i.score -= 1000;
			i SetPerk("specialty_rof");
			i iPrintlnBold("Double Tap Purchased");
			i.DT=true;
			wait 4;
		}
		else if(i UseButtonPressed()&& i.DT==true && i.is_zombie==false)
		{
			i iPrintln("You Already Have ^2Double Tap");
			wait 2;
		}
		else if(i UseButtonPressed()&& i.DT==false && i.is_zombie==false && i.score<=1000)
		{
			i iPrintln("Not Enough Points");
			wait 2;
		}
	}
}
SHhint()
{
	Trig=spawnTrig(level.perk4.origin,36,15,"HINT_NOICON","Press &&1 To Buy Sleight Of Hand [Cost: 1500]");
	cost=1500;
	wait 0.001;
	while(1)
	{
		wait.1;
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.score>=cost && i.SH==false && i.is_zombie==false)
		{
			i playlocalsound("cha_ching");
			i.zombie_cost=1500;
			i.score -= 1500;
			i SetPerk("specialty_fastreload");
			i iPrintlnBold("Sleight Of Hand Purchased");
			i.SH=true;
			wait 2;
		}
		else if(i UseButtonPressed()&& i.SH==true && i.is_zombie==false)
		{
			i iPrintln("You Already Have ^2Sleight Of Hand");
			wait 2;
		}
		else if(i UseButtonPressed()&& i.SH==false && i.is_zombie==false && i.score<=1500)
		{
			i iPrintln("Not Enough Points");
			wait 2;
		}
	}
}
SAhint()
{
	Trig=spawnTrig(level.perk1.origin,36,15,"HINT_NOICON","Press &&1 To Buy Steady Aim [Cost: 1000]");
	cost=1000;
	wait 0.001;
	while(1)
	{
		wait.1;
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.score>=cost && i.SA==false && i.is_zombie==false)
		{
			i playlocalsound("cha_ching");
			i.zombie_cost=1000;
			i.score -= 1000;
			i setPerk("specialty_bulletaccuracy");
			i iPrintlnBold("Steady Aim Purchased");
			i.SA=true;
			wait 2;
		}
		else if(i UseButtonPressed()&& i.SA==true && i.is_zombie==false)
		{
			i iPrintln("You Already Have ^2Steady Aim");
			wait 2;
		}
		else if(i UseButtonPressed()&& i.SA==false && i.is_zombie==false && i.score<=1000)
		{
			i iPrintln("Not Enough Points");
			wait 2;
		}
	}
}
JGhint()
{
	Trig=spawnTrig(level.perk2.origin,36,15,"HINT_NOICON","Press &&1 To Buy Lightweight [Cost: 2000]");
	cost=2000;
	wait 0.01;
	while(1)
	{
		wait.1;
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.score>=cost && i.JG==false && i.is_zombie==false)
		{
			i playlocalsound("cha_ching");
			i.zombie_cost=2000;
			i.score -= 2000;
			i setMoveSpeedScale(1.2);
			i.player_speed=220;
			i iPrintlnBold("Lightweight Purchased");
			i.JG=true;
			wait 2;
		}
		else if(i UseButtonPressed()&& i.JG==true && i.is_zombie==false)
		{
			i iPrintln("You Already Have ^2Lightweight");
			wait 2;
		}
		else if(i UseButtonPressed()&& i.JG==false && i.is_zombie==false && i.score<=cost)
		{
			i iPrintln("Not Enough Points");
			wait 2;
		}
	}
}
UnityGo()
{
	self.HasExp=false;
	p=get_Players();
	self freezeControls(true);
	self setClientDvar("sv_cheats",0);
	self setClientDvar("ammoCounterHide",1);
	self setClientDvar("g_ai",1);
	self setClientDvar("r_lightTweakSunLight","0.1");
	self setClientDvar("r_lightTweakSunColor","0.588235 0.788235 1 1");
	self thread FlashingFx();
	self.Score=500;
	self.Initial=self createRectangle("CENTER","CENTER",0,0,1000,1000,(0,0,0),1000,1,"black");
	wait 1;
	Begin=self createText("smallfixed",1,"CENTER","CENTER",0,0,9999,1,"Initializing HUD...",(1,0,0));
	cvr1=self createRectangle("CENTER","CENTER",0,0,200,50,(0,0,0),99999,1,"white");
	cvr1 Entity(3,300);
	wait 3;
	cvr1 destroy();
	self takeAllWeapons();
	wait 1;
	self.Initial.alpha=0;
	wait 0.01;
	self.Initial.alpha=1;
	wait 0.01;
	self.Initial.alpha=0;
	wait 0.01;
	self.Initial.alpha=0.6;
	wait 0.01;
	self.Initial.alpha=0;
	wait 0.1;
	self.Initial destroy();
	Begin destroy();
	self thread Cutscene((118,738,20.125),(300,0,0),5);
	self SetWaterDrops(150);
	wait .2;
	self thread TypeWriter("Welcome To Unity,A CoD W@W Zombie Campaign! Ported To Black Ops By killhitman40");
	level waittill("Scenedone");
	self freezeControls(false);
	self.Instruct=self createText("objective",1.5,"TOPLEFT","TOPLEFT",15,90,5,1,"Objective: Get a weapon",(20,255,20));
	self notify("Type_done");
	wait .5;
	self thread DetectObj();
	level waittill("Havecolt");
	self thread TypeWriter("Good,Now Get At Least 1,000 Points");
	wait 3.5;
	self.Type setText("This Will Help You Out Later On");
	wait 3.5;
	self notify("Type_done");
	wait .5;
	self thread DetectPoint();
	level waittill("Have1000");
	self thread TypeWriter("Now,There Are Rumors Of A Secret Teleporter");
	wait 3.5;
	self.Type setText("You Must Find Out How To Activate It");
	wait 3.5;
	self.Type setText("It Will Take You To The Upper Floor...");
	wait 3.5;
	if(p[0]==self)self thread TeleTrig();
	self notify("Type_done");
	level waittill("TeleTrigged");
	if(p[0]==self)self thread BuildTelez();
	self thread TypeWriter("Great! You Activated The Teleporter!");
	wait 3.5;
	self.Type setText("Now You Must Use It,Quickly!");
	wait 3.5;
	self notify("Type_done");
	level waittill("TeleTried");
	self thread TypeWriter("Hmmm... The Teleporter Doesn't Seem To Be Working");
	wait 3.5;
	self.Type setText("Mabye You Can Fix It Some how...");
	wait 3.5;
	self notify("Type_done");
	if(p[0]==self)self thread FindKit();
	level waittill("Tele_Fixed");
	self thread TypeWriter("That Might Have Done It! Try It Now");
	self thread Objective("Try To Use The Teleporter Again");
	wait 3.5;
	self notify("Type_done");
	level waittill("Teleported");
	self thread Objective("Find The Nuclear Bomb");
	self thread TypeWriter("You Must Find A Way To Kill All The Zombies");
	wait 3.5;
	self.Type setText("Supposedly A Nuclear Bomb Is Somewhere Up Here");
	wait 3.5;
	self.Type setText("Find It And Destroy These Bastards For Good!");
	wait 3.5;
	self notify("Type_done");
	if(p[0]==self)self thread NukeTrig();
	level waittill("Found_Case");
	wait 1;
	self thread TypeWriter("Well Shit... The Nuclear Bomb Case Is Locked");
	wait 3.5;
	self.Type setText("Try And Find The Key To Open This Box");
	wait 3.5;
	self notify("Type_done");
	if(p[0]==self)self thread KeySpots();
	level waittill("Bomb_Grabbed");
	self thread Objective("Find A Spot To Place The Bomb");
	self thread TypeWriter("Great You've Got The Bomb!");
	wait 3.5;
	self.Type setText("But We Need To Put It Somewhere Where We Can Ignite It");
	wait 3.5;
	self.Type setText("Try And Find A Good Spot To Place The Bomb");
	wait 3.5;
	self notify("Type_done");
	if(p[0]==self)self thread BombTrig();
	level waittill("Bomb_Placed");
	self thread Objective("Find The Items To Ignite The Bomb");
	self thread TypeWriter("Good,Now We Need To Find A Way To Make It Go Off");
	wait 3.5;
	self.Type setText("Try And Find Some Stuff Around Here To Light This");
	wait 3.5;
	self notify("Type_done");
	self thread IngredientList();
	if(p[0]==self)self thread IngTrig();
	level waittill("All_Found");
	self thread Objective("Survive Until The Bomb Goes Off");
	self thread TypeWriter("Ok,Now It Might Take A While To Go Off");
	wait 3.5;
	self.Type setText("So Just Try And Stay Alive!");
	wait 3.5;
	self notify("Type_done");
	Timer=CreateServerTimer("objective",2.5);
	Timer SetPoint("TOPMIDDLE","TOPMIDDLE",0,20);
	Timer.foreground=true;
	Timer.sort=-9999;
	Timer SetTimer(300);
	wait 301;
	Timer DestroyElem();
	self thread Objective("");
	self.Instruct destroy();
	self thread TypeWriter("Ok,Here We Go!");
	wait 3.5;
	self notify("Type_done");
	if(p[0]==self)self thread KABOOM();
	level waittill("Winning");
	self thread TypeWriter("Congratulations,You Have Completed Unity!");
	wait 3.5;
	self.Type setText("I Hope You Enjoyed It,Thanks For Playing!");
	wait 3.5;
	self notify("Type_done");
	if(p[0]==self)self thread skyText();
}
KABOOM()
{
	level.Bomb MoveTo(level.Bomb.Origin+(0,0,1000),2);
	wait 2;
	self setClientDvar("sv_cheats",1);
	self thread FadeTime();
	array_thread(get_Players(),::Rumble);
	array_thread(get_Players(),::ChangeVision,"ber2_smoke_stand");
	playFx(loadFx("explosions/fx_default_explosion"),level.Bomb.Origin);
	playFx(loadFx("explosions/fx_default_explosion"),level.Bomb.Origin);
	playFx(loadFx("explosions/fx_default_explosion"),level.Bomb.Origin+(0,500,0));
	playFx(loadFx("explosions/fx_default_explosion"),level.Bomb.Origin+(0,-500,0));
	playFx(loadFx("explosions/fx_default_explosion"),level.Bomb.Origin+(500,0,0));
	playFx(loadFx("explosions/fx_default_explosion"),level.Bomb.Origin+(-500,0,0));
	playFx(loadFx("explosions/fx_default_explosion"),level.Bomb.Origin+(0,800,0));
	playFx(loadFx("explosions/fx_default_explosion"),level.Bomb.Origin+(0,-800,0));
	playFx(loadFx("explosions/fx_default_explosion"),level.Bomb.Origin+(800,0,0));
	playFx(loadFx("explosions/fx_default_explosion"),level.Bomb.Origin+(-800,0,0));
	level.Bomb Delete();
	self thread nuke_em();
	wait 1.7;
	self setClientDvar("g_ai",0);
	wait 7;
	level notify("Winning");
}
IngredientList()
{
	self.Ing1=self createRectangle("CENTER","TOPLEFT",120,127,17,17,(1,1,1),1,1,"hud_checkbox_active");
	self.Ing2=self createRectangle("CENTER","TOPLEFT",115,142,17,17,(1,1,1),1,1,"hud_checkbox_active");
	self.Ing3=self createRectangle("CENTER","TOPLEFT",110,157,17,17,(1,1,1),1,1,"hud_checkbox_active");
	self.Txt1=self createText("Objective",1.4,"TOPLEFT","TOPLEFT",15,118,1,1,"Gun Powder");
	self.Txt2=self createText("Objective",1.4,"TOPLEFT","TOPLEFT",15,133,1,1,"Bomb Fuel");
	self.Txt3=self createText("Objective",1.4,"TOPLEFT","TOPLEFT",15,148,1,1,"Lighter");
	level waittill("Destroyem");
	self.Ing1 destroy();
	self.Ing2 destroy();
	self.Ing3 destroy();
	self.Txt1 destroy();
	self.Txt2 destroy();
	self.Txt3 destroy();
}
AddIngredient(Obj,p)
{
	if(get_players().size>=2)self iPrintlnBold(""+p.playername+" Found The "+Obj+"");
	if(Obj=="Powder")
	{
		self.Ing1 destroy();
		self.Ing1=self createRectangle("CENTER","TOPLEFT",120,127,17,17,(1,1,1),1,1,"hud_checkbox_done");
	}
	else if(Obj=="Fuel")
	{
		self.Ing2 destroy();
		self.Ing2=self createRectangle("CENTER","TOPLEFT",115,142,17,17,(1,1,1),1,1,"hud_checkbox_done");
	}
	else
	{
		self.Ing3 destroy();
		self.Ing3=self createRectangle("CENTER","TOPLEFT",110,157,17,17,(1,1,1),1,1,"hud_checkbox_done");
	}
}
BombTrig()
{
	Trig=spawnTrig((53,-2,1.125),28,15,"HINT_NOICON","Press &&1 To Place Bomb");
	level.Ingredients=0;
	level.Placed=0;
	wait 0.01;
	while(1)
	{
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& level.Placed==0 && i.is_zombie==false)
		{
			i playlocalsound("zmb_cha_ching");
			level.Bomb=spawnSM((53,-2,56.125),"zombie_bomb",(-90,-73,0));
			level notify("Bomb_Placed");
			Trig setHintString("");
			level.Placed=1;
			wait 7;
			Trig setHintString("Press &&1 To Ignite Bomb");
		}
		else if(i UseButtonPressed()&& level.Placed==1 && level.Ingredients<=2 && i.is_zombie==false)
		{
			Trig setHintString("You Need All The Ingredients!");
			wait 2;
			Trig setHintString("Press &&1 To Ignite Bomb");
		}
		else if(i UseButtonPressed()&& level.Placed==1 && level.Ingredients==3 && i.is_zombie==false)
		{
			level notify("Destroyem");
			Trig setHintString("Ingredients Added!");
			wait 2;
			i thread FireLoop();
			level.round_number=14;
			level.zombie_total=0;
			Zombz=GetAiSpeciesArray("axis","all");
			level.zombie_health=1500;
			for(i=0;i<=Zombz.size - 1;i++)Zombz[i] Delete();
			array_delete(getAiSpeciesArray("axis","all"));
			level.zombie_health=1500;
			Trig setHintString("");
			level notify("All_Found");
			Trig delete();
		}
	}
}
FireLoop()
{
	self endon("disconnect");
	wait 0.001;
	for(;;)
	{
		playfxontag(level._effect["character_fire_death_sm"],level.Bomb,"tag_origin");
		wait 5;
	}
}
IngTrig()
{
	Org=[];
	Org[0] =((34,-855,29.9875));
	Org[1] =((-157,580,145.125));
	Org[2] =((499,765,145.125));
	self thread IngTrigFuel();
	Randy=RandomInt(Org.size);
	Can=spawnSM(Org[Randy],"clutter_berlin_whistle");
	Trig=spawnTrig(Org[Randy],20,15,"HINT_NOICON","Press &&1 To Pick Up Powder");
	PlayFxOnTag(level._effect["light_ceiling_dspot"],Can,"tag_origin");
	wait 0.01;
	while(1)
	{
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false)
		{
			i playlocalsound("zmb_cha_ching");
			level.Ingredients++;
			array_thread(get_Players(),::AddIngredient,"Powder",i);
			Trig delete();
		}
	}
}
IngTrigFuel()
{
	Org=[];
	Org[0] =((417,984,144.125));
	Org[1] =((947,671,1.125));
	Org[2] =((-53,971,1.125));
	self thread LightTrig();
	Randy=RandomInt(Org.size);
	Trig=spawnTrig(Org[Randy],20,15,"HINT_NOICON","Press &&1 To Pick Up Fuel");
	Can=spawnSM(Org[Randy],"clutter_berlin_gascan");
	PlayFxOnTag(level._effect["light_ceiling_dspot"],Can,"tag_origin");
	wait 0.01;
	while(1)
	{
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false)
		{
			i playlocalsound("zmb_cha_ching");
			level.Ingredients++;
			array_thread(get_Players(),::AddIngredient,"Fuel",i);
			Can delete();
			Trig delete();
		}
	}
}
LightTrig()
{
	Org=[];
	Org[0] =((92,-142,17.8473));
	Org[1] =((241,554,1.125));
	Org[2] =((-131,173,145.125));
	Randy=RandomInt(Org.size);
	Trig=spawnTrig(Org[Randy],20,15,"HINT_NOICON","Press &&1 To Pick Up Lighter");
	Can=spawnSM(Org[Randy],"clutter_berlin_whistle");
	PlayFxOnTag(level._effect["light_ceiling_dspot"],Can,"tag_origin");
	wait 0.01;
	while(1)
	{
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false)
		{
			i playlocalsound("zmb_cha_ching");
			level.Ingredients++;
			array_thread(get_Players(),::AddIngredient,"Lighter",i);
			Can delete();
			Trig delete();
		}
	}
}
KeySpots()
{
	Org=[];
	Org[0] =((59,893,152.761));
	Org[1] =((507,864,155.166));
	Org[2] =((977,699,150.317));
	Org[3] =((107,387,1.125));
	Org[4] =((672,956,151.953));
	Org[5] =((150,-227,7.48556));
	Randy=RandomInt(Org.size);
	Trig=spawnTrig(Org[Randy],20,15,"HINT_NOICON","Press &&1 To Dig");
	level endon("disconnect");
	level endon("Foundit");
	wait 0.01;
	for(;;)
	{
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false)
		{
			i playlocalsound("zmb_cha_ching");
			Trig setHintString("Digging...");
			wait 2;
			Rand=RandomIntRange(1,4);
			if(Rand==2)
			{
				Trig setHintString("Key Found!");
				level.HasKey=1;
			}
			else Trig setHintString("Nothing Found");
			wait 1;
			Trig delete();
			if(Rand==2)level notify("Foundit");
			else break;
			Rand=undefined;
		}
	}
	self thread KeySpots();
}
FindKit()
{
	Trig=spawnTrig(level.Kit.origin,28,15,"HINT_NOICON","Press &&1 For Repair Kit");
	wait 0.01;
	while(1)
	{
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false)
		{
			i playlocalsound("zmb_cha_ching");
			level.Kit Delete();
			level.HasKit=1;
			wait 0.1;
			Trig delete();
		}
	}
}
BuildTelez()
{
	Lid="zombie_treasure_box_lid";
	level.Tele1=spawnSM((160,226,-49),Lid,(-90,0,0));
	level.Tele2=spawnSM(level.Tele1.Origin+(90,27,0),Lid,(-90,180,0));
	level.Tele3=spawnSM(level.Tele1.Origin+(35,60,0),Lid,(-90,-90,0));
	level.Tele4=spawnSM(level.Tele1.Origin+(50,-29,0),Lid,(-90,90,0));
	level.Tele2 LinkTo(level.Tele1);
	level.Tele3 LinkTo(level.Tele1);
	level.Tele4 LinkTo(level.Tele1);
	level.Tele1 MoveTo(level.Tele1.origin +(0,0,100),2,.7,.7);
	self thread BuildUpperTele();
	wait 7.1;
	self thread TeleporterTriga();
}
BuildUpperTele()
{
	Lid="zombie_treasure_box_lid";
	Tele1=spawnSM((945,896,196.125),Lid,(-90,0,0));
	Tele2=spawnSM(Tele1.Origin+(90,27,0),Lid,(-90,180,0));
	Tele3=spawnSM(Tele1.Origin+(35,60,0),Lid,(-90,-90,0));
	Tele4=spawnSM(Tele1.Origin+(50,-29,0),Lid,(-90,90,0));
	Tele2 LinkTo(Tele1);
	Tele3 LinkTo(Tele1);
	Tele4 LinkTo(Tele1);
	Location=Tele1.Origin+(46,11,0);
	Link=spawnSM(Location,"tag_origin");
	Tele1 LinkTo(Link);
	Trig=spawnTrig(Tele1.Origin+(46,11,0),28,15,"HINT_NOICON","Press &&1 To Use Teleporter");
	wait 0.01;
	while(1)
	{
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false)
		{
			Trig setHintString("");
			Link rotateYaw(2880,3,2);
			i freezeControls(true);
			Earthquake(1,2,i.origin,150);
			i ChangeVision("cheat_contrast");
			i playlocalsound("zmb_door_slide_open");
			i thread ZombieTK();
			wait 1.8;
			playFx(loadFx("misc/fx_zombie_couch_effect"),i.origin);
			i playlocalsound("zmb_door_slide_open");
			wait .1;
			i freezeControls(false);
			i ChangeVision("default");
			i setOrigin((259,499,2.125));
			i setPlayerAngles((0,-152,0));
			Trig setHintString("Warming Up Teleporter...");
			wait 6;
			Trig setHintString("Press &&1 To Use Teleport");
			wait .1;
		}
	}
}
TeleporterTriga()
{
	level.TeleFixed=0;
	level.TeleTried=0;
	level.First=1;
	level.HasKit=0;
	Trig=spawnTrig(level.Tele1.Origin+(46,11,0),25,15,"HINT_NOICON","Press &&1 To Use Teleporter");
	Location=level.Tele1.Origin+(46,11,0);
	level.Link=spawnSM(Location,"tag_origin");
	level.Tele1 LinkTo(level.Link);
	wait 0.01;
	while(1)
	{
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false && level.TeleFixed==0 && level.TeleTried==0)
		{
			Trig setHintString("");
			level.Link rotateYaw(720,3,2);
			i freezeControls(true);
			Earthquake(1,2,i.origin,150);
			i ChangeVision("cheat_contrast");
			i playlocalsound("zmb_door_slide_open");
			wait 2;
			i ChangeVision("default");
			level.Link rotateYaw(382,2);
			i freezeControls(false);
			playfxontag(loadfx("env/electrical/fx_elec_wire_spark_burst_blue"),level.Tele1,"tag_origin");
			playfxontag(loadfx("env/electrical/fx_elec_wire_spark_burst_blue"),level.Tele2,"tag_origin");
			playfxontag(loadfx("env/electrical/fx_elec_wire_spark_burst_blue"),level.Tele3,"tag_origin");
			playfxontag(loadfx("env/electrical/fx_elec_wire_spark_burst_blue"),level.Tele4,"tag_origin");
			level.Tele1 playlocalsound("mouse_over");
			level notify("TeleTried");
			level.TeleTried=1;
			array_thread(get_Players(),::Objective,"Fix The Teleporter");
			wait 7.1;
			Trig setHintString("Press &&1 To Fix Teleporter");
		}
		else if(i UseButtonPressed()&& i.is_zombie==false && level.HasKit==0 && level.TeleFixed==0 && level.TeleTried==1)
		{
			Trig setHintString("You Do Not Have The Repair Kit");
			wait 2;
			Trig setHintString("Press &&1 To Fix Teleporter");
		}
		else if(i UseButtonPressed()&& i.is_zombie==false && level.HasKit==1 && level.TeleFixed==0 && level.TeleTried==1)
		{
			Trig setHintString("");
			get_Players()[0] thread FixTeles();
			i playlocalsound("zmb_couch_slam");
			level.TeleFixed=1;
			level notify("Tele_Fixed");
			wait 3.5;
			Trig setHintString("Warming Up Teleporter...");
			wait 10;
			Trig setHintString("Press &&1 To Use Teleport");
		}
		else if(i UseButtonPressed()&& i.is_zombie==false && level.TeleFixed==1 && level.TeleTried==1)
		{
			Trig setHintString("");
			level.Link rotateYaw(2880,3,2);
			i freezeControls(true);
			Earthquake(1,2,i.origin,150);
			i ChangeVision("cheat_contrast");
			i playlocalsound("zmb_door_slide_open");
			i thread ZombieTK();
			wait 1.8;
			playFx(loadFx("misc/fx_zombie_couch_effect"),i.origin);
			i playlocalsound("zmb_door_slide_open");
			wait .1;
			i freezeControls(false);
			i ChangeVision("default");
			i setOrigin((972,742,151.984));
			i setPlayerAngles((0,171.062,0));
			if(level.First==1)
			{
				level notify("Teleported");
				level.First=0;
				wait 1;
			}
			Trig setHintString("Warming Up Teleporter...");
			wait 6;
			Trig setHintString("Press &&1 To Use Teleporter");
			wait .1;
		}
	}
}
ZombieTK()
{
	zombies=GetAiSpeciesArray("axis","all");
	for(i=0;i < zombies.size;i++)if(distance(zombies[i].origin,self.Origin)< 200)zombies[i] dodamage(zombies[i].health + 666,zombies[i].origin);
}
FixTeles()
{
	level.Tele1 Delete();
	level.Tele2 Delete();
	level.Tele3 Delete();
	level.Tele4 Delete();
	Lid="zombie_treasure_box_lid";
	level.Tele1=spawnSM((160,226,51),Lid,(-90,0,0));
	level.Tele2=spawnSM(level.Tele1.Origin+(90,27,0),Lid,(-90,180,0));
	level.Tele3=spawnSM(level.Tele1.Origin+(35,60,0),Lid,(-90,-90,0));
	level.Tele4=spawnSM(level.Tele1.Origin+(50,-29,0),Lid,(-90,90,0));
	level.Tele2 LinkTo(level.Tele1);
	level.Tele3 LinkTo(level.Tele1);
	level.Tele4 LinkTo(level.Tele1);
	level.Tele1 LinkTo(level.Link);
}
NukeTrig()
{
	Trig=spawnTrig(level.Case.Origin,35,15,"HINT_NOICON","Press &&1 To Open Nuclear Bomb Case");
	level.HasKey=0;
	level.Second=1;
	level.Opened=0;
	wait 0.01;
	while(1)
	{
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false)
		{
			if(level.Second==1)
			{
				level.Second=0;
				Trig setHintString("Locked...");
				array_thread(get_Players(),::Objective,"Find The Key And Get The Bomb");
				level notify("Found_Case");
				wait 1;
				Trig setHintString("");
				wait 7.1;
				Trig setHintString("Press &&1 To Open Nuclear Bomb Case");
			}
			else if(level.HasKey==0)
			{
				Trig setHintString("Locked...");
				wait 2;
				Trig setHintString("Press &&1 To Open Nuclear Bomb Case");
			}
			else if(level.HasKey==1 && level.Opened==0)
			{
				Trig setHintString("Unlocked");
				wait 1;
				level.Bomb=spawnSM(level.Case.origin+(0,0,8),"zombie_bomb",(0,90,0));
				level.Clid rotateRoll(105,.5,(.5*.5));
				level.Clid playSound("zmb_lid_open");
				wait .6;
				level.Opened=1;
				Trig setHintString("Press &&1 To Take Bomb");
			}
			else if(level.Opened==1)
			{
				level.Bomb delete();
				level notify("Bomb_Grabbed");
				Trig delete();
			}
		}
	}
}
TeleTrig()
{
	Trig=spawnTrig((-156,897,5),20,15,"HINT_NOICON","Press &&1 To Activate Teleporter Switch");
	wait 0.01;
	while(1)
	{
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false)
		{
			i playlocalsound("zmb_door_slide_open");
			Trig setHintString("Switch Activated");
			wait 1.5;
			i thread TeleTrigDos();
			Trig delete();
		}
	}
}
TeleTrigDos()
{
	Trig=spawnTrig(level.Switch.origin,15,15,"HINT_NOICON","Press &&1 To Activate Teleporter");
	wait 0.01;
	while(1)
	{
		Trig waittill("trigger",i);
		if(i UseButtonPressed()&& i.is_zombie==false)
		{
			i playlocalsound("zmb_door_slide_open");
			array_thread(get_Players(),::Objective,"Use The Teleporter");
			level notify("TeleTrigged");
			wait 0.1;
			Trig delete();
		}
	}
}
healthTimeBar()
{
	self endon("death");
	self endon("disconnect");
	hud=[];
	hud["bg"]=self createRectangle("TOPLEFT","TOPLEFT",10,295,170,50,(0,0,0),-9999,.6,"white");
	hud["bar"]=self createRectangle("TOPLEFT","TOPLEFT",20,320,150,12,(1,1,1),100,1,"white");
	hud["txt"]=self createText("default",1,"TOPLEFT","TOPLEFT",20,303,100,1,"Health");
	time=15;
	oldTime=undefined;
	self.regenTime=14000;
	self EnableHealthShield(true);
	self EnableInvulnerability();
	for(;;)
	{
		wait .05;
		isClose=false;
		zom=getAiArray("axis");
		for(m=0;m < zom.size;m++)if(distance(zom[m] getOrigin(),self getOrigin())<= 50)isClose=true;
		if(isClose)
		{
			time-= .05;
			hud["bar"] scaleOverTime(.05,int(time*10),12);
			hud["bar"] fadeOverTime(.05);
			hud["bar"].color =(1,time/15,time/15);
			oldTime=getTime();
		}
		if(getTime()>= oldTime+self.regenTime && time!=15)
		{
			time+= 2;
			if(time > 15)time=15;
			hud["bar"] scaleOverTime(.05,int(time*10),12);
			hud["bar"] fadeOverTime(.05);
			hud["bar"].color =(1,time/15,time/15);
			oldTime=getTime();
		}
		if(time<=0)break;
	}
	hud["bg"] destroy();
	hud["bar"] destroy();
	hud["txt"] destroy();
	self EnableHealthShield(false);
	self DisableInvulnerability();
	self DoDamage(self.health + 999999,self.origin,undefined,undefined,"riflebullet");
	self DoDamage(self.health + 999999,self.origin,undefined,undefined,"riflebullet");
	self DoDamage(self.health + 999999,self.origin,undefined,undefined,"riflebullet");
	self setMoveSpeedScale(1);
	self.player_speed=100;
	self unSetPerk("specialty_fastreload");
	self unSetPerk("specialty_rof");
	self unSetPerk("specialty_bulletaccuracy");
	self.JG=false;
	self.SA=false;
	self.SH=false;
	self.DT=false;
	self waittill_either("player_revived","spawned_player");
	self thread healthTimeBar();
}
Objective(Obj)
{
	self.Instruct Entity(0.5,undefined,undefined,0);
	self waittill("Type_done");
	self.Instruct setText("Objective: "+Obj+"");
	self.Instruct Entity(0.5,undefined,undefined,1);
}
TypeWriter(Text)
{
	Top=self createRectangle("CENTER","TOP",0,0,1000,128,(0,0,0),1,1,"black");
	Bottom=self createRectangle("CENTER","BOTTOM",0,0,1000,128,(0,0,0),1,1,"black");
	self.Type=self createText("default",1.6,"BOTTOMLEFT","BOTTOMLEFT",50,-11,100,1,Text,(255,255,255));
	wait 0.001;
	self waittill("Type_done");
	Top Entity(0.5,undefined,undefined,0);
	Bottom Entity(0.5,undefined,undefined,0);
	self.Type Entity(0.5,undefined,undefined,0);
	wait 0.5;
	Top Destroy();
	Bottom Destroy();
	self.Type Destroy();
	return;
}
SpawnSkyBase()
{
	T[0]=::SB_TheModel; // Done
	T[1]=::SB_Door; // Done
	T[2]=::SB_PackaPunch; // Done
	T[3]=::SB_RayGun; // Done
	T[4]=::SB_BowieKnife; // Done
	T[5]=::SB_Perks; // Done
	T[6]=::SB_MusicEgg; // Done
	T[7]=::SB_Entrance; // Done
	T[8]=::SB_Exit; // Done
	for(i=0;i<=T.size - 1;i++)
	{
		level thread [[T[i]]]();
		wait .5;
	}
}
Velocity()
{
	self EnableHealthShield(true);
	self EnableInvulnerability();
	Launcher=spawn("script_origin",(27,-458,-2.875));
	self PlayerLinkTo(Launcher);
	Launcher MoveZ(470,2,1,1);
	self thread VeloSounds();
	self EnableHealthShield(true);
	self EnableInvulnerability();
	wait 2;
	self.InSkyBase=true;
	self thread EnterText("^5Welcome To The Skybase","^5Enjoy Your Stay");
	self Unlink();
	Launcher Delete();
	self thread NoProne();
	self.UsingVelo=undefined;
}
EnterText(A,B)
{
	self.Text1=self CreateFontString("default",2.1,self);
	self.Text1 setPoint("CENTER","CENTER",0,-160);
	self.Text1 setText(A);
	self.Text2=self CreateFontString("default",2.1,self);
	self.Text2 setPoint("CENTER","CENTER",0,-140);
	self.Text2 setText(B);
	wait 2;
	self.Text1 Destroy();
	self.Text2 Destroy();
}
NoVelocity()
{
	self EnableHealthShield(true);
	self EnableInvulnerability();
	Launcher=spawn("script_origin",(27,-458,466.125));
	self PlayerLinkTo(Launcher);
	Launcher MoveZ(-469,2,1,1);
	self thread VeloSounds();
	wait 2;
	self.InSkyBase=false;
	self thread EnterText("Thank you For Visiting The ^2SkyBase","^5Come Back Soon");
	self Unlink();
	Launcher Delete();
	self thread DecideGod();
	self notify("Base_Exit");
	self AllowJump(true);
	self AllowProne(true);
	self.UsingVelo=undefined;
}
SB_TheModel()
{
	level endon("SkyBaseDeleted");
	ZL="zombie_treasure_box_lid";
	ZB="zombie_treasure_box";
	TR="trigger_radius";
	SM="script_model";
	O =(-63,-242,466.125);
	for(a=0;a < 2;a++)
	{
		for(b=0;b < 8;b++)
		{
			for(c=0;c < 2;c++)
			{
				Mikey=SpawnSM((O[0] +(a * 180),O[1] +(b * -24),O[2] +(c * 89)),ZL);
				SkyBaseArray(Mikey);
				wait .05;
			}
		}
	}
	O =(27,-242,466.125);
	Mikey=[];
	for(a=0;a < 12;a++)
	{
		for(b=0;b < 2;b++)
		{
			i=Mikey.size;
			Mikey[i]=SpawnSM((O[0],O[1] +(a * -24),O[2] +(b * 89)),ZL);
			SkyBaseArray(Mikey[i]);
			wait .05;
		}
	}
	Mikey[18] Delete();
	Mikey[20] Delete();
	O =(-119,-273,466.125);
	for(a=0;a < 2;a++)
	{
		for(b=0;b < 2;b++)
		{
			for(c=0;c < 5;c++)
			{
				Mikey=SpawnSM((O[0] +(a * 293),O[1] +(b * -93),O[2] +(c * 17.8)),ZB,(0,90,0));
				SkyBaseArray(Mikey);
				wait .05;
			}
		}
	}
	O =(-63,-422,466.125);
	for(a=0;a < 2;a++)
	{
		for(b=0;b < 5;b++)
		{
			Mikey=SpawnSM((O[0] +(a * 180),O[1],O[2] +(b * 17.8)),ZB);
			SkyBaseArray(Mikey);
			wait .05;
		}
	}
	O =(27,-515,466.125);
	for(a=0;a < 5;a++)
	{
		Mikey=SpawnSM((O[0],O[1],O[2] +(a * 17.8)),ZB);
		SkyBaseArray(Mikey);
		wait .05;
	}
	O =(-63,-216,466.125);
	O2 =(-63,-228,484.125);
	for(a=0;a < 3;a++)
	{
		for(b=0;b < 2;b++)
		{
			Mikey=SpawnSM((O[0] +(a * 90),O[1],O[2] +(b * 71)),ZB);
			SkyBaseArray(Mikey);
			Mikey=SpawnSM((O2[0] +(a * 90),O2[1],O2[2]),ZL);
			SkyBaseArray(Mikey);
			wait .05;
		}
	}
	O =(-31,-467,466.125);
	for(a=0;a < 2;a++)
	{
		for(b=0;b < 5;b++)
		{
			Mikey=SpawnSM((O[0] +(a * 116),O[1],O[2] +(b * 17.8)),ZB,(0,90,0));
			SkyBaseArray(Mikey);
			wait .05;
		}
	}
	M[0]=SpawnSM((144,-216,511.125),ZB,(90,0,0));
	M[1]=SpawnSM((-109,-216,511.125),ZB,(90,0,0));
	M[2]=SpawnSM((-92,-228,511),ZL,(90,0,0));
	M[3]=SpawnSM((143,-228,511),ZL,(90,0,0));
	M[4]=SpawnSM((27,-228,537.125),ZL);
	wait .05;
	M[5]=SpawnSM((117,-228,537.125),ZL);
	M[6]=SpawnSM((-63,-228,537.125),ZL);
	M[7]=SpawnSM((-28,-457,466),ZL,(0,270,0));
	M[8]=SpawnSM((82,-457,466),ZL,(0,90,0));
	M[9]=SpawnSM((27,-458,465),"zombie_teleporter_mainframe_ring1");
	M[9] thread RotateEntYaw(-360,2);
	for(i=0;i<=M.size - 1;i++)
	{
		SkyBaseArray(M[i]);
	}
	i=0;
	for(a=425;a>=25;a -= 40)
	{
		if(i==0)
		{
			Ring=SpawnSM((27,-458,a),"zombie_teleporter_mainframe_ring3");
			Ring thread RotateEntYaw(360,2);
			SkyBaseArray(Ring);
			i++;
			wait .05;
			continue;
		}
		else if(i==1)
		{
			Ring=SpawnSM((27,-458,a),"zombie_teleporter_mainframe_ring1");
			Ring thread RotateEntYaw(-360,2);
			SkyBaseArray(Ring);
			i--;
			wait .05;
			continue;
		}
	}
	VeloFx=SpawnSM((27,-458,525),"zombie_sign_please_wait");
	SkyBaseArray(VeloFx);
	PlayFxOnTag(level._effect["powerup_on"],VeloFx,"tag_origin");
	level endon("Deleting");
	VeloFx thread maps\_zombiemode_powerups::powerup_wobble();
	for(;;)
	{
		VeloFx MoveZ((-510),10,3,3);
		VeloFx RotateYaw(-360,10,3,3);
		wait 10;
		VeloFx MoveZ((510),10,3,3);
		VeloFx RotateYaw(360,10,3,3);
		wait 10;
	}
}
SpawnSolidTR(Width,Height,Origin)
{
	Ent=spawn("trigger_radius",(0,0,0),0,Width,Height);
	Ent.origin=Origin;
	Ent SetContents(1);
	return Ent;
}
SB_Collision()
{
	self thread OldDoors();
	wait .1;
	Door=GetEntArray("zombie_door","targetname");
	for(i=0;i < Door[3].doors.size;i++)
	{
		Door[3].doors[i] Hide();
		Door[3].doors[i].origin =(-124.441,-305.733,567.93);
	}
	for(i=0;i < Door[2].doors.size;i++)
	{
		Door[2].doors[i] Hide();
		Door[2].doors[i].origin =(172.473,-318.286,577.355);
	}
	for(i=0;i < Door[1].doors.size;i++)
	{
		Door[1].doors[i] Hide();
		Door[1].doors[i].origin =(89.7265,-470.183,512.35);
		Door[1].doors[i].angles =(0,90,0);
		Door[1].doors[i] Solid();
	}
	for(i=0;i < Door[8].doors.size;i++)
	{
		Door[8].doors[i] Hide();
		Door[8].doors[i].origin =(-31,-470.183,512.35);
		Door[8].doors[i].angles =(0,45,0);
	}
	for(i=0;i < Door[6].doors.size;i++)
	{
		Door[6].doors[i] Hide();
		Door[6].doors[i].origin =(28.038,-504.581,507.367);
	}
	Door[7].doors[0] Hide();
	Door[7].doors[0].origin =(-64.1683,-392,495.603);
	Door[7].doors[0].angles =(0,90,0);
	Door[7].doors[1] Hide();
	Door[7].doors[1].origin =(123.512,-412.523,494.668);
	Door[7].doors[1].angles =(0,90,90);
	Door[5].doors[0] Hide();
	Door[5].doors[0].origin =(-54.9452,-216.078,475);
	Door[5].doors[0].angles =(-90,0,0);
	Door[5].doors[1] Hide();
	Door[5].doors[1].origin =(90,-216.078,475);
	Door[5].doors[1].angles =(-90,0,0);
	Door[4].doors[0] Hide();
	Door[4].doors[0].origin =(-75.6313,-397.62,510.284);
	wait .05;
}
SB_Door()
{
	level endon("SkyBaseDeleted");
	O =(-63,-204,475);
	Mikey=[];
	for(a=0;a < 3;a++)
	{
		for(b=0;b < 3;b++)
		{
			i=Mikey.size;
			Mikey[i]=SpawnSM((O[0] +(a * 90),O[1],O[2] +(b * 24)),"zombie_treasure_box_lid",(0,0,90));
			SkyBaseArray(Mikey[i]);
			wait .05;
		}
	}
	WindowsLvr=SpawnSM((-106,-340,510),"zombie_power_lever_handle",(0,90,90));
	WindowsLvrLight=SpawnSM(WindowsLvr.origin +(0,-15,0),"lights_cagelight_red_on",(0,270,90));
	SkyBaseArray(WindowsLvr);
	SkyBaseArray(WindowsLvrLight);
	level.WindowPos="Closed";
	WindowTrig=spawn("trigger_radius",WindowsLvr.origin +(7,0,0),1,10,10);
	WindowTrig SetCursorHint("HINT_NOICON");
	WindowTrig SetHintString("Press &&1 To ^2Open ^7Window");
	SkyBaseArray(WindowTrig);
	for(;;)
	{
		WindowTrig waittill("trigger",i);
		if(i UseButtonPressed())
		{
			if(level.WindowPos!="Open")
			{
				WindowsLvrLight SetModel("zombie_zapper_cagelight_green");
				i thread RotateModelFx(WindowsLvr);
				for(i=0;i < Mikey.size;i++)
				{
					Mikey[i] MoveTo(Mikey[i].origin +(0,0,-80),2,.5,.5);
				}
				wait 2;
				level.Turret RotateTo((0,90,0),2,.5,.5);
				level.Turret2 RotateTo((0,90,0),2,.5,.5);
				for(i=0;i < Mikey.size;i++)
				{
					Mikey[i] hide();
				}
				wait .5;
				WindowTrig SetHintString("Press &&1 To ^1Close ^7Window");
				level.WindowPos="Open";
			}
			else
			{
				WindowsLvrLight SetModel("lights_cagelight_red_on");
				level.Turret RotateTo((0,0,0),2,.5,.5);
				level.Turret2 RotateTo((0,180,0),2,.5,.5);
				i thread RotateModelFx(WindowsLvr);
				for(i=0;i < Mikey.size;i++)
				{
					Mikey[i] show();
				}
				for(i=0;i < Mikey.size;i++)
				{
					Mikey[i] MoveTo(Mikey[i].origin +(0,0,80),2,.5,.5);
				}
				wait 2.5;
				WindowTrig SetHintString("Press &&1 To ^2Open ^7Window");
				level.WindowPos="Closed";
			}
		}
	}
}
RotateModelFx(Ent)
{
	PlaySoundatPosition("packa_door_1",(27,-204,475));
	Ent RotateTo((0,90,0),1,0,.5);
	wait 1;
	Ent RotateTo((0,90,90),1,0,.5);
}

SB_PackaPunch()
{
	level endon("SkyBaseDeleted");
	Packi = SpawnSM((145,-320,466.125), "zombie_vending_packapunch_on", (0,270,0));
	level thread PackiMusic(Packi);
	SkyBaseArray(Packi);
	PackiSolid = spawn("trigger_radius", (0,0,0), 0, 100, 100);
	PackiSolid.origin = (145,-320,466.125);
	PackiSolid.angles = (0,270,0);
	PackiSolid SetContents(1);
	SkyBaseArray(PackiSolid);
	Packi PlayLoopSound("zmb_perks_packa_loop");
	PaPTrig = Spawn("trigger_radius", (150,-320,466.125), 1, 60, 60);
	PaPTrig SetCursorHint("HINT_NOICON");
	PaPTrig SetHintString("Press &&1 To Buy Pack 'a' Punch Upgrade [Cost: 500]");
	SkyBaseArray(PaPTrig);
	for(;;)
	{
		PaPTrig waittill("trigger", i);
		if(!IsPlayer(i)) continue;
		if(i UseButtonPressed())
		{
			if(!IsDefined(i.SkyBaseUsing)) i.SkyBaseUsing = false;
			if(i.SkyBaseUsing) continue;
			Weap = i GetCurrentWeapon();
			if(i.score >= 500 && Weap != "none" && !IsSubStr(Weap, "upgraded") && !IsSubStr(Weap, "defaultweapon") && !IsSubStr(Weap, "zombie_melee") && Weap != "zombie_knuckle_crack")
			{
				i.SkyBaseUsing = true;
				PlaySoundAtPosition("evt_bottle_dispense", Packi.origin);
				if(!IsDefined(level.PaPMusicPlaying))
				{
					Packi PlaySound("mus_perks_packa_sting"); 
				}
				orig_weapon = Weap;
				upgraded_weapon = get_upgrade_names(orig_weapon);
				i.zombie_cost = 500;
				i.score -= 500;
				i FreezeControls(true);
				if(i GetStance() == "prone")
				{
					i SetStance("crouch");
				}
				Crack = "zombie_knuckle_crack";
				self playSound("zmb_perks_packa_knuckle_0");
				self playSound("zmb_perks_packa_knuckle_1");
				i TakeWeapon(orig_weapon);
				i GiveWeapon(Crack);
				i SwitchToWeapon(Crack);
				Fx = Spawn("script_model", Packi.origin);
				Fx SetModel("tag_origin");
				Fx LinkTo(Packi);
				PlayFxOnTag(LoadFx("maps/zombie/fx_zombie_packapunch"), Fx, "tag_origin");
				Fx thread DeleteOverTime(10);
				SkyBaseArray(Fx);
				i third_person_weapon_upgrade(orig_weapon, upgraded_weapon, Packi.origin + (0,-1,34), Packi.angles + (0,90,0), Packi, Packi);
				i FreezeControls(false);
				i TakeWeapon(Crack);
				if(i HasWeapon(orig_weapon))
				{
					i TakeWeapon(orig_weapon);
				}
				i GiveWeapon(upgraded_weapon);
				i SwitchToWeapon(upgraded_weapon);
				i GiveMaxAmmo(upgraded_weapon);
				i.SkyBaseUsing = false;
			}
			else
			{
				Packi PlaySound("zmb_perks_pap_deny");
				wait 1;
			}
		}
	}
}
get_upgrade_names(weap)
{
	if(IsSubStr(weap, "_zm"))
	{
		tokens = strtok(weap, "_");
		base = "";
		for(k=0;k<tokens.size-1;k++)
		{
			base = base + tokens[k] + "_";
		}
		return base + "upgraded_zm";
	}
	else
	{
		return weap + "_upgraded";
	}
}
third_person_weapon_upgrade(current_weapon, upgraded_weapon, origin, angles, packa_rollers, perk_machine)
{
	forward = anglesToForward(angles);
	interact_pos = origin + (forward * -25);
	worldgun = spawn("script_model", interact_pos);
	worldgun.angles = self.angles;
	wModel = GetWeaponModel(current_weapon);
	if(IsDefined(wModel))
	{
		worldgun setModel(wModel);
	}
	worldgun rotateto(angles + (0,90,0), 0.35, 0, 0);
	wait(0.5);
	worldgun moveto(origin, 0.5, 0, 0);
	packa_rollers playsound("zmb_perks_packa_upgrade");
	if(isDefined(perk_machine.wait_flag))
	{
		perk_machine.wait_flag rotateto(perk_machine.wait_flag.angles + (179,0,0), 0.25, 0, 0);
	}
	wait(0.35);
	worldgun delete();
	wait(3);
	packa_rollers playsound("zmb_perks_packa_ready");
	worldgun = spawn("script_model", origin);
	worldgun.angles = angles + (0,90,0);
	upgraded_model = GetWeaponModel(upgraded_weapon);
	if(IsDefined(upgraded_model))
	{
		worldgun setModel(upgraded_model);
	}
	worldgun moveto(interact_pos, 0.5, 0, 0);
	if(isDefined(perk_machine.wait_flag))
	{
		perk_machine.wait_flag rotateto(perk_machine.wait_flag.angles - (179,0,0), 0.25, 0, 0);
	}
	wait(0.5);
	worldgun delete();
}

PackiMusic(Ent)
{
	level endon("SkyBaseDeleted");
	for(;;)
	{
		Ent PlaySound("mus_perks_packapunch_jingle");
		level.PaPMusicPlaying=true;
		wait 45;
		level.PaPMusicPlaying=undefined;
		wait 90;
	}
}
DeleteOverTime(Time)
{
	wait Time;
	self Delete();
}
SB_RayGun()
{
	level endon("SkyBaseDeleted");
	TesGun=SpawnSM((25,-215,513),"viewmodel_zombie_tesla_up");
	TesGun.angles =(0,-180,0);
	PlayFxOnTag(LoadFx("maps/zombie/fx_zombie_wire_spark"),TesGun,"tag_origin");
	SkyBaseArray(TesGun);
	TesTrig=Spawn("trigger_radius",(25,-215,513),1,30,30);
	TesTrig SetCursorHint("HINT_NOICON");
	TesTrig SetHintString("Press &&1 To Buy A Wunderwaffle DG-3 JZ [Cost: 500]");
	SkyBaseArray(TesTrig);
	for(;;)
	{
		TesTrig waittill("trigger",i);
		if(i UseButtonPressed())
		{
			if(!i HasWeapon("tesla_gun_upgraded_zm")&& i.score>=500)
			{
				i.SkyBaseUsing=true;
				i PlaySound("zmb_cha_ching");
				i.zombie_cost=500;
				i.score -= 500;
				i GiveWeapon("tesla_gun_upgraded_zm");
				i SwitchToWeapon("tesla_gun_upgraded_zm");
				i PlaySound("zmb_laugh_child");
				i.SkyBaseUsing=false;
			}
			else
			{
				i PlaySound("zmb_no_cha_ching");
				wait 1;
			}
		}
	}
}
SB_BowieKnife()
{
	level endon("SkyBaseDeleted");
	DubTap=spawn("script_model",(-64,-400,522.125));
	DubTap SetModel("viewmodel_knife_bowie");
	DubTap.angles =(-90,180,0);
	self thread Rotate(DubTap);
	self thread UpAndDown(DubTap);
	PlayfxOnTag(level._effect["powerup_on"],DubTap,"tag_origin");
	SkyBaseArray(DubTap);
	BowieTrig=Spawn("trigger_radius",(-64,-400,466.125),1,30,30);
	BowieTrig SetCursorHint("HINT_NOICON");
	BowieTrig SetHintString("Press &&1 To Buy Bowie Knife [Cost: 500]");
	SkyBaseArray(BowieTrig);
	for(;;)
	{
		BowieTrig waittill("trigger",i);
		if(i UseButtonPressed())
		{
			if(i HasPerk("specialty_altmelee"))
			{
				DubTap playSound("evt_perk_deny");
				wait .3;
			}
			else if(i.score < 500)
			{
				i playSound("plr_"+i getEntityNumber()+"_vox_nomoney_perk_0");
				wait .3;
			}
			else if(i.score>=500)
			{
				i thread GiveBowie();
				wait .6;
			}
		}
	}
}
UpAndDown(Obj)
{
	level endon("Deleting");
	for(;;)
	{
		Obj MoveZ(-38,3,.5,.5);
		wait 3;
		Obj MoveZ(38,3,.5,.5);
		wait 3;
	}
}
SB_Perks()
{
	level endon("SkyBaseDeleted");
	level thread PerksModel();
	PerkTrig=Spawn("trigger_radius",(-85,-242,510),1,20,20);
	PerkTrig SetCursorHint("HINT_NOICON");
	PerkTrig SetHintString("Press &&1 To Buy All Perks [Cost: 500]");
	SkyBaseArray(PerkTrig);
	for(;;)
	{
		PerkTrig waittill("trigger",i);
		if(i UseButtonPressed()&& !i.SkyBaseUsing)
		{
			if(i.score>=500)
			{
				if(!i HasPerk("specialty_rof")|| !i HasPerk("specialty_armorvest")|| !i HasPerk("specialty_quickrevive")|| !i HasPerk("specialty_fastreload"))
				{
					i.SkyBaseUsing=true;
					i PlaySound("zmb_cha_ching");
					i.zombie_cost=500;
					i.score -= 500;
					i Purchase_Perks();
					i.SkyBaseUsing=false;
					wait 1;
				}
				else
				{
					i PlaySound("zmb_no_cha_ching");
					wait 1;
				}
			}
			else
			{
				i PlaySound("evt_perk_deny");
				wait 1;
			}
		}
	}
}
Purchase_Perks()
{
	weap=self GetCurrentWeapon();
	self thread giveMenuPerk("specialty_rof");
	self waittill("perk_drank");
	self thread giveMenuPerk("specialty_armorvest");
	self waittill("perk_drank");
	self thread giveMenuPerk("specialty_fastreload");
	self waittill("perk_drank");
	self thread giveMenuPerk("specialty_quickrevive");
	self waittill("perk_drank");
	self SwitchToWeapon(weap);
}
PerksModel()
{
	level endon("SkyBaseDeleted");
	Perk[0]=SpawnSM((-85,-242,528),"tag_origin");
	Perk[1]=SpawnSM(Perk[0].origin +(-5,0,0),"zombie_perk_bottle_jugg");
	Perk[2]=SpawnSM(Perk[0].origin +(5,0,0),"zombie_perk_bottle_revive");
	Perk[3]=SpawnSM(Perk[0].origin +(0,-5,0),"zombie_perk_bottle_doubletap");
	Perk[4]=SpawnSM(Perk[0].origin +(0,5,0),"zombie_perk_bottle_sleight");
	Perk[5]=SpawnSM(Perk[0].origin -(0,0,61.875),"tag_origin",(-90,0,0));
	PlayFxOnTag(LoadFx("misc/fx_zombie_electric_trap"),Perk[5],"tag_origin");
	SkyBaseArray(Perk[0]);
	for(i=1;i<=Perk.size - 1;i++)
	{
		Perk[i] LinkTo(Perk[0]);
		SkyBaseArray(Perk[i]);
	}
	Perk[0] thread RotateEntYaw(360,2);
	level endon("Deleting");
	for(;;)
	{
		Perk[0] MoveZ(-38,3,.5,.5);
		wait 3;
		Perk[0] MoveZ(38,3,.5,.5);
		wait 3;
	}
}
SB_MusicEgg()
{
	level endon("SkyBaseDeleted");
	Jar=SpawnSM((95,-402,502.125),"weapon_zombie_monkey_bomb");
	PlayfxOnTag(level._effect["powerup_on"],Jar,"tag_origin");
	self thread Rotate(Jar);
	SkyBaseArray(Jar);
	MusicTrig=Spawn("trigger_radius",Jar.origin,1,15,15);
	MusicTrig SetCursorHint("HINT_NOICON");
	MusicTrig SetHintString("Press &&1 To Play Music Easter Egg");
	SkyBaseArray(MusicTrig);
	for(;;)
	{
		MusicTrig waittill("trigger",i);
		if(i UseButtonPressed()&& !IsDefined(level.SkyBaseMusic))
		{
			level.SkyBaseMusic=true;
			MusicTrig SetHintString("");
			PlaySoundatPosition("zmb_monkey_anim_cymb",Jar.origin);
			PlaySoundatPosition("zmb_meteor_activate",Jar.origin);
			i thread EggSong();
			wait(265);
			MusicTrig SetHintString("Press &&1 To Play Music Easter Egg");
			level.SkyBaseMusic=undefined;
		}
	}
}
SB_Entrance()
{
	level endon("SkyBaseDeleted");
	EntranceTrig=Spawn("trigger_radius",(27,-458,-2.875),1,10,10);
	EntranceTrig SetCursorHint("HINT_NOICON");
	EntranceTrig SetHintString("Press &&1 To ^2Ascend ^7To SkyBase");
	SkyBaseArray(EntranceTrig);
	for(;;)
	{
		EntranceTrig waittill("trigger",i);
		if(i UseButtonPressed()&& !IsDefined(i.UsingVelo)&& i.is_zombie==false)
		{
			i.UsingVelo=true;
			i thread Velocity();
			i.inBase=true;
		}
	}
}
SB_Exit()
{
	level endon("SkyBaseDeleted");
	ExitTrig=Spawn("trigger_radius",(27,-458,466.125),1,10,10);
	ExitTrig SetCursorHint("HINT_NOICON");
	ExitTrig SetHintString("Press &&1 To ^1Descend ^7To Ground");
	SkyBaseArray(ExitTrig);
	for(;;)
	{
		ExitTrig waittill("trigger",i);
		if(i UseButtonPressed()&& !IsDefined(i.UsingVelo)&& i.is_zombie==false)
		{
			i.UsingVelo=true;
			i thread NoVelocity();
			i.inBase=false;
		}
	}
}
VeloSounds()
{
	self PlayLocalSound("zmb_whoosh");
	wait 1;
	self PlayLocalSound("zmb_whoosh");
}
NoProne()
{
	self endon("Base_Exit");
	for(;;)
	{
		self AllowJump(false);
		self AllowProne(false);
		wait .1;
	}
}
SkyBaseArray(Ent)
{
	if(!IsDefined(level.SkyBaseEnt))
	{
		level.SkyBaseEnt=[];
	}
	i=level.SkyBaseEnt.size;
	level.SkyBaseEnt[i]=Ent;
}
SkyBaseStart()
{
	if(!level.SkyBase)
	{
		if(level.merryGoRound==true||level.Secret==true||level.TrampoSpwnd==true||level.LunaSpawned==true)self iPrintln("^1Cannot Spawn Skybase");
		else
		{
			self iPrintln("Building SkyBase...");
			self notify("rain_over");
			level.SkyBaseBuilding=true;
			self thread LetDeleteTime();
			level.SkyBase=true;
			self thread Instant(8);
			self thread OpenAllDoor();
			self thread SpawnSkyBase();
			wait 6;
			self thread SB_collision();
			self iPrintln("Skybase ^2Spawned");
		}
	}
	else
	{
		if(!level.SkyBaseBuilding)
		{
			self iPrintln("SkyBase ^1Deleted");
			Player=get_players();
			self thread LetDeleteTime();
			level notify("SkyBaseDeleted");
			wait .05;
			for(i=0;i<=level.SkyBaseEnt.size - 1;i++)
			{
				level.SkyBaseEnt[i] Delete();
				for(p=0;p < Player.size;p++)
				{
					if(Player[p].inBase==true)
					{
						Player[p] notify("Base_Exit");
						Player[p] AllowJump(true);
						Player[p] AllowProne(true);
						Player[p] returnToSpawn();
						Player[p] thread DecideGod();
					}
				}
			}
			level notify("Deleting");
			level.SkyBase=false;
			self thread Instant(8);
		}
		else
		{
			self iPrintln("Please Wait...");
			wait 1;
		}
	}
}
LetDeleteTime()
{
	wait 10;
	level.SkyBaseBuilding=false;
}
createServerText(font,fontScale,align,relative,x,y,sort,alpha,text)
{
	textElem=createServerFontString(font,fontScale);
	textElem setPoint(align,relative,x,y);
	textElem.sort=sort;
	textElem.alpha=alpha;
	textElem setText(text);
	return textElem;
}
setLobbyTimer(time)
{
	if(time==1)level.Timer=""+time+" Minute";
	else level.Timer=""+time+" Minutes";
	self.MainT SetText("Timer ["+level.Timer+"]");
	self iPrintLn("Timer Set To: ^2"+level.Timer+"");
	level.lobbyTimerTime=time;
}
startLobbyTimer()
{
	if(!isDefined(level.lobbyTimerTime))
	{
		self iPrintLn("Please Set The Timer First");
		return;
	}
	if(isDefined(level.lobbyTimerIsSet))self iPrintLn("Timed Lobby Already Set");
	if(!isDefined(level.lobbyTimerIsSet))
	{
		level.lobbyTimerIsSet=true;
		level.timerSet=true;
		text=createServerText("small",1.5,"TOPLEFT","TOPLEFT",560,0,1,1,"Lobby Ends In:");
		time=createServerText("small",1.5,"TOPLEFT","TOPLEFT",560,20,1,1,undefined);
		time setTimer(level.lobbyTimerTime*60);
		wait(level.lobbyTimerTime*60);
		wait 1;
		text destroy();
		time destroy();
		exitLevel();
	}
}
