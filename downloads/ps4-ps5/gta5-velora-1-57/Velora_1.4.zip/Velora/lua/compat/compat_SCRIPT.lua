-- compat_SCRIPT.lua — AUTO GENERATO


-- SCRIPT


SCRIPT=SCRIPT or {}


-- PC:0x6EB5F71AA68F2E8E Old:0xE26B2666


function SCRIPT.REQUEST_SCRIPT(scriptName)


  Velora.invoke(0xAB0E40,"void", scriptName)


end


-- PC:0xC90D2DCACD56184C Old:0x6FCB7795


function SCRIPT.SET_SCRIPT_AS_NO_LONGER_NEEDED(scriptName)


  Velora.invoke(0xAB0EC0,"void", scriptName)


end


-- PC:0xE6CC9F3BA0FB9EF1 Old:0x5D67F751


function SCRIPT.HAS_SCRIPT_LOADED(scriptName)


  return Velora.invoke(0xAB0FB0,"bool", scriptName)


end


-- PC:0xFC04745FBE67C19A Old:0xDEAB87AB


function SCRIPT.DOES_SCRIPT_EXIST(scriptName)


  return Velora.invoke(0xAB0F70,"bool", scriptName)


end


-- PC:0xD62A67D26D9653E6 Old:0x1C68D9DC


function SCRIPT.REQUEST_SCRIPT_WITH_NAME_HASH(scriptHash)


  Velora.invoke(0xAB0FB0,"void", scriptHash)


end


-- PC:0xC5BC038960E9DB27 Old:0x96C26F66


function SCRIPT.SET_SCRIPT_WITH_NAME_HASH_AS_NO_LONGER_NEEDED(scriptHash)


  Velora.invoke(0xAB10A0,"void", scriptHash)


end


-- PC:0x5F0F0C783EB16C04 Old:0x06674818


function SCRIPT.HAS_SCRIPT_WITH_NAME_HASH_LOADED(scriptHash)


  return Velora.invoke(0xAB1280,"bool", scriptHash)


end


-- PC:0xF86AA3C56BA31381 Old:0x19EAE282


function SCRIPT.DOES_SCRIPT_WITH_NAME_HASH_EXIST(scriptHash)


  return Velora.invoke(0xAB11F0,"bool", scriptHash)


end


-- PC:0xC8B189ED9138BCD4 Old:0x253FD520


function SCRIPT.TERMINATE_THREAD(threadId)


  Velora.invoke(0xAB1280,"void", threadId)


end


-- PC:0x46E9AE36D8FA6417 Old:0x78D7A5A0


function SCRIPT.IS_THREAD_ACTIVE(threadId)


  return Velora.invoke(0xAB1350,"bool", threadId)


end


-- PC:0xDADFADA5A20143A8 Old:0xBB4E2F66


function SCRIPT.SCRIPT_THREAD_ITERATOR_RESET()


  Velora.invoke(0xAB1350,"void")


end


-- PC:0x30B4FA1C82DD4B9F Old:0x1E28B28F


function SCRIPT.SCRIPT_THREAD_ITERATOR_GET_NEXT_THREAD_ID()


  return Velora.invoke(0xAB13A0,"int")


end


-- PC:0xC30338E8088E2E21 Old:0xDE524830


function SCRIPT.GET_ID_OF_THIS_THREAD()


  return Velora.invoke(0xAB1380,"int")


end


-- PC:0x1090044AD1DA76FA Old:0x3CD9CBB7


function SCRIPT.TERMINATE_THIS_THREAD()


  Velora.invoke(0xAB13A0,"void")


end


-- PC:0x2C83A9DA6BFFC4F9 Old:0x029D3841


function SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(scriptHash)


  return Velora.invoke(0xAB1540,"int", scriptHash)


end


-- PC:0x8A1C8B1738FFE87E Old:0x2BEE1F45


function SCRIPT.GET_HASH_OF_THIS_SCRIPT_NAME()


  return Velora.invoke(0xAB1410,"int")


end


-- PC:0x5F92A689A06620AA Old:0xA3525D60


function SCRIPT.GET_NUMBER_OF_EVENTS(eventGroup)


  return Velora.invoke(0xAB1430,"int", eventGroup)


end


-- PC:0x936E6168A9BCEDB5 Old:0xA1B447B5


function SCRIPT.GET_EVENT_EXISTS(eventGroup, eventIndex)


  return Velora.invoke(0xAB1480,"bool", eventGroup, eventIndex)


end


-- PC:0xD8F66A3A60C62153 Old:0xB49C1442


function SCRIPT.GET_EVENT_AT_INDEX(eventGroup, eventIndex)


  return Velora.invoke(0xAB14B0,"int", eventGroup, eventIndex)


end


-- PC:0x2902843FCD2B2D79 Old:0x4280F92F


function SCRIPT.GET_EVENT_DATA(eventGroup, eventIndex, eventData, eventDataSize)


  return Velora.invoke(0xAB14F0,"bool", eventGroup, eventIndex, eventData, eventDataSize)


end


-- PC:0x5AE99C571D5BBE5D Old:0x54763B35


function SCRIPT.TRIGGER_SCRIPT_EVENT(eventGroup, eventData, eventDataSize, playerBits)


  Velora.invoke(0xAB1540,"void", eventGroup, eventData, eventDataSize, playerBits)


end


-- PC:0x078EBE9809CCD637 Old:0xA2826D17


function SCRIPT.SHUTDOWN_LOADING_SCREEN()


  Velora.invoke(0xAB1560,"void")


end


-- PC:0x5262CC1995D07E09 Old:0xC8055034


function SCRIPT.SET_NO_LOADING_SCREEN(toggle)


  Velora.invoke(0xAB1570,"void", toggle)


end


-- PC:0x18C1270EA7F199BC Old:0x27512BA0


function SCRIPT.GET_NO_LOADING_SCREEN()


  return Velora.invoke(0xAB15A0,"bool")


end


-- PC:0xB1577667C3708F9B Old:0xB03BCCDF


function SCRIPT.COMMIT_TO_LOADINGSCREEN_SELCTION()


  Velora.invoke(0xAB15A0,"void")


end


-- PC:0x836B62713E0534CA Old:0x22B9F132


function SCRIPT.BG_IS_EXITFLAG_SET()


  return Velora.invoke(0xAB15E0,"bool")


end


-- PC:0x760910B49D2B98EA Old:0x5C95B670


function SCRIPT.BG_SET_EXITFLAG_RESPONSE()


  Velora.invoke(0xAB15E0,"void")


end


-- PC:0x75B18E49607874C7 Old:0x67B23E17


function SCRIPT.BG_START_CONTEXT_HASH(contextHash)


  Velora.invoke(0xAB1600,"void", contextHash)


end


-- PC:0x107E5CC7CA942BC1 Old:0x3D981EBF


function SCRIPT.BG_END_CONTEXT_HASH(contextHash)


  Velora.invoke(0xAB1620,"void", contextHash)


end


-- PC:0x9D5A25BADB742ACD Old:0xF3F1D953


function SCRIPT.BG_START_CONTEXT(contextName)


  Velora.invoke(0xAB1640,"void", contextName)


end


-- PC:0xDC2BACD920D0A0DD Old:0x11F38FB3


function SCRIPT.BG_END_CONTEXT(contextName)


  Velora.invoke(0xAB1670,"void", contextName)


end


-- PC:0x0F6F1EBBC4E1D5E6 Old:0xF8E5F73A


function SCRIPT.BG_DOES_LAUNCH_PARAM_EXIST(scriptIndex, p1)


  return Velora.invoke(0xDEADBEEF,"bool", scriptIndex, p1)


end


-- PC:0x22E21FBCFC88C149 Old:0x682CB7E1


function SCRIPT.BG_GET_LAUNCH_PARAM_VALUE(scriptIndex, p1)


  return Velora.invoke(0xAB1710,"int", scriptIndex, p1)


end


-- PC:0x829CD22E043A2577 Old:0xC515E735


function SCRIPT.BG_GET_SCRIPT_ID_FROM_NAME_HASH(p0)


  return Velora.invoke(0xAB1790,"int", p0)


end


function SCRIPT.SEND_TU_SCRIPT_EVENT(eventGroup, eventData, eventDataSize, playerBits)


  Velora.invoke(0xDEADBEEF,"void", eventGroup, eventData, eventDataSize, playerBits)


end


