-- compat_DECORATOR.lua — AUTO GENERATO


-- DECORATOR


DECORATOR=DECORATOR or {}


-- PC:0x95AED7B8E39ECAA4 Old:0xBBAEEF94


function DECORATOR.DECOR_SET_TIME(entity, propertyName, timestamp)


  return Velora.invoke(0x9A0030,"bool", entity, propertyName, timestamp)


end


-- PC:0x6B1E8E2ED1335B71 Old:0x8E101F5C


function DECORATOR.DECOR_SET_BOOL(entity, propertyName, value)


  return Velora.invoke(0x9A0060,"bool", entity, propertyName, value)


end


-- PC:0x211AB1DD8D0F363A Old:0xBC7BD5CB


function DECORATOR.DECOR_SET_FLOAT(entity, propertyName, value)


  return Velora.invoke(0x9A0140,"bool", entity, propertyName, value)


end


-- PC:0x0CE3AA5E1CA19E10 Old:0xDB718B21


function DECORATOR.DECOR_SET_INT(entity, propertyName, value)


  return Velora.invoke(0x9A0220,"bool", entity, propertyName, value)


end


-- PC:0xDACE671663F2F5DB Old:0xDBCE51E0


function DECORATOR.DECOR_GET_BOOL(entity, propertyName)


  return Velora.invoke(0x9A02F0,"bool", entity, propertyName)


end


-- PC:0x6524A2F114706F43 Old:0x8DE5382F


function DECORATOR.DECOR_GET_FLOAT(entity, propertyName)


  return Velora.invoke(0x9A03B0,"float", entity, propertyName)


end


-- PC:0xA06C969B02A97298 Old:0xDDDE59B5


function DECORATOR.DECOR_GET_INT(entity, propertyName)


  return Velora.invoke(0x9A0480,"int", entity, propertyName)


end


-- PC:0x05661B80A8C9165F Old:0x74EF9C40


function DECORATOR.DECOR_EXIST_ON(entity, propertyName)


  return Velora.invoke(0x9A0540,"bool", entity, propertyName)


end


-- PC:0x00EE9F297C738720 Old:0xE0E2640B


function DECORATOR.DECOR_REMOVE(entity, propertyName)


  return Velora.invoke(0x9A05C0,"bool", entity, propertyName)


end


-- PC:0x9FD90732F56403CE Old:0x68BD42A9


function DECORATOR.DECOR_REGISTER(propertyName, type)


  Velora.invoke(0x9A0640,"void", propertyName, type)


end


-- PC:0x4F14F9F870D6FBC8 Old:0x7CF0971D


function DECORATOR.DECOR_IS_REGISTERED_AS_TYPE(propertyName, type)


  return Velora.invoke(0x9A0730,"bool", propertyName, type)


end


-- PC:0xA9D14EEA259F9248 Old:0x7F3F1C02


function DECORATOR.DECOR_REGISTER_LOCK()


  Velora.invoke(0x9A0730,"void")


end


