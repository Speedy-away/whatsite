-- compat_INTERIOR.lua — AUTO GENERATO


-- INTERIOR


INTERIOR=INTERIOR or {}


function INTERIOR.GET_INTERIOR_HEADING(interior)


  return Velora.invoke(0x9E80B0,"float", interior)


end


-- PC:0x252BDC06B73FA6EA Old:0x75885CB3


function INTERIOR.GET_INTERIOR_LOCATION_AND_NAMEHASH(interior)


  Velora.invoke(0x9E80B0,"void", interior)


end


-- PC:0xE4A84ABF135EF91A Old:0x09D6376F


function INTERIOR.GET_INTERIOR_GROUP_ID(interior)


  return Velora.invoke(0x9E82F0,"int", interior)


end


-- PC:0x9E3B3E6D66F6E22F Old:0x7D8F26A1


function INTERIOR.GET_OFFSET_FROM_INTERIOR_IN_WORLD_COORDS(interior, x, y, z)


  local x,y,z=Velora.invoke(0x9E81E0,"vector3", interior, x, y, z)


  return {x=x,y=y,z=z}


end


-- PC:0xBC72B5D7A1CBD54D Old:0x55226C13


function INTERIOR.IS_INTERIOR_SCENE()


  return Velora.invoke(0x9E82C0,"bool")


end


-- PC:0x26B0E73D7EAAF4D3 Old:0x39C0B635


function INTERIOR.IS_VALID_INTERIOR(interior)


  return Velora.invoke(0x9E82D0,"bool", interior)


end


-- PC:0xB365FC0C4E27FFA7 Old:0x7DDADB92


function INTERIOR.CLEAR_ROOM_FOR_ENTITY(entity)


  Velora.invoke(0x9E82F0,"void", entity)


end


-- PC:0x52923C4710DD9907 Old:0x10BD4435


function INTERIOR.FORCE_ROOM_FOR_ENTITY(entity, interior, roomHashKey)


  Velora.invoke(0x9E8380,"void", entity, interior, roomHashKey)


end


-- PC:0x47C2A06D4F5F424B Old:0xE4ACF8C3


function INTERIOR.GET_ROOM_KEY_FROM_ENTITY(entity)


  return Velora.invoke(0x9E8470,"int", entity)


end


-- PC:0x399685DB942336BC Old:0x91EA80EF


function INTERIOR.GET_KEY_FOR_ENTITY_IN_ROOM(entity)


  return Velora.invoke(0x9E83C0,"int", entity)


end


-- PC:0x2107BA504071A6BB Old:0x5C644614


function INTERIOR.GET_INTERIOR_FROM_ENTITY(entity)


  return Velora.invoke(0x9E8450,"int", entity)


end


-- PC:0x82EBB79E258FA2B7 Old:0xE645E162


function INTERIOR.RETAIN_ENTITY_IN_INTERIOR(entity, interior)


  Velora.invoke(0x9E8470,"void", entity, interior)


end


function INTERIOR.CLEAR_INTERIOR_STATE_OF_ENTITY(entity)


  Velora.invoke(0x9E84E0,"void", entity)


end


function INTERIOR.FORCE_ACTIVATING_TRACKING_ON_ENTITY(p0, p1)


  Velora.invoke(0x9E8530,"void", p0, p1)


end


-- PC:0x920D853F3E17F1DA Old:0xD79803B5


function INTERIOR.FORCE_ROOM_FOR_GAME_VIEWPORT(interiorID, roomHashKey)


  Velora.invoke(0x9E8590,"void", interiorID, roomHashKey)


end


-- PC:0xAF348AFCB575A441 Old:0x1F6B4B13


function INTERIOR.SET_ROOM_FOR_GAME_VIEWPORT_BY_NAME(roomName)


  Velora.invoke(0x9E85A0,"void", roomName)


end


-- PC:0x405DC2AEF6AF95B9 Old:0x0E9529CC


function INTERIOR.SET_ROOM_FOR_GAME_VIEWPORT_BY_KEY(roomHashKey)


  Velora.invoke(0x9E85B0,"void", roomHashKey)


end


-- PC:0xA6575914D2A0B450 Old:0x4FF3D3F5


function INTERIOR.GET_ROOM_KEY_FOR_GAME_VIEWPORT()


  return Velora.invoke(0x9E8740,"int")


end


-- PC:0x23B59D8912F94246 Old:0x617DC75D


function INTERIOR.CLEAR_ROOM_FOR_GAME_VIEWPORT()


  Velora.invoke(0x9E8740,"void")


end


-- PC:0xE7D267EC6CA966C3 Old:0xA83C3D15


function INTERIOR.GET_INTERIOR_FROM_PRIMARY_VIEW()


  return Velora.invoke(0x9E88A0,"int")


end


-- PC:0xB0F7F8663821D9C3 Old:0xA17FBF37


function INTERIOR.GET_INTERIOR_AT_COORDS(x, y, z)


  return Velora.invoke(0x9E8830,"int", x, y, z)


end


-- PC:0x3F6167F351168730 Old:0xA2A73564


function INTERIOR.ADD_PICKUP_TO_INTERIOR_ROOM_BY_NAME(pickup, roomName)


  Velora.invoke(0x9E88A0,"void", pickup, roomName)


end


-- PC:0x2CA429C029CCF247 Old:0x3ADA414E


function INTERIOR.PIN_INTERIOR_IN_MEMORY(interior)


  Velora.invoke(0x9E88F0,"void", interior)


end


-- PC:0x261CCE7EED010641 Old:0xFCFF792A


function INTERIOR.UNPIN_INTERIOR(interior)


  Velora.invoke(0x9E8960,"void", interior)


end


-- PC:0x6726BDCCC1932F0E Old:0xE1EF6450


function INTERIOR.IS_INTERIOR_READY(interior)


  return Velora.invoke(0x9E8B60,"bool", interior)


end


function INTERIOR.SET_INTERIOR_IN_USE(interior)


  return Velora.invoke(0x9E8A00,"bool", interior)


end


-- PC:0x05B7A89BD78797FC Old:0x96525B06


function INTERIOR.GET_INTERIOR_AT_COORDS_WITH_TYPE(x, y, z, interiorType)


  return Velora.invoke(0x9E8A50,"int", x, y, z, interiorType)


end


-- PC:0xF0F77ADB9F67E79D Old:0x11718507


function INTERIOR.GET_INTERIOR_AT_COORDS_WITH_TYPEHASH(x, y, z, typeHash)


  return Velora.invoke(0x9E8AF0,"int", x, y, z, typeHash)


end


function INTERIOR.ACTIVATE_INTERIOR_GROUPS_USING_CAMERA()


  Velora.invoke(0x9E8B60,"void")


end


-- PC:0xEEA5AC2EDA7C33E8 Old:0x7762249C


function INTERIOR.IS_COLLISION_MARKED_OUTSIDE(x, y, z)


  return Velora.invoke(0x9E8CB0,"bool", x, y, z)


end


-- PC:0xEC4CF9FCB29A4424 Old:0x7ED33DC1


function INTERIOR.GET_INTERIOR_FROM_COLLISION(x, y, z)


  return Velora.invoke(0x9E8C00,"int", x, y, z)


end


function INTERIOR.ENABLE_STADIUM_PROBES_THIS_FRAME(toggle)


  Velora.invoke(0x9E8CB0,"void", toggle)


end


-- PC:0x55E86AF2712B36A1 Old:0xC80A5DDF


function INTERIOR.ACTIVATE_INTERIOR_ENTITY_SET(interior, entitySetName)


  Velora.invoke(0x9E8CE0,"void", interior, entitySetName)


end


-- PC:0x420BD37289EEE162 Old:0xDBA768A1


function INTERIOR.DEACTIVATE_INTERIOR_ENTITY_SET(interior, entitySetName)


  Velora.invoke(0x9E8D70,"void", interior, entitySetName)


end


-- PC:0x35F7DD45E8C0A16D Old:0x39A3CC6F


function INTERIOR.IS_INTERIOR_ENTITY_SET_ACTIVE(interior, entitySetName)


  return Velora.invoke(0x9E8EB0,"bool", interior, entitySetName)


end


function INTERIOR.SET_INTERIOR_ENTITY_SET_TINT_INDEX(interior, entitySetName, color)


  Velora.invoke(0x9E8EB0,"void", interior, entitySetName, color)


end


-- PC:0x41F37C3427C75AE0 Old:0x9A29ACE6


function INTERIOR.REFRESH_INTERIOR(interior)


  Velora.invoke(0x9E8F50,"void", interior)


end


-- PC:0xA97F257D0151A6AB Old:0x1F375B4C


function INTERIOR.ENABLE_EXTERIOR_CULL_MODEL_THIS_FRAME(mapObjectHash)


  Velora.invoke(0x9E8FC0,"void", mapObjectHash)


end


function INTERIOR.ENABLE_SHADOW_CULL_MODEL_THIS_FRAME(mapObjectHash)


  Velora.invoke(0x9E8FF0,"void", mapObjectHash)


end


-- PC:0x6170941419D7D8EC Old:0x093ADEA5


function INTERIOR.DISABLE_INTERIOR(interior, toggle)


  Velora.invoke(0x9E9020,"void", interior, toggle)


end


-- PC:0xBC5115A5A939DD15 Old:0x81F34C71


function INTERIOR.IS_INTERIOR_DISABLED(interior)


  return Velora.invoke(0x9E9110,"bool", interior)


end


-- PC:0xD9175F941610DB54 Old:0x34E735A6


function INTERIOR.CAP_INTERIOR(interior, toggle)


  Velora.invoke(0x9E9110,"void", interior, toggle)


end


-- PC:0x92BAC8ACF88CEC26 Old:0x18B17C80


function INTERIOR.IS_INTERIOR_CAPPED(interior)


  return Velora.invoke(0x9E9200,"bool", interior)


end


-- PC:0x9E6542F0CE8E70A3 Old:0x5EF9C5C2


function INTERIOR.DISABLE_METRO_SYSTEM(toggle)


  Velora.invoke(0x9E9200,"void", toggle)


end


function INTERIOR.SET_IS_EXTERIOR_ONLY(entity, toggle)


  Velora.invoke(0x9E9220,"void", entity, toggle)


end


