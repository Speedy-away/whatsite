-- compat_OBJECT.lua — AUTO GENERATO


-- OBJECT


OBJECT=OBJECT or {}


-- PC:0x9A294B2138ABB884 Old:0x58040420


function OBJECT.CREATE_OBJECT_NO_OFFSET(modelHash, x, y, z, isNetwork, bScriptHostObj, dynamic)


  return Velora.invoke(0xA63A80,"int", modelHash, x, y, z, isNetwork, bScriptHostObj, dynamic)


end


-- PC:0x539E0AE3E6634B9F Old:0xD6EF9DA7


function OBJECT.DELETE_OBJECT()


  Velora.invoke(0xA63B20,"void")


end


-- PC:0x58A850EAEE20FAA3 Old:0x8F95A20B


function OBJECT.PLACE_OBJECT_ON_GROUND_PROPERLY(object)


  return Velora.invoke(0xA63CF0,"bool", object)


end


function OBJECT.PLACE_OBJECT_ON_GROUND_OR_OBJECT_PROPERLY(object)


  return Velora.invoke(0xA63BD0,"bool", object)


end


function OBJECT.ROTATE_OBJECT(object, p1, p2, p3)


  return Velora.invoke(0xA63C70,"bool", object, p1, p2, p3)


end


-- PC:0x2FDFF4107B8C1147 Old:0x63BFA7A0


function OBJECT.SLIDE_OBJECT(object, toX, toY, toZ, speedX, speedY, speedZ, collision)


  return Velora.invoke(0xA63CB0,"bool", object, toX, toY, toZ, speedX, speedY, speedZ, collision)


end


-- PC:0x8A7391690F5AFD81 Old:0x3F88CD86


function OBJECT.SET_OBJECT_TARGETTABLE(object, targettable)


  Velora.invoke(0xA63CF0,"void", object, targettable)


end


-- PC:0x77F33F2CCF64B3AA Old:0x483C5C88


function OBJECT.SET_OBJECT_FORCE_VEHICLES_TO_AVOID(object, toggle)


  Velora.invoke(0xA63E70,"void", object, toggle)


end


-- PC:0xE143FA2249364369 Old:0x45619B33


function OBJECT.GET_CLOSEST_OBJECT_OF_TYPE(x, y, z, radius, modelHash, isMission, p6, p7)


  return Velora.invoke(0xA64220,"int", x, y, z, radius, modelHash, isMission, p6, p7)


end


-- PC:0x8ABFB70C49CC43E2 Old:0xFE21F891


function OBJECT.HAS_OBJECT_BEEN_BROKEN(object, p1)


  return Velora.invoke(0xA63F20,"bool", object, p1)


end


-- PC:0x761B0E69AC4D007E Old:0x6FC0353D


function OBJECT.HAS_CLOSEST_OBJECT_OF_TYPE_BEEN_BROKEN(p0, p1, p2, p3, modelHash, p5)


  return Velora.invoke(0xA63FC0,"bool", p0, p1, p2, p3, modelHash, p5)


end


-- PC:0x46494A2475701343 Old:0x7DB578DD


function OBJECT.HAS_CLOSEST_OBJECT_OF_TYPE_BEEN_COMPLETELY_DESTROYED(x, y, z, radius, modelHash, p5)


  return Velora.invoke(0xA63FF0,"bool", x, y, z, radius, modelHash, p5)


end


function OBJECT.GET_HAS_OBJECT_BEEN_COMPLETELY_DESTROYED(p0)


  return Velora.invoke(0xA64020,"bool", p0)


end


-- PC:0x163E252DE035A133 Old:0x87A42A12


function OBJECT.GET_OFFSET_FROM_COORD_AND_HEADING_IN_WORLD_COORDS(xPos, yPos, zPos, heading, xOffset, yOffset, zOffset)


  local x,y,z=Velora.invoke(0xA64090,"vector3", xPos, yPos, zPos, heading, xOffset, yOffset, zOffset)


  return {x=x,y=y,z=z}


end


-- PC:0x163F8B586BC95F2A Old:0x65213FC3


function OBJECT.GET_COORDS_AND_ROTATION_OF_CLOSEST_OBJECT_OF_TYPE(x, y, z, radius, modelHash, rotationOrder)


  return Velora.invoke(0xA64170,"bool", x, y, z, radius, modelHash, rotationOrder)


end


-- PC:0xF82D8F1926A02C3D Old:0x38C951A4


function OBJECT.SET_STATE_OF_CLOSEST_DOOR_OF_TYPE(type, x, y, z, locked, heading, p6)


  Velora.invoke(0xA64220,"void", type, x, y, z, locked, heading, p6)


end


-- PC:0xEDC1A5B84AEF33FF Old:0x4B44A83D


function OBJECT.GET_STATE_OF_CLOSEST_DOOR_OF_TYPE(type, x, y, z)


  Velora.invoke(0xA64320,"void", type, x, y, z)


end


-- PC:0x9B12F9A24FABEDB0 Old:0x4E0A260B


function OBJECT.SET_LOCKED_UNSTREAMED_IN_DOOR_OF_TYPE(modelHash, x, y, z, locked, xRotMult, yRotMult, zRotMult)


  Velora.invoke(0xA64340,"void", modelHash, x, y, z, locked, xRotMult, yRotMult, zRotMult)


end


function OBJECT.PLAY_OBJECT_AUTO_START_ANIM(p0)


  Velora.invoke(0xA64460,"void", p0)


end


-- PC:0x6F8838D03D1DC226 Old:0x9D2D778D


function OBJECT.ADD_DOOR_TO_SYSTEM(doorHash, modelHash, x, y, z, p5, scriptDoor, isLocal)


  Velora.invoke(0xA644B0,"void", doorHash, modelHash, x, y, z, p5, scriptDoor, isLocal)


end


-- PC:0x464D8E1427156FE4 Old:0x00253286


function OBJECT.REMOVE_DOOR_FROM_SYSTEM(doorHash, p1)


  Velora.invoke(0xA64500,"void", doorHash, p1)


end


-- PC:0x6BAB9442830C7F53 Old:0xDF83DB47


function OBJECT.DOOR_SYSTEM_SET_DOOR_STATE(doorHash, state, requestDoor, forceUpdate)


  Velora.invoke(0xA64520,"void", doorHash, state, requestDoor, forceUpdate)


end


-- PC:0x160AA1B32F6139B8 Old:0xD42A41C2


function OBJECT.DOOR_SYSTEM_GET_DOOR_STATE(doorHash)


  return Velora.invoke(0xA645B0,"int", doorHash)


end


-- PC:0x4BC2854478F3A749 Old:0xD649B7E1


function OBJECT.DOOR_SYSTEM_GET_DOOR_PENDING_STATE(doorHash)


  return Velora.invoke(0xA64580,"int", doorHash)


end


-- PC:0x03C27E13B42A0E82 Old:0x4F44AF21


function OBJECT.DOOR_SYSTEM_SET_AUTOMATIC_RATE(doorHash, rate, requestDoor, forceUpdate)


  Velora.invoke(0xA645B0,"void", doorHash, rate, requestDoor, forceUpdate)


end


-- PC:0x9BA001CB45CBF627 Old:0x47531446


function OBJECT.DOOR_SYSTEM_SET_AUTOMATIC_DISTANCE(doorHash, distance, requestDoor, forceUpdate)


  Velora.invoke(0xA64650,"void", doorHash, distance, requestDoor, forceUpdate)


end


-- PC:0xB6E6FBA95C7324AC Old:0x34883DE3


function OBJECT.DOOR_SYSTEM_SET_OPEN_RATIO(doorHash, ajar, requestDoor, forceUpdate)


  Velora.invoke(0xA646F0,"void", doorHash, ajar, requestDoor, forceUpdate)


end


function OBJECT.DOOR_SYSTEM_GET_AUTOMATIC_DISTANCE(doorHash)


  return Velora.invoke(0xA64870,"float", doorHash)


end


-- PC:0x65499865FCA6E5EC Old:0xB74C3BD7


function OBJECT.DOOR_SYSTEM_GET_OPEN_RATIO(doorHash)


  return Velora.invoke(0xA647E0,"float", doorHash)


end


-- PC:0xC485E07E4F0B7958 Old:0xB4A9A558


function OBJECT.DOOR_SYSTEM_SET_SPRING_REMOVED(doorHash, removed, requestDoor, forceUpdate)


  Velora.invoke(0xA64870,"void", doorHash, removed, requestDoor, forceUpdate)


end


-- PC:0xD9B71952F78A2640 Old:0xECE58AE0


function OBJECT.DOOR_SYSTEM_SET_HOLD_OPEN(doorHash, toggle)


  Velora.invoke(0xA64920,"void", doorHash, toggle)


end


-- PC:0xA85A21582451E951 Old:0xF736227C


function OBJECT.DOOR_SYSTEM_SET_DOOR_OPEN_FOR_RACES(doorHash, p1)


  Velora.invoke(0xA64980,"void", doorHash, p1)


end


-- PC:0xC153C43EA202C8C1 Old:0x5AFCD8A1


function OBJECT.IS_DOOR_REGISTERED_WITH_SYSTEM(doorHash)


  return Velora.invoke(0xA64AC0,"bool", doorHash)


end


-- PC:0xC531EE8A1145A149 Old:0x48659CD7


function OBJECT.IS_DOOR_CLOSED(doorHash)


  return Velora.invoke(0xA64A50,"bool", doorHash)


end


-- PC:0xC7F29CA00F46350E Old:0x9BF33E41


function OBJECT.OPEN_ALL_BARRIERS_FOR_RACE(p0)


  Velora.invoke(0xA64AC0,"void", p0)


end


-- PC:0x701FDA1E82076BA4 Old:0xF592AD10


function OBJECT.CLOSE_ALL_BARRIERS_FOR_RACE()


  Velora.invoke(0xA64AE0,"void")


end


-- PC:0xDF97CDD4FC08FD34 Old:0x17FF9393


function OBJECT.DOOR_SYSTEM_GET_IS_PHYSICS_LOADED(p0)


  return Velora.invoke(0xA64F70,"bool", p0)


end


-- PC:0x589F80B325CC82C5 Old:0xE9AE494F


function OBJECT.DOOR_SYSTEM_FIND_EXISTING_DOOR(x, y, z, modelHash)


  return Velora.invoke(0xA64B30,"bool", x, y, z, modelHash)


end


-- PC:0x90E47239EA1980B8 Old:0xA8B37DEA


function OBJECT.IS_GARAGE_EMPTY(garageHash, p1, p2)


  return Velora.invoke(0xA64BC0,"bool", garageHash, p1, p2)


end


-- PC:0x024A60DEB0EA69F0 Old:0xC33ED360


function OBJECT.IS_PLAYER_ENTIRELY_INSIDE_GARAGE(garageHash, player, p2, p3)


  return Velora.invoke(0xA64C50,"bool", garageHash, player, p2, p3)


end


-- PC:0x1761DC5D8471CBAA Old:0x41924877


function OBJECT.IS_PLAYER_PARTIALLY_INSIDE_GARAGE(garageHash, player, p2)


  return Velora.invoke(0xA64CF0,"bool", garageHash, player, p2)


end


-- PC:0x85B6C850546FDDE2 Old:0x4BD59750


function OBJECT.ARE_ENTITIES_ENTIRELY_INSIDE_GARAGE(garageHash, p1, p2, p3, p4)


  return Velora.invoke(0xA64D50,"bool", garageHash, p1, p2, p3, p4)


end


-- PC:0x673ED815D6E323B7 Old:0x7B44D659


function OBJECT.IS_ANY_ENTITY_ENTIRELY_INSIDE_GARAGE(garageHash, p1, p2, p3, p4)


  return Velora.invoke(0xA64DC0,"bool", garageHash, p1, p2, p3, p4)


end


-- PC:0x372EF6699146A1E4 Old:0x142C8F76


function OBJECT.IS_OBJECT_ENTIRELY_INSIDE_GARAGE(garageHash, entity, p2, p3)


  return Velora.invoke(0xA64E30,"bool", garageHash, entity, p2, p3)


end


-- PC:0xF0EED5A6BC7B237A Old:0x95A9AB2B


function OBJECT.IS_OBJECT_PARTIALLY_INSIDE_GARAGE(garageHash, entity, p2)


  return Velora.invoke(0xA64EF0,"bool", garageHash, entity, p2)


end


function OBJECT.CLEAR_GARAGE(garageHash, isNetwork)


  Velora.invoke(0xA64F70,"void", garageHash, isNetwork)


end


-- PC:0x190428512B240692 Old:0xA565E27E


function OBJECT.CLEAR_OBJECTS_INSIDE_GARAGE(garageHash, vehicles, peds, objects, isNetwork)


  Velora.invoke(0xA64F90,"void", garageHash, vehicles, peds, objects, isNetwork)


end


function OBJECT.DISABLE_TIDYING_UP_IN_GARAGE(id, toggle)


  Velora.invoke(0xA64FD0,"void", id, toggle)


end


-- PC:0xF2E1A7133DD356A6 Old:0x43BB7E48


function OBJECT.ENABLE_SAVING_IN_GARAGE(garageHash, toggle)


  Velora.invoke(0xA65030,"void", garageHash, toggle)


end


-- PC:0x66A49D021870FE88 Old:0x6158959E


function OBJECT.CLOSE_SAFEHOUSE_GARAGES()


  Velora.invoke(0xA65090,"void")


end


-- PC:0xBFA48E2FF417213F Old:0x23FF2BA4


function OBJECT.DOES_OBJECT_OF_TYPE_EXIST_AT_COORDS(x, y, z, radius, hash, p5)


  return Velora.invoke(0xA651F0,"bool", x, y, z, radius, hash, p5)


end


-- PC:0x2A70BAE8883E4C81 Old:0x73BCFFDC


function OBJECT.IS_POINT_IN_ANGLED_AREA(xPos, yPos, zPos, x1, y1, z1, x2, y2, z2, width, debug, includeZ)


  return Velora.invoke(0xA65110,"bool", xPos, yPos, zPos, x1, y1, z1, x2, y2, z2, width, debug, includeZ)


end


-- PC:0x4D89D607CB3DD1D2 Old:0x19B17769


function OBJECT.SET_OBJECT_ALLOW_LOW_LOD_BUOYANCY(object, toggle)


  Velora.invoke(0xA651F0,"void", object, toggle)


end


-- PC:0xF6DF6E90DE7DF90F Old:0xE8D11C58


function OBJECT.SET_OBJECT_PHYSICS_PARAMS(object, weight, p2, p3, p4, p5, gravity, p7, p8, p9, p10, buoyancy)


  Velora.invoke(0xA65250,"void", object, weight, p2, p3, p4, p5, gravity, p7, p8, p9, p10, buoyancy)


end


-- PC:0xB6FBFD079B8D0596 Old:0xF0B330AD


function OBJECT.GET_OBJECT_FRAGMENT_DAMAGE_HEALTH(p0, p1)


  return Velora.invoke(0xA652F0,"float", p0, p1)


end


-- PC:0x406137F8EF90EAF5 Old:0x3E263AE1


function OBJECT.SET_ACTIVATE_OBJECT_PHYSICS_AS_SOON_AS_IT_IS_UNFROZEN(object, toggle)


  Velora.invoke(0xA652F0,"void", object, toggle)


end


-- PC:0x397DC58FF00298D1 Old:0xE9E46941


function OBJECT.IS_ANY_OBJECT_NEAR_POINT(x, y, z, range, p4)


  return Velora.invoke(0xA65480,"bool", x, y, z, range, p4)


end


-- PC:0x8C90FE4B381BA60A Old:0x50A62C43


function OBJECT.IS_OBJECT_NEAR_POINT(objectHash, x, y, z, range)


  return Velora.invoke(0xA65450,"bool", objectHash, x, y, z, range)


end


-- PC:0x4A39DB43E47CF3AA Old:0xE3261B35


function OBJECT.REMOVE_OBJECT_HIGH_DETAIL_MODEL(object)


  Velora.invoke(0xA65480,"void", object)


end


-- PC:0xE7E4C198B0185900 Old:0x1E82C2AE


function OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(p0, p1, p2)


  Velora.invoke(0xA654B0,"void", p0, p1, p2)


end


function OBJECT.DAMAGE_OBJECT_FRAGMENT_CHILD(p0, p1, p2)


  Velora.invoke(0xA654D0,"void", p0, p1, p2)


end


function OBJECT.FIX_OBJECT_FRAGMENT(object)


  Velora.invoke(0xA654F0,"void", object)


end


-- PC:0xB252BC036B525623 Old:0x46D06B9A


function OBJECT.TRACK_OBJECT_VISIBILITY(object)


  Velora.invoke(0xA65570,"void", object)


end


-- PC:0x8B32ACE6326A7546 Old:0xF4FD8AE4


function OBJECT.IS_OBJECT_VISIBLE(object)


  return Velora.invoke(0xA65620,"bool", object)


end


-- PC:0xC6033D32241F6FB5 Old:0xF4A1A14A


function OBJECT.SET_OBJECT_IS_SPECIAL_GOLFBALL(object, toggle)


  Velora.invoke(0xA65620,"void", object, toggle)


end


-- PC:0xEB6F1A9B5510A5D2 Old:0xAF016CC1


function OBJECT.SET_OBJECT_TAKES_DAMAGE_FROM_COLLIDING_WITH_BUILDINGS(p0, p1)


  Velora.invoke(0xA65680,"void", p0, p1)


end


function OBJECT.ALLOW_DAMAGE_EVENTS_FOR_NON_NETWORKED_OBJECTS(value)


  Velora.invoke(0xA656E0,"void", value)


end


-- PC:0xBCE595371A5FBAAF Old:0x3A68AA46


function OBJECT.SET_CUTSCENES_WEAPON_FLASHLIGHT_ON_THIS_FRAME(object, toggle)


  Velora.invoke(0xA65700,"void", object, toggle)


end


-- PC:0xB48FCED898292E52 Old:0xA286DE96


function OBJECT.GET_RAYFIRE_MAP_OBJECT(x, y, z, radius, name)


  return Velora.invoke(0xA65880,"int", x, y, z, radius, name)


end


-- PC:0x5C29F698D404C5E1 Old:0x21F51560


function OBJECT.SET_STATE_OF_RAYFIRE_MAP_OBJECT(object, state)


  Velora.invoke(0xA65880,"void", object, state)


end


-- PC:0x899BA936634A322E Old:0xF1B8817A


function OBJECT.GET_STATE_OF_RAYFIRE_MAP_OBJECT(object)


  return Velora.invoke(0xA659F0,"int", object)


end


-- PC:0x52AF537A0C5B8AAD Old:0xE08C834D


function OBJECT.DOES_RAYFIRE_MAP_OBJECT_EXIST(object)


  return Velora.invoke(0xA658E0,"bool", object)


end


-- PC:0x260EE4FDBDF4DB01 Old:0x020497DE


function OBJECT.GET_RAYFIRE_MAP_OBJECT_ANIM_PHASE(object)


  return Velora.invoke(0xA65930,"float", object)


end


function OBJECT.FORCE_PICKUP_ROTATE_FACE_UP()


  Velora.invoke(0xA659F0,"void")


end


function OBJECT.SET_CUSTOM_PICKUP_WEAPON_HASH(pickupHash, pickup)


  Velora.invoke(0xA65A00,"void", pickupHash, pickup)


end


-- PC:0x673966A0C0FD7171 Old:0x17B99CE7


function OBJECT.CREATE_AMBIENT_PICKUP(pickupHash, posX, posY, posZ, flags, value, modelHash, p7, p8)


  return Velora.invoke(0xA65AF0,"int", pickupHash, posX, posY, posZ, flags, value, modelHash, p7, p8)


end


function OBJECT.CREATE_NON_NETWORKED_AMBIENT_PICKUP(pickupHash, posX, posY, posZ, flags, value, modelHash, p7, p8)


  return Velora.invoke(0xA65A90,"int", pickupHash, posX, posY, posZ, flags, value, modelHash, p7, p8)


end


function OBJECT.BLOCK_PLAYERS_FOR_AMBIENT_PICKUP(p0, p1)


  Velora.invoke(0xA65AF0,"void", p0, p1)


end


-- PC:0x2EAF1FDB2FB55698 Old:0x8C886BE5


function OBJECT.CREATE_PORTABLE_PICKUP(pickupHash, x, y, z, placeOnGround, modelHash)


  return Velora.invoke(0xA65BC0,"int", pickupHash, x, y, z, placeOnGround, modelHash)


end


-- PC:0x125494B98A21AAF7 Old:0x56A02502


function OBJECT.CREATE_NON_NETWORKED_PORTABLE_PICKUP(pickupHash, x, y, z, placeOnGround, modelHash)


  return Velora.invoke(0xA65B80,"int", pickupHash, x, y, z, placeOnGround, modelHash)


end


-- PC:0x8DC39368BDD57755 Old:0x184F6AB3


function OBJECT.ATTACH_PORTABLE_PICKUP_TO_PED(pickupObject, ped)


  Velora.invoke(0xA65BC0,"void", pickupObject, ped)


end


-- PC:0xCF463D1E9A0AECB1 Old:0x1D094562


function OBJECT.DETACH_PORTABLE_PICKUP_FROM_PED(pickupObject)


  Velora.invoke(0xA65BD0,"void", pickupObject)


end


function OBJECT.FORCE_PORTABLE_PICKUP_LAST_ACCESSIBLE_POSITION_SETTING(object)


  Velora.invoke(0xA65C50,"void", object)


end


-- PC:0x867458251D47CCB2 Old:0x1F63B042


function OBJECT.HIDE_PORTABLE_PICKUP_WHEN_DETACHED(pickupObject, toggle)


  Velora.invoke(0xA65CA0,"void", pickupObject, toggle)


end


-- PC:0x0BF3B3BD47D79C08 Old:0x7EFBA039


function OBJECT.SET_MAX_NUM_PORTABLE_PICKUPS_CARRIED_BY_PLAYER(modelHash, number)


  Velora.invoke(0xA65D00,"void", modelHash, number)


end


-- PC:0x78857FC65CADB909 Old:0xA3CDF152


function OBJECT.SET_LOCAL_PLAYER_CAN_COLLECT_PORTABLE_PICKUPS(toggle)


  Velora.invoke(0xA65DC0,"void", toggle)


end


-- PC:0x6E16BC2503FF1FF0 Old:0x618B5F67


function OBJECT.GET_SAFE_PICKUP_COORDS(x, y, z, p3, p4)


  local x,y,z=Velora.invoke(0xA65F20,"vector3", x, y, z, p3, p4)


  return {x=x,y=y,z=z}


end


function OBJECT.ADD_EXTENDED_PICKUP_PROBE_AREA(x, y, z, radius)


  Velora.invoke(0xA65F20,"void", x, y, z, radius)


end


function OBJECT.CLEAR_EXTENDED_PICKUP_PROBE_AREAS()


  Velora.invoke(0xA65F90,"void")


end


-- PC:0x225B8B35C88029B3 Old:0xC2E1E2C5


function OBJECT.GET_PICKUP_COORDS(pickup)


  local x,y,z=Velora.invoke(0xA66040,"vector3", pickup)


  return {x=x,y=y,z=z}


end


function OBJECT.SUPPRESS_PICKUP_SOUND_FOR_PICKUP(p0, p1)


  Velora.invoke(0xA66040,"void", p0, p1)


end


-- PC:0x27F9D613092159CF Old:0x40062C53


function OBJECT.REMOVE_ALL_PICKUPS_OF_TYPE(pickupHash)


  Velora.invoke(0xA660A0,"void", pickupHash)


end


-- PC:0x80EC48E6679313F9 Old:0x0BE5CCED


function OBJECT.HAS_PICKUP_BEEN_COLLECTED(pickup)


  return Velora.invoke(0xA660F0,"bool", pickup)


end


-- PC:0x3288D8ACAECD2AB2 Old:0x64A7A0E0


function OBJECT.REMOVE_PICKUP(pickup)


  Velora.invoke(0xA660F0,"void", pickup)


end


-- PC:0x0589B5E791CE9B2B Old:0x36C9A5EA


function OBJECT.CREATE_MONEY_PICKUPS(x, y, z, value, amount, model)


  Velora.invoke(0xA66100,"void", x, y, z, value, amount, model)


end


-- PC:0xAFC1CA75AD4074D1 Old:0x9C6DA0B3


function OBJECT.DOES_PICKUP_EXIST(pickup)


  return Velora.invoke(0xA663A0,"bool", pickup)


end


-- PC:0xD9EFB6DBF7DAAEA3 Old:0xE0B32108


function OBJECT.DOES_PICKUP_OBJECT_EXIST(pickupObject)


  return Velora.invoke(0xA66170,"bool", pickupObject)


end


-- PC:0x5099BC55630B25AE Old:0x6052E62E


function OBJECT.GET_PICKUP_OBJECT(pickup)


  return Velora.invoke(0xA661A0,"int", pickup)


end


-- PC:0xFC481C641EBBD27D Old:0x93D23399


function OBJECT.IS_OBJECT_A_PICKUP(object)


  return Velora.invoke(0xA661C0,"bool", object)


end


-- PC:0x0378C08504160D0D Old:0x0F0E94FF


function OBJECT.IS_OBJECT_A_PORTABLE_PICKUP(object)


  return Velora.invoke(0xA66220,"bool", object)


end


-- PC:0xF9C36251F6E48E33 Old:0xF139681B


function OBJECT.DOES_PICKUP_OF_TYPE_EXIST_IN_AREA(pickupHash, x, y, z, radius)


  return Velora.invoke(0xA66280,"bool", pickupHash, x, y, z, radius)


end


-- PC:0x78015C9B4B3ECC9D Old:0xAB11267D


function OBJECT.SET_PICKUP_REGENERATION_TIME(pickup, duration)


  Velora.invoke(0xA663A0,"void", pickup, duration)


end


function OBJECT.FORCE_PICKUP_REGENERATE(p0)


  Velora.invoke(0xA663B0,"void", p0)


end


-- PC:0x616093EC6B139DD9 Old:0x7FADB4B9


function OBJECT.SET_PLAYER_PERMITTED_TO_COLLECT_PICKUPS_OF_TYPE(player, pickupHash, toggle)


  Velora.invoke(0xA66420,"void", player, pickupHash, toggle)


end


-- PC:0x88EAEC617CD26926 Old:0x3A8F1BF7


function OBJECT.SET_LOCAL_PLAYER_PERMITTED_TO_COLLECT_PICKUPS_WITH_MODEL(modelHash, toggle)


  Velora.invoke(0xA66490,"void", modelHash, toggle)


end


function OBJECT.ALLOW_ALL_PLAYERS_TO_COLLECT_PICKUPS_OF_TYPE(pickupHash)


  Velora.invoke(0xA664D0,"void", pickupHash)


end


-- PC:0x53E0DF1A2A3CF0CA Old:0x77687DC5


function OBJECT.SET_TEAM_PICKUP_OBJECT(object, p1, p2)


  Velora.invoke(0xA664F0,"void", object, p1, p2)


end


-- PC:0x92AEFB5F6E294023 Old:0xCBB5F9B6


function OBJECT.PREVENT_COLLECTION_OF_PORTABLE_PICKUP(object, p1, p2)


  Velora.invoke(0xA66580,"void", object, p1, p2)


end


function OBJECT.SET_PICKUP_OBJECT_GLOW_WHEN_UNCOLLECTABLE(pickup, toggle)


  Velora.invoke(0xA66620,"void", pickup, toggle)


end


function OBJECT.SET_PICKUP_GLOW_OFFSET(pickup, p1)


  Velora.invoke(0xA666F0,"void", pickup, p1)


end


-- PC:0xA08FE5E49BDC39DD Old:0x276A7807


function OBJECT.SET_PICKUP_OBJECT_GLOW_OFFSET(pickup, p1, p2)


  Velora.invoke(0xA66740,"void", pickup, p1, p2)


end


function OBJECT.SET_OBJECT_GLOW_IN_SAME_TEAM(pickup)


  Velora.invoke(0xA667C0,"void", pickup)


end


function OBJECT.SET_PICKUP_OBJECT_ARROW_MARKER(pickup, toggle)


  Velora.invoke(0xA66810,"void", pickup, toggle)


end


function OBJECT.ALLOW_PICKUP_ARROW_MARKER_WHEN_UNCOLLECTABLE(pickup, toggle)


  Velora.invoke(0xA66870,"void", pickup, toggle)


end


-- PC:0xDB41D07A45A6D4B7 Old:0x000E92DC


function OBJECT.GET_DEFAULT_AMMO_FOR_WEAPON_PICKUP(pickupHash)


  return Velora.invoke(0xA66960,"int", pickupHash)


end


-- PC:0x318516E02DE3ECE2 Old:0x9879AC51


function OBJECT.SET_PICKUP_GENERATION_RANGE_MULTIPLIER(multiplier)


  Velora.invoke(0xA66960,"void", multiplier)


end


function OBJECT.GET_PICKUP_GENERATION_RANGE_MULTIPLIER()


  return Velora.invoke(0xA66A10,"float")


end


-- PC:0x31F924B53EADDF65 Old:0xDB18FA01


function OBJECT.SET_ONLY_ALLOW_AMMO_COLLECTION_WHEN_LOW(p0)


  Velora.invoke(0xA66A10,"void", p0)


end


function OBJECT.SET_PICKUP_UNCOLLECTABLE(pickup, toggle)


  Velora.invoke(0xA66A30,"void", pickup, toggle)


end


function OBJECT.SET_PICKUP_TRANSPARENT_WHEN_UNCOLLECTABLE(pickup, toggle)


  Velora.invoke(0xA66A80,"void", pickup, toggle)


end


function OBJECT.SET_PICKUP_HIDDEN_WHEN_UNCOLLECTABLE(pickup, toggle)


  Velora.invoke(0xA66AD0,"void", pickup, toggle)


end


function OBJECT.SET_PICKUP_OBJECT_TRANSPARENT_WHEN_UNCOLLECTABLE(pickup, toggle)


  Velora.invoke(0xA66B20,"void", pickup, toggle)


end


function OBJECT.SET_PICKUP_OBJECT_ALPHA_WHEN_TRANSPARENT(p0)


  Velora.invoke(0xA66B80,"void", p0)


end


function OBJECT.SET_PORTABLE_PICKUP_PERSIST(pickup, toggle)


  Velora.invoke(0xA66BA0,"void", pickup, toggle)


end


function OBJECT.ALLOW_PORTABLE_PICKUP_TO_MIGRATE_TO_NON_PARTICIPANTS(pickup, toggle)


  Velora.invoke(0xA66C00,"void", pickup, toggle)


end


function OBJECT.FORCE_ACTIVATE_PHYSICS_ON_UNFIXED_PICKUP(pickup, toggle)


  Velora.invoke(0xA66C70,"void", pickup, toggle)


end


function OBJECT.ALLOW_PICKUP_BY_NONE_PARTICIPANT(pickup, toggle)


  Velora.invoke(0xA66CD0,"void", pickup, toggle)


end


-- PC:0xF92099527DB8E2A7 Old:0xA7E936FD


function OBJECT.SUPPRESS_PICKUP_REWARD_TYPE(rewardType, suppress)


  Velora.invoke(0xA66D20,"void", rewardType, suppress)


end


-- PC:0xA2C1F5E92AFE49ED Old:0xB241806C


function OBJECT.CLEAR_ALL_PICKUP_REWARD_TYPE_SUPPRESSION()


  Velora.invoke(0xA66D50,"void")


end


-- PC:0x762DB2D380B48D04 Old:0xD1BAAFB7


function OBJECT.CLEAR_PICKUP_REWARD_TYPE_SUPPRESSION(rewardType)


  Velora.invoke(0xA66D60,"void", rewardType)


end


-- PC:0x3430676B11CDF21D Old:0x63B02FAD


function OBJECT.RENDER_FAKE_PICKUP_GLOW(x, y, z, colorIndex)


  Velora.invoke(0xA66D80,"void", x, y, z, colorIndex)


end


function OBJECT.SET_PICKUP_OBJECT_COLLECTABLE_IN_VEHICLE(pickup)


  Velora.invoke(0xA66DB0,"void", pickup)


end


function OBJECT.SET_PICKUP_TRACK_DAMAGE_EVENTS(pickup, toggle)


  Velora.invoke(0xA66DF0,"void", pickup, toggle)


end


function OBJECT.SET_ENTITY_FLAG_SUPPRESS_SHADOW(entity, toggle)


  Velora.invoke(0xA66E50,"void", entity, toggle)


end


-- PC:0xB2D0BDE54F0E8E5A Old:0x132B6D92


function OBJECT.SET_ENTITY_FLAG_RENDER_SMALL_SHADOW(object, toggle)


  Velora.invoke(0xA66EA0,"void", object, toggle)


end


-- PC:0x08F96CA6C551AD51 Old:0xEDD01937


function OBJECT.GET_WEAPON_TYPE_FROM_PICKUP_TYPE(pickupHash)


  return Velora.invoke(0xA670C0,"int", pickupHash)


end


function OBJECT.GET_PICKUP_TYPE_FROM_WEAPON_HASH(weaponHash)


  return Velora.invoke(0xA66FA0,"int", weaponHash)


end


-- PC:0x11D1E53A726891FE Old:0x883DAB2D


function OBJECT.IS_PICKUP_WEAPON_OBJECT_VALID(object)


  return Velora.invoke(0xA67010,"bool", object)


end


function OBJECT.GET_OBJECT_TINT_INDEX(object)


  return Velora.invoke(0xA67060,"int", object)


end


function OBJECT.SET_OBJECT_TINT_INDEX(object, textureVariation)


  Velora.invoke(0xA670C0,"void", object, textureVariation)


end


function OBJECT.SET_TINT_INDEX_CLOSEST_BUILDING_OF_TYPE(x, y, z, radius, modelHash, textureVariation)


  return Velora.invoke(0xA67210,"bool", x, y, z, radius, modelHash, textureVariation)


end


function OBJECT.SET_PROP_TINT_INDEX(p0, p1)


  Velora.invoke(0xA67210,"void", p0, p1)


end


function OBJECT.SET_PROP_LIGHT_COLOR(object, p1, r, g, b)


  return Velora.invoke(0xA672F0,"bool", object, p1, r, g, b)


end


function OBJECT.IS_PROP_LIGHT_OVERRIDEN(object)


  return Velora.invoke(0xA672C0,"bool", object)


end


function OBJECT.SET_OBJECT_IS_VISIBLE_IN_MIRRORS(object, toggle)


  Velora.invoke(0xA672F0,"void", object, toggle)


end


function OBJECT.SET_OBJECT_SPEED_BOOST_AMOUNT(object, p1)


  Velora.invoke(0xA67350,"void", object, p1)


end


function OBJECT.SET_OBJECT_SPEED_BOOST_DURATION(object, duration)


  Velora.invoke(0xA673A0,"void", object, duration)


end


-- PC:0x5EAAD83F8CFB4575 Old:0x6AE36192


function OBJECT.CONVERT_OLD_PICKUP_TYPE_TO_NEW(pickupHash)


  return Velora.invoke(0xA67430,"int", pickupHash)


end


-- PC:0xF538081986E49E9D Old:0x3DA41C1A


function OBJECT.SET_FORCE_OBJECT_THIS_FRAME(x, y, z, p3)


  Velora.invoke(0xA67430,"void", x, y, z, p3)


end


-- PC:0xADBE4809F19F927A Old:0x2048A7DD


function OBJECT.ONLY_CLEAN_UP_OBJECT_WHEN_OUT_OF_RANGE(object)


  Velora.invoke(0xA67490,"void", object)


end


function OBJECT.SET_DISABLE_COLLISIONS_BETWEEN_CARS_AND_CAR_PARACHUTE(p0)


  Velora.invoke(0xA674D0,"void", p0)


end


function OBJECT.SET_PROJECTILES_SHOULD_EXPLODE_ON_CONTACT(entity, p1)


  Velora.invoke(0xA674F0,"void", entity, p1)


end


function OBJECT.SET_DRIVE_ARTICULATED_JOINT(object, toggle, p2)


  Velora.invoke(0xA67550,"void", object, toggle, p2)


end


function OBJECT.SET_DRIVE_ARTICULATED_JOINT_WITH_INFLICTOR(object, toggle, p2, ped)


  Velora.invoke(0xA675D0,"void", object, toggle, p2, ped)


end


function OBJECT.SET_OBJECT_IS_A_PRESSURE_PLATE(object, toggle)


  Velora.invoke(0xA675F0,"void", object, toggle)


end


function OBJECT.SET_WEAPON_IMPACTS_APPLY_GREATER_FORCE(object, p1)


  Velora.invoke(0xA67650,"void", object, p1)


end


function OBJECT.GET_IS_ARTICULATED_JOINT_AT_MIN_ANGLE(object, p1)


  return Velora.invoke(0xA67790,"bool", object, p1)


end


function OBJECT.GET_IS_ARTICULATED_JOINT_AT_MAX_ANGLE(p0, p1)


  return Velora.invoke(0xA67720,"bool", p0, p1)


end


function OBJECT.SET_IS_OBJECT_ARTICULATED(object, toggle)


  Velora.invoke(0xA67790,"void", object, toggle)


end


function OBJECT.SET_IS_OBJECT_BALL(object, toggle)


  Velora.invoke(0xA677F0,"void", object, toggle)


end


