-- compat_AUDIO.lua — AUTO GENERATO


-- AUDIO


AUDIO=AUDIO or {}


-- PC:0xF9E56683CA8E11A5 Old:0x1D530E47


function AUDIO.PLAY_PED_RINGTONE(ringtoneName, ped, p2)


  Velora.invoke(0x982850,"void", ringtoneName, ped, p2)


end


-- PC:0x1E8E5E20937E3137 Old:0xFE576EE4


function AUDIO.IS_PED_RINGTONE_PLAYING(ped)


  return Velora.invoke(0x9828E0,"bool", ped)


end


-- PC:0x6C5AE23EFA885092 Old:0xFEEA107C


function AUDIO.STOP_PED_RINGTONE(ped)


  Velora.invoke(0x9828E0,"void", ped)


end


-- PC:0x7497D2CE2C30D24C Old:0x4ED1400A


function AUDIO.IS_MOBILE_PHONE_CALL_ONGOING()


  return Velora.invoke(0x9829E0,"bool")


end


-- PC:0xC8B1B2425604CDD0 Old:0x16FB88B5


function AUDIO.IS_MOBILE_INTERFERENCE_ACTIVE()


  return Velora.invoke(0x982970,"bool")


end


-- PC:0xD2C91A0B572AAE56 Old:0xB2BC25F8


function AUDIO.CREATE_NEW_SCRIPTED_CONVERSATION()


  Velora.invoke(0x9829E0,"void")


end


-- PC:0xC5EF963405593646 Old:0x96CD0513


function AUDIO.ADD_LINE_TO_CONVERSATION(index, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)


  Velora.invoke(0x982A00,"void", index, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)


end


-- PC:0x95D9F4BC443956E7 Old:0xF8D5EB86


function AUDIO.ADD_PED_TO_CONVERSATION(index, ped, p2)


  Velora.invoke(0x982AF0,"void", index, ped, p2)


end


-- PC:0x33E3C6C6F2F0B506 Old:0x73C6F979


function AUDIO.SET_POSITION_FOR_NULL_CONV_PED(p0, p1, p2, p3)


  Velora.invoke(0x982B70,"void", p0, p1, p2, p3)


end


-- PC:0x892B6AB8F33606F5 Old:0x88203DDA


function AUDIO.SET_ENTITY_FOR_NULL_CONV_PED(p0, entity)


  Velora.invoke(0x982BE0,"void", p0, entity)


end


-- PC:0xB6AE90EDDE95C762 Old:0xAD7BB191


function AUDIO.SET_MICROPHONE_POSITION(toggle, x1, y1, z1, x2, y2, z2, x3, y3, z3)


  Velora.invoke(0x982C40,"void", toggle, x1, y1, z1, x2, y2, z2, x3, y3, z3)


end


-- PC:0x0B568201DD99F0EB Old:0x1193ED6E


function AUDIO.SET_CONVERSATION_AUDIO_CONTROLLED_BY_ANIM(p0)


  Velora.invoke(0x982D30,"void", p0)


end


function AUDIO.SET_CONVERSATION_AUDIO_PLACEHOLDER(p0)


  Velora.invoke(0x982D50,"void", p0)


end


-- PC:0x252E5F915EABB675 Old:0x38E42D07


function AUDIO.START_SCRIPT_PHONE_CONVERSATION(p0, p1)


  Velora.invoke(0x982D70,"void", p0, p1)


end


-- PC:0x6004BCB0E226AAEA Old:0x9ACB213A


function AUDIO.PRELOAD_SCRIPT_PHONE_CONVERSATION(p0, p1)


  Velora.invoke(0x982DC0,"void", p0, p1)


end


-- PC:0x6B17C62C9635D2DC Old:0xE5DE7D9D


function AUDIO.START_SCRIPT_CONVERSATION(p0, p1, p2, p3)


  Velora.invoke(0x982E10,"void", p0, p1, p2, p3)


end


-- PC:0x3B3CAD6166916D87 Old:0xDDF5C579


function AUDIO.PRELOAD_SCRIPT_CONVERSATION(p0, p1, p2, p3)


  Velora.invoke(0x982E70,"void", p0, p1, p2, p3)


end


-- PC:0x23641AFE870AF385 Old:0xA170261B


function AUDIO.START_PRELOADED_CONVERSATION()


  Velora.invoke(0x982ED0,"void")


end


-- PC:0xE73364DB90778FFA Old:0x336F3D35


function AUDIO.GET_IS_PRELOADED_CONVERSATION_READY()


  return Velora.invoke(0x982FC0,"bool")


end


-- PC:0x16754C556D2EDE3D Old:0xCB8FD96F


function AUDIO.IS_SCRIPTED_CONVERSATION_ONGOING()


  return Velora.invoke(0x982F20,"bool")


end


-- PC:0xDF0D54BE7A776737 Old:0xE1870EA9


function AUDIO.IS_SCRIPTED_CONVERSATION_LOADED()


  return Velora.invoke(0x982F60,"bool")


end


-- PC:0x480357EE890C295A Old:0x9620E41F


function AUDIO.GET_CURRENT_SCRIPTED_CONVERSATION_LINE()


  return Velora.invoke(0x982F90,"int")


end


-- PC:0x8530AD776CD72B12 Old:0xE2C9C6F8


function AUDIO.PAUSE_SCRIPTED_CONVERSATION(p0)


  Velora.invoke(0x982FC0,"void", p0)


end


-- PC:0x9AEB285D1818C9AC Old:0x6CB24B56


function AUDIO.RESTART_SCRIPTED_CONVERSATION()


  Velora.invoke(0x982FF0,"void")


end


-- PC:0xD79DEEFB53455EBA Old:0xAB77DA7D


function AUDIO.STOP_SCRIPTED_CONVERSATION(p0)


  return Velora.invoke(0x983040,"int", p0)


end


-- PC:0x9663FE6B7A61EB00 Old:0x85C98304


function AUDIO.SKIP_TO_NEXT_SCRIPTED_CONVERSATION_LINE()


  Velora.invoke(0x983040,"void")


end


-- PC:0xA018A12E5C5C2FA6 Old:0xF3A67AF3


function AUDIO.INTERRUPT_CONVERSATION(ped, voiceline, speaker)


  Velora.invoke(0x983050,"void", ped, voiceline, speaker)


end


-- PC:0x8A694D7A68F8DC38 Old:0xDD4A3F1F


function AUDIO.INTERRUPT_CONVERSATION_AND_PAUSE(ped, p1, speaker)


  Velora.invoke(0x9830D0,"void", ped, p1, speaker)


end


-- PC:0xAA19F5572C38B564 Old:0xB58B8FF3


function AUDIO.GET_VARIATION_CHOSEN_FOR_SCRIPTED_LINE(p0)


  return Velora.invoke(0x9831B0,"int", p0)


end


-- PC:0xB542DE8C3D1CB210 Old:0x789D8C6C


function AUDIO.SET_NO_DUCKING_FOR_CONVERSATION(p0)


  Velora.invoke(0x9831B0,"void", p0)


end


-- PC:0xC6ED9D5092438D91 Old:0xA6203643


function AUDIO.REGISTER_SCRIPT_WITH_AUDIO(p0)


  Velora.invoke(0x9831D0,"void", p0)


end


-- PC:0xA8638BE228D4751A Old:0x66728EFE


function AUDIO.UNREGISTER_SCRIPT_WITH_AUDIO()


  Velora.invoke(0x9831E0,"void")


end


-- PC:0x7345BDD95E62E0F2 Old:0x916E37CA


function AUDIO.REQUEST_MISSION_AUDIO_BANK(audioBank, p1, p2)


  return Velora.invoke(0x983310,"bool", audioBank, p1, p2)


end


-- PC:0xFE02FFBED8CA9D99 Old:0x23C88BC7


function AUDIO.REQUEST_AMBIENT_AUDIO_BANK(audioBank, p1, p2)


  return Velora.invoke(0x983230,"bool", audioBank, p1, p2)


end


-- PC:0x2F844A8B08D76685 Old:0x21322887


function AUDIO.REQUEST_SCRIPT_AUDIO_BANK(audioBank, p1, p2)


  return Velora.invoke(0x983270,"bool", audioBank, p1, p2)


end


function AUDIO.HINT_MISSION_AUDIO_BANK(audioBank, p1, p2)


  return Velora.invoke(0x9832B0,"bool", audioBank, p1, p2)


end


-- PC:0x8F8C0E370AE62F5C Old:0xF1850DDC


function AUDIO.HINT_AMBIENT_AUDIO_BANK(audioBank, p1, p2)


  return Velora.invoke(0x9832D0,"bool", audioBank, p1, p2)


end


-- PC:0xFB380A29641EC31A Old:0x41FA0E51


function AUDIO.HINT_SCRIPT_AUDIO_BANK(audioBank, p1, p2)


  return Velora.invoke(0x9832F0,"bool", audioBank, p1, p2)


end


-- PC:0x0EC92A1BF0857187 Old:0x8E8824C7


function AUDIO.RELEASE_MISSION_AUDIO_BANK()


  Velora.invoke(0x983310,"void")


end


-- PC:0x65475A218FFAA93D Old:0x8C938784


function AUDIO.RELEASE_AMBIENT_AUDIO_BANK()


  Velora.invoke(0x983320,"void")


end


-- PC:0x77ED170667F50170 Old:0x16707ABC


function AUDIO.RELEASE_NAMED_SCRIPT_AUDIO_BANK(audioBank)


  Velora.invoke(0x983330,"void", audioBank)


end


-- PC:0x7A2D8AD0A9EB9C3F Old:0x22F865E5


function AUDIO.RELEASE_SCRIPT_AUDIO_BANK()


  Velora.invoke(0x983350,"void")


end


-- PC:0x19AF7ED9B9D23058 Old:0xA58BBF4F


function AUDIO.UNHINT_AMBIENT_AUDIO_BANK()


  Velora.invoke(0x983360,"void")


end


-- PC:0x9AC92EED5E4793AB Old:0xE67446E9


function AUDIO.UNHINT_SCRIPT_AUDIO_BANK()


  Velora.invoke(0x983370,"void")


end


function AUDIO.UNHINT_NAMED_SCRIPT_AUDIO_BANK(audioBank)


  Velora.invoke(0x983380,"void", audioBank)


end


-- PC:0x430386FE9BF80B45 Old:0x6AE0AD56


function AUDIO.GET_SOUND_ID()


  return Velora.invoke(0x9833D0,"int")


end


-- PC:0x353FC880830B88FA Old:0x9C080899


function AUDIO.RELEASE_SOUND_ID(soundId)


  Velora.invoke(0x9833D0,"void", soundId)


end


-- PC:0x7FF4944CC209192D Old:0xB6E1917F


function AUDIO.PLAY_SOUND(soundId, audioName, audioRef, p3, p4, p5)


  Velora.invoke(0x9833F0,"void", soundId, audioName, audioRef, p3, p4, p5)


end


-- PC:0x67C540AA08E4A6F5 Old:0x2E458F74


function AUDIO.PLAY_SOUND_FRONTEND(soundId, audioName, audioRef, p3)


  Velora.invoke(0x983430,"void", soundId, audioName, audioRef, p3)


end


-- PC:0xCADA5A0D0702381E Old:0xC70E6CFA


function AUDIO.PLAY_DEFERRED_SOUND_FRONTEND(soundName, soundsetName)


  Velora.invoke(0x983450,"void", soundName, soundsetName)


end


-- PC:0xE65F427EB70AB1ED Old:0x95AE00F8


function AUDIO.PLAY_SOUND_FROM_ENTITY(soundId, audioName, entity, audioRef, isNetwork, p5)


  Velora.invoke(0x9834B0,"void", soundId, audioName, entity, audioRef, isNetwork, p5)


end


function AUDIO.PLAY_SOUND_FROM_ENTITY_HASH(soundId, model, entity, soundSetHash, p4, p5)


  Velora.invoke(0x983540,"void", soundId, model, entity, soundSetHash, p4, p5)


end


-- PC:0x8D8686B622B88120 Old:0xCAD3E2D5


function AUDIO.PLAY_SOUND_FROM_COORD(soundId, audioName, x, y, z, audioRef, isNetwork, range, p8)


  Velora.invoke(0x9835D0,"void", soundId, audioName, x, y, z, audioRef, isNetwork, range, p8)


end


function AUDIO.UPDATE_SOUND_COORD(soundId, x, y, z)


  Velora.invoke(0x983660,"void", soundId, x, y, z)


end


-- PC:0xA3B0C41BA5CC0BB5 Old:0xCD7F4030


function AUDIO.STOP_SOUND(soundId)


  Velora.invoke(0x9836D0,"void", soundId)


end


-- PC:0x2DE3F0A134FFBC0D Old:0x2576F610


function AUDIO.GET_NETWORK_ID_FROM_SOUND_ID(soundId)


  return Velora.invoke(0x983750,"int", soundId)


end


-- PC:0x75262FD12D0A1C84 Old:0xD064D4DC


function AUDIO.GET_SOUND_ID_FROM_NETWORK_ID(netId)


  return Velora.invoke(0x983720,"int", netId)


end


-- PC:0xAD6B3148A78AE9B6 Old:0x606EE5FA


function AUDIO.SET_VARIABLE_ON_SOUND(soundId, variable, p2)


  Velora.invoke(0x983750,"void", soundId, variable, p2)


end


-- PC:0x2F9D3834AEB9EF79 Old:0xF67BB44C


function AUDIO.SET_VARIABLE_ON_STREAM(variable, p1)


  Velora.invoke(0x983770,"void", variable, p1)


end


-- PC:0xF2A9CDABCEA04BD6 Old:0x9A083B7E


function AUDIO.OVERRIDE_UNDERWATER_STREAM(p0, p1)


  Velora.invoke(0x983790,"void", p0, p1)


end


-- PC:0x733ADF241531E5C2 Old:0x62D026BE


function AUDIO.SET_VARIABLE_ON_UNDER_WATER_STREAM(variableName, value)


  Velora.invoke(0x9837B0,"void", variableName, value)


end


-- PC:0xFCBDCE714A7C88E5 Old:0xE85AEC2E


function AUDIO.HAS_SOUND_FINISHED(soundId)


  return Velora.invoke(0x983800,"bool", soundId)


end


-- PC:0x8E04FEDD28D42462 Old:0x5C57B85D


function AUDIO.PLAY_PED_AMBIENT_SPEECH_NATIVE(ped, speechName, speechParam, p3)


  Velora.invoke(0x983800,"void", ped, speechName, speechParam, p3)


end


-- PC:0xC6941B4A3A8FBBB9 Old:0x444180DB


function AUDIO.PLAY_PED_AMBIENT_SPEECH_AND_CLONE_NATIVE(ped, speechName, speechParam, p3)


  Velora.invoke(0x983820,"void", ped, speechName, speechParam, p3)


end


-- PC:0x3523634255FC3318 Old:0x8386AE28


function AUDIO.PLAY_PED_AMBIENT_SPEECH_WITH_VOICE_NATIVE(ped, speechName, voiceName, speechParam, p4)


  Velora.invoke(0x983840,"void", ped, speechName, voiceName, speechParam, p4)


end


-- PC:0xED640017ED337E45 Old:0xA1A1402E


function AUDIO.PLAY_AMBIENT_SPEECH_FROM_POSITION_NATIVE(speechName, voiceName, x, y, z, speechParam)


  Velora.invoke(0x983870,"void", speechName, voiceName, x, y, z, speechParam)


end


-- PC:0x13AD665062541A7E Old:0x05B9B5CF


function AUDIO.OVERRIDE_TREVOR_RAGE(voiceEffect)


  Velora.invoke(0x983900,"void", voiceEffect)


end


-- PC:0xE78503B10C4314E0 Old:0xE80CF0D4


function AUDIO.RESET_TREVOR_RAGE()


  Velora.invoke(0x983920,"void")


end


-- PC:0xEA241BB04110F091 Old:0x782CA58D


function AUDIO.SET_PLAYER_ANGRY(ped, toggle)


  Velora.invoke(0x983930,"void", ped, toggle)


end


-- PC:0xBC9AE166038A5CEC Old:0x874BD6CB


function AUDIO.PLAY_PAIN(ped, painID, p1, p3)


  Velora.invoke(0x983990,"void", ped, painID, p1, p3)


end


-- PC:0xCE4AC0439F607045 Old:0x6096504C


function AUDIO.RELEASE_WEAPON_AUDIO()


  Velora.invoke(0x9839B0,"void")


end


-- PC:0xD01005D2BA2EB778 Old:0x59A3A17D


function AUDIO.ACTIVATE_AUDIO_SLOWMO_MODE(mode)


  Velora.invoke(0x9839C0,"void", mode)


end


-- PC:0xDDC635D5B3262C56 Old:0x0E387BFE


function AUDIO.DEACTIVATE_AUDIO_SLOWMO_MODE(mode)


  Velora.invoke(0x983A00,"void", mode)


end


-- PC:0x6C8065A3B780185B Old:0xBD2EA1A1


function AUDIO.SET_AMBIENT_VOICE_NAME(ped, name)


  Velora.invoke(0x983A40,"void", ped, name)


end


function AUDIO.SET_AMBIENT_VOICE_NAME_HASH(ped, hash)


  Velora.invoke(0x983AB0,"void", ped, hash)


end


function AUDIO.GET_AMBIENT_VOICE_NAME_HASH(ped)


  return Velora.invoke(0x983B70,"int", ped)


end


function AUDIO.SET_PED_VOICE_FULL(ped)


  Velora.invoke(0x983B70,"void", ped)


end


function AUDIO.SET_PED_RACE_AND_VOICE_GROUP(ped, p1, voiceGroup)


  Velora.invoke(0x983BD0,"void", ped, p1, voiceGroup)


end


function AUDIO.SET_PED_VOICE_GROUP(ped, voiceGroupHash)


  Velora.invoke(0x983C40,"void", ped, voiceGroupHash)


end


function AUDIO.SET_PED_VOICE_GROUP_FROM_RACE_TO_PVG(ped, voiceGroupHash)


  Velora.invoke(0x983CA0,"void", ped, voiceGroupHash)


end


function AUDIO.SET_PED_GENDER(ped, p1)


  Velora.invoke(0x983D30,"void", ped, p1)


end


-- PC:0x7A73D05A607734C7 Old:0x5B7463F4


function AUDIO.STOP_CURRENT_PLAYING_SPEECH(ped)


  Velora.invoke(0x983D90,"void", ped)


end


-- PC:0xB8BEC0CA6F0EDB0F Old:0xBB8E64BF


function AUDIO.STOP_CURRENT_PLAYING_AMBIENT_SPEECH(ped)


  Velora.invoke(0x983DE0,"void", ped)


end


-- PC:0x9072C8B49907BFAD Old:0x1972E8AA


function AUDIO.IS_AMBIENT_SPEECH_PLAYING(ped)


  return Velora.invoke(0x984150,"bool", ped)


end


-- PC:0xCC9AA18DCC7084F4 Old:0x2C653904


function AUDIO.IS_SCRIPTED_SPEECH_PLAYING(p0)


  return Velora.invoke(0x983EA0,"bool", p0)


end


-- PC:0x729072355FA39EC9 Old:0x2B74A6D6


function AUDIO.IS_ANY_SPEECH_PLAYING(ped)


  return Velora.invoke(0x983F10,"bool", ped)


end


function AUDIO.IS_ANY_POSITIONAL_SPEECH_PLAYING()


  return Velora.invoke(0x983FA0,"bool")


end


-- PC:0x49B99BF3FDA89A7A Old:0x8BD5F11E


function AUDIO.DOES_CONTEXT_EXIST_FOR_THIS_PED(ped, speechName, p2)


  return Velora.invoke(0x984000,"bool", ped, speechName, p2)


end


-- PC:0x049E937F18F4020C Old:0x7B2F0743


function AUDIO.IS_PED_IN_CURRENT_CONVERSATION(ped)


  return Velora.invoke(0x9840E0,"bool", ped)


end


-- PC:0x95D2D383D5396B8A Old:0xD2EA77A3


function AUDIO.SET_PED_IS_DRUNK(ped, toggle)


  Velora.invoke(0x984150,"void", ped, toggle)


end


-- PC:0xEE066C7006C49C0A Old:0x498849F3


function AUDIO.PLAY_ANIMAL_VOCALIZATION(pedHandle, p1, speechName)


  Velora.invoke(0x9841B0,"void", pedHandle, p1, speechName)


end


-- PC:0xC265DF9FB44A9FBD Old:0x0CBAF2EF


function AUDIO.IS_ANIMAL_VOCALIZATION_PLAYING(pedHandle)


  return Velora.invoke(0x9842F0,"bool", pedHandle)


end


-- PC:0xCC97B29285B1DC3B Old:0x3EA7C6CB


function AUDIO.SET_ANIMAL_MOOD(animal, mood)


  Velora.invoke(0x9842F0,"void", animal, mood)


end


-- PC:0xB35CE999E8EF317E Old:0x6E502A5B


function AUDIO.IS_MOBILE_PHONE_RADIO_ACTIVE()


  return Velora.invoke(0x9843C0,"bool")


end


-- PC:0xBF286C554784F3DF Old:0xE1E0ED34


function AUDIO.SET_MOBILE_PHONE_RADIO_STATE(state)


  Velora.invoke(0x9843C0,"void", state)


end


-- PC:0xE8AF77C4C06ADC93 Old:0x1C4946AC


function AUDIO.GET_PLAYER_RADIO_STATION_INDEX()


  return Velora.invoke(0x984520,"int")


end


-- PC:0xA571991A7FE6CCEB Old:0x872CF0EA


function AUDIO.GET_PLAYER_RADIO_STATION_GENRE()


  return Velora.invoke(0x984490,"int")


end


-- PC:0xA151A7394A214E65 Old:0xCF29097B


function AUDIO.IS_RADIO_RETUNING()


  return Velora.invoke(0x9844C0,"bool")


end


-- PC:0x0626A247D2405330 Old:0x815CAE99


function AUDIO.IS_RADIO_FADED_OUT()


  return Velora.invoke(0x9844F0,"bool")


end


-- PC:0xFF266D1D0EB1195D Old:0x53DB6994


function AUDIO.SET_RADIO_RETUNE_UP()


  Velora.invoke(0x984520,"void")


end


-- PC:0xDD6BCF9E94425DF9 Old:0xD70ECC80


function AUDIO.SET_RADIO_RETUNE_DOWN()


  Velora.invoke(0x984540,"void")


end


-- PC:0xC69EDA28699D5107 Old:0x7B36E35E


function AUDIO.SET_RADIO_TO_STATION_NAME(stationName)


  Velora.invoke(0x984560,"void", stationName)


end


-- PC:0x1B9C0099CB942AC6 Old:0xE391F55F


function AUDIO.SET_VEH_RADIO_STATION(vehicle, radioStation)


  Velora.invoke(0x984580,"void", vehicle, radioStation)


end


function AUDIO.SET_VEH_HAS_NORMAL_RADIO(vehicle)


  Velora.invoke(0x984620,"void", vehicle)


end


function AUDIO.IS_VEHICLE_RADIO_ON(vehicle)


  return Velora.invoke(0x9846E0,"bool", vehicle)


end


-- PC:0xC1805D05E6D4FE10 Old:0x7ABB89D2


function AUDIO.SET_VEH_FORCED_RADIO_THIS_FRAME(vehicle)


  Velora.invoke(0x9846E0,"void", vehicle)


end


-- PC:0xACF57305B12AF907 Old:0x87431585


function AUDIO.SET_EMITTER_RADIO_STATION(emitterName, radioStation, p2)


  Velora.invoke(0x984730,"void", emitterName, radioStation, p2)


end


-- PC:0x399D2D3B33F1B8EB Old:0x91F72E92


function AUDIO.SET_STATIC_EMITTER_ENABLED(emitterName, toggle)


  Velora.invoke(0x984760,"void", emitterName, toggle)


end


function AUDIO.LINK_STATIC_EMITTER_TO_ENTITY(emitterName, entity)


  Velora.invoke(0x984790,"void", emitterName, entity)


end


-- PC:0xA619B168B8A8570F Old:0x1D82766D


function AUDIO.SET_RADIO_TO_STATION_INDEX(radioStation)


  Velora.invoke(0x9847F0,"void", radioStation)


end


-- PC:0xF7F26C6E9CC9EBB8 Old:0xB1172075


function AUDIO.SET_FRONTEND_RADIO_ACTIVE(active)


  Velora.invoke(0x984810,"void", active)


end


-- PC:0xB165AB7C248B2DC1 Old:0xCCD9ABE4


function AUDIO.UNLOCK_MISSION_NEWS_STORY(newsStory)


  Velora.invoke(0x984860,"void", newsStory)


end


-- PC:0x66E49BF55B4B1874 Old:0x27305D37


function AUDIO.IS_MISSION_NEWS_STORY_UNLOCKED(newsStory)


  return Velora.invoke(0x9848C0,"bool", newsStory)


end


-- PC:0x50B196FC9ED6545B Old:0xA2B88CA7


function AUDIO.GET_AUDIBLE_MUSIC_TRACK_TEXT_ID()


  return Velora.invoke(0x984890,"int")


end


-- PC:0xCD536C4D33DCC900 Old:0x8E88B3CC


function AUDIO.PLAY_END_CREDITS_MUSIC(play)


  Velora.invoke(0x9848C0,"void", play)


end


-- PC:0x6DDBBDD98E2E9C25 Old:0x10D36630


function AUDIO.SKIP_RADIO_FORWARD()


  Velora.invoke(0x9848F0,"void")


end


-- PC:0x344F393B027E38C3 Old:0x286BF543


function AUDIO.FREEZE_RADIO_STATION(radioStation)


  Velora.invoke(0x984900,"void", radioStation)


end


-- PC:0xFC00454CF60B91DD Old:0x4D46202C


function AUDIO.UNFREEZE_RADIO_STATION(radioStation)


  Velora.invoke(0x984940,"void", radioStation)


end


-- PC:0xC1AA9F53CE982990 Old:0xA40196BF


function AUDIO.SET_RADIO_AUTO_UNFREEZE(toggle)


  Velora.invoke(0x984960,"void", toggle)


end


-- PC:0x88795F13FACDA88D Old:0x9B069233


function AUDIO.SET_INITIAL_PLAYER_STATION(radioStation)


  Velora.invoke(0x984980,"void", radioStation)


end


-- PC:0x19F21E63AE6EAE4E Old:0x52E054CE


function AUDIO.SET_USER_RADIO_CONTROL_ENABLED(toggle)


  Velora.invoke(0x9849B0,"void", toggle)


end


-- PC:0xB39786F201FEE30B Old:0x76E96212


function AUDIO.SET_RADIO_TRACK(radioStation, radioTrack)


  Velora.invoke(0x984A00,"void", radioStation, radioTrack)


end


function AUDIO.SET_RADIO_TRACK_WITH_START_OFFSET(radioStationName, mixName, p2)


  Velora.invoke(0x984A40,"void", radioStationName, mixName, p2)


end


function AUDIO.SET_NEXT_RADIO_TRACK(radioName, radioTrack, p2, p3)


  Velora.invoke(0x984A80,"void", radioName, radioTrack, p2, p3)


end


-- PC:0xBB6F1CAEC68B0BCE Old:0x8D9EDD99


function AUDIO.SET_VEHICLE_RADIO_LOUD(vehicle, toggle)


  Velora.invoke(0x984AF0,"void", vehicle, toggle)


end


-- PC:0x032A116663A4D5AC Old:0xCBA99F4A


function AUDIO.CAN_VEHICLE_RECEIVE_CB_RADIO(vehicle)


  return Velora.invoke(0x984BC0,"bool", vehicle)


end


-- PC:0x1098355A16064BB3 Old:0x990085F0


function AUDIO.SET_MOBILE_RADIO_ENABLED_DURING_GAMEPLAY(toggle)


  Velora.invoke(0x984BC0,"void", toggle)


end


-- PC:0x109697E2FFBAC8A1 Old:0x46B0C696


function AUDIO.DOES_PLAYER_VEH_HAVE_RADIO()


  return Velora.invoke(0x984C90,"bool")


end


-- PC:0x5F43D83FD6738741 Old:0x2A3E5E8B


function AUDIO.IS_PLAYER_VEH_RADIO_ENABLE()


  return Velora.invoke(0x984C50,"bool")


end


-- PC:0x3B988190C0AA6C0B Old:0x6F812CAB


function AUDIO.SET_VEHICLE_RADIO_ENABLED(vehicle, toggle)


  Velora.invoke(0x984C90,"void", vehicle, toggle)


end


function AUDIO.SET_POSITIONED_PLAYER_VEHICLE_RADIO_EMITTER_ENABLED(p0)


  Velora.invoke(0x984D00,"void", p0)


end


-- PC:0x4E404A9361F75BB2 Old:0x128C3873


function AUDIO.SET_CUSTOM_RADIO_TRACK_LIST(radioStation, trackListName, p2)


  Velora.invoke(0x984D20,"void", radioStation, trackListName, p2)


end


-- PC:0x1654F24A88A8E3FE Old:0x1D766976


function AUDIO.CLEAR_CUSTOM_RADIO_TRACK_LIST(radioStation)


  Velora.invoke(0x984DA0,"void", radioStation)


end


-- PC:0xF1620ECB50E01DE7 Old:0xCC91FCF5


function AUDIO.GET_NUM_UNLOCKED_RADIO_STATIONS()


  return Velora.invoke(0x984E10,"int")


end


-- PC:0x8D67489793FF428B Old:0xECA1512F


function AUDIO.FIND_RADIO_STATION_INDEX(stationNameHash)


  return Velora.invoke(0x984DD0,"int", stationNameHash)


end


-- PC:0x774BD811F656A122 Old:0xB1FF7137


function AUDIO.SET_RADIO_STATION_MUSIC_ONLY(radioStation, toggle)


  Velora.invoke(0x984E10,"void", radioStation, toggle)


end


-- PC:0x2C96CDB04FCA358E Old:0xC8B514E2


function AUDIO.SET_RADIO_FRONTEND_FADE_TIME(fadeTime)


  Velora.invoke(0x984E40,"void", fadeTime)


end


-- PC:0x031ACB6ABA18C729 Old:0xBE998184


function AUDIO.UNLOCK_RADIO_STATION_TRACK_LIST(radioStation, trackListName)


  Velora.invoke(0x984E60,"void", radioStation, trackListName)


end


function AUDIO.LOCK_RADIO_STATION_TRACK_LIST(radioStation, trackListName)


  Velora.invoke(0x984EA0,"void", radioStation, trackListName)


end


function AUDIO.UPDATE_UNLOCKABLE_DJ_RADIO_TRACKS(enableMixes)


  Velora.invoke(0x984F10,"void", enableMixes)


end


function AUDIO.LOCK_RADIO_STATION(radioStationName, toggle)


  Velora.invoke(0x984F20,"void", radioStationName, toggle)


end


function AUDIO.SET_RADIO_STATION_AS_FAVOURITE(radioStation, toggle)


  Velora.invoke(0x984F70,"void", radioStation, toggle)


end


function AUDIO.IS_RADIO_STATION_FAVOURITED(radioStation)


  return Velora.invoke(0x985030,"bool", radioStation)


end


function AUDIO.GET_NEXT_AUDIBLE_BEAT()


  return Velora.invoke(0x984FF0,"bool")


end


function AUDIO.FORCE_MUSIC_TRACK_LIST(radioStation, trackListName, milliseconds)


  Velora.invoke(0x985030,"void", radioStation, trackListName, milliseconds)


end


function AUDIO.GET_CURRENT_TRACK_PLAY_TIME(radioStationName)


  return Velora.invoke(0x985110,"int", radioStationName)


end


function AUDIO.GET_CURRENT_TRACK_SOUND_NAME(radioStationName)


  return Velora.invoke(0x9850D0,"int", radioStationName)


end


-- PC:0xF3365489E0DD50F9 Old:0x8AFC488D


function AUDIO.SET_VEHICLE_MISSILE_WARNING_ENABLED(vehicle, toggle)


  Velora.invoke(0x985110,"void", vehicle, toggle)


end


-- PC:0xBDA07E5950085E46 Old:0x2849CAC9


function AUDIO.SET_AMBIENT_ZONE_STATE(zoneName, p1, p2)


  Velora.invoke(0x985180,"void", zoneName, p1, p2)


end


-- PC:0x218DD44AAAC964FF Old:0xCDFF3C82


function AUDIO.CLEAR_AMBIENT_ZONE_STATE(zoneName, p1)


  Velora.invoke(0x9851C0,"void", zoneName, p1)


end


-- PC:0x9748FA4DE50CCE3E Old:0xBF80B412


function AUDIO.SET_AMBIENT_ZONE_LIST_STATE(ambientZone, p1, p2)


  Velora.invoke(0x985200,"void", ambientZone, p1, p2)


end


-- PC:0x120C48C614909FA4 Old:0x38B9B8D4


function AUDIO.CLEAR_AMBIENT_ZONE_LIST_STATE(ambientZone, p1)


  Velora.invoke(0x985290,"void", ambientZone, p1)


end


-- PC:0x1D6650420CEC9D3B Old:0xC1FFB672


function AUDIO.SET_AMBIENT_ZONE_STATE_PERSISTENT(ambientZone, p1, p2)


  Velora.invoke(0x985310,"void", ambientZone, p1, p2)


end


-- PC:0xF3638DAE8C4045E1 Old:0x5F5A2605


function AUDIO.SET_AMBIENT_ZONE_LIST_STATE_PERSISTENT(ambientZone, p1, p2)


  Velora.invoke(0x985350,"void", ambientZone, p1, p2)


end


-- PC:0x01E2817A479A7F9B Old:0xBFABD872


function AUDIO.IS_AMBIENT_ZONE_ENABLED(ambientZone)


  return Velora.invoke(0x985450,"bool", ambientZone)


end


function AUDIO.REFRESH_CLOSEST_OCEAN_SHORELINE()


  Velora.invoke(0x985450,"void")


end


-- PC:0x3B4BF5F0859204D9 Old:0xCE1332B7


function AUDIO.SET_CUTSCENE_AUDIO_OVERRIDE(name)


  Velora.invoke(0x985460,"void", name)


end


-- PC:0xBCC29F935ED07688 Old:0xD63CF33A


function AUDIO.SET_VARIABLE_ON_SYNCH_SCENE_AUDIO(variableName, value)


  Velora.invoke(0x985490,"void", variableName, value)


end


-- PC:0xDFEBD56D9BD1EB16 Old:0x3F277B62


function AUDIO.PLAY_POLICE_REPORT(name, p1)


  return Velora.invoke(0x985500,"int", name, p1)


end


function AUDIO.CANCEL_ALL_POLICE_REPORTS()


  Velora.invoke(0x985500,"void")


end


-- PC:0x1B9025BDA76822B6 Old:0xC0EB6924


function AUDIO.BLIP_SIREN(vehicle)


  Velora.invoke(0x985510,"void", vehicle)


end


-- PC:0x3CDC1E622CCE0356 Old:0x2ACAB783


function AUDIO.OVERRIDE_VEH_HORN(vehicle, override, hornHash)


  Velora.invoke(0x985560,"void", vehicle, override, hornHash)


end


-- PC:0x9D6BFC12B05C6121 Old:0x20E2BDD0


function AUDIO.IS_HORN_ACTIVE(vehicle)


  return Velora.invoke(0x985660,"bool", vehicle)


end


-- PC:0x395BF71085D1B1D9 Old:0x01D6EABE


function AUDIO.SET_AGGRESSIVE_HORNS(toggle)


  Velora.invoke(0x985660,"void", toggle)


end


-- PC:0x02E93C796ABD3A97 Old:0x3C395AEE


function AUDIO.SET_RADIO_POSITION_AUDIO_MUTE(p0)


  Velora.invoke(0x985680,"void", p0)


end


-- PC:0x58BB377BEC7CD5F4 Old:0x8CE63FA1


function AUDIO.SET_VEHICLE_CONVERSATIONS_PERSIST(p0, p1)


  Velora.invoke(0x985690,"void", p0, p1)


end


function AUDIO.SET_VEHICLE_CONVERSATIONS_PERSIST_NEW(p0, p1, p2)


  Velora.invoke(0x9856C0,"void", p0, p1, p2)


end


-- PC:0xD11FA52EB849D978 Old:0xF1F51A14


function AUDIO.IS_STREAM_PLAYING()


  return Velora.invoke(0x9857D0,"bool")


end


-- PC:0x4E72BBDBCA58A3DB Old:0xB4F0AD56


function AUDIO.GET_STREAM_PLAY_TIME()


  return Velora.invoke(0x985720,"int")


end


-- PC:0x1F1F957154EC51DF Old:0x0D89599D


function AUDIO.LOAD_STREAM(streamName, soundSet)


  return Velora.invoke(0x985750,"bool", streamName, soundSet)


end


-- PC:0x59C16B79F53B3712 Old:0xE5B5745C


function AUDIO.LOAD_STREAM_WITH_START_OFFSET(streamName, startOffset, soundSet)


  return Velora.invoke(0x985790,"bool", streamName, startOffset, soundSet)


end


-- PC:0x89049DD63C08B5D1 Old:0xA1D7FABE


function AUDIO.PLAY_STREAM_FROM_PED(ped)


  Velora.invoke(0x9857D0,"void", ped)


end


-- PC:0xB70374A758007DFA Old:0xF8E4BDA2


function AUDIO.PLAY_STREAM_FROM_VEHICLE(vehicle)


  Velora.invoke(0x985820,"void", vehicle)


end


-- PC:0xEBAA9B64D76356FD Old:0xC5266BF7


function AUDIO.PLAY_STREAM_FROM_OBJECT(object)


  Velora.invoke(0x985870,"void", object)


end


-- PC:0x58FCE43488F9F5F4 Old:0x2C2A16BC


function AUDIO.PLAY_STREAM_FRONTEND()


  Velora.invoke(0x9858C0,"void")


end


-- PC:0x21442F412E8DE56B Old:0x6FE5D865


function AUDIO.PLAY_STREAM_FROM_POSITION(x, y, z)


  Velora.invoke(0x9858D0,"void", x, y, z)


end


-- PC:0xA4718A1419D18151 Old:0xD1E364DE


function AUDIO.STOP_STREAM()


  Velora.invoke(0x985930,"void")


end


-- PC:0x9D64D7405520E3D3 Old:0xFF92B49D


function AUDIO.STOP_PED_SPEAKING(ped, shaking)


  Velora.invoke(0x985940,"void", ped, shaking)


end


function AUDIO.BLOCK_ALL_SPEECH_FROM_PED(ped, p1, p2)


  Velora.invoke(0x9859A0,"void", ped, p1, p2)


end


function AUDIO.STOP_PED_SPEAKING_SYNCED(ped, p1)


  Velora.invoke(0x985A10,"void", ped, p1)


end


-- PC:0xA9A41C1E940FB0E8 Old:0x3B8E2D5F


function AUDIO.DISABLE_PED_PAIN_AUDIO(ped, toggle)


  Velora.invoke(0x985A70,"void", ped, toggle)


end


-- PC:0x932C2D096A2C3FFF Old:0x109D1F89


function AUDIO.IS_AMBIENT_SPEECH_DISABLED(ped)


  return Velora.invoke(0x985B50,"bool", ped)


end


function AUDIO.BLOCK_SPEECH_CONTEXT_GROUP(p0, p1)


  Velora.invoke(0x985B50,"void", p0, p1)


end


function AUDIO.UNBLOCK_SPEECH_CONTEXT_GROUP(p0)


  Velora.invoke(0x985B90,"void", p0)


end


-- PC:0x1FEF0683B96EBCF2 Old:0x77182D58


function AUDIO.SET_SIREN_WITH_NO_DRIVER(vehicle, toggle)


  Velora.invoke(0x985BA0,"void", vehicle, toggle)


end


function AUDIO.SET_SIREN_BYPASS_MP_DRIVER_CHECK(vehicle, toggle)


  Velora.invoke(0x985C10,"void", vehicle, toggle)


end


function AUDIO.TRIGGER_SIREN_AUDIO(vehicle)


  Velora.invoke(0x985C80,"void", vehicle)


end


-- PC:0x9C11908013EA4715 Old:0xDE8BA3CD


function AUDIO.SET_HORN_PERMANENTLY_ON(vehicle)


  Velora.invoke(0x985CF0,"void", vehicle)


end


-- PC:0x76D683C108594D0E Old:0x6EB92D05


function AUDIO.SET_HORN_ENABLED(vehicle, toggle)


  Velora.invoke(0x985D50,"void", vehicle, toggle)


end


-- PC:0xE5564483E407F914 Old:0x271A9766


function AUDIO.SET_AUDIO_VEHICLE_PRIORITY(vehicle, p1)


  Velora.invoke(0x985DE0,"void", vehicle, p1)


end


-- PC:0x9D3AF56E94C9AE98 Old:0x2F0A16D1


function AUDIO.SET_HORN_PERMANENTLY_ON_TIME(vehicle, time)


  Velora.invoke(0x985E40,"void", vehicle, time)


end


-- PC:0xFA932DE350266EF8 Old:0xC6BC16F3


function AUDIO.USE_SIREN_AS_HORN(vehicle, toggle)


  Velora.invoke(0x985EC0,"void", vehicle, toggle)


end


-- PC:0x4F0C413926060B38 Old:0x33B0B007


function AUDIO.FORCE_USE_AUDIO_GAME_OBJECT(vehicle, audioName)


  Velora.invoke(0x985F50,"void", vehicle, audioName)


end


function AUDIO.PRELOAD_VEHICLE_AUDIO_BANK(vehicleModel)


  Velora.invoke(0x985FB0,"void", vehicleModel)


end


-- PC:0xF1F8157B8C3F171C Old:0x1C0C5E4C


function AUDIO.SET_VEHICLE_STARTUP_REV_SOUND(vehicle, p1, p2)


  Velora.invoke(0x985FD0,"void", vehicle, p1, p2)


end


function AUDIO.RESET_VEHICLE_STARTUP_REV_SOUND(vehicle)


  Velora.invoke(0x985FF0,"void", vehicle)


end


function AUDIO.SET_VEHICLE_FORCE_REVERSE_WARNING(p0, p1)


  Velora.invoke(0x986050,"void", p0, p1)


end


-- PC:0x5DB8010EE71FDEF2 Old:0x6E660D3F


function AUDIO.IS_VEHICLE_AUDIBLY_DAMAGED(vehicle)


  return Velora.invoke(0x986140,"bool", vehicle)


end


-- PC:0x59E7B488451F4D3A Old:0x23BE6432


function AUDIO.SET_VEHICLE_AUDIO_ENGINE_DAMAGE_FACTOR(vehicle, damageFactor)


  Velora.invoke(0x986140,"void", vehicle, damageFactor)


end


-- PC:0x01BB4D577D38BD9E Old:0xE81FAC68


function AUDIO.SET_VEHICLE_AUDIO_BODY_DAMAGE_FACTOR(vehicle, intensity)


  Velora.invoke(0x9861A0,"void", vehicle, intensity)


end


-- PC:0x1C073274E065C6D2 Old:0x9365E042


function AUDIO.ENABLE_VEHICLE_FANBELT_DAMAGE(vehicle, toggle)


  Velora.invoke(0x986270,"void", vehicle, toggle)


end


-- PC:0x2BE4BC731D039D5A Old:0x2A60A90E


function AUDIO.ENABLE_VEHICLE_EXHAUST_POPS(vehicle, toggle)


  Velora.invoke(0x9862F0,"void", vehicle, toggle)


end


-- PC:0x4A04DE7CAB2739A1 Old:0x072F15F2


function AUDIO.SET_VEHICLE_BOOST_ACTIVE(vehicle, toggle)


  Velora.invoke(0x986380,"void", vehicle, toggle)


end


-- PC:0x6FDDAD856E36988A Old:0x934BE749


function AUDIO.SET_PLAYER_VEHICLE_ALARM_AUDIO_ACTIVE(vehicle, toggle)


  Velora.invoke(0x986410,"void", vehicle, toggle)


end


-- PC:0x06C0023BED16DD6B Old:0xE61110A2


function AUDIO.SET_SCRIPT_UPDATE_DOOR_AUDIO(doorHash, toggle)


  Velora.invoke(0x986480,"void", doorHash, toggle)


end


-- PC:0x3A539D52857EA82D Old:0x84930330


function AUDIO.PLAY_VEHICLE_DOOR_OPEN_SOUND(vehicle, doorId)


  Velora.invoke(0x9864D0,"void", vehicle, doorId)


end


-- PC:0x62A456AA4769EF34 Old:0xBA2CF407


function AUDIO.PLAY_VEHICLE_DOOR_CLOSE_SOUND(vehicle, doorId)


  Velora.invoke(0x986560,"void", vehicle, doorId)


end


-- PC:0xC15907D667F7CFB2 Old:0x563B635D


function AUDIO.ENABLE_STALL_WARNING_SOUNDS(vehicle, toggle)


  Velora.invoke(0x9865F0,"void", vehicle, toggle)


end


-- PC:0x6D28DC1671E334FD Old:0x7643170D


function AUDIO.IS_GAME_IN_CONTROL_OF_MUSIC()


  return Velora.invoke(0x986700,"bool")


end


-- PC:0x3BD3F52BA9B1E4E8 Old:0x0FC3379A


function AUDIO.SET_GPS_ACTIVE(active)


  Velora.invoke(0x986700,"void", active)


end


-- PC:0xB138AAB8A70D3C69 Old:0x3033EA1D


function AUDIO.PLAY_MISSION_COMPLETE_AUDIO(audioName)


  Velora.invoke(0x986720,"void", audioName)


end


-- PC:0x19A30C23F5827F8A Old:0x939982A1


function AUDIO.IS_MISSION_COMPLETE_PLAYING()


  return Velora.invoke(0x986790,"bool")


end


-- PC:0x6F259F82D873B8B8 Old:0xCBE09AEC


function AUDIO.IS_MISSION_COMPLETE_READY_FOR_UI()


  return Velora.invoke(0x986770,"bool")


end


-- PC:0xF154B8D1775B2DEC Old:0xD2858D8A


function AUDIO.BLOCK_DEATH_JINGLE(toggle)


  Velora.invoke(0x986790,"void", toggle)


end


-- PC:0x013A80FC08F6E4F2 Old:0xE48D757B


function AUDIO.START_AUDIO_SCENE(scene)


  return Velora.invoke(0x9867F0,"bool", scene)


end


-- PC:0xDFE8422B3B94E688 Old:0xA08D8C58


function AUDIO.STOP_AUDIO_SCENE(scene)


  Velora.invoke(0x9867F0,"void", scene)


end


-- PC:0xBAC7FC81A75EC1A1 Old:0xF6C7342A


function AUDIO.STOP_AUDIO_SCENES()


  Velora.invoke(0x986820,"void")


end


-- PC:0xB65B60556E2A9225 Old:0xACBED05C


function AUDIO.IS_AUDIO_SCENE_ACTIVE(scene)


  return Velora.invoke(0x986870,"bool", scene)


end


-- PC:0xEF21A9EF089A2668 Old:0x19BB3CE8


function AUDIO.SET_AUDIO_SCENE_VARIABLE(scene, variable, value)


  Velora.invoke(0x986870,"void", scene, variable, value)


end


-- PC:0xA5F377B175A699C5 Old:0xE812925D


function AUDIO.SET_AUDIO_SCRIPT_CLEANUP_TIME(time)


  Velora.invoke(0x986890,"void", time)


end


-- PC:0x153973AB99FE8980 Old:0x2BC93264


function AUDIO.ADD_ENTITY_TO_AUDIO_MIX_GROUP(entity, groupName, p2)


  Velora.invoke(0x9868B0,"void", entity, groupName, p2)


end


-- PC:0x18EB48CFC41F2EA0 Old:0x308ED0EC


function AUDIO.REMOVE_ENTITY_FROM_AUDIO_MIX_GROUP(entity, p1)


  Velora.invoke(0x986940,"void", entity, p1)


end


function AUDIO.AUDIO_IS_MUSIC_PLAYING()


  return Velora.invoke(0x986B50,"bool")


end


function AUDIO.AUDIO_IS_SCRIPTED_MUSIC_PLAYING()


  return Velora.invoke(0x9869F0,"bool")


end


-- PC:0x1E5185B72EF5158A Old:0x534A5C1C


function AUDIO.PREPARE_MUSIC_EVENT(eventName)


  return Velora.invoke(0x986A20,"bool", eventName)


end


-- PC:0x5B17A90291133DA5 Old:0x89FF942D


function AUDIO.CANCEL_MUSIC_EVENT(eventName)


  return Velora.invoke(0x986A90,"bool", eventName)


end


-- PC:0x706D57B0F50DA710 Old:0xB6094948


function AUDIO.TRIGGER_MUSIC_EVENT(eventName)


  return Velora.invoke(0x986AD0,"bool", eventName)


end


-- PC:0xA097AB275061FB21 Old:0x2705C4D5


function AUDIO.IS_MUSIC_ONESHOT_PLAYING()


  return Velora.invoke(0x986B10,"bool")


end


-- PC:0xE7A0D23DC414507B Old:0xD633C809


function AUDIO.GET_MUSIC_PLAYTIME()


  return Velora.invoke(0x986B30,"int")


end


function AUDIO.SET_GLOBAL_RADIO_SIGNAL_LEVEL(p0)


  Velora.invoke(0x986B50,"void", p0)


end


-- PC:0xFBE20329593DEC9D Old:0x53FC3FEC


function AUDIO.RECORD_BROKEN_GLASS(x, y, z, radius)


  Velora.invoke(0x986B70,"void", x, y, z, radius)


end


-- PC:0xB32209EFFDC04913 Old:0xE6B033BF


function AUDIO.CLEAR_ALL_BROKEN_GLASS()


  Velora.invoke(0x986BD0,"void")


end


-- PC:0x70B8EC8FC108A634 Old:0x95050CAD


function AUDIO.SCRIPT_OVERRIDES_WIND_ELEVATION(p0, p1)


  Velora.invoke(0x986BF0,"void", p0, p1)


end


-- PC:0x149AEE66F0CB3A99 Old:0xE64F97A0


function AUDIO.SET_PED_WALLA_DENSITY(p0, p1)


  Velora.invoke(0x986C50,"void", p0, p1)


end


-- PC:0x8BF907833BE275DE Old:0x2CD26D69


function AUDIO.SET_PED_INTERIOR_WALLA_DENSITY(p0, p1)


  Velora.invoke(0x986C70,"void", p0, p1)


end


-- PC:0x062D5EAD4DA2FA6A Old:0xD87AF337


function AUDIO.FORCE_PED_PANIC_WALLA()


  Velora.invoke(0x986C90,"void")


end


-- PC:0x9D74AE343DB65533 Old:0x084932E8


function AUDIO.PREPARE_ALARM(alarmName)


  return Velora.invoke(0x986CD0,"bool", alarmName)


end


-- PC:0x0355EF116C4C97B2 Old:0x703F524B


function AUDIO.START_ALARM(alarmName, p2)


  Velora.invoke(0x986CD0,"void", alarmName, p2)


end


-- PC:0xA1CADDCD98415A41 Old:0xF987BE8C


function AUDIO.STOP_ALARM(alarmName, toggle)


  Velora.invoke(0x986CF0,"void", alarmName, toggle)


end


-- PC:0x2F794A877ADD4C92 Old:0xC3CB9DC6


function AUDIO.STOP_ALL_ALARMS(stop)


  Velora.invoke(0x986D10,"void", stop)


end


-- PC:0x226435CB96CCFC8C Old:0x9D8E1D23


function AUDIO.IS_ALARM_PLAYING(alarmName)


  return Velora.invoke(0x986E70,"bool", alarmName)


end


-- PC:0x02165D55000219AC Old:0xE84ABC19


function AUDIO.GET_VEHICLE_DEFAULT_HORN(vehicle)


  return Velora.invoke(0x986D90,"int", vehicle)


end


-- PC:0xACB5DCCA1EC76840 Old:0xFD4B5B3B


function AUDIO.GET_VEHICLE_DEFAULT_HORN_IGNORE_MODS(vehicle)


  return Velora.invoke(0x986E00,"int", vehicle)


end


-- PC:0xF54BB7B61036F335 Old:0xDF720C86


function AUDIO.RESET_PED_AUDIO_FLAGS(ped)


  Velora.invoke(0x986E70,"void", ped)


end


function AUDIO.SET_PED_FOOTSTEPS_EVENTS_ENABLED(ped, toggle)


  Velora.invoke(0x986EC0,"void", ped, toggle)


end


function AUDIO.SET_PED_CLOTH_EVENTS_ENABLED(ped, toggle)


  Velora.invoke(0x986F10,"void", ped, toggle)


end


-- PC:0xD2CC78CD3D0B50F9 Old:0xC307D531


function AUDIO.OVERRIDE_PLAYER_GROUND_MATERIAL(hash, toggle)


  Velora.invoke(0x986F60,"void", hash, toggle)


end


-- PC:0xBF4DC1784BE94DFA Old:0xD99E275B


function AUDIO.USE_FOOTSTEP_SCRIPT_SWEETENERS(ped, p1, hash)


  Velora.invoke(0x986FD0,"void", ped, p1, hash)


end


function AUDIO.OVERRIDE_MICROPHONE_SETTINGS(hash, toggle)


  Velora.invoke(0x987060,"void", hash, toggle)


end


-- PC:0xD57AAAE0E2214D11 Old:0x2B9D91E8


function AUDIO.FREEZE_MICROPHONE()


  Velora.invoke(0x9870D0,"void")


end


-- PC:0x552369F549563AD5 Old:0x13EB5861


function AUDIO.DISTANT_COP_CAR_SIRENS(value)


  Velora.invoke(0x987110,"void", value)


end


-- PC:0x43FA0DFC5DF87815 Old:0x7BED1872


function AUDIO.SET_SIREN_CAN_BE_CONTROLLED_BY_AUDIO(vehicle, p1)


  Velora.invoke(0x9871B0,"void", vehicle, p1)


end


function AUDIO.ENABLE_STUNT_JUMP_AUDIO()


  Velora.invoke(0x987280,"void")


end


-- PC:0xB9EFD5C25018725A Old:0x1C09C9E0


function AUDIO.SET_AUDIO_FLAG(flagName, toggle)


  Velora.invoke(0x987300,"void", flagName, toggle)


end


-- PC:0xC7ABCACA4985A766 Old:0xE1D91FD0


function AUDIO.PREPARE_SYNCHRONIZED_AUDIO_EVENT(audioEvent, p1)


  return Velora.invoke(0x987460,"bool", audioEvent, p1)


end


-- PC:0x029FE7CD1B7E2E75 Old:0x7652DD49


function AUDIO.PREPARE_SYNCHRONIZED_AUDIO_EVENT_FOR_SCENE(sceneID, audioEvent)


  return Velora.invoke(0x987390,"bool", sceneID, audioEvent)


end


-- PC:0x8B2FD4560E55DD2D Old:0x507F3241


function AUDIO.PLAY_SYNCHRONIZED_AUDIO_EVENT(sceneID)


  return Velora.invoke(0x9873E0,"bool", sceneID)


end


-- PC:0x92D6A88E64A94430 Old:0xADEED2B4


function AUDIO.STOP_SYNCHRONIZED_AUDIO_EVENT(sceneID)


  return Velora.invoke(0x987420,"bool", sceneID)


end


-- PC:0xC8EDE9BDBCCBA6D4 Old:0x55A21772


function AUDIO.INIT_SYNCH_SCENE_AUDIO_WITH_POSITION(audioEvent, x, y, z)


  Velora.invoke(0x987460,"void", audioEvent, x, y, z)


end


-- PC:0x950A154B8DAB6185 Old:0xA17F9AB0


function AUDIO.INIT_SYNCH_SCENE_AUDIO_WITH_ENTITY(audioEvent, entity)


  Velora.invoke(0x9874D0,"void", audioEvent, entity)


end


-- PC:0x12561FCBB62D5B9C Old:0x62B43677


function AUDIO.SET_AUDIO_SPECIAL_EFFECT_MODE(mode)


  Velora.invoke(0x987550,"void", mode)


end


-- PC:0x044DBAD7A7FA2BE5 Old:0x8AD670EC


function AUDIO.SET_PORTAL_SETTINGS_OVERRIDE(p0, p1)


  Velora.invoke(0x987570,"void", p0, p1)


end


-- PC:0xB4BBFD9CD8B3922B Old:0xD24B4D0C


function AUDIO.REMOVE_PORTAL_SETTINGS_OVERRIDE(p0)


  Velora.invoke(0x9875A0,"void", p0)


end


-- PC:0xE4E6DD5566D28C82 Old:0x7262B5BA


function AUDIO.STOP_SMOKE_GRENADE_EXPLOSION_SOUNDS()


  Velora.invoke(0x9875D0,"void")


end


-- PC:0x3A48AB4445D499BE Old:0x93A44A1F


function AUDIO.GET_MUSIC_VOL_SLIDER()


  return Velora.invoke(0x987610,"int")


end


-- PC:0x4ADA3F19BE4A6047 Old:0x13777A0B


function AUDIO.REQUEST_TENNIS_BANKS(ped)


  Velora.invoke(0x987610,"void", ped)


end


-- PC:0x0150B6FF25A9E2E5 Old:0x1134F68B


function AUDIO.UNREQUEST_TENNIS_BANKS()


  Velora.invoke(0x987660,"void")


end


-- PC:0xBEF34B1D9624D5DD Old:0xE0047BFD


function AUDIO.SET_SKIP_MINIGUN_SPIN_UP_AUDIO(p0)


  Velora.invoke(0x987670,"void", p0)


end


-- PC:0x806058BBDC136E06 Old:0x55461BE6


function AUDIO.STOP_CUTSCENE_AUDIO()


  Velora.invoke(0x987690,"void")


end


function AUDIO.HAS_LOADED_MP_DATA_SET()


  return Velora.invoke(0x987740,"bool")


end


function AUDIO.HAS_LOADED_SP_DATA_SET()


  return Velora.invoke(0x9876C0,"bool")


end


function AUDIO.GET_VEHICLE_HORN_SOUND_INDEX(vehicle)


  return Velora.invoke(0x9876E0,"int", vehicle)


end


function AUDIO.SET_VEHICLE_HORN_SOUND_INDEX(vehicle, value)


  Velora.invoke(0x987740,"void", vehicle, value)


end


