-- ============================================================
--  compat.lua  —  Bridge namespace PC → Velora.invoke (PS4)
--  AUTO GENERATO da NativesConverter.py per la versione 1.57
-- ============================================================

local BASE = "/data/Velora/lua/"

dofile(BASE .. "natives.lua")
dofile(BASE .. "compat.lua")

local GUI_Mount = dofile(BASE .. "GUIMount.lua")
GUI_Mount.init()

local MountMod = dofile(BASE .. "MountMod.lua")
MountMod.init(GUI_Mount)


-- ────────────────────────────────────────────────────────────
-- GLOBAL
-- ────────────────────────────────────────────────────────────
function WAIT(ms)
    Velora.invoke(0x1E24A20, "void", ms)
end

function START_NEW_SCRIPT(scriptName, invoke<int>(0x1E24D50, scriptName, args, argCount, invoke<int>(0x1E24F20, scriptHash, invoke<int>(0x1E24F60, scriptHash, args, argCount, invoke<int>(0x1E24FD0, value)
    return Velora.invoke(0x1E263E0, "int", scriptName, invoke<int>(0x1E24D50, scriptName, args, argCount, invoke<int>(0x1E24F20, scriptHash, invoke<int>(0x1E24F60, scriptHash, args, argCount, invoke<int>(0x1E24FD0, value)
end

function SETTIMERB(value)
    Velora.invoke(0x1E26410, "void", value)
end

function TIMESTEP(invoke<float>(0x1E26460, invoke<float>(0x1E26490, invoke<float>(0x1E264D0, base, invoke<float>(0x1E264F0, invoke<float>(0xDEADBEEF, x, y, invoke<float>(0x1E26550, x, y, invoke<float>(0x1E26590, x1, y1, z1, x2, y2, invoke<float>(0x1E265C0, x1, y1, z1, x2, y2, invoke<float>(0x1E26610, value, invoke<int>(0x1E26650, value, invoke<int>(0x1E26670, invoke<int>(0x1E26690, invoke<int>(0x1E266B0, invoke<int>(0x1E266D0, invoke<float>(0x1E266F0, priority)
    return Velora.invoke(0xDEADBEEF, "float", invoke<float>(0x1E26460, invoke<float>(0x1E26490, invoke<float>(0x1E264D0, base, invoke<float>(0x1E264F0, invoke<float>(0xDEADBEEF, x, y, invoke<float>(0x1E26550, x, y, invoke<float>(0x1E26590, x1, y1, z1, x2, y2, invoke<float>(0x1E265C0, x1, y1, z1, x2, y2, invoke<float>(0x1E26610, value, invoke<int>(0x1E26650, value, invoke<int>(0x1E26670, invoke<int>(0x1E26690, invoke<int>(0x1E266B0, invoke<int>(0x1E266D0, invoke<float>(0x1E266F0, priority)
end

function APP_DATA_VALID(invoke<int>(0x97A8F0, invoke<float>(0x97A9B0, char>(0x97AA80, property, value)
    return Velora.invoke(0x97AB50, "bool", invoke<int>(0x97A8F0, invoke<float>(0x97A9B0, char>(0x97AA80, property, value)
end

function APP_SET_FLOAT(property, value)
    Velora.invoke(0x97AB60, "void", property, value)
end

function APP_SET_STRING(property, value)
    Velora.invoke(0x97AB80, "void", property, value)
end

function APP_SET_APP(appName)
    Velora.invoke(0x97AB90, "void", appName)
end

function APP_SET_BLOCK(blockName)
    Velora.invoke(0x97AC70, "void", blockName)
end

function APP_CLEAR_BLOCK()
    Velora.invoke(0x97ACC0, "void")
end

function APP_CLOSE_APP()
    Velora.invoke(0x97AD20, "void")
end

function APP_CLOSE_BLOCK()
    Velora.invoke(0x97AD60, "void")
end

function APP_HAS_LINKED_SOCIAL_CLUB_ACCOUNT(invoke<BOOL>(0x97ADE0, APP_SAVE_DATA()
    return Velora.invoke(0x97AE20, "bool", invoke<BOOL>(0x97ADE0, APP_SAVE_DATA()
end

function APP_GET_DELETED_FILE_STATUS(invoke<BOOL>(0x97AE60, ringtoneName, ped, p2)
    return Velora.invoke(0x982850, "int", invoke<BOOL>(0x97AE60, ringtoneName, ped, p2)
end

function IS_PED_RINGTONE_PLAYING(invoke<BOOL>(0x982870, ped)
    return Velora.invoke(0x9828E0, "bool", invoke<BOOL>(0x982870, ped)
end

function IS_MOBILE_PHONE_CALL_ONGOING(CREATE_NEW_SCRIPTED_CONVERSATION()
    return Velora.invoke(0x9829E0, "bool", CREATE_NEW_SCRIPTED_CONVERSATION()
end

function ADD_LINE_TO_CONVERSATION(index, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)
    Velora.invoke(0x982A00, "void", index, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)
end

function ADD_PED_TO_CONVERSATION(index, ped, p2)
    Velora.invoke(0x982AF0, "void", index, ped, p2)
end

function SET_POSITION_FOR_NULL_CONV_PED(p0, p1, p2, p3)
    Velora.invoke(0x982B70, "void", p0, p1, p2, p3)
end

function SET_ENTITY_FOR_NULL_CONV_PED(p0, entity)
    Velora.invoke(0x982BE0, "void", p0, entity)
end

function SET_MICROPHONE_POSITION(toggle, x1, y1, z1, x2, y2, z2, x3, y3, z3)
    Velora.invoke(0x982C40, "void", toggle, x1, y1, z1, x2, y2, z2, x3, y3, z3)
end

function SET_CONVERSATION_AUDIO_CONTROLLED_BY_ANIM(p0)
    Velora.invoke(0x982D30, "void", p0)
end

function SET_CONVERSATION_AUDIO_PLACEHOLDER(p0)
    Velora.invoke(0x982D50, "void", p0)
end

function START_SCRIPT_PHONE_CONVERSATION(p0, p1)
    Velora.invoke(0x982D70, "void", p0, p1)
end

function PRELOAD_SCRIPT_PHONE_CONVERSATION(p0, p1)
    Velora.invoke(0x982DC0, "void", p0, p1)
end

function START_SCRIPT_CONVERSATION(p0, p1, p2, p3)
    Velora.invoke(0x982E10, "void", p0, p1, p2, p3)
end

function PRELOAD_SCRIPT_CONVERSATION(p0, p1, p2, p3)
    Velora.invoke(0x982E70, "void", p0, p1, p2, p3)
end

function START_PRELOADED_CONVERSATION()
    Velora.invoke(0x982ED0, "void")
end

function GET_IS_PRELOADED_CONVERSATION_READY(p0)
    return Velora.invoke(0x982FC0, "bool", p0)
end

function RESTART_SCRIPTED_CONVERSATION()
    Velora.invoke(0x982FF0, "void")
end

function STOP_SCRIPTED_CONVERSATION(invoke<int>(0x983010, SKIP_TO_NEXT_SCRIPTED_CONVERSATION_LINE()
    return Velora.invoke(0x983040, "int", invoke<int>(0x983010, SKIP_TO_NEXT_SCRIPTED_CONVERSATION_LINE()
end

function INTERRUPT_CONVERSATION(ped, voiceline, speaker)
    Velora.invoke(0x983050, "void", ped, voiceline, speaker)
end

function INTERRUPT_CONVERSATION_AND_PAUSE(ped, p1, speaker)
    Velora.invoke(0x9830D0, "void", ped, p1, speaker)
end

function GET_VARIATION_CHOSEN_FOR_SCRIPTED_LINE(invoke<int>(0x983150, p0)
    return Velora.invoke(0x9831B0, "int", invoke<int>(0x983150, p0)
end

function REGISTER_SCRIPT_WITH_AUDIO(p0)
    Velora.invoke(0x9831D0, "void", p0)
end

function UNREGISTER_SCRIPT_WITH_AUDIO()
    Velora.invoke(0x9831E0, "void")
end

function REQUEST_MISSION_AUDIO_BANK(audioBank, p1, invoke<BOOL>(0x9831F0, audioBank, p1, invoke<BOOL>(0x983230, audioBank, p1, invoke<BOOL>(0x983270, audioBank, p1, invoke<BOOL>(0x9832B0, audioBank, p1, invoke<BOOL>(0x9832D0, audioBank, p1, invoke<BOOL>(0x9832F0, RELEASE_MISSION_AUDIO_BANK()
    return Velora.invoke(0x983310, "bool", audioBank, p1, invoke<BOOL>(0x9831F0, audioBank, p1, invoke<BOOL>(0x983230, audioBank, p1, invoke<BOOL>(0x983270, audioBank, p1, invoke<BOOL>(0x9832B0, audioBank, p1, invoke<BOOL>(0x9832D0, audioBank, p1, invoke<BOOL>(0x9832F0, RELEASE_MISSION_AUDIO_BANK()
end

function RELEASE_AMBIENT_AUDIO_BANK()
    Velora.invoke(0x983320, "void")
end

function RELEASE_NAMED_SCRIPT_AUDIO_BANK(audioBank)
    Velora.invoke(0x983330, "void", audioBank)
end

function RELEASE_SCRIPT_AUDIO_BANK()
    Velora.invoke(0x983350, "void")
end

function UNHINT_AMBIENT_AUDIO_BANK()
    Velora.invoke(0x983360, "void")
end

function UNHINT_SCRIPT_AUDIO_BANK()
    Velora.invoke(0x983370, "void")
end

function UNHINT_NAMED_SCRIPT_AUDIO_BANK(audioBank)
    Velora.invoke(0x983380, "void", audioBank)
end

function GET_SOUND_ID(soundId)
    return Velora.invoke(0x9833D0, "int", soundId)
end

function PLAY_SOUND(soundId, audioName, audioRef, p3, p4, p5)
    Velora.invoke(0x9833F0, "void", soundId, audioName, audioRef, p3, p4, p5)
end

function PLAY_SOUND_FRONTEND(soundId, audioName, audioRef, p3)
    Velora.invoke(0x983430, "void", soundId, audioName, audioRef, p3)
end

function PLAY_DEFERRED_SOUND_FRONTEND(soundName, soundsetName)
    Velora.invoke(0x983450, "void", soundName, soundsetName)
end

function PLAY_SOUND_FROM_ENTITY(soundId, audioName, entity, audioRef, isNetwork, p5)
    Velora.invoke(0x9834B0, "void", soundId, audioName, entity, audioRef, isNetwork, p5)
end

function PLAY_SOUND_FROM_ENTITY_HASH(soundId, model, entity, soundSetHash, p4, p5)
    Velora.invoke(0x983540, "void", soundId, model, entity, soundSetHash, p4, p5)
end

function PLAY_SOUND_FROM_COORD(soundId, audioName, x, y, z, audioRef, isNetwork, range, p8)
    Velora.invoke(0x9835D0, "void", soundId, audioName, x, y, z, audioRef, isNetwork, range, p8)
end

function UPDATE_SOUND_COORD(soundId, x, y, z)
    Velora.invoke(0x983660, "void", soundId, x, y, z)
end

function STOP_SOUND(soundId)
    Velora.invoke(0x9836D0, "void", soundId)
end

function GET_NETWORK_ID_FROM_SOUND_ID(invoke<int>(0x9836F0, invoke<int>(0x983720, soundId, variable, p2)
    return Velora.invoke(0x983750, "int", invoke<int>(0x9836F0, invoke<int>(0x983720, soundId, variable, p2)
end

function SET_VARIABLE_ON_STREAM(variable, p1)
    Velora.invoke(0x983770, "void", variable, p1)
end

function OVERRIDE_UNDERWATER_STREAM(p0, p1)
    Velora.invoke(0x983790, "void", p0, p1)
end

function SET_VARIABLE_ON_UNDER_WATER_STREAM(variableName, value)
    Velora.invoke(0x9837B0, "void", variableName, value)
end

function HAS_SOUND_FINISHED(invoke<BOOL>(0x9837D0, ped, speechName, speechParam, p3)
    return Velora.invoke(0x983800, "bool", invoke<BOOL>(0x9837D0, ped, speechName, speechParam, p3)
end

function PLAY_PED_AMBIENT_SPEECH_AND_CLONE_NATIVE(ped, speechName, speechParam, p3)
    Velora.invoke(0x983820, "void", ped, speechName, speechParam, p3)
end

function PLAY_PED_AMBIENT_SPEECH_WITH_VOICE_NATIVE(ped, speechName, voiceName, speechParam, p4)
    Velora.invoke(0x983840, "void", ped, speechName, voiceName, speechParam, p4)
end

function PLAY_AMBIENT_SPEECH_FROM_POSITION_NATIVE(speechName, voiceName, x, y, z, speechParam)
    Velora.invoke(0x983870, "void", speechName, voiceName, x, y, z, speechParam)
end

function OVERRIDE_TREVOR_RAGE(voiceEffect)
    Velora.invoke(0x983900, "void", voiceEffect)
end

function RESET_TREVOR_RAGE()
    Velora.invoke(0x983920, "void")
end

function SET_PLAYER_ANGRY(ped, toggle)
    Velora.invoke(0x983930, "void", ped, toggle)
end

function PLAY_PAIN(ped, painID, p1, p3)
    Velora.invoke(0x983990, "void", ped, painID, p1, p3)
end

function RELEASE_WEAPON_AUDIO()
    Velora.invoke(0x9839B0, "void")
end

function ACTIVATE_AUDIO_SLOWMO_MODE(mode)
    Velora.invoke(0x9839C0, "void", mode)
end

function DEACTIVATE_AUDIO_SLOWMO_MODE(mode)
    Velora.invoke(0x983A00, "void", mode)
end

function SET_AMBIENT_VOICE_NAME(ped, name)
    Velora.invoke(0x983A40, "void", ped, name)
end

function SET_AMBIENT_VOICE_NAME_HASH(ped, hash)
    Velora.invoke(0x983AB0, "void", ped, hash)
end

function GET_AMBIENT_VOICE_NAME_HASH(invoke<Hash>(0x983B10, ped)
    return Velora.invoke(0x983B70, "int", invoke<Hash>(0x983B10, ped)
end

function SET_PED_RACE_AND_VOICE_GROUP(ped, p1, voiceGroup)
    Velora.invoke(0x983BD0, "void", ped, p1, voiceGroup)
end

function SET_PED_VOICE_GROUP(ped, voiceGroupHash)
    Velora.invoke(0x983C40, "void", ped, voiceGroupHash)
end

function SET_PED_VOICE_GROUP_FROM_RACE_TO_PVG(ped, voiceGroupHash)
    Velora.invoke(0x983CA0, "void", ped, voiceGroupHash)
end

function SET_PED_GENDER(ped, p1)
    Velora.invoke(0x983D30, "void", ped, p1)
end

function STOP_CURRENT_PLAYING_SPEECH(ped)
    Velora.invoke(0x983D90, "void", ped)
end

function STOP_CURRENT_PLAYING_AMBIENT_SPEECH(ped)
    Velora.invoke(0x983DE0, "void", ped)
end

function IS_AMBIENT_SPEECH_PLAYING(invoke<BOOL>(0x983E30, invoke<BOOL>(0x983EA0, invoke<BOOL>(0x983F10, ped, speechName, invoke<BOOL>(0x984000, invoke<BOOL>(0x9840E0, ped, toggle)
    return Velora.invoke(0x984150, "bool", invoke<BOOL>(0x983E30, invoke<BOOL>(0x983EA0, invoke<BOOL>(0x983F10, ped, speechName, invoke<BOOL>(0x984000, invoke<BOOL>(0x9840E0, ped, toggle)
end

function PLAY_ANIMAL_VOCALIZATION(pedHandle, p1, speechName)
    Velora.invoke(0x9841B0, "void", pedHandle, p1, speechName)
end

function IS_ANIMAL_VOCALIZATION_PLAYING(invoke<BOOL>(0x984280, animal, mood)
    return Velora.invoke(0x9842F0, "bool", invoke<BOOL>(0x984280, animal, mood)
end

function IS_MOBILE_PHONE_RADIO_ACTIVE(state)
    return Velora.invoke(0x9843C0, "bool", state)
end

function GET_PLAYER_RADIO_STATION_INDEX(char>(0x984450, SET_RADIO_RETUNE_UP()
    return Velora.invoke(0x984520, "int", char>(0x984450, SET_RADIO_RETUNE_UP()
end

function SET_RADIO_RETUNE_DOWN()
    Velora.invoke(0x984540, "void")
end

function SET_RADIO_TO_STATION_NAME(stationName)
    Velora.invoke(0x984560, "void", stationName)
end

function SET_VEH_RADIO_STATION(vehicle, radioStation)
    Velora.invoke(0x984580, "void", vehicle, radioStation)
end

function SET_VEH_HAS_NORMAL_RADIO(vehicle)
    Velora.invoke(0x984620, "void", vehicle)
end

function IS_VEHICLE_RADIO_ON(invoke<BOOL>(0x984670, vehicle)
    return Velora.invoke(0x9846E0, "bool", invoke<BOOL>(0x984670, vehicle)
end

function SET_EMITTER_RADIO_STATION(emitterName, radioStation, p2)
    Velora.invoke(0x984730, "void", emitterName, radioStation, p2)
end

function SET_STATIC_EMITTER_ENABLED(emitterName, toggle)
    Velora.invoke(0x984760, "void", emitterName, toggle)
end

function LINK_STATIC_EMITTER_TO_ENTITY(emitterName, entity)
    Velora.invoke(0x984790, "void", emitterName, entity)
end

function SET_RADIO_TO_STATION_INDEX(radioStation)
    Velora.invoke(0x9847F0, "void", radioStation)
end

function SET_FRONTEND_RADIO_ACTIVE(active)
    Velora.invoke(0x984810, "void", active)
end

function UNLOCK_MISSION_NEWS_STORY(newsStory)
    Velora.invoke(0x984860, "void", newsStory)
end

function IS_MISSION_NEWS_STORY_UNLOCKED(invoke<BOOL>(0x984870, play)
    return Velora.invoke(0x9848C0, "bool", invoke<BOOL>(0x984870, play)
end

function SKIP_RADIO_FORWARD()
    Velora.invoke(0x9848F0, "void")
end

function FREEZE_RADIO_STATION(radioStation)
    Velora.invoke(0x984900, "void", radioStation)
end

function UNFREEZE_RADIO_STATION(radioStation)
    Velora.invoke(0x984940, "void", radioStation)
end

function SET_RADIO_AUTO_UNFREEZE(toggle)
    Velora.invoke(0x984960, "void", toggle)
end

function SET_INITIAL_PLAYER_STATION(radioStation)
    Velora.invoke(0x984980, "void", radioStation)
end

function SET_USER_RADIO_CONTROL_ENABLED(toggle)
    Velora.invoke(0x9849B0, "void", toggle)
end

function SET_RADIO_TRACK(radioStation, radioTrack)
    Velora.invoke(0x984A00, "void", radioStation, radioTrack)
end

function SET_RADIO_TRACK_WITH_START_OFFSET(radioStationName, mixName, p2)
    Velora.invoke(0x984A40, "void", radioStationName, mixName, p2)
end

function SET_NEXT_RADIO_TRACK(radioName, radioTrack, p2, p3)
    Velora.invoke(0x984A80, "void", radioName, radioTrack, p2, p3)
end

function SET_VEHICLE_RADIO_LOUD(vehicle, toggle)
    Velora.invoke(0x984AF0, "void", vehicle, toggle)
end

function CAN_VEHICLE_RECEIVE_CB_RADIO(invoke<BOOL>(0x984B40, toggle)
    return Velora.invoke(0x984BC0, "bool", invoke<BOOL>(0x984B40, toggle)
end

function DOES_PLAYER_VEH_HAVE_RADIO(vehicle, toggle)
    return Velora.invoke(0x984C90, "bool", vehicle, toggle)
end

function SET_POSITIONED_PLAYER_VEHICLE_RADIO_EMITTER_ENABLED(p0)
    Velora.invoke(0x984D00, "void", p0)
end

function SET_CUSTOM_RADIO_TRACK_LIST(radioStation, trackListName, p2)
    Velora.invoke(0x984D20, "void", radioStation, trackListName, p2)
end

function CLEAR_CUSTOM_RADIO_TRACK_LIST(radioStation)
    Velora.invoke(0x984DA0, "void", radioStation)
end

function GET_NUM_UNLOCKED_RADIO_STATIONS(invoke<int>(0x984DD0, radioStation, toggle)
    return Velora.invoke(0x984E10, "int", invoke<int>(0x984DD0, radioStation, toggle)
end

function SET_RADIO_FRONTEND_FADE_TIME(fadeTime)
    Velora.invoke(0x984E40, "void", fadeTime)
end

function UNLOCK_RADIO_STATION_TRACK_LIST(radioStation, trackListName)
    Velora.invoke(0x984E60, "void", radioStation, trackListName)
end

function LOCK_RADIO_STATION_TRACK_LIST(radioStation, trackListName)
    Velora.invoke(0x984EA0, "void", radioStation, trackListName)
end

function UPDATE_UNLOCKABLE_DJ_RADIO_TRACKS(enableMixes)
    Velora.invoke(0x984F10, "void", enableMixes)
end

function LOCK_RADIO_STATION(radioStationName, toggle)
    Velora.invoke(0x984F20, "void", radioStationName, toggle)
end

function SET_RADIO_STATION_AS_FAVOURITE(radioStation, toggle)
    Velora.invoke(0x984F70, "void", radioStation, toggle)
end

function IS_RADIO_STATION_FAVOURITED(invoke<BOOL>(0x984FB0, out1, out2, invoke<BOOL>(0x984FF0, radioStation, trackListName, milliseconds)
    return Velora.invoke(0x985030, "bool", invoke<BOOL>(0x984FB0, out1, out2, invoke<BOOL>(0x984FF0, radioStation, trackListName, milliseconds)
end

function GET_CURRENT_TRACK_PLAY_TIME(invoke<int>(0x985090, invoke<Hash>(0x9850D0, vehicle, toggle)
    return Velora.invoke(0x985110, "int", invoke<int>(0x985090, invoke<Hash>(0x9850D0, vehicle, toggle)
end

function SET_AMBIENT_ZONE_STATE(zoneName, p1, p2)
    Velora.invoke(0x985180, "void", zoneName, p1, p2)
end

function CLEAR_AMBIENT_ZONE_STATE(zoneName, p1)
    Velora.invoke(0x9851C0, "void", zoneName, p1)
end

function SET_AMBIENT_ZONE_LIST_STATE(ambientZone, p1, p2)
    Velora.invoke(0x985200, "void", ambientZone, p1, p2)
end

function CLEAR_AMBIENT_ZONE_LIST_STATE(ambientZone, p1)
    Velora.invoke(0x985290, "void", ambientZone, p1)
end

function SET_AMBIENT_ZONE_STATE_PERSISTENT(ambientZone, p1, p2)
    Velora.invoke(0x985310, "void", ambientZone, p1, p2)
end

function SET_AMBIENT_ZONE_LIST_STATE_PERSISTENT(ambientZone, p1, p2)
    Velora.invoke(0x985350, "void", ambientZone, p1, p2)
end

function IS_AMBIENT_ZONE_ENABLED(invoke<BOOL>(0x9853E0, REFRESH_CLOSEST_OCEAN_SHORELINE()
    return Velora.invoke(0x985450, "bool", invoke<BOOL>(0x9853E0, REFRESH_CLOSEST_OCEAN_SHORELINE()
end

function SET_CUTSCENE_AUDIO_OVERRIDE(name)
    Velora.invoke(0x985460, "void", name)
end

function SET_VARIABLE_ON_SYNCH_SCENE_AUDIO(variableName, value)
    Velora.invoke(0x985490, "void", variableName, value)
end

function PLAY_POLICE_REPORT(name, invoke<int>(0x9854D0, CANCEL_ALL_POLICE_REPORTS()
    return Velora.invoke(0x985500, "int", name, invoke<int>(0x9854D0, CANCEL_ALL_POLICE_REPORTS()
end

function BLIP_SIREN(vehicle)
    Velora.invoke(0x985510, "void", vehicle)
end

function OVERRIDE_VEH_HORN(vehicle, override, hornHash)
    Velora.invoke(0x985560, "void", vehicle, override, hornHash)
end

function IS_HORN_ACTIVE(invoke<BOOL>(0x985600, toggle)
    return Velora.invoke(0x985660, "bool", invoke<BOOL>(0x985600, toggle)
end

function SET_RADIO_POSITION_AUDIO_MUTE(p0)
    Velora.invoke(0x985680, "void", p0)
end

function SET_VEHICLE_CONVERSATIONS_PERSIST(p0, p1)
    Velora.invoke(0x985690, "void", p0, p1)
end

function SET_VEHICLE_CONVERSATIONS_PERSIST_NEW(p0, p1, p2)
    Velora.invoke(0x9856C0, "void", p0, p1, p2)
end

function IS_STREAM_PLAYING(streamName, invoke<BOOL>(0x985750, streamName, startOffset, invoke<BOOL>(0x985790, ped)
    return Velora.invoke(0x9857D0, "bool", streamName, invoke<BOOL>(0x985750, streamName, startOffset, invoke<BOOL>(0x985790, ped)
end

function PLAY_STREAM_FROM_VEHICLE(vehicle)
    Velora.invoke(0x985820, "void", vehicle)
end

function PLAY_STREAM_FROM_OBJECT(object)
    Velora.invoke(0x985870, "void", object)
end

function PLAY_STREAM_FRONTEND()
    Velora.invoke(0x9858C0, "void")
end

function PLAY_STREAM_FROM_POSITION(x, y, z)
    Velora.invoke(0x9858D0, "void", x, y, z)
end

function STOP_STREAM()
    Velora.invoke(0x985930, "void")
end

function STOP_PED_SPEAKING(ped, shaking)
    Velora.invoke(0x985940, "void", ped, shaking)
end

function BLOCK_ALL_SPEECH_FROM_PED(ped, p1, p2)
    Velora.invoke(0x9859A0, "void", ped, p1, p2)
end

function STOP_PED_SPEAKING_SYNCED(ped, p1)
    Velora.invoke(0x985A10, "void", ped, p1)
end

function DISABLE_PED_PAIN_AUDIO(ped, toggle)
    Velora.invoke(0x985A70, "void", ped, toggle)
end

function IS_AMBIENT_SPEECH_DISABLED(invoke<BOOL>(0x985AD0, p0, p1)
    return Velora.invoke(0x985B50, "bool", invoke<BOOL>(0x985AD0, p0, p1)
end

function UNBLOCK_SPEECH_CONTEXT_GROUP(p0)
    Velora.invoke(0x985B90, "void", p0)
end

function SET_SIREN_WITH_NO_DRIVER(vehicle, toggle)
    Velora.invoke(0x985BA0, "void", vehicle, toggle)
end

function SET_SIREN_BYPASS_MP_DRIVER_CHECK(vehicle, toggle)
    Velora.invoke(0x985C10, "void", vehicle, toggle)
end

function TRIGGER_SIREN_AUDIO(vehicle)
    Velora.invoke(0x985C80, "void", vehicle)
end

function SET_HORN_PERMANENTLY_ON(vehicle)
    Velora.invoke(0x985CF0, "void", vehicle)
end

function SET_HORN_ENABLED(vehicle, toggle)
    Velora.invoke(0x985D50, "void", vehicle, toggle)
end

function SET_AUDIO_VEHICLE_PRIORITY(vehicle, p1)
    Velora.invoke(0x985DE0, "void", vehicle, p1)
end

function SET_HORN_PERMANENTLY_ON_TIME(vehicle, time)
    Velora.invoke(0x985E40, "void", vehicle, time)
end

function USE_SIREN_AS_HORN(vehicle, toggle)
    Velora.invoke(0x985EC0, "void", vehicle, toggle)
end

function FORCE_USE_AUDIO_GAME_OBJECT(vehicle, audioName)
    Velora.invoke(0x985F50, "void", vehicle, audioName)
end

function PRELOAD_VEHICLE_AUDIO_BANK(vehicleModel)
    Velora.invoke(0x985FB0, "void", vehicleModel)
end

function SET_VEHICLE_STARTUP_REV_SOUND(vehicle, p1, p2)
    Velora.invoke(0x985FD0, "void", vehicle, p1, p2)
end

function RESET_VEHICLE_STARTUP_REV_SOUND(vehicle)
    Velora.invoke(0x985FF0, "void", vehicle)
end

function SET_VEHICLE_FORCE_REVERSE_WARNING(p0, p1)
    Velora.invoke(0x986050, "void", p0, p1)
end

function IS_VEHICLE_AUDIBLY_DAMAGED(invoke<BOOL>(0x9860C0, vehicle, damageFactor)
    return Velora.invoke(0x986140, "bool", invoke<BOOL>(0x9860C0, vehicle, damageFactor)
end

function SET_VEHICLE_AUDIO_BODY_DAMAGE_FACTOR(vehicle, intensity)
    Velora.invoke(0x9861A0, "void", vehicle, intensity)
end

function ENABLE_VEHICLE_FANBELT_DAMAGE(vehicle, toggle)
    Velora.invoke(0x986270, "void", vehicle, toggle)
end

function ENABLE_VEHICLE_EXHAUST_POPS(vehicle, toggle)
    Velora.invoke(0x9862F0, "void", vehicle, toggle)
end

function SET_VEHICLE_BOOST_ACTIVE(vehicle, toggle)
    Velora.invoke(0x986380, "void", vehicle, toggle)
end

function SET_PLAYER_VEHICLE_ALARM_AUDIO_ACTIVE(vehicle, toggle)
    Velora.invoke(0x986410, "void", vehicle, toggle)
end

function SET_SCRIPT_UPDATE_DOOR_AUDIO(doorHash, toggle)
    Velora.invoke(0x986480, "void", doorHash, toggle)
end

function PLAY_VEHICLE_DOOR_OPEN_SOUND(vehicle, doorId)
    Velora.invoke(0x9864D0, "void", vehicle, doorId)
end

function PLAY_VEHICLE_DOOR_CLOSE_SOUND(vehicle, doorId)
    Velora.invoke(0x986560, "void", vehicle, doorId)
end

function ENABLE_STALL_WARNING_SOUNDS(vehicle, toggle)
    Velora.invoke(0x9865F0, "void", vehicle, toggle)
end

function IS_GAME_IN_CONTROL_OF_MUSIC(active)
    return Velora.invoke(0x986700, "bool", active)
end

function PLAY_MISSION_COMPLETE_AUDIO(audioName)
    Velora.invoke(0x986720, "void", audioName)
end

function IS_MISSION_COMPLETE_PLAYING(toggle)
    return Velora.invoke(0x986790, "bool", toggle)
end

function START_AUDIO_SCENE(invoke<BOOL>(0x9867B0, scene)
    return Velora.invoke(0x9867F0, "bool", invoke<BOOL>(0x9867B0, scene)
end

function STOP_AUDIO_SCENES()
    Velora.invoke(0x986820, "void")
end

function IS_AUDIO_SCENE_ACTIVE(invoke<BOOL>(0x986830, scene, variable, value)
    return Velora.invoke(0x986870, "bool", invoke<BOOL>(0x986830, scene, variable, value)
end

function SET_AUDIO_SCRIPT_CLEANUP_TIME(time)
    Velora.invoke(0x986890, "void", time)
end

function ADD_ENTITY_TO_AUDIO_MIX_GROUP(entity, groupName, p2)
    Velora.invoke(0x9868B0, "void", entity, groupName, p2)
end

function REMOVE_ENTITY_FROM_AUDIO_MIX_GROUP(entity, p1)
    Velora.invoke(0x986940, "void", entity, p1)
end

function AUDIO_IS_MUSIC_PLAYING(invoke<BOOL>(0x986A20, invoke<BOOL>(0x986A90, invoke<BOOL>(0x986AD0, p0)
    return Velora.invoke(0x986B50, "bool", invoke<BOOL>(0x986A20, invoke<BOOL>(0x986A90, invoke<BOOL>(0x986AD0, p0)
end

function RECORD_BROKEN_GLASS(x, y, z, radius)
    Velora.invoke(0x986B70, "void", x, y, z, radius)
end

function CLEAR_ALL_BROKEN_GLASS()
    Velora.invoke(0x986BD0, "void")
end

function SCRIPT_OVERRIDES_WIND_ELEVATION(p0, p1)
    Velora.invoke(0x986BF0, "void", p0, p1)
end

function SET_PED_WALLA_DENSITY(p0, p1)
    Velora.invoke(0x986C50, "void", p0, p1)
end

function SET_PED_INTERIOR_WALLA_DENSITY(p0, p1)
    Velora.invoke(0x986C70, "void", p0, p1)
end

function FORCE_PED_PANIC_WALLA()
    Velora.invoke(0x986C90, "void")
end

function PREPARE_ALARM(invoke<BOOL>(0x986CA0, alarmName, p2)
    return Velora.invoke(0x986CD0, "bool", invoke<BOOL>(0x986CA0, alarmName, p2)
end

function STOP_ALARM(alarmName, toggle)
    Velora.invoke(0x986CF0, "void", alarmName, toggle)
end

function STOP_ALL_ALARMS(stop)
    Velora.invoke(0x986D10, "void", stop)
end

function IS_ALARM_PLAYING(invoke<BOOL>(0x986D30, invoke<Hash>(0x986D90, invoke<Hash>(0x986E00, ped)
    return Velora.invoke(0x986E70, "bool", invoke<BOOL>(0x986D30, invoke<Hash>(0x986D90, invoke<Hash>(0x986E00, ped)
end

function SET_PED_FOOTSTEPS_EVENTS_ENABLED(ped, toggle)
    Velora.invoke(0x986EC0, "void", ped, toggle)
end

function SET_PED_CLOTH_EVENTS_ENABLED(ped, toggle)
    Velora.invoke(0x986F10, "void", ped, toggle)
end

function OVERRIDE_PLAYER_GROUND_MATERIAL(hash, toggle)
    Velora.invoke(0x986F60, "void", hash, toggle)
end

function USE_FOOTSTEP_SCRIPT_SWEETENERS(ped, p1, hash)
    Velora.invoke(0x986FD0, "void", ped, p1, hash)
end

function OVERRIDE_MICROPHONE_SETTINGS(hash, toggle)
    Velora.invoke(0x987060, "void", hash, toggle)
end

function FREEZE_MICROPHONE()
    Velora.invoke(0x9870D0, "void")
end

function DISTANT_COP_CAR_SIRENS(value)
    Velora.invoke(0x987110, "void", value)
end

function SET_SIREN_CAN_BE_CONTROLLED_BY_AUDIO(vehicle, p1)
    Velora.invoke(0x9871B0, "void", vehicle, p1)
end

function ENABLE_STUNT_JUMP_AUDIO()
    Velora.invoke(0x987280, "void")
end

function SET_AUDIO_FLAG(flagName, toggle)
    Velora.invoke(0x987300, "void", flagName, toggle)
end

function PREPARE_SYNCHRONIZED_AUDIO_EVENT(audioEvent, invoke<BOOL>(0x987360, sceneID, invoke<BOOL>(0x987390, invoke<BOOL>(0x9873E0, invoke<BOOL>(0x987420, audioEvent, x, y, z)
    return Velora.invoke(0x987460, "bool", audioEvent, invoke<BOOL>(0x987360, sceneID, invoke<BOOL>(0x987390, invoke<BOOL>(0x9873E0, invoke<BOOL>(0x987420, audioEvent, x, y, z)
end

function INIT_SYNCH_SCENE_AUDIO_WITH_ENTITY(audioEvent, entity)
    Velora.invoke(0x9874D0, "void", audioEvent, entity)
end

function SET_AUDIO_SPECIAL_EFFECT_MODE(mode)
    Velora.invoke(0x987550, "void", mode)
end

function SET_PORTAL_SETTINGS_OVERRIDE(p0, p1)
    Velora.invoke(0x987570, "void", p0, p1)
end

function REMOVE_PORTAL_SETTINGS_OVERRIDE(p0)
    Velora.invoke(0x9875A0, "void", p0)
end

function STOP_SMOKE_GRENADE_EXPLOSION_SOUNDS()
    Velora.invoke(0x9875D0, "void")
end

function GET_MUSIC_VOL_SLIDER(ped)
    return Velora.invoke(0x987610, "int", ped)
end

function UNREQUEST_TENNIS_BANKS()
    Velora.invoke(0x987660, "void")
end

function SET_SKIP_MINIGUN_SPIN_UP_AUDIO(p0)
    Velora.invoke(0x987670, "void", p0)
end

function STOP_CUTSCENE_AUDIO()
    Velora.invoke(0x987690, "void")
end

function HAS_LOADED_MP_DATA_SET(invoke<int>(0x9876E0, vehicle, value)
    return Velora.invoke(0x987740, "bool", invoke<int>(0x9876E0, vehicle, value)
end

function ADD_SCRIPT_TO_RANDOM_PED(name, model, p2, p3)
    Velora.invoke(0x987E90, "void", name, model, p2, p3)
end

function REGISTER_OBJECT_SCRIPT_BRAIN(scriptName, modelHash, p2, activationRange, p4, p5)
    Velora.invoke(0x987F70, "void", scriptName, modelHash, p2, activationRange, p4, p5)
end

function IS_OBJECT_WITHIN_BRAIN_ACTIVATION_RANGE(invoke<BOOL>(0x988040, scriptName, activationRange, p2)
    return Velora.invoke(0x9880F0, "bool", invoke<BOOL>(0x988040, scriptName, activationRange, p2)
end

function IS_WORLD_POINT_WITHIN_BRAIN_ACTIVATION_RANGE(brainSet)
    return Velora.invoke(0x9881C0, "bool", brainSet)
end

function DISABLE_SCRIPT_BRAIN_SET(brainSet)
    Velora.invoke(0x9881E0, "void", brainSet)
end

function REACTIVATE_ALL_WORLD_BRAINS_THAT_ARE_WAITING_TILL_OUT_OF_RANGE()
    Velora.invoke(0x988200, "void")
end

function REACTIVATE_ALL_OBJECT_BRAINS_THAT_ARE_WAITING_TILL_OUT_OF_RANGE()
    Velora.invoke(0x988210, "void")
end

function REACTIVATE_NAMED_WORLD_BRAINS_WAITING_TILL_OUT_OF_RANGE(scriptName)
    Velora.invoke(0x988220, "void", scriptName)
end

function REACTIVATE_NAMED_OBJECT_BRAINS_WAITING_TILL_OUT_OF_RANGE(scriptName)
    Velora.invoke(0x988230, "void", scriptName)
end

function RENDER_SCRIPT_CAMS(render, ease, easeTime, p3, p4, p5)
    Velora.invoke(0x990E50, "void", render, ease, easeTime, p3, p4, p5)
end

function STOP_RENDERING_SCRIPT_CAMS_USING_CATCH_UP(render, p1, p2, p3)
    Velora.invoke(0x990F00, "void", render, p1, p2, p3)
end

function CREATE_CAM(camName, invoke<Cam>(0x990F80, camName, posX, posY, posZ, rotX, rotY, rotZ, fov, p8, invoke<Cam>(0x991000, camHash, invoke<Cam>(0x991170, camHash, posX, posY, posZ, rotX, rotY, rotZ, fov, p8, invoke<Cam>(0x9911F0, cam, bScriptHostCam)
    return Velora.invoke(0x991360, "int", camName, invoke<Cam>(0x990F80, camName, posX, posY, posZ, rotX, rotY, rotZ, fov, p8, invoke<Cam>(0x991000, camHash, invoke<Cam>(0x991170, camHash, posX, posY, posZ, rotX, rotY, rotZ, fov, p8, invoke<Cam>(0x9911F0, cam, bScriptHostCam)
end

function DESTROY_ALL_CAMS(bScriptHostCam)
    Velora.invoke(0x9913C0, "void", bScriptHostCam)
end

function DOES_CAM_EXIST(invoke<BOOL>(0x991400, cam, active)
    return Velora.invoke(0x991450, "bool", invoke<BOOL>(0x991400, cam, active)
end

function IS_CAM_ACTIVE(invoke<BOOL>(0x991470, invoke<BOOL>(0x9914D0, invoke<Vector3>(0x9915A0, cam, invoke<Vector3>(0x991660, invoke<float>(0x991760, invoke<float>(0x9917E0, invoke<float>(0x991860, invoke<float>(0x9918E0, invoke<float>(0x991960, invoke<float>(0x9919E0, cam, posX, posY, posZ, rotX, rotY, rotZ, fieldOfView, p8, p9, p10, p11)
    return Velora.invoke(0x991A60, "bool", invoke<BOOL>(0x991470, invoke<BOOL>(0x9914D0, invoke<Vector3>(0x9915A0, cam, invoke<Vector3>(0x991660, invoke<float>(0x991760, invoke<float>(0x9917E0, invoke<float>(0x991860, invoke<float>(0x9918E0, invoke<float>(0x991960, invoke<float>(0x9919E0, cam, posX, posY, posZ, rotX, rotY, rotZ, fieldOfView, p8, p9, p10, p11)
end

function SET_CAM_COORD(cam, posX, posY, posZ)
    Velora.invoke(0x991AA0, "void", cam, posX, posY, posZ)
end

function SET_CAM_ROT(cam, rotX, rotY, rotZ, rotationOrder)
    Velora.invoke(0x991B50, "void", cam, rotX, rotY, rotZ, rotationOrder)
end

function SET_CAM_FOV(cam, fieldOfView)
    Velora.invoke(0x991B70, "void", cam, fieldOfView)
end

function SET_CAM_NEAR_CLIP(cam, nearClip)
    Velora.invoke(0x991C30, "void", cam, nearClip)
end

function SET_CAM_FAR_CLIP(cam, farClip)
    Velora.invoke(0x991CB0, "void", cam, farClip)
end

function FORCE_CAM_FAR_CLIP(cam, p1)
    Velora.invoke(0x991D40, "void", cam, p1)
end

function SET_CAM_MOTION_BLUR_STRENGTH(cam, strength)
    Velora.invoke(0x991E00, "void", cam, strength)
end

function SET_CAM_NEAR_DOF(cam, nearDOF)
    Velora.invoke(0x991E90, "void", cam, nearDOF)
end

function SET_CAM_FAR_DOF(cam, farDOF)
    Velora.invoke(0x991F10, "void", cam, farDOF)
end

function SET_CAM_DOF_STRENGTH(cam, dofStrength)
    Velora.invoke(0x991F90, "void", cam, dofStrength)
end

function SET_CAM_DOF_PLANES(cam, p1, p2, p3, p4)
    Velora.invoke(0x992020, "void", cam, p1, p2, p3, p4)
end

function SET_CAM_USE_SHALLOW_DOF_MODE(cam, toggle)
    Velora.invoke(0x9920E0, "void", cam, toggle)
end

function SET_USE_HI_DOF()
    Velora.invoke(0x992160, "void")
end

function SET_USE_HI_DOF_ON_SYNCED_SCENE_THIS_UPDATE()
    Velora.invoke(0x992180, "void")
end

function SET_CAM_DOF_OVERRIDDEN_FOCUS_DISTANCE(camera, p1)
    Velora.invoke(0x9921A0, "void", camera, p1)
end

function SET_CAM_DOF_OVERRIDDEN_FOCUS_DISTANCE_BLEND_LEVEL(p0, p1)
    Velora.invoke(0x992280, "void", p0, p1)
end

function SET_CAM_DOF_FNUMBER_OF_LENS(camera, p1)
    Velora.invoke(0x992360, "void", camera, p1)
end

function SET_CAM_DOF_FOCAL_LENGTH_MULTIPLIER(camera, multiplier)
    Velora.invoke(0x992430, "void", camera, multiplier)
end

function SET_CAM_DOF_FOCUS_DISTANCE_BIAS(camera, p1)
    Velora.invoke(0x992500, "void", camera, p1)
end

function SET_CAM_DOF_MAX_NEAR_IN_FOCUS_DISTANCE(camera, p1)
    Velora.invoke(0x9925D0, "void", camera, p1)
end

function SET_CAM_DOF_MAX_NEAR_IN_FOCUS_DISTANCE_BLEND_LEVEL(camera, p1)
    Velora.invoke(0x9926A0, "void", camera, p1)
end

function ATTACH_CAM_TO_ENTITY(cam, entity, xOffset, yOffset, zOffset, isRelative)
    Velora.invoke(0x992810, "void", cam, entity, xOffset, yOffset, zOffset, isRelative)
end

function ATTACH_CAM_TO_PED_BONE(cam, ped, boneIndex, x, y, z, heading)
    Velora.invoke(0x992830, "void", cam, ped, boneIndex, x, y, z, heading)
end

function HARD_ATTACH_CAM_TO_PED_BONE(cam, ped, boneIndex, p3, p4, p5, p6, p7, p8, p9)
    Velora.invoke(0x992850, "void", cam, ped, boneIndex, p3, p4, p5, p6, p7, p8, p9)
end

function HARD_ATTACH_CAM_TO_ENTITY(cam, entity, xRot, yRot, zRot, xOffset, yOffset, zOffset, isRelative)
    Velora.invoke(0x992880, "void", cam, entity, xRot, yRot, zRot, xOffset, yOffset, zOffset, isRelative)
end

function ATTACH_CAM_TO_VEHICLE_BONE(cam, vehicle, boneIndex, relativeRotation, rotX, rotY, rotZ, offsetX, offsetY, offsetZ, fixedDirection)
    Velora.invoke(0x9928B0, "void", cam, vehicle, boneIndex, relativeRotation, rotX, rotY, rotZ, offsetX, offsetY, offsetZ, fixedDirection)
end

function DETACH_CAM(cam)
    Velora.invoke(0x992900, "void", cam)
end

function SET_CAM_INHERIT_ROLL_VEHICLE(cam, p1)
    Velora.invoke(0x992980, "void", cam, p1)
end

function POINT_CAM_AT_COORD(cam, x, y, z)
    Velora.invoke(0x992990, "void", cam, x, y, z)
end

function POINT_CAM_AT_ENTITY(cam, entity, p2, p3, p4, p5)
    Velora.invoke(0x992A50, "void", cam, entity, p2, p3, p4, p5)
end

function POINT_CAM_AT_PED_BONE(cam, ped, boneIndex, x, y, z, p6)
    Velora.invoke(0x992A70, "void", cam, ped, boneIndex, x, y, z, p6)
end

function STOP_CAM_POINTING(cam)
    Velora.invoke(0x992A90, "void", cam)
end

function SET_CAM_AFFECTS_AIMING(cam, toggle)
    Velora.invoke(0x992B10, "void", cam, toggle)
end

function SET_CAM_CONTROLS_MINI_MAP_HEADING(cam, toggle)
    Velora.invoke(0x992BA0, "void", cam, toggle)
end

function SET_CAM_IS_INSIDE_VEHICLE(cam, toggle)
    Velora.invoke(0x992C60, "void", cam, toggle)
end

function ALLOW_MOTION_BLUR_DECAY(p0, p1)
    Velora.invoke(0x992CF0, "void", p0, p1)
end

function SET_CAM_DEBUG_NAME(camera, name)
    Velora.invoke(0x992D80, "void", camera, name)
end

function GET_DEBUG_CAM(camera, x, y, z, xRot, yRot, zRot, length, smoothingStyle, rotationOrder)
    return Velora.invoke(0x992DB0, "int", camera, x, y, z, xRot, yRot, zRot, length, smoothingStyle, rotationOrder)
end

function ADD_CAM_SPLINE_NODE_USING_CAMERA_FRAME(cam, cam2, length, p3)
    Velora.invoke(0x992DD0, "void", cam, cam2, length, p3)
end

function ADD_CAM_SPLINE_NODE_USING_CAMERA(cam, cam2, length, p3)
    Velora.invoke(0x992DF0, "void", cam, cam2, length, p3)
end

function ADD_CAM_SPLINE_NODE_USING_GAMEPLAY_FRAME(cam, length, p2)
    Velora.invoke(0x992E10, "void", cam, length, p2)
end

function SET_CAM_SPLINE_PHASE(cam, p1)
    Velora.invoke(0x992EB0, "void", cam, p1)
end

function GET_CAM_SPLINE_PHASE(invoke<float>(0x992F50, invoke<float>(0x992FF0, cam, timeDuration)
    return Velora.invoke(0x993090, "float", invoke<float>(0x992F50, invoke<float>(0x992FF0, cam, timeDuration)
end

function SET_CAM_SPLINE_SMOOTHING_STYLE(cam, smoothingStyle)
    Velora.invoke(0x993110, "void", cam, smoothingStyle)
end

function GET_CAM_SPLINE_NODE_INDEX(invoke<int>(0x993190, cam, easingFunction, p2, p3)
    return Velora.invoke(0x993220, "int", invoke<int>(0x993190, cam, easingFunction, p2, p3)
end

function SET_CAM_SPLINE_NODE_VELOCITY_SCALE(cam, p1, scale)
    Velora.invoke(0x9932E0, "void", cam, p1, scale)
end

function OVERRIDE_CAM_SPLINE_VELOCITY(cam, p1, p2, p3)
    Velora.invoke(0x993300, "void", cam, p1, p2, p3)
end

function OVERRIDE_CAM_SPLINE_MOTION_BLUR(cam, p1, p2, p3)
    Velora.invoke(0x9933D0, "void", cam, p1, p2, p3)
end

function SET_CAM_SPLINE_NODE_EXTRA_FLAGS(cam, p1, flags)
    Velora.invoke(0x9934A0, "void", cam, p1, flags)
end

function IS_CAM_SPLINE_PAUSED(invoke<BOOL>(0x9934C0, camTo, camFrom, duration, easeLocation, easeRotation)
    return Velora.invoke(0x9935B0, "bool", invoke<BOOL>(0x9934C0, camTo, camFrom, duration, easeLocation, easeRotation)
end

function IS_CAM_INTERPOLATING(invoke<BOOL>(0x9935D0, cam, type, amplitude)
    return Velora.invoke(0x993600, "bool", invoke<BOOL>(0x9935D0, cam, type, amplitude)
end

function ANIMATED_SHAKE_CAM(cam, p1, p2, p3, amplitude)
    Velora.invoke(0x9936A0, "void", cam, p1, p2, p3, amplitude)
end

function IS_CAM_SHAKING(invoke<BOOL>(0x993750, cam, amplitude)
    return Velora.invoke(0x9937D0, "bool", invoke<BOOL>(0x993750, cam, amplitude)
end

function STOP_CAM_SHAKING(cam, p1)
    Velora.invoke(0x993850, "void", cam, p1)
end

function SHAKE_SCRIPT_GLOBAL(p0, p1)
    Velora.invoke(0x9938D0, "void", p0, p1)
end

function ANIMATED_SHAKE_SCRIPT_GLOBAL(p0, p1, p2, p3)
    Velora.invoke(0x993910, "void", p0, p1, p2, p3)
end

function IS_SCRIPT_GLOBAL_SHAKING(p0)
    return Velora.invoke(0x993990, "bool", p0)
end

function TRIGGER_VEHICLE_PART_BROKEN_CAMERA_SHAKE(vehicle, p1, p2)
    Velora.invoke(0x9939C0, "void", vehicle, p1, p2)
end

function PLAY_CAM_ANIM(cam, animName, animDictionary, x, y, z, xRot, yRot, zRot, p9, invoke<BOOL>(0x993A50, cam, animName, invoke<BOOL>(0x993A90, cam, phase)
    return Velora.invoke(0x993B40, "bool", cam, animName, animDictionary, x, y, z, xRot, yRot, zRot, p9, invoke<BOOL>(0x993A50, cam, animName, invoke<BOOL>(0x993A90, cam, phase)
end

function GET_CAM_ANIM_CURRENT_PHASE(invoke<float>(0x993BB0, p0, p1, animName, invoke<BOOL>(0x993C00, cam, p1, p2, p3)
    return Velora.invoke(0x993C30, "float", invoke<float>(0x993BB0, p0, p1, animName, invoke<BOOL>(0x993C00, cam, p1, p2, p3)
end

function SET_FLY_CAM_VERTICAL_RESPONSE(cam, p1, p2, p3)
    Velora.invoke(0x993CF0, "void", cam, p1, p2, p3)
end

function SET_FLY_CAM_MAX_HEIGHT(cam, height)
    Velora.invoke(0x993DB0, "void", cam, height)
end

function SET_FLY_CAM_COORD_AND_CONSTRAIN(cam, x, y, z)
    Velora.invoke(0x993E40, "void", cam, x, y, z)
end

function SET_FLY_CAM_VERTICAL_CONTROLS_THIS_UPDATE(cam)
    Velora.invoke(0x993EF0, "void", cam)
end

function WAS_FLY_CAM_CONSTRAINED_ON_PREVIOUS_UDPATE(invoke<BOOL>(0x993F60, duration)
    return Velora.invoke(0x994070, "bool", invoke<BOOL>(0x993F60, duration)
end

function DO_SCREEN_FADE_OUT(duration)
    Velora.invoke(0x994080, "void", duration)
end

function SET_WIDESCREEN_BORDERS(p0, p1)
    Velora.invoke(0x994090, "void", p0, p1)
end

function ARE_WIDESCREEN_BORDERS_ACTIVE(invoke<Vector3>(0x994110, p0)
    return Velora.invoke(0x9941E0, "bool", invoke<Vector3>(0x994110, p0)
end

function SET_GAMEPLAY_CAM_MAX_MOTION_BLUR_STRENGTH_THIS_UPDATE(p0)
    Velora.invoke(0x994220, "void", p0)
end

function GET_GAMEPLAY_CAM_RELATIVE_HEADING(heading)
    return Velora.invoke(0x9942A0, "float", heading)
end

function GET_GAMEPLAY_CAM_RELATIVE_PITCH(angle, scalingFactor)
    return Velora.invoke(0x9942E0, "float", angle, scalingFactor)
end

function RESET_GAMEPLAY_CAM_FULL_ATTACH_PARENT_TRANSFORM_TIMER()
    Velora.invoke(0x994350, "void")
end

function FORCE_CAMERA_RELATIVE_HEADING_AND_PITCH(roll, pitch, yaw)
    Velora.invoke(0x994380, "void", roll, pitch, yaw)
end

function FORCE_BONNET_CAMERA_RELATIVE_HEADING_AND_PITCH(p0, p1)
    Velora.invoke(0x9943A0, "void", p0, p1)
end

function SET_FIRST_PERSON_SHOOTER_CAMERA_HEADING(yaw)
    Velora.invoke(0x9944C0, "void", yaw)
end

function SET_FIRST_PERSON_SHOOTER_CAMERA_PITCH(pitch)
    Velora.invoke(0x994500, "void", pitch)
end

function SET_SCRIPTED_CAMERA_IS_FIRST_PERSON_THIS_FRAME(p0)
    Velora.invoke(0x994560, "void", p0)
end

function SHAKE_GAMEPLAY_CAM(shakeName, intensity)
    Velora.invoke(0x994580, "void", shakeName, intensity)
end

function IS_GAMEPLAY_CAM_SHAKING(amplitude)
    return Velora.invoke(0x9945F0, "bool", amplitude)
end

function STOP_GAMEPLAY_CAM_SHAKING(p0)
    Velora.invoke(0x994620, "void", p0)
end

function SET_GAMEPLAY_CAM_FOLLOW_PED_THIS_UPDATE(ped)
    Velora.invoke(0x994650, "void", ped)
end

function IS_GAMEPLAY_CAM_RENDERING(p0)
    return Velora.invoke(0x994770, "bool", p0)
end

function DISABLE_GAMEPLAY_CAM_ALTITUDE_FOV_SCALING_THIS_UPDATE()
    Velora.invoke(0x9947A0, "void")
end

function IS_GAMEPLAY_CAM_LOOKING_BEHIND(entity)
    return Velora.invoke(0x9947F0, "bool", entity)
end

function DISABLE_CAM_COLLISION_FOR_OBJECT(entity)
    Velora.invoke(0x994860, "void", entity)
end

function BYPASS_CAMERA_COLLISION_BUOYANCY_TEST_THIS_UPDATE()
    Velora.invoke(0x9948C0, "void")
end

function SET_GAMEPLAY_CAM_ENTITY_TO_LIMIT_FOCUS_OVER_BOUNDING_SPHERE_THIS_UPDATE(entity)
    Velora.invoke(0x9948F0, "void", entity)
end

function DISABLE_FIRST_PERSON_CAMERA_WATER_CLIPPING_TEST_THIS_UPDATE()
    Velora.invoke(0x994960, "void")
end

function SET_FOLLOW_CAM_IGNORE_ATTACH_PARENT_MOVEMENT_THIS_UPDATE()
    Velora.invoke(0x994980, "void")
end

function IS_SPHERE_VISIBLE(x, y, z, invoke<BOOL>(0x9949A0, camName, invoke<BOOL>(0x994A40, p0, p1)
    return Velora.invoke(0x994AD0, "bool", x, y, z, invoke<BOOL>(0x9949A0, camName, invoke<BOOL>(0x994A40, p0, p1)
end

function SET_FOLLOW_PED_CAM_LADDER_ALIGN_THIS_UPDATE()
    Velora.invoke(0x994B20, "void")
end

function SET_THIRD_PERSON_CAM_RELATIVE_HEADING_LIMITS_THIS_UPDATE(minimum, maximum)
    Velora.invoke(0x994B50, "void", minimum, maximum)
end

function SET_THIRD_PERSON_CAM_RELATIVE_PITCH_LIMITS_THIS_UPDATE(minimum, maximum)
    Velora.invoke(0x994BF0, "void", minimum, maximum)
end

function SET_THIRD_PERSON_CAM_ORBIT_DISTANCE_LIMITS_THIS_UPDATE(p0, distance)
    Velora.invoke(0x994C90, "void", p0, distance)
end

function SET_IN_VEHICLE_CAM_STATE_THIS_UPDATE(p0, p1)
    Velora.invoke(0x994D40, "void", p0, p1)
end

function DISABLE_ON_FOOT_FIRST_PERSON_VIEW_THIS_UPDATE()
    Velora.invoke(0x994DB0, "void")
end

function DISABLE_FIRST_PERSON_FLASH_EFFECT_THIS_UPDATE()
    Velora.invoke(0x994DD0, "void")
end

function BLOCK_FIRST_PERSON_ORIENTATION_RESET_THIS_UPDATE()
    Velora.invoke(0x994DE0, "void")
end

function GET_FOLLOW_PED_CAM_ZOOM_LEVEL(viewMode)
    return Velora.invoke(0x994E50, "int", viewMode)
end

function IS_FOLLOW_VEHICLE_CAM_ACTIVE(p0)
    return Velora.invoke(0x994E90, "bool", p0)
end

function SET_FOLLOW_VEHICLE_CAM_HIGH_ANGLE_MODE_EVERY_UPDATE(p0, p1)
    Velora.invoke(0x994EC0, "void", p0, p1)
end

function SET_TABLE_GAMES_CAMERA_THIS_UPDATE(invoke<BOOL>(0x994EF0, zoomLevel)
    return Velora.invoke(0x994F90, "bool", invoke<BOOL>(0x994EF0, zoomLevel)
end

function GET_FOLLOW_VEHICLE_CAM_VIEW_MODE(viewMode)
    return Velora.invoke(0x994FC0, "int", viewMode)
end

function GET_CAM_VIEW_MODE_FOR_CONTEXT(invoke<int>(0x994FD0, context, viewMode)
    return Velora.invoke(0x994FF0, "int", invoke<int>(0x994FD0, context, viewMode)
end

function GET_CAM_ACTIVE_VIEW_MODE_CONTEXT(USE_VEHICLE_CAM_STUNT_SETTINGS_THIS_UPDATE()
    return Velora.invoke(0x995030, "int", USE_VEHICLE_CAM_STUNT_SETTINGS_THIS_UPDATE()
end

function USE_DEDICATED_STUNT_CAMERA_THIS_UPDATE(camName)
    Velora.invoke(0x995050, "void", camName)
end

function FORCE_VEHICLE_CAM_STUNT_SETTINGS_THIS_UPDATE()
    Velora.invoke(0x995080, "void")
end

function SET_FOLLOW_VEHICLE_CAM_SEAT_THIS_UPDATE(seatIndex)
    Velora.invoke(0x9950A0, "void", seatIndex)
end

function IS_AIM_CAM_ACTIVE(DISABLE_AIM_CAM_THIS_UPDATE()
    return Velora.invoke(0x995190, "bool", DISABLE_AIM_CAM_THIS_UPDATE()
end

function GET_FIRST_PERSON_AIM_CAM_ZOOM_FACTOR(zoomFactor)
    return Velora.invoke(0x9951F0, "float", zoomFactor)
end

function SET_FIRST_PERSON_AIM_CAM_ZOOM_FACTOR_LIMITS_THIS_UPDATE(p0, p1)
    Velora.invoke(0x995210, "void", p0, p1)
end

function SET_FIRST_PERSON_AIM_CAM_RELATIVE_HEADING_LIMITS_THIS_UPDATE(p0, p1)
    Velora.invoke(0x995230, "void", p0, p1)
end

function SET_FIRST_PERSON_AIM_CAM_RELATIVE_PITCH_LIMITS_THIS_UPDATE(p0, p1)
    Velora.invoke(0x9953A0, "void", p0, p1)
end

function SET_FIRST_PERSON_AIM_CAM_NEAR_CLIP_THIS_UPDATE(p0)
    Velora.invoke(0x995440, "void", p0)
end

function SET_THIRD_PERSON_AIM_CAM_NEAR_CLIP_THIS_UPDATE(p0)
    Velora.invoke(0x995480, "void", p0)
end

function SET_ALLOW_CUSTOM_VEHICLE_DRIVE_BY_CAM_THIS_UPDATE(p0)
    Velora.invoke(0x9954C0, "void", p0)
end

function FORCE_TIGHTSPACE_CUSTOM_FRAMING_THIS_UPDATE()
    Velora.invoke(0x9954F0, "void")
end

function GET_FINAL_RENDERED_CAM_COORD(invoke<Vector3>(0x995550, player, invoke<Vector3>(0x9955E0, invoke<float>(0x995700, x, y, z, duration, blendOutDuration, blendInDuration, p6)
    local x, y, z = Velora.invoke(0x9957F0, "vector3", invoke<Vector3>(0x995550, player, invoke<Vector3>(0x9955E0, invoke<float>(0x995700, x, y, z, duration, blendOutDuration, blendInDuration, p6)
    return {x = x, y = y, z = z}
end

function SET_GAMEPLAY_PED_HINT(ped, x1, y1, z1, p4, duration, blendOutDuration, blendInDuration)
    Velora.invoke(0x995880, "void", ped, x1, y1, z1, p4, duration, blendOutDuration, blendInDuration)
end

function SET_GAMEPLAY_VEHICLE_HINT(vehicle, offsetX, offsetY, offsetZ, p4, time, easeInTime, easeOutTime)
    Velora.invoke(0x995950, "void", vehicle, offsetX, offsetY, offsetZ, p4, time, easeInTime, easeOutTime)
end

function SET_GAMEPLAY_OBJECT_HINT(object, xOffset, yOffset, zOffset, p4, time, easeInTime, easeOutTime)
    Velora.invoke(0x995A20, "void", object, xOffset, yOffset, zOffset, p4, time, easeInTime, easeOutTime)
end

function SET_GAMEPLAY_ENTITY_HINT(entity, xOffset, yOffset, zOffset, p4, time, easeInTime, easeOutTime, p8)
    Velora.invoke(0x995AF0, "void", entity, xOffset, yOffset, zOffset, p4, time, easeInTime, easeOutTime, p8)
end

function IS_GAMEPLAY_HINT_ACTIVE(p0)
    return Velora.invoke(0x995C00, "bool", p0)
end

function STOP_GAMEPLAY_HINT_BEING_CANCELLED_THIS_UPDATE(p0)
    Velora.invoke(0x995C40, "void", p0)
end

function STOP_CODE_GAMEPLAY_HINT(p0)
    Velora.invoke(0x995C50, "void", p0)
end

function IS_CODE_GAMEPLAY_HINT_ACTIVE(FOV)
    return Velora.invoke(0x995CC0, "bool", FOV)
end

function SET_GAMEPLAY_HINT_FOLLOW_DISTANCE_SCALAR(value)
    Velora.invoke(0x995D10, "void", value)
end

function SET_GAMEPLAY_HINT_BASE_ORBIT_PITCH_OFFSET(value)
    Velora.invoke(0x995D50, "void", value)
end

function SET_GAMEPLAY_HINT_CAMERA_RELATIVE_SIDE_OFFSET(xOffset)
    Velora.invoke(0x995D90, "void", xOffset)
end

function SET_GAMEPLAY_HINT_CAMERA_RELATIVE_VERTICAL_OFFSET(yOffset)
    Velora.invoke(0x995DD0, "void", yOffset)
end

function SET_GAMEPLAY_HINT_CAMERA_BLEND_TO_FOLLOW_PED_MEDIUM_VIEW_MODE(toggle)
    Velora.invoke(0x995E10, "void", toggle)
end

function SET_CINEMATIC_BUTTON_ACTIVE(p0)
    Velora.invoke(0x995E40, "void", p0)
end

function IS_CINEMATIC_CAM_RENDERING(shakeType, amount)
    return Velora.invoke(0x995ED0, "bool", shakeType, amount)
end

function IS_CINEMATIC_CAM_SHAKING(p0)
    return Velora.invoke(0x995F40, "bool", p0)
end

function STOP_CINEMATIC_CAM_SHAKING(p0)
    Velora.invoke(0x995F70, "void", p0)
end

function DISABLE_CINEMATIC_BONNET_CAMERA_THIS_UPDATE()
    Velora.invoke(0x995FA0, "void")
end

function DISABLE_CINEMATIC_VEHICLE_IDLE_MODE_THIS_UPDATE()
    Velora.invoke(0x995FC0, "void")
end

function INVALIDATE_CINEMATIC_VEHICLE_IDLE_MODE()
    Velora.invoke(0x995FE0, "void")
end

function INVALIDATE_IDLE_CAM()
    Velora.invoke(0x996000, "void")
end

function IS_CINEMATIC_IDLE_CAM_RENDERING(p0, time, p2, entity)
    return Velora.invoke(0x996080, "bool", p0, time, p2, entity)
end

function IS_CINEMATIC_SHOT_ACTIVE(invoke<BOOL>(0x9960A0, p0)
    return Velora.invoke(0x996110, "bool", invoke<BOOL>(0x9960A0, p0)
end

function FORCE_CINEMATIC_RENDERING_THIS_UPDATE(toggle)
    Velora.invoke(0x996170, "void", toggle)
end

function SET_CINEMATIC_NEWS_CHANNEL_ACTIVE_THIS_UPDATE()
    Velora.invoke(0x9961D0, "void")
end

function SET_CINEMATIC_MODE_ACTIVE(toggle)
    Velora.invoke(0x9961F0, "void", toggle)
end

function IS_IN_VEHICLE_MOBILE_PHONE_CAMERA_RENDERING(IGNORE_MENU_PREFERENCE_FOR_BONNET_CAMERA_THIS_UPDATE()
    return Velora.invoke(0x996310, "bool", IGNORE_MENU_PREFERENCE_FOR_BONNET_CAMERA_THIS_UPDATE()
end

function BYPASS_CUTSCENE_CAM_RENDERING_THIS_UPDATE()
    Velora.invoke(0x996330, "void")
end

function STOP_CUTSCENE_CAM_SHAKING(p0)
    Velora.invoke(0x996350, "void", p0)
end

function SET_CUTSCENE_CAM_FAR_CLIP_THIS_UPDATE(p0)
    Velora.invoke(0x996380, "void", p0)
end

function GET_FOCUS_PED_ON_SCREEN(p0, p1, p2, p3, p4, p5, p6, p7, invoke<Ped>(0x9963C0, DISABLE_NEAR_CLIP_SCAN_THIS_UPDATE()
    return Velora.invoke(0x996420, "int", p0, p1, p2, p3, p4, p5, p6, p7, invoke<Ped>(0x9963C0, DISABLE_NEAR_CLIP_SCAN_THIS_UPDATE()
end

function SET_CAM_DEATH_FAIL_EFFECT_STATE(p0)
    Velora.invoke(0x996430, "void", p0)
end

function SET_FIRST_PERSON_FLASH_EFFECT_TYPE(p0)
    Velora.invoke(0x996440, "void", p0)
end

function SET_FIRST_PERSON_FLASH_EFFECT_VEHICLE_MODEL_NAME(vehicleName)
    Velora.invoke(0x996470, "void", vehicleName)
end

function SET_FIRST_PERSON_FLASH_EFFECT_VEHICLE_MODEL_HASH(vehicleModel)
    Velora.invoke(0x9964A0, "void", vehicleModel)
end

function IS_ALLOWED_INDEPENDENT_CAMERA_MODES(CAMERA_PREVENT_COLLISION_SETTINGS_FOR_TRIPLEHEAD_IN_INTERIORS_THIS_UPDATE()
    return Velora.invoke(0x9964F0, "bool", CAMERA_PREVENT_COLLISION_SETTINGS_FOR_TRIPLEHEAD_IN_INTERIORS_THIS_UPDATE()
end

function REPLAY_GET_MAX_DISTANCE_ALLOWED_FROM_PLAYER(hour, minute, second)
    return Velora.invoke(0x9969B0, "float", hour, minute, second)
end

function PAUSE_CLOCK(toggle)
    Velora.invoke(0x9969E0, "void", toggle)
end

function ADVANCE_CLOCK_TIME_TO(hour, minute, second)
    Velora.invoke(0x996A00, "void", hour, minute, second)
end

function ADD_TO_CLOCK_TIME(hours, minutes, seconds)
    Velora.invoke(0x996A20, "void", hours, minutes, seconds)
end

function GET_CLOCK_HOURS(day, month, year)
    return Velora.invoke(0x996A70, "int", day, month, year)
end

function GET_CLOCK_DAY_OF_WEEK(year, month, day, hour, minute, second)
    return Velora.invoke(0x996AE0, "int", year, month, day, hour, minute, second)
end

function GET_UTC_TIME(year, month, day, hour, minute, second)
    Velora.invoke(0x996B00, "void", year, month, day, hour, minute, second)
end

function GET_LOCAL_TIME(year, month, day, hour, minute, second)
    Velora.invoke(0x996B20, "void", year, month, day, hour, minute, second)
end

function REQUEST_CUTSCENE(cutsceneName, flags)
    Velora.invoke(0x998FD0, "void", cutsceneName, flags)
end

function REQUEST_CUTSCENE_WITH_PLAYBACK_LIST(cutsceneName, playbackFlags, flags)
    Velora.invoke(0x999030, "void", cutsceneName, playbackFlags, flags)
end

function REMOVE_CUTSCENE()
    Velora.invoke(0x9990B0, "void")
end

function HAS_CUTSCENE_LOADED(invoke<BOOL>(0x999110, threadId)
    return Velora.invoke(0x999160, "bool", invoke<BOOL>(0x999110, threadId)
end

function CAN_REQUEST_ASSETS_FOR_CUTSCENE_ENTITY(invoke<BOOL>(0x9991C0, cutsceneEntName, p1, p2)
    return Velora.invoke(0x999200, "bool", invoke<BOOL>(0x9991C0, cutsceneEntName, p1, p2)
end

function REQUEST_CUT_FILE(cutsceneName)
    Velora.invoke(0x999220, "void", cutsceneName)
end

function HAS_CUT_FILE_LOADED(invoke<BOOL>(0x9992D0, cutsceneName)
    return Velora.invoke(0x999300, "bool", invoke<BOOL>(0x9992D0, cutsceneName)
end

function GET_CUT_FILE_CONCAT_COUNT(invoke<int>(0x999380, flags)
    return Velora.invoke(0x9993B0, "int", invoke<int>(0x999380, flags)
end

function START_CUTSCENE_AT_COORDS(x, y, z, flags)
    Velora.invoke(0x9993E0, "void", x, y, z, flags)
end

function STOP_CUTSCENE(p0)
    Velora.invoke(0x9993F0, "void", p0)
end

function STOP_CUTSCENE_IMMEDIATELY()
    Velora.invoke(0x999430, "void")
end

function SET_CUTSCENE_ORIGIN(x, y, z, p3, p4)
    Velora.invoke(0x999460, "void", x, y, z, p3, p4)
end

function SET_CUTSCENE_ORIGIN_AND_ORIENTATION(x1, y1, z1, x2, y2, z2, p6)
    Velora.invoke(0x999480, "void", x1, y1, z1, x2, y2, z2, p6)
end

function GET_CUTSCENE_TIME(cutsceneEntName, invoke<Entity>(0x999680, invoke<BOOL>(0x999760, invoke<int>(0x999770, cutscenePed, cutsceneEntName, p2, modelHash, p4)
    return Velora.invoke(0x999810, "int", cutsceneEntName, invoke<Entity>(0x999680, invoke<BOOL>(0x999760, invoke<int>(0x999770, cutscenePed, cutsceneEntName, p2, modelHash, p4)
end

function GET_ENTITY_INDEX_OF_REGISTERED_ENTITY(cutsceneEntName, invoke<Entity>(0x999830, modelHash)
    return Velora.invoke(0x999860, "int", cutsceneEntName, invoke<Entity>(0x999830, modelHash)
end

function SET_CUTSCENE_TRIGGER_AREA(x1, y1, z1, x2, y2, z2)
    Velora.invoke(0x999880, "void", x1, y1, z1, x2, y2, z2)
end

function CAN_SET_ENTER_STATE_FOR_REGISTERED_ENTITY(cutsceneEntName, invoke<BOOL>(0x999920, cutsceneEntName, invoke<BOOL>(0x9999A0, invoke<BOOL>(0x999A20, toggle)
    return Velora.invoke(0x999A60, "bool", cutsceneEntName, invoke<BOOL>(0x999920, cutsceneEntName, invoke<BOOL>(0x9999A0, invoke<BOOL>(0x999A20, toggle)
end

function SET_CUTSCENE_FADE_VALUES(p0, p1, p2, p3)
    Velora.invoke(0x999AA0, "void", p0, p1, p2, p3)
end

function SET_CUTSCENE_MULTIHEAD_FADE(p0, p1, p2, p3)
    Velora.invoke(0x999B50, "void", p0, p1, p2, p3)
end

function SET_CUTSCENE_MULTIHEAD_FADE_MANUAL(p0)
    Velora.invoke(0x999B60, "void", p0)
end

function IS_MULTIHEAD_FADE_UP(p0)
    return Velora.invoke(0x999B80, "bool", p0)
end

function SET_CAR_GENERATORS_CAN_UPDATE_DURING_CUTSCENE(p0)
    Velora.invoke(0x999BC0, "void", p0)
end

function CAN_USE_MOBILE_PHONE_DURING_CUTSCENE(p0)
    return Velora.invoke(0x999C50, "bool", p0)
end

function SET_CAN_DISPLAY_MINIMAP_DURING_CUTSCENE_THIS_UPDATE()
    Velora.invoke(0x999C90, "void")
end

function SET_CUTSCENE_PED_COMPONENT_VARIATION(cutsceneEntName, componentId, drawableId, textureId, modelHash)
    Velora.invoke(0x999CC0, "void", cutsceneEntName, componentId, drawableId, textureId, modelHash)
end

function SET_CUTSCENE_PED_COMPONENT_VARIATION_FROM_PED(cutsceneEntName, ped, modelHash)
    Velora.invoke(0x999CE0, "void", cutsceneEntName, ped, modelHash)
end

function DOES_CUTSCENE_ENTITY_EXIST(cutsceneEntName, invoke<BOOL>(0x999D00, cutsceneEntName, componentId, drawableId, textureId, modelHash)
    return Velora.invoke(0x999DA0, "bool", cutsceneEntName, invoke<BOOL>(0x999D00, cutsceneEntName, componentId, drawableId, textureId, modelHash)
end

function HAS_CUTSCENE_CUT_THIS_FRAME(requestId)
    return Velora.invoke(0x99DCC0, "bool", requestId)
end

function DATAFILE_CLEAR_WATCH_LIST()
    Velora.invoke(0x99DCD0, "void")
end

function DATAFILE_IS_VALID_REQUEST_ID(invoke<BOOL>(0x99DD10, invoke<BOOL>(0x99DD50, invoke<BOOL>(0x99DDA0, requestId, invoke<BOOL>(0x99DE20, invoke<BOOL>(0x99DE50, data, dataCount, contentName, description, tagsCsv, contentTypeName, publish, invoke<BOOL>(0x99DE80, contentName, description, tagsCsv, contentTypeName, publish, invoke<BOOL>(0x99DEE0, contentId, data, dataCount, contentName, description, tagsCsv, contentTypeName, invoke<BOOL>(0x99DF20, contentId, contentName, description, tagsCsv, contentTypeName, invoke<BOOL>(0x99DF70, contentId, rating, contentTypeName, invoke<BOOL>(0x99DFB0, p0, invoke<BOOL>(0x99DFE0, p0, p1, invoke<BOOL>(0x99E010, p0, invoke<BOOL>(0x99E040, p0, invoke<BOOL>(0x99E070, filename, invoke<BOOL>(0x99E0A0, p0)
    return Velora.invoke(0x99E0D0, "bool", invoke<BOOL>(0x99DD10, invoke<BOOL>(0x99DD50, invoke<BOOL>(0x99DDA0, requestId, invoke<BOOL>(0x99DE20, invoke<BOOL>(0x99DE50, data, dataCount, contentName, description, tagsCsv, contentTypeName, publish, invoke<BOOL>(0x99DE80, contentName, description, tagsCsv, contentTypeName, publish, invoke<BOOL>(0x99DEE0, contentId, data, dataCount, contentName, description, tagsCsv, contentTypeName, invoke<BOOL>(0x99DF20, contentId, contentName, description, tagsCsv, contentTypeName, invoke<BOOL>(0x99DF70, contentId, rating, contentTypeName, invoke<BOOL>(0x99DFB0, p0, invoke<BOOL>(0x99DFE0, p0, p1, invoke<BOOL>(0x99E010, p0, invoke<BOOL>(0x99E040, p0, invoke<BOOL>(0x99E070, filename, invoke<BOOL>(0x99E0A0, p0)
end

function DATAFILE_DELETE(p0)
    Velora.invoke(0x99E0E0, "void", p0)
end

function DATAFILE_STORE_MISSION_HEADER(p0)
    Velora.invoke(0x99E1E0, "void", p0)
end

function DATAFILE_FLUSH_MISSION_HEADER()
    Velora.invoke(0x99E1F0, "void")
end

function DATAFILE_GET_FILE_DICT(invoke<Any>(0x99E2C0, filename, invoke<BOOL>(0x99E2F0, invoke<BOOL>(0x99E380, p0, invoke<BOOL>(0x99E3F0, p0)
    return Velora.invoke(0x99E420, "int", invoke<Any>(0x99E2C0, filename, invoke<BOOL>(0x99E2F0, invoke<BOOL>(0x99E380, p0, invoke<BOOL>(0x99E3F0, p0)
end

function DATAFILE_GET_FILE_DICT_FOR_ADDITIONAL_DATA_FILE(invoke<Any>(0x99E520, objectData, key, value)
    return Velora.invoke(0x99E550, "int", invoke<Any>(0x99E520, objectData, key, value)
end

function DATADICT_SET_INT(objectData, key, value)
    Velora.invoke(0x99E570, "void", objectData, key, value)
end

function DATADICT_SET_FLOAT(objectData, key, value)
    Velora.invoke(0x99E590, "void", objectData, key, value)
end

function DATADICT_SET_STRING(objectData, key, value)
    Velora.invoke(0x99E5B0, "void", objectData, key, value)
end

function DATADICT_SET_VECTOR(objectData, key, valueX, valueY, valueZ)
    Velora.invoke(0x99E5D0, "void", objectData, key, valueX, valueY, valueZ)
end

function DATADICT_CREATE_DICT(objectData, invoke<Any>(0x99E600, objectData, invoke<Any>(0x99E630, objectData, invoke<BOOL>(0x99E660, objectData, invoke<int>(0x99E710, objectData, invoke<float>(0x99E7B0, objectData, char>(0x99E870, objectData, invoke<Vector3>(0x99E920, objectData, invoke<Any>(0x99E9F0, objectData, invoke<Any>(0x99EA90, objectData, invoke<int>(0x99EB30, arrayData, value)
    return Velora.invoke(0x99EBD0, "int", objectData, invoke<Any>(0x99E600, objectData, invoke<Any>(0x99E630, objectData, invoke<BOOL>(0x99E660, objectData, invoke<int>(0x99E710, objectData, invoke<float>(0x99E7B0, objectData, char>(0x99E870, objectData, invoke<Vector3>(0x99E920, objectData, invoke<Any>(0x99E9F0, objectData, invoke<Any>(0x99EA90, objectData, invoke<int>(0x99EB30, arrayData, value)
end

function DATAARRAY_ADD_INT(arrayData, value)
    Velora.invoke(0x99EBF0, "void", arrayData, value)
end

function DATAARRAY_ADD_FLOAT(arrayData, value)
    Velora.invoke(0x99EC10, "void", arrayData, value)
end

function DATAARRAY_ADD_STRING(arrayData, value)
    Velora.invoke(0x99EC30, "void", arrayData, value)
end

function DATAARRAY_ADD_VECTOR(arrayData, valueX, valueY, valueZ)
    Velora.invoke(0x99EC50, "void", arrayData, valueX, valueY, valueZ)
end

function DATAARRAY_ADD_DICT(invoke<Any>(0x99EC80, arrayData, invoke<BOOL>(0x99ECB0, arrayData, invoke<int>(0x99ED20, arrayData, invoke<float>(0x99ED80, arrayData, char>(0x99EDF0, arrayData, invoke<Vector3>(0x99EE60, arrayData, invoke<Any>(0x99EEE0, invoke<int>(0x99EF40, arrayData, invoke<int>(0x99EF60, entity, propertyName, invoke<BOOL>(0x9A0030, entity, propertyName, invoke<BOOL>(0x9A0060, entity, propertyName, invoke<BOOL>(0x9A0140, entity, propertyName, invoke<BOOL>(0x9A0220, entity, invoke<BOOL>(0x9A02F0, entity, invoke<float>(0x9A03B0, entity, invoke<int>(0x9A0480, entity, invoke<BOOL>(0x9A0540, entity, invoke<BOOL>(0x9A05C0, propertyName, type)
    return Velora.invoke(0x9A0640, "int", invoke<Any>(0x99EC80, arrayData, invoke<BOOL>(0x99ECB0, arrayData, invoke<int>(0x99ED20, arrayData, invoke<float>(0x99ED80, arrayData, char>(0x99EDF0, arrayData, invoke<Vector3>(0x99EE60, arrayData, invoke<Any>(0x99EEE0, invoke<int>(0x99EF40, arrayData, invoke<int>(0x99EF60, entity, propertyName, invoke<BOOL>(0x9A0030, entity, propertyName, invoke<BOOL>(0x9A0060, entity, propertyName, invoke<BOOL>(0x9A0140, entity, propertyName, invoke<BOOL>(0x9A0220, entity, invoke<BOOL>(0x9A02F0, entity, invoke<float>(0x9A03B0, entity, invoke<int>(0x9A0480, entity, invoke<BOOL>(0x9A0540, entity, invoke<BOOL>(0x9A05C0, propertyName, type)
end

function DECOR_IS_REGISTERED_AS_TYPE(propertyName, invoke<BOOL>(0x9A06C0, DECOR_REGISTER_LOCK()
    return Velora.invoke(0x9A0730, "bool", propertyName, invoke<BOOL>(0x9A06C0, DECOR_REGISTER_LOCK()
end

function ARE_ANY_CCS_PENDING(invoke<BOOL>(0x9D2B80, p0, invoke<BOOL>(0x9D2C30, ON_ENTER_SP()
    return Velora.invoke(0x9D2C50, "bool", invoke<BOOL>(0x9D2B80, p0, invoke<BOOL>(0x9D2C30, ON_ENTER_SP()
end

function ON_ENTER_MP()
    Velora.invoke(0x9D2CA0, "void")
end

function DOES_ENTITY_EXIST(invoke<BOOL>(0x9B2290, entity, invoke<BOOL>(0x9B22F0, invoke<BOOL>(0x9B2370, invoke<BOOL>(0x9B23D0, invoke<BOOL>(0x9B2430, invoke<BOOL>(0x9B24C0, entity, animDict, animName, invoke<BOOL>(0x9B2520, invoke<BOOL>(0x9B2550, invoke<BOOL>(0x9B25B0, invoke<BOOL>(0x9B2610, entity1, entity2, invoke<BOOL>(0x9B2670, entity1, entity2, invoke<BOOL>(0x9B26A0, entity1, entity2, invoke<BOOL>(0x9B26D0, entity1, invoke<BOOL>(0x9B2700, invoke<BOOL>(0x9B2730, invoke<Entity>(0x9B27B0, invoke<Hash>(0x9B2840, invoke<Vector3>(0x9B2920, entity)
    return Velora.invoke(0x9B2A20, "bool", invoke<BOOL>(0x9B2290, entity, invoke<BOOL>(0x9B22F0, invoke<BOOL>(0x9B2370, invoke<BOOL>(0x9B23D0, invoke<BOOL>(0x9B2430, invoke<BOOL>(0x9B24C0, entity, animDict, animName, invoke<BOOL>(0x9B2520, invoke<BOOL>(0x9B2550, invoke<BOOL>(0x9B25B0, invoke<BOOL>(0x9B2610, entity1, entity2, invoke<BOOL>(0x9B2670, entity1, entity2, invoke<BOOL>(0x9B26A0, entity1, entity2, invoke<BOOL>(0x9B26D0, entity1, invoke<BOOL>(0x9B2700, invoke<BOOL>(0x9B2730, invoke<Entity>(0x9B27B0, invoke<Hash>(0x9B2840, invoke<Vector3>(0x9B2920, entity)
end

function GET_ENTITY_ANIM_CURRENT_TIME(entity, animDict, invoke<float>(0x9B2A90, entity, animDict, invoke<float>(0x9B2AC0, animDict, invoke<float>(0x9B2AF0, invoke<Entity>(0x9B2B30, entity, invoke<Vector3>(0x9B2BC0, invoke<Vector3>(0x9B2C70, invoke<float>(0x9B2D10, invoke<float>(0x9B2D80, invoke<float>(0x9B2DF0, invoke<float>(0x9B2EA0, invoke<int>(0x9B3010, invoke<int>(0x9B3060, entity, value)
    return Velora.invoke(0x9B30B0, "float", entity, animDict, invoke<float>(0x9B2A90, entity, animDict, invoke<float>(0x9B2AC0, animDict, invoke<float>(0x9B2AF0, invoke<Entity>(0x9B2B30, entity, invoke<Vector3>(0x9B2BC0, invoke<Vector3>(0x9B2C70, invoke<float>(0x9B2D10, invoke<float>(0x9B2D80, invoke<float>(0x9B2DF0, invoke<float>(0x9B2EA0, invoke<int>(0x9B3010, invoke<int>(0x9B3060, entity, value)
end

function GET_ENTITY_HEIGHT(entity, X, Y, Z, atTop, invoke<float>(0x9B3120, invoke<float>(0x9B3160, entity, forwardVector, rightVector, upVector, position)
    return Velora.invoke(0x9B31E0, "float", entity, X, Y, Z, atTop, invoke<float>(0x9B3120, invoke<float>(0x9B3160, entity, forwardVector, rightVector, upVector, position)
end

function GET_ENTITY_MODEL(invoke<Hash>(0x9B3330, entity, posX, posY, invoke<Vector3>(0x9B3350, entity, offsetX, offsetY, invoke<Vector3>(0x9B3470, invoke<float>(0x9B3530, entity, x, y, z, w)
    return Velora.invoke(0x9B3560, "int", invoke<Hash>(0x9B3330, entity, posX, posY, invoke<Vector3>(0x9B3350, entity, offsetX, offsetY, invoke<Vector3>(0x9B3470, invoke<float>(0x9B3530, entity, x, y, z, w)
end

function GET_ENTITY_ROLL(invoke<float>(0x9B36A0, entity, invoke<Vector3>(0x9B36D0, invoke<Vector3>(0x9B3840, entity, char>(0x9B3920, invoke<float>(0x9B3980, entity, invoke<Vector3>(0x9B3A30, invoke<float>(0x9B3B70, invoke<Vector3>(0x9B3BC0, invoke<Object>(0x9B3C90, invoke<Ped>(0x9B3CA0, invoke<Vehicle>(0x9B3CB0, entity, invoke<Vector3>(0x9B3CC0, invoke<Player>(0x9B3D30, entity, invoke<Player>(0x9B3D70, invoke<int>(0x9B3DD0, invoke<int>(0x9B3E40, invoke<BOOL>(0x9B3EB0, invoke<BOOL>(0x9B3EF0, invoke<BOOL>(0x9B3F50, invoke<BOOL>(0x9B3FB0, invoke<BOOL>(0x9B4010, entity, xPos, yPos, zPos, xSize, ySize, zSize, p7, p8, invoke<BOOL>(0x9B4070, entity1, entity2, xSize, ySize, zSize, p5, p6, invoke<BOOL>(0x9B40C0, invoke<BOOL>(0x9B4110, invoke<BOOL>(0x9B41A0, invoke<BOOL>(0x9B4230, invoke<BOOL>(0x9B42C0, from, invoke<BOOL>(0x9B4350, entity, invoke<BOOL>(0x9B4380, invoke<BOOL>(0x9B4440, entity, x1, y1, z1, x2, y2, z2, width, debug, includeZ, invoke<BOOL>(0x9B4470, entity, x1, y1, z1, x2, y2, z2, p7, p8, invoke<BOOL>(0x9B44C0, entity, invoke<BOOL>(0x9B4510, invoke<BOOL>(0x9B4600, invoke<float>(0x9B4630, entity, toggle)
    return Velora.invoke(0x9B46A0, "float", invoke<float>(0x9B36A0, entity, invoke<Vector3>(0x9B36D0, invoke<Vector3>(0x9B3840, entity, char>(0x9B3920, invoke<float>(0x9B3980, entity, invoke<Vector3>(0x9B3A30, invoke<float>(0x9B3B70, invoke<Vector3>(0x9B3BC0, invoke<Object>(0x9B3C90, invoke<Ped>(0x9B3CA0, invoke<Vehicle>(0x9B3CB0, entity, invoke<Vector3>(0x9B3CC0, invoke<Player>(0x9B3D30, entity, invoke<Player>(0x9B3D70, invoke<int>(0x9B3DD0, invoke<int>(0x9B3E40, invoke<BOOL>(0x9B3EB0, invoke<BOOL>(0x9B3EF0, invoke<BOOL>(0x9B3F50, invoke<BOOL>(0x9B3FB0, invoke<BOOL>(0x9B4010, entity, xPos, yPos, zPos, xSize, ySize, zSize, p7, p8, invoke<BOOL>(0x9B4070, entity1, entity2, xSize, ySize, zSize, p5, p6, invoke<BOOL>(0x9B40C0, invoke<BOOL>(0x9B4110, invoke<BOOL>(0x9B41A0, invoke<BOOL>(0x9B4230, invoke<BOOL>(0x9B42C0, from, invoke<BOOL>(0x9B4350, entity, invoke<BOOL>(0x9B4380, invoke<BOOL>(0x9B4440, entity, x1, y1, z1, x2, y2, z2, width, debug, includeZ, invoke<BOOL>(0x9B4470, entity, x1, y1, z1, x2, y2, z2, p7, p8, invoke<BOOL>(0x9B44C0, entity, invoke<BOOL>(0x9B4510, invoke<BOOL>(0x9B4600, invoke<float>(0x9B4630, entity, toggle)
end

function IS_ENTITY_ON_SCREEN(invoke<BOOL>(0x9B4700, entity, animDict, animName, invoke<BOOL>(0x9B47A0, invoke<BOOL>(0x9B47D0, entity, invoke<BOOL>(0x9B4830, entity, invoke<BOOL>(0x9B4860, entity, invoke<BOOL>(0x9B4890, invoke<BOOL>(0x9B4920, invoke<BOOL>(0x9B4980, invoke<BOOL>(0x9B49E0, invoke<BOOL>(0x9B4A60, entityModelHash, x, y, z, invoke<BOOL>(0x9B4A90, invoke<BOOL>(0x9B4AD0, entity, forceType, x, y, z, p5, isDirectionRel, isForceRel, p8)
    return Velora.invoke(0x9B4BA0, "bool", invoke<BOOL>(0x9B4700, entity, animDict, animName, invoke<BOOL>(0x9B47A0, invoke<BOOL>(0x9B47D0, entity, invoke<BOOL>(0x9B4830, entity, invoke<BOOL>(0x9B4860, entity, invoke<BOOL>(0x9B4890, invoke<BOOL>(0x9B4920, invoke<BOOL>(0x9B4980, invoke<BOOL>(0x9B49E0, invoke<BOOL>(0x9B4A60, entityModelHash, x, y, z, invoke<BOOL>(0x9B4A90, invoke<BOOL>(0x9B4AD0, entity, forceType, x, y, z, p5, isDirectionRel, isForceRel, p8)
end

function APPLY_FORCE_TO_ENTITY(entity, forceFlags, x, y, z, offX, offY, offZ, boneIndex, isDirectionRel, ignoreUpVec, isForceRel, p12, p13)
    Velora.invoke(0x9B4C40, "void", entity, forceFlags, x, y, z, offX, offY, offZ, boneIndex, isDirectionRel, ignoreUpVec, isForceRel, p12, p13)
end

function ATTACH_ENTITY_TO_ENTITY(entity1, entity2, boneIndex, xPos, yPos, zPos, xRot, yRot, zRot, p9, useSoftPinning, collision, isPed, vertexIndex, fixedRot, p15)
    Velora.invoke(0x9B4CC0, "void", entity1, entity2, boneIndex, xPos, yPos, zPos, xRot, yRot, zRot, p9, useSoftPinning, collision, isPed, vertexIndex, fixedRot, p15)
end

function ATTACH_ENTITY_BONE_TO_ENTITY_BONE(entity1, entity2, boneIndex1, boneIndex2, p4, p5)
    Velora.invoke(0x9B4E60, "void", entity1, entity2, boneIndex1, boneIndex2, p4, p5)
end

function ATTACH_ENTITY_BONE_TO_ENTITY_BONE_Y_FORWARD(entity1, entity2, boneIndex1, boneIndex2, p4, p5)
    Velora.invoke(0x9B4E90, "void", entity1, entity2, boneIndex1, boneIndex2, p4, p5)
end

function ATTACH_ENTITY_TO_ENTITY_PHYSICALLY(entity1, entity2, boneIndex1, boneIndex2, xPos1, yPos1, zPos1, xPos2, yPos2, zPos2, xRot, yRot, zRot, breakForce, fixedRot, p15, collision, p17, p18)
    Velora.invoke(0x9B4EC0, "void", entity1, entity2, boneIndex1, boneIndex2, xPos1, yPos1, zPos1, xPos2, yPos2, zPos2, xRot, yRot, zRot, breakForce, fixedRot, p15, collision, p17, p18)
end

function PROCESS_ENTITY_ATTACHMENTS(entity)
    Velora.invoke(0x9B5020, "void", entity)
end

function GET_ENTITY_BONE_INDEX_BY_NAME(entity, invoke<int>(0x9B5030, entity)
    return Velora.invoke(0x9B5100, "int", entity, invoke<int>(0x9B5030, entity)
end

function DELETE_ENTITY(entity)
    Velora.invoke(0x9B5160, "void", entity)
end

function DETACH_ENTITY(entity, dynamic, collision)
    Velora.invoke(0x9B5170, "void", entity, dynamic, collision)
end

function FREEZE_ENTITY_POSITION(entity, toggle)
    Velora.invoke(0x9B5190, "void", entity, toggle)
end

function SET_ENTITY_SHOULD_FREEZE_WAITING_ON_COLLISION(entity, toggle)
    Velora.invoke(0x9B51B0, "void", entity, toggle)
end

function PLAY_ENTITY_ANIM(entity, animName, animDict, p3, loop, stayInAnim, p6, delta, invoke<BOOL>(0x9B52A0, entity, syncedScene, animation, propName, p4, p5, p6, invoke<BOOL>(0x9B5310, x1, y1, z1, x2, y2, z2, p6, p7, p8, p9, p10, invoke<BOOL>(0x9B5360, x1, y1, z1, x2, y2, invoke<BOOL>(0x9B5450, entity, animation, animGroup, invoke<BOOL>(0x9B54F0, entity, p1, invoke<BOOL>(0x9B5510, entity, invoke<BOOL>(0x9B5550, animDictionary, animName, p2, p3, invoke<BOOL>(0x9B5580, entity, animDictionary, animName, time)
    return Velora.invoke(0x9B55C0, "bool", entity, animName, animDict, p3, loop, stayInAnim, p6, delta, invoke<BOOL>(0x9B52A0, entity, syncedScene, animation, propName, p4, p5, p6, invoke<BOOL>(0x9B5310, x1, y1, z1, x2, y2, z2, p6, p7, p8, p9, p10, invoke<BOOL>(0x9B5360, x1, y1, z1, x2, y2, invoke<BOOL>(0x9B5450, entity, animation, animGroup, invoke<BOOL>(0x9B54F0, entity, p1, invoke<BOOL>(0x9B5510, entity, invoke<BOOL>(0x9B5550, animDictionary, animName, p2, p3, invoke<BOOL>(0x9B5580, entity, animDictionary, animName, time)
end

function SET_ENTITY_ANIM_SPEED(entity, animDictionary, animName, speedMultiplier)
    Velora.invoke(0x9B55E0, "void", entity, animDictionary, animName, speedMultiplier)
end

function SET_ENTITY_AS_MISSION_ENTITY(entity, p1, p2)
    Velora.invoke(0x9B5600, "void", entity, p1, p2)
end

function SET_ENTITY_AS_NO_LONGER_NEEDED(entity)
    Velora.invoke(0x9B5620, "void", entity)
end

function SET_PED_AS_NO_LONGER_NEEDED(ped)
    Velora.invoke(0x9B5680, "void", ped)
end

function SET_VEHICLE_AS_NO_LONGER_NEEDED(vehicle)
    Velora.invoke(0x9B56E0, "void", vehicle)
end

function SET_OBJECT_AS_NO_LONGER_NEEDED(object)
    Velora.invoke(0x9B5740, "void", object)
end

function SET_ENTITY_CAN_BE_DAMAGED(entity, toggle)
    Velora.invoke(0x9B57A0, "void", entity, toggle)
end

function GET_ENTITY_CAN_BE_DAMAGED(invoke<BOOL>(0x9B5830, entity, bCanBeDamaged, relGroup)
    return Velora.invoke(0x9B5890, "bool", invoke<BOOL>(0x9B5830, entity, bCanBeDamaged, relGroup)
end

function SET_ENTITY_CAN_ONLY_BE_DAMAGED_BY_SCRIPT_PARTICIPANTS(entity, toggle)
    Velora.invoke(0x9B5960, "void", entity, toggle)
end

function SET_ENTITY_CAN_BE_TARGETED_WITHOUT_LOS(entity, toggle)
    Velora.invoke(0x9B59E0, "void", entity, toggle)
end

function SET_ENTITY_COLLISION(entity, toggle, keepPhysics)
    Velora.invoke(0x9B5AE0, "void", entity, toggle, keepPhysics)
end

function GET_ENTITY_COLLISION_DISABLED(invoke<BOOL>(0x9B5B10, entity, toggle, keepPhysics)
    return Velora.invoke(0x9B5B70, "bool", invoke<BOOL>(0x9B5B10, entity, toggle, keepPhysics)
end

function SET_ENTITY_COORDS(entity, xPos, yPos, zPos, xAxis, yAxis, zAxis, clearArea)
    Velora.invoke(0x9B5BA0, "void", entity, xPos, yPos, zPos, xAxis, yAxis, zAxis, clearArea)
end

function SET_ENTITY_COORDS_WITHOUT_PLANTS_RESET(entity, xPos, yPos, zPos, alive, deadFlag, ragdollFlag, clearArea)
    Velora.invoke(0x9B5BF0, "void", entity, xPos, yPos, zPos, alive, deadFlag, ragdollFlag, clearArea)
end

function SET_ENTITY_COORDS_NO_OFFSET(entity, xPos, yPos, zPos, xAxis, yAxis, zAxis)
    Velora.invoke(0x9B5C40, "void", entity, xPos, yPos, zPos, xAxis, yAxis, zAxis)
end

function SET_ENTITY_DYNAMIC(entity, toggle)
    Velora.invoke(0x9B5C70, "void", entity, toggle)
end

function SET_ENTITY_HEADING(entity, heading)
    Velora.invoke(0x9B5CF0, "void", entity, heading)
end

function SET_ENTITY_HEALTH(entity, health, p2)
    Velora.invoke(0x9B5D00, "void", entity, health, p2)
end

function SET_ENTITY_INVINCIBLE(entity, toggle)
    Velora.invoke(0x9B5D20, "void", entity, toggle)
end

function SET_ENTITY_IS_TARGET_PRIORITY(entity, p1, p2)
    Velora.invoke(0x9B5E00, "void", entity, p1, p2)
end

function SET_ENTITY_LIGHTS(entity, toggle)
    Velora.invoke(0x9B5F20, "void", entity, toggle)
end

function SET_ENTITY_LOAD_COLLISION_FLAG(entity, toggle, p2)
    Velora.invoke(0x9B5F90, "void", entity, toggle, p2)
end

function HAS_COLLISION_LOADED_AROUND_ENTITY(invoke<BOOL>(0x9B5FE0, entity, speed)
    return Velora.invoke(0x9B6050, "bool", invoke<BOOL>(0x9B5FE0, entity, speed)
end

function SET_ENTITY_ONLY_DAMAGED_BY_PLAYER(entity, toggle)
    Velora.invoke(0x9B60C0, "void", entity, toggle)
end

function SET_ENTITY_ONLY_DAMAGED_BY_RELATIONSHIP_GROUP(entity, p1, p2)
    Velora.invoke(0x9B6140, "void", entity, p1, p2)
end

function SET_ENTITY_PROOFS(entity, bulletProof, fireProof, explosionProof, collisionProof, meleeProof, steamProof, p7, waterProof)
    Velora.invoke(0x9B6210, "void", entity, bulletProof, fireProof, explosionProof, collisionProof, meleeProof, steamProof, p7, waterProof)
end

function GET_ENTITY_PROOFS(entity, bulletProof, fireProof, explosionProof, collisionProof, meleeProof, steamProof, p7, invoke<BOOL>(0x9B6350, entity, x, y, z, w)
    return Velora.invoke(0x9B6480, "bool", entity, bulletProof, fireProof, explosionProof, collisionProof, meleeProof, steamProof, p7, invoke<BOOL>(0x9B6350, entity, x, y, z, w)
end

function SET_ENTITY_RECORDS_COLLISIONS(entity, toggle)
    Velora.invoke(0x9B6650, "void", entity, toggle)
end

function SET_ENTITY_ROTATION(entity, pitch, roll, yaw, rotationOrder, p5)
    Velora.invoke(0x9B66A0, "void", entity, pitch, roll, yaw, rotationOrder, p5)
end

function SET_ENTITY_VISIBLE(entity, toggle, p2)
    Velora.invoke(0x9B66C0, "void", entity, toggle, p2)
end

function SET_ENTITY_WATER_REFLECTION_FLAG(entity, toggle)
    Velora.invoke(0x9B66E0, "void", entity, toggle)
end

function SET_ENTITY_MIRROR_REFLECTION_FLAG(entity, p1)
    Velora.invoke(0x9B6750, "void", entity, p1)
end

function SET_ENTITY_VELOCITY(entity, x, y, z)
    Velora.invoke(0x9B67C0, "void", entity, x, y, z)
end

function SET_ENTITY_ANGULAR_VELOCITY(entity, x, y, z)
    Velora.invoke(0x9B6850, "void", entity, x, y, z)
end

function SET_ENTITY_HAS_GRAVITY(entity, toggle)
    Velora.invoke(0x9B68E0, "void", entity, toggle)
end

function SET_ENTITY_LOD_DIST(entity, value)
    Velora.invoke(0x9B6A00, "void", entity, value)
end

function GET_ENTITY_LOD_DIST(invoke<int>(0x9B6A50, entity, alphaLevel, skin)
    return Velora.invoke(0x9B6AB0, "int", invoke<int>(0x9B6A50, entity, alphaLevel, skin)
end

function GET_ENTITY_ALPHA(invoke<int>(0x9B6B10, entity)
    return Velora.invoke(0x9B6B70, "int", invoke<int>(0x9B6B10, entity)
end

function RESET_PICKUP_ENTITY_GLOW(entity)
    Velora.invoke(0x9B6B80, "void", entity)
end

function SET_PICKUP_COLLIDES_WITH_PROJECTILES(p0, p1)
    Velora.invoke(0x9B6BC0, "void", p0, p1)
end

function SET_ENTITY_SORT_BIAS(entity, p1)
    Velora.invoke(0x9B6C20, "void", entity, p1)
end

function SET_ENTITY_ALWAYS_PRERENDER(entity, toggle)
    Velora.invoke(0x9B6C80, "void", entity, toggle)
end

function SET_ENTITY_RENDER_SCORCHED(entity, toggle)
    Velora.invoke(0x9B6CE0, "void", entity, toggle)
end

function SET_ENTITY_TRAFFICLIGHT_OVERRIDE(entity, state)
    Velora.invoke(0x9B6D60, "void", entity, state)
end

function SET_ENTITY_IS_IN_VEHICLE(entity)
    Velora.invoke(0x9B6DC0, "void", entity)
end

function CREATE_MODEL_SWAP(x, y, z, radius, originalModel, newModel, p6)
    Velora.invoke(0x9B6E20, "void", x, y, z, radius, originalModel, newModel, p6)
end

function REMOVE_MODEL_SWAP(x, y, z, radius, originalModel, newModel, p6)
    Velora.invoke(0x9B6F00, "void", x, y, z, radius, originalModel, newModel, p6)
end

function CREATE_MODEL_HIDE(x, y, z, radius, modelHash, p5)
    Velora.invoke(0x9B6F90, "void", x, y, z, radius, modelHash, p5)
end

function CREATE_MODEL_HIDE_EXCLUDING_SCRIPT_OBJECTS(x, y, z, radius, modelHash, p5)
    Velora.invoke(0x9B7060, "void", x, y, z, radius, modelHash, p5)
end

function REMOVE_MODEL_HIDE(x, y, z, radius, modelHash, p5)
    Velora.invoke(0x9B7130, "void", x, y, z, radius, modelHash, p5)
end

function CREATE_FORCED_OBJECT(x, y, z, p3, modelHash, p5)
    Velora.invoke(0x9B71C0, "void", x, y, z, p3, modelHash, p5)
end

function REMOVE_FORCED_OBJECT(x, y, z, p3, modelHash)
    Velora.invoke(0x9B7290, "void", x, y, z, p3, modelHash)
end

function SET_ENTITY_NO_COLLISION_ENTITY(entity1, entity2, thisFrameOnly)
    Velora.invoke(0x9B7310, "void", entity1, entity2, thisFrameOnly)
end

function SET_ENTITY_MOTION_BLUR(entity, toggle)
    Velora.invoke(0x9B7340, "void", entity, toggle)
end

function SET_CAN_AUTO_VAULT_ON_ENTITY(entity, toggle)
    Velora.invoke(0x9B73A0, "void", entity, toggle)
end

function SET_CAN_CLIMB_ON_ENTITY(entity, toggle)
    Velora.invoke(0x9B7420, "void", entity, toggle)
end

function SET_WAIT_FOR_COLLISIONS_BEFORE_PROBE(entity, toggle)
    Velora.invoke(0x9B74A0, "void", entity, toggle)
end

function SET_ENTITY_NOWEAPONDECALS(entity, p1)
    Velora.invoke(0x9B7500, "void", entity, p1)
end

function SET_ENTITY_USE_MAX_DISTANCE_FOR_WATER_REFLECTION(entity, p1)
    Velora.invoke(0x9B7570, "void", entity, p1)
end

function GET_ENTITY_BONE_ROTATION(entity, invoke<Vector3>(0x9B75D0, entity, invoke<Vector3>(0x9B7640, entity, invoke<Vector3>(0x9B76B0, entity, invoke<Vector3>(0x9B7720, invoke<int>(0x9B7810, entity)
    local x, y, z = Velora.invoke(0x9B78C0, "vector3", entity, invoke<Vector3>(0x9B75D0, entity, invoke<Vector3>(0x9B7640, entity, invoke<Vector3>(0x9B76B0, entity, invoke<Vector3>(0x9B7720, invoke<int>(0x9B7810, entity)
    return {x = x, y = y, z = z}
end

function SET_ENTITY_CAN_ONLY_BE_DAMAGED_BY_ENTITY(entity1, entity2)
    Velora.invoke(0x9B7920, "void", entity1, entity2)
end

function SET_ENTITY_CANT_CAUSE_COLLISION_DAMAGED_ENTITY(entity1, entity2)
    Velora.invoke(0x9B79A0, "void", entity1, entity2)
end

function SET_ALLOW_MIGRATE_TO_SPECTATOR(entity, p1)
    Velora.invoke(0x9B7A20, "void", entity, p1)
end

function GET_ENTITY_OF_TYPE_ATTACHED_TO_ENTITY(entity, invoke<Entity>(0x9B7A90, entity, toggle)
    return Velora.invoke(0x9B7B30, "int", entity, invoke<Entity>(0x9B7A90, entity, toggle)
end

function SET_DECISION_MAKER(ped, name)
    Velora.invoke(0x9B9360, "void", ped, name)
end

function CLEAR_DECISION_MAKER_EVENT_RESPONSE(name, eventType)
    Velora.invoke(0x9B93C0, "void", name, eventType)
end

function BLOCK_DECISION_MAKER_EVENT(name, eventType)
    Velora.invoke(0x9B9400, "void", name, eventType)
end

function UNBLOCK_DECISION_MAKER_EVENT(name, eventType)
    Velora.invoke(0x9B9430, "void", name, eventType)
end

function ADD_SHOCKING_EVENT_AT_POSITION(eventType, x, y, z, invoke<int>(0x9B9470, eventType, entity, invoke<int>(0x9B9500, eventType, x, y, z, invoke<BOOL>(0x9B95B0, invoke<BOOL>(0x9B95E0, p0)
    return Velora.invoke(0x9B9610, "int", eventType, x, y, z, invoke<int>(0x9B9470, eventType, entity, invoke<int>(0x9B9500, eventType, x, y, z, invoke<BOOL>(0x9B95B0, invoke<BOOL>(0x9B95E0, p0)
end

function REMOVE_SHOCKING_EVENT_SPAWN_BLOCKING_AREAS()
    Velora.invoke(0x9B9630, "void")
end

function SUPPRESS_SHOCKING_EVENTS_NEXT_FRAME()
    Velora.invoke(0x9B9640, "void")
end

function SUPPRESS_SHOCKING_EVENT_TYPE_NEXT_FRAME(eventType)
    Velora.invoke(0x9B9650, "void", eventType)
end

function SUPPRESS_AGITATION_EVENTS_NEXT_FRAME()
    Velora.invoke(0x9B9670, "void")
end

function GET_NUM_TATTOO_SHOP_DLC_ITEMS(invoke<int>(0x9A23B0, characterType, decorationIndex, invoke<BOOL>(0x9A23E0, overlayHash, p1, invoke<int>(0x9A2490, outComponent)
    return Velora.invoke(0x9A24D0, "int", invoke<int>(0x9A23B0, characterType, decorationIndex, invoke<BOOL>(0x9A23E0, overlayHash, p1, invoke<int>(0x9A2490, outComponent)
end

function INIT_SHOP_PED_PROP(outProp)
    Velora.invoke(0x9A2510, "void", outProp)
end

function SETUP_SHOP_PED_APPAREL_QUERY(p0, p1, p2, invoke<int>(0x9A2550, character, p1, p2, p3, p4, invoke<int>(0x9A25D0, componentId, outComponent)
    return Velora.invoke(0x9A2640, "int", p0, p1, p2, invoke<int>(0x9A2550, character, p1, p2, p3, p4, invoke<int>(0x9A25D0, componentId, outComponent)
end

function GET_SHOP_PED_QUERY_COMPONENT_INDEX(invoke<int>(0x9A2650, componentHash, outComponent)
    return Velora.invoke(0x9A2680, "int", invoke<int>(0x9A2650, componentHash, outComponent)
end

function GET_SHOP_PED_QUERY_PROP(componentId, outProp)
    Velora.invoke(0x9A2690, "void", componentId, outProp)
end

function GET_SHOP_PED_QUERY_PROP_INDEX(invoke<int>(0x9A26A0, componentHash, outProp)
    return Velora.invoke(0x9A26D0, "int", invoke<int>(0x9A26A0, componentHash, outProp)
end

function GET_HASH_NAME_FOR_COMPONENT(entity, componentId, drawableVariant, invoke<Hash>(0x9A26E0, entity, componentId, propIndex, invoke<Hash>(0x9A2720, invoke<int>(0x9A2760, invoke<int>(0x9A2790, componentHash, variantComponentIndex, nameHash, enumValue, componentType)
    return Velora.invoke(0x9A27C0, "int", entity, componentId, drawableVariant, invoke<Hash>(0x9A26E0, entity, componentId, propIndex, invoke<Hash>(0x9A2720, invoke<int>(0x9A2760, invoke<int>(0x9A2790, componentHash, variantComponentIndex, nameHash, enumValue, componentType)
end

function GET_VARIANT_PROP(componentHash, variantPropIndex, nameHash, enumValue, anchorPoint)
    Velora.invoke(0x9A27F0, "void", componentHash, variantPropIndex, nameHash, enumValue, anchorPoint)
end

function GET_SHOP_PED_APPAREL_FORCED_COMPONENT_COUNT(invoke<int>(0x9A2820, invoke<int>(0x9A2850, componentHash, forcedComponentIndex, nameHash, enumValue, componentType)
    return Velora.invoke(0x9A2880, "int", invoke<int>(0x9A2820, invoke<int>(0x9A2850, componentHash, forcedComponentIndex, nameHash, enumValue, componentType)
end

function GET_FORCED_PROP(componentHash, forcedPropIndex, nameHash, enumValue, anchorPoint)
    Velora.invoke(0x9A28B0, "void", componentHash, forcedPropIndex, nameHash, enumValue, anchorPoint)
end

function DOES_SHOP_PED_APPAREL_HAVE_RESTRICTION_TAG(componentHash, restrictionTagHash, invoke<BOOL>(0x9A28E0, ped, componentId, invoke<BOOL>(0x9A2910, ped, componentId, invoke<BOOL>(0x9A29C0, character, invoke<int>(0x9A2A70, outfitIndex, outfit)
    return Velora.invoke(0x9A2AB0, "bool", componentHash, restrictionTagHash, invoke<BOOL>(0x9A28E0, ped, componentId, invoke<BOOL>(0x9A2910, ped, componentId, invoke<BOOL>(0x9A29C0, character, invoke<int>(0x9A2A70, outfitIndex, outfit)
end

function GET_SHOP_PED_OUTFIT(p0, p1)
    Velora.invoke(0x9A2AC0, "void", p0, p1)
end

function GET_SHOP_PED_OUTFIT_LOCATE(invoke<int>(0x9A2AD0, outfitHash, variantIndex, invoke<BOOL>(0x9A2B10, outfitHash, variantIndex, invoke<BOOL>(0x9A2B90, invoke<Hash>(0x9A2C30, dlcVehicleIndex, invoke<BOOL>(0x9A2C60, invoke<int>(0x9A2CB0, dlcWeaponIndex, invoke<BOOL>(0x9A2D40, dlcWeaponIndex, invoke<BOOL>(0x9A2D70, invoke<int>(0x9A2DC0, invoke<int>(0x9A2DF0, dlcWeaponIndex, dlcWeapCompIndex, invoke<BOOL>(0x9A2E20, dlcWeaponIndex, dlcWeapCompIndex, invoke<BOOL>(0x9A2E50, invoke<BOOL>(0x9A2EB0, invoke<BOOL>(0x9A2EE0, invoke<Hash>(0x9A2F40, hash)
    return Velora.invoke(0x9A2FA0, "int", invoke<int>(0x9A2AD0, outfitHash, variantIndex, invoke<BOOL>(0x9A2B10, outfitHash, variantIndex, invoke<BOOL>(0x9A2B90, invoke<Hash>(0x9A2C30, dlcVehicleIndex, invoke<BOOL>(0x9A2C60, invoke<int>(0x9A2CB0, dlcWeaponIndex, invoke<BOOL>(0x9A2D40, dlcWeaponIndex, invoke<BOOL>(0x9A2D70, invoke<int>(0x9A2DC0, invoke<int>(0x9A2DF0, dlcWeaponIndex, dlcWeapCompIndex, invoke<BOOL>(0x9A2E20, dlcWeaponIndex, dlcWeapCompIndex, invoke<BOOL>(0x9A2E50, invoke<BOOL>(0x9A2EB0, invoke<BOOL>(0x9A2EE0, invoke<Hash>(0x9A2F40, hash)
end

function REVERT_CONTENT_CHANGESET_GROUP_FOR_ALL(hash)
    Velora.invoke(0x9A2FC0, "void", hash)
end

function START_SCRIPT_FIRE(X, Y, Z, maxChildren, invoke<FireId>(0x9BAFF0, fireHandle)
    return Velora.invoke(0x9BB0C0, "int", X, Y, Z, maxChildren, invoke<FireId>(0x9BAFF0, fireHandle)
end

function START_ENTITY_FIRE(invoke<FireId>(0x9BB100, entity)
    return Velora.invoke(0x9BB180, "int", invoke<FireId>(0x9BB100, entity)
end

function IS_ENTITY_ON_FIRE(invoke<BOOL>(0x9BB1F0, x, y, z, invoke<int>(0x9BB260, p0)
    return Velora.invoke(0x9BB2A0, "bool", invoke<BOOL>(0x9BB1F0, x, y, z, invoke<int>(0x9BB260, p0)
end

function STOP_FIRE_IN_RANGE(x, y, z, radius)
    Velora.invoke(0x9BB2E0, "void", x, y, z, radius)
end

function GET_CLOSEST_FIRE_POS(outPosition, x, y, invoke<BOOL>(0x9BB310, x, y, z, explosionType, damageScale, isAudible, isInvisible, cameraShake, noDamage)
    return Velora.invoke(0x9BB3E0, "bool", outPosition, x, y, invoke<BOOL>(0x9BB310, x, y, z, explosionType, damageScale, isAudible, isInvisible, cameraShake, noDamage)
end

function ADD_OWNED_EXPLOSION(ped, x, y, z, explosionType, damageScale, isAudible, isInvisible, cameraShake)
    Velora.invoke(0x9BB420, "void", ped, x, y, z, explosionType, damageScale, isAudible, isInvisible, cameraShake)
end

function ADD_EXPLOSION_WITH_USER_VFX(x, y, z, explosionType, explosionFx, damageScale, isAudible, isInvisible, cameraShake)
    Velora.invoke(0x9BB460, "void", x, y, z, explosionType, explosionFx, damageScale, isAudible, isInvisible, cameraShake)
end

function IS_EXPLOSION_IN_AREA(explosionType, x1, y1, z1, x2, y2, invoke<BOOL>(0x9BB490, explosionType, x1, y1, z1, x2, y2, invoke<BOOL>(0x9BB560, explosionType, x, y, z, invoke<BOOL>(0x9BB630, explosionType, x, y, z, invoke<Entity>(0x9BB6B0, explosionType, x1, y1, z1, x2, y2, z2, invoke<BOOL>(0x9BB740, explosionType, x1, y1, z1, x2, y2, z2, invoke<Entity>(0x9BB7D0, enabled)
    return Velora.invoke(0x9CB750, "bool", explosionType, x1, y1, z1, x2, y2, invoke<BOOL>(0x9BB490, explosionType, x1, y1, z1, x2, y2, invoke<BOOL>(0x9BB560, explosionType, x, y, z, invoke<BOOL>(0x9BB630, explosionType, x, y, z, invoke<Entity>(0x9BB6B0, explosionType, x1, y1, z1, x2, y2, z2, invoke<BOOL>(0x9BB740, explosionType, x1, y1, z1, x2, y2, z2, invoke<Entity>(0x9BB7D0, enabled)
end

function DRAW_DEBUG_LINE(x1, y1, z1, x2, y2, z2, r, g, b, alpha)
    Velora.invoke(0x9CB760, "void", x1, y1, z1, x2, y2, z2, r, g, b, alpha)
end

function DRAW_DEBUG_LINE_WITH_TWO_COLOURS(x1, y1, z1, x2, y2, z2, r1, g1, b1, r2, g2, b2, alpha1, alpha2)
    Velora.invoke(0x9CB770, "void", x1, y1, z1, x2, y2, z2, r1, g1, b1, r2, g2, b2, alpha1, alpha2)
end

function DRAW_DEBUG_SPHERE(x, y, z, radius, red, green, blue, alpha)
    Velora.invoke(0x9CB780, "void", x, y, z, radius, red, green, blue, alpha)
end

function DRAW_DEBUG_BOX(x1, y1, z1, x2, y2, z2, r, g, b, alpha)
    Velora.invoke(0x9CB790, "void", x1, y1, z1, x2, y2, z2, r, g, b, alpha)
end

function DRAW_DEBUG_CROSS(x, y, z, size, red, green, blue, alpha)
    Velora.invoke(0x9CB7A0, "void", x, y, z, size, red, green, blue, alpha)
end

function DRAW_DEBUG_TEXT(text, x, y, z, red, green, blue, alpha)
    Velora.invoke(0x9CB7B0, "void", text, x, y, z, red, green, blue, alpha)
end

function DRAW_DEBUG_TEXT_2D(text, x, y, z, red, green, blue, alpha)
    Velora.invoke(0x9CB7C0, "void", text, x, y, z, red, green, blue, alpha)
end

function DRAW_LINE(x1, y1, z1, x2, y2, z2, red, green, blue, alpha)
    Velora.invoke(0x9CB7D0, "void", x1, y1, z1, x2, y2, z2, red, green, blue, alpha)
end

function DRAW_POLY(x1, y1, z1, x2, y2, z2, x3, y3, z3, red, green, blue, alpha)
    Velora.invoke(0x9CB8A0, "void", x1, y1, z1, x2, y2, z2, x3, y3, z3, red, green, blue, alpha)
end

function DRAW_TEXTURED_POLY(x1, y1, z1, x2, y2, z2, x3, y3, z3, red, green, blue, alpha, textureDict, textureName, u1, v1, w1, u2, v2, w2, u3, v3, w3)
    Velora.invoke(0x9CB980, "void", x1, y1, z1, x2, y2, z2, x3, y3, z3, red, green, blue, alpha, textureDict, textureName, u1, v1, w1, u2, v2, w2, u3, v3, w3)
end

function DRAW_TEXTURED_POLY_WITH_THREE_COLOURS(x1, y1, z1, x2, y2, z2, x3, y3, z3, red1, green1, blue1, alpha1, red2, green2, blue2, alpha2, red3, green3, blue3, alpha3, textureDict, textureName, u1, v1, w1, u2, v2, w2, u3, v3, w3)
    Velora.invoke(0x9CB9F0, "void", x1, y1, z1, x2, y2, z2, x3, y3, z3, red1, green1, blue1, alpha1, red2, green2, blue2, alpha2, red3, green3, blue3, alpha3, textureDict, textureName, u1, v1, w1, u2, v2, w2, u3, v3, w3)
end

function DRAW_BOX(x1, y1, z1, x2, y2, z2, red, green, blue, alpha)
    Velora.invoke(0x9CBA80, "void", x1, y1, z1, x2, y2, z2, red, green, blue, alpha)
end

function SET_BACKFACECULLING(toggle)
    Velora.invoke(0x9CBB50, "void", toggle)
end

function SET_DEPTHWRITING(toggle)
    Velora.invoke(0x9CBB70, "void", toggle)
end

function BEGIN_TAKE_MISSION_CREATOR_PHOTO(FREE_MEMORY_FOR_MISSION_CREATOR_PHOTO()
    return Velora.invoke(0x9CBBF0, "bool", FREE_MEMORY_FOR_MISSION_CREATOR_PHOTO()
end

function LOAD_MISSION_CREATOR_PHOTO(p0, p1, p2, invoke<BOOL>(0x9CBC00, invoke<int>(0x9CBC60, FREE_MEMORY_FOR_MISSION_CREATOR_PHOTO_PREVIEW()
    return Velora.invoke(0x9CBCF0, "bool", p0, p1, p2, invoke<BOOL>(0x9CBC00, invoke<int>(0x9CBC60, FREE_MEMORY_FOR_MISSION_CREATOR_PHOTO_PREVIEW()
end

function BEGIN_TAKE_HIGH_QUALITY_PHOTO(FREE_MEMORY_FOR_HIGH_QUALITY_PHOTO()
    return Velora.invoke(0x9CBD40, "bool", FREE_MEMORY_FOR_HIGH_QUALITY_PHOTO()
end

function SET_TAKEN_PHOTO_IS_MUGSHOT(toggle)
    Velora.invoke(0x9CBD50, "void", toggle)
end

function SET_ARENA_THEME_AND_VARIATION_FOR_TAKEN_PHOTO(p0, p1)
    Velora.invoke(0x9CBD70, "void", p0, p1)
end

function SET_ON_ISLAND_X_FOR_TAKEN_PHOTO(p0)
    Velora.invoke(0x9CBD80, "void", p0)
end

function SAVE_HIGH_QUALITY_PHOTO(invoke<BOOL>(0x9CBDA0, invoke<BOOL>(0x9CBDE0, invoke<int>(0x9CBE10, FREE_MEMORY_FOR_LOW_QUALITY_PHOTO()
    return Velora.invoke(0x9CBE30, "bool", invoke<BOOL>(0x9CBDA0, invoke<BOOL>(0x9CBDE0, invoke<int>(0x9CBE10, FREE_MEMORY_FOR_LOW_QUALITY_PHOTO()
end

function DRAW_LOW_QUALITY_PHOTO_TO_PHONE(p0, p1)
    Velora.invoke(0x9CBE40, "void", p0, p1)
end

function GET_MAXIMUM_NUMBER_OF_PHOTOS(invoke<BOOL>(0x9CBEA0, invoke<int>(0x9CBED0, CLEAR_STATUS_OF_SORTED_LIST_OPERATION()
    return Velora.invoke(0x9CBF00, "int", invoke<BOOL>(0x9CBEA0, invoke<int>(0x9CBED0, CLEAR_STATUS_OF_SORTED_LIST_OPERATION()
end

function DOES_THIS_PHOTO_SLOT_CONTAIN_A_VALID_PHOTO(invoke<BOOL>(0x9CBF10, invoke<BOOL>(0x9CBF20, invoke<int>(0x9CBF30, x, y, z, r, g, b, range, intensity, shadow)
    return Velora.invoke(0x9CBF40, "bool", invoke<BOOL>(0x9CBF10, invoke<BOOL>(0x9CBF20, invoke<int>(0x9CBF30, x, y, z, r, g, b, range, intensity, shadow)
end

function DRAW_LIGHT_WITH_RANGE(posX, posY, posZ, colorR, colorG, colorB, range, intensity)
    Velora.invoke(0x9CBF70, "void", posX, posY, posZ, colorR, colorG, colorB, range, intensity)
end

function DRAW_SPOT_LIGHT(posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, hardness, radius, falloff)
    Velora.invoke(0x9CBFA0, "void", posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, hardness, radius, falloff)
end

function DRAW_SHADOWED_SPOT_LIGHT(posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, roundness, radius, falloff, shadowId)
    Velora.invoke(0x9CBFD0, "void", posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, roundness, radius, falloff, shadowId)
end

function FADE_UP_PED_LIGHT(p0)
    Velora.invoke(0x9CC040, "void", p0)
end

function UPDATE_LIGHTS_ON_ENTITY(entity)
    Velora.invoke(0x9CC050, "void", entity)
end

function SET_LIGHT_OVERRIDE_MAX_INTENSITY_SCALE(p0)
    Velora.invoke(0x9CC0F0, "void", p0)
end

function GET_LIGHT_OVERRIDE_MAX_INTENSITY_SCALE(type, posX, posY, posZ, dirX, dirY, dirZ, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, red, green, blue, alpha, bobUpAndDown, faceCamera, p19, rotate, textureDict, textureName, drawOnEnts)
    return Velora.invoke(0x9CC120, "float", type, posX, posY, posZ, dirX, dirY, dirZ, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, red, green, blue, alpha, bobUpAndDown, faceCamera, p19, rotate, textureDict, textureName, drawOnEnts)
end

function DRAW_MARKER_EX(type, posX, posY, posZ, dirX, dirY, dirZ, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, red, green, blue, alpha, bobUpAndDown, faceCamera, p19, rotate, textureDict, textureName, drawOnEnts, p24, p25)
    Velora.invoke(0x9CC200, "void", type, posX, posY, posZ, dirX, dirY, dirZ, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, red, green, blue, alpha, bobUpAndDown, faceCamera, p19, rotate, textureDict, textureName, drawOnEnts, p24, p25)
end

function DRAW_MARKER_SPHERE(x, y, z, radius, red, green, blue, alpha)
    Velora.invoke(0x9CC300, "void", x, y, z, radius, red, green, blue, alpha)
end

function CREATE_CHECKPOINT(type, posX1, posY1, posZ1, posX2, posY2, posZ2, diameter, red, green, blue, alpha, invoke<int>(0x9CC460, checkpoint, scale)
    return Velora.invoke(0x9CC540, "int", type, posX1, posY1, posZ1, posX2, posY2, posZ2, diameter, red, green, blue, alpha, invoke<int>(0x9CC460, checkpoint, scale)
end

function SET_CHECKPOINT_INSIDE_CYLINDER_SCALE(checkpoint, scale)
    Velora.invoke(0x9CC590, "void", checkpoint, scale)
end

function SET_CHECKPOINT_CYLINDER_HEIGHT(checkpoint, nearHeight, farHeight, radius)
    Velora.invoke(0x9CC5E0, "void", checkpoint, nearHeight, farHeight, radius)
end

function SET_CHECKPOINT_RGBA(checkpoint, red, green, blue, alpha)
    Velora.invoke(0x9CC650, "void", checkpoint, red, green, blue, alpha)
end

function SET_CHECKPOINT_RGBA2(checkpoint, red, green, blue, alpha)
    Velora.invoke(0x9CC6D0, "void", checkpoint, red, green, blue, alpha)
end

function SET_CHECKPOINT_CLIPPLANE_WITH_POS_NORM(checkpoint, posX, posY, posZ, unkX, unkY, unkZ)
    Velora.invoke(0x9CC750, "void", checkpoint, posX, posY, posZ, unkX, unkY, unkZ)
end

function SET_CHECKPOINT_FORCE_OLD_ARROW_POINTING(checkpoint)
    Velora.invoke(0x9CC7D0, "void", checkpoint)
end

function SET_CHECKPOINT_DECAL_ROT_ALIGNED_TO_CAMERA_ROT(checkpoint)
    Velora.invoke(0x9CC810, "void", checkpoint)
end

function SET_CHECKPOINT_FORCE_DIRECTION(checkpoint)
    Velora.invoke(0x9CC850, "void", checkpoint)
end

function SET_CHECKPOINT_DIRECTION(checkpoint, posX, posY, posZ)
    Velora.invoke(0x9CC890, "void", checkpoint, posX, posY, posZ)
end

function DELETE_CHECKPOINT(checkpoint)
    Velora.invoke(0x9CC8F0, "void", checkpoint)
end

function DONT_RENDER_IN_GAME_UI(p0)
    Velora.invoke(0x9CC930, "void", p0)
end

function FORCE_RENDER_IN_GAME_UI(toggle)
    Velora.invoke(0x9CC950, "void", toggle)
end

function REQUEST_STREAMED_TEXTURE_DICT(textureDict, p1)
    Velora.invoke(0x9CC970, "void", textureDict, p1)
end

function HAS_STREAMED_TEXTURE_DICT_LOADED(invoke<BOOL>(0x9CCA00, textureDict)
    return Velora.invoke(0x9CCA60, "bool", invoke<BOOL>(0x9CCA00, textureDict)
end

function DRAW_RECT(x, y, width, height, r, g, b, a, p8)
    Velora.invoke(0x9CCAC0, "void", x, y, width, height, r, g, b, a, p8)
end

function SET_SCRIPT_GFX_DRAW_BEHIND_PAUSEMENU(toggle)
    Velora.invoke(0x9CCB00, "void", toggle)
end

function SET_SCRIPT_GFX_DRAW_ORDER(drawOrder)
    Velora.invoke(0x9CCB20, "void", drawOrder)
end

function SET_SCRIPT_GFX_ALIGN(horizontalAlign, verticalAlign)
    Velora.invoke(0x9CCBB0, "void", horizontalAlign, verticalAlign)
end

function RESET_SCRIPT_GFX_ALIGN()
    Velora.invoke(0x9CCBD0, "void")
end

function SET_SCRIPT_GFX_ALIGN_PARAMS(x, y, w, h)
    Velora.invoke(0x9CCBF0, "void", x, y, w, h)
end

function GET_SCRIPT_GFX_ALIGN_POSITION(x, y, calculatedX, calculatedY)
    Velora.invoke(0x9CCC30, "void", x, y, calculatedX, calculatedY)
end

function GET_SAFE_ZONE_SIZE(textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha, p11, p12)
    return Velora.invoke(0x9CCCD0, "float", textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha, p11, p12)
end

function DRAW_SPRITE_ARX(textureDict, textureName, x, y, width, height, p6, red, green, blue, alpha, p11, p12)
    Velora.invoke(0x9CCE30, "void", textureDict, textureName, x, y, width, height, p6, red, green, blue, alpha, p11, p12)
end

function DRAW_SPRITE_NAMED_RENDERTARGET(textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha, p11)
    Velora.invoke(0x9CCF90, "void", textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha, p11)
end

function DRAW_SPRITE_ARX_WITH_UV(textureDict, textureName, x, y, width, height, u1, v1, u2, v2, heading, red, green, blue, alpha, p15)
    Velora.invoke(0x9CD0E0, "void", textureDict, textureName, x, y, width, height, u1, v1, u2, v2, heading, red, green, blue, alpha, p15)
end

function ADD_ENTITY_ICON(entity, invoke<int>(0x9CD330, entity, toggle)
    return Velora.invoke(0x9CD3C0, "int", entity, invoke<int>(0x9CD330, entity, toggle)
end

function SET_ENTITY_ICON_COLOR(entity, red, green, blue, alpha)
    Velora.invoke(0x9CD420, "void", entity, red, green, blue, alpha)
end

function SET_DRAW_ORIGIN(x, y, z, p3)
    Velora.invoke(0x9CD4C0, "void", x, y, z, p3)
end

function CLEAR_DRAW_ORIGIN()
    Velora.invoke(0x9CD580, "void")
end

function SET_BINK_MOVIE(invoke<int>(0x9CD590, binkMovie)
    return Velora.invoke(0x9CD620, "int", invoke<int>(0x9CD590, binkMovie)
end

function STOP_BINK_MOVIE(binkMovie)
    Velora.invoke(0x9CD660, "void", binkMovie)
end

function RELEASE_BINK_MOVIE(binkMovie)
    Velora.invoke(0x9CD6A0, "void", binkMovie)
end

function DRAW_BINK_MOVIE(binkMovie, p1, p2, p3, p4, p5, r, g, b, a)
    Velora.invoke(0x9CD6F0, "void", binkMovie, p1, p2, p3, p4, p5, r, g, b, a)
end

function SET_BINK_MOVIE_TIME(binkMovie, progress)
    Velora.invoke(0x9CD820, "void", binkMovie, progress)
end

function GET_BINK_MOVIE_TIME(invoke<float>(0x9CD880, binkMovie, value)
    return Velora.invoke(0x9CD8E0, "float", invoke<float>(0x9CD880, binkMovie, value)
end

function ATTACH_TV_AUDIO_TO_ENTITY(entity)
    Velora.invoke(0x9CD920, "void", entity)
end

function SET_BINK_MOVIE_AUDIO_FRONTEND(binkMovie, p1)
    Velora.invoke(0x9CD990, "void", binkMovie, p1)
end

function SET_TV_AUDIO_FRONTEND(toggle)
    Velora.invoke(0x9CD9D0, "void", toggle)
end

function SET_BINK_SHOULD_SKIP(binkMovie, bShouldSkip)
    Velora.invoke(0x9CD9F0, "void", binkMovie, bShouldSkip)
end

function LOAD_MOVIE_MESH_SET(invoke<int>(0x9CDA40, movieMeshSet)
    return Velora.invoke(0x9CDAB0, "int", invoke<int>(0x9CDA40, movieMeshSet)
end

function QUERY_MOVIE_MESH_SET_STATE(invoke<int>(0x9CDAF0, x, y)
    return Velora.invoke(0x9CDB30, "int", invoke<int>(0x9CDAF0, x, y)
end

function GET_ACTUAL_SCREEN_RESOLUTION(x, y)
    Velora.invoke(0x9CDB50, "void", x, y)
end

function GET_ASPECT_RATIO(invoke<float>(0x9CDB80, ADJUST_NEXT_POS_SIZE_AS_NORMALIZED_16_9()
    return Velora.invoke(0x9CDC20, "float", invoke<float>(0x9CDB80, ADJUST_NEXT_POS_SIZE_AS_NORMALIZED_16_9()
end

function SET_NIGHTVISION(toggle)
    Velora.invoke(0x9CDC30, "void", toggle)
end

function GET_REQUESTINGNIGHTVISION(toggle)
    return Velora.invoke(0x9CDCB0, "bool", toggle)
end

function FORCE_EXPOSURE_READBACK(toggle)
    Velora.invoke(0x9CDCD0, "void", toggle)
end

function OVERRIDE_NIGHTVISION_LIGHT_RANGE(p0)
    Velora.invoke(0x9CDCF0, "void", p0)
end

function SET_NOISEOVERIDE(toggle)
    Velora.invoke(0x9CDD00, "void", toggle)
end

function SET_NOISINESSOVERIDE(value)
    Velora.invoke(0x9CDD20, "void", value)
end

function GET_SCREEN_COORD_FROM_WORLD_COORD(worldX, worldY, worldZ, screenX, invoke<BOOL>(0x9CDD40, textureDict, invoke<Vector3>(0x9CDDB0, ped, txd, invoke<BOOL>(0x9CDE20, p0)
    return Velora.invoke(0x9CDE50, "bool", worldX, worldY, worldZ, screenX, invoke<BOOL>(0x9CDD40, textureDict, invoke<Vector3>(0x9CDDB0, ped, txd, invoke<BOOL>(0x9CDE20, p0)
end

function SET_FLASH(p0, p1, fadeIn, duration, fadeOut)
    Velora.invoke(0x9CDE70, "void", p0, p1, fadeIn, duration, fadeOut)
end

function DISABLE_OCCLUSION_THIS_FRAME()
    Velora.invoke(0x9CDEA0, "void")
end

function SET_ARTIFICIAL_LIGHTS_STATE(state)
    Velora.invoke(0x9CDEB0, "void", state)
end

function SET_ARTIFICIAL_VEHICLE_LIGHTS_STATE(toggle)
    Velora.invoke(0x9CDED0, "void", toggle)
end

function DISABLE_HDTEX_THIS_FRAME()
    Velora.invoke(0x9CDEF0, "void")
end

function CREATE_TRACKED_POINT(point, x, y, z, radius)
    return Velora.invoke(0x9CDF20, "int", point, x, y, z, radius)
end

function IS_TRACKED_POINT_VISIBLE(invoke<BOOL>(0x9CDFD0, point)
    return Velora.invoke(0x9CE000, "bool", invoke<BOOL>(0x9CDFD0, point)
end

function SET_GRASS_CULL_SPHERE(p0, p1, p2, invoke<int>(0x9CE010, handle)
    return Velora.invoke(0x9CE020, "int", p0, p1, p2, invoke<int>(0x9CE010, handle)
end

function PROCGRASS_ENABLE_CULLSPHERE(handle, x, y, z, scale)
    Velora.invoke(0x9CE030, "void", handle, x, y, z, scale)
end

function PROCGRASS_DISABLE_CULLSPHERE(handle)
    Velora.invoke(0x9CE090, "void", handle)
end

function PROCGRASS_IS_CULLSPHERE_ENABLED(invoke<BOOL>(0x9CE0B0, PROCGRASS_ENABLE_AMBSCALESCAN()
    return Velora.invoke(0x9CE0E0, "bool", invoke<BOOL>(0x9CE0B0, PROCGRASS_ENABLE_AMBSCALESCAN()
end

function PROCGRASS_DISABLE_AMBSCALESCAN()
    Velora.invoke(0x9CE0F0, "void")
end

function DISABLE_PROCOBJ_CREATION()
    Velora.invoke(0x9CE100, "void")
end

function ENABLE_PROCOBJ_CREATION()
    Velora.invoke(0x9CE110, "void")
end

function GRASSBATCH_ENABLE_FLATTENING_EXT_IN_SPHERE(x, y, z, p3, p4, p5, p6, scale)
    Velora.invoke(0x9CE120, "void", x, y, z, p3, p4, p5, p6, scale)
end

function GRASSBATCH_ENABLE_FLATTENING_IN_SPHERE(x, y, z, radius, p4, p5, p6)
    Velora.invoke(0x9CE1B0, "void", x, y, z, radius, p4, p5, p6)
end

function GRASSBATCH_DISABLE_FLATTENING()
    Velora.invoke(0x9CE240, "void")
end

function CASCADE_SHADOWS_INIT_SESSION()
    Velora.invoke(0x9CE250, "void")
end

function CASCADE_SHADOWS_SET_CASCADE_BOUNDS(p0, p1, p2, p3, p4, p5, p6, p7)
    Velora.invoke(0x9CE270, "void", p0, p1, p2, p3, p4, p5, p6, p7)
end

function CASCADE_SHADOWS_SET_CASCADE_BOUNDS_SCALE(p0)
    Velora.invoke(0x9CE2B0, "void", p0)
end

function CASCADE_SHADOWS_SET_ENTITY_TRACKER_SCALE(p0)
    Velora.invoke(0x9CE2C0, "void", p0)
end

function CASCADE_SHADOWS_SET_SPLIT_Z_EXP_WEIGHT(p0)
    Velora.invoke(0x9CE2D0, "void", p0)
end

function CASCADE_SHADOWS_SET_BOUND_POSITION(p0)
    Velora.invoke(0x9CE2E0, "void", p0)
end

function CASCADE_SHADOWS_ENABLE_ENTITY_TRACKER(toggle)
    Velora.invoke(0x9CE2F0, "void", toggle)
end

function CASCADE_SHADOWS_SET_SCREEN_SIZE_CHECK_ENABLED(p0)
    Velora.invoke(0x9CE310, "void", p0)
end

function CASCADE_SHADOWS_SET_SHADOW_SAMPLE_TYPE(type)
    Velora.invoke(0x9CE330, "void", type)
end

function CASCADE_SHADOWS_CLEAR_SHADOW_SAMPLE_TYPE()
    Velora.invoke(0x9CE340, "void")
end

function CASCADE_SHADOWS_SET_AIRCRAFT_MODE(p0)
    Velora.invoke(0x9CE350, "void", p0)
end

function CASCADE_SHADOWS_SET_DYNAMIC_DEPTH_MODE(p0)
    Velora.invoke(0x9CE370, "void", p0)
end

function CASCADE_SHADOWS_SET_DYNAMIC_DEPTH_VALUE(p0)
    Velora.invoke(0x9CE390, "void", p0)
end

function CASCADE_SHADOWS_ENABLE_FREEZER(p0)
    Velora.invoke(0x9CE3A0, "void", p0)
end

function WATER_REFLECTION_SET_SCRIPT_OBJECT_VISIBILITY(p0)
    Velora.invoke(0x9CE3C0, "void", p0)
end

function GOLF_TRAIL_SET_ENABLED(toggle)
    Velora.invoke(0x9CE3E0, "void", toggle)
end

function GOLF_TRAIL_SET_PATH(p0, p1, p2, p3, p4, p5, p6, p7, p8)
    Velora.invoke(0x9CE400, "void", p0, p1, p2, p3, p4, p5, p6, p7, p8)
end

function GOLF_TRAIL_SET_RADIUS(p0, p1, p2)
    Velora.invoke(0x9CE450, "void", p0, p1, p2)
end

function GOLF_TRAIL_SET_COLOUR(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11)
    Velora.invoke(0x9CE470, "void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11)
end

function GOLF_TRAIL_SET_TESSELLATION(p0, p1)
    Velora.invoke(0x9CE4E0, "void", p0, p1)
end

function GOLF_TRAIL_SET_FIXED_CONTROL_POINT_ENABLE(p0)
    Velora.invoke(0x9CE4F0, "void", p0)
end

function GOLF_TRAIL_SET_FIXED_CONTROL_POINT(type, xPos, yPos, zPos, p4, red, green, blue, alpha)
    Velora.invoke(0x9CE510, "void", type, xPos, yPos, zPos, p4, red, green, blue, alpha)
end

function GOLF_TRAIL_SET_SHADER_PARAMS(p0, p1, p2, p3, p4)
    Velora.invoke(0x9CE5D0, "void", p0, p1, p2, p3, p4)
end

function GOLF_TRAIL_SET_FACING(p0)
    Velora.invoke(0x9CE600, "void", p0)
end

function GOLF_TRAIL_GET_MAX_HEIGHT(invoke<Vector3>(0x9CE640, toggle)
    return Velora.invoke(0x9CE690, "float", invoke<Vector3>(0x9CE640, toggle)
end

function GET_USINGSEETHROUGH(SEETHROUGH_RESET()
    return Velora.invoke(0x9CE6E0, "bool", SEETHROUGH_RESET()
end

function SEETHROUGH_SET_FADE_STARTDISTANCE(distance)
    Velora.invoke(0x9CE6F0, "void", distance)
end

function SEETHROUGH_SET_FADE_ENDDISTANCE(distance)
    Velora.invoke(0x9CE710, "void", distance)
end

function SEETHROUGH_GET_MAX_THICKNESS(thickness)
    return Velora.invoke(0x9CE750, "float", thickness)
end

function SEETHROUGH_SET_NOISE_MIN(amount)
    Velora.invoke(0x9CE780, "void", amount)
end

function SEETHROUGH_SET_NOISE_MAX(amount)
    Velora.invoke(0x9CE7A0, "void", amount)
end

function SEETHROUGH_SET_HILIGHT_INTENSITY(intensity)
    Velora.invoke(0x9CE7C0, "void", intensity)
end

function SEETHROUGH_SET_HIGHLIGHT_NOISE(noise)
    Velora.invoke(0x9CE7E0, "void", noise)
end

function SEETHROUGH_SET_HEATSCALE(index, heatScale)
    Velora.invoke(0x9CE800, "void", index, heatScale)
end

function SEETHROUGH_SET_COLOR_NEAR(red, green, blue)
    Velora.invoke(0x9CE840, "void", red, green, blue)
end

function SET_MOTIONBLUR_MAX_VEL_SCALER(p0)
    Velora.invoke(0x9CE8C0, "void", p0)
end

function GET_MOTIONBLUR_MAX_VEL_SCALER(toggle)
    return Velora.invoke(0x9CE900, "float", toggle)
end

function TOGGLE_PLAYER_DAMAGE_OVERLAY(toggle)
    Velora.invoke(0x9CE920, "void", toggle)
end

function RESET_ADAPTATION(p0)
    Velora.invoke(0x9CE950, "void", p0)
end

function TRIGGER_SCREENBLUR_FADE_IN(invoke<BOOL>(0x9CE960, invoke<BOOL>(0x9CE9B0, DISABLE_SCREENBLUR_FADE()
    return Velora.invoke(0x9CEA10, "bool", invoke<BOOL>(0x9CE960, invoke<BOOL>(0x9CE9B0, DISABLE_SCREENBLUR_FADE()
end

function GET_SCREENBLUR_FADE_CURRENT_TIME(toggle)
    return Velora.invoke(0x9CEA80, "float", toggle)
end

function GET_TOGGLE_PAUSED_RENDERPHASES_STATUS(RESET_PAUSED_RENDERPHASES()
    return Velora.invoke(0x9CEAC0, "bool", RESET_PAUSED_RENDERPHASES()
end

function GRAB_PAUSEMENU_OWNERSHIP()
    Velora.invoke(0x9CEAD0, "void")
end

function SET_HIDOF_OVERRIDE(p0, p1, nearplaneOut, nearplaneIn, farplaneOut, farplaneIn)
    Velora.invoke(0x9CEAF0, "void", p0, p1, nearplaneOut, nearplaneIn, farplaneOut, farplaneIn)
end

function SET_LOCK_ADAPTIVE_DOF_DISTANCE(p0)
    Velora.invoke(0x9CEB40, "void", p0)
end

function PHONEPHOTOEDITOR_TOGGLE(invoke<BOOL>(0x9CEB60, textureDict, invoke<BOOL>(0x9CEBE0, effectName, xPos, yPos, zPos, xRot, yRot, zRot, scale, xAxis, yAxis, invoke<BOOL>(0x9CEC10, effectName, xPos, yPos, zPos, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, invoke<BOOL>(0x9CECF0, effectName, ped, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, invoke<BOOL>(0x9CEDE0, effectName, ped, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, invoke<BOOL>(0x9CEE70, effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, scale, axisX, axisY, invoke<BOOL>(0x9CEF00, effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, scale, axisX, axisY, invoke<BOOL>(0x9CEF90, effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, invoke<BOOL>(0x9CF020, r, g, b)
    return Velora.invoke(0x9CF0A0, "bool", invoke<BOOL>(0x9CEB60, textureDict, invoke<BOOL>(0x9CEBE0, effectName, xPos, yPos, zPos, xRot, yRot, zRot, scale, xAxis, yAxis, invoke<BOOL>(0x9CEC10, effectName, xPos, yPos, zPos, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, invoke<BOOL>(0x9CECF0, effectName, ped, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, invoke<BOOL>(0x9CEDE0, effectName, ped, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, invoke<BOOL>(0x9CEE70, effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, scale, axisX, axisY, invoke<BOOL>(0x9CEF00, effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, scale, axisX, axisY, invoke<BOOL>(0x9CEF90, effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, invoke<BOOL>(0x9CF020, r, g, b)
end

function SET_PARTICLE_FX_NON_LOOPED_ALPHA(alpha)
    Velora.invoke(0x9CF0C0, "void", alpha)
end

function SET_PARTICLE_FX_NON_LOOPED_SCALE(scale)
    Velora.invoke(0x9CF0F0, "void", scale)
end

function SET_PARTICLE_FX_NON_LOOPED_EMITTER_SIZE(p0, p1, scale)
    Velora.invoke(0x9CF100, "void", p0, p1, scale)
end

function SET_PARTICLE_FX_FORCE_VEHICLE_INTERIOR(toggle)
    Velora.invoke(0x9CF120, "void", toggle)
end

function START_PARTICLE_FX_LOOPED_AT_COORD(effectName, x, y, z, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, invoke<int>(0x9CF140, effectName, ped, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, invoke<int>(0x9CF1A0, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, xAxis, yAxis, invoke<int>(0x9CF200, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, invoke<int>(0x9CF290, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, r, g, b, invoke<int>(0x9CF320, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis, r, g, b, invoke<int>(0x9CF3B0, ptfxHandle, p1)
    return Velora.invoke(0x9CF440, "int", effectName, x, y, z, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, invoke<int>(0x9CF140, effectName, ped, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, invoke<int>(0x9CF1A0, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, xAxis, yAxis, invoke<int>(0x9CF200, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, invoke<int>(0x9CF290, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, r, g, b, invoke<int>(0x9CF320, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis, r, g, b, invoke<int>(0x9CF3B0, ptfxHandle, p1)
end

function REMOVE_PARTICLE_FX(ptfxHandle, p1)
    Velora.invoke(0x9CF460, "void", ptfxHandle, p1)
end

function REMOVE_PARTICLE_FX_FROM_ENTITY(entity)
    Velora.invoke(0x9CF480, "void", entity)
end

function REMOVE_PARTICLE_FX_IN_RANGE(X, Y, Z, radius)
    Velora.invoke(0x9CF4D0, "void", X, Y, Z, radius)
end

function FORCE_PARTICLE_FX_IN_VEHICLE_INTERIOR(p0, p1)
    Velora.invoke(0x9CF500, "void", p0, p1)
end

function DOES_PARTICLE_FX_LOOPED_EXIST(invoke<BOOL>(0x9CF520, ptfxHandle, x, y, z, rotX, rotY, rotZ)
    return Velora.invoke(0x9CF550, "bool", invoke<BOOL>(0x9CF520, ptfxHandle, x, y, z, rotX, rotY, rotZ)
end

function SET_PARTICLE_FX_LOOPED_EVOLUTION(ptfxHandle, propertyName, amount, noNetwork)
    Velora.invoke(0x9CF5A0, "void", ptfxHandle, propertyName, amount, noNetwork)
end

function SET_PARTICLE_FX_LOOPED_COLOUR(ptfxHandle, r, g, b, p4)
    Velora.invoke(0x9CF5C0, "void", ptfxHandle, r, g, b, p4)
end

function SET_PARTICLE_FX_LOOPED_ALPHA(ptfxHandle, alpha)
    Velora.invoke(0x9CF5F0, "void", ptfxHandle, alpha)
end

function SET_PARTICLE_FX_LOOPED_SCALE(ptfxHandle, scale)
    Velora.invoke(0x9CF600, "void", ptfxHandle, scale)
end

function SET_PARTICLE_FX_LOOPED_FAR_CLIP_DIST(ptfxHandle, range)
    Velora.invoke(0x9CF610, "void", ptfxHandle, range)
end

function SET_PARTICLE_FX_CAM_INSIDE_VEHICLE(p0)
    Velora.invoke(0x9CF630, "void", p0)
end

function SET_PARTICLE_FX_CAM_INSIDE_NONPLAYER_VEHICLE(vehicle, p1)
    Velora.invoke(0x9CF650, "void", vehicle, p1)
end

function SET_PARTICLE_FX_SHOOTOUT_BOAT(p0)
    Velora.invoke(0x9CF6D0, "void", p0)
end

function CLEAR_PARTICLE_FX_SHOOTOUT_BOAT()
    Velora.invoke(0x9CF740, "void")
end

function SET_PARTICLE_FX_BLOOD_SCALE(p0)
    Velora.invoke(0x9CF770, "void", p0)
end

function DISABLE_IN_WATER_PTFX(toggle)
    Velora.invoke(0x9CF7B0, "void", toggle)
end

function DISABLE_DOWNWASH_PTFX(toggle)
    Velora.invoke(0x9CF7E0, "void", toggle)
end

function SET_PARTICLE_FX_SLIPSTREAM_LODRANGE_SCALE(scale)
    Velora.invoke(0x9CF810, "void", scale)
end

function ENABLE_CLOWN_BLOOD_VFX(toggle)
    Velora.invoke(0x9CF850, "void", toggle)
end

function ENABLE_ALIEN_BLOOD_VFX(toggle)
    Velora.invoke(0x9CF890, "void", toggle)
end

function SET_PARTICLE_FX_BULLET_IMPACT_SCALE(scale)
    Velora.invoke(0x9CF8D0, "void", scale)
end

function SET_PARTICLE_FX_BULLET_IMPACT_LODRANGE_SCALE(p0)
    Velora.invoke(0x9CF910, "void", p0)
end

function SET_PARTICLE_FX_BULLET_TRACE_NO_ANGLE_REJECT(p0)
    Velora.invoke(0x9CF950, "void", p0)
end

function SET_PARTICLE_FX_BANG_SCRAPE_LODRANGE_SCALE(p0)
    Velora.invoke(0x9CF980, "void", p0)
end

function SET_PARTICLE_FX_FOOT_LODRANGE_SCALE(p0)
    Velora.invoke(0x9CF9C0, "void", p0)
end

function SET_PARTICLE_FX_FOOT_OVERRIDE_NAME(p0)
    Velora.invoke(0x9CFA00, "void", p0)
end

function SET_SKIDMARK_RANGE_SCALE(scale)
    Velora.invoke(0x9CFA80, "void", scale)
end

function SET_PTFX_FORCE_VEHICLE_INTERIOR_FLAG(p0)
    Velora.invoke(0x9CFAC0, "void", p0)
end

function REGISTER_POSTFX_BULLET_IMPACT(weaponWorldPosX, weaponWorldPosY, weaponWorldPosZ, intensity)
    Velora.invoke(0x9CFAF0, "void", weaponWorldPosX, weaponWorldPosY, weaponWorldPosZ, intensity)
end

function FORCE_POSTFX_BULLET_IMPACTS_AFTER_HUD(p0)
    Velora.invoke(0x9CFB60, "void", p0)
end

function USE_PARTICLE_FX_ASSET(name)
    Velora.invoke(0x9CFB80, "void", name)
end

function SET_PARTICLE_FX_OVERRIDE(oldAsset, newAsset)
    Velora.invoke(0x9CFBA0, "void", oldAsset, newAsset)
end

function RESET_PARTICLE_FX_OVERRIDE(name)
    Velora.invoke(0x9CFBD0, "void", name)
end

function SET_WEATHER_PTFX_USE_OVERRIDE_SETTINGS(p0)
    Velora.invoke(0x9CFC50, "void", p0)
end

function SET_WEATHER_PTFX_OVERRIDE_CURR_LEVEL(p0)
    Velora.invoke(0x9CFC70, "void", p0)
end

function WASH_DECALS_IN_RANGE(x, y, z, range, p4)
    Velora.invoke(0x9CFC90, "void", x, y, z, range, p4)
end

function WASH_DECALS_FROM_VEHICLE(vehicle, p1)
    Velora.invoke(0x9CFCD0, "void", vehicle, p1)
end

function FADE_DECALS_IN_RANGE(x, y, z, p3, p4)
    Velora.invoke(0x9CFD30, "void", x, y, z, p3, p4)
end

function REMOVE_DECALS_IN_RANGE(x, y, z, range)
    Velora.invoke(0x9CFD70, "void", x, y, z, range)
end

function REMOVE_DECALS_FROM_OBJECT(obj)
    Velora.invoke(0x9CFDB0, "void", obj)
end

function REMOVE_DECALS_FROM_OBJECT_FACING(obj, x, y, z)
    Velora.invoke(0x9CFE10, "void", obj, x, y, z)
end

function REMOVE_DECALS_FROM_VEHICLE(vehicle)
    Velora.invoke(0x9CFE80, "void", vehicle)
end

function ADD_DECAL(decalType, posX, posY, posZ, p4, p5, p6, p7, p8, p9, width, height, rCoef, gCoef, bCoef, opacity, timeout, p17, p18, invoke<int>(0x9CFEE0, x, y, z, groundLvl, width, invoke<int>(0x9CFF70, x, y, z, groundLvl, width, invoke<int>(0x9CFFF0, p0)
    return Velora.invoke(0x9D0070, "int", decalType, posX, posY, posZ, p4, p5, p6, p7, p8, p9, width, height, rCoef, gCoef, bCoef, opacity, timeout, p17, p18, invoke<int>(0x9CFEE0, x, y, z, groundLvl, width, invoke<int>(0x9CFF70, x, y, z, groundLvl, width, invoke<int>(0x9CFFF0, p0)
end

function ADD_PETROL_TRAIL_DECAL_INFO(x, y, z, p3)
    Velora.invoke(0x9D00D0, "void", x, y, z, p3)
end

function END_PETROL_TRAIL_DECALS()
    Velora.invoke(0x9D0100, "void")
end

function REMOVE_DECAL(decal)
    Velora.invoke(0x9D0110, "void", decal)
end

function IS_DECAL_ALIVE(invoke<BOOL>(0x9D0130, invoke<float>(0x9D0160, SET_DISABLE_PETROL_DECALS_IGNITING_THIS_FRAME()
    return Velora.invoke(0x9D0190, "bool", invoke<BOOL>(0x9D0130, invoke<float>(0x9D0160, SET_DISABLE_PETROL_DECALS_IGNITING_THIS_FRAME()
end

function SET_DISABLE_PETROL_DECALS_RECYCLING_THIS_FRAME()
    Velora.invoke(0x9D01A0, "void")
end

function SET_DISABLE_DECAL_RENDERING_THIS_FRAME()
    Velora.invoke(0x9D01B0, "void")
end

function GET_IS_PETROL_DECAL_IN_RANGE(xCoord, yCoord, zCoord, invoke<BOOL>(0x9D01C0, decalType, textureDict, textureName)
    return Velora.invoke(0x9D0270, "bool", xCoord, yCoord, zCoord, invoke<BOOL>(0x9D01C0, decalType, textureDict, textureName)
end

function UNPATCH_DECAL_DIFFUSE_MAP(decalType)
    Velora.invoke(0x9D02B0, "void", decalType)
end

function MOVE_VEHICLE_DECALS(p0, p1)
    Velora.invoke(0x9D02D0, "void", p0, p1)
end

function ADD_VEHICLE_CREW_EMBLEM(vehicle, ped, boneIndex, x1, x2, x3, y1, y2, y3, z1, z2, z3, scale, p13, invoke<BOOL>(0x9D0360, invoke<BOOL>(0x9D03B0, vehicle, p1)
    return Velora.invoke(0x9D0400, "bool", vehicle, ped, boneIndex, x1, x2, x3, y1, y2, y3, z1, z2, z3, scale, p13, invoke<BOOL>(0x9D0360, invoke<BOOL>(0x9D03B0, vehicle, p1)
end

function GET_VEHICLE_CREW_EMBLEM_REQUEST_STATE(vehicle, invoke<int>(0x9D0460, vehicle, invoke<BOOL>(0x9D04C0, toggle)
    return Velora.invoke(0x9D0530, "int", vehicle, invoke<int>(0x9D0460, vehicle, invoke<BOOL>(0x9D04C0, toggle)
end

function DISABLE_SCUFF_DECALS(toggle)
    Velora.invoke(0x9D0560, "void", toggle)
end

function SET_DECAL_BULLET_IMPACT_RANGE_SCALE(p0)
    Velora.invoke(0x9D0590, "void", p0)
end

function OVERRIDE_INTERIOR_SMOKE_NAME(name)
    Velora.invoke(0x9D05D0, "void", name)
end

function OVERRIDE_INTERIOR_SMOKE_LEVEL(level)
    Velora.invoke(0x9D0600, "void", level)
end

function OVERRIDE_INTERIOR_SMOKE_END()
    Velora.invoke(0x9D0620, "void")
end

function REGISTER_NOIR_LENS_EFFECT()
    Velora.invoke(0x9D0630, "void")
end

function DISABLE_VEHICLE_DISTANTLIGHTS(toggle)
    Velora.invoke(0x9D0660, "void", toggle)
end

function RENDER_SHADOWED_LIGHTS_WITH_NO_SHADOWS(p0)
    Velora.invoke(0x9D0680, "void", p0)
end

function REQUEST_EARLY_LIGHT_CHECK()
    Velora.invoke(0x9D06A0, "void")
end

function USE_SNOW_FOOT_VFX_WHEN_UNSHELTERED(toggle)
    Velora.invoke(0x9D06B0, "void", toggle)
end

function USE_SNOW_WHEEL_VFX_WHEN_UNSHELTERED(toggle)
    Velora.invoke(0x9D06F0, "void", toggle)
end

function DISABLE_REGION_VFX(p0)
    Velora.invoke(0x9D0710, "void", p0)
end

function PRESET_INTERIOR_AMBIENT_CACHE(timecycleModifierName)
    Velora.invoke(0x9D0760, "void", timecycleModifierName)
end

function SET_TIMECYCLE_MODIFIER(modifierName)
    Velora.invoke(0x9D07B0, "void", modifierName)
end

function SET_TIMECYCLE_MODIFIER_STRENGTH(strength)
    Velora.invoke(0x9D0830, "void", strength)
end

function SET_TRANSITION_TIMECYCLE_MODIFIER(modifierName, transition)
    Velora.invoke(0x9D0850, "void", modifierName, transition)
end

function SET_TRANSITION_OUT_OF_TIMECYCLE_MODIFIER(strength)
    Velora.invoke(0x9D08B0, "void", strength)
end

function CLEAR_TIMECYCLE_MODIFIER()
    Velora.invoke(0x9D08D0, "void")
end

function GET_TIMECYCLE_MODIFIER_INDEX(PUSH_TIMECYCLE_MODIFIER()
    return Velora.invoke(0x9D0970, "int", PUSH_TIMECYCLE_MODIFIER()
end

function POP_TIMECYCLE_MODIFIER()
    Velora.invoke(0x9D0980, "void")
end

function SET_CURRENT_PLAYER_TCMODIFIER(modifierName)
    Velora.invoke(0x9D0990, "void", modifierName)
end

function SET_PLAYER_TCMODIFIER_TRANSITION(value)
    Velora.invoke(0x9D0A60, "void", value)
end

function SET_NEXT_PLAYER_TCMODIFIER(modifierName)
    Velora.invoke(0x9D0A80, "void", modifierName)
end

function ADD_TCMODIFIER_OVERRIDE(modifierName1, modifierName2)
    Velora.invoke(0x9D0B30, "void", modifierName1, modifierName2)
end

function CLEAR_ALL_TCMODIFIER_OVERRIDES(p0)
    Velora.invoke(0x9D0BA0, "void", p0)
end

function SET_EXTRA_TCMODIFIER(modifierName)
    Velora.invoke(0x9D0BB0, "void", modifierName)
end

function CLEAR_EXTRA_TCMODIFIER()
    Velora.invoke(0x9D0C30, "void")
end

function GET_EXTRA_TCMODIFIER(strength)
    return Velora.invoke(0x9D0C70, "int", strength)
end

function DISABLE_MOON_CYCLE_OVERRIDE()
    Velora.invoke(0x9D0CA0, "void")
end

function REQUEST_SCALEFORM_MOVIE(invoke<int>(0x9D0CC0, invoke<int>(0x9D0CF0, invoke<int>(0x9D0D20, invoke<int>(0x9D0D50, invoke<BOOL>(0x9D0D80, invoke<BOOL>(0x9D0E90, invoke<BOOL>(0x9D0F10, invoke<BOOL>(0x9D0F50, invoke<BOOL>(0x9D0FF0, scaleformHandle)
    return Velora.invoke(0x9D1020, "int", invoke<int>(0x9D0CC0, invoke<int>(0x9D0CF0, invoke<int>(0x9D0D20, invoke<int>(0x9D0D50, invoke<BOOL>(0x9D0D80, invoke<BOOL>(0x9D0E90, invoke<BOOL>(0x9D0F10, invoke<BOOL>(0x9D0F50, invoke<BOOL>(0x9D0FF0, scaleformHandle)
end

function SET_SCALEFORM_MOVIE_TO_USE_SYSTEM_TIME(scaleform, toggle)
    Velora.invoke(0x9D10A0, "void", scaleform, toggle)
end

function SET_SCALEFORM_MOVIE_TO_USE_LARGE_RT(scaleformHandle, toggle)
    Velora.invoke(0x9D1100, "void", scaleformHandle, toggle)
end

function SET_SCALEFORM_MOVIE_TO_USE_SUPER_LARGE_RT(scaleformHandle, toggle)
    Velora.invoke(0x9D1150, "void", scaleformHandle, toggle)
end

function DRAW_SCALEFORM_MOVIE(scaleformHandle, x, y, width, height, red, green, blue, alpha, p9)
    Velora.invoke(0x9D11A0, "void", scaleformHandle, x, y, width, height, red, green, blue, alpha, p9)
end

function DRAW_SCALEFORM_MOVIE_FULLSCREEN(scaleform, red, green, blue, alpha, p5)
    Velora.invoke(0x9D11F0, "void", scaleform, red, green, blue, alpha, p5)
end

function DRAW_SCALEFORM_MOVIE_FULLSCREEN_MASKED(scaleform1, scaleform2, red, green, blue, alpha)
    Velora.invoke(0x9D12C0, "void", scaleform1, scaleform2, red, green, blue, alpha)
end

function DRAW_SCALEFORM_MOVIE_3D(scaleform, posX, posY, posZ, rotX, rotY, rotZ, p7, p8, p9, scaleX, scaleY, scaleZ, rotationOrder)
    Velora.invoke(0x9D12E0, "void", scaleform, posX, posY, posZ, rotX, rotY, rotZ, p7, p8, p9, scaleX, scaleY, scaleZ, rotationOrder)
end

function DRAW_SCALEFORM_MOVIE_3D_SOLID(scaleform, posX, posY, posZ, rotX, rotY, rotZ, p7, p8, p9, scaleX, scaleY, scaleZ, rotationOrder)
    Velora.invoke(0x9D1300, "void", scaleform, posX, posY, posZ, rotX, rotY, rotZ, p7, p8, p9, scaleX, scaleY, scaleZ, rotationOrder)
end

function CALL_SCALEFORM_MOVIE_METHOD(scaleform, method)
    Velora.invoke(0x9D1320, "void", scaleform, method)
end

function CALL_SCALEFORM_MOVIE_METHOD_WITH_NUMBER(scaleform, methodName, param1, param2, param3, param4, param5)
    Velora.invoke(0x9D13F0, "void", scaleform, methodName, param1, param2, param3, param4, param5)
end

function CALL_SCALEFORM_MOVIE_METHOD_WITH_STRING(scaleform, methodName, param1, param2, param3, param4, param5)
    Velora.invoke(0x9D14C0, "void", scaleform, methodName, param1, param2, param3, param4, param5)
end

function CALL_SCALEFORM_MOVIE_METHOD_WITH_NUMBER_AND_STRING(scaleform, methodName, floatParam1, floatParam2, floatParam3, floatParam4, floatParam5, stringParam1, stringParam2, stringParam3, stringParam4, stringParam5)
    Velora.invoke(0x9D15A0, "void", scaleform, methodName, floatParam1, floatParam2, floatParam3, floatParam4, floatParam5, stringParam1, stringParam2, stringParam3, stringParam4, stringParam5)
end

function BEGIN_SCALEFORM_SCRIPT_HUD_MOVIE_METHOD(hudComponent, invoke<BOOL>(0x9D1680, scaleform, invoke<BOOL>(0x9D16D0, invoke<BOOL>(0x9D17B0, invoke<BOOL>(0x9D1810, END_SCALEFORM_MOVIE_METHOD()
    return Velora.invoke(0x9D1870, "bool", hudComponent, invoke<BOOL>(0x9D1680, scaleform, invoke<BOOL>(0x9D16D0, invoke<BOOL>(0x9D17B0, invoke<BOOL>(0x9D1810, END_SCALEFORM_MOVIE_METHOD()
end

function END_SCALEFORM_MOVIE_METHOD_RETURN_VALUE(invoke<BOOL>(0x9D18A0, invoke<int>(0x9D18D0, invoke<BOOL>(0x9D18F0, char>(0x9D1920, value)
    return Velora.invoke(0x9D1990, "int", invoke<BOOL>(0x9D18A0, invoke<int>(0x9D18D0, invoke<BOOL>(0x9D18F0, char>(0x9D1920, value)
end

function SCALEFORM_MOVIE_METHOD_ADD_PARAM_FLOAT(value)
    Velora.invoke(0x9D19A0, "void", value)
end

function SCALEFORM_MOVIE_METHOD_ADD_PARAM_BOOL(value)
    Velora.invoke(0x9D19C0, "void", value)
end

function BEGIN_TEXT_COMMAND_SCALEFORM_STRING(componentType)
    Velora.invoke(0x9D19E0, "void", componentType)
end

function END_TEXT_COMMAND_SCALEFORM_STRING()
    Velora.invoke(0x9D19F0, "void")
end

function END_TEXT_COMMAND_UNPARSED_SCALEFORM_STRING()
    Velora.invoke(0x9D1A00, "void")
end

function SCALEFORM_MOVIE_METHOD_ADD_PARAM_LITERAL_STRING(string)
    Velora.invoke(0x9D1A10, "void", string)
end

function SCALEFORM_MOVIE_METHOD_ADD_PARAM_TEXTURE_NAME_STRING(string)
    Velora.invoke(0x9D1A30, "void", string)
end

function SCALEFORM_MOVIE_METHOD_ADD_PARAM_PLAYER_NAME_STRING(string)
    Velora.invoke(0x9D1A50, "void", string)
end

function DOES_LATEST_BRIEF_STRING_EXIST(invoke<BOOL>(0x9D1A70, value)
    return Velora.invoke(0x9D1AA0, "bool", invoke<BOOL>(0x9D1A70, value)
end

function REQUEST_SCALEFORM_SCRIPT_HUD_MOVIE(hudComponent)
    Velora.invoke(0x9D1B10, "void", hudComponent)
end

function HAS_SCALEFORM_SCRIPT_HUD_MOVIE_LOADED(invoke<BOOL>(0x9D1B30, hudComponent)
    return Velora.invoke(0x9D1B60, "bool", invoke<BOOL>(0x9D1B30, hudComponent)
end

function PASS_KEYBOARD_INPUT_TO_SCALEFORM(invoke<BOOL>(0x9D1B70, channel)
    return Velora.invoke(0x9D1BA0, "bool", invoke<BOOL>(0x9D1B70, channel)
end

function GET_TV_CHANNEL(volume)
    return Velora.invoke(0x9D1BD0, "int", volume)
end

function GET_TV_VOLUME(xPos, yPos, xScale, yScale, rotation, red, green, blue, alpha)
    return Velora.invoke(0x9D1C00, "float", xPos, yPos, xScale, yScale, rotation, red, green, blue, alpha)
end

function SET_TV_CHANNEL_PLAYLIST(tvChannel, playlistName, restart)
    Velora.invoke(0x9D1D20, "void", tvChannel, playlistName, restart)
end

function SET_TV_CHANNEL_PLAYLIST_AT_HOUR(tvChannel, playlistName, hour)
    Velora.invoke(0x9D1D40, "void", tvChannel, playlistName, hour)
end

function CLEAR_TV_CHANNEL_PLAYLIST(tvChannel)
    Velora.invoke(0x9D1D80, "void", tvChannel)
end

function IS_PLAYLIST_ON_CHANNEL(tvChannel, invoke<BOOL>(0x9D1DA0, invoke<BOOL>(0x9D1DD0, toggle)
    return Velora.invoke(0x9D1E00, "bool", tvChannel, invoke<BOOL>(0x9D1DA0, invoke<BOOL>(0x9D1DD0, toggle)
end

function SET_TV_PLAYER_WATCHING_THIS_FRAME(p0)
    Velora.invoke(0x9D1E20, "void", p0)
end

function GET_CURRENT_TV_CLIP_NAMEHASH(toggle)
    return Velora.invoke(0x9D1E90, "int", toggle)
end

function UI3DSCENE_IS_AVAILABLE(invoke<BOOL>(0x9D1ED0, presetName, ped, slot, posX, posY, invoke<BOOL>(0x9D1F40, UI3DSCENE_CLEAR_PATCHED_DATA()
    return Velora.invoke(0x9D2040, "bool", invoke<BOOL>(0x9D1ED0, presetName, ped, slot, posX, posY, invoke<BOOL>(0x9D1F40, UI3DSCENE_CLEAR_PATCHED_DATA()
end

function UI3DSCENE_MAKE_PUSHED_PRESET_PERSISTENT(toggle)
    Velora.invoke(0x9D2060, "void", toggle)
end

function TERRAINGRID_ACTIVATE(toggle)
    Velora.invoke(0x9D2080, "void", toggle)
end

function TERRAINGRID_SET_PARAMS(x, y, z, forwardX, forwardY, forwardZ, sizeX, sizeY, sizeZ, gridScale, glowIntensity, normalHeight, heightDiff)
    Velora.invoke(0x9D20A0, "void", x, y, z, forwardX, forwardY, forwardZ, sizeX, sizeY, sizeZ, gridScale, glowIntensity, normalHeight, heightDiff)
end

function TERRAINGRID_SET_COLOURS(lowR, lowG, lowB, lowAlpha, r, g, b, alpha, highR, highG, highB, highAlpha)
    Velora.invoke(0x9D2180, "void", lowR, lowG, lowB, lowAlpha, r, g, b, alpha, highR, highG, highB, highAlpha)
end

function ANIMPOSTFX_PLAY(effectName, duration, looped)
    Velora.invoke(0x9D21F0, "void", effectName, duration, looped)
end

function ANIMPOSTFX_STOP(effectName)
    Velora.invoke(0x9D2280, "void", effectName)
end

function ANIMPOSTFX_GET_CURRENT_TIME(invoke<float>(0x9D22E0, invoke<BOOL>(0x9D2350, ANIMPOSTFX_STOP_ALL()
    return Velora.invoke(0x9D23C0, "float", invoke<float>(0x9D22E0, invoke<BOOL>(0x9D2350, ANIMPOSTFX_STOP_ALL()
end

function ANIMPOSTFX_STOP_AND_FLUSH_REQUESTS(effectName)
    Velora.invoke(0x9D23E0, "void", effectName)
end

function BEGIN_TEXT_COMMAND_BUSYSPINNER_ON(string)
    Velora.invoke(0x9DFAC0, "void", string)
end

function END_TEXT_COMMAND_BUSYSPINNER_ON(busySpinnerType)
    Velora.invoke(0x9DFAD0, "void", busySpinnerType)
end

function BUSYSPINNER_OFF()
    Velora.invoke(0x9DFAE0, "void")
end

function PRELOAD_BUSYSPINNER()
    Velora.invoke(0x9DFAF0, "void")
end

function BUSYSPINNER_IS_ON(p0)
    return Velora.invoke(0x9DFB40, "bool", p0)
end

function SET_MOUSE_CURSOR_THIS_FRAME()
    Velora.invoke(0x9DFB50, "void")
end

function SET_MOUSE_CURSOR_STYLE(spriteId)
    Velora.invoke(0x9DFB60, "void", spriteId)
end

function SET_MOUSE_CURSOR_VISIBLE(toggle)
    Velora.invoke(0x9DFB70, "void", toggle)
end

function IS_MOUSE_ROLLED_OVER_INSTRUCTIONAL_BUTTONS(scaleformHandle, p1, p2, invoke<BOOL>(0x9DFB90, toggle)
    return Velora.invoke(0x9DFBA0, "bool", scaleformHandle, p1, p2, invoke<BOOL>(0x9DFB90, toggle)
end

function THEFEED_SET_SCRIPTED_MENU_HEIGHT(pos)
    Velora.invoke(0x9DFBF0, "void", pos)
end

function THEFEED_HIDE()
    Velora.invoke(0x9DFC20, "void")
end

function THEFEED_HIDE_THIS_FRAME()
    Velora.invoke(0x9DFC40, "void")
end

function THEFEED_SHOW()
    Velora.invoke(0x9DFC60, "void")
end

function THEFEED_FLUSH_QUEUE()
    Velora.invoke(0x9DFC80, "void")
end

function THEFEED_REMOVE_ITEM(notificationId)
    Velora.invoke(0x9DFCA0, "void", notificationId)
end

function THEFEED_FORCE_RENDER_ON()
    Velora.invoke(0x9DFCD0, "void")
end

function THEFEED_FORCE_RENDER_OFF()
    Velora.invoke(0x9DFCF0, "void")
end

function THEFEED_PAUSE()
    Velora.invoke(0x9DFD10, "void")
end

function THEFEED_RESUME()
    Velora.invoke(0x9DFD30, "void")
end

function THEFEED_IS_PAUSED(THEFEED_REPORT_LOGO_ON()
    return Velora.invoke(0x9DFD70, "bool", THEFEED_REPORT_LOGO_ON()
end

function THEFEED_REPORT_LOGO_OFF()
    Velora.invoke(0x9DFD90, "void")
end

function THEFEED_GET_LAST_SHOWN_PHONE_ACTIVATABLE_FEED_ID(THEFEED_AUTO_POST_GAMETIPS_ON()
    return Velora.invoke(0x9DFDE0, "int", THEFEED_AUTO_POST_GAMETIPS_ON()
end

function THEFEED_AUTO_POST_GAMETIPS_OFF()
    Velora.invoke(0x9DFE00, "void")
end

function THEFEED_SET_BACKGROUND_COLOR_FOR_NEXT_POST(hudColorIndex)
    Velora.invoke(0x9DFE20, "void", hudColorIndex)
end

function THEFEED_SET_RGBA_PARAMETER_FOR_NEXT_MESSAGE(red, green, blue, alpha)
    Velora.invoke(0x9DFE50, "void", red, green, blue, alpha)
end

function THEFEED_SET_FLASH_DURATION_PARAMETER_FOR_NEXT_MESSAGE(count)
    Velora.invoke(0x9DFEB0, "void", count)
end

function THEFEED_SET_VIBRATE_PARAMETER_FOR_NEXT_MESSAGE(toggle)
    Velora.invoke(0x9DFEE0, "void", toggle)
end

function THEFEED_RESET_ALL_PARAMETERS()
    Velora.invoke(0x9DFF10, "void")
end

function THEFEED_FREEZE_NEXT_POST()
    Velora.invoke(0x9DFF30, "void")
end

function THEFEED_CLEAR_FROZEN_POST()
    Velora.invoke(0x9DFF50, "void")
end

function THEFEED_SET_SNAP_FEED_ITEM_POSITIONS(p0)
    Velora.invoke(0xDEADBEEF, "void", p0)
end

function THEFEED_UPDATE_ITEM_TEXTURE(txdString1, txnString1, txdString2, txnString2)
    Velora.invoke(0x9DFF70, "void", txdString1, txnString1, txdString2, txnString2)
end

function BEGIN_TEXT_COMMAND_THEFEED_POST(text)
    Velora.invoke(0x9DFFC0, "void", text)
end

function END_TEXT_COMMAND_THEFEED_POST_STATS(statTitle, iconEnum, stepVal, barValue, isImportant, pictureTextureDict, invoke<int>(0x9DFFD0, txdName, textureName, flash, iconType, sender, invoke<int>(0x9E0010, txdName, textureName, flash, iconType, sender, invoke<int>(0x9E0080, txdName, textureName, flash, iconType, sender, subject, invoke<int>(0x9E0130, txdName, textureName, flash, iconType, sender, subject, duration, invoke<int>(0x9E01A0, txdName, textureName, flash, iconType1, sender, subject, duration, clanTag, iconType2, invoke<int>(0x9E0210, blink, invoke<int>(0x9E0280, blink, invoke<int>(0x9E02C0, blink, invoke<int>(0x9E0330, textureDict, textureName, rpBonus, colorOverlay, invoke<int>(0x9E0370, p0, p1, p2, p3, isLeader, unk0, clanDesc, R, G, invoke<int>(0x9E03A0, p0, p1, p2, p3, isLeader, unk0, clanDesc, playerName, R, G, invoke<int>(0x9E0420, gxtLabel1, p1, invoke<int>(0x9E04B0, gxtLabel1, p1, gxtLabel2, invoke<int>(0x9E04E0, p0, p1, p2, p3, p4, invoke<int>(0x9E0520, blink, invoke<int>(0x9E0560, p0, p1, p2, p3, invoke<int>(0x9E05A0, txdName1, textureName1, count1, txdName2, textureName2, count2, hudColor1, invoke<int>(0x9E05E0, type, image, invoke<int>(0xDEADBEEF, type, button, invoke<int>(0xDEADBEEF, GxtEntry)
    return Velora.invoke(0x9E0630, "int", statTitle, iconEnum, stepVal, barValue, isImportant, pictureTextureDict, invoke<int>(0x9DFFD0, txdName, textureName, flash, iconType, sender, invoke<int>(0x9E0010, txdName, textureName, flash, iconType, sender, invoke<int>(0x9E0080, txdName, textureName, flash, iconType, sender, subject, invoke<int>(0x9E0130, txdName, textureName, flash, iconType, sender, subject, duration, invoke<int>(0x9E01A0, txdName, textureName, flash, iconType1, sender, subject, duration, clanTag, iconType2, invoke<int>(0x9E0210, blink, invoke<int>(0x9E0280, blink, invoke<int>(0x9E02C0, blink, invoke<int>(0x9E0330, textureDict, textureName, rpBonus, colorOverlay, invoke<int>(0x9E0370, p0, p1, p2, p3, isLeader, unk0, clanDesc, R, G, invoke<int>(0x9E03A0, p0, p1, p2, p3, isLeader, unk0, clanDesc, playerName, R, G, invoke<int>(0x9E0420, gxtLabel1, p1, invoke<int>(0x9E04B0, gxtLabel1, p1, gxtLabel2, invoke<int>(0x9E04E0, p0, p1, p2, p3, p4, invoke<int>(0x9E0520, blink, invoke<int>(0x9E0560, p0, p1, p2, p3, invoke<int>(0x9E05A0, txdName1, textureName1, count1, txdName2, textureName2, count2, hudColor1, invoke<int>(0x9E05E0, type, image, invoke<int>(0xDEADBEEF, type, button, invoke<int>(0xDEADBEEF, GxtEntry)
end

function END_TEXT_COMMAND_PRINT(duration, drawImmediately)
    Velora.invoke(0x9E0640, "void", duration, drawImmediately)
end

function BEGIN_TEXT_COMMAND_IS_MESSAGE_DISPLAYED(text)
    Velora.invoke(0x9E0660, "void", text)
end

function END_TEXT_COMMAND_IS_MESSAGE_DISPLAYED(text)
    return Velora.invoke(0x9E0690, "bool", text)
end

function END_TEXT_COMMAND_DISPLAY_TEXT(x, y, p2)
    Velora.invoke(0x9E06C0, "void", x, y, p2)
end

function BEGIN_TEXT_COMMAND_GET_SCREEN_WIDTH_OF_DISPLAY_TEXT(text)
    Velora.invoke(0x9E0710, "void", text)
end

function END_TEXT_COMMAND_GET_SCREEN_WIDTH_OF_DISPLAY_TEXT(invoke<float>(0x9E0720, entry)
    return Velora.invoke(0x9E0750, "float", invoke<float>(0x9E0720, entry)
end

function END_TEXT_COMMAND_GET_NUMBER_OF_LINES_FOR_STRING(x, invoke<int>(0x9E0760, inputType)
    return Velora.invoke(0x9E0790, "int", x, invoke<int>(0x9E0760, inputType)
end

function END_TEXT_COMMAND_DISPLAY_HELP(p0, loop, beep, shape)
    Velora.invoke(0x9E07A0, "void", p0, loop, beep, shape)
end

function BEGIN_TEXT_COMMAND_IS_THIS_HELP_MESSAGE_BEING_DISPLAYED(labelName)
    Velora.invoke(0x9E07D0, "void", labelName)
end

function END_TEXT_COMMAND_IS_THIS_HELP_MESSAGE_BEING_DISPLAYED(invoke<BOOL>(0x9E07E0, textLabel)
    return Velora.invoke(0x9E0810, "bool", invoke<BOOL>(0x9E07E0, textLabel)
end

function END_TEXT_COMMAND_SET_BLIP_NAME(blip)
    Velora.invoke(0x9E0820, "void", blip)
end

function BEGIN_TEXT_COMMAND_ADD_DIRECTLY_TO_PREVIOUS_BRIEFS(p0)
    Velora.invoke(0x9E0830, "void", p0)
end

function END_TEXT_COMMAND_ADD_DIRECTLY_TO_PREVIOUS_BRIEFS(p0)
    Velora.invoke(0x9E0840, "void", p0)
end

function BEGIN_TEXT_COMMAND_CLEAR_PRINT(text)
    Velora.invoke(0x9E0860, "void", text)
end

function END_TEXT_COMMAND_CLEAR_PRINT()
    Velora.invoke(0x9E0870, "void")
end

function BEGIN_TEXT_COMMAND_OVERRIDE_BUTTON_TEXT(gxtEntry)
    Velora.invoke(0x9E0880, "void", gxtEntry)
end

function END_TEXT_COMMAND_OVERRIDE_BUTTON_TEXT(p0)
    Velora.invoke(0x9E0890, "void", p0)
end

function ADD_TEXT_COMPONENT_INTEGER(value)
    Velora.invoke(0x9E08A0, "void", value)
end

function ADD_TEXT_COMPONENT_FLOAT(value, decimalPlaces)
    Velora.invoke(0x9E08B0, "void", value, decimalPlaces)
end

function ADD_TEXT_COMPONENT_SUBSTRING_TEXT_LABEL(labelName)
    Velora.invoke(0x9E08C0, "void", labelName)
end

function ADD_TEXT_COMPONENT_SUBSTRING_TEXT_LABEL_HASH_KEY(gxtEntryHash)
    Velora.invoke(0x9E08D0, "void", gxtEntryHash)
end

function ADD_TEXT_COMPONENT_SUBSTRING_BLIP_NAME(blip)
    Velora.invoke(0x9E08E0, "void", blip)
end

function ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text)
    Velora.invoke(0x9E08F0, "void", text)
end

function ADD_TEXT_COMPONENT_SUBSTRING_TIME(timestamp, flags)
    Velora.invoke(0x9E0900, "void", timestamp, flags)
end

function ADD_TEXT_COMPONENT_FORMATTED_INTEGER(value, commaSeparated)
    Velora.invoke(0x9E0910, "void", value, commaSeparated)
end

function ADD_TEXT_COMPONENT_SUBSTRING_PHONE_NUMBER(p0, p1)
    Velora.invoke(0x9E0920, "void", p0, p1)
end

function ADD_TEXT_COMPONENT_SUBSTRING_WEBSITE(website)
    Velora.invoke(0x9E09B0, "void", website)
end

function ADD_TEXT_COMPONENT_SUBSTRING_KEYBOARD_DISPLAY(string)
    Velora.invoke(0x9E09C0, "void", string)
end

function SET_COLOUR_OF_NEXT_TEXT_COMPONENT(hudColor)
    Velora.invoke(0x9E09D0, "void", hudColor)
end

function GET_CHARACTER_FROM_AUDIO_CONVERSATION_FILENAME(text, position, char>(0x9E09E0, text, position, length, char>(0x9E0A10, text, startPosition, char>(0x9E0A40, char>(0x9E0A80, CLEAR_PRINTS()
    return Velora.invoke(0x9E0B10, "string", text, position, char>(0x9E09E0, text, position, length, char>(0x9E0A10, text, startPosition, char>(0x9E0A40, char>(0x9E0A80, CLEAR_PRINTS()
end

function CLEAR_BRIEF()
    Velora.invoke(0x9E0B20, "void")
end

function CLEAR_ALL_HELP_MESSAGES()
    Velora.invoke(0x9E0B40, "void")
end

function CLEAR_THIS_PRINT(p0)
    Velora.invoke(0x9E0B50, "void", p0)
end

function CLEAR_SMALL_PRINTS()
    Velora.invoke(0x9E0CD0, "void")
end

function DOES_TEXT_BLOCK_EXIST(invoke<BOOL>(0x9E0CE0, gxt, slot)
    return Velora.invoke(0x9E0D20, "bool", invoke<BOOL>(0x9E0CE0, gxt, slot)
end

function REQUEST_ADDITIONAL_TEXT_FOR_DLC(gxt, slot)
    Velora.invoke(0x9E0D40, "void", gxt, slot)
end

function HAS_ADDITIONAL_TEXT_LOADED(invoke<BOOL>(0x9E0D60, p0, p1)
    return Velora.invoke(0x9E0D90, "bool", invoke<BOOL>(0x9E0D60, p0, p1)
end

function IS_STREAMING_ADDITIONAL_TEXT(invoke<BOOL>(0x9E0DB0, gxt, invoke<BOOL>(0x9E0DE0, invoke<BOOL>(0x9E0E30, string, char>(0x9E0E60, invoke<int>(0x9E0ED0, invoke<int>(0x9E0F20, invoke<int>(0x9E0F50, char>(0x9E0F80, toggle)
    return Velora.invoke(0x9E10A0, "bool", invoke<BOOL>(0x9E0DB0, gxt, invoke<BOOL>(0x9E0DE0, invoke<BOOL>(0x9E0E30, string, char>(0x9E0E60, invoke<int>(0x9E0ED0, invoke<int>(0x9E0F20, invoke<int>(0x9E0F50, char>(0x9E0F80, toggle)
end

function DISPLAY_HUD_WHEN_NOT_IN_STATE_OF_PLAY_THIS_FRAME()
    Velora.invoke(0x9E10D0, "void")
end

function DISPLAY_HUD_WHEN_PAUSED_THIS_FRAME()
    Velora.invoke(0x9E10F0, "void")
end

function DISPLAY_RADAR(toggle)
    Velora.invoke(0x9E1110, "void", toggle)
end

function SET_FAKE_SPECTATOR_MODE(toggle)
    Velora.invoke(0x9E1140, "void", toggle)
end

function GET_FAKE_SPECTATOR_MODE(p0)
    return Velora.invoke(0x9E11C0, "bool", p0)
end

function ADD_VALID_VEHICLE_HIT_HASH(p0)
    Velora.invoke(0x9E1200, "void", p0)
end

function CLEAR_VALID_VEHICLE_HIT_HASHES()
    Velora.invoke(0x9E12B0, "void")
end

function SET_BLIP_ROUTE(blip, enabled)
    Velora.invoke(0x9E12F0, "void", blip, enabled)
end

function CLEAR_ALL_BLIP_ROUTES()
    Velora.invoke(0x9E1310, "void")
end

function SET_BLIP_ROUTE_COLOUR(blip, colour)
    Velora.invoke(0x9E1320, "void", blip, colour)
end

function SET_FORCE_SHOW_GPS(toggle)
    Velora.invoke(0x9E1340, "void", toggle)
end

function SET_USE_SET_DESTINATION_IN_PAUSE_MAP(toggle)
    Velora.invoke(0x9E1360, "void", toggle)
end

function SET_BLOCK_WANTED_FLASH(disabled)
    Velora.invoke(0x9E1380, "void", disabled)
end

function ADD_NEXT_MESSAGE_TO_PREVIOUS_BRIEFS(p0)
    Velora.invoke(0x9E13A0, "void", p0)
end

function FORCE_NEXT_MESSAGE_TO_PREVIOUS_BRIEFS_LIST(p0)
    Velora.invoke(0x9E13C0, "void", p0)
end

function SET_RADAR_ZOOM_PRECISE(zoom)
    Velora.invoke(0x9E13E0, "void", zoom)
end

function SET_RADAR_ZOOM(zoomLevel)
    Velora.invoke(0x9E1420, "void", zoomLevel)
end

function SET_RADAR_ZOOM_TO_BLIP(blip, zoom)
    Velora.invoke(0x9E14D0, "void", blip, zoom)
end

function SET_RADAR_ZOOM_TO_DISTANCE(zoom)
    Velora.invoke(0x9E15A0, "void", zoom)
end

function UPDATE_RADAR_ZOOM_TO_BLIP()
    Velora.invoke(0x9E15E0, "void")
end

function GET_HUD_COLOUR(hudColorIndex, r, g, b, a)
    Velora.invoke(0x9E15F0, "void", hudColorIndex, r, g, b, a)
end

function SET_SCRIPT_VARIABLE_HUD_COLOUR(r, g, b, a)
    Velora.invoke(0x9E1650, "void", r, g, b, a)
end

function SET_SECOND_SCRIPT_VARIABLE_HUD_COLOUR(r, g, b, a)
    Velora.invoke(0x9E1670, "void", r, g, b, a)
end

function REPLACE_HUD_COLOUR(hudColorIndex, hudColorIndex2)
    Velora.invoke(0x9E1690, "void", hudColorIndex, hudColorIndex2)
end

function REPLACE_HUD_COLOUR_WITH_RGBA(hudColorIndex, r, g, b, a)
    Velora.invoke(0x9E16D0, "void", hudColorIndex, r, g, b, a)
end

function SET_ABILITY_BAR_VISIBILITY(visible)
    Velora.invoke(0x9E1700, "void", visible)
end

function SET_ALLOW_ABILITY_BAR(toggle)
    Velora.invoke(0x9E1720, "void", toggle)
end

function FLASH_ABILITY_BAR(millisecondsToFlash)
    Velora.invoke(0x9E1750, "void", millisecondsToFlash)
end

function SET_ABILITY_BAR_VALUE(p0, p1)
    Velora.invoke(0x9E1760, "void", p0, p1)
end

function FLASH_WANTED_DISPLAY(p0)
    Velora.invoke(0x9E1780, "void", p0)
end

function FORCE_OFF_WANTED_STAR_FLASH(toggle)
    Velora.invoke(0x9E17A0, "void", toggle)
end

function SET_CUSTOM_MP_HUD_COLOR(hudColorId)
    Velora.invoke(0x9E17C0, "void", hudColorId)
end

function GET_RENDERED_CHARACTER_HEIGHT(size, invoke<float>(0x9E1810, scale, size)
    return Velora.invoke(0x9E18D0, "float", size, invoke<float>(0x9E1810, scale, size)
end

function SET_TEXT_COLOUR(red, green, blue, alpha)
    Velora.invoke(0x9E18F0, "void", red, green, blue, alpha)
end

function SET_TEXT_CENTRE(align)
    Velora.invoke(0x9E1930, "void", align)
end

function SET_TEXT_RIGHT_JUSTIFY(toggle)
    Velora.invoke(0x9E1950, "void", toggle)
end

function SET_TEXT_JUSTIFICATION(justifyType)
    Velora.invoke(0x9E1970, "void", justifyType)
end

function SET_TEXT_WRAP(start, end)
    Velora.invoke(0x9E19A0, "void", start, end)
end

function SET_TEXT_LEADING(p0)
    Velora.invoke(0x9E19C0, "void", p0)
end

function SET_TEXT_PROPORTIONAL(p0)
    Velora.invoke(0x9E19E0, "void", p0)
end

function SET_TEXT_FONT(fontType)
    Velora.invoke(0x9E19F0, "void", fontType)
end

function SET_TEXT_DROP_SHADOW()
    Velora.invoke(0x9E1A10, "void")
end

function SET_TEXT_DROPSHADOW(distance, r, g, b, a)
    Velora.invoke(0x9E1A20, "void", distance, r, g, b, a)
end

function SET_TEXT_OUTLINE()
    Velora.invoke(0x9E1A40, "void")
end

function SET_TEXT_EDGE(p0, r, g, b, a)
    Velora.invoke(0x9E1A50, "void", p0, r, g, b, a)
end

function SET_TEXT_RENDER_ID(renderId)
    Velora.invoke(0x9E1A60, "void", renderId)
end

function GET_DEFAULT_SCRIPT_RENDERTARGET_RENDER_ID(name, invoke<BOOL>(0x9E1AE0, invoke<BOOL>(0x9E1BA0, invoke<BOOL>(0x9E1BE0, modelHash)
    return Velora.invoke(0x9E1C20, "int", name, invoke<BOOL>(0x9E1AE0, invoke<BOOL>(0x9E1BA0, invoke<BOOL>(0x9E1BE0, modelHash)
end

function GET_NAMED_RENDERTARGET_RENDER_ID(invoke<int>(0x9E1CD0, invoke<BOOL>(0x9E1D10, toggle)
    return Velora.invoke(0x9E1DD0, "int", invoke<int>(0x9E1CD0, invoke<BOOL>(0x9E1D10, toggle)
end

function IS_HELP_MESSAGE_ON_SCREEN(style, hudColor, alpha, p3, p4)
    return Velora.invoke(0x9E1EB0, "bool", style, hudColor, alpha, p3, p4)
end

function GET_STANDARD_BLIP_ENUM_ID(invoke<Blip>(0x9E1F60, invoke<Blip>(0x9E1F80, invoke<Blip>(0x9E1FB0, invoke<Vector3>(0x9E1FD0, invoke<int>(0x9E2080, invoke<int>(0x9E20C0, invoke<Entity>(0x9E2100, invoke<Pickup>(0x9E2170, invoke<Blip>(0x9E2180, posX, posY, posZ, invoke<Blip>(0x9E21A0, x, y, z, width, invoke<Blip>(0x9E2260, invoke<Blip>(0x9E2290, invoke<Blip>(0x9E22B0, x, y, invoke<Blip>(0x9E22D0, posX, posY, posZ, radius, p4)
    return Velora.invoke(0x9E2380, "int", invoke<Blip>(0x9E1F60, invoke<Blip>(0x9E1F80, invoke<Blip>(0x9E1FB0, invoke<Vector3>(0x9E1FD0, invoke<int>(0x9E2080, invoke<int>(0x9E20C0, invoke<Entity>(0x9E2100, invoke<Pickup>(0x9E2170, invoke<Blip>(0x9E2180, posX, posY, posZ, invoke<Blip>(0x9E21A0, x, y, z, width, invoke<Blip>(0x9E2260, invoke<Blip>(0x9E2290, invoke<Blip>(0x9E22B0, x, y, invoke<Blip>(0x9E22D0, posX, posY, posZ, radius, p4)
end

function ALLOW_SONAR_BLIPS(toggle)
    Velora.invoke(0x9E23F0, "void", toggle)
end

function SET_BLIP_COORDS(blip, posX, posY, posZ)
    Velora.invoke(0x9E2410, "void", blip, posX, posY, posZ)
end

function GET_BLIP_COORDS(invoke<Vector3>(0x9E24B0, blip, spriteId)
    local x, y, z = Velora.invoke(0x9E2560, "vector3", invoke<Vector3>(0x9E24B0, blip, spriteId)
    return {x = x, y = y, z = z}
end

function GET_BLIP_SPRITE(invoke<int>(0x9E2580, p0, p1)
    return Velora.invoke(0x9E25C0, "int", invoke<int>(0x9E2580, p0, p1)
end

function SET_COP_BLIP_SPRITE_AS_STANDARD()
    Velora.invoke(0x9E25E0, "void")
end

function SET_BLIP_NAME_FROM_TEXT_FILE(blip, gxtEntry)
    Velora.invoke(0x9E2600, "void", blip, gxtEntry)
end

function SET_BLIP_NAME_TO_PLAYER_NAME(blip, player)
    Velora.invoke(0x9E2640, "void", blip, player)
end

function SET_BLIP_ALPHA(blip, alpha)
    Velora.invoke(0x9E2680, "void", blip, alpha)
end

function GET_BLIP_ALPHA(invoke<int>(0x9E26C0, blip, opacity, duration)
    return Velora.invoke(0x9E2700, "int", invoke<int>(0x9E26C0, blip, opacity, duration)
end

function GET_BLIP_FADE_DIRECTION(invoke<int>(0x9E2730, blip, rotation)
    return Velora.invoke(0x9E2760, "int", invoke<int>(0x9E2730, blip, rotation)
end

function SET_BLIP_ROTATION_WITH_FLOAT(blip, heading)
    Velora.invoke(0x9E2780, "void", blip, heading)
end

function GET_BLIP_ROTATION(invoke<int>(0x9E27A0, blip, duration)
    return Velora.invoke(0x9E27E0, "int", invoke<int>(0x9E27A0, blip, duration)
end

function SET_BLIP_FLASH_INTERVAL(blip, p1)
    Velora.invoke(0x9E2800, "void", blip, p1)
end

function SET_BLIP_COLOUR(blip, color)
    Velora.invoke(0x9E2820, "void", blip, color)
end

function SET_BLIP_SECONDARY_COLOUR(blip, r, g, b)
    Velora.invoke(0x9E2840, "void", blip, r, g, b)
end

function GET_BLIP_COLOUR(invoke<int>(0x9E28C0, invoke<int>(0x9E2900, invoke<BOOL>(0x9E29A0, invoke<BOOL>(0x9E29E0, invoke<BOOL>(0x9E2A20, blip, toggle)
    return Velora.invoke(0x9E2A60, "int", invoke<int>(0x9E28C0, invoke<int>(0x9E2900, invoke<BOOL>(0x9E29A0, invoke<BOOL>(0x9E29E0, invoke<BOOL>(0x9E2A20, blip, toggle)
end

function SET_BLIP_HIGH_DETAIL(blip, toggle)
    Velora.invoke(0x9E2A80, "void", blip, toggle)
end

function SET_BLIP_AS_MISSION_CREATOR_BLIP(blip, toggle)
    Velora.invoke(0x9E2AA0, "void", blip, toggle)
end

function IS_MISSION_CREATOR_BLIP(invoke<BOOL>(0x9E2AC0, toggle)
    return Velora.invoke(0x9E2B90, "bool", invoke<BOOL>(0x9E2AC0, toggle)
end

function SHOW_CONTACT_INSTRUCTIONAL_BUTTON(toggle)
    Velora.invoke(0x9E2BE0, "void", toggle)
end

function RELOAD_MAP_MENU()
    Velora.invoke(0x9E2C80, "void")
end

function SET_BLIP_MARKER_LONG_DISTANCE(p0, p1)
    Velora.invoke(0x9E2CA0, "void", p0, p1)
end

function SET_BLIP_FLASHES(blip, toggle)
    Velora.invoke(0x9E2CC0, "void", blip, toggle)
end

function SET_BLIP_FLASHES_ALTERNATE(blip, toggle)
    Velora.invoke(0x9E2CE0, "void", blip, toggle)
end

function IS_BLIP_FLASHING(invoke<BOOL>(0x9E2D00, blip, toggle)
    return Velora.invoke(0x9E2D40, "bool", invoke<BOOL>(0x9E2D00, blip, toggle)
end

function SET_BLIP_SCALE(blip, scale)
    Velora.invoke(0x9E2D60, "void", blip, scale)
end

function SET_BLIP_SCALE_2D(blip, xScale, yScale)
    Velora.invoke(0x9E2D80, "void", blip, xScale, yScale)
end

function SET_BLIP_PRIORITY(blip, priority)
    Velora.invoke(0x9E2DF0, "void", blip, priority)
end

function SET_BLIP_DISPLAY(blip, displayId)
    Velora.invoke(0x9E2E10, "void", blip, displayId)
end

function SET_BLIP_CATEGORY(blip, index)
    Velora.invoke(0x9E2E30, "void", blip, index)
end

function REMOVE_BLIP(blip)
    Velora.invoke(0x9E2E50, "void", blip)
end

function SET_BLIP_AS_FRIENDLY(blip, toggle)
    Velora.invoke(0x9E2EC0, "void", blip, toggle)
end

function PULSE_BLIP(blip)
    Velora.invoke(0x9E2EE0, "void", blip)
end

function SHOW_NUMBER_ON_BLIP(blip, number)
    Velora.invoke(0x9E2F00, "void", blip, number)
end

function HIDE_NUMBER_ON_BLIP(blip)
    Velora.invoke(0x9E2F30, "void", blip)
end

function SHOW_HEIGHT_ON_BLIP(blip, toggle)
    Velora.invoke(0x9E2F50, "void", blip, toggle)
end

function SHOW_TICK_ON_BLIP(blip, toggle)
    Velora.invoke(0x9E2F70, "void", blip, toggle)
end

function SHOW_GOLD_TICK_ON_BLIP(blip, toggle)
    Velora.invoke(0x9E2F90, "void", blip, toggle)
end

function SHOW_FOR_SALE_ICON_ON_BLIP(blip, toggle)
    Velora.invoke(0x9E2FB0, "void", blip, toggle)
end

function SHOW_HEADING_INDICATOR_ON_BLIP(blip, toggle)
    Velora.invoke(0x9E2FD0, "void", blip, toggle)
end

function SHOW_OUTLINE_INDICATOR_ON_BLIP(blip, toggle)
    Velora.invoke(0x9E2FF0, "void", blip, toggle)
end

function SHOW_FRIEND_INDICATOR_ON_BLIP(blip, toggle)
    Velora.invoke(0x9E3010, "void", blip, toggle)
end

function SHOW_CREW_INDICATOR_ON_BLIP(blip, toggle)
    Velora.invoke(0x9E3030, "void", blip, toggle)
end

function SET_BLIP_EXTENDED_HEIGHT_THRESHOLD(blip, toggle)
    Velora.invoke(0x9E3050, "void", blip, toggle)
end

function SET_BLIP_SHORT_HEIGHT_THRESHOLD(p0, p1)
    Velora.invoke(0x9E3070, "void", p0, p1)
end

function SET_BLIP_USE_HEIGHT_INDICATOR_ON_EDGE(blip, p1)
    Velora.invoke(0x9E3090, "void", blip, p1)
end

function SET_BLIP_AS_MINIMAL_ON_EDGE(blip, toggle)
    Velora.invoke(0x9E30B0, "void", blip, toggle)
end

function SET_RADIUS_BLIP_EDGE(blip, toggle)
    Velora.invoke(0x9E30D0, "void", blip, toggle)
end

function DOES_BLIP_EXIST(invoke<BOOL>(0x9E30F0, SET_WAYPOINT_OFF()
    return Velora.invoke(0x9E3120, "bool", invoke<BOOL>(0x9E30F0, SET_WAYPOINT_OFF()
end

function DELETE_WAYPOINTS_FROM_THIS_PLAYER()
    Velora.invoke(0x9E3130, "void")
end

function REFRESH_WAYPOINT()
    Velora.invoke(0x9E3150, "void")
end

function IS_WAYPOINT_ACTIVE(x, y)
    return Velora.invoke(0x9E3190, "bool", x, y)
end

function SET_BLIP_BRIGHT(blip, toggle)
    Velora.invoke(0x9E3250, "void", blip, toggle)
end

function SET_BLIP_SHOW_CONE(blip, toggle, hudColorIndex)
    Velora.invoke(0x9E3270, "void", blip, toggle, hudColorIndex)
end

function REMOVE_COP_BLIP_FROM_PED(ped)
    Velora.invoke(0x9E32C0, "void", ped)
end

function SETUP_FAKE_CONE_DATA(blip, p1, p2, p3, p4, p5, p6, p7, p8)
    Velora.invoke(0x9E3310, "void", blip, p1, p2, p3, p4, p5, p6, p7, p8)
end

function REMOVE_FAKE_CONE_DATA(blip)
    Velora.invoke(0x9E3350, "void", blip)
end

function CLEAR_FAKE_CONE_ARRAY()
    Velora.invoke(0x9E3360, "void")
end

function SET_MINIMAP_COMPONENT(componentId, toggle, invoke<BOOL>(0x9E33C0, toggle)
    return Velora.invoke(0x9E3400, "bool", componentId, toggle, invoke<BOOL>(0x9E33C0, toggle)
end

function SHOW_ACCOUNT_PICKER()
    Velora.invoke(0x9E3420, "void")
end

function GET_MAIN_PLAYER_BLIP_ID(p0)
    return Velora.invoke(0x9E3470, "int", p0)
end

function HIDE_LOADING_ON_FADE_THIS_FRAME()
    Velora.invoke(0x9E3490, "void")
end

function SET_RADAR_AS_INTERIOR_THIS_FRAME(interior, x, y, z, zoom)
    Velora.invoke(0x9E34A0, "void", interior, x, y, z, zoom)
end

function SET_INSIDE_VERY_SMALL_INTERIOR(toggle)
    Velora.invoke(0x9E34F0, "void", toggle)
end

function SET_INSIDE_VERY_LARGE_INTERIOR(toggle)
    Velora.invoke(0x9E3510, "void", toggle)
end

function SET_RADAR_AS_EXTERIOR_THIS_FRAME()
    Velora.invoke(0x9E3530, "void")
end

function SET_FAKE_PAUSEMAP_PLAYER_POSITION_THIS_FRAME(x, y)
    Velora.invoke(0x9E3540, "void", x, y)
end

function SET_FAKE_GPS_PLAYER_POSITION_THIS_FRAME(x, y, p2)
    Velora.invoke(0x9E3560, "void", x, y, p2)
end

function IS_PAUSEMAP_IN_INTERIOR_MODE(HIDE_MINIMAP_EXTERIOR_MAP_THIS_FRAME()
    return Velora.invoke(0x9E35A0, "bool", HIDE_MINIMAP_EXTERIOR_MAP_THIS_FRAME()
end

function HIDE_MINIMAP_INTERIOR_MAP_THIS_FRAME()
    Velora.invoke(0x9E35B0, "void")
end

function SET_USE_ISLAND_MAP(toggle)
    Velora.invoke(0x9E35C0, "void", toggle)
end

function DONT_TILT_MINIMAP_THIS_FRAME()
    Velora.invoke(0x9E35F0, "void")
end

function DONT_ZOOM_MINIMAP_WHEN_RUNNING_THIS_FRAME()
    Velora.invoke(0x9E3600, "void")
end

function DONT_ZOOM_MINIMAP_WHEN_SNIPING_THIS_FRAME()
    Velora.invoke(0x9E3610, "void")
end

function SET_WIDESCREEN_FORMAT(p0)
    Velora.invoke(0x9E3620, "void", p0)
end

function DISPLAY_AREA_NAME(toggle)
    Velora.invoke(0x9E3640, "void", toggle)
end

function DISPLAY_CASH(toggle)
    Velora.invoke(0x9E3660, "void", toggle)
end

function USE_FAKE_MP_CASH(toggle)
    Velora.invoke(0x9E3680, "void", toggle)
end

function CHANGE_FAKE_MP_CASH(cash, bank)
    Velora.invoke(0x9E36A0, "void", cash, bank)
end

function DISPLAY_AMMO_THIS_FRAME(display)
    Velora.invoke(0x9E36B0, "void", display)
end

function DISPLAY_SNIPER_SCOPE_THIS_FRAME()
    Velora.invoke(0x9E36D0, "void")
end

function HIDE_HUD_AND_RADAR_THIS_FRAME()
    Velora.invoke(0x9E36E0, "void")
end

function ALLOW_DISPLAY_OF_MULTIPLAYER_CASH_TEXT(allow)
    Velora.invoke(0x9E36F0, "void", allow)
end

function SET_MULTIPLAYER_WALLET_CASH()
    Velora.invoke(0x9E3710, "void")
end

function REMOVE_MULTIPLAYER_WALLET_CASH()
    Velora.invoke(0x9E3730, "void")
end

function SET_MULTIPLAYER_BANK_CASH()
    Velora.invoke(0x9E3750, "void")
end

function REMOVE_MULTIPLAYER_BANK_CASH()
    Velora.invoke(0x9E3770, "void")
end

function SET_MULTIPLAYER_HUD_CASH(p0, p1)
    Velora.invoke(0x9E3790, "void", p0, p1)
end

function REMOVE_MULTIPLAYER_HUD_CASH()
    Velora.invoke(0x9E37A0, "void")
end

function HIDE_HELP_TEXT_THIS_FRAME()
    Velora.invoke(0x9E37D0, "void")
end

function IS_IME_IN_PROGRESS(message, p1)
    return Velora.invoke(0x9E37F0, "bool", message, p1)
end

function HUD_FORCE_WEAPON_WHEEL(show)
    Velora.invoke(0x9E3850, "void", show)
end

function HUD_FORCE_SPECIAL_VEHICLE_WEAPON_WHEEL()
    Velora.invoke(0x9E3870, "void")
end

function HUD_SUPPRESS_WEAPON_WHEEL_RESULTS_THIS_FRAME()
    Velora.invoke(0x9E3880, "void")
end

function HUD_GET_WEAPON_WHEEL_CURRENTLY_HIGHLIGHTED(weaponHash)
    return Velora.invoke(0x9E38B0, "int", weaponHash)
end

function HUD_GET_WEAPON_WHEEL_TOP_SLOT(invoke<Hash>(0x9E3900, toggle)
    return Velora.invoke(0x9E3960, "int", invoke<Hash>(0x9E3900, toggle)
end

function SET_GPS_FLAGS(p0, p1)
    Velora.invoke(0x9E3980, "void", p0, p1)
end

function CLEAR_GPS_FLAGS()
    Velora.invoke(0x9E39B0, "void")
end

function SET_RACE_TRACK_RENDER(toggle)
    Velora.invoke(0x9E39D0, "void", toggle)
end

function CLEAR_GPS_RACE_TRACK()
    Velora.invoke(0x9E39F0, "void")
end

function START_GPS_CUSTOM_ROUTE(hudColor, displayOnFoot, followPlayer)
    Velora.invoke(0x9E3A00, "void", hudColor, displayOnFoot, followPlayer)
end

function ADD_POINT_TO_GPS_CUSTOM_ROUTE(x, y, z)
    Velora.invoke(0x9E3A20, "void", x, y, z)
end

function SET_GPS_CUSTOM_ROUTE_RENDER(toggle, radarThickness, mapThickness)
    Velora.invoke(0x9E3A80, "void", toggle, radarThickness, mapThickness)
end

function CLEAR_GPS_CUSTOM_ROUTE()
    Velora.invoke(0x9E3AA0, "void")
end

function START_GPS_MULTI_ROUTE(hudColor, routeFromPlayer, displayOnFoot)
    Velora.invoke(0x9E3AC0, "void", hudColor, routeFromPlayer, displayOnFoot)
end

function ADD_POINT_TO_GPS_MULTI_ROUTE(x, y, z)
    Velora.invoke(0x9E3AE0, "void", x, y, z)
end

function SET_GPS_MULTI_ROUTE_RENDER(toggle)
    Velora.invoke(0x9E3B40, "void", toggle)
end

function CLEAR_GPS_MULTI_ROUTE()
    Velora.invoke(0x9E3B60, "void")
end

function CLEAR_GPS_PLAYER_WAYPOINT()
    Velora.invoke(0x9E3B70, "void")
end

function SET_GPS_FLASHES(toggle)
    Velora.invoke(0x9E3B90, "void", toggle)
end

function SET_PLAYER_ICON_COLOUR(color)
    Velora.invoke(0x9E3BB0, "void", color)
end

function FLASH_MINIMAP_DISPLAY()
    Velora.invoke(0x9E3BC0, "void")
end

function FLASH_MINIMAP_DISPLAY_WITH_COLOR(hudColorIndex)
    Velora.invoke(0x9E3BD0, "void", hudColorIndex)
end

function TOGGLE_STEALTH_RADAR(toggle)
    Velora.invoke(0x9E3BE0, "void", toggle)
end

function SET_MINIMAP_IN_SPECTATOR_MODE(toggle, ped)
    Velora.invoke(0x9E3C00, "void", toggle, ped)
end

function SET_MISSION_NAME(p0, name)
    Velora.invoke(0x9E3C70, "void", p0, name)
end

function SET_MISSION_NAME_FOR_UGC_MISSION(p0, name)
    Velora.invoke(0x9E3C90, "void", p0, name)
end

function SET_DESCRIPTION_FOR_UGC_MISSION_EIGHT_STRINGS(p0, p1, p2, p3, p4, p5, p6, p7, p8)
    Velora.invoke(0x9E3D00, "void", p0, p1, p2, p3, p4, p5, p6, p7, p8)
end

function SET_MINIMAP_BLOCK_WAYPOINT(toggle)
    Velora.invoke(0x9E3D50, "void", toggle)
end

function SET_MINIMAP_IN_PROLOGUE(toggle)
    Velora.invoke(0x9E3D70, "void", toggle)
end

function SET_MINIMAP_HIDE_FOW(toggle)
    Velora.invoke(0x9E3DA0, "void", toggle)
end

function GET_MINIMAP_FOW_DISCOVERY_RATIO(x, y, invoke<BOOL>(0x9E3DE0, p0)
    return Velora.invoke(0x9E3E50, "float", x, y, invoke<BOOL>(0x9E3DE0, p0)
end

function SET_MINIMAP_FOW_REVEAL_COORDINATE(x, y, z)
    Velora.invoke(0x9E3E70, "void", x, y, z)
end

function SET_MINIMAP_GOLF_COURSE(hole)
    Velora.invoke(0x9E3EC0, "void", hole)
end

function SET_MINIMAP_GOLF_COURSE_OFF()
    Velora.invoke(0x9E3ED0, "void")
end

function LOCK_MINIMAP_ANGLE(angle)
    Velora.invoke(0x9E3EE0, "void", angle)
end

function UNLOCK_MINIMAP_ANGLE()
    Velora.invoke(0x9E3F00, "void")
end

function LOCK_MINIMAP_POSITION(x, y)
    Velora.invoke(0x9E3F10, "void", x, y)
end

function UNLOCK_MINIMAP_POSITION()
    Velora.invoke(0x9E3F30, "void")
end

function SET_FAKE_MINIMAP_MAX_ALTIMETER_HEIGHT(altitude, p1, p2)
    Velora.invoke(0x9E3F50, "void", altitude, p1, p2)
end

function SET_HEALTH_HUD_DISPLAY_VALUES(health, capacity, wasAdded)
    Velora.invoke(0x9E3F80, "void", health, capacity, wasAdded)
end

function SET_MAX_HEALTH_HUD_DISPLAY(maximumValue)
    Velora.invoke(0x9E3FA0, "void", maximumValue)
end

function SET_MAX_ARMOUR_HUD_DISPLAY(maximumValue)
    Velora.invoke(0x9E3FB0, "void", maximumValue)
end

function SET_BIGMAP_ACTIVE(toggleBigMap, showFullMap)
    Velora.invoke(0x9E3FC0, "void", toggleBigMap, showFullMap)
end

function IS_HUD_COMPONENT_ACTIVE(invoke<BOOL>(0x9E3FE0, invoke<BOOL>(0x9E4030, id)
    return Velora.invoke(0x9E4070, "bool", invoke<BOOL>(0x9E3FE0, invoke<BOOL>(0x9E4030, id)
end

function SHOW_SCRIPTED_HUD_COMPONENT_THIS_FRAME(id)
    Velora.invoke(0x9E4090, "void", id)
end

function IS_SCRIPTED_HUD_COMPONENT_HIDDEN_THIS_FRAME(invoke<BOOL>(0x9E40B0, id)
    return Velora.invoke(0x9E40F0, "bool", invoke<BOOL>(0x9E40B0, id)
end

function SHOW_HUD_COMPONENT_THIS_FRAME(id)
    Velora.invoke(0x9E4150, "void", id)
end

function HIDE_STREET_AND_CAR_NAMES_THIS_FRAME()
    Velora.invoke(0x9E4170, "void")
end

function RESET_RETICULE_VALUES()
    Velora.invoke(0x9E4180, "void")
end

function RESET_HUD_COMPONENT_VALUES(id)
    Velora.invoke(0x9E4190, "void", id)
end

function SET_HUD_COMPONENT_POSITION(id, x, y)
    Velora.invoke(0x9E41B0, "void", id, x, y)
end

function GET_HUD_COMPONENT_POSITION(invoke<Vector3>(0x9E4210, CLEAR_REMINDER_MESSAGE()
    local x, y, z = Velora.invoke(0x9E42D0, "vector3", invoke<Vector3>(0x9E4210, CLEAR_REMINDER_MESSAGE()
    return {x = x, y = y, z = z}
end

function GET_HUD_SCREEN_POSITION_FROM_WORLD_POSITION(worldX, worldY, worldZ, screenX, invoke<int>(0x9E42E0, OPEN_REPORTUGC_MENU()
    return Velora.invoke(0x9E4380, "int", worldX, worldY, worldZ, screenX, invoke<int>(0x9E42E0, OPEN_REPORTUGC_MENU()
end

function FORCE_CLOSE_REPORTUGC_MENU()
    Velora.invoke(0x9E43B0, "void")
end

function IS_REPORTUGC_MENU_OPEN(invoke<BOOL>(0x9E4440, hudIndex, x, y)
    return Velora.invoke(0x9E44B0, "bool", invoke<BOOL>(0x9E4440, hudIndex, x, y)
end

function SET_FLOATING_HELP_TEXT_WORLD_POSITION(hudIndex, x, y, z)
    Velora.invoke(0x9E4510, "void", hudIndex, x, y, z)
end

function SET_FLOATING_HELP_TEXT_TO_ENTITY(hudIndex, entity, offsetX, offsetY)
    Velora.invoke(0x9E4570, "void", hudIndex, entity, offsetX, offsetY)
end

function SET_FLOATING_HELP_TEXT_STYLE(hudIndex, p1, p2, p3, p4, p5)
    Velora.invoke(0x9E4610, "void", hudIndex, p1, p2, p3, p4, p5)
end

function CLEAR_FLOATING_HELP(hudIndex, p1)
    Velora.invoke(0x9E4630, "void", hudIndex, p1)
end

function CREATE_MP_GAMER_TAG_WITH_CREW_COLOR(player, username, pointedClanTag, isRockstarClan, clanTag, clanFlag, r, g, b)
    Velora.invoke(0x9E4650, "void", player, username, pointedClanTag, isRockstarClan, clanTag, clanFlag, r, g, b)
end

function IS_MP_GAMER_TAG_MOVIE_ACTIVE(ped, username, pointedClanTag, isRockstarClan, clanTag, invoke<int>(0x9E4760, gamerTagId)
    return Velora.invoke(0x9E4890, "bool", ped, username, pointedClanTag, isRockstarClan, clanTag, invoke<int>(0x9E4760, gamerTagId)
end

function IS_MP_GAMER_TAG_ACTIVE(invoke<BOOL>(0x9E48B0, invoke<BOOL>(0x9E48E0, gamerTagId, component, toggle, p3)
    return Velora.invoke(0x9E4910, "bool", invoke<BOOL>(0x9E48B0, invoke<BOOL>(0x9E48E0, gamerTagId, component, toggle, p3)
end

function SET_ALL_MP_GAMER_TAGS_VISIBILITY(gamerTagId, toggle)
    Velora.invoke(0x9E4950, "void", gamerTagId, toggle)
end

function SET_MP_GAMER_TAGS_SHOULD_USE_VEHICLE_HEALTH(gamerTagId, toggle)
    Velora.invoke(0x9E4980, "void", gamerTagId, toggle)
end

function SET_MP_GAMER_TAGS_SHOULD_USE_POINTS_HEALTH(gamerTagId, toggle)
    Velora.invoke(0x9E49B0, "void", gamerTagId, toggle)
end

function SET_MP_GAMER_TAGS_POINT_HEALTH(gamerTagId, value, maximumValue)
    Velora.invoke(0x9E49E0, "void", gamerTagId, value, maximumValue)
end

function SET_MP_GAMER_TAG_COLOUR(gamerTagId, component, hudColorIndex)
    Velora.invoke(0x9E4A10, "void", gamerTagId, component, hudColorIndex)
end

function SET_MP_GAMER_TAG_HEALTH_BAR_COLOUR(gamerTagId, hudColorIndex)
    Velora.invoke(0x9E4A40, "void", gamerTagId, hudColorIndex)
end

function SET_MP_GAMER_TAG_ALPHA(gamerTagId, component, alpha)
    Velora.invoke(0x9E4A70, "void", gamerTagId, component, alpha)
end

function SET_MP_GAMER_TAG_WANTED_LEVEL(gamerTagId, wantedlvl)
    Velora.invoke(0x9E4AA0, "void", gamerTagId, wantedlvl)
end

function SET_MP_GAMER_TAG_NUM_PACKAGES(gamerTagId, p1)
    Velora.invoke(0x9E4AD0, "void", gamerTagId, p1)
end

function SET_MP_GAMER_TAG_NAME(gamerTagId, string)
    Velora.invoke(0x9E4B00, "void", gamerTagId, string)
end

function IS_UPDATING_MP_GAMER_TAG_NAME_AND_CREW_DETAILS(invoke<BOOL>(0x9E4B30, gamerTagId, string)
    return Velora.invoke(0x9E4B70, "bool", invoke<BOOL>(0x9E4B30, gamerTagId, string)
end

function GET_CURRENT_WEBPAGE_ID(invoke<int>(0x9E4BC0, flagIndex)
    return Velora.invoke(0x9E4BF0, "int", invoke<int>(0x9E4BC0, flagIndex)
end

function IS_WARNING_MESSAGE_READY_FOR_CONTROL(titleMsg, flags, promptMsg, p3, p4, p5, p6, showBackground, errorCode)
    return Velora.invoke(0x9E4C60, "bool", titleMsg, flags, promptMsg, p3, p4, p5, p6, showBackground, errorCode)
end

function SET_WARNING_MESSAGE_WITH_HEADER(entryHeader, entryLine1, instructionalKey, entryLine2, p4, p5, showBackground, p7, p8, p9)
    Velora.invoke(0x9E4D80, "void", entryHeader, entryLine1, instructionalKey, entryLine2, p4, p5, showBackground, p7, p8, p9)
end

function SET_WARNING_MESSAGE_WITH_HEADER_AND_SUBSTRING_FLAGS(entryHeader, entryLine1, instructionalKey, entryLine2, p4, p5, additionalIntInfo, additionalTextInfoLine1, additionalTextInfoLine2, showBackground, errorCode)
    Velora.invoke(0x9E4DF0, "void", entryHeader, entryLine1, instructionalKey, entryLine2, p4, p5, additionalIntInfo, additionalTextInfoLine1, additionalTextInfoLine2, showBackground, errorCode)
end

function SET_WARNING_MESSAGE_WITH_HEADER_EXTENDED(entryHeader, entryLine1, flags, entryLine2, p4, p5, p6, p7, showBg, p9, p10)
    Velora.invoke(0x9E4E60, "void", entryHeader, entryLine1, flags, entryLine2, p4, p5, p6, p7, showBg, p9, p10)
end

function SET_WARNING_MESSAGE_WITH_HEADER_AND_SUBSTRING_FLAGS_EXTENDED(labelTitle, labelMessage, p2, p3, labelMessage2, p5, p6, p7, p8, p9, background, errorCode)
    Velora.invoke(0x9E4ED0, "void", labelTitle, labelMessage, p2, p3, labelMessage2, p5, p6, p7, p8, p9, background, errorCode)
end

function GET_WARNING_SCREEN_MESSAGE_HASH(index, name, cash, rp, lvl, invoke<BOOL>(0x9E4F70, invoke<BOOL>(0x9E4FB0, REMOVE_WARNING_MESSAGE_OPTION_ITEMS()
    return Velora.invoke(0x9E4FE0, "int", index, name, cash, rp, lvl, invoke<BOOL>(0x9E4F70, invoke<BOOL>(0x9E4FB0, REMOVE_WARNING_MESSAGE_OPTION_ITEMS()
end

function IS_WARNING_MESSAGE_ACTIVE(CLEAR_DYNAMIC_PAUSE_MENU_ERROR_MESSAGE()
    return Velora.invoke(0x9E5030, "bool", CLEAR_DYNAMIC_PAUSE_MENU_ERROR_MESSAGE()
end

function CUSTOM_MINIMAP_SET_ACTIVE(toggle)
    Velora.invoke(0x9E5050, "void", toggle)
end

function CUSTOM_MINIMAP_SET_BLIP_OBJECT(spriteId)
    Velora.invoke(0x9E5070, "void", spriteId)
end

function CUSTOM_MINIMAP_CREATE_BLIP(x, y, invoke<int>(0x9E5080, CUSTOM_MINIMAP_CLEAR_BLIPS()
    return Velora.invoke(0x9E50F0, "int", x, y, invoke<int>(0x9E5080, CUSTOM_MINIMAP_CLEAR_BLIPS()
end

function FORCE_SONAR_BLIPS_THIS_FRAME(toggle)
    return Velora.invoke(0x9E5120, "bool", toggle)
end

function DRAW_FRONTEND_BACKGROUND_THIS_FRAME()
    Velora.invoke(0x9E5140, "void")
end

function DRAW_HUD_OVER_FADE_THIS_FRAME()
    Velora.invoke(0x9E5150, "void")
end

function ACTIVATE_FRONTEND_MENU(menuhash, togglePause, component)
    Velora.invoke(0x9E5160, "void", menuhash, togglePause, component)
end

function RESTART_FRONTEND_MENU(menuHash, p1)
    Velora.invoke(0x9E51B0, "void", menuHash, p1)
end

function GET_CURRENT_FRONTEND_MENU_VERSION(toggle)
    return Velora.invoke(0x9E5220, "int", toggle)
end

function DISABLE_FRONTEND_THIS_FRAME()
    Velora.invoke(0x9E5240, "void")
end

function SUPPRESS_FRONTEND_RENDERING_THIS_FRAME()
    Velora.invoke(0x9E5250, "void")
end

function ALLOW_PAUSE_WHEN_NOT_IN_STATE_OF_PLAY_THIS_FRAME()
    Velora.invoke(0x9E5260, "void")
end

function SET_FRONTEND_ACTIVE(active)
    Velora.invoke(0x9E5270, "void", active)
end

function IS_PAUSE_MENU_ACTIVE(p0)
    return Velora.invoke(0x9E5390, "bool", p0)
end

function PAUSE_MENUCEPTION_GO_DEEPER(page)
    Velora.invoke(0x9E53A0, "void", page)
end

function PAUSE_MENUCEPTION_THE_KICK()
    Velora.invoke(0x9E53B0, "void")
end

function PAUSE_TOGGLE_FULLSCREEN_MAP(p0)
    Velora.invoke(0x9E53C0, "void", p0)
end

function PAUSE_MENU_ACTIVATE_CONTEXT(contextHash)
    Velora.invoke(0x9E53E0, "void", contextHash)
end

function PAUSE_MENU_DEACTIVATE_CONTEXT(contextHash)
    Velora.invoke(0x9E5420, "void", contextHash)
end

function PAUSE_MENU_IS_CONTEXT_ACTIVE(invoke<BOOL>(0x9E5460, p0, p1, invoke<BOOL>(0x9E5590, p0)
    return Velora.invoke(0x9E55A0, "bool", invoke<BOOL>(0x9E5460, p0, p1, invoke<BOOL>(0x9E5590, p0)
end

function PAUSE_MENU_SET_BUSY_SPINNER(p0, position, spinnerIndex)
    Velora.invoke(0x9E55B0, "void", p0, position, spinnerIndex)
end

function PAUSE_MENU_SET_WARN_ON_TAB_CHANGE(p0)
    Velora.invoke(0x9E55F0, "void", p0)
end

function IS_FRONTEND_READY_FOR_CONTROL(TAKE_CONTROL_OF_FRONTEND()
    return Velora.invoke(0x9E5650, "bool", TAKE_CONTROL_OF_FRONTEND()
end

function RELEASE_CONTROL_OF_FRONTEND()
    Velora.invoke(0x9E5660, "void")
end

function CODE_WANTS_SCRIPT_TO_TAKE_CONTROL(p0)
    return Velora.invoke(0x9E56E0, "bool", p0)
end

function GET_MENU_TRIGGER_EVENT_DETAILS(lastItemMenuId, selectedItemUniqueId)
    Velora.invoke(0x9E56F0, "void", lastItemMenuId, selectedItemUniqueId)
end

function GET_MENU_LAYOUT_CHANGED_EVENT_DETAILS(lastItemMenuId, selectedItemMenuId, selectedItemUniqueId)
    Velora.invoke(0x9E5720, "void", lastItemMenuId, selectedItemMenuId, selectedItemUniqueId)
end

function GET_PM_PLAYER_CREW_COLOR(r, g, invoke<BOOL>(0x9E5770, p0, invoke<BOOL>(0x9E57F0, p0, p1, invoke<BOOL>(0x9E5820, statHash, outValue, mask, invoke<BOOL>(0x9E5850, statHash, outValue, p2, mask, invoke<BOOL>(0x9E58F0, statHash, invoke<BOOL>(0x9E5990, statHash, outValue, invoke<BOOL>(0x9E59C0, statHash, invoke<BOOL>(0x9E59F0, CLEAR_PED_IN_PAUSE_MENU()
    return Velora.invoke(0x9E5A20, "bool", r, g, invoke<BOOL>(0x9E5770, p0, invoke<BOOL>(0x9E57F0, p0, p1, invoke<BOOL>(0x9E5820, statHash, outValue, mask, invoke<BOOL>(0x9E5850, statHash, outValue, p2, mask, invoke<BOOL>(0x9E58F0, statHash, invoke<BOOL>(0x9E5990, statHash, outValue, invoke<BOOL>(0x9E59C0, statHash, invoke<BOOL>(0x9E59F0, CLEAR_PED_IN_PAUSE_MENU()
end

function GIVE_PED_TO_PAUSE_MENU(ped, p1)
    Velora.invoke(0x9E5A60, "void", ped, p1)
end

function SET_PAUSE_MENU_PED_LIGHTING(state)
    Velora.invoke(0x9E5A70, "void", state)
end

function SET_PAUSE_MENU_PED_SLEEP_STATE(state)
    Velora.invoke(0x9E5AD0, "void", state)
end

function OPEN_ONLINE_POLICIES_MENU()
    Velora.invoke(0x9E5B20, "void")
end

function ARE_ONLINE_POLICIES_UP_TO_DATE(OPEN_SOCIAL_CLUB_MENU()
    return Velora.invoke(0x9E5BA0, "bool", OPEN_SOCIAL_CLUB_MENU()
end

function CLOSE_SOCIAL_CLUB_MENU()
    Velora.invoke(0x9E5BE0, "void")
end

function SET_SOCIAL_CLUB_TOUR(name)
    Velora.invoke(0x9E5C00, "void", name)
end

function IS_SOCIAL_CLUB_ACTIVE(p0)
    return Velora.invoke(0x9E5C40, "bool", p0)
end

function FORCE_CLOSE_TEXT_INPUT_BOX()
    Velora.invoke(0x9E5C50, "void")
end

function SET_ALLOW_COMMA_ON_TEXT_INPUT(p0)
    Velora.invoke(0x9E5C60, "void", p0)
end

function OVERRIDE_MP_TEXT_CHAT_TEAM_STRING(gxtEntryHash)
    Velora.invoke(0x9E5C70, "void", gxtEntryHash)
end

function IS_MP_TEXT_CHAT_TYPING(CLOSE_MP_TEXT_CHAT()
    return Velora.invoke(0x9E5C90, "bool", CLOSE_MP_TEXT_CHAT()
end

function MP_TEXT_CHAT_IS_TEAM_JOB(p0)
    Velora.invoke(0x9E5CA0, "void", p0)
end

function OVERRIDE_MP_TEXT_CHAT_COLOR(p0, hudColor)
    Velora.invoke(0x9E5CB0, "void", p0, hudColor)
end

function MP_TEXT_CHAT_DISABLE(toggle)
    Velora.invoke(0x9E5CC0, "void", toggle)
end

function FLAG_PLAYER_CONTEXT_IN_TOURNAMENT(toggle)
    Velora.invoke(0x9E5CD0, "void", toggle)
end

function SET_PED_HAS_AI_BLIP(ped, hasCone)
    Velora.invoke(0x9E5CF0, "void", ped, hasCone)
end

function SET_PED_HAS_AI_BLIP_WITH_COLOUR(ped, hasCone, color)
    Velora.invoke(0x9E5D30, "void", ped, hasCone, color)
end

function DOES_PED_HAVE_AI_BLIP(invoke<BOOL>(0x9E5D70, ped, gangId)
    return Velora.invoke(0x9E5DA0, "bool", invoke<BOOL>(0x9E5D70, ped, gangId)
end

function SET_PED_AI_BLIP_HAS_CONE(ped, toggle)
    Velora.invoke(0x9E5DB0, "void", ped, toggle)
end

function SET_PED_AI_BLIP_FORCED_ON(ped, toggle)
    Velora.invoke(0x9E5DD0, "void", ped, toggle)
end

function SET_PED_AI_BLIP_NOTICE_RANGE(ped, range)
    Velora.invoke(0x9E5DF0, "void", ped, range)
end

function SET_PED_AI_BLIP_SPRITE(ped, spriteId)
    Velora.invoke(0x9E5E00, "void", ped, spriteId)
end

function GET_AI_PED_PED_BLIP_INDEX(invoke<Blip>(0x9E5E10, invoke<Blip>(0x9E5E30, SET_DIRECTOR_MODE_LAUNCHED_BY_SCRIPT()
    return Velora.invoke(0x9E5E60, "int", invoke<Blip>(0x9E5E10, invoke<Blip>(0x9E5E30, SET_DIRECTOR_MODE_LAUNCHED_BY_SCRIPT()
end

function SET_PLAYER_IS_IN_DIRECTOR_MODE(toggle)
    Velora.invoke(0x9E5E70, "void", toggle)
end

function SET_DIRECTOR_MODE_AVAILABLE(toggle)
    Velora.invoke(0x9E5E90, "void", toggle)
end

function HIDE_HUDMARKERS_THIS_FRAME()
    Velora.invoke(0x9E5EB0, "void")
end

function GET_INTERIOR_HEADING(invoke<float>(0x9E8060, interior, position, nameHash)
    return Velora.invoke(0x9E80B0, "float", invoke<float>(0x9E8060, interior, position, nameHash)
end

function GET_INTERIOR_GROUP_ID(invoke<int>(0x9E8190, interior, x, y, invoke<Vector3>(0x9E81E0, invoke<BOOL>(0x9E82D0, entity)
    return Velora.invoke(0x9E82F0, "int", invoke<int>(0x9E8190, interior, x, y, invoke<Vector3>(0x9E81E0, invoke<BOOL>(0x9E82D0, entity)
end

function FORCE_ROOM_FOR_ENTITY(entity, interior, roomHashKey)
    Velora.invoke(0x9E8380, "void", entity, interior, roomHashKey)
end

function GET_ROOM_KEY_FROM_ENTITY(invoke<Hash>(0x9E83A0, invoke<Hash>(0x9E83C0, invoke<Interior>(0x9E8450, entity, interior)
    return Velora.invoke(0x9E8470, "int", invoke<Hash>(0x9E83A0, invoke<Hash>(0x9E83C0, invoke<Interior>(0x9E8450, entity, interior)
end

function CLEAR_INTERIOR_STATE_OF_ENTITY(entity)
    Velora.invoke(0x9E84E0, "void", entity)
end

function FORCE_ACTIVATING_TRACKING_ON_ENTITY(p0, p1)
    Velora.invoke(0x9E8530, "void", p0, p1)
end

function FORCE_ROOM_FOR_GAME_VIEWPORT(interiorID, roomHashKey)
    Velora.invoke(0x9E8590, "void", interiorID, roomHashKey)
end

function SET_ROOM_FOR_GAME_VIEWPORT_BY_NAME(roomName)
    Velora.invoke(0x9E85A0, "void", roomName)
end

function SET_ROOM_FOR_GAME_VIEWPORT_BY_KEY(roomHashKey)
    Velora.invoke(0x9E85B0, "void", roomHashKey)
end

function GET_ROOM_KEY_FOR_GAME_VIEWPORT(CLEAR_ROOM_FOR_GAME_VIEWPORT()
    return Velora.invoke(0x9E8740, "int", CLEAR_ROOM_FOR_GAME_VIEWPORT()
end

function GET_INTERIOR_FROM_PRIMARY_VIEW(x, y, invoke<Interior>(0x9E8830, pickup, roomName)
    return Velora.invoke(0x9E88A0, "int", x, y, invoke<Interior>(0x9E8830, pickup, roomName)
end

function PIN_INTERIOR_IN_MEMORY(interior)
    Velora.invoke(0x9E88F0, "void", interior)
end

function UNPIN_INTERIOR(interior)
    Velora.invoke(0x9E8960, "void", interior)
end

function IS_INTERIOR_READY(invoke<BOOL>(0x9E89A0, invoke<BOOL>(0x9E8A00, x, y, z, invoke<Interior>(0x9E8A50, x, y, z, invoke<Interior>(0x9E8AF0, ACTIVATE_INTERIOR_GROUPS_USING_CAMERA()
    return Velora.invoke(0x9E8B60, "bool", invoke<BOOL>(0x9E89A0, invoke<BOOL>(0x9E8A00, x, y, z, invoke<Interior>(0x9E8A50, x, y, z, invoke<Interior>(0x9E8AF0, ACTIVATE_INTERIOR_GROUPS_USING_CAMERA()
end

function IS_COLLISION_MARKED_OUTSIDE(x, y, invoke<BOOL>(0x9E8B70, x, y, invoke<Interior>(0x9E8C00, toggle)
    return Velora.invoke(0x9E8CB0, "bool", x, y, invoke<BOOL>(0x9E8B70, x, y, invoke<Interior>(0x9E8C00, toggle)
end

function ACTIVATE_INTERIOR_ENTITY_SET(interior, entitySetName)
    Velora.invoke(0x9E8CE0, "void", interior, entitySetName)
end

function DEACTIVATE_INTERIOR_ENTITY_SET(interior, entitySetName)
    Velora.invoke(0x9E8D70, "void", interior, entitySetName)
end

function IS_INTERIOR_ENTITY_SET_ACTIVE(interior, invoke<BOOL>(0x9E8E00, interior, entitySetName, color)
    return Velora.invoke(0x9E8EB0, "bool", interior, invoke<BOOL>(0x9E8E00, interior, entitySetName, color)
end

function REFRESH_INTERIOR(interior)
    Velora.invoke(0x9E8F50, "void", interior)
end

function ENABLE_EXTERIOR_CULL_MODEL_THIS_FRAME(mapObjectHash)
    Velora.invoke(0x9E8FC0, "void", mapObjectHash)
end

function ENABLE_SHADOW_CULL_MODEL_THIS_FRAME(mapObjectHash)
    Velora.invoke(0x9E8FF0, "void", mapObjectHash)
end

function DISABLE_INTERIOR(interior, toggle)
    Velora.invoke(0x9E9020, "void", interior, toggle)
end

function IS_INTERIOR_DISABLED(invoke<BOOL>(0x9E90C0, interior, toggle)
    return Velora.invoke(0x9E9110, "bool", invoke<BOOL>(0x9E90C0, interior, toggle)
end

function IS_INTERIOR_CAPPED(invoke<BOOL>(0x9E91B0, toggle)
    return Velora.invoke(0x9E9200, "bool", invoke<BOOL>(0x9E91B0, toggle)
end

function SET_IS_EXTERIOR_ONLY(entity, toggle)
    Velora.invoke(0x9E9220, "void", entity, toggle)
end

function CREATE_ITEMSET(invoke<ScrHandle>(0x9E9630, itemset)
    return Velora.invoke(0x9E96B0, "int", invoke<ScrHandle>(0x9E9630, itemset)
end

function IS_ITEMSET_VALID(invoke<BOOL>(0x9E96F0, item, invoke<BOOL>(0x9E9730, item, itemset)
    return Velora.invoke(0x9E97A0, "bool", invoke<BOOL>(0x9E96F0, item, invoke<BOOL>(0x9E9730, item, itemset)
end

function GET_ITEMSET_SIZE(invoke<int>(0x9E9800, index, invoke<ScrHandle>(0x9E9850, item, invoke<BOOL>(0x9E98B0, itemset)
    return Velora.invoke(0x9E9920, "int", invoke<int>(0x9E9800, index, invoke<ScrHandle>(0x9E9850, item, invoke<BOOL>(0x9E98B0, itemset)
end

function LOBBY_AUTO_MULTIPLAYER_MENU(toggle)
    return Velora.invoke(0x9E9C00, "bool", toggle)
end

function LOBBY_AUTO_MULTIPLAYER_EVENT(toggle)
    return Velora.invoke(0x9E9C40, "bool", toggle)
end

function LOBBY_AUTO_MULTIPLAYER_RANDOM_JOB(toggle)
    return Velora.invoke(0x9E9C80, "bool", toggle)
end

function SHUTDOWN_SESSION_CLEARS_AUTO_MULTIPLAYER(toggle)
    Velora.invoke(0x9E9CA0, "void", toggle)
end

function LOCALIZATION_GET_SYSTEM_LANGUAGE(invoke<int>(0x9F5770, seed)
    return Velora.invoke(0x9F5790, "int", invoke<int>(0x9F5770, seed)
end

function SET_TIME_SCALE(timeScale)
    Velora.invoke(0x9F57C0, "void", timeScale)
end

function SET_MISSION_FLAG(toggle)
    Velora.invoke(0x9F5800, "void", toggle)
end

function GET_MISSION_FLAG(toggle)
    return Velora.invoke(0x9F5870, "bool", toggle)
end

function GET_RANDOM_EVENT_FLAG(p0, p1)
    return Velora.invoke(0x9F5970, "bool", p0, p1)
end

function ACTIVITY_FEED_ADD_SUBSTRING_TO_CAPTION(p0)
    Velora.invoke(0x9F5980, "void", p0)
end

function ACTIVITY_FEED_ADD_LITERAL_SUBSTRING_TO_CAPTION(p0)
    Velora.invoke(0x9F5990, "void", p0)
end

function ACTIVITY_FEED_ADD_INT_TO_CAPTION(p0)
    Velora.invoke(0x9F59A0, "void", p0)
end

function ACTIVITY_FEED_LARGE_IMAGE_URL(p0)
    Velora.invoke(0x9F59C0, "void", p0)
end

function ACTIVITY_FEED_ACTION_START_WITH_COMMAND_LINE(p0, p1)
    Velora.invoke(0x9F59E0, "void", p0, p1)
end

function ACTIVITY_FEED_ACTION_START_WITH_COMMAND_LINE_ADD(p0)
    Velora.invoke(0x9F59F0, "void", p0)
end

function ACTIVITY_FEED_POST()
    Velora.invoke(0x9F5A10, "void")
end

function ACTIVITY_FEED_ONLINE_PLAYED_WITH_POST(p0)
    Velora.invoke(0x9F5A30, "void", p0)
end

function HAS_RESUMED_FROM_SUSPEND(toggle)
    return Velora.invoke(0x9F5A70, "bool", toggle)
end

function SET_THIS_IS_A_TRIGGER_SCRIPT(toggle)
    Velora.invoke(0x9F5AA0, "void", toggle)
end

function INFORM_CODE_OF_CONTENT_ID_OF_CURRENT_UGC_MISSION(p0)
    Velora.invoke(0x9F5AD0, "void", p0)
end

function GET_BASE_ELEMENT_LOCATION_FROM_METADATA_BLOCK(p0, p1, p2, invoke<BOOL>(0x9F5AE0, invoke<BOOL>(0x9F5BC0, invoke<BOOL>(0x9F5C10, weatherType)
    return Velora.invoke(0x9F5C60, "bool", p0, p1, p2, invoke<BOOL>(0x9F5AE0, invoke<BOOL>(0x9F5BC0, invoke<BOOL>(0x9F5C10, weatherType)
end

function SET_WEATHER_TYPE_NOW_PERSIST(weatherType)
    Velora.invoke(0x9F5CB0, "void", weatherType)
end

function SET_WEATHER_TYPE_NOW(weatherType)
    Velora.invoke(0x9F5D00, "void", weatherType)
end

function SET_WEATHER_TYPE_OVERTIME_PERSIST(weatherType, time)
    Velora.invoke(0x9F5D50, "void", weatherType, time)
end

function SET_RANDOM_WEATHER_TYPE()
    Velora.invoke(0x9F5DA0, "void")
end

function CLEAR_WEATHER_TYPE_PERSIST()
    Velora.invoke(0x9F5DC0, "void")
end

function CLEAR_WEATHER_TYPE_NOW_PERSIST_NETWORK(milliseconds)
    Velora.invoke(0x9F5DD0, "void", milliseconds)
end

function GET_CURR_WEATHER_STATE(weatherType1, weatherType2, percentWeather2)
    Velora.invoke(0x9F5E00, "void", weatherType1, weatherType2, percentWeather2)
end

function SET_CURR_WEATHER_STATE(weatherType1, weatherType2, percentWeather2)
    Velora.invoke(0x9F5E50, "void", weatherType1, weatherType2, percentWeather2)
end

function SET_OVERRIDE_WEATHER(weatherType)
    Velora.invoke(0x9F5EE0, "void", weatherType)
end

function SET_OVERRIDE_WEATHEREX(weatherType, p1)
    Velora.invoke(0x9F5F30, "void", weatherType, p1)
end

function CLEAR_OVERRIDE_WEATHER()
    Velora.invoke(0x9F5F80, "void")
end

function WATER_OVERRIDE_SET_SHOREWAVEAMPLITUDE(amplitude)
    Velora.invoke(0x9F5F90, "void", amplitude)
end

function WATER_OVERRIDE_SET_SHOREWAVEMINAMPLITUDE(minAmplitude)
    Velora.invoke(0x9F5FB0, "void", minAmplitude)
end

function WATER_OVERRIDE_SET_SHOREWAVEMAXAMPLITUDE(maxAmplitude)
    Velora.invoke(0x9F5FD0, "void", maxAmplitude)
end

function WATER_OVERRIDE_SET_OCEANNOISEMINAMPLITUDE(minAmplitude)
    Velora.invoke(0x9F5FF0, "void", minAmplitude)
end

function WATER_OVERRIDE_SET_OCEANWAVEAMPLITUDE(amplitude)
    Velora.invoke(0x9F6010, "void", amplitude)
end

function WATER_OVERRIDE_SET_OCEANWAVEMINAMPLITUDE(minAmplitude)
    Velora.invoke(0x9F6030, "void", minAmplitude)
end

function WATER_OVERRIDE_SET_OCEANWAVEMAXAMPLITUDE(maxAmplitude)
    Velora.invoke(0x9F6050, "void", maxAmplitude)
end

function WATER_OVERRIDE_SET_RIPPLEBUMPINESS(bumpiness)
    Velora.invoke(0x9F6070, "void", bumpiness)
end

function WATER_OVERRIDE_SET_RIPPLEMINBUMPINESS(minBumpiness)
    Velora.invoke(0x9F6090, "void", minBumpiness)
end

function WATER_OVERRIDE_SET_RIPPLEMAXBUMPINESS(maxBumpiness)
    Velora.invoke(0x9F60B0, "void", maxBumpiness)
end

function WATER_OVERRIDE_SET_RIPPLEDISTURB(disturb)
    Velora.invoke(0x9F60D0, "void", disturb)
end

function WATER_OVERRIDE_SET_STRENGTH(strength)
    Velora.invoke(0x9F60F0, "void", strength)
end

function WATER_OVERRIDE_FADE_IN(p0)
    Velora.invoke(0x9F6110, "void", p0)
end

function WATER_OVERRIDE_FADE_OUT(p0)
    Velora.invoke(0x9F6130, "void", p0)
end

function SET_WIND(speed)
    Velora.invoke(0x9F6150, "void", speed)
end

function SET_WIND_SPEED(speed)
    Velora.invoke(0x9F6170, "void", speed)
end

function GET_WIND_SPEED(direction)
    return Velora.invoke(0x9F61C0, "float", direction)
end

function GET_WIND_DIRECTION(intensity)
    local x, y, z = Velora.invoke(0x9F6250, "vector3", intensity)
    return {x = x, y = y, z = z}
end

function GET_RAIN_LEVEL(level)
    return Velora.invoke(0x9F6290, "float", level)
end

function GET_SNOW_LEVEL(FORCE_LIGHTNING_FLASH()
    return Velora.invoke(0x9F62D0, "float", FORCE_LIGHTNING_FLASH()
end

function SET_CLOUD_SETTINGS_OVERRIDE(p0)
    Velora.invoke(0x9F62E0, "void", p0)
end

function PRELOAD_CLOUD_HAT(name)
    Velora.invoke(0x9F6330, "void", name)
end

function LOAD_CLOUD_HAT(name, transitionTime)
    Velora.invoke(0x9F6350, "void", name, transitionTime)
end

function UNLOAD_CLOUD_HAT(name, p1)
    Velora.invoke(0x9F6370, "void", name, p1)
end

function UNLOAD_ALL_CLOUD_HATS()
    Velora.invoke(0x9F6390, "void")
end

function SET_CLOUDS_ALPHA(opacity)
    Velora.invoke(0x9F63A0, "void", opacity)
end

function GET_CLOUDS_ALPHA(startRange, invoke<float>(0x9F6440, startRange, invoke<int>(0x9F64A0, startRange, invoke<int>(0x9F64F0, x, y, z, groundZ, ignoreWater, invoke<BOOL>(0x9F65A0, x, y, z, groundZ, invoke<BOOL>(0x9F65E0, x, y, z, groundZ, p4, invoke<BOOL>(0x9F66E0, invoke<float>(0x9F6720, invoke<float>(0x9F6770, invoke<float>(0x9F67C0, invoke<float>(0x9F67F0, p0, invoke<float>(0x9F6830, x1, y1, z1, x2, y2, z2, invoke<float>(0x9F6870, x1, y1, x2, invoke<float>(0x9F68D0, dx, invoke<float>(0x9F6990, x1, y1, z1, x2, y2, z2, x3, y3, z3, invoke<float>(0x9F6A10, x1, y1, z1, x2, y2, z2, x3, y3, z3, invoke<Vector3>(0x9F6B30, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, invoke<BOOL>(0x9F6C80, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, invoke<BOOL>(0x9F6D60, address, offset)
    return Velora.invoke(0x9F6DA0, "float", startRange, invoke<float>(0x9F6440, startRange, invoke<int>(0x9F64A0, startRange, invoke<int>(0x9F64F0, x, y, z, groundZ, ignoreWater, invoke<BOOL>(0x9F65A0, x, y, z, groundZ, invoke<BOOL>(0x9F65E0, x, y, z, groundZ, p4, invoke<BOOL>(0x9F66E0, invoke<float>(0x9F6720, invoke<float>(0x9F6770, invoke<float>(0x9F67C0, invoke<float>(0x9F67F0, p0, invoke<float>(0x9F6830, x1, y1, z1, x2, y2, z2, invoke<float>(0x9F6870, x1, y1, x2, invoke<float>(0x9F68D0, dx, invoke<float>(0x9F6990, x1, y1, z1, x2, y2, z2, x3, y3, z3, invoke<float>(0x9F6A10, x1, y1, z1, x2, y2, z2, x3, y3, z3, invoke<Vector3>(0x9F6B30, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, invoke<BOOL>(0x9F6C80, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, invoke<BOOL>(0x9F6D60, address, offset)
end

function CLEAR_BIT(address, offset)
    Velora.invoke(0x9F6DC0, "void", address, offset)
end

function GET_HASH_KEY(invoke<Hash>(0x9F6DE0, t, x, y, z, w, x1, y1, z1, w1, outX, outY, outZ, outW)
    return Velora.invoke(0x9F6E10, "int", invoke<Hash>(0x9F6DE0, t, x, y, z, w, x1, y1, z1, w1, outX, outY, outZ, outW)
end

function IS_AREA_OCCUPIED(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, invoke<BOOL>(0x9F6E70, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, invoke<BOOL>(0x9F7050, x, y, z, range, p4, checkVehicles, checkPeds, p7, p8, ignoreEntity, invoke<BOOL>(0x9F7230, p0, p1, p2, p3, p4, p5, invoke<BOOL>(0x9F72B0, X, Y, Z, radius, p4, ignoreCopCars, ignoreObjects, p7)
    return Velora.invoke(0x9F7450, "bool", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, invoke<BOOL>(0x9F6E70, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, invoke<BOOL>(0x9F7050, x, y, z, range, p4, checkVehicles, checkPeds, p7, p8, ignoreEntity, invoke<BOOL>(0x9F7230, p0, p1, p2, p3, p4, p5, invoke<BOOL>(0x9F72B0, X, Y, Z, radius, p4, ignoreCopCars, ignoreObjects, p7)
end

function CLEAR_AREA_LEAVE_VEHICLE_HEALTH(x, y, z, radius, p4, p5, p6, p7)
    Velora.invoke(0x9F7490, "void", x, y, z, radius, p4, p5, p6, p7)
end

function CLEAR_AREA_OF_VEHICLES(x, y, z, radius, p4, p5, p6, p7, p8, p9, p10)
    Velora.invoke(0x9F74D0, "void", x, y, z, radius, p4, p5, p6, p7, p8, p9, p10)
end

function CLEAR_ANGLED_AREA_OF_VEHICLES(x1, y1, z1, x2, y2, z2, width, p7, p8, p9, p10, p11, p12, p13)
    Velora.invoke(0x9F7550, "void", x1, y1, z1, x2, y2, z2, width, p7, p8, p9, p10, p11, p12, p13)
end

function CLEAR_AREA_OF_OBJECTS(x, y, z, radius, flags)
    Velora.invoke(0x9F7630, "void", x, y, z, radius, flags)
end

function CLEAR_AREA_OF_PEDS(x, y, z, radius, flags)
    Velora.invoke(0x9F7650, "void", x, y, z, radius, flags)
end

function CLEAR_AREA_OF_COPS(x, y, z, radius, flags)
    Velora.invoke(0x9F7670, "void", x, y, z, radius, flags)
end

function CLEAR_AREA_OF_PROJECTILES(x, y, z, radius, flags)
    Velora.invoke(0x9F7690, "void", x, y, z, radius, flags)
end

function CLEAR_SCENARIO_SPAWN_HISTORY()
    Velora.invoke(0x9F76B0, "void")
end

function SET_SAVE_MENU_ACTIVE(ignoreVehicle)
    Velora.invoke(0x9F76C0, "void", ignoreVehicle)
end

function GET_STATUS_OF_MANUAL_SAVE(toggle)
    return Velora.invoke(0x9F77B0, "int", toggle)
end

function SET_CREDITS_FADE_OUT_WITH_SCREEN(toggle)
    Velora.invoke(0x9F77D0, "void", toggle)
end

function HAVE_CREDITS_REACHED_END(scriptName)
    return Velora.invoke(0x9F7810, "bool", scriptName)
end

function NETWORK_SET_SCRIPT_IS_SAFE_FOR_NETWORK_GAME()
    Velora.invoke(0x9F7850, "void")
end

function ADD_HOSPITAL_RESTART(x, y, z, p3, invoke<int>(0x9F7870, hospitalIndex, toggle)
    return Velora.invoke(0x9F79D0, "int", x, y, z, p3, invoke<int>(0x9F7870, hospitalIndex, toggle)
end

function ADD_POLICE_RESTART(p0, p1, p2, p3, invoke<int>(0x9F79F0, policeIndex, toggle)
    return Velora.invoke(0x9F7B50, "int", p0, p1, p2, p3, invoke<int>(0x9F79F0, policeIndex, toggle)
end

function SET_RESTART_COORD_OVERRIDE(x, y, z, heading)
    Velora.invoke(0x9F7B70, "void", x, y, z, heading)
end

function CLEAR_RESTART_COORD_OVERRIDE()
    Velora.invoke(0x9F7C90, "void")
end

function PAUSE_DEATH_ARREST_RESTART(toggle)
    Velora.invoke(0x9F7CA0, "void", toggle)
end

function IGNORE_NEXT_RESTART(toggle)
    Velora.invoke(0x9F7CC0, "void", toggle)
end

function SET_FADE_OUT_AFTER_DEATH(toggle)
    Velora.invoke(0x9F7CE0, "void", toggle)
end

function SET_FADE_OUT_AFTER_ARREST(toggle)
    Velora.invoke(0x9F7D00, "void", toggle)
end

function SET_FADE_IN_AFTER_DEATH_ARREST(toggle)
    Velora.invoke(0x9F7D20, "void", toggle)
end

function SET_FADE_IN_AFTER_LOAD(toggle)
    Velora.invoke(0x9F7D40, "void", toggle)
end

function REGISTER_SAVE_HOUSE(x, y, z, p3, p4, p5, invoke<int>(0x9F7D60, savehouseHandle, p1, p2)
    return Velora.invoke(0x9F7DE0, "int", x, y, z, p3, p4, p5, invoke<int>(0x9F7D60, savehouseHandle, p1, p2)
end

function OVERRIDE_SAVE_HOUSE(p0, p1, p2, p3, p4, p5, p6, invoke<BOOL>(0x9F7E00, p0, p1, fadeInAfterLoad, invoke<BOOL>(0x9F7EE0, DO_AUTO_SAVE()
    return Velora.invoke(0x9F7FB0, "bool", p0, p1, p2, p3, p4, p5, p6, invoke<BOOL>(0x9F7E00, p0, p1, fadeInAfterLoad, invoke<BOOL>(0x9F7EE0, DO_AUTO_SAVE()
end

function GET_IS_AUTO_SAVE_OFF(CLEAR_CODE_REQUESTED_AUTOSAVE()
    return Velora.invoke(0x9F8090, "bool", CLEAR_CODE_REQUESTED_AUTOSAVE()
end

function BEGIN_REPLAY_STATS(p0, p1)
    Velora.invoke(0x9F80A0, "void", p0, p1)
end

function ADD_REPLAY_STAT_VALUE(value)
    Velora.invoke(0x9F80C0, "void", value)
end

function END_REPLAY_STATS()
    Velora.invoke(0x9F80E0, "void")
end

function HAVE_REPLAY_STATS_BEEN_STORED(invoke<int>(0x9F8150, CLEAR_REPLAY_STATS()
    return Velora.invoke(0x9F8180, "bool", invoke<int>(0x9F8150, CLEAR_REPLAY_STATS()
end

function QUEUE_MISSION_REPEAT_LOAD(x1, y1, z1, x2, y2, z2, damage, p7, weaponHash, ownerPed, isAudible, isInvisible, speed)
    return Velora.invoke(0x9F8240, "bool", x1, y1, z1, x2, y2, z2, damage, p7, weaponHash, ownerPed, isAudible, isInvisible, speed)
end

function SHOOT_SINGLE_BULLET_BETWEEN_COORDS_IGNORE_ENTITY(x1, y1, z1, x2, y2, z2, damage, p7, weaponHash, ownerPed, isAudible, isInvisible, speed, entity, p14)
    Velora.invoke(0x9F82E0, "void", x1, y1, z1, x2, y2, z2, damage, p7, weaponHash, ownerPed, isAudible, isInvisible, speed, entity, p14)
end

function SHOOT_SINGLE_BULLET_BETWEEN_COORDS_IGNORE_ENTITY_NEW(x1, y1, z1, x2, y2, z2, damage, p7, weaponHash, ownerPed, isAudible, isInvisible, speed, entity, p14, p15, targetEntity, p17, p18, p19, p20)
    Velora.invoke(0x9F8380, "void", x1, y1, z1, x2, y2, z2, damage, p7, weaponHash, ownerPed, isAudible, isInvisible, speed, entity, p14, p15, targetEntity, p17, p18, p19, p20)
end

function GET_MODEL_DIMENSIONS(modelHash, minimum, maximum)
    Velora.invoke(0x9F8480, "void", modelHash, minimum, maximum)
end

function SET_FAKE_WANTED_LEVEL(fakeWantedLevel)
    Velora.invoke(0x9F8500, "void", fakeWantedLevel)
end

function GET_FAKE_WANTED_LEVEL(toggle)
    return Velora.invoke(0x9F85B0, "int", toggle)
end

function ALLOW_MISSION_CREATOR_WARP(toggle)
    Velora.invoke(0x9F85E0, "void", toggle)
end

function SET_MINIGAME_IN_PROGRESS(toggle)
    Velora.invoke(0x9F8630, "void", toggle)
end

function IS_MINIGAME_IN_PROGRESS(invoke<int>(0x9F86E0, string1, invoke<BOOL>(0x9F8710, str1, str2, matchCase, invoke<int>(0x9F8750, invoke<int>(0x9F87A0, invoke<float>(0x9F87C0, x1, y1, z1, x2, y2, invoke<BOOL>(0x9F87F0, x1, y1, z1, x2, y2, z2, invoke<BOOL>(0x9F88B0, x1, y1, z1, x2, y2, z2, type, invoke<BOOL>(0x9F89B0, x1, y1, z1, x2, y2, z2, width, p7, invoke<BOOL>(0x9F8A10, x, y, z, projectileHash, radius, invoke<BOOL>(0x9F8A70, x1, y1, z1, x2, y2, z2, projectileHash, projectilePos, invoke<BOOL>(0x9F8AB0, vecAngledAreaPoint1X, vecAngledAreaPoint1Y, vecAngledAreaPoint1Z, vecAngledAreaPoint2X, vecAngledAreaPoint2Y, vecAngledAreaPoint2Z, distanceOfOppositeFace, weaponType, positionOut, invoke<BOOL>(0x9F8B40, ped, weaponHash, distance, outCoords, invoke<BOOL>(0x9F8BE0, ped, weaponHash, distance, outCoords, outProjectile, invoke<BOOL>(0x9F8C90, x1, y1, z1, x2, y2, z2, width, invoke<BOOL>(0x9F8D40, x, y, z, radius, invoke<BOOL>(0x9F8E00, x1, y1, z1, x2, y2, z2, invoke<BOOL>(0x9F8EA0, x, y, z, p3, p4, invoke<BOOL>(0x9F8F90, p0, p1, p2, p3, p4, p5, p6, invoke<BOOL>(0x9F9030, invoke<BOOL>(0x9F9200, invoke<BOOL>(0x9F9220, string, invoke<BOOL>(0x9F9240, var, rangeStart, rangeEnd, p3)
    return Velora.invoke(0x9F92E0, "bool", invoke<int>(0x9F86E0, string1, invoke<BOOL>(0x9F8710, str1, str2, matchCase, invoke<int>(0x9F8750, invoke<int>(0x9F87A0, invoke<float>(0x9F87C0, x1, y1, z1, x2, y2, invoke<BOOL>(0x9F87F0, x1, y1, z1, x2, y2, z2, invoke<BOOL>(0x9F88B0, x1, y1, z1, x2, y2, z2, type, invoke<BOOL>(0x9F89B0, x1, y1, z1, x2, y2, z2, width, p7, invoke<BOOL>(0x9F8A10, x, y, z, projectileHash, radius, invoke<BOOL>(0x9F8A70, x1, y1, z1, x2, y2, z2, projectileHash, projectilePos, invoke<BOOL>(0x9F8AB0, vecAngledAreaPoint1X, vecAngledAreaPoint1Y, vecAngledAreaPoint1Z, vecAngledAreaPoint2X, vecAngledAreaPoint2Y, vecAngledAreaPoint2Z, distanceOfOppositeFace, weaponType, positionOut, invoke<BOOL>(0x9F8B40, ped, weaponHash, distance, outCoords, invoke<BOOL>(0x9F8BE0, ped, weaponHash, distance, outCoords, outProjectile, invoke<BOOL>(0x9F8C90, x1, y1, z1, x2, y2, z2, width, invoke<BOOL>(0x9F8D40, x, y, z, radius, invoke<BOOL>(0x9F8E00, x1, y1, z1, x2, y2, z2, invoke<BOOL>(0x9F8EA0, x, y, z, p3, p4, invoke<BOOL>(0x9F8F90, p0, p1, p2, p3, p4, p5, p6, invoke<BOOL>(0x9F9030, invoke<BOOL>(0x9F9200, invoke<BOOL>(0x9F9220, string, invoke<BOOL>(0x9F9240, var, rangeStart, rangeEnd, p3)
end

function GET_BITS_IN_RANGE(var, rangeStart, invoke<int>(0x9F9330, x1, y1, z1, x2, y2, z2, x3, y3, z3, x4, y4, z4, camX, camY, camZ, p15, p16, invoke<int>(0x9F9370, x1, y1, z1, x2, y2, z2, radius1, x3, y3, z3, x4, y4, z4, radius2, camX, camY, camZ, p17, p18, invoke<int>(0x9F9450, toggle)
    return Velora.invoke(0x9F9540, "int", var, rangeStart, invoke<int>(0x9F9330, x1, y1, z1, x2, y2, z2, x3, y3, z3, x4, y4, z4, camX, camY, camZ, p15, p16, invoke<int>(0x9F9370, x1, y1, z1, x2, y2, z2, radius1, x3, y3, z3, x4, y4, z4, radius2, camX, camY, camZ, p17, p18, invoke<int>(0x9F9450, toggle)
end

function DELETE_STUNT_JUMP(p0)
    Velora.invoke(0x9F9560, "void", p0)
end

function ENABLE_STUNT_JUMP_SET(p0)
    Velora.invoke(0x9F9580, "void", p0)
end

function DISABLE_STUNT_JUMP_SET(p0)
    Velora.invoke(0x9F95A0, "void", p0)
end

function SET_STUNT_JUMPS_CAN_TRIGGER(toggle)
    Velora.invoke(0x9F95C0, "void", toggle)
end

function IS_STUNT_JUMP_IN_PROGRESS(CANCEL_STUNT_JUMP()
    return Velora.invoke(0x9F96B0, "bool", CANCEL_STUNT_JUMP()
end

function SET_GAME_PAUSED(toggle)
    Velora.invoke(0x9F96D0, "void", toggle)
end

function SET_THIS_SCRIPT_CAN_BE_PAUSED(toggle)
    Velora.invoke(0x9F9700, "void", toggle)
end

function SET_THIS_SCRIPT_CAN_REMOVE_BLIPS_CREATED_BY_ANY_SCRIPT(toggle)
    Velora.invoke(0x9F9730, "void", toggle)
end

function HAS_CHEAT_WITH_HASH_BEEN_ACTIVATED(hash, invoke<BOOL>(0x9F9760, invoke<BOOL>(0x9F9790, p0)
    return Velora.invoke(0x9F97A0, "bool", hash, invoke<BOOL>(0x9F9760, invoke<BOOL>(0x9F9790, p0)
end

function SET_INSTANCE_PRIORITY_MODE(p0)
    Velora.invoke(0x9F97C0, "void", p0)
end

function SET_INSTANCE_PRIORITY_HINT(flag)
    Velora.invoke(0x9F97D0, "void", flag)
end

function IS_FRONTEND_FADING(POPULATE_NOW()
    return Velora.invoke(0x9F97F0, "bool", POPULATE_NOW()
end

function GET_INDEX_OF_CURRENT_LEVEL(level)
    return Velora.invoke(0x9F9830, "int", level)
end

function START_SAVE_DATA(p0, p1, p2)
    Velora.invoke(0x9F9850, "void", p0, p1, p2)
end

function STOP_SAVE_DATA()
    Velora.invoke(0x9F9890, "void")
end

function GET_SIZE_OF_SAVE_DATA(invoke<int>(0x9F98B0, p0, name)
    return Velora.invoke(0x9F98E0, "int", invoke<int>(0x9F98B0, p0, name)
end

function REGISTER_INT64_TO_SAVE(p0, name)
    Velora.invoke(0x9F9910, "void", p0, name)
end

function REGISTER_ENUM_TO_SAVE(p0, name)
    Velora.invoke(0x9F9940, "void", p0, name)
end

function REGISTER_FLOAT_TO_SAVE(p0, name)
    Velora.invoke(0x9F9970, "void", p0, name)
end

function REGISTER_BOOL_TO_SAVE(p0, name)
    Velora.invoke(0x9F99A0, "void", p0, name)
end

function REGISTER_TEXT_LABEL_TO_SAVE(p0, name)
    Velora.invoke(0x9F99D0, "void", p0, name)
end

function REGISTER_TEXT_LABEL_15_TO_SAVE(p0, name)
    Velora.invoke(0x9F9A00, "void", p0, name)
end

function REGISTER_TEXT_LABEL_23_TO_SAVE(p0, name)
    Velora.invoke(0x9F9A30, "void", p0, name)
end

function REGISTER_TEXT_LABEL_31_TO_SAVE(p0, name)
    Velora.invoke(0x9F9A60, "void", p0, name)
end

function REGISTER_TEXT_LABEL_63_TO_SAVE(p0, name)
    Velora.invoke(0x9F9A90, "void", p0, name)
end

function START_SAVE_STRUCT_WITH_SIZE(p0, size, structName)
    Velora.invoke(0x9F9AC0, "void", p0, size, structName)
end

function STOP_SAVE_STRUCT()
    Velora.invoke(0x9F9B00, "void")
end

function START_SAVE_ARRAY_WITH_SIZE(p0, size, arrayName)
    Velora.invoke(0x9F9B20, "void", p0, size, arrayName)
end

function STOP_SAVE_ARRAY()
    Velora.invoke(0x9F9B60, "void")
end

function COPY_SCRIPT_STRUCT(dst, src, size)
    Velora.invoke(0x9F9B80, "void", dst, src, size)
end

function ENABLE_DISPATCH_SERVICE(dispatchService, toggle)
    Velora.invoke(0x9F9BA0, "void", dispatchService, toggle)
end

function BLOCK_DISPATCH_SERVICE_RESOURCE_CREATION(dispatchService, toggle)
    Velora.invoke(0x9F9BD0, "void", dispatchService, toggle)
end

function GET_NUMBER_RESOURCES_ALLOCATED_TO_WANTED_LEVEL(invoke<int>(0x9F9C00, dispatchService, x, y, z, numUnits, radius, outIncidentID, p7, invoke<BOOL>(0x9F9C50, dispatchService, ped, numUnits, radius, outIncidentID, p5, invoke<BOOL>(0x9F9C90, incidentId)
    return Velora.invoke(0x9F9CD0, "int", invoke<int>(0x9F9C00, dispatchService, x, y, z, numUnits, radius, outIncidentID, p7, invoke<BOOL>(0x9F9C50, dispatchService, ped, numUnits, radius, outIncidentID, p5, invoke<BOOL>(0x9F9C90, incidentId)
end

function IS_INCIDENT_VALID(invoke<BOOL>(0x9F9D10, incidentId, dispatchService, numUnits)
    return Velora.invoke(0x9F9D50, "bool", invoke<BOOL>(0x9F9D10, incidentId, dispatchService, numUnits)
end

function SET_IDEAL_SPAWN_DISTANCE_FOR_INCIDENT(incidentId, p1)
    Velora.invoke(0x9F9DC0, "void", incidentId, p1)
end

function FIND_SPAWN_POINT_IN_DIRECTION(posX, posY, posZ, fwdVecX, fwdVecY, fwdVecZ, distance, invoke<BOOL>(0x9F9E20, x1, y1, z1, x2, y2, z2, p6, p7, p8, invoke<int>(0x9F9ED0, invoke<BOOL>(0x9F9F90, id, p1)
    return Velora.invoke(0x9F9FD0, "bool", posX, posY, posZ, fwdVecX, fwdVecY, fwdVecZ, distance, invoke<BOOL>(0x9F9E20, x1, y1, z1, x2, y2, z2, p6, p7, p8, invoke<int>(0x9F9ED0, invoke<BOOL>(0x9F9F90, id, p1)
end

function IS_POP_MULTIPLIER_AREA_NETWORKED(invoke<BOOL>(0x9F9FF0, x, y, z, radius, pedMultiplier, vehicleMultiplier, p6, invoke<int>(0x9FA020, invoke<BOOL>(0x9FA0C0, id, p1)
    return Velora.invoke(0x9FA100, "bool", invoke<BOOL>(0x9F9FF0, x, y, z, radius, pedMultiplier, vehicleMultiplier, p6, invoke<int>(0x9FA020, invoke<BOOL>(0x9FA0C0, id, p1)
end

function ENABLE_TENNIS_MODE(ped, toggle, p2)
    Velora.invoke(0x9FA120, "void", ped, toggle, p2)
end

function IS_TENNIS_MODE(invoke<BOOL>(0x9FA140, ped, animDict, animName, p3, p4, p5)
    return Velora.invoke(0x9FA1C0, "bool", invoke<BOOL>(0x9FA140, ped, animDict, animName, p3, p4, p5)
end

function GET_TENNIS_SWING_ANIM_COMPLETE(invoke<BOOL>(0x9FA270, invoke<BOOL>(0x9FA2F0, invoke<BOOL>(0x9FA370, ped, p1, p2, p3, p4, p5)
    return Velora.invoke(0x9FA3F0, "bool", invoke<BOOL>(0x9FA270, invoke<BOOL>(0x9FA2F0, invoke<BOOL>(0x9FA370, ped, p1, p2, p3, p4, p5)
end

function SET_TENNIS_MOVE_NETWORK_SIGNAL_FLOAT(ped, p1, p2)
    Velora.invoke(0x9FA4A0, "void", ped, p1, p2)
end

function RESET_DISPATCH_SPAWN_LOCATION()
    Velora.invoke(0x9FA560, "void")
end

function SET_DISPATCH_SPAWN_LOCATION(x, y, z)
    Velora.invoke(0x9FA580, "void", x, y, z)
end

function RESET_DISPATCH_IDEAL_SPAWN_DISTANCE()
    Velora.invoke(0x9FA5C0, "void")
end

function SET_DISPATCH_IDEAL_SPAWN_DISTANCE(distance)
    Velora.invoke(0x9FA5E0, "void", distance)
end

function RESET_DISPATCH_TIME_BETWEEN_SPAWN_ATTEMPTS(p0)
    Velora.invoke(0x9FA620, "void", p0)
end

function SET_DISPATCH_TIME_BETWEEN_SPAWN_ATTEMPTS(p0, p1)
    Velora.invoke(0x9FA680, "void", p0, p1)
end

function SET_DISPATCH_TIME_BETWEEN_SPAWN_ATTEMPTS_MULTIPLIER(p0, p1)
    Velora.invoke(0x9FA690, "void", p0, p1)
end

function ADD_DISPATCH_SPAWN_ANGLED_BLOCKING_AREA(x1, y1, z1, x2, y2, z2, invoke<int>(0x9FA6A0, x1, y1, x2, invoke<int>(0x9FA720, p0)
    return Velora.invoke(0x9FA790, "int", x1, y1, z1, x2, y2, z2, invoke<int>(0x9FA6A0, x1, y1, x2, invoke<int>(0x9FA720, p0)
end

function RESET_DISPATCH_SPAWN_BLOCKING_AREAS()
    Velora.invoke(0x9FA7C0, "void")
end

function RESET_WANTED_RESPONSE_NUM_PEDS_TO_SPAWN()
    Velora.invoke(0x9FA7E0, "void")
end

function SET_WANTED_RESPONSE_NUM_PEDS_TO_SPAWN(p0, p1)
    Velora.invoke(0x9FA800, "void", p0, p1)
end

function ADD_TACTICAL_NAV_MESH_POINT(x, y, z)
    Velora.invoke(0x9FA840, "void", x, y, z)
end

function CLEAR_TACTICAL_NAV_MESH_POINTS()
    Velora.invoke(0x9FA870, "void")
end

function SET_RIOT_MODE_ENABLED(toggle)
    Velora.invoke(0x9FA880, "void", toggle)
end

function DISPLAY_ONSCREEN_KEYBOARD_WITH_LONGER_INITIAL_STRING(p0, windowTitle, p2, defaultText, defaultConcat1, defaultConcat2, defaultConcat3, defaultConcat4, defaultConcat5, defaultConcat6, defaultConcat7, maxInputLength)
    Velora.invoke(0x9FA8A0, "void", p0, windowTitle, p2, defaultText, defaultConcat1, defaultConcat2, defaultConcat3, defaultConcat4, defaultConcat5, defaultConcat6, defaultConcat7, maxInputLength)
end

function DISPLAY_ONSCREEN_KEYBOARD(p0, windowTitle, p2, defaultText, defaultConcat1, defaultConcat2, defaultConcat3, maxInputLength)
    Velora.invoke(0x9FA910, "void", p0, windowTitle, p2, defaultText, defaultConcat1, defaultConcat2, defaultConcat3, maxInputLength)
end

function UPDATE_ONSCREEN_KEYBOARD(CANCEL_ONSCREEN_KEYBOARD()
    return Velora.invoke(0x9FA9C0, "int", CANCEL_ONSCREEN_KEYBOARD()
end

function NEXT_ONSCREEN_KEYBOARD_RESULT_WILL_DISPLAY_USING_THESE_FONTS(p0)
    Velora.invoke(0x9FA9D0, "void", p0)
end

function ACTION_MANAGER_ENABLE_ACTION(hash, enable)
    Velora.invoke(0x9FA9E0, "void", hash, enable)
end

function GET_REAL_WORLD_TIME(eventType, suppress)
    return Velora.invoke(0x9FAA30, "int", eventType, suppress)
end

function SET_EXPLOSIVE_AMMO_THIS_FRAME(player)
    Velora.invoke(0x9FAA50, "void", player)
end

function SET_FIRE_AMMO_THIS_FRAME(player)
    Velora.invoke(0x9FAA90, "void", player)
end

function SET_EXPLOSIVE_MELEE_THIS_FRAME(player)
    Velora.invoke(0x9FAAE0, "void", player)
end

function SET_SUPER_JUMP_THIS_FRAME(player)
    Velora.invoke(0x9FAB20, "void", player)
end

function SET_BEAST_JUMP_THIS_FRAME(player)
    Velora.invoke(0x9FAB50, "void", player)
end

function SET_FORCED_JUMP_THIS_FRAME(player)
    Velora.invoke(0x9FAB80, "void", player)
end

function HAS_GAME_INSTALLED_THIS_SESSION(SET_TICKER_JOHNMARSTON_IS_DONE()
    return Velora.invoke(0x9FABC0, "bool", SET_TICKER_JOHNMARSTON_IS_DONE()
end

function ARE_PROFILE_SETTINGS_VALID(PREVENT_ARREST_STATE_THIS_FRAME()
    return Velora.invoke(0x9FAC30, "bool", PREVENT_ARREST_STATE_THIS_FRAME()
end

function FORCE_GAME_STATE_PLAYING()
    Velora.invoke(0x9FAC40, "void")
end

function SCRIPT_RACE_INIT(p0, p1, p2, p3)
    Velora.invoke(0x9FAC70, "void", p0, p1, p2, p3)
end

function SCRIPT_RACE_SHUTDOWN()
    Velora.invoke(0x9FAC90, "void")
end

function SCRIPT_RACE_PLAYER_HIT_CHECKPOINT(player, p1, p2, p3)
    Velora.invoke(0x9FACA0, "void", player, p1, p2, p3)
end

function SCRIPT_RACE_GET_PLAYER_SPLIT_TIME(player, p1, invoke<BOOL>(0x9FACC0, START_END_USER_BENCHMARK()
    return Velora.invoke(0x9FACF0, "bool", player, p1, invoke<BOOL>(0x9FACC0, START_END_USER_BENCHMARK()
end

function STOP_END_USER_BENCHMARK()
    Velora.invoke(0x9FAD00, "void")
end

function RESET_END_USER_BENCHMARK()
    Velora.invoke(0x9FAD10, "void")
end

function SAVE_END_USER_BENCHMARK()
    Velora.invoke(0x9FAD20, "void")
end

function UI_STARTED_END_USER_BENCHMARK(RESTART_GAME()
    return Velora.invoke(0x9FAD80, "bool", RESTART_GAME()
end

function QUIT_GAME()
    Velora.invoke(0x9FAD90, "void")
end

function HAS_ASYNC_INSTALL_FINISHED(CLEANUP_ASYNC_INSTALL()
    return Velora.invoke(0x9FADC0, "bool", CLEANUP_ASYNC_INSTALL()
end

function PLM_IS_IN_CONSTRAINED_MODE(toggle)
    return Velora.invoke(0x9FAE30, "bool", toggle)
end

function GET_IS_PLAYER_IN_ANIMAL_FORM(toggle)
    return Velora.invoke(0x9FAE60, "bool", toggle)
end

function DISABLE_SCREEN_DIMMING_THIS_FRAME()
    Velora.invoke(0x9FAE80, "void")
end

function GET_CITY_DENSITY(USE_ACTIVE_CAMERA_FOR_TIMESLICING_CENTRE()
    return Velora.invoke(0x9FAEA0, "float", USE_ACTIVE_CAMERA_FOR_TIMESLICING_CENTRE()
end

function SET_CONTENT_ID_INDEX(contentId, index)
    Velora.invoke(0x9FAEB0, "void", contentId, index)
end

function GET_CONTENT_ID_INDEX(invoke<int>(0x9FAF00, phoneType)
    return Velora.invoke(0xAAF040, "int", invoke<int>(0x9FAF00, phoneType)
end

function DESTROY_MOBILE_PHONE()
    Velora.invoke(0xAAF050, "void")
end

function SET_MOBILE_PHONE_SCALE(scale)
    Velora.invoke(0xAAF080, "void", scale)
end

function SET_MOBILE_PHONE_ROTATION(rotX, rotY, rotZ, p3)
    Velora.invoke(0xAAF0A0, "void", rotX, rotY, rotZ, p3)
end

function GET_MOBILE_PHONE_ROTATION(rotation, p1)
    Velora.invoke(0xAAF0E0, "void", rotation, p1)
end

function SET_MOBILE_PHONE_POSITION(posX, posY, posZ)
    Velora.invoke(0xAAF1D0, "void", posX, posY, posZ)
end

function GET_MOBILE_PHONE_POSITION(position)
    Velora.invoke(0xAAF260, "void", position)
end

function SCRIPT_IS_MOVING_MOBILE_PHONE_OFFSCREEN(toggle)
    Velora.invoke(0xAAF2D0, "void", toggle)
end

function CAN_PHONE_BE_SEEN_ON_SCREEN(toggle)
    return Velora.invoke(0xAAF300, "bool", toggle)
end

function CELL_SET_INPUT(direction)
    Velora.invoke(0xAAF320, "void", direction)
end

function CELL_HORIZONTAL_MODE_TOGGLE(toggle)
    Velora.invoke(0xAAF330, "void", toggle)
end

function CELL_CAM_ACTIVATE(p0, p1)
    Velora.invoke(0xAAF350, "void", p0, p1)
end

function CELL_CAM_ACTIVATE_SELFIE_MODE(toggle)
    Velora.invoke(0xAAF370, "void", toggle)
end

function CELL_CAM_ACTIVATE_SHALLOW_DOF_MODE(toggle)
    Velora.invoke(0xAAF390, "void", toggle)
end

function CELL_CAM_SET_SELFIE_MODE_SIDE_OFFSET_SCALING(p0)
    Velora.invoke(0xAAF3B0, "void", p0)
end

function CELL_CAM_SET_SELFIE_MODE_HORZ_PAN_OFFSET(horizontalPan)
    Velora.invoke(0xAAF3C0, "void", horizontalPan)
end

function CELL_CAM_SET_SELFIE_MODE_VERT_PAN_OFFSET(vertPan)
    Velora.invoke(0xAAF3D0, "void", vertPan)
end

function CELL_CAM_SET_SELFIE_MODE_ROLL_OFFSET(roll)
    Velora.invoke(0xAAF3E0, "void", roll)
end

function CELL_CAM_SET_SELFIE_MODE_DISTANCE_SCALING(distanceScaling)
    Velora.invoke(0xAAF3F0, "void", distanceScaling)
end

function CELL_CAM_SET_SELFIE_MODE_HEAD_YAW_OFFSET(yaw)
    Velora.invoke(0xAAF400, "void", yaw)
end

function CELL_CAM_SET_SELFIE_MODE_HEAD_ROLL_OFFSET(roll)
    Velora.invoke(0xAAF410, "void", roll)
end

function CELL_CAM_SET_SELFIE_MODE_HEAD_PITCH_OFFSET(pitch)
    Velora.invoke(0xAAF420, "void", pitch)
end

function CELL_CAM_IS_CHAR_VISIBLE_NO_FACE_CHECK(invoke<BOOL>(0xAAF430, renderId)
    return Velora.invoke(0xAAF460, "bool", invoke<BOOL>(0xAAF430, renderId)
end

function NETWORK_INITIALIZE_CASH(wallet, bank)
    Velora.invoke(0xA1D3E0, "void", wallet, bank)
end

function NETWORK_DELETE_CHARACTER(characterSlot, p1, p2)
    Velora.invoke(0xA1D3F0, "void", characterSlot, p1, p2)
end

function NETWORK_MANUAL_DELETE_CHARACTER(characterSlot)
    Velora.invoke(0xA1D410, "void", characterSlot)
end

function NETWORK_GET_PLAYER_IS_HIGH_EARNER(characterSlot)
    return Velora.invoke(0xA1D4C0, "bool", characterSlot)
end

function NETWORK_GIVE_PLAYER_JOBSHARE_CASH(amount, gamerHandle)
    Velora.invoke(0xA1D510, "void", amount, gamerHandle)
end

function NETWORK_RECEIVE_PLAYER_JOBSHARE_CASH(value, gamerHandle)
    Velora.invoke(0xA1D520, "void", value, gamerHandle)
end

function NETWORK_CAN_SHARE_JOB_CASH(index, context, reason, p3)
    return Velora.invoke(0xA1D590, "bool", index, context, reason, p3)
end

function NETWORK_DEDUCT_CASH(amount, p1, p2, p3, p4, p5)
    Velora.invoke(0xA1D5B0, "void", amount, p1, p2, p3, p4, p5)
end

function NETWORK_MONEY_CAN_BET(amount, p1, invoke<BOOL>(0xA1D5F0, invoke<BOOL>(0xA1D630, invoke<BOOL>(0xA1D6B0, invoke<BOOL>(0xA1D710, p0, invoke<BOOL>(0xA1D770, p0, invoke<BOOL>(0xA1D7A0, NETWORK_DEFER_CASH_TRANSACTIONS_UNTIL_SHOP_SAVE()
    return Velora.invoke(0xA1D7D0, "bool", amount, p1, invoke<BOOL>(0xA1D5F0, invoke<BOOL>(0xA1D630, invoke<BOOL>(0xA1D6B0, invoke<BOOL>(0xA1D710, p0, invoke<BOOL>(0xA1D770, p0, invoke<BOOL>(0xA1D7A0, NETWORK_DEFER_CASH_TRANSACTIONS_UNTIL_SHOP_SAVE()
end

function CAN_PAY_AMOUNT_TO_BOSS(p0, p1, amount, invoke<BOOL>(0xA1D7E0, amount)
    return Velora.invoke(0xA1D860, "bool", p0, p1, amount, invoke<BOOL>(0xA1D7E0, amount)
end

function NETWORK_EARN_FROM_CASHING_OUT(amount)
    Velora.invoke(0xA1D920, "void", amount)
end

function NETWORK_EARN_FROM_GANGATTACK_PICKUP(amount)
    Velora.invoke(0xA1D9E0, "void", amount)
end

function NETWORK_EARN_ASSASSINATE_TARGET_KILLED(amount)
    Velora.invoke(0xA1DAA0, "void", amount)
end

function NETWORK_EARN_FROM_ROB_ARMORED_CARS(amount)
    Velora.invoke(0xA1DB60, "void", amount)
end

function NETWORK_EARN_FROM_CRATE_DROP(amount)
    Velora.invoke(0xA1DC20, "void", amount)
end

function NETWORK_EARN_FROM_BETTING(amount, p1)
    Velora.invoke(0xA1DCE0, "void", amount, p1)
end

function NETWORK_EARN_FROM_JOB(amount, p1)
    Velora.invoke(0xA1DCF0, "void", amount, p1)
end

function NETWORK_EARN_FROM_JOBX2(amount, p1)
    Velora.invoke(0xA1DD00, "void", amount, p1)
end

function NETWORK_EARN_FROM_PREMIUM_JOB(amount, p1)
    Velora.invoke(0xA1DD10, "void", amount, p1)
end

function NETWORK_EARN_FROM_BEND_JOB(amount, heistHash)
    Velora.invoke(0xA1DD20, "void", amount, heistHash)
end

function NETWORK_EARN_FROM_CHALLENGE_WIN(p0, p1, p2)
    Velora.invoke(0xA1DD30, "void", p0, p1, p2)
end

function NETWORK_EARN_FROM_BOUNTY(amount, gamerHandle, p2, p3)
    Velora.invoke(0xA1DD50, "void", amount, gamerHandle, p2, p3)
end

function NETWORK_EARN_FROM_IMPORT_EXPORT(amount, modelHash)
    Velora.invoke(0xA1DD70, "void", amount, modelHash)
end

function NETWORK_EARN_FROM_HOLDUPS(amount)
    Velora.invoke(0xA1DD80, "void", amount)
end

function NETWORK_EARN_FROM_PROPERTY(amount, propertyName)
    Velora.invoke(0xA1DE40, "void", amount, propertyName)
end

function NETWORK_EARN_FROM_AI_TARGET_KILL(p0, p1)
    Velora.invoke(0xA1DF10, "void", p0, p1)
end

function NETWORK_EARN_FROM_NOT_BADSPORT(amount)
    Velora.invoke(0xA1DFD0, "void", amount)
end

function NETWORK_EARN_FROM_ROCKSTAR(amount)
    Velora.invoke(0xDEADBEEF, "void", amount)
end

function NETWORK_EARN_FROM_VEHICLE(p0, p1, p2, p3, p4, p5, p6, p7)
    Velora.invoke(0xA1E090, "void", p0, p1, p2, p3, p4, p5, p6, p7)
end

function NETWORK_EARN_FROM_PERSONAL_VEHICLE(p0, p1, p2, p3, p4, p5, p6, p7, p8)
    Velora.invoke(0xA1E0E0, "void", p0, p1, p2, p3, p4, p5, p6, p7, p8)
end

function NETWORK_EARN_FROM_DAILY_OBJECTIVES(amount, type, characterSlot)
    Velora.invoke(0xA1E140, "void", amount, type, characterSlot)
end

function NETWORK_EARN_FROM_AMBIENT_JOB(p0, p1, p2)
    Velora.invoke(0xA1E160, "void", p0, p1, p2)
end

function NETWORK_EARN_FROM_JOB_BONUS(p0, p1, p2)
    Velora.invoke(0xA1E180, "void", p0, p1, p2)
end

function NETWORK_EARN_FROM_CRIMINAL_MASTERMIND(p0, p1, p2)
    Velora.invoke(0xA1E1A0, "void", p0, p1, p2)
end

function NETWORK_EARN_HEIST_AWARD(p0, p1, p2)
    Velora.invoke(0xA1E1C0, "void", p0, p1, p2)
end

function NETWORK_EARN_FIRST_TIME_BONUS(p0, p1, p2)
    Velora.invoke(0xA1E1E0, "void", p0, p1, p2)
end

function NETWORK_EARN_GOON(p0, p1, p2)
    Velora.invoke(0xA1E200, "void", p0, p1, p2)
end

function NETWORK_EARN_BOSS(p0, p1, p2)
    Velora.invoke(0xA1E2D0, "void", p0, p1, p2)
end

function NETWORK_EARN_AGENCY(p0, p1, p2, p3)
    Velora.invoke(0xA1E3A0, "void", p0, p1, p2, p3)
end

function NETWORK_EARN_FROM_WAREHOUSE(amount, id)
    Velora.invoke(0xA1E470, "void", amount, id)
end

function NETWORK_EARN_FROM_CONTRABAND(amount, p1)
    Velora.invoke(0xA1E530, "void", amount, p1)
end

function NETWORK_EARN_FROM_DESTROYING_CONTRABAND(p0)
    Velora.invoke(0xA1E5F0, "void", p0)
end

function NETWORK_EARN_FROM_SMUGGLER_WORK(p0, p1, p2, p3, p4)
    Velora.invoke(0xA1E6C0, "void", p0, p1, p2, p3, p4)
end

function NETWORK_EARN_FROM_HANGAR_TRADE(p0, p1)
    Velora.invoke(0xA1E6E0, "void", p0, p1)
end

function NETWORK_EARN_PURCHASE_CLUB_HOUSE(p0, p1)
    Velora.invoke(0xA1E7B0, "void", p0, p1)
end

function NETWORK_EARN_FROM_BUSINESS_PRODUCT(amount, p1, p2, p3)
    Velora.invoke(0xA1E7C0, "void", amount, p1, p2, p3)
end

function NETWORK_EARN_FROM_VEHICLE_EXPORT(amount, p1, p2)
    Velora.invoke(0xA1E8B0, "void", amount, p1, p2)
end

function NETWORK_EARN_SMUGGLER_AGENCY(amount, p1, p2, p3)
    Velora.invoke(0xA1E990, "void", amount, p1, p2, p3)
end

function NETWORK_EARN_BOUNTY_HUNTER_REWARD(p0)
    Velora.invoke(0xA1EA60, "void", p0)
end

function NETWORK_EARN_FROM_BUSINESS_BATTLE(p0)
    Velora.invoke(0xA1EB20, "void", p0)
end

function NETWORK_EARN_FROM_CLUB_MANAGEMENT_PARTICIPATION(p0, p1)
    Velora.invoke(0xA1EBE0, "void", p0, p1)
end

function NETWORK_EARN_FROM_FMBB_PHONECALL_MISSION(p0)
    Velora.invoke(0xA1ECB0, "void", p0)
end

function NETWORK_EARN_FROM_BUSINESS_HUB_SELL(p0, p1, p2)
    Velora.invoke(0xA1ED70, "void", p0, p1, p2)
end

function NETWORK_EARN_FROM_FMBB_BOSS_WORK(p0)
    Velora.invoke(0xA1EE50, "void", p0)
end

function NETWORK_EARN_FMBB_WAGE_BONUS(p0)
    Velora.invoke(0xA1EF10, "void", p0)
end

function NETWORK_CAN_SPEND_MONEY(p0, p1, p2, p3, p4, invoke<BOOL>(0xA1EFD0, p0, p1, p2, p3, p4, p5, invoke<BOOL>(0xA1F060, amount, item, p2, p3, p4, item_name, p6, p7, p8, p9)
    return Velora.invoke(0xA1F0C0, "bool", p0, p1, p2, p3, p4, invoke<BOOL>(0xA1EFD0, p0, p1, p2, p3, p4, p5, invoke<BOOL>(0xA1F060, amount, item, p2, p3, p4, item_name, p6, p7, p8, p9)
end

function NETWORK_SPENT_TAXI(amount, p1, p2, p3, p4)
    Velora.invoke(0xA1F120, "void", amount, p1, p2, p3, p4)
end

function NETWORK_PAY_EMPLOYEE_WAGE(p0, p1, p2)
    Velora.invoke(0xA1F230, "void", p0, p1, p2)
end

function NETWORK_PAY_MATCH_ENTRY_FEE(amount, matchId, p2, p3)
    Velora.invoke(0xA1F320, "void", amount, matchId, p2, p3)
end

function NETWORK_SPENT_BETTING(amount, p1, matchId, p3, p4)
    Velora.invoke(0xA1F350, "void", amount, p1, matchId, p3, p4)
end

function NETWORK_SPENT_WAGER(p0, p1, amount)
    Velora.invoke(0xA1F380, "void", p0, p1, amount)
end

function NETWORK_SPENT_IN_STRIPCLUB(p0, p1, p2, p3)
    Velora.invoke(0xA1F3A0, "void", p0, p1, p2, p3)
end

function NETWORK_BUY_HEALTHCARE(cost, p1, p2)
    Velora.invoke(0xA1F4A0, "void", cost, p1, p2)
end

function NETWORK_BUY_AIRSTRIKE(cost, p1, p2, p3)
    Velora.invoke(0xA1F590, "void", cost, p1, p2, p3)
end

function NETWORK_BUY_BACKUP_GANG(p0, p1, p2, p3)
    Velora.invoke(0xA1F690, "void", p0, p1, p2, p3)
end

function NETWORK_BUY_HELI_STRIKE(cost, p1, p2, p3)
    Velora.invoke(0xA1F7A0, "void", cost, p1, p2, p3)
end

function NETWORK_SPENT_AMMO_DROP(p0, p1, p2, p3)
    Velora.invoke(0xA1F8A0, "void", p0, p1, p2, p3)
end

function NETWORK_BUY_BOUNTY(amount, victim, p2, p3, p4)
    Velora.invoke(0xA1F9A0, "void", amount, victim, p2, p3, p4)
end

function NETWORK_BUY_PROPERTY(cost, propertyName, p2, p3)
    Velora.invoke(0xA1F9D0, "void", cost, propertyName, p2, p3)
end

function NETWORK_BUY_SMOKES(p0, p1, p2)
    Velora.invoke(0xA1FA00, "void", p0, p1, p2)
end

function NETWORK_SPENT_HELI_PICKUP(p0, p1, p2, p3)
    Velora.invoke(0xA1FAF0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_BOAT_PICKUP(p0, p1, p2, p3)
    Velora.invoke(0xA1FBF0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_BULL_SHARK(p0, p1, p2, p3)
    Velora.invoke(0xA1FCF0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_CASH_DROP(amount, p1, p2)
    Velora.invoke(0xA1FDF0, "void", amount, p1, p2)
end

function NETWORK_SPENT_HIRE_MUGGER(p0, p1, p2, p3)
    Velora.invoke(0xA1FEE0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_ROBBED_BY_MUGGER(amount, p1, p2, p3)
    Velora.invoke(0xA1FFE0, "void", amount, p1, p2, p3)
end

function NETWORK_SPENT_HIRE_MERCENARY(p0, p1, p2, p3)
    Velora.invoke(0xA200E0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_BUY_WANTEDLEVEL(p0, p1, p2, p3, p4)
    Velora.invoke(0xA201E0, "void", p0, p1, p2, p3, p4)
end

function NETWORK_SPENT_BUY_OFFTHERADAR(p0, p1, p2, p3)
    Velora.invoke(0xA20210, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_BUY_REVEAL_PLAYERS(p0, p1, p2, p3)
    Velora.invoke(0xA20310, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_CARWASH(p0, p1, p2, p3, p4)
    Velora.invoke(0xA20410, "void", p0, p1, p2, p3, p4)
end

function NETWORK_SPENT_CINEMA(p0, p1, p2, p3)
    Velora.invoke(0xA20520, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_TELESCOPE(p0, p1, p2)
    Velora.invoke(0xA20620, "void", p0, p1, p2)
end

function NETWORK_SPENT_HOLDUPS(p0, p1, p2)
    Velora.invoke(0xA20710, "void", p0, p1, p2)
end

function NETWORK_SPENT_BUY_PASSIVE_MODE(p0, p1, p2, p3)
    Velora.invoke(0xA20800, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_BANK_INTEREST(p0, p1, p2)
    Velora.invoke(0xA20900, "void", p0, p1, p2)
end

function NETWORK_SPENT_PROSTITUTES(p0, p1, p2)
    Velora.invoke(0xA209F0, "void", p0, p1, p2)
end

function NETWORK_SPENT_ARREST_BAIL(p0, p1, p2)
    Velora.invoke(0xA20AE0, "void", p0, p1, p2)
end

function NETWORK_SPENT_PAY_VEHICLE_INSURANCE_PREMIUM(amount, vehicleModel, gamerHandle, notBankrupt, hasTheMoney)
    Velora.invoke(0xA20BD0, "void", amount, vehicleModel, gamerHandle, notBankrupt, hasTheMoney)
end

function NETWORK_SPENT_CALL_PLAYER(p0, p1, p2, p3)
    Velora.invoke(0xA20C00, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_BOUNTY(p0, p1, p2)
    Velora.invoke(0xA20C30, "void", p0, p1, p2)
end

function NETWORK_SPENT_FROM_ROCKSTAR(p0, p1, p2)
    Velora.invoke(0xA20D20, "void", p0, p1, p2)
end

function NETWORK_SPEND_EARNED_FROM_BANK_AND_WALLETS(invoke<int>(0xA20E10, p0, p1, char>(0xA20E20, p0, p1, p2)
    return Velora.invoke(0xA20E50, "int", invoke<int>(0xA20E10, p0, p1, char>(0xA20E20, p0, p1, p2)
end

function NETWORK_SPENT_PLAYER_HEALTHCARE(p0, p1, p2, p3)
    Velora.invoke(0xA20F40, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_NO_COPS(p0, p1, p2, p3)
    Velora.invoke(0xA20F70, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_CARGO_SOURCING(p0, p1, p2, p3, p4, p5)
    Velora.invoke(0xA21070, "void", p0, p1, p2, p3, p4, p5)
end

function NETWORK_SPENT_REQUEST_JOB(p0, p1, p2, p3)
    Velora.invoke(0xA211A0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_REQUEST_HEIST(p0, p1, p2, p3)
    Velora.invoke(0xA212A0, "void", p0, p1, p2, p3)
end

function NETWORK_BUY_FAIRGROUND_RIDE(amount, p1, p2, p3, p4)
    Velora.invoke(0xA213A0, "void", amount, p1, p2, p3, p4)
end

function NETWORK_ECONOMY_HAS_FIXED_CRAZY_NUMBERS(amount, matchId, p2, p3)
    return Velora.invoke(0xA214D0, "bool", amount, matchId, p2, p3)
end

function NETWORK_SPENT_BOSS_GOON(amount, p1, invoke<BOOL>(0xA21500, p0, p1, amount)
    return Velora.invoke(0xA21540, "bool", amount, p1, invoke<BOOL>(0xA21500, p0, p1, amount)
end

function NETWORK_SPEND_BOSS(p0, p1, p2)
    Velora.invoke(0xA21560, "void", p0, p1, p2)
end

function NETWORK_SPENT_MOVE_YACHT(amount, p1, p2)
    Velora.invoke(0xA21580, "void", amount, p1, p2)
end

function NETWORK_SPENT_RENAME_ORGANIZATION(p0, p1, p2)
    Velora.invoke(0xA21670, "void", p0, p1, p2)
end

function NETWORK_BUY_CONTRABAND_MISSION(p0, p1, p2, p3, p4)
    Velora.invoke(0xA216A0, "void", p0, p1, p2, p3, p4)
end

function NETWORK_SPENT_PA_SERVICE_HELI(p0, p1, p2, p3)
    Velora.invoke(0xA216D0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_PA_SERVICE_VEHICLE(p0, p1, p2, p3)
    Velora.invoke(0xA21700, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_PA_SERVICE_SNACK(p0, p1, p2, p3)
    Velora.invoke(0xA21730, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_PA_SERVICE_DANCER(p0, p1, p2, p3)
    Velora.invoke(0xA21760, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_PA_SERVICE_IMPOUND(p0, p1, p2)
    Velora.invoke(0xA21790, "void", p0, p1, p2)
end

function NETWORK_SPENT_PA_HELI_PICKUP(p0, p1, p2, p3)
    Velora.invoke(0xA217B0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_PURCHASE_OFFICE_PROPERTY(p0, p1, p2, p3)
    Velora.invoke(0xA217E0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPGRADE_OFFICE_PROPERTY(p0, p1, p2, p3)
    Velora.invoke(0xA21810, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_PURCHASE_WAREHOUSE_PROPERTY(p0, p1, p2, p3)
    Velora.invoke(0xA21850, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPGRADE_WAREHOUSE_PROPERTY(p0, p1, p2, p3)
    Velora.invoke(0xA21890, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_PURCHASE_IMPEXP_WAREHOUSE_PROPERTY(amount, data, p2, p3)
    Velora.invoke(0xA218D0, "void", amount, data, p2, p3)
end

function NETWORK_SPENT_UPGRADE_IMPEXP_WAREHOUSE_PROPERTY(p0, p1, p2, p3)
    Velora.invoke(0xA21910, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_TRADE_IMPEXP_WAREHOUSE_PROPERTY(p0, p1, p2, p3)
    Velora.invoke(0xA21950, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_ORDER_WAREHOUSE_VEHICLE(p0, p1, p2, p3)
    Velora.invoke(0xA21980, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_ORDER_BODYGUARD_VEHICLE(p0, p1, p2, p3)
    Velora.invoke(0xA21A80, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_JUKEBOX(p0, p1, p2, p3)
    Velora.invoke(0xA21B80, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_PURCHASE_CLUB_HOUSE(p0, p1, p2, p3)
    Velora.invoke(0xA21C80, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPGRADE_CLUB_HOUSE(p0, p1, p2, p3)
    Velora.invoke(0xA21CB0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_PURCHASE_BUSINESS_PROPERTY(p0, p1, p2, p3)
    Velora.invoke(0xA21CE0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPGRADE_BUSINESS_PROPERTY(p0, p1, p2, p3)
    Velora.invoke(0xA21D10, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_TRADE_BUSINESS_PROPERTY(p0, p1, p2, p3)
    Velora.invoke(0xA21D40, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_MC_ABILITY(p0, p1, p2, p3, p4)
    Velora.invoke(0xA21D70, "void", p0, p1, p2, p3, p4)
end

function NETWORK_SPENT_PAY_BUSINESS_SUPPLIES(p0, p1, p2, p3)
    Velora.invoke(0xA21E80, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_CHANGE_APPEARANCE(p0, p1, p2)
    Velora.invoke(0xA21EA0, "void", p0, p1, p2)
end

function NETWORK_SPENT_VEHICLE_EXPORT_MODS(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)
    Velora.invoke(0xA21F90, "void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)
end

function NETWORK_SPENT_PURCHASE_OFFICE_GARAGE(p0, p1, p2, p3)
    Velora.invoke(0xA22110, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPGRADE_OFFICE_GARAGE(p0, p1, p2, p3)
    Velora.invoke(0xA22140, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_IMPORT_EXPORT_REPAIR(p0, p1, p2)
    Velora.invoke(0xA22170, "void", p0, p1, p2)
end

function NETWORK_SPENT_PURCHASE_HANGAR(p0, p1, p2, p3)
    Velora.invoke(0xA22270, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPGRADE_HANGAR(p0, p1, p2, p3)
    Velora.invoke(0xA222A0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_HANGAR_UTILITY_CHARGES(amount, p1, p2)
    Velora.invoke(0xA222D0, "void", amount, p1, p2)
end

function NETWORK_SPENT_HANGAR_STAFF_CHARGES(amount, p1, p2)
    Velora.invoke(0xA223D0, "void", amount, p1, p2)
end

function NETWORK_SPENT_BUY_TRUCK(p0, p1, p2, p3)
    Velora.invoke(0xA224D0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPGRADE_TRUCK(p0, p1, p2, p3)
    Velora.invoke(0xA22500, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_BUY_BUNKER(p0, p1, p2, p3)
    Velora.invoke(0xA22530, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPRADE_BUNKER(p0, p1, p2, p3)
    Velora.invoke(0xA22560, "void", p0, p1, p2, p3)
end

function NETWORK_EARN_FROM_SELL_BUNKER(amount, bunkerHash)
    Velora.invoke(0xA22590, "void", amount, bunkerHash)
end

function NETWORK_SPENT_BALLISTIC_EQUIPMENT(amount, p1, p2)
    Velora.invoke(0xA22650, "void", amount, p1, p2)
end

function NETWORK_EARN_RDR_BONUS(amount, p1)
    Velora.invoke(0xA22740, "void", amount, p1)
end

function NETWORK_EARN_WAGE_PAYMENT(amount, p1)
    Velora.invoke(0xA22800, "void", amount, p1)
end

function NETWORK_EARN_WAGE_PAYMENT_BONUS(amount)
    Velora.invoke(0xA228C0, "void", amount)
end

function NETWORK_SPENT_BUY_BASE(p0, p1, p2, p3)
    Velora.invoke(0xA22980, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPGRADE_BASE(p0, p1, p2, p3)
    Velora.invoke(0xA229B0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_BUY_TILTROTOR(p0, p1, p2, p3)
    Velora.invoke(0xA229E0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPGRADE_TILTROTOR(p0, p1, p2, p3)
    Velora.invoke(0xA22A10, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_EMPLOY_ASSASSINS(p0, p1, p2, p3)
    Velora.invoke(0xA22A40, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_GANGOPS_CANNON(p0, p1, p2, p3)
    Velora.invoke(0xA22B40, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_GANGOPS_SKIP_MISSION(p0, p1, p2, p3)
    Velora.invoke(0xA22C40, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_CASINO_HEIST_SKIP_MISSION(p0, p1, p2, p3)
    Velora.invoke(0xA22D40, "void", p0, p1, p2, p3)
end

function NETWORK_EARN_SELL_BASE(amount, baseNameHash)
    Velora.invoke(0xA22E40, "void", amount, baseNameHash)
end

function NETWORK_EARN_TARGET_REFUND(amount, p1)
    Velora.invoke(0xA22F00, "void", amount, p1)
end

function NETWORK_EARN_GANGOPS_WAGES(amount, p1)
    Velora.invoke(0xA22FC0, "void", amount, p1)
end

function NETWORK_EARN_GANGOPS_WAGES_BONUS(amount, p1)
    Velora.invoke(0xA23080, "void", amount, p1)
end

function NETWORK_EARN_DAR_CHALLENGE(amount, p1)
    Velora.invoke(0xA23140, "void", amount, p1)
end

function NETWORK_EARN_DOOMSDAY_FINALE_BONUS(amount, vehicleHash)
    Velora.invoke(0xA23200, "void", amount, vehicleHash)
end

function NETWORK_EARN_GANGOPS_AWARD(amount, p1, p2)
    Velora.invoke(0xA232C0, "void", amount, p1, p2)
end

function NETWORK_EARN_GANGOPS_ELITE(amount, p1, actIndex)
    Velora.invoke(0xA23300, "void", amount, p1, actIndex)
end

function NETWORK_SERVICE_EARN_GANGOPS_RIVAL_DELIVERY(earnedMoney)
    Velora.invoke(0xA23350, "void", earnedMoney)
end

function NETWORK_SPEND_GANGOPS_START_STRAND(type, amount, p2, p3)
    Velora.invoke(0xA23360, "void", type, amount, p2, p3)
end

function NETWORK_SPEND_GANGOPS_TRIP_SKIP(amount, p1, p2)
    Velora.invoke(0xA23460, "void", amount, p1, p2)
end

function NETWORK_EARN_GANGOPS_PREP_PARTICIPATION(amount)
    Velora.invoke(0xA23550, "void", amount)
end

function NETWORK_EARN_GANGOPS_SETUP(amount, p1)
    Velora.invoke(0xA23560, "void", amount, p1)
end

function NETWORK_EARN_GANGOPS_FINALE(amount, p1)
    Velora.invoke(0xA23570, "void", amount, p1)
end

function NETWORK_SPEND_GANGOPS_REPAIR_COST(p0, p1, p2)
    Velora.invoke(0xA23580, "void", p0, p1, p2)
end

function NETWORK_EARN_NIGHTCLUB(p0)
    Velora.invoke(0xA23670, "void", p0)
end

function NETWORK_EARN_NIGHTCLUB_DANCING(p0)
    Velora.invoke(0xA23730, "void", p0)
end

function NETWORK_EARN_BB_EVENT_BONUS(amount)
    Velora.invoke(0xA237F0, "void", amount)
end

function NETWORK_SPENT_PURCHASE_HACKER_TRUCK(p0, p1, p2, p3)
    Velora.invoke(0xA238B0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPGRADE_HACKER_TRUCK(p0, p1, p2, p3)
    Velora.invoke(0xA238E0, "void", p0, p1, p2, p3)
end

function NETWORK_EARN_HACKER_TRUCK(p0, amount, p2, p3)
    Velora.invoke(0xA23910, "void", p0, amount, p2, p3)
end

function NETWORK_SPENT_PURCHASE_NIGHTCLUB_AND_WAREHOUSE(p0, p1, p2, p3)
    Velora.invoke(0xA23930, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_UPGRADE_NIGHTCLUB_AND_WAREHOUSE(p0, p1, p2, p3)
    Velora.invoke(0xA23960, "void", p0, p1, p2, p3)
end

function NETWORK_EARN_NIGHTCLUB_AND_WAREHOUSE(p0, p1, p2, p3, p4, p5, p6)
    Velora.invoke(0xA23990, "void", p0, p1, p2, p3, p4, p5, p6)
end

function NETWORK_SPEND_NIGHTCLUB_AND_WAREHOUSE(p0, p1, p2, p3)
    Velora.invoke(0xA239C0, "void", p0, p1, p2, p3)
end

function NETWORK_SPENT_RDR_HATCHET_BONUS(amount, p1, p2)
    Velora.invoke(0xA23AA0, "void", amount, p1, p2)
end

function NETWORK_SPENT_NIGHTCLUB_ENTRY_FEE(player, amount, p1, p2, p3)
    Velora.invoke(0xA23AC0, "void", player, amount, p1, p2, p3)
end

function NETWORK_SPEND_NIGHTCLUB_BAR_DRINK(amount, p1, p2, p3)
    Velora.invoke(0xA23AF0, "void", amount, p1, p2, p3)
end

function NETWORK_SPEND_BOUNTY_HUNTER_MISSION(amount, p1, p2)
    Velora.invoke(0xA23BF0, "void", amount, p1, p2)
end

function NETWORK_SPENT_REHIRE_DJ(amount, p1, p2, p3)
    Velora.invoke(0xA23CE0, "void", amount, p1, p2, p3)
end

function NETWORK_SPENT_ARENA_JOIN_SPECTATOR(amount, p1, p2, p3)
    Velora.invoke(0xA23DE0, "void", amount, p1, p2, p3)
end

function NETWORK_EARN_ARENA_SKILL_LEVEL_PROGRESSION(amount, p1)
    Velora.invoke(0xA23EE0, "void", amount, p1)
end

function NETWORK_EARN_ARENA_CAREER_PROGRESSION(amount, p1)
    Velora.invoke(0xA23FA0, "void", amount, p1)
end

function NETWORK_SPEND_MAKE_IT_RAIN(amount, p1, p2)
    Velora.invoke(0xA24060, "void", amount, p1, p2)
end

function NETWORK_SPEND_BUY_ARENA(amount, p1, p2, p3)
    Velora.invoke(0xA24160, "void", amount, p1, p2, p3)
end

function NETWORK_SPEND_UPGRADE_ARENA(amount, p1, p2, p3)
    Velora.invoke(0xA24190, "void", amount, p1, p2, p3)
end

function NETWORK_SPEND_ARENA_SPECTATOR_BOX(amount, type, p2, p3)
    Velora.invoke(0xA241C0, "void", amount, type, p2, p3)
end

function NETWORK_SPEND_SPIN_THE_WHEEL_PAYMENT(amount, p1, p2)
    Velora.invoke(0xA242C0, "void", amount, p1, p2)
end

function NETWORK_EARN_SPIN_THE_WHEEL_CASH(amount)
    Velora.invoke(0xA243C0, "void", amount)
end

function NETWORK_SPEND_ARENA_PREMIUM(amount, p1, p2)
    Velora.invoke(0xA24480, "void", amount, p1, p2)
end

function NETWORK_EARN_ARENA_WAR(amount, p1, p2, p3)
    Velora.invoke(0xA24570, "void", amount, p1, p2, p3)
end

function NETWORK_EARN_ARENA_WAR_ASSASSINATE_TARGET(amount)
    Velora.invoke(0xA24590, "void", amount)
end

function NETWORK_EARN_ARENA_WAR_EVENT_CARGO(amount)
    Velora.invoke(0xA245A0, "void", amount)
end

function NETWORK_EARN_RC_TIME_TRIAL(amount)
    Velora.invoke(0xA245B0, "void", amount)
end

function NETWORK_EARN_DAILY_OBJECTIVE_EVENT(amount)
    Velora.invoke(0xA24670, "void", amount)
end

function NETWORK_SPEND_CASINO_MEMBERSHIP(amount, p1, p2, p3)
    Velora.invoke(0xA24730, "void", amount, p1, p2, p3)
end

function NETWORK_SPEND_BUY_CASINO(amount, p1, p2, data)
    Velora.invoke(0xA24830, "void", amount, p1, p2, data)
end

function NETWORK_SPEND_UPGRADE_CASINO(amount, p1, p2, data)
    Velora.invoke(0xA24860, "void", amount, p1, p2, data)
end

function NETWORK_SPEND_CASINO_GENERIC(amount, p1, p2, p3, p4)
    Velora.invoke(0xA24890, "void", amount, p1, p2, p3, p4)
end

function NETWORK_EARN_CASINO_TIME_TRIAL_WIN(amount)
    Velora.invoke(0xA248C0, "void", amount)
end

function NETWORK_EARN_COLLECTABLES_ACTION_FIGURES(amount)
    Velora.invoke(0xA248D0, "void", amount)
end

function NETWORK_EARN_CASINO_COLLECTABLE_COMPLETED_COLLECTION(amount)
    Velora.invoke(0xA248E0, "void", amount)
end

function NETWORK_EARN_SELL_PRIZE_VEHICLE(amount, p1, p2)
    Velora.invoke(0xA248F0, "void", amount, p1, p2)
end

function NETWORK_EARN_CASINO_MISSION_REWARD(amount)
    Velora.invoke(0xA24910, "void", amount)
end

function NETWORK_EARN_CASINO_STORY_MISSION_REWARD(amount)
    Velora.invoke(0xA24920, "void", amount)
end

function NETWORK_EARN_CASINO_MISSION_PARTICIPATION(amount)
    Velora.invoke(0xA24930, "void", amount)
end

function NETWORK_EARN_CASINO_AWARD(amount, hash)
    Velora.invoke(0xA24940, "void", amount, hash)
end

function NETWORK_SPEND_BUY_ARCADE(p0, p1, p2, p3)
    Velora.invoke(0xA24A00, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_UPGRADE_ARCADE(p0, p1, p2, p3)
    Velora.invoke(0xA24A30, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_CASINO_HEIST(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
    Velora.invoke(0xA24A60, "void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
end

function NETWORK_SPEND_ARCADE_MGMT(p0, p1, p2, p3, p4)
    Velora.invoke(0xA24AD0, "void", p0, p1, p2, p3, p4)
end

function NETWORK_SPEND_PLAY_ARCADE(p0, p1, p2, p3, p4)
    Velora.invoke(0xA24B00, "void", p0, p1, p2, p3, p4)
end

function NETWORK_SPEND_ARCADE(p0, p1, p2, p3, p4)
    Velora.invoke(0xA24B30, "void", p0, p1, p2, p3, p4)
end

function NETWORK_EARN_CASINO_HEIST(p0, p1, p2, p3, p4, p5, p6)
    Velora.invoke(0xA24B60, "void", p0, p1, p2, p3, p4, p5, p6)
end

function NETWORK_EARN_UPGRADE_ARCADE(p0, p1, p2)
    Velora.invoke(0xA24B90, "void", p0, p1, p2)
end

function NETWORK_EARN_ARCADE(p0, p1, p2, p3, p4)
    Velora.invoke(0xA24BB0, "void", p0, p1, p2, p3, p4)
end

function NETWORK_EARN_COLLECTABLES(p0, p1, p2)
    Velora.invoke(0xA24BD0, "void", p0, p1, p2)
end

function NETWORK_EARN_CHALLENGE(amount, p1, p2)
    Velora.invoke(0xA24BF0, "void", amount, p1, p2)
end

function NETWORK_EARN_CASINO_HEIST_AWARDS(p0, p1, p2, p3, p4)
    Velora.invoke(0xA24C10, "void", p0, p1, p2, p3, p4)
end

function NETWORK_EARN_COLLECTABLE_ITEM(amount, p1)
    Velora.invoke(0xA24C30, "void", amount, p1)
end

function NETWORK_EARN_COLLECTABLE_COMPLETED_COLLECTION(amount, p1)
    Velora.invoke(0xA24C40, "void", amount, p1)
end

function NETWORK_EARN_YATCH_MISSION(amount, p1)
    Velora.invoke(0xA24C50, "void", amount, p1)
end

function NETWORK_EARN_DISPATCH_CALL(amount, p1)
    Velora.invoke(0xA24D10, "void", amount, p1)
end

function NETWORK_SPEND_BEACH_PARTY(p0)
    Velora.invoke(0xA24DD0, "void", p0)
end

function NETWORK_SPEND_SUBMARINE(p0, p1, p2, p3, p4, p5)
    Velora.invoke(0xA24DE0, "void", p0, p1, p2, p3, p4, p5)
end

function NETWORK_SPEND_CASINO_CLUB(amount1, p1, p2, p3, p4, p5, p6, amount2, p8)
    Velora.invoke(0xA24E10, "void", amount1, p1, p2, p3, p4, p5, p6, amount2, p8)
end

function NETWORK_SPEND_BUY_SUB(p0, p1, p2, p3)
    Velora.invoke(0xA24E60, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_UPGRADE_SUB(p0, p1, p2, p3)
    Velora.invoke(0xA24E90, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_ISLAND_HEIST(p0, p1, p2, p3)
    Velora.invoke(0xA24EC0, "void", p0, p1, p2, p3)
end

function NETWORK_EARN_ISLAND_HEIST(amount1, p1, p2, p3, amount2, p5)
    Velora.invoke(0xA24EF0, "void", amount1, p1, p2, p3, amount2, p5)
end

function NETWORK_EARN_BEACH_PARTY_LOST_FOUND(p0, p1, p2)
    Velora.invoke(0xA24F10, "void", p0, p1, p2)
end

function NETWORK_EARN_FROM_ISLAND_HEIST_DJ_MISSION(p0, p1)
    Velora.invoke(0xA24F30, "void", p0, p1)
end

function NETWORK_SPEND_CAR_CLUB_MEMBERSHIP(amount1, p1, p2, amount2, p4)
    Velora.invoke(0xA24F40, "void", amount1, p1, p2, amount2, p4)
end

function NETWORK_SPEND_CAR_CLUB_BAR(p0, p1, p2, p3)
    Velora.invoke(0xA24F70, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_AUTOSHOP_MODIFY(p0, p1, p2, p3, p4)
    Velora.invoke(0xA24FA0, "void", p0, p1, p2, p3, p4)
end

function NETWORK_SPEND_CAR_CLUB_TAKEOVER(p0, p1, p2, p3)
    Velora.invoke(0xA24FD0, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_BUY_AUTOSHOP(p0, p1, p2, p3)
    Velora.invoke(0xA25000, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_UPGRADE_AUTOSHOP(p0, p1, p2, p3)
    Velora.invoke(0xA25030, "void", p0, p1, p2, p3)
end

function NETWORK_EARN_AUTOSHOP_BUSINESS(p0, p1, p2)
    Velora.invoke(0xA25060, "void", p0, p1, p2)
end

function NETWORK_EARN_AUTOSHOP_INCOME(p0, p1)
    Velora.invoke(0xA25080, "void", p0, p1)
end

function NETWORK_EARN_CARCLUB_MEMBERSHIP(p0)
    Velora.invoke(0xA25090, "void", p0)
end

function NETWORK_EARN_DAILY_VEHICLE(p0, p1)
    Velora.invoke(0xA250A0, "void", p0, p1)
end

function NETWORK_EARN_DAILY_VEHICLE_BONUS(p0)
    Velora.invoke(0xA250B0, "void", p0)
end

function NETWORK_EARN_TUNER_AWARD(p0, p1, p2)
    Velora.invoke(0xA250C0, "void", p0, p1, p2)
end

function NETWORK_EARN_TUNER_ROBBERY(p0, p1, p2, p3, p4)
    Velora.invoke(0xA250E0, "void", p0, p1, p2, p3, p4)
end

function NETWORK_EARN_UPGRADE_AUTOSHOP(p0, p1)
    Velora.invoke(0xA25100, "void", p0, p1)
end

function NETWORK_SPEND_INTERACTION_MENU_ABILITY(p0, p1, p2, p3)
    Velora.invoke(0xA25110, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_SET_COMMON_FIELDS(p0, p1, p2, p3)
    Velora.invoke(0xA25140, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_SET_DISCOUNT(p0)
    Velora.invoke(0xA25190, "void", p0)
end

function NETWORK_SPEND_BUY_AGENCY(p0, p1, p2, p3)
    Velora.invoke(0xA251C0, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_UPGRADE_AGENCY(p0, p1, p2, p3)
    Velora.invoke(0xA251F0, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_AGENCY(p0, p1, p2, p3, p4)
    Velora.invoke(0xA25220, "void", p0, p1, p2, p3, p4)
end

function NETWORK_SPEND_HIDDEN(p0, p1, p2, p3)
    Velora.invoke(0xA25250, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_SOURCE_BIKE(p0, p1, p2, p3)
    Velora.invoke(0xA25280, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_COMP_SUV(p0, p1, p2, p3)
    Velora.invoke(0xA252B0, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_SUV_FST_TRVL(p0, p1, p2, p3)
    Velora.invoke(0xA252E0, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_SUPPLY(p0, p1, p2, p3)
    Velora.invoke(0xA25310, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_BIKE_SHOP(p0, p1, p2, p3)
    Velora.invoke(0xA25340, "void", p0, p1, p2, p3)
end

function NETWORK_SPEND_VEHICLE_REQUESTED(p0, p1, p2, p3, p4)
    Velora.invoke(0xA25370, "void", p0, p1, p2, p3, p4)
end

function NETWORK_SPEND_GUNRUNNING(p0, p1, p2, p3)
    Velora.invoke(0xA25490, "void", p0, p1, p2, p3)
end

function NETWORK_EARN_AGENCY_SAFE(p0)
    Velora.invoke(0xA254C0, "void", p0)
end

function NETWORK_EARN_AWARD_CONTRACT(p0, p1)
    Velora.invoke(0xA254D0, "void", p0, p1)
end

function NETWORK_EARN_AGENCY_CONTRACT(p0, p1)
    Velora.invoke(0xA254E0, "void", p0, p1)
end

function NETWORK_EARN_AWARD_PHONE(p0, p1)
    Velora.invoke(0xA254F0, "void", p0, p1)
end

function NETWORK_EARN_AGENCY_PHONE(p0, p1, p2)
    Velora.invoke(0xA25500, "void", p0, p1, p2)
end

function NETWORK_EARN_AWARD_FIXER_MISSION(p0, p1)
    Velora.invoke(0xA25520, "void", p0, p1)
end

function NETWORK_EARN_FIXER_PREP(p0, p1)
    Velora.invoke(0xA25530, "void", p0, p1)
end

function NETWORK_EARN_FIXER_FINALE(p0, p1)
    Velora.invoke(0xA25540, "void", p0, p1)
end

function NETWORK_EARN_FIXER_AGENCY_SHORT_TRIP(p0, p1)
    Velora.invoke(0xA25550, "void", p0, p1)
end

function NETWORK_EARN_AWARD_SHORT_TRIP(p0, p1)
    Velora.invoke(0xA25560, "void", p0, p1)
end

function NETWORK_EARN_FIXER_RIVAL_DELIVERY(p0, p1)
    Velora.invoke(0xA25570, "void", p0, p1)
end

function NETWORK_EARN_UPGRADE_AGENCY(p0, p1)
    Velora.invoke(0xA25580, "void", p0, p1)
end

function NETWORK_SPEND_APARTMENT_UTILITIES(amount, p1, p2, data)
    Velora.invoke(0xA25590, "void", amount, p1, p2, data)
end

function NETWORK_SPEND_BUSINESS_PROPERTY_FEES(p0, p1, p2, p3)
    Velora.invoke(0xA255C0, "void", p0, p1, p2, p3)
end

function NETWORK_EARN_SIGHTSEEING_REWARD(p0, p1, p2, p3)
    Velora.invoke(0xA255F0, "void", p0, p1, p2, p3)
end

function NETWORK_EARN_BIKER_SHOP(p0, p1)
    Velora.invoke(0xA25610, "void", p0, p1)
end

function NETWORK_EARN_BIKER(p0)
    Velora.invoke(0xA25620, "void", p0)
end

function NETWORK_YOHAN_SOURCE_GOODS(p0, p1, p2, p3)
    Velora.invoke(0xA25630, "void", p0, p1, p2, p3)
end

function _NETWORK_SPEND_BUY_MFGARAGE(p0, p1, p2, p3)
    Velora.invoke(0xA25650, "void", p0, p1, p2, p3)
end

function _NETWORK_SPEND_UPGRADE_MFGARAGE(p0, p1, p2, p3)
    Velora.invoke(0xA25680, "void", p0, p1, p2, p3)
end

function _NETWORK_SPEND_BUY_SUPPLIES(p0, p1, p2, p3)
    Velora.invoke(0xA256B0, "void", p0, p1, p2, p3)
end

function _NETWORK_SPEND_BUY_ACID_LAB(p0, p1, p2, p3)
    Velora.invoke(0xA257C0, "void", p0, p1, p2, p3)
end

function _NETWORK_SPEND_UPGRADE_ACID_LAB_EQUIPMENT(p0, p1, p2, p3)
    Velora.invoke(0xA258D0, "void", p0, p1, p2, p3)
end

function _NETWORK_SPEND_UPGRADE_ACID_LAB_ARMOR(p0, p1, p2, p3)
    Velora.invoke(0xA25900, "void", p0, p1, p2, p3)
end

function _NETWORK_SPEND_UPGRADE_ACID_LAB_SCOOP(p0, p1, p2, p3)
    Velora.invoke(0xA25930, "void", p0, p1, p2, p3)
end

function _NETWORK_SPEND_UPGRADE_ACID_LAB_MINES(p0, p1, p2, p3)
    Velora.invoke(0xA25960, "void", p0, p1, p2, p3)
end

function _NETWORK_SPEND_RENAME_ACID_LAB(p0, p1, p2, p3)
    Velora.invoke(0xA25990, "void", p0, p1, p2, p3)
end

function _NETWORK_SPEND_RENAME_ACID_PRODUCT(p0, p1, p2, p3)
    Velora.invoke(0xA259C0, "void", p0, p1, p2, p3)
end

function _NETWORK_EARN_AWARD_JUGGALO_MISSION(p0, p1)
    Velora.invoke(0xA259F0, "void", p0, p1)
end

function _NETWORK_EARN_AWARD_ACID_LAB(p0, p1)
    Velora.invoke(0xA25AF0, "void", p0, p1)
end

function _NETWORK_EARN_AWARD_DAILY_STASH(p0, p1)
    Velora.invoke(0xA25BF0, "void", p0, p1)
end

function _NETWORK_EARN_AWARD_DEAD_DROP(p0, p1)
    Velora.invoke(0xA25CF0, "void", p0, p1)
end

function _NETWORK_EARN_AWARD_RANDOM_EVENT(p0, p1)
    Velora.invoke(0xA25DF0, "void", p0, p1)
end

function _NETWORK_EARN_AWARD_TAXI(p0, p1)
    Velora.invoke(0xA25EF0, "void", p0, p1)
end

function _NETWORK_EARN_STREET_DEALER(p0, p1)
    Velora.invoke(0xA25FF0, "void", p0, p1)
end

function _NETWORK_EARN_SELL_ACID(p0, p1)
    Velora.invoke(0xA26000, "void", p0, p1)
end

function _NETWORK_EARN_SETUP_PARTICIPATION_ACID_LAB(p0, p1)
    Velora.invoke(0xA260C0, "void", p0, p1)
end

function _NETWORK_EARN_SOURCE_PARTICIPATION_ACID_LAB(p0, p1)
    Velora.invoke(0xA26180, "void", p0, p1)
end

function _NETWORK_EARN_SELL_PARTICIPATION_ACID_LAB(p0, p1)
    Velora.invoke(0xA26240, "void", p0, p1)
end

function _NETWORK_EARN_JUGGALO_STORY_MISSION(p0, p1)
    Velora.invoke(0xA26300, "void", p0, p1)
end

function _NETWORK_EARN_JUGGALO_STORY_MISSION_PARTICIPATION(p0, p1)
    Velora.invoke(0xA263C0, "void", p0, p1)
end

function _NETWORK_EARN_FOOLIGAN_JOB(p0, p1)
    Velora.invoke(0xA26480, "void", p0, p1)
end

function _NETWORK_EARN_FOOLIGAN_JOB_PARTICIPATION(p0, p1)
    Velora.invoke(0xA26540, "void", p0, p1)
end

function _NETWORK_EARN_TAXI_JOB(p0, p1)
    Velora.invoke(0xA26600, "void", p0, p1)
end

function _NETWORK_EARN_DAILY_STASH_HOUSE_COMPLETED(p0, p1)
    Velora.invoke(0xA266F0, "void", p0, p1)
end

function _NETWORK_EARN_DAILY_STASH_HOUSE_PARTICIPATION(p0, p1)
    Velora.invoke(0xA267B0, "void", p0, p1)
end

function NETWORK_GET_VC_BANK_BALANCE(invoke<int>(0xA26FF0, char>(0xA270B0, amount, invoke<BOOL>(0xA27180, invoke<BOOL>(0xA271B0, amount, invoke<BOOL>(0xA271E0, invoke<BOOL>(0xA27240, p0, p1, p2, invoke<BOOL>(0xA272D0, invoke<int>(0xA27340, invoke<BOOL>(0xA27370, invoke<BOOL>(0xA273A0, invoke<BOOL>(0xA273B0, invoke<BOOL>(0xA28330, invoke<BOOL>(0xA28340, itemHash, categoryHash, invoke<int>(0xA28350, invoke<BOOL>(0xA283A0, invoke<BOOL>(0xA283C0, invoke<BOOL>(0xA283D0, invoke<BOOL>(0xA283F0, invoke<BOOL>(0xA28400, invoke<BOOL>(0xA28410, invoke<BOOL>(0xA28420, invoke<BOOL>(0xA28430, inventory, invoke<BOOL>(0xA28450, p0, invoke<BOOL>(0xA28470, transactionId, categoryHash, actionHash, invoke<BOOL>(0xA28480, itemData, invoke<BOOL>(0xA284B0, p0, invoke<BOOL>(0xA284D0, invoke<BOOL>(0xA284E0, transactionId, categoryHash, itemHash, actionTypeHash, value, invoke<BOOL>(0xA28500, invoke<BOOL>(0xA28510, slot, transfer, invoke<BOOL>(0xA28520, charSlot, invoke<BOOL>(0xA28550, charSlot, invoke<BOOL>(0xA28560, invoke<BOOL>(0xA285A0, invoke<BOOL>(0xA4A0A0, p0, invoke<BOOL>(0xA4A0C0, p0, invoke<BOOL>(0xA4A160, p0, p1, invoke<BOOL>(0xA4A190, p0, p1, invoke<BOOL>(0xA4A1C0, p0, p1, invoke<BOOL>(0xA4A1F0, p0, p1, invoke<BOOL>(0xA4A2E0, NETWORK_SET_PRIVILEGE_CHECK_RESULT_NOT_NEEDED()
    return Velora.invoke(0xA4A370, "int", invoke<int>(0xA26FF0, char>(0xA270B0, amount, invoke<BOOL>(0xA27180, invoke<BOOL>(0xA271B0, amount, invoke<BOOL>(0xA271E0, invoke<BOOL>(0xA27240, p0, p1, p2, invoke<BOOL>(0xA272D0, invoke<int>(0xA27340, invoke<BOOL>(0xA27370, invoke<BOOL>(0xA273A0, invoke<BOOL>(0xA273B0, invoke<BOOL>(0xA28330, invoke<BOOL>(0xA28340, itemHash, categoryHash, invoke<int>(0xA28350, invoke<BOOL>(0xA283A0, invoke<BOOL>(0xA283C0, invoke<BOOL>(0xA283D0, invoke<BOOL>(0xA283F0, invoke<BOOL>(0xA28400, invoke<BOOL>(0xA28410, invoke<BOOL>(0xA28420, invoke<BOOL>(0xA28430, inventory, invoke<BOOL>(0xA28450, p0, invoke<BOOL>(0xA28470, transactionId, categoryHash, actionHash, invoke<BOOL>(0xA28480, itemData, invoke<BOOL>(0xA284B0, p0, invoke<BOOL>(0xA284D0, invoke<BOOL>(0xA284E0, transactionId, categoryHash, itemHash, actionTypeHash, value, invoke<BOOL>(0xA28500, invoke<BOOL>(0xA28510, slot, transfer, invoke<BOOL>(0xA28520, charSlot, invoke<BOOL>(0xA28550, charSlot, invoke<BOOL>(0xA28560, invoke<BOOL>(0xA285A0, invoke<BOOL>(0xA4A0A0, p0, invoke<BOOL>(0xA4A0C0, p0, invoke<BOOL>(0xA4A160, p0, p1, invoke<BOOL>(0xA4A190, p0, p1, invoke<BOOL>(0xA4A1C0, p0, p1, invoke<BOOL>(0xA4A1F0, p0, p1, invoke<BOOL>(0xA4A2E0, NETWORK_SET_PRIVILEGE_CHECK_RESULT_NOT_NEEDED()
end

function NETWORK_RESOLVE_PRIVILEGE_USER_CONTENT(NETWORK_SHOW_ACCOUNT_UPGRADE_UI()
    return Velora.invoke(0xA4A3F0, "bool", NETWORK_SHOW_ACCOUNT_UPGRADE_UI()
end

function NETWORK_IS_SHOWING_SYSTEM_UI_OR_RECENTLY_REQUESTED_UPSELL(p0, p1, p2)
    return Velora.invoke(0xA4A480, "bool", p0, p1, p2)
end

function NETWORK_ON_RETURN_TO_SINGLE_PLAYER()
    Velora.invoke(0xA4A540, "void")
end

function NETWORK_TRANSITION_START(p0, p1, p2, invoke<BOOL>(0xA4A550, hash, p1, p2, state, invoke<BOOL>(0xA4A570, p0, p1, invoke<BOOL>(0xA4A590, invoke<BOOL>(0xA4A5B0, p0, p1, p2, invoke<BOOL>(0xA4A6F0, p0, p1, invoke<BOOL>(0xA4A740, crewId, p1, p2, invoke<BOOL>(0xA4A7A0, p0, p1, p2, p3, invoke<BOOL>(0xA4A8A0, p0, maxPlayers, invoke<BOOL>(0xA4A910, p0, invoke<BOOL>(0xA4A970, p0, invoke<BOOL>(0xA4A9D0, p0, invoke<BOOL>(0xDEADBEEF, invoke<BOOL>(0xA4AB40, player)
    return Velora.invoke(0xA4AB80, "bool", p0, p1, p2, invoke<BOOL>(0xA4A550, hash, p1, p2, state, invoke<BOOL>(0xA4A570, p0, p1, invoke<BOOL>(0xA4A590, invoke<BOOL>(0xA4A5B0, p0, p1, p2, invoke<BOOL>(0xA4A6F0, p0, p1, invoke<BOOL>(0xA4A740, crewId, p1, p2, invoke<BOOL>(0xA4A7A0, p0, p1, p2, p3, invoke<BOOL>(0xA4A8A0, p0, maxPlayers, invoke<BOOL>(0xA4A910, p0, invoke<BOOL>(0xA4A970, p0, invoke<BOOL>(0xA4A9D0, p0, invoke<BOOL>(0xDEADBEEF, invoke<BOOL>(0xA4AB40, player)
end

function NETWORK_SESSION_GET_KICK_VOTE(invoke<BOOL>(0xA4ABE0, p0, p1, invoke<BOOL>(0xA4AC30, matchmakingGroup)
    return Velora.invoke(0xA4ACC0, "bool", invoke<BOOL>(0xA4ABE0, p0, p1, invoke<BOOL>(0xA4AC30, matchmakingGroup)
end

function NETWORK_SESSION_SET_MATCHMAKING_GROUP_MAX(playerType, playerCount)
    Velora.invoke(0xA4ACE0, "void", playerType, playerCount)
end

function NETWORK_SESSION_GET_MATCHMAKING_GROUP_FREE(invoke<int>(0xA4AD10, groupId)
    return Velora.invoke(0xA4AD50, "int", invoke<int>(0xA4AD10, groupId)
end

function NETWORK_SESSION_SET_UNIQUE_CREW_LIMIT(p0)
    Velora.invoke(0xA4AD70, "void", p0)
end

function NETWORK_SESSION_SET_UNIQUE_CREW_LIMIT_TRANSITION(p0)
    Velora.invoke(0xA4ADC0, "void", p0)
end

function NETWORK_SESSION_SET_UNIQUE_CREW_ONLY_CREWS_TRANSITION(p0)
    Velora.invoke(0xA4ADE0, "void", p0)
end

function NETWORK_SESSION_SET_CREW_LIMIT_MAX_MEMBERS_TRANSITION(p0)
    Velora.invoke(0xA4AE10, "void", p0)
end

function NETWORK_SESSION_SET_MATCHMAKING_PROPERTY_ID(p0)
    Velora.invoke(0xA4AE30, "void", p0)
end

function NETWORK_SESSION_SET_MATCHMAKING_MENTAL_STATE(p0)
    Velora.invoke(0xA4AE50, "void", p0)
end

function NETWORK_SESSION_SET_NUM_BOSSES(num)
    Velora.invoke(0xA4AE80, "void", num)
end

function NETWORK_SESSION_SET_SCRIPT_VALIDATE_JOIN()
    Velora.invoke(0xA4AE90, "void")
end

function NETWORK_SESSION_VALIDATE_JOIN(p0)
    Velora.invoke(0xA4AEA0, "void", p0)
end

function NETWORK_ADD_FOLLOWERS(p0, p1)
    Velora.invoke(0xA4AEC0, "void", p0, p1)
end

function NETWORK_CLEAR_FOLLOWERS()
    Velora.invoke(0xA4AED0, "void")
end

function NETWORK_GET_GLOBAL_MULTIPLAYER_CLOCK(hours, minutes, seconds)
    Velora.invoke(0xA4AEE0, "void", hours, minutes, seconds)
end

function NETWORK_SESSION_SET_GAMEMODE(p0)
    Velora.invoke(0xA4AF00, "void", p0)
end

function NETWORK_SESSION_GET_HOST_AIM_PREFERENCE(invoke<BOOL>(0xA4AF30, attribute, fallbackLimit, lowerLimit, invoke<BOOL>(0xA4B000, p0, invoke<BOOL>(0xA4B0A0, NETWORK_CLEAR_FOUND_GAMERS()
    return Velora.invoke(0xA4B160, "int", invoke<BOOL>(0xA4AF30, attribute, fallbackLimit, lowerLimit, invoke<BOOL>(0xA4B000, p0, invoke<BOOL>(0xA4B0A0, NETWORK_CLEAR_FOUND_GAMERS()
end

function NETWORK_QUEUE_GAMER_FOR_STATUS(invoke<BOOL>(0xA4B170, p0, invoke<BOOL>(0xA4B250, NETWORK_CLEAR_GET_GAMER_STATUS()
    return Velora.invoke(0xA4B300, "bool", invoke<BOOL>(0xA4B170, p0, invoke<BOOL>(0xA4B250, NETWORK_CLEAR_GET_GAMER_STATUS()
end

function NETWORK_SESSION_JOIN_INVITE()
    Velora.invoke(0xA4B310, "void")
end

function NETWORK_SESSION_CANCEL_INVITE()
    Velora.invoke(0xA4B320, "void")
end

function NETWORK_SESSION_FORCE_CANCEL_INVITE()
    Velora.invoke(0xA4B350, "void")
end

function NETWORK_HAS_PENDING_INVITE(gamerHandle)
    return Velora.invoke(0xA4B440, "bool", gamerHandle)
end

function NETWORK_SESSION_IS_AWAITING_INVITE_RESPONSE(toggle)
    return Velora.invoke(0xA4B4D0, "bool", toggle)
end

function NETWORK_BLOCK_INVITES(toggle)
    Velora.invoke(0xA4B4F0, "void", toggle)
end

function NETWORK_BLOCK_JOIN_QUEUE_INVITES(toggle)
    Velora.invoke(0xA4B510, "void", toggle)
end

function NETWORK_SET_CAN_RECEIVE_RS_INVITES(p0)
    Velora.invoke(0xA4B530, "void", p0)
end

function NETWORK_STORE_INVITE_THROUGH_RESTART()
    Velora.invoke(0xA4B550, "void")
end

function NETWORK_ALLOW_INVITE_PROCESS_IN_PLAYER_SWITCH(p0)
    Velora.invoke(0xA4B560, "void", p0)
end

function NETWORK_SET_SCRIPT_READY_FOR_EVENTS(toggle)
    Velora.invoke(0xA4B580, "void", toggle)
end

function NETWORK_IS_OFFLINE_INVITE_PENDING(NETWORK_CLEAR_OFFLINE_INVITE_PENDING()
    return Velora.invoke(0xA4B5C0, "bool", NETWORK_CLEAR_OFFLINE_INVITE_PENDING()
end

function NETWORK_SESSION_HOST_SINGLE_PLAYER(p0)
    Velora.invoke(0xA4B610, "void", p0)
end

function NETWORK_SESSION_LEAVE_SINGLE_PLAYER()
    Velora.invoke(0xA4B630, "void")
end

function NETWORK_IS_GAME_IN_PROGRESS(toggle)
    return Velora.invoke(0xA4B750, "bool", toggle)
end

function NETWORK_SESSION_IS_VISIBLE(toggle)
    return Velora.invoke(0xA4B7E0, "bool", toggle)
end

function NETWORK_SESSION_CHANGE_SLOTS(slots, p1)
    Velora.invoke(0xA4B830, "void", slots, p1)
end

function NETWORK_SESSION_GET_PRIVATE_SLOTS(gamerHandle)
    return Velora.invoke(0xA4B900, "int", gamerHandle)
end

function NETWORK_SESSION_VOICE_RESPOND_TO_REQUEST(p0, p1)
    Velora.invoke(0xA4B980, "void", p0, p1)
end

function NETWORK_SESSION_VOICE_SET_TIMEOUT(timeout)
    Velora.invoke(0xA4B9A0, "void", timeout)
end

function NETWORK_SESSION_IS_IN_VOICE_SESSION(message, invoke<BOOL>(0xA4BA50, toggle)
    return Velora.invoke(0xA4BAE0, "bool", message, invoke<BOOL>(0xA4BA50, toggle)
end

function NETWORK_IS_ACTIVITY_SPECTATOR(p0)
    return Velora.invoke(0xA4BB20, "bool", p0)
end

function NETWORK_SET_ACTIVITY_SPECTATOR_MAX(maxSpectators)
    Velora.invoke(0xA4BB40, "void", maxSpectators)
end

function NETWORK_GET_ACTIVITY_PLAYER_NUM(invoke<int>(0xA4BB60, invoke<BOOL>(0xA4BBA0, p0, p1, p2, p3, p4, p5, p6, p7, p8, invoke<BOOL>(0xA4BC30, p0, p1, p2, p3, p4, invoke<BOOL>(0xA4BD00, p0, p1, p2, p3, p4, invoke<BOOL>(0xA4BDA0, p0, p1, p2, p3, p4, p5, p6, invoke<BOOL>(0xA4BE40, NETWORK_CLEAR_GROUP_ACTIVITY()
    return Velora.invoke(0xA4BEC0, "int", invoke<int>(0xA4BB60, invoke<BOOL>(0xA4BBA0, p0, p1, p2, p3, p4, p5, p6, p7, p8, invoke<BOOL>(0xA4BC30, p0, p1, p2, p3, p4, invoke<BOOL>(0xA4BD00, p0, p1, p2, p3, p4, invoke<BOOL>(0xA4BDA0, p0, p1, p2, p3, p4, p5, p6, invoke<BOOL>(0xA4BE40, NETWORK_CLEAR_GROUP_ACTIVITY()
end

function NETWORK_RETAIN_ACTIVITY_GROUP()
    Velora.invoke(0xA4BED0, "void")
end

function NETWORK_IS_TRANSITION_CLOSED_FRIENDS(p0)
    return Velora.invoke(0xA4BFD0, "bool", p0)
end

function NETWORK_MARK_AS_WAITING_ASYNC(p0)
    Velora.invoke(0xA4BFF0, "void", p0)
end

function NETWORK_SET_IN_PROGRESS_FINISH_TIME(p0)
    Velora.invoke(0xA4C010, "void", p0)
end

function NETWORK_SET_TRANSITION_CREATOR_HANDLE(p0)
    Velora.invoke(0xA4C030, "void", p0)
end

function NETWORK_CLEAR_TRANSITION_CREATOR_HANDLE()
    Velora.invoke(0xA4C0B0, "void")
end

function NETWORK_INVITE_GAMERS_TO_TRANSITION(p0, invoke<BOOL>(0xA4C110, gamerHandle)
    return Velora.invoke(0xA4C140, "bool", p0, invoke<BOOL>(0xA4C110, gamerHandle)
end

function NETWORK_LEAVE_TRANSITION(toggle)
    return Velora.invoke(0xA4C250, "bool", toggle)
end

function NETWORK_CANCEL_TRANSITION_MATCHMAKING()
    Velora.invoke(0xA4C270, "void")
end

function NETWORK_BAIL_TRANSITION(p0, p1, p2)
    Velora.invoke(0xA4C280, "void", p0, p1, p2)
end

function NETWORK_DO_TRANSITION_TO_GAME(p0, invoke<BOOL>(0xA4C2B0, p0, maxPlayers, invoke<BOOL>(0xA4C2E0, p0, p1, p2, players, invoke<BOOL>(0xA4C320, p0, p1, players, p3, p4, invoke<BOOL>(0xA4C360, data, invoke<int>(0xA4C3F0, p0, p1)
    return Velora.invoke(0xA4C420, "bool", p0, invoke<BOOL>(0xA4C2B0, p0, maxPlayers, invoke<BOOL>(0xA4C2E0, p0, p1, p2, players, invoke<BOOL>(0xA4C320, p0, p1, players, p3, p4, invoke<BOOL>(0xA4C360, data, invoke<int>(0xA4C3F0, p0, p1)
end

function NETWORK_APPLY_TRANSITION_PARAMETER_STRING(p0, string, p2)
    Velora.invoke(0xA4C440, "void", p0, string, p2)
end

function NETWORK_SEND_TRANSITION_GAMER_INSTRUCTION(gamerHandle, p1, p2, p3, invoke<BOOL>(0xA4C470, invoke<BOOL>(0xA4C540, invoke<BOOL>(0xA4C610, invoke<BOOL>(0xA4C6C0, p0)
    return Velora.invoke(0xA4C7F0, "bool", gamerHandle, p1, p2, p3, invoke<BOOL>(0xA4C470, invoke<BOOL>(0xA4C540, invoke<BOOL>(0xA4C610, invoke<BOOL>(0xA4C6C0, p0)
end

function NETWORK_TRANSITION_SET_CONTENT_CREATOR(p0)
    Velora.invoke(0xA4C820, "void", p0)
end

function NETWORK_TRANSITION_SET_ACTIVITY_ISLAND(p0)
    Velora.invoke(0xA4C840, "void", p0)
end

function NETWORK_OPEN_TRANSITION_MATCHMAKING()
    Velora.invoke(0xA4C870, "void")
end

function NETWORK_CLOSE_TRANSITION_MATCHMAKING()
    Velora.invoke(0xA4C890, "void")
end

function NETWORK_IS_TRANSITION_OPEN_TO_MATCHMAKING(p0, p1)
    return Velora.invoke(0xA4C8E0, "bool", p0, p1)
end

function NETWORK_IS_TRANSITION_VISIBILITY_LOCKED(p0)
    return Velora.invoke(0xA4C940, "bool", p0)
end

function NETWORK_CHANGE_TRANSITION_SLOTS(p0, p1)
    Velora.invoke(0xA4C990, "void", p0, p1)
end

function NETWORK_TRANSITION_BLOCK_JOIN_REQUESTS(p0)
    Velora.invoke(0xA4C9F0, "void", p0)
end

function NETWORK_HAS_PLAYER_STARTED_TRANSITION(invoke<BOOL>(0xA4CA40, invoke<BOOL>(0xA4CA90, invoke<BOOL>(0xA4CAF0, invoke<BOOL>(0xA4CB50, invoke<BOOL>(0xA4CBE0, NETWORK_DISABLE_REALTIME_MULTIPLAYER()
    return Velora.invoke(0xA4CCA0, "bool", invoke<BOOL>(0xA4CA40, invoke<BOOL>(0xA4CA90, invoke<BOOL>(0xA4CAF0, invoke<BOOL>(0xA4CB50, invoke<BOOL>(0xA4CBE0, NETWORK_DISABLE_REALTIME_MULTIPLAYER()
end

function NETWORK_SET_PRESENCE_SESSION_INVITES_BLOCKED(toggle)
    Velora.invoke(0xA4CCB0, "void", toggle)
end

function NETWORK_SEND_INVITE_VIA_PRESENCE(gamerHandle, p1, dataCount, invoke<BOOL>(0xA4CCE0, gamerHandle, p1, dataCount, invoke<BOOL>(0xA4CDB0, gamerHandle, p1, dataCount, invoke<BOOL>(0xA4CE80, invoke<int>(0xA4CF50, invoke<BOOL>(0xA4CFB0, invoke<BOOL>(0xA4CFE0, invoke<int>(0xA4D010, char>(0xA4D040, p0, invoke<BOOL>(0xA4D070, invoke<int>(0xA4D100, char>(0xA4D120, invoke<int>(0xA4D150, invoke<int>(0xA4D180, invoke<BOOL>(0xA4D1B0, invoke<BOOL>(0xA4D1E0, NETWORK_REMOVE_AND_CANCEL_ALL_INVITES()
    return Velora.invoke(0xA4D2A0, "bool", gamerHandle, p1, dataCount, invoke<BOOL>(0xA4CCE0, gamerHandle, p1, dataCount, invoke<BOOL>(0xA4CDB0, gamerHandle, p1, dataCount, invoke<BOOL>(0xA4CE80, invoke<int>(0xA4CF50, invoke<BOOL>(0xA4CFB0, invoke<BOOL>(0xA4CFE0, invoke<int>(0xA4D010, char>(0xA4D040, p0, invoke<BOOL>(0xA4D070, invoke<int>(0xA4D100, char>(0xA4D120, invoke<int>(0xA4D150, invoke<int>(0xA4D180, invoke<BOOL>(0xA4D1B0, invoke<BOOL>(0xA4D1E0, NETWORK_REMOVE_AND_CANCEL_ALL_INVITES()
end

function NETWORK_REMOVE_TRANSITION_INVITE(p0)
    Velora.invoke(0xA4D2B0, "void", p0)
end

function NETWORK_REMOVE_ALL_TRANSITION_INVITE()
    Velora.invoke(0xA4D330, "void")
end

function NETWORK_REMOVE_AND_CANCEL_ALL_TRANSITION_INVITES()
    Velora.invoke(0xA4D340, "void")
end

function NETWORK_INVITE_GAMERS(p0, p1, p2, invoke<BOOL>(0xA4D350, invoke<BOOL>(0xA4D380, invoke<BOOL>(0xA4D420, invoke<int>(0xA4D4B0, invoke<BOOL>(0xA4D540, invoke<BOOL>(0xA4D5A0, p0)
    return Velora.invoke(0xA4D670, "bool", p0, p1, p2, invoke<BOOL>(0xA4D350, invoke<BOOL>(0xA4D380, invoke<BOOL>(0xA4D420, invoke<int>(0xA4D4B0, invoke<BOOL>(0xA4D540, invoke<BOOL>(0xA4D5A0, p0)
end

function NETWORK_CHECK_DATA_MANAGER_SUCCEEDED_FOR_HANDLE(p0, invoke<BOOL>(0xA4D680, p0, invoke<BOOL>(0xA4D740, p0, p1)
    return Velora.invoke(0xA4D800, "bool", p0, invoke<BOOL>(0xA4D680, p0, invoke<BOOL>(0xA4D740, p0, p1)
end

function FILLOUT_PM_PLAYER_LIST(gamerHandle, p1, invoke<BOOL>(0xA4D810, p0, p1, p2, invoke<BOOL>(0xA4D840, invoke<BOOL>(0xA4D870, invoke<BOOL>(0xA4D8A0, data, invoke<int>(0xA4D990, invoke<BOOL>(0xA4D9E0, NETWORK_CLEAR_QUEUED_JOIN_REQUEST()
    return Velora.invoke(0xA4DAC0, "bool", gamerHandle, p1, invoke<BOOL>(0xA4D810, p0, p1, p2, invoke<BOOL>(0xA4D840, invoke<BOOL>(0xA4D870, invoke<BOOL>(0xA4D8A0, data, invoke<int>(0xA4D990, invoke<BOOL>(0xA4D9E0, NETWORK_CLEAR_QUEUED_JOIN_REQUEST()
end

function NETWORK_SEND_QUEUED_JOIN_REQUEST()
    Velora.invoke(0xA4DAD0, "void")
end

function NETWORK_REMOVE_ALL_QUEUED_JOIN_REQUESTS()
    Velora.invoke(0xA4DAE0, "void")
end

function NETWORK_SEED_RANDOM_NUMBER_GENERATOR(seed)
    Velora.invoke(0xA4DAF0, "void", seed)
end

function NETWORK_GET_RANDOM_INT(rangeStart, invoke<int>(0xA4DB70, rangeStart, invoke<float>(0xA4DBD0, player, p1, invoke<BOOL>(0xDEADBEEF, player, p1, invoke<BOOL>(0xDEADBEEF, player, invoke<BOOL>(0xDEADBEEF, player, a, invoke<BOOL>(0xA4DD00, gamerHandle, event, invoke<BOOL>(0xA4DD70, modelHash)
    return Velora.invoke(0xA4DE20, "int", rangeStart, invoke<int>(0xA4DB70, rangeStart, invoke<float>(0xA4DBD0, player, p1, invoke<BOOL>(0xDEADBEEF, player, p1, invoke<BOOL>(0xDEADBEEF, player, invoke<BOOL>(0xDEADBEEF, player, a, invoke<BOOL>(0xA4DD00, gamerHandle, event, invoke<BOOL>(0xA4DD70, modelHash)
end

function NETWORK_REMOVE_INVALID_OBJECT_MODEL(modelHash)
    Velora.invoke(0xA4DEA0, "void", modelHash)
end

function NETWORK_CLEAR_INVALID_OBJECT_MODELS()
    Velora.invoke(0xA4DF20, "void")
end

function NETWORK_APPLY_PED_SCAR_DATA(ped, p1)
    Velora.invoke(0xA4DF40, "void", ped, p1)
end

function NETWORK_SET_THIS_SCRIPT_IS_NETWORK_SCRIPT(maxNumMissionParticipants, p1, instanceId)
    Velora.invoke(0xA4DFA0, "void", maxNumMissionParticipants, p1, instanceId)
end

function NETWORK_TRY_TO_SET_THIS_SCRIPT_IS_NETWORK_SCRIPT(p0, p1, invoke<BOOL>(0xA4E010, vars, numVars, debugName)
    return Velora.invoke(0xA4E170, "bool", p0, p1, invoke<BOOL>(0xA4E010, vars, numVars, debugName)
end

function NETWORK_REGISTER_PLAYER_BROADCAST_VARIABLES(vars, numVars, debugName)
    Velora.invoke(0xA4E190, "void", vars, numVars, debugName)
end

function NETWORK_REGISTER_HIGH_FREQUENCY_HOST_BROADCAST_VARIABLES(p0, p1, p2)
    Velora.invoke(0xA4E1B0, "void", p0, p1, p2)
end

function NETWORK_REGISTER_HIGH_FREQUENCY_PLAYER_BROADCAST_VARIABLES(p0, p1, p2)
    Velora.invoke(0xA4E1D0, "void", p0, p1, p2)
end

function NETWORK_FINISH_BROADCASTING_DATA()
    Velora.invoke(0xA4E1F0, "void")
end

function NETWORK_HAS_RECEIVED_HOST_BROADCAST_DATA(invoke<Player>(0xA4E510, invoke<int>(0xA4E5E0, invoke<Player>(0xA4E660, invoke<BOOL>(0xA4E710, invoke<BOOL>(0xA4E790, invoke<BOOL>(0xA4E7D0, invoke<BOOL>(0xA4E800, scriptName, instance_id, invoke<Player>(0xA4E8B0, NETWORK_SET_MISSION_FINISHED()
    return Velora.invoke(0xA4E980, "bool", invoke<Player>(0xA4E510, invoke<int>(0xA4E5E0, invoke<Player>(0xA4E660, invoke<BOOL>(0xA4E710, invoke<BOOL>(0xA4E790, invoke<BOOL>(0xA4E7D0, invoke<BOOL>(0xA4E800, scriptName, instance_id, invoke<Player>(0xA4E8B0, NETWORK_SET_MISSION_FINISHED()
end

function NETWORK_IS_SCRIPT_ACTIVE(scriptName, instance_id, p2, invoke<BOOL>(0xA4E9B0, scriptHash, p1, p2, invoke<BOOL>(0xA4EAC0, invoke<BOOL>(0xA4EB80, scriptName, instance_id, invoke<int>(0xA4EBD0, player, script, invoke<BOOL>(0xA4ED60, NETWORK_PREVENT_SCRIPT_HOST_MIGRATION()
    return Velora.invoke(0xA4ED90, "bool", scriptName, instance_id, p2, invoke<BOOL>(0xA4E9B0, scriptHash, p1, p2, invoke<BOOL>(0xA4EAC0, invoke<BOOL>(0xA4EB80, scriptName, instance_id, invoke<int>(0xA4EBD0, player, script, invoke<BOOL>(0xA4ED60, NETWORK_PREVENT_SCRIPT_HOST_MIGRATION()
end

function NETWORK_REQUEST_TO_BE_HOST_OF_THIS_SCRIPT()
    Velora.invoke(0xA4EDC0, "void")
end

function PARTICIPANT_ID(player, invoke<Player>(0xA4EE70, netId, invoke<Player>(0xA4EEE0, entity, invoke<Player>(0xA4EF10, player, entity, invoke<BOOL>(0xA4EF40, player, entity, invoke<BOOL>(0xA4EF70, player, invoke<Entity>(0xA4EFA0, missionId)
    Velora.invoke(0xA4EFD0, "void", player, invoke<Player>(0xA4EE70, netId, invoke<Player>(0xA4EEE0, entity, invoke<Player>(0xA4EF10, player, entity, invoke<BOOL>(0xA4EF40, player, entity, invoke<BOOL>(0xA4EF70, player, invoke<Entity>(0xA4EFA0, missionId)
end

function NETWORK_SET_CURRENT_CHAT_OPTION(newChatOption)
    Velora.invoke(0xA4F010, "void", newChatOption)
end

function NETWORK_SET_CURRENT_SPAWN_LOCATION_OPTION(mpSettingSpawn)
    Velora.invoke(0xA4F040, "void", mpSettingSpawn)
end

function NETWORK_SET_VEHICLE_DRIVEN_IN_TEST_DRIVE(toggle)
    Velora.invoke(0xA4F070, "void", toggle)
end

function NETWORK_RESURRECT_LOCAL_PLAYER(x, y, z, heading, p4, changetime, p6, p7, p8)
    Velora.invoke(0xA4F0E0, "void", x, y, z, heading, p4, changetime, p6, p7, p8)
end

function NETWORK_SET_LOCAL_PLAYER_INVINCIBLE_TIME(time)
    Velora.invoke(0xA4F110, "void", time)
end

function NETWORK_IS_LOCAL_PLAYER_INVINCIBLE(player, toggle)
    return Velora.invoke(0xA4F190, "bool", player, toggle)
end

function NETWORK_PATCH_POST_CUTSCENE_HS4F_TUN_ENT(ped)
    Velora.invoke(0xA4F1E0, "void", ped)
end

function NETWORK_SET_LOCAL_PLAYER_SYNC_LOOK_AT(toggle)
    Velora.invoke(0xA4F240, "void", toggle)
end

function NETWORK_HAS_ENTITY_BEEN_REGISTERED_WITH_THIS_THREAD(invoke<BOOL>(0xA4F280, invoke<int>(0xA4F2E0, invoke<Entity>(0xA4F340, invoke<BOOL>(0xA4F380, invoke<BOOL>(0xA4F3E0, entity)
    return Velora.invoke(0xA4F450, "bool", invoke<BOOL>(0xA4F280, invoke<int>(0xA4F2E0, invoke<Entity>(0xA4F340, invoke<BOOL>(0xA4F380, invoke<BOOL>(0xA4F3E0, entity)
end

function NETWORK_UNREGISTER_NETWORKED_ENTITY(entity)
    Velora.invoke(0xA4F520, "void", entity)
end

function NETWORK_DOES_NETWORK_ID_EXIST(invoke<BOOL>(0xA4F5C0, invoke<BOOL>(0xA4F600, invoke<BOOL>(0xA4F640, invoke<BOOL>(0xA4F6B0, invoke<BOOL>(0xA4F730, invoke<BOOL>(0xA4F780, invoke<BOOL>(0xA4F7B0, invoke<BOOL>(0xA4F820, invoke<BOOL>(0xA4F890, invoke<BOOL>(0xA4F8C0, invoke<BOOL>(0xA4F910, invoke<int>(0xA4F950, invoke<int>(0xA4F9B0, invoke<int>(0xA4FA10, invoke<Vehicle>(0xA4FA70, invoke<Ped>(0xA4FAB0, invoke<Object>(0xA4FAF0, invoke<Entity>(0xA4FB30, gamerHandle, gamerHandleSize)
    return Velora.invoke(0xA4FB70, "bool", invoke<BOOL>(0xA4F5C0, invoke<BOOL>(0xA4F600, invoke<BOOL>(0xA4F640, invoke<BOOL>(0xA4F6B0, invoke<BOOL>(0xA4F730, invoke<BOOL>(0xA4F780, invoke<BOOL>(0xA4F7B0, invoke<BOOL>(0xA4F820, invoke<BOOL>(0xA4F890, invoke<BOOL>(0xA4F8C0, invoke<BOOL>(0xA4F910, invoke<int>(0xA4F950, invoke<int>(0xA4F9B0, invoke<int>(0xA4FA10, invoke<Vehicle>(0xA4FA70, invoke<Ped>(0xA4FAB0, invoke<Object>(0xA4FAF0, invoke<Entity>(0xA4FB30, gamerHandle, gamerHandleSize)
end

function NETWORK_HANDLE_FROM_USER_ID(userId, gamerHandle, gamerHandleSize)
    Velora.invoke(0xA4FBB0, "void", userId, gamerHandle, gamerHandleSize)
end

function NETWORK_HANDLE_FROM_MEMBER_ID(memberId, gamerHandle, gamerHandleSize)
    Velora.invoke(0xA4FC30, "void", memberId, gamerHandle, gamerHandleSize)
end

function NETWORK_HANDLE_FROM_PLAYER(player, gamerHandle, gamerHandleSize)
    Velora.invoke(0xA4FCB0, "void", player, gamerHandle, gamerHandleSize)
end

function NETWORK_HASH_FROM_PLAYER_HANDLE(invoke<Hash>(0xA4FD20, invoke<Hash>(0xA4FD40, friendIndex, gamerHandle, gamerHandleSize)
    return Velora.invoke(0xA4FDF0, "int", invoke<Hash>(0xA4FD20, invoke<Hash>(0xA4FD40, friendIndex, gamerHandle, gamerHandleSize)
end

function NETWORK_GAMERTAG_FROM_HANDLE_START(invoke<BOOL>(0xA4FEA0, char>(0xA4FED0, p0, invoke<int>(0xA4FF80, p0, p1, invoke<int>(0xA50080, gamerHandle1, invoke<BOOL>(0xA50190, gamerHandle, invoke<BOOL>(0xA50240, invoke<Player>(0xA50270, char>(0xA502A0, invoke<BOOL>(0xA50330, gamerHandle)
    return Velora.invoke(0xA503C0, "bool", invoke<BOOL>(0xA4FEA0, char>(0xA4FED0, p0, invoke<int>(0xA4FF80, p0, p1, invoke<int>(0xA50080, gamerHandle1, invoke<BOOL>(0xA50190, gamerHandle, invoke<BOOL>(0xA50240, invoke<Player>(0xA50270, char>(0xA502A0, invoke<BOOL>(0xA50330, gamerHandle)
end

function NETWORK_PLAYER_GET_NAME(char>(0xA50430, player, char>(0xA504B0, invoke<BOOL>(0xA504E0, invoke<BOOL>(0xA50530, invoke<int>(0xA505B0, invoke<Entity>(0xA50620, invoke<BOOL>(0xA50680, char>(0xA50760, char>(0xA507B0, invoke<BOOL>(0xA50800, invoke<BOOL>(0xA50850, invoke<BOOL>(0xA50880, invoke<BOOL>(0xA50900, invoke<BOOL>(0xA50950, invoke<BOOL>(0xA509E0, gamerHandle, invoke<BOOL>(0xA50A10, invoke<BOOL>(0xA50AA0, toggle)
    return Velora.invoke(0xA50AF0, "string", char>(0xA50430, player, char>(0xA504B0, invoke<BOOL>(0xA504E0, invoke<BOOL>(0xA50530, invoke<int>(0xA505B0, invoke<Entity>(0xA50620, invoke<BOOL>(0xA50680, char>(0xA50760, char>(0xA507B0, invoke<BOOL>(0xA50800, invoke<BOOL>(0xA50850, invoke<BOOL>(0xA50880, invoke<BOOL>(0xA50900, invoke<BOOL>(0xA50950, invoke<BOOL>(0xA509E0, gamerHandle, invoke<BOOL>(0xA50A10, invoke<BOOL>(0xA50AA0, toggle)
end

function NETWORK_GET_PLAYER_OWNS_WAYPOINT(invoke<BOOL>(0xA50B40, NETWORK_IGNORE_REMOTE_WAYPOINTS()
    return Velora.invoke(0xA50BD0, "bool", invoke<BOOL>(0xA50B40, NETWORK_IGNORE_REMOTE_WAYPOINTS()
end

function NETWORK_IS_PLAYER_ON_BLOCKLIST(invoke<BOOL>(0xA50E10, invoke<BOOL>(0xA50E90, p0)
    return Velora.invoke(0xA50F20, "bool", invoke<BOOL>(0xA50E10, invoke<BOOL>(0xA50E90, p0)
end

function NETWORK_IS_PUSH_TO_TALK_ACTIVE(invoke<BOOL>(0xA50F60, invoke<BOOL>(0xA50FF0, invoke<BOOL>(0xA51020, invoke<BOOL>(0xA510B0, invoke<BOOL>(0xA51150, invoke<BOOL>(0xA511E0, invoke<BOOL>(0xA51270, invoke<BOOL>(0xA51300, invoke<BOOL>(0xA51390, invoke<BOOL>(0xA51420, invoke<BOOL>(0xA514B0, invoke<BOOL>(0xA515D0, invoke<BOOL>(0xA51660, invoke<BOOL>(0xA516F0, invoke<BOOL>(0xA51770, invoke<BOOL>(0xA51800, invoke<BOOL>(0xA51860, invoke<BOOL>(0xA518C0, invoke<BOOL>(0xA51920, invoke<BOOL>(0xA51980, invoke<BOOL>(0xA519E0, invoke<float>(0xA51A40, value)
    return Velora.invoke(0xA51AA0, "bool", invoke<BOOL>(0xA50F60, invoke<BOOL>(0xA50FF0, invoke<BOOL>(0xA51020, invoke<BOOL>(0xA510B0, invoke<BOOL>(0xA51150, invoke<BOOL>(0xA511E0, invoke<BOOL>(0xA51270, invoke<BOOL>(0xA51300, invoke<BOOL>(0xA51390, invoke<BOOL>(0xA51420, invoke<BOOL>(0xA514B0, invoke<BOOL>(0xA515D0, invoke<BOOL>(0xA51660, invoke<BOOL>(0xA516F0, invoke<BOOL>(0xA51770, invoke<BOOL>(0xA51800, invoke<BOOL>(0xA51860, invoke<BOOL>(0xA518C0, invoke<BOOL>(0xA51920, invoke<BOOL>(0xA51980, invoke<BOOL>(0xA519E0, invoke<float>(0xA51A40, value)
end

function NETWORK_GET_TALKER_PROXIMITY(toggle)
    return Velora.invoke(0xA51AF0, "float", toggle)
end

function NETWORK_REMAIN_IN_GAME_CHAT(p0)
    Velora.invoke(0xA51B10, "void", p0)
end

function NETWORK_OVERRIDE_TRANSITION_CHAT(p0)
    Velora.invoke(0xA51B30, "void", p0)
end

function NETWORK_SET_TEAM_ONLY_CHAT(toggle)
    Velora.invoke(0xA51B50, "void", toggle)
end

function NETWORK_SET_SCRIPT_CONTROLLING_TEAMS(p0)
    Velora.invoke(0xA51B70, "void", p0)
end

function NETWORK_SET_SAME_TEAM_AS_LOCAL_PLAYER(p0, invoke<BOOL>(0xA51B80, team, toggle)
    return Velora.invoke(0xA51B90, "bool", p0, invoke<BOOL>(0xA51B80, team, toggle)
end

function NETWORK_SET_OVERRIDE_SPECTATOR_MODE(toggle)
    Velora.invoke(0xA51BC0, "void", toggle)
end

function NETWORK_SET_OVERRIDE_TUTORIAL_SESSION_CHAT(toggle)
    Velora.invoke(0xA51BE0, "void", toggle)
end

function NETWORK_SET_PROXIMITY_AFFECTS_TEAM(toggle)
    Velora.invoke(0xA51C00, "void", toggle)
end

function NETWORK_SET_NO_SPECTATOR_CHAT(toggle)
    Velora.invoke(0xA51C20, "void", toggle)
end

function NETWORK_SET_IGNORE_SPECTATOR_CHAT_LIMITS_SAME_TEAM(toggle)
    Velora.invoke(0xA51C40, "void", toggle)
end

function NETWORK_OVERRIDE_CHAT_RESTRICTIONS(player, toggle)
    Velora.invoke(0xA51C60, "void", player, toggle)
end

function NETWORK_OVERRIDE_SEND_RESTRICTIONS(player, toggle)
    Velora.invoke(0xA51CC0, "void", player, toggle)
end

function NETWORK_OVERRIDE_SEND_RESTRICTIONS_ALL(toggle)
    Velora.invoke(0xA51CF0, "void", toggle)
end

function NETWORK_OVERRIDE_RECEIVE_RESTRICTIONS(player, toggle)
    Velora.invoke(0xA51D10, "void", player, toggle)
end

function NETWORK_OVERRIDE_RECEIVE_RESTRICTIONS_ALL(toggle)
    Velora.invoke(0xA51D40, "void", toggle)
end

function NETWORK_SET_VOICE_CHANNEL(channel)
    Velora.invoke(0xA51D60, "void", channel)
end

function NETWORK_CLEAR_VOICE_CHANNEL()
    Velora.invoke(0xA51DB0, "void")
end

function NETWORK_APPLY_VOICE_PROXIMITY_OVERRIDE(x, y, z)
    Velora.invoke(0xA51DE0, "void", x, y, z)
end

function NETWORK_CLEAR_VOICE_PROXIMITY_OVERRIDE()
    Velora.invoke(0xA51E70, "void")
end

function NETWORK_ENABLE_VOICE_BANDWIDTH_RESTRICTION(player)
    Velora.invoke(0xA51EA0, "void", player)
end

function NETWORK_DISABLE_VOICE_BANDWIDTH_RESTRICTION(player)
    Velora.invoke(0xA51F00, "void", player)
end

function NETWORK_GET_MUTE_COUNT_FOR_PLAYER(p0, p1, p2)
    Velora.invoke(0xA51F60, "void", p0, p1, p2)
end

function NETWORK_SET_SPECTATOR_TO_NON_SPECTATOR_TEXT_CHAT(toggle)
    Velora.invoke(0xA51FB0, "void", toggle)
end

function NETWORK_TEXT_CHAT_IS_TYPING(SHUTDOWN_AND_LAUNCH_SINGLE_PLAYER_GAME()
    return Velora.invoke(0xA51FD0, "bool", SHUTDOWN_AND_LAUNCH_SINGLE_PLAYER_GAME()
end

function SHUTDOWN_AND_LOAD_MOST_RECENT_SAVE(toggle)
    return Velora.invoke(0xA52030, "bool", toggle)
end

function NETWORK_SET_RICH_PRESENCE(p0, p1, p2, p3)
    Velora.invoke(0xA52050, "void", p0, p1, p2, p3)
end

function NETWORK_SET_RICH_PRESENCE_STRING(p0, textLabel)
    Velora.invoke(0xA52060, "void", p0, textLabel)
end

function NETWORK_GET_TIMEOUT_TIME(player, x, y, z, p4, p5)
    return Velora.invoke(0xA52090, "int", player, x, y, z, p4, p5)
end

function NETWORK_LEAVE_PED_BEHIND_BEFORE_CUTSCENE(player, p1)
    Velora.invoke(0xA520C0, "void", player, p1)
end

function REMOVE_ALL_STICKY_BOMBS_FROM_ENTITY(entity, ped)
    Velora.invoke(0xA520E0, "void", entity, ped)
end

function NETWORK_KEEP_ENTITY_COLLISION_DISABLED_AFTER_ANIM_SCENE(p0, p1)
    Velora.invoke(0xA52170, "void", p0, p1)
end

function NETWORK_IS_ANY_PLAYER_NEAR(p0, p1, p2, p3, p4, p5, invoke<BOOL>(0xA521E0, invoke<BOOL>(0xA52250, clanDesc, bufferSize, invoke<BOOL>(0xA52300, clanDesc, invoke<BOOL>(0xA52330, clanDesc, bufferSize, formattedTag)
    return Velora.invoke(0xA52370, "bool", p0, p1, p2, p3, p4, p5, invoke<BOOL>(0xA521E0, invoke<BOOL>(0xA52250, clanDesc, bufferSize, invoke<BOOL>(0xA52300, clanDesc, invoke<BOOL>(0xA52330, clanDesc, bufferSize, formattedTag)
end

function NETWORK_CLAN_GET_LOCAL_MEMBERSHIPS_COUNT(memberDesc, invoke<BOOL>(0xA52420, invoke<BOOL>(0xA52450, invoke<BOOL>(0xA52480, invoke<BOOL>(0xA52500, invoke<int>(0xA52530, p0, invoke<BOOL>(0xA52560, p0, clanMembership, invoke<BOOL>(0xA52590, invoke<BOOL>(0xA525C0, animDict, invoke<BOOL>(0xA525F0, p0, invoke<BOOL>(0xA52640, netHandle, invoke<BOOL>(0xA526D0, invoke<BOOL>(0xA52700, p0, invoke<BOOL>(0xA52730, p0)
    return Velora.invoke(0xA527E0, "int", memberDesc, invoke<BOOL>(0xA52420, invoke<BOOL>(0xA52450, invoke<BOOL>(0xA52480, invoke<BOOL>(0xA52500, invoke<int>(0xA52530, p0, invoke<BOOL>(0xA52560, p0, clanMembership, invoke<BOOL>(0xA52590, invoke<BOOL>(0xA525C0, animDict, invoke<BOOL>(0xA525F0, p0, invoke<BOOL>(0xA52640, netHandle, invoke<BOOL>(0xA526D0, invoke<BOOL>(0xA52700, p0, invoke<BOOL>(0xA52730, p0)
end

function NETWORK_GET_PRIMARY_CLAN_DATA_CLEAR(NETWORK_GET_PRIMARY_CLAN_DATA_CANCEL()
    return Velora.invoke(0xA528A0, "bool", NETWORK_GET_PRIMARY_CLAN_DATA_CANCEL()
end

function NETWORK_GET_PRIMARY_CLAN_DATA_START(p0, invoke<BOOL>(0xA528C0, p0, invoke<BOOL>(0xA52930, netId, toggle)
    return Velora.invoke(0xA52960, "bool", p0, invoke<BOOL>(0xA528C0, p0, invoke<BOOL>(0xA52930, netId, toggle)
end

function SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(netId, toggle)
    Velora.invoke(0xA52980, "void", netId, toggle)
end

function SET_NETWORK_ID_ALWAYS_EXISTS_FOR_PLAYER(netId, player, toggle)
    Velora.invoke(0xA529A0, "void", netId, player, toggle)
end

function SET_NETWORK_ID_CAN_BE_REASSIGNED(netId, toggle)
    Velora.invoke(0xA529C0, "void", netId, toggle)
end

function NETWORK_SET_ENTITY_CAN_BLEND(entity, toggle)
    Velora.invoke(0xA529E0, "void", entity, toggle)
end

function NETWORK_SET_OBJECT_CAN_BLEND_WHEN_FIXED(object, toggle)
    Velora.invoke(0xA52A40, "void", object, toggle)
end

function NETWORK_SET_ENTITY_ONLY_EXISTS_FOR_PARTICIPANTS(entity, toggle)
    Velora.invoke(0xA52AB0, "void", entity, toggle)
end

function SET_NETWORK_ID_VISIBLE_IN_CUTSCENE(netId, p1, p2)
    Velora.invoke(0xA52B30, "void", netId, p1, p2)
end

function SET_NETWORK_ID_VISIBLE_IN_CUTSCENE_HACK(netId, p1, p2)
    Velora.invoke(0xA52B50, "void", netId, p1, p2)
end

function SET_NETWORK_ID_VISIBLE_IN_CUTSCENE_REMAIN_HACK(p0, p1)
    Velora.invoke(0xA52B70, "void", p0, p1)
end

function SET_NETWORK_CUTSCENE_ENTITIES(toggle)
    Velora.invoke(0xA52B90, "void", toggle)
end

function ARE_CUTSCENE_ENTITIES_NETWORKED(netId, state)
    return Velora.invoke(0xA52BC0, "bool", netId, state)
end

function IS_NETWORK_ID_OWNED_BY_PARTICIPANT(invoke<BOOL>(0xA52C60, player, locallyVisible)
    return Velora.invoke(0xA52C90, "bool", invoke<BOOL>(0xA52C60, player, locallyVisible)
end

function SET_LOCAL_PLAYER_VISIBLE_IN_CUTSCENE(p0, p1)
    Velora.invoke(0xA52D00, "void", p0, p1)
end

function SET_LOCAL_PLAYER_INVISIBLE_LOCALLY(bIncludePlayersVehicle)
    Velora.invoke(0xA52D80, "void", bIncludePlayersVehicle)
end

function SET_LOCAL_PLAYER_VISIBLE_LOCALLY(bIncludePlayersVehicle)
    Velora.invoke(0xA52E20, "void", bIncludePlayersVehicle)
end

function SET_PLAYER_INVISIBLE_LOCALLY(player, bIncludePlayersVehicle)
    Velora.invoke(0xA52EC0, "void", player, bIncludePlayersVehicle)
end

function SET_PLAYER_VISIBLE_LOCALLY(player, bIncludePlayersVehicle)
    Velora.invoke(0xA52F60, "void", player, bIncludePlayersVehicle)
end

function FADE_OUT_LOCAL_PLAYER(p0)
    Velora.invoke(0xA53010, "void", p0)
end

function NETWORK_FADE_OUT_ENTITY(entity, normal, slow)
    Velora.invoke(0xA53090, "void", entity, normal, slow)
end

function NETWORK_FADE_IN_ENTITY(entity, state, p2)
    Velora.invoke(0xA530B0, "void", entity, state, p2)
end

function NETWORK_IS_PLAYER_FADING(invoke<BOOL>(0xA530D0, invoke<BOOL>(0xA53150, invoke<BOOL>(0xA531D0, p0, p1, p2)
    return Velora.invoke(0xA53230, "bool", invoke<BOOL>(0xA530D0, invoke<BOOL>(0xA53150, invoke<BOOL>(0xA531D0, p0, p1, p2)
end

function SET_ENTITY_LOCALLY_INVISIBLE(entity)
    Velora.invoke(0xA532E0, "void", entity)
end

function SET_ENTITY_LOCALLY_VISIBLE(entity)
    Velora.invoke(0xA53340, "void", entity)
end

function IS_DAMAGE_TRACKER_ACTIVE_ON_NETWORK_ID(invoke<BOOL>(0xA533B0, netID, toggle)
    return Velora.invoke(0xA533E0, "bool", invoke<BOOL>(0xA533B0, netID, toggle)
end

function IS_DAMAGE_TRACKER_ACTIVE_ON_PLAYER(invoke<BOOL>(0xA53400, player, toggle)
    return Velora.invoke(0xA53470, "bool", invoke<BOOL>(0xA53400, player, toggle)
end

function IS_SPHERE_VISIBLE_TO_ANOTHER_MACHINE(p0, p1, p2, invoke<BOOL>(0xA534F0, p0, p1, p2, p3, invoke<BOOL>(0xA53590, amount)
    return Velora.invoke(0xA53650, "bool", p0, p1, p2, invoke<BOOL>(0xA534F0, p0, p1, p2, p3, invoke<BOOL>(0xA53590, amount)
end

function RESERVE_NETWORK_MISSION_PEDS(amount)
    Velora.invoke(0xA53660, "void", amount)
end

function RESERVE_NETWORK_MISSION_VEHICLES(amount)
    Velora.invoke(0xA53670, "void", amount)
end

function RESERVE_LOCAL_NETWORK_MISSION_OBJECTS(amount)
    Velora.invoke(0xA53680, "void", amount)
end

function RESERVE_LOCAL_NETWORK_MISSION_PEDS(amount)
    Velora.invoke(0xA53690, "void", amount)
end

function RESERVE_LOCAL_NETWORK_MISSION_VEHICLES(amount)
    Velora.invoke(0xA536A0, "void", amount)
end

function CAN_REGISTER_MISSION_OBJECTS(invoke<BOOL>(0xA536B0, invoke<BOOL>(0xA53730, invoke<BOOL>(0xA537B0, invoke<BOOL>(0xA53850, invoke<BOOL>(0xA538D0, ped_amt, vehicle_amt, object_amt, invoke<BOOL>(0xA53920, p0, invoke<int>(0xA53A00, p0, invoke<int>(0xA53AC0, p0, invoke<int>(0xA53B80, invoke<int>(0xA53C40, invoke<int>(0xA53CC0, invoke<int>(0xA53D40, x, y, z, p3, out1, out2, out3)
    return Velora.invoke(0xA53DC0, "bool", invoke<BOOL>(0xA536B0, invoke<BOOL>(0xA53730, invoke<BOOL>(0xA537B0, invoke<BOOL>(0xA53850, invoke<BOOL>(0xA538D0, ped_amt, vehicle_amt, object_amt, invoke<BOOL>(0xA53920, p0, invoke<int>(0xA53A00, p0, invoke<int>(0xA53AC0, p0, invoke<int>(0xA53B80, invoke<int>(0xA53C40, invoke<int>(0xA53CC0, invoke<int>(0xA53D40, x, y, z, p3, out1, out2, out3)
end

function GET_MAX_NUM_NETWORK_OBJECTS(object, range)
    return Velora.invoke(0xA53F00, "int", object, range)
end

function NETWORK_ALLOW_CLONING_WHILE_IN_TUTORIAL(p0, p1)
    Velora.invoke(0xA53F60, "void", p0, p1)
end

function NETWORK_SET_TASK_CUTSCENE_INSCOPE_MULTIPLER(p0)
    Velora.invoke(0xA53FE0, "void", p0)
end

function GET_NETWORK_TIME(timeA, invoke<int>(0xA541F0, timeA, invoke<BOOL>(0xA54200, timeA, invoke<BOOL>(0xA54220, timeA, invoke<BOOL>(0xA54240, timeA, invoke<int>(0xA54260, char>(0xA54270, posixTime, timeStructure)
    return Velora.invoke(0xA543E0, "int", timeA, invoke<int>(0xA541F0, timeA, invoke<BOOL>(0xA54200, timeA, invoke<BOOL>(0xA54220, timeA, invoke<BOOL>(0xA54240, timeA, invoke<int>(0xA54260, char>(0xA54270, posixTime, timeStructure)
end

function NETWORK_SET_IN_SPECTATOR_MODE(toggle, playerPed)
    Velora.invoke(0xA54480, "void", toggle, playerPed)
end

function NETWORK_SET_IN_SPECTATOR_MODE_EXTENDED(toggle, playerPed, p2)
    Velora.invoke(0xA544F0, "void", toggle, playerPed, p2)
end

function NETWORK_SET_IN_FREE_CAM_MODE(toggle)
    Velora.invoke(0xA54560, "void", toggle)
end

function NETWORK_SET_ANTAGONISTIC_TO_PLAYER(toggle, player)
    Velora.invoke(0xA545B0, "void", toggle, player)
end

function NETWORK_IS_IN_SPECTATOR_MODE(p0, p1)
    return Velora.invoke(0xA54620, "bool", p0, p1)
end

function NETWORK_IS_IN_MP_CUTSCENE(invoke<BOOL>(0xA54660, NETWORK_HIDE_PROJECTILE_IN_CUTSCENE()
    return Velora.invoke(0xA546B0, "bool", invoke<BOOL>(0xA54660, NETWORK_HIDE_PROJECTILE_IN_CUTSCENE()
end

function SET_NETWORK_VEHICLE_RESPOT_TIMER(netId, time, p2, p3)
    Velora.invoke(0xA546C0, "void", netId, time, p2, p3)
end

function IS_NETWORK_VEHICLE_RUNNING_RESPOT_TIMER(invoke<BOOL>(0xA54730, vehicle, toggle)
    return Velora.invoke(0xA54780, "bool", invoke<BOOL>(0xA54730, vehicle, toggle)
end

function SET_NETWORK_VEHICLE_MAX_POSITION_DELTA_MULTIPLIER(vehicle, multiplier)
    Velora.invoke(0xA547E0, "void", vehicle, multiplier)
end

function SET_NETWORK_ENABLE_HIGH_SPEED_EDGE_FALL_DETECTION(vehicle, toggle)
    Velora.invoke(0xA548B0, "void", vehicle, toggle)
end

function SET_LOCAL_PLAYER_AS_GHOST(toggle, p1)
    Velora.invoke(0xA54970, "void", toggle, p1)
end

function IS_ENTITY_A_GHOST(invoke<BOOL>(0xA54990, p0)
    return Velora.invoke(0xA54A00, "bool", invoke<BOOL>(0xA54990, p0)
end

function SET_REMOTE_PLAYER_AS_GHOST(player, p1)
    Velora.invoke(0xA54A70, "void", player, p1)
end

function SET_GHOST_ALPHA(alpha)
    Velora.invoke(0xA54B20, "void", alpha)
end

function RESET_GHOST_ALPHA()
    Velora.invoke(0xA54BB0, "void")
end

function SET_ENTITY_GHOSTED_FOR_GHOST_PLAYERS(entity, toggle)
    Velora.invoke(0xA54BC0, "void", entity, toggle)
end

function SET_INVERT_GHOSTING(p0)
    Velora.invoke(0xA54C30, "void", p0)
end

function IS_ENTITY_IN_GHOST_COLLISION(invoke<BOOL>(0xA54CC0, toggle)
    return Velora.invoke(0xA54DF0, "bool", invoke<BOOL>(0xA54CC0, toggle)
end

function NETWORK_CREATE_SYNCHRONISED_SCENE(x, y, z, xRot, yRot, zRot, rotationOrder, useOcclusionPortal, looped, p9, animTime, invoke<int>(0xA54E10, ped, netScene, animDict, animnName, speed, speedMultiplier, duration, flag, playbackRate, p9)
    return Velora.invoke(0xA54E60, "int", x, y, z, xRot, yRot, zRot, rotationOrder, useOcclusionPortal, looped, p9, animTime, invoke<int>(0xA54E10, ped, netScene, animDict, animnName, speed, speedMultiplier, duration, flag, playbackRate, p9)
end

function NETWORK_ADD_PED_TO_SYNCHRONISED_SCENE_WITH_IK(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)
    Velora.invoke(0xA54F40, "void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)
end

function NETWORK_ADD_ENTITY_TO_SYNCHRONISED_SCENE(entity, netScene, animDict, animName, speed, speedMulitiplier, flag)
    Velora.invoke(0xA55020, "void", entity, netScene, animDict, animName, speed, speedMulitiplier, flag)
end

function NETWORK_ADD_MAP_ENTITY_TO_SYNCHRONISED_SCENE(netScene, modelHash, x, y, z, p5, p6, p7, p8, flags)
    Velora.invoke(0xA550E0, "void", netScene, modelHash, x, y, z, p5, p6, p7, p8, flags)
end

function NETWORK_ADD_SYNCHRONISED_SCENE_CAMERA(netScene, animDict, animName)
    Velora.invoke(0xA55160, "void", netScene, animDict, animName)
end

function NETWORK_ATTACH_SYNCHRONISED_SCENE_TO_ENTITY(netScene, entity, bone)
    Velora.invoke(0xA551E0, "void", netScene, entity, bone)
end

function NETWORK_START_SYNCHRONISED_SCENE(netScene)
    Velora.invoke(0xA552A0, "void", netScene)
end

function NETWORK_STOP_SYNCHRONISED_SCENE(netScene)
    Velora.invoke(0xA55310, "void", netScene)
end

function NETWORK_GET_LOCAL_SCENE_FROM_NETWORK_ID(invoke<int>(0xA55380, netScene)
    return Velora.invoke(0xA553C0, "int", invoke<int>(0xA55380, netScene)
end

function NETWORK_ALLOW_REMOTE_SYNCED_SCENE_LOCAL_PLAYER_REQUESTS(p0)
    Velora.invoke(0xA55430, "void", p0)
end

function NETWORK_FIND_LARGEST_BUNCH_OF_PLAYERS(p0, invoke<BOOL>(0xA55460, player, x, y, z, radius, p5, p6, p7, invoke<BOOL>(0xA554D0, player, x1, y1, z1, x2, y2, z2, width, p8, p9, p10, invoke<BOOL>(0xA55510, invoke<int>(0xA55550, NETWORK_CANCEL_RESPAWN_SEARCH()
    return Velora.invoke(0xA555B0, "bool", p0, invoke<BOOL>(0xA55460, player, x, y, z, radius, p5, p6, p7, invoke<BOOL>(0xA554D0, player, x1, y1, z1, x2, y2, z2, width, p8, p9, p10, invoke<BOOL>(0xA55510, invoke<int>(0xA55550, NETWORK_CANCEL_RESPAWN_SEARCH()
end

function NETWORK_GET_RESPAWN_RESULT(randomInt, coordinates, heading)
    Velora.invoke(0xA555C0, "void", randomInt, coordinates, heading)
end

function NETWORK_GET_RESPAWN_RESULT_FLAGS(invoke<int>(0xA55630, NETWORK_START_SOLO_TUTORIAL_SESSION()
    return Velora.invoke(0xA55650, "int", invoke<int>(0xA55630, NETWORK_START_SOLO_TUTORIAL_SESSION()
end

function NETWORK_ALLOW_GANG_TO_JOIN_TUTORIAL_SESSION(teamId, instanceId)
    Velora.invoke(0xA55680, "void", teamId, instanceId)
end

function NETWORK_END_TUTORIAL_SESSION()
    Velora.invoke(0xA556D0, "void")
end

function NETWORK_IS_IN_TUTORIAL_SESSION(invoke<int>(0xA557C0, player, invoke<BOOL>(0xA55810, p0)
    return Velora.invoke(0xA55870, "bool", invoke<int>(0xA557C0, player, invoke<BOOL>(0xA55810, p0)
end

function NETWORK_CONCEAL_PLAYER(player, toggle, p2)
    Velora.invoke(0xA558A0, "void", player, toggle, p2)
end

function NETWORK_IS_PLAYER_CONCEALED(invoke<BOOL>(0xA558F0, entity, toggle)
    return Velora.invoke(0xA55940, "bool", invoke<BOOL>(0xA558F0, entity, toggle)
end

function NETWORK_IS_ENTITY_CONCEALED(invoke<BOOL>(0xA559B0, hours, minutes, seconds)
    return Velora.invoke(0xA55A20, "bool", invoke<BOOL>(0xA559B0, hours, minutes, seconds)
end

function NETWORK_OVERRIDE_CLOCK_RATE(ms)
    Velora.invoke(0xA55A40, "void", ms)
end

function NETWORK_CLEAR_CLOCK_TIME_OVERRIDE()
    Velora.invoke(0xA55A50, "void")
end

function NETWORK_IS_CLOCK_TIME_OVERRIDDEN(x1, y1, z1, x2, y2, invoke<int>(0xA55AF0, x1, y1, z1, x2, y2, z2, invoke<int>(0xA55B20, x1, y1, z1, x2, y2, invoke<int>(0xA55B50, x1, y1, z1, x2, y2, z2, invoke<int>(0xA55B80, invoke<BOOL>(0xA55BB0, invoke<BOOL>(0xA55CB0, invoke<BOOL>(0xA55CE0, invoke<BOOL>(0xA55D10, netID, toggle)
    return Velora.invoke(0xA55D40, "bool", x1, y1, z1, x2, y2, invoke<int>(0xA55AF0, x1, y1, z1, x2, y2, z2, invoke<int>(0xA55B20, x1, y1, z1, x2, y2, invoke<int>(0xA55B50, x1, y1, z1, x2, y2, z2, invoke<int>(0xA55B80, invoke<BOOL>(0xA55BB0, invoke<BOOL>(0xA55CB0, invoke<BOOL>(0xA55CE0, invoke<BOOL>(0xA55D10, netID, toggle)
end

function NETWORK_SET_CUSTOM_ARENA_BALL_PARAMS(netId)
    Velora.invoke(0xA55DA0, "void", netId)
end

function NETWORK_ENTITY_USE_HIGH_PRECISION_ROTATION(netId, toggle)
    Velora.invoke(0xA55E00, "void", netId, toggle)
end

function NETWORK_REQUEST_CLOUD_BACKGROUND_SCRIPTS(NETWORK_REQUEST_CLOUD_TUNABLES()
    return Velora.invoke(0xA55EC0, "bool", NETWORK_REQUEST_CLOUD_TUNABLES()
end

function NETWORK_IS_TUNABLE_CLOUD_REQUEST_PENDING(tunableContext, invoke<BOOL>(0xA561B0, tunableContext, tunableName, invoke<BOOL>(0xA56220, tunableContext, tunableName, invoke<BOOL>(0xA562A0, tunableContext, invoke<BOOL>(0xA56320, tunableContext, invoke<BOOL>(0xA563C0, tunableContext, tunableName, invoke<BOOL>(0xA56440, contextHash, nameHash, invoke<BOOL>(0xA564A0, tunableContext, tunableName, invoke<BOOL>(0xA564E0, contextHash, nameHash, invoke<BOOL>(0xA56540, tunableContext, invoke<BOOL>(0xA56580, contextHash, nameHash, invoke<BOOL>(0xA56600, tunableContext, tunableName, invoke<BOOL>(0xA56640, invoke<int>(0xA566A0, NETWORK_RESET_BODY_TRACKER()
    return Velora.invoke(0xA56700, "bool", tunableContext, invoke<BOOL>(0xA561B0, tunableContext, tunableName, invoke<BOOL>(0xA56220, tunableContext, tunableName, invoke<BOOL>(0xA562A0, tunableContext, invoke<BOOL>(0xA56320, tunableContext, invoke<BOOL>(0xA563C0, tunableContext, tunableName, invoke<BOOL>(0xA56440, contextHash, nameHash, invoke<BOOL>(0xA564A0, tunableContext, tunableName, invoke<BOOL>(0xA564E0, contextHash, nameHash, invoke<BOOL>(0xA56540, tunableContext, invoke<BOOL>(0xA56580, contextHash, nameHash, invoke<BOOL>(0xA56600, tunableContext, tunableName, invoke<BOOL>(0xA56640, invoke<int>(0xA566A0, NETWORK_RESET_BODY_TRACKER()
end

function NETWORK_GET_NUMBER_BODY_TRACKER_HITS(invoke<BOOL>(0xA56750, ped, invoke<BOOL>(0xA567E0, entity, toggle)
    return Velora.invoke(0xA568A0, "int", invoke<BOOL>(0xA56750, ped, invoke<BOOL>(0xA567E0, entity, toggle)
end

function NETWORK_TRIGGER_DAMAGE_EVENT_FOR_ZERO_WEAPON_HASH(entity, toggle)
    Velora.invoke(0xA56980, "void", entity, toggle)
end

function NETWORK_SET_NO_LONGER_NEEDED(entity, toggle)
    Velora.invoke(0xA569F0, "void", entity, toggle)
end

function NETWORK_EXPLODE_VEHICLE(vehicle, isAudible, isInvisible, invoke<BOOL>(0xA56A00, vehicle, isAudible, isInvisible, netId)
    return Velora.invoke(0xA56A30, "bool", vehicle, isAudible, isInvisible, invoke<BOOL>(0xA56A00, vehicle, isAudible, isInvisible, netId)
end

function NETWORK_USE_LOGARITHMIC_BLENDING_THIS_FRAME(entity)
    Velora.invoke(0xA56A60, "void", entity)
end

function NETWORK_OVERRIDE_COORDS_AND_HEADING(entity, x, y, z, heading)
    Velora.invoke(0xA56AC0, "void", entity, x, y, z, heading)
end

function NETWORK_ENABLE_EXTRA_VEHICLE_ORIENTATION_BLEND_CHECKS(netId, toggle)
    Velora.invoke(0xA56BA0, "void", netId, toggle)
end

function NETWORK_DISABLE_PROXIMITY_MIGRATION(netID)
    Velora.invoke(0xA56C20, "void", netID)
end

function NETWORK_SET_PROPERTY_ID(id)
    Velora.invoke(0xDEADBEEF, "void", id)
end

function NETWORK_CLEAR_PROPERTY_ID()
    Velora.invoke(0xDEADBEEF, "void")
end

function NETWORK_SET_PLAYER_MENTAL_STATE(p0)
    Velora.invoke(0xA56C70, "void", p0)
end

function NETWORK_SET_MINIMUM_RANK_FOR_MISSION(p0)
    Velora.invoke(0xA56CB0, "void", p0)
end

function NETWORK_CACHE_LOCAL_PLAYER_HEAD_BLEND_DATA()
    Velora.invoke(0xA56CD0, "void")
end

function NETWORK_HAS_CACHED_PLAYER_HEAD_BLEND_DATA(invoke<BOOL>(0xA56CE0, ped, invoke<BOOL>(0xA56D20, p0)
    return Velora.invoke(0xA56E10, "bool", invoke<BOOL>(0xA56CE0, ped, invoke<BOOL>(0xA56D20, p0)
end

function IS_COMMERCE_DATA_FETCH_IN_PROGRESS(char>(0xA56E50, char>(0xA56EC0, char>(0xA56F30, invoke<int>(0xA56FA0, index, char>(0xA57010, p0, p1, p2)
    return Velora.invoke(0xA57080, "bool", char>(0xA56E50, char>(0xA56EC0, char>(0xA56F30, invoke<int>(0xA56FA0, index, char>(0xA57010, p0, p1, p2)
end

function IS_COMMERCE_STORE_OPEN(toggle)
    return Velora.invoke(0xA570C0, "bool", toggle)
end

function REQUEST_COMMERCE_ITEM_IMAGE(invoke<BOOL>(0xA570E0, RELEASE_ALL_COMMERCE_ITEM_IMAGES()
    return Velora.invoke(0xA57110, "bool", invoke<BOOL>(0xA570E0, RELEASE_ALL_COMMERCE_ITEM_IMAGES()
end

function GET_COMMERCE_ITEM_TEXTURENAME(char>(0xA57120, DELAY_MP_STORE_OPEN()
    return Velora.invoke(0xA571E0, "string", char>(0xA57120, DELAY_MP_STORE_OPEN()
end

function RESET_STORE_NETWORK_GAME_TRACKING()
    Velora.invoke(0xA571F0, "void")
end

function IS_USER_OLD_ENOUGH_TO_ACCESS_STORE(p0, p1, p2)
    return Velora.invoke(0xA57240, "bool", p0, p1, p2)
end

function GET_USER_PREMIUM_ACCESS(invoke<int>(0xA572C0, invoke<BOOL>(0xA57320, invoke<BOOL>(0xA57350, CLOUD_CHECK_AVAILABILITY()
    return Velora.invoke(0xA57380, "int", invoke<int>(0xA572C0, invoke<BOOL>(0xA57320, invoke<BOOL>(0xA57350, CLOUD_CHECK_AVAILABILITY()
end

function CLOUD_IS_CHECKING_AVAILABILITY(CLEAR_SERVICE_EVENT_ARGUMENTS()
    return Velora.invoke(0xA57580, "bool", CLEAR_SERVICE_EVENT_ARGUMENTS()
end

function UGC_COPY_CONTENT(p0, invoke<BOOL>(0xA57590, UGC_CLEAR_CREATE_RESULT()
    return Velora.invoke(0xA576D0, "bool", p0, invoke<BOOL>(0xA57590, UGC_CLEAR_CREATE_RESULT()
end

function UGC_QUERY_MY_CONTENT(p0, p1, p2, p3, p4, invoke<BOOL>(0xA576E0, p0, p1, p2, p3, p4, invoke<BOOL>(0xA577B0, contentId, latestVersion, invoke<BOOL>(0xA57840, data, count, latestVersion, invoke<BOOL>(0xA57900, offset, count, contentTypeName, invoke<BOOL>(0xA57A20, p0, p1, p2, invoke<BOOL>(0xA57AC0, p0, p1, p2, invoke<BOOL>(0xA57B20, p0, p1, p2, invoke<BOOL>(0xA57B90, p0, p1, p2, p3, invoke<BOOL>(0xA57BF0, p0, p1, p2, p3, invoke<BOOL>(0xA57C50, contentId, invoke<BOOL>(0xA57CD0, data, dataCount, invoke<BOOL>(0xA57D80, p0, p1, p2, invoke<BOOL>(0xA57EA0, p0, p1, p2, invoke<BOOL>(0xA57F00, p0, p1, p2, invoke<BOOL>(0xA57F60, UGC_CANCEL_QUERY()
    return Velora.invoke(0xA58020, "bool", p0, p1, p2, p3, p4, invoke<BOOL>(0xA576E0, p0, p1, p2, p3, p4, invoke<BOOL>(0xA577B0, contentId, latestVersion, invoke<BOOL>(0xA57840, data, count, latestVersion, invoke<BOOL>(0xA57900, offset, count, contentTypeName, invoke<BOOL>(0xA57A20, p0, p1, p2, invoke<BOOL>(0xA57AC0, p0, p1, p2, invoke<BOOL>(0xA57B20, p0, p1, p2, invoke<BOOL>(0xA57B90, p0, p1, p2, p3, invoke<BOOL>(0xA57BF0, p0, p1, p2, p3, invoke<BOOL>(0xA57C50, contentId, invoke<BOOL>(0xA57CD0, data, dataCount, invoke<BOOL>(0xA57D80, p0, p1, p2, invoke<BOOL>(0xA57EA0, p0, p1, p2, invoke<BOOL>(0xA57F00, p0, p1, p2, invoke<BOOL>(0xA57F60, UGC_CANCEL_QUERY()
end

function UGC_IS_GETTING(UGC_CLEAR_QUERY_RESULTS()
    return Velora.invoke(0xA581B0, "bool", UGC_CLEAR_QUERY_RESULTS()
end

function UGC_GET_CONTENT_USER_ID(char>(0xA581C0, p0, invoke<BOOL>(0xA581F0, invoke<BOOL>(0xA58280, char>(0xA582B0, invoke<BOOL>(0xA582E0, invoke<int>(0xA58310, char>(0xA58340, char>(0xA58370, char>(0xA583A0, invoke<int>(0xA58400, p0, char>(0xA58430, p0, p1)
    return Velora.invoke(0xA58470, "string", char>(0xA581C0, p0, invoke<BOOL>(0xA581F0, invoke<BOOL>(0xA58280, char>(0xA582B0, invoke<BOOL>(0xA582E0, invoke<int>(0xA58310, char>(0xA58340, char>(0xA58370, char>(0xA583A0, invoke<int>(0xA58400, p0, char>(0xA58430, p0, p1)
end

function UGC_GET_CONTENT_FILE_VERSION(p0, invoke<int>(0xA58500, invoke<BOOL>(0xA58530, invoke<BOOL>(0xA58560, invoke<int>(0xA58590, invoke<BOOL>(0xA585C0, invoke<BOOL>(0xA585F0, p0, invoke<float>(0xA58620, p0, invoke<int>(0xA58650, p0, invoke<int>(0xA58680, p0, invoke<int>(0xA586B0, invoke<BOOL>(0xA586E0, invoke<BOOL>(0xA58710, p0, invoke<int>(0xA58740, contentTypeName, contentId, p2, p3, invoke<int>(0xA58780, invoke<int>(0xA58800, invoke<BOOL>(0xA58830, invoke<BOOL>(0xA58860, invoke<BOOL>(0xA58890, p0, char>(0xA588C0, invoke<BOOL>(0xA58940, UGC_RELEASE_ALL_CACHED_DESCRIPTIONS()
    return Velora.invoke(0xA58970, "int", p0, invoke<int>(0xA58500, invoke<BOOL>(0xA58530, invoke<BOOL>(0xA58560, invoke<int>(0xA58590, invoke<BOOL>(0xA585C0, invoke<BOOL>(0xA585F0, p0, invoke<float>(0xA58620, p0, invoke<int>(0xA58650, p0, invoke<int>(0xA58680, p0, invoke<int>(0xA586B0, invoke<BOOL>(0xA586E0, invoke<BOOL>(0xA58710, p0, invoke<int>(0xA58740, contentTypeName, contentId, p2, p3, invoke<int>(0xA58780, invoke<int>(0xA58800, invoke<BOOL>(0xA58830, invoke<BOOL>(0xA58860, invoke<BOOL>(0xA58890, p0, char>(0xA588C0, invoke<BOOL>(0xA58940, UGC_RELEASE_ALL_CACHED_DESCRIPTIONS()
end

function UGC_PUBLISH(contentId, baseContentId, invoke<BOOL>(0xA589C0, contentId, bookmarked, invoke<BOOL>(0xA58A30, p0, p1, invoke<BOOL>(0xA58B30, UGC_CLEAR_MODIFY_RESULT()
    return Velora.invoke(0xA58C50, "bool", contentId, baseContentId, invoke<BOOL>(0xA589C0, contentId, bookmarked, invoke<BOOL>(0xA58A30, p0, p1, invoke<BOOL>(0xA58B30, UGC_CLEAR_MODIFY_RESULT()
end

function UGC_GET_CREATORS_BY_USER_ID(p0, invoke<BOOL>(0xA58C60, invoke<BOOL>(0xA58DA0, UGC_CLEAR_OFFLINE_QUERY()
    return Velora.invoke(0xA58DD0, "bool", p0, invoke<BOOL>(0xA58C60, invoke<BOOL>(0xA58DA0, UGC_CLEAR_OFFLINE_QUERY()
end

function UGC_SET_QUERY_DATA_FROM_OFFLINE(p0)
    Velora.invoke(0xA58DE0, "void", p0)
end

function UGC_SET_USING_OFFLINE_CONTENT(p0)
    Velora.invoke(0xA58E00, "void", p0)
end

function UGC_IS_LANGUAGE_SUPPORTED(invoke<BOOL>(0xA58E20, heistName, cashEarned, invoke<BOOL>(0xA58E50, invoke<BOOL>(0xA58E70, gamerHandle, filePath, name, invoke<int>(0xA58EB0, filePath, name, invoke<int>(0xA59010, p0, p1, p2, p3, p4, invoke<int>(0xA590D0, p0)
    return Velora.invoke(0xA591A0, "bool", invoke<BOOL>(0xA58E20, heistName, cashEarned, invoke<BOOL>(0xA58E50, invoke<BOOL>(0xA58E70, gamerHandle, filePath, name, invoke<int>(0xA58EB0, filePath, name, invoke<int>(0xA59010, p0, p1, p2, p3, p4, invoke<int>(0xA590D0, p0)
end

function TEXTURE_DOWNLOAD_HAS_FAILED(invoke<BOOL>(0xA591C0, char>(0xA591F0, invoke<int>(0xA59220, invoke<BOOL>(0xA59530, privilege, banType, invoke<BOOL>(0xA595B0, invoke<int>(0xDEADBEEF, invoke<int>(0xA59790, NETWORK_SKIP_RADIO_RESET_NEXT_CLOSE()
    return Velora.invoke(0xA597A0, "bool", invoke<BOOL>(0xA591C0, char>(0xA591F0, invoke<int>(0xA59220, invoke<BOOL>(0xA59530, privilege, banType, invoke<BOOL>(0xA595B0, invoke<int>(0xDEADBEEF, invoke<int>(0xA59790, NETWORK_SKIP_RADIO_RESET_NEXT_CLOSE()
end

function NETWORK_SKIP_RADIO_RESET_NEXT_OPEN()
    Velora.invoke(0xA597B0, "void")
end

function NETWORK_SKIP_RADIO_WARNING(NETWORK_FORCE_LOCAL_PLAYER_SCAR_SYNC()
    return Velora.invoke(0xA597D0, "bool", NETWORK_FORCE_LOCAL_PLAYER_SCAR_SYNC()
end

function NETWORK_DISABLE_LEAVE_REMOTE_PED_BEHIND(toggle)
    Velora.invoke(0xA597F0, "void", toggle)
end

function NETWORK_ALLOW_REMOTE_ATTACHMENT_MODIFICATION(entity, toggle)
    Velora.invoke(0xA59840, "void", entity, toggle)
end

function NETWORK_SHOW_CHAT_RESTRICTION_MSC(player)
    Velora.invoke(0xA59890, "void", player)
end

function NETWORK_SHOW_PSN_UGC_RESTRICTION()
    Velora.invoke(0xA598E0, "void")
end

function NETWORK_IS_TITLE_UPDATE_REQUIRED(NETWORK_QUIT_MP_TO_DESKTOP()
    return Velora.invoke(0xA59990, "bool", NETWORK_QUIT_MP_TO_DESKTOP()
end

function NETWORK_IS_CONNECTED_VIA_RELAY(invoke<BOOL>(0xA599A0, invoke<float>(0xA59A00, invoke<float>(0xA59A50, invoke<float>(0xA59AA0, invoke<int>(0xA59AF0, invoke<int>(0xA59B50, invoke<int>(0xA59BB0, NETWORK_REPORT_CODE_TAMPER()
    return Velora.invoke(0xA59C10, "bool", invoke<BOOL>(0xA599A0, invoke<float>(0xA59A00, invoke<float>(0xA59A50, invoke<float>(0xA59AA0, invoke<int>(0xA59AF0, invoke<int>(0xA59B50, invoke<int>(0xA59BB0, NETWORK_REPORT_CODE_TAMPER()
end

function NETWORK_GET_LAST_ENTITY_POS_RECEIVED_OVER_NETWORK(invoke<Vector3>(0xA59C30, invoke<Vector3>(0xA59D30, invoke<Vector3>(0xA59E00, invoke<Vector3>(0xA59EC0, NETWORK_DUMP_NET_IF_CONFIG()
    local x, y, z = Velora.invoke(0xA59F90, "vector3", invoke<Vector3>(0xA59C30, invoke<Vector3>(0xA59D30, invoke<Vector3>(0xA59E00, invoke<Vector3>(0xA59EC0, NETWORK_DUMP_NET_IF_CONFIG()
    return {x = x, y = y, z = z}
end

function NETWORK_GET_SIGNALLING_INFO(p0)
    Velora.invoke(0xA59FA0, "void", p0)
end

function NETWORK_GET_NET_STATISTICS_INFO(p0)
    Velora.invoke(0xA59FB0, "void", p0)
end

function NETWORK_GET_PLAYER_ACCOUNT_ID(invoke<int>(0xA59FC0, p0, p1)
    return Velora.invoke(0xA5A010, "int", invoke<int>(0xA59FC0, p0, p1)
end

function CREATE_OBJECT(modelHash, x, y, z, isNetwork, bScriptHostObj, invoke<Object>(0xA639E0, modelHash, x, y, z, isNetwork, bScriptHostObj, invoke<Object>(0xA63A80, object)
    return Velora.invoke(0xA63B20, "int", modelHash, x, y, z, isNetwork, bScriptHostObj, invoke<Object>(0xA639E0, modelHash, x, y, z, isNetwork, bScriptHostObj, invoke<Object>(0xA63A80, object)
end

function PLACE_OBJECT_ON_GROUND_PROPERLY(invoke<BOOL>(0xA63B30, invoke<BOOL>(0xA63BD0, object, p1, p2, invoke<BOOL>(0xA63C70, object, toX, toY, toZ, speedX, speedY, speedZ, invoke<BOOL>(0xA63CB0, object, targettable)
    return Velora.invoke(0xA63CF0, "bool", invoke<BOOL>(0xA63B30, invoke<BOOL>(0xA63BD0, object, p1, p2, invoke<BOOL>(0xA63C70, object, toX, toY, toZ, speedX, speedY, speedZ, invoke<BOOL>(0xA63CB0, object, targettable)
end

function SET_OBJECT_FORCE_VEHICLES_TO_AVOID(object, toggle)
    Velora.invoke(0xA63E70, "void", object, toggle)
end

function GET_CLOSEST_OBJECT_OF_TYPE(x, y, z, radius, modelHash, isMission, p6, invoke<Object>(0xA63ED0, object, invoke<BOOL>(0xA63F20, p0, p1, p2, p3, modelHash, invoke<BOOL>(0xA63FC0, x, y, z, radius, modelHash, invoke<BOOL>(0xA63FF0, invoke<BOOL>(0xA64020, xPos, yPos, zPos, heading, xOffset, yOffset, invoke<Vector3>(0xA64090, x, y, z, radius, modelHash, outPosition, outRotation, invoke<BOOL>(0xA64170, type, x, y, z, locked, heading, p6)
    return Velora.invoke(0xA64220, "int", x, y, z, radius, modelHash, isMission, p6, invoke<Object>(0xA63ED0, object, invoke<BOOL>(0xA63F20, p0, p1, p2, p3, modelHash, invoke<BOOL>(0xA63FC0, x, y, z, radius, modelHash, invoke<BOOL>(0xA63FF0, invoke<BOOL>(0xA64020, xPos, yPos, zPos, heading, xOffset, yOffset, invoke<Vector3>(0xA64090, x, y, z, radius, modelHash, outPosition, outRotation, invoke<BOOL>(0xA64170, type, x, y, z, locked, heading, p6)
end

function GET_STATE_OF_CLOSEST_DOOR_OF_TYPE(type, x, y, z, locked, heading)
    Velora.invoke(0xA64320, "void", type, x, y, z, locked, heading)
end

function SET_LOCKED_UNSTREAMED_IN_DOOR_OF_TYPE(modelHash, x, y, z, locked, xRotMult, yRotMult, zRotMult)
    Velora.invoke(0xA64340, "void", modelHash, x, y, z, locked, xRotMult, yRotMult, zRotMult)
end

function PLAY_OBJECT_AUTO_START_ANIM(p0)
    Velora.invoke(0xA64460, "void", p0)
end

function ADD_DOOR_TO_SYSTEM(doorHash, modelHash, x, y, z, p5, scriptDoor, isLocal)
    Velora.invoke(0xA644B0, "void", doorHash, modelHash, x, y, z, p5, scriptDoor, isLocal)
end

function REMOVE_DOOR_FROM_SYSTEM(doorHash, p1)
    Velora.invoke(0xA64500, "void", doorHash, p1)
end

function DOOR_SYSTEM_SET_DOOR_STATE(doorHash, state, requestDoor, forceUpdate)
    Velora.invoke(0xA64520, "void", doorHash, state, requestDoor, forceUpdate)
end

function DOOR_SYSTEM_GET_DOOR_STATE(invoke<int>(0xA64550, invoke<int>(0xA64580, doorHash, rate, requestDoor, forceUpdate)
    return Velora.invoke(0xA645B0, "int", invoke<int>(0xA64550, invoke<int>(0xA64580, doorHash, rate, requestDoor, forceUpdate)
end

function DOOR_SYSTEM_SET_AUTOMATIC_DISTANCE(doorHash, distance, requestDoor, forceUpdate)
    Velora.invoke(0xA64650, "void", doorHash, distance, requestDoor, forceUpdate)
end

function DOOR_SYSTEM_SET_OPEN_RATIO(doorHash, ajar, requestDoor, forceUpdate)
    Velora.invoke(0xA646F0, "void", doorHash, ajar, requestDoor, forceUpdate)
end

function DOOR_SYSTEM_GET_AUTOMATIC_DISTANCE(invoke<float>(0xA64790, invoke<float>(0xA647E0, doorHash, removed, requestDoor, forceUpdate)
    return Velora.invoke(0xA64870, "float", invoke<float>(0xA64790, invoke<float>(0xA647E0, doorHash, removed, requestDoor, forceUpdate)
end

function DOOR_SYSTEM_SET_HOLD_OPEN(doorHash, toggle)
    Velora.invoke(0xA64920, "void", doorHash, toggle)
end

function DOOR_SYSTEM_SET_DOOR_OPEN_FOR_RACES(doorHash, p1)
    Velora.invoke(0xA64980, "void", doorHash, p1)
end

function IS_DOOR_REGISTERED_WITH_SYSTEM(invoke<BOOL>(0xA64A20, invoke<BOOL>(0xA64A50, p0)
    return Velora.invoke(0xA64AC0, "bool", invoke<BOOL>(0xA64A20, invoke<BOOL>(0xA64A50, p0)
end

function CLOSE_ALL_BARRIERS_FOR_RACE()
    Velora.invoke(0xA64AE0, "void")
end

function DOOR_SYSTEM_GET_IS_PHYSICS_LOADED(invoke<BOOL>(0xA64AF0, x, y, z, modelHash, invoke<BOOL>(0xA64B30, garageHash, p1, invoke<BOOL>(0xA64BC0, garageHash, player, p2, invoke<BOOL>(0xA64C50, garageHash, player, invoke<BOOL>(0xA64CF0, garageHash, p1, p2, p3, invoke<BOOL>(0xA64D50, garageHash, p1, p2, p3, invoke<BOOL>(0xA64DC0, garageHash, entity, p2, invoke<BOOL>(0xA64E30, garageHash, entity, invoke<BOOL>(0xA64EF0, garageHash, isNetwork)
    return Velora.invoke(0xA64F70, "bool", invoke<BOOL>(0xA64AF0, x, y, z, modelHash, invoke<BOOL>(0xA64B30, garageHash, p1, invoke<BOOL>(0xA64BC0, garageHash, player, p2, invoke<BOOL>(0xA64C50, garageHash, player, invoke<BOOL>(0xA64CF0, garageHash, p1, p2, p3, invoke<BOOL>(0xA64D50, garageHash, p1, p2, p3, invoke<BOOL>(0xA64DC0, garageHash, entity, p2, invoke<BOOL>(0xA64E30, garageHash, entity, invoke<BOOL>(0xA64EF0, garageHash, isNetwork)
end

function CLEAR_OBJECTS_INSIDE_GARAGE(garageHash, vehicles, peds, objects, isNetwork)
    Velora.invoke(0xA64F90, "void", garageHash, vehicles, peds, objects, isNetwork)
end

function DISABLE_TIDYING_UP_IN_GARAGE(id, toggle)
    Velora.invoke(0xA64FD0, "void", id, toggle)
end

function ENABLE_SAVING_IN_GARAGE(garageHash, toggle)
    Velora.invoke(0xA65030, "void", garageHash, toggle)
end

function CLOSE_SAFEHOUSE_GARAGES()
    Velora.invoke(0xA65090, "void")
end

function DOES_OBJECT_OF_TYPE_EXIST_AT_COORDS(x, y, z, radius, hash, invoke<BOOL>(0xA650A0, xPos, yPos, zPos, x1, y1, z1, x2, y2, z2, width, debug, invoke<BOOL>(0xA65110, object, toggle)
    return Velora.invoke(0xA651F0, "bool", x, y, z, radius, hash, invoke<BOOL>(0xA650A0, xPos, yPos, zPos, x1, y1, z1, x2, y2, z2, width, debug, invoke<BOOL>(0xA65110, object, toggle)
end

function SET_OBJECT_PHYSICS_PARAMS(object, weight, p2, p3, p4, p5, gravity, p7, p8, p9, p10, buoyancy)
    Velora.invoke(0xA65250, "void", object, weight, p2, p3, p4, p5, gravity, p7, p8, p9, p10, buoyancy)
end

function GET_OBJECT_FRAGMENT_DAMAGE_HEALTH(p0, invoke<float>(0xA65280, object, toggle)
    return Velora.invoke(0xA652F0, "float", p0, invoke<float>(0xA65280, object, toggle)
end

function IS_ANY_OBJECT_NEAR_POINT(x, y, z, range, invoke<BOOL>(0xA65350, objectHash, x, y, z, invoke<BOOL>(0xA65450, object)
    return Velora.invoke(0xA65480, "bool", x, y, z, range, invoke<BOOL>(0xA65350, objectHash, x, y, z, invoke<BOOL>(0xA65450, object)
end

function BREAK_OBJECT_FRAGMENT_CHILD(p0, p1, p2)
    Velora.invoke(0xA654B0, "void", p0, p1, p2)
end

function DAMAGE_OBJECT_FRAGMENT_CHILD(p0, p1, p2)
    Velora.invoke(0xA654D0, "void", p0, p1, p2)
end

function FIX_OBJECT_FRAGMENT(object)
    Velora.invoke(0xA654F0, "void", object)
end

function TRACK_OBJECT_VISIBILITY(object)
    Velora.invoke(0xA65570, "void", object)
end

function IS_OBJECT_VISIBLE(invoke<BOOL>(0xA655B0, object, toggle)
    return Velora.invoke(0xA65620, "bool", invoke<BOOL>(0xA655B0, object, toggle)
end

function SET_OBJECT_TAKES_DAMAGE_FROM_COLLIDING_WITH_BUILDINGS(p0, p1)
    Velora.invoke(0xA65680, "void", p0, p1)
end

function ALLOW_DAMAGE_EVENTS_FOR_NON_NETWORKED_OBJECTS(value)
    Velora.invoke(0xA656E0, "void", value)
end

function SET_CUTSCENES_WEAPON_FLASHLIGHT_ON_THIS_FRAME(object, toggle)
    Velora.invoke(0xA65700, "void", object, toggle)
end

function GET_RAYFIRE_MAP_OBJECT(x, y, z, radius, invoke<Object>(0xA65770, object, state)
    return Velora.invoke(0xA65880, "int", x, y, z, radius, invoke<Object>(0xA65770, object, state)
end

function GET_STATE_OF_RAYFIRE_MAP_OBJECT(invoke<int>(0xA65890, invoke<BOOL>(0xA658E0, invoke<float>(0xA65930, pickupHash, posX, posY, posZ, p4, value, p6, invoke<Pickup>(0xA65960, pickupHash, posX, posY, posZ, rotX, rotY, rotZ, flag, amount, p9, p10, invoke<Pickup>(0xA659A0, FORCE_PICKUP_ROTATE_FACE_UP()
    return Velora.invoke(0xA659F0, "int", invoke<int>(0xA65890, invoke<BOOL>(0xA658E0, invoke<float>(0xA65930, pickupHash, posX, posY, posZ, p4, value, p6, invoke<Pickup>(0xA65960, pickupHash, posX, posY, posZ, rotX, rotY, rotZ, flag, amount, p9, p10, invoke<Pickup>(0xA659A0, FORCE_PICKUP_ROTATE_FACE_UP()
end

function SET_CUSTOM_PICKUP_WEAPON_HASH(pickupHash, pickup)
    Velora.invoke(0xA65A00, "void", pickupHash, pickup)
end

function CREATE_AMBIENT_PICKUP(pickupHash, posX, posY, posZ, flags, value, modelHash, p7, invoke<Object>(0xA65A40, pickupHash, posX, posY, posZ, flags, value, modelHash, p7, invoke<Object>(0xA65A90, p0, p1)
    return Velora.invoke(0xA65AF0, "int", pickupHash, posX, posY, posZ, flags, value, modelHash, p7, invoke<Object>(0xA65A40, pickupHash, posX, posY, posZ, flags, value, modelHash, p7, invoke<Object>(0xA65A90, p0, p1)
end

function CREATE_PORTABLE_PICKUP(pickupHash, x, y, z, placeOnGround, invoke<Object>(0xA65B40, pickupHash, x, y, z, placeOnGround, invoke<Object>(0xA65B80, pickupObject, ped)
    return Velora.invoke(0xA65BC0, "int", pickupHash, x, y, z, placeOnGround, invoke<Object>(0xA65B40, pickupHash, x, y, z, placeOnGround, invoke<Object>(0xA65B80, pickupObject, ped)
end

function DETACH_PORTABLE_PICKUP_FROM_PED(pickupObject)
    Velora.invoke(0xA65BD0, "void", pickupObject)
end

function FORCE_PORTABLE_PICKUP_LAST_ACCESSIBLE_POSITION_SETTING(object)
    Velora.invoke(0xA65C50, "void", object)
end

function HIDE_PORTABLE_PICKUP_WHEN_DETACHED(pickupObject, toggle)
    Velora.invoke(0xA65CA0, "void", pickupObject, toggle)
end

function SET_MAX_NUM_PORTABLE_PICKUPS_CARRIED_BY_PLAYER(modelHash, number)
    Velora.invoke(0xA65D00, "void", modelHash, number)
end

function SET_LOCAL_PLAYER_CAN_COLLECT_PORTABLE_PICKUPS(toggle)
    Velora.invoke(0xA65DC0, "void", toggle)
end

function GET_SAFE_PICKUP_COORDS(x, y, z, p3, invoke<Vector3>(0xA65E10, x, y, z, radius)
    local x, y, z = Velora.invoke(0xA65F20, "vector3", x, y, z, p3, invoke<Vector3>(0xA65E10, x, y, z, radius)
    return {x = x, y = y, z = z}
end

function CLEAR_EXTENDED_PICKUP_PROBE_AREAS()
    Velora.invoke(0xA65F90, "void")
end

function GET_PICKUP_COORDS(invoke<Vector3>(0xA65FA0, p0, p1)
    local x, y, z = Velora.invoke(0xA66040, "vector3", invoke<Vector3>(0xA65FA0, p0, p1)
    return {x = x, y = y, z = z}
end

function REMOVE_ALL_PICKUPS_OF_TYPE(pickupHash)
    Velora.invoke(0xA660A0, "void", pickupHash)
end

function HAS_PICKUP_BEEN_COLLECTED(invoke<BOOL>(0xA660C0, pickup)
    return Velora.invoke(0xA660F0, "bool", invoke<BOOL>(0xA660C0, pickup)
end

function CREATE_MONEY_PICKUPS(x, y, z, value, amount, model)
    Velora.invoke(0xA66100, "void", x, y, z, value, amount, model)
end

function DOES_PICKUP_EXIST(invoke<BOOL>(0xA66120, invoke<BOOL>(0xA66170, invoke<Object>(0xA661A0, invoke<BOOL>(0xA661C0, invoke<BOOL>(0xA66220, pickupHash, x, y, z, invoke<BOOL>(0xA66280, pickup, duration)
    return Velora.invoke(0xA663A0, "bool", invoke<BOOL>(0xA66120, invoke<BOOL>(0xA66170, invoke<Object>(0xA661A0, invoke<BOOL>(0xA661C0, invoke<BOOL>(0xA66220, pickupHash, x, y, z, invoke<BOOL>(0xA66280, pickup, duration)
end

function FORCE_PICKUP_REGENERATE(p0)
    Velora.invoke(0xA663B0, "void", p0)
end

function SET_PLAYER_PERMITTED_TO_COLLECT_PICKUPS_OF_TYPE(player, pickupHash, toggle)
    Velora.invoke(0xA66420, "void", player, pickupHash, toggle)
end

function SET_LOCAL_PLAYER_PERMITTED_TO_COLLECT_PICKUPS_WITH_MODEL(modelHash, toggle)
    Velora.invoke(0xA66490, "void", modelHash, toggle)
end

function ALLOW_ALL_PLAYERS_TO_COLLECT_PICKUPS_OF_TYPE(pickupHash)
    Velora.invoke(0xA664D0, "void", pickupHash)
end

function SET_TEAM_PICKUP_OBJECT(object, p1, p2)
    Velora.invoke(0xA664F0, "void", object, p1, p2)
end

function PREVENT_COLLECTION_OF_PORTABLE_PICKUP(object, p1, p2)
    Velora.invoke(0xA66580, "void", object, p1, p2)
end

function SET_PICKUP_OBJECT_GLOW_WHEN_UNCOLLECTABLE(pickup, toggle)
    Velora.invoke(0xA66620, "void", pickup, toggle)
end

function SET_PICKUP_GLOW_OFFSET(pickup, p1)
    Velora.invoke(0xA666F0, "void", pickup, p1)
end

function SET_PICKUP_OBJECT_GLOW_OFFSET(pickup, p1, p2)
    Velora.invoke(0xA66740, "void", pickup, p1, p2)
end

function SET_OBJECT_GLOW_IN_SAME_TEAM(pickup)
    Velora.invoke(0xA667C0, "void", pickup)
end

function SET_PICKUP_OBJECT_ARROW_MARKER(pickup, toggle)
    Velora.invoke(0xA66810, "void", pickup, toggle)
end

function ALLOW_PICKUP_ARROW_MARKER_WHEN_UNCOLLECTABLE(pickup, toggle)
    Velora.invoke(0xA66870, "void", pickup, toggle)
end

function GET_DEFAULT_AMMO_FOR_WEAPON_PICKUP(invoke<int>(0xA668D0, multiplier)
    return Velora.invoke(0xA66960, "int", invoke<int>(0xA668D0, multiplier)
end

function GET_PICKUP_GENERATION_RANGE_MULTIPLIER(p0)
    return Velora.invoke(0xA66A10, "float", p0)
end

function SET_PICKUP_UNCOLLECTABLE(pickup, toggle)
    Velora.invoke(0xA66A30, "void", pickup, toggle)
end

function SET_PICKUP_TRANSPARENT_WHEN_UNCOLLECTABLE(pickup, toggle)
    Velora.invoke(0xA66A80, "void", pickup, toggle)
end

function SET_PICKUP_HIDDEN_WHEN_UNCOLLECTABLE(pickup, toggle)
    Velora.invoke(0xA66AD0, "void", pickup, toggle)
end

function SET_PICKUP_OBJECT_TRANSPARENT_WHEN_UNCOLLECTABLE(pickup, toggle)
    Velora.invoke(0xA66B20, "void", pickup, toggle)
end

function SET_PICKUP_OBJECT_ALPHA_WHEN_TRANSPARENT(p0)
    Velora.invoke(0xA66B80, "void", p0)
end

function SET_PORTABLE_PICKUP_PERSIST(pickup, toggle)
    Velora.invoke(0xA66BA0, "void", pickup, toggle)
end

function ALLOW_PORTABLE_PICKUP_TO_MIGRATE_TO_NON_PARTICIPANTS(pickup, toggle)
    Velora.invoke(0xA66C00, "void", pickup, toggle)
end

function FORCE_ACTIVATE_PHYSICS_ON_UNFIXED_PICKUP(pickup, toggle)
    Velora.invoke(0xA66C70, "void", pickup, toggle)
end

function ALLOW_PICKUP_BY_NONE_PARTICIPANT(pickup, toggle)
    Velora.invoke(0xA66CD0, "void", pickup, toggle)
end

function SUPPRESS_PICKUP_REWARD_TYPE(rewardType, suppress)
    Velora.invoke(0xA66D20, "void", rewardType, suppress)
end

function CLEAR_ALL_PICKUP_REWARD_TYPE_SUPPRESSION()
    Velora.invoke(0xA66D50, "void")
end

function CLEAR_PICKUP_REWARD_TYPE_SUPPRESSION(rewardType)
    Velora.invoke(0xA66D60, "void", rewardType)
end

function RENDER_FAKE_PICKUP_GLOW(x, y, z, colorIndex)
    Velora.invoke(0xA66D80, "void", x, y, z, colorIndex)
end

function SET_PICKUP_OBJECT_COLLECTABLE_IN_VEHICLE(pickup)
    Velora.invoke(0xA66DB0, "void", pickup)
end

function SET_PICKUP_TRACK_DAMAGE_EVENTS(pickup, toggle)
    Velora.invoke(0xA66DF0, "void", pickup, toggle)
end

function SET_ENTITY_FLAG_SUPPRESS_SHADOW(entity, toggle)
    Velora.invoke(0xA66E50, "void", entity, toggle)
end

function SET_ENTITY_FLAG_RENDER_SMALL_SHADOW(object, toggle)
    Velora.invoke(0xA66EA0, "void", object, toggle)
end

function GET_WEAPON_TYPE_FROM_PICKUP_TYPE(invoke<Hash>(0xA66EF0, invoke<Hash>(0xA66FA0, invoke<BOOL>(0xA67010, invoke<int>(0xA67060, object, textureVariation)
    return Velora.invoke(0xA670C0, "int", invoke<Hash>(0xA66EF0, invoke<Hash>(0xA66FA0, invoke<BOOL>(0xA67010, invoke<int>(0xA67060, object, textureVariation)
end

function SET_TINT_INDEX_CLOSEST_BUILDING_OF_TYPE(x, y, z, radius, modelHash, invoke<BOOL>(0xA67150, p0, p1)
    return Velora.invoke(0xA67210, "bool", x, y, z, radius, modelHash, invoke<BOOL>(0xA67150, p0, p1)
end

function SET_PROP_LIGHT_COLOR(object, p1, r, g, invoke<BOOL>(0xA67280, invoke<BOOL>(0xA672C0, object, toggle)
    return Velora.invoke(0xA672F0, "bool", object, p1, r, g, invoke<BOOL>(0xA67280, invoke<BOOL>(0xA672C0, object, toggle)
end

function SET_OBJECT_SPEED_BOOST_AMOUNT(object, p1)
    Velora.invoke(0xA67350, "void", object, p1)
end

function SET_OBJECT_SPEED_BOOST_DURATION(object, duration)
    Velora.invoke(0xA673A0, "void", object, duration)
end

function CONVERT_OLD_PICKUP_TYPE_TO_NEW(invoke<Hash>(0xA67410, x, y, z, p3)
    return Velora.invoke(0xA67430, "int", invoke<Hash>(0xA67410, x, y, z, p3)
end

function ONLY_CLEAN_UP_OBJECT_WHEN_OUT_OF_RANGE(object)
    Velora.invoke(0xA67490, "void", object)
end

function SET_DISABLE_COLLISIONS_BETWEEN_CARS_AND_CAR_PARACHUTE(p0)
    Velora.invoke(0xA674D0, "void", p0)
end

function SET_PROJECTILES_SHOULD_EXPLODE_ON_CONTACT(entity, p1)
    Velora.invoke(0xA674F0, "void", entity, p1)
end

function SET_DRIVE_ARTICULATED_JOINT(object, toggle, p2)
    Velora.invoke(0xA67550, "void", object, toggle, p2)
end

function SET_DRIVE_ARTICULATED_JOINT_WITH_INFLICTOR(object, toggle, p2, ped)
    Velora.invoke(0xA675D0, "void", object, toggle, p2, ped)
end

function SET_OBJECT_IS_A_PRESSURE_PLATE(object, toggle)
    Velora.invoke(0xA675F0, "void", object, toggle)
end

function SET_WEAPON_IMPACTS_APPLY_GREATER_FORCE(object, p1)
    Velora.invoke(0xA67650, "void", object, p1)
end

function GET_IS_ARTICULATED_JOINT_AT_MIN_ANGLE(object, invoke<BOOL>(0xA676B0, p0, invoke<BOOL>(0xA67720, object, toggle)
    return Velora.invoke(0xA67790, "bool", object, invoke<BOOL>(0xA676B0, p0, invoke<BOOL>(0xA67720, object, toggle)
end

function SET_IS_OBJECT_BALL(object, toggle)
    Velora.invoke(0xA677F0, "void", object, toggle)
end

function IS_CONTROL_ENABLED(control, invoke<BOOL>(0xA6A3F0, control, invoke<BOOL>(0xA6A450, control, invoke<BOOL>(0xA6A4C0, control, invoke<BOOL>(0xA6A530, control, invoke<BOOL>(0xA6A5A0, control, invoke<int>(0xA6A6A0, control, invoke<float>(0xA6A720, toggle)
    return Velora.invoke(0xA6A780, "bool", control, invoke<BOOL>(0xA6A3F0, control, invoke<BOOL>(0xA6A450, control, invoke<BOOL>(0xA6A4C0, control, invoke<BOOL>(0xA6A530, control, invoke<BOOL>(0xA6A5A0, control, invoke<int>(0xA6A6A0, control, invoke<float>(0xA6A720, toggle)
end

function GET_CONTROL_UNBOUND_NORMAL(control, invoke<float>(0xA6A7A0, control, action, invoke<BOOL>(0xA6A800, control, invoke<BOOL>(0xA6A880, control, invoke<BOOL>(0xA6A920, control, invoke<BOOL>(0xA6A9C0, control, invoke<BOOL>(0xA6AA60, control, invoke<float>(0xA6AB00, control, invoke<float>(0xA6ABA0, invoke<int>(0xA6AC40, invoke<BOOL>(0xA6AC90, invoke<BOOL>(0xA6ACA0, x, invoke<BOOL>(0xA6ACF0, invoke<BOOL>(0xA6AD00, invoke<BOOL>(0xA6AD50, control, action, char>(0xA6AD80, control, controlGroup, char>(0xA6AE30, control, red, green, blue)
    return Velora.invoke(0xA6AEE0, "float", control, invoke<float>(0xA6A7A0, control, action, invoke<BOOL>(0xA6A800, control, invoke<BOOL>(0xA6A880, control, invoke<BOOL>(0xA6A920, control, invoke<BOOL>(0xA6A9C0, control, invoke<BOOL>(0xA6AA60, control, invoke<float>(0xA6AB00, control, invoke<float>(0xA6ABA0, invoke<int>(0xA6AC40, invoke<BOOL>(0xA6AC90, invoke<BOOL>(0xA6ACA0, x, invoke<BOOL>(0xA6ACF0, invoke<BOOL>(0xA6AD00, invoke<BOOL>(0xA6AD50, control, action, char>(0xA6AD80, control, controlGroup, char>(0xA6AE30, control, red, green, blue)
end

function CLEAR_CONTROL_LIGHT_EFFECT(control)
    Velora.invoke(0xA6AF80, "void", control)
end

function SET_CONTROL_SHAKE(control, duration, frequency)
    Velora.invoke(0xA6AFC0, "void", control, duration, frequency)
end

function SET_CONTROL_TRIGGER_SHAKE(control, leftDuration, leftFrequency, rightDuration, rightFrequency)
    Velora.invoke(0xA6B030, "void", control, leftDuration, leftFrequency, rightDuration, rightFrequency)
end

function STOP_CONTROL_SHAKE(control)
    Velora.invoke(0xA6B040, "void", control)
end

function SET_CONTROL_SHAKE_SUPPRESSED_ID(control, uniqueId)
    Velora.invoke(0xA6B080, "void", control, uniqueId)
end

function CLEAR_CONTROL_SHAKE_SUPPRESSED_ID(control)
    Velora.invoke(0xA6B0C0, "void", control)
end

function IS_LOOK_INVERTED(toggle)
    return Velora.invoke(0xA6B1B0, "bool", toggle)
end

function SET_INPUT_EXCLUSIVE(control, action)
    Velora.invoke(0xA6B1D0, "void", control, action)
end

function DISABLE_CONTROL_ACTION(control, action, disableRelatedActions)
    Velora.invoke(0xA6B220, "void", control, action, disableRelatedActions)
end

function ENABLE_CONTROL_ACTION(control, action, enableRelatedActions)
    Velora.invoke(0xA6B2B0, "void", control, action, enableRelatedActions)
end

function DISABLE_ALL_CONTROL_ACTIONS(control)
    Velora.invoke(0xA6B340, "void", control)
end

function ENABLE_ALL_CONTROL_ACTIONS(control)
    Velora.invoke(0xA6B390, "void", control)
end

function INIT_PC_SCRIPTED_CONTROLS(invoke<BOOL>(0xA6B3C0, invoke<BOOL>(0xA6B3D0, SHUTDOWN_PC_SCRIPTED_CONTROLS()
    return Velora.invoke(0xA6B3E0, "bool", invoke<BOOL>(0xA6B3C0, invoke<BOOL>(0xA6B3D0, SHUTDOWN_PC_SCRIPTED_CONTROLS()
end

function ALLOW_ALTERNATIVE_SCRIPT_CONTROLS_LAYOUT(control)
    Velora.invoke(0xA6B3F0, "void", control)
end

function SET_ROADS_IN_AREA(x1, y1, z1, x2, y2, z2, nodeEnabled, unknown2)
    Velora.invoke(0xA6F500, "void", x1, y1, z1, x2, y2, z2, nodeEnabled, unknown2)
end

function SET_ROADS_IN_ANGLED_AREA(x1, y1, z1, x2, y2, z2, width, unknown1, unknown2, unknown3)
    Velora.invoke(0xA6F530, "void", x1, y1, z1, x2, y2, z2, width, unknown1, unknown2, unknown3)
end

function SET_PED_PATHS_IN_AREA(x1, y1, z1, x2, y2, z2, p6, p7)
    Velora.invoke(0xA6F570, "void", x1, y1, z1, x2, y2, z2, p6, p7)
end

function GET_SAFE_COORD_FOR_PED(x, y, z, onGround, outPosition, invoke<BOOL>(0xA6F5A0, x, y, z, outPosition, nodeFlags, p5, invoke<BOOL>(0xA6F6F0, x, y, z, outPosition, unknown1, invoke<BOOL>(0xA6F7D0, x, y, z, outPosition, outHeading, nodeType, p6, invoke<BOOL>(0xA6F8A0, x, y, z, nthClosest, outPosition, nodeFlags, unknown1, invoke<BOOL>(0xA6F990, x, y, z, nth, nodeFlags, p5, invoke<int>(0xA6FA70, x, y, z, nthClosest, outPosition, outHeading, outNumLanes, nodeFlags, unknown3, invoke<BOOL>(0xA6FB10, x, y, z, nthClosest, outPosition, outHeading, nodeFlags, p7, invoke<int>(0xA6FC10, x, y, z, desiredX, desiredY, desiredZ, nthClosest, outPosition, outHeading, nodeFlags, p10, invoke<BOOL>(0xA6FCC0, x, y, z, density, invoke<BOOL>(0xA6FDD0, invoke<BOOL>(0xA6FE00, nodeId, outPosition)
    return Velora.invoke(0xA6FE20, "bool", x, y, z, onGround, outPosition, invoke<BOOL>(0xA6F5A0, x, y, z, outPosition, nodeFlags, p5, invoke<BOOL>(0xA6F6F0, x, y, z, outPosition, unknown1, invoke<BOOL>(0xA6F7D0, x, y, z, outPosition, outHeading, nodeType, p6, invoke<BOOL>(0xA6F8A0, x, y, z, nthClosest, outPosition, nodeFlags, unknown1, invoke<BOOL>(0xA6F990, x, y, z, nth, nodeFlags, p5, invoke<int>(0xA6FA70, x, y, z, nthClosest, outPosition, outHeading, outNumLanes, nodeFlags, unknown3, invoke<BOOL>(0xA6FB10, x, y, z, nthClosest, outPosition, outHeading, nodeFlags, p7, invoke<int>(0xA6FC10, x, y, z, desiredX, desiredY, desiredZ, nthClosest, outPosition, outHeading, nodeFlags, p10, invoke<BOOL>(0xA6FCC0, x, y, z, density, invoke<BOOL>(0xA6FDD0, invoke<BOOL>(0xA6FE00, nodeId, outPosition)
end

function GET_VEHICLE_NODE_IS_GPS_ALLOWED(invoke<BOOL>(0xA6FF00, invoke<BOOL>(0xA6FF50, x, y, z, p3, p4, p5, p6, p7, p8, p9, invoke<BOOL>(0xA6FFA0, invoke<BOOL>(0xA70080, toggle)
    return Velora.invoke(0xA700F0, "bool", invoke<BOOL>(0xA6FF00, invoke<BOOL>(0xA6FF50, x, y, z, p3, p4, p5, p6, p7, p8, p9, invoke<BOOL>(0xA6FFA0, invoke<BOOL>(0xA70080, toggle)
end

function SET_ALLOW_STREAM_HEIST_ISLAND_NODES(type)
    Velora.invoke(0xA70110, "void", type)
end

function ARE_NODES_LOADED_FOR_AREA(x1, y1, x2, invoke<BOOL>(0xA70130, x1, y1, x2, invoke<BOOL>(0xA70170, p0, p1, p2, p3, p4, p5, p6)
    return Velora.invoke(0xA70220, "bool", x1, y1, x2, invoke<BOOL>(0xA70130, x1, y1, x2, invoke<BOOL>(0xA70170, p0, p1, p2, p3, p4, p5, p6)
end

function SET_ROADS_BACK_TO_ORIGINAL_IN_ANGLED_AREA(x1, y1, z1, x2, y2, z2, width, p7)
    Velora.invoke(0xA70240, "void", x1, y1, z1, x2, y2, z2, width, p7)
end

function SET_AMBIENT_PED_RANGE_MULTIPLIER_THIS_FRAME(multiplier)
    Velora.invoke(0xA70260, "void", multiplier)
end

function ADJUST_AMBIENT_PED_SPAWN_DENSITIES_THIS_FRAME(p0, p1, p2, p3, p4, p5, p6)
    Velora.invoke(0xA70270, "void", p0, p1, p2, p3, p4, p5, p6)
end

function SET_PED_PATHS_BACK_TO_ORIGINAL(x1, y1, z1, x2, y2, z2, p6)
    Velora.invoke(0xA70310, "void", x1, y1, z1, x2, y2, z2, p6)
end

function GET_RANDOM_VEHICLE_NODE(x, y, z, radius, p4, p5, p6, outPosition, invoke<BOOL>(0xA703C0, x, y, z, streetName, crossingRoad)
    return Velora.invoke(0xA705B0, "bool", x, y, z, radius, p4, p5, p6, outPosition, invoke<BOOL>(0xA703C0, x, y, z, streetName, crossingRoad)
end

function GENERATE_DIRECTIONS_TO_COORD(x, y, z, p3, direction, p5, invoke<int>(0xA70640, toggle)
    return Velora.invoke(0xA706A0, "int", x, y, z, p3, direction, p5, invoke<int>(0xA70640, toggle)
end

function SET_IGNORE_NO_GPS_FLAG_UNTIL_FIRST_NORMAL_NODE(toggle)
    Velora.invoke(0xA706C0, "void", toggle)
end

function SET_GPS_DISABLED_ZONE(x1, y1, z1, x2, y2, z3)
    Velora.invoke(0xA706E0, "void", x1, y1, z1, x2, y2, z3)
end

function GET_GPS_BLIP_ROUTE_LENGTH(result, p1, p2, invoke<BOOL>(0xA707D0, x, y, z, heading, invoke<BOOL>(0xA708F0, x, y, z, p3, invoke<BOOL>(0xA70960, x, y, z, invoke<BOOL>(0xA70A00, x1, y1, z1, x2, y2, z2, index)
    return Velora.invoke(0xA70AE0, "int", result, p1, p2, invoke<BOOL>(0xA707D0, x, y, z, heading, invoke<BOOL>(0xA708F0, x, y, z, p3, invoke<BOOL>(0xA70960, x, y, z, invoke<BOOL>(0xA70A00, x1, y1, z1, x2, y2, z2, index)
end

function CLEAR_GPS_DISABLED_ZONE_AT_INDEX(index)
    Velora.invoke(0xA70BA0, "void", index)
end

function ADD_NAVMESH_REQUIRED_REGION(x, y, radius)
    Velora.invoke(0xA70BD0, "void", x, y, radius)
end

function REMOVE_NAVMESH_REQUIRED_REGIONS()
    Velora.invoke(0xA70C20, "void")
end

function IS_NAVMESH_REQUIRED_REGION_IN_USE(x1, y1, z1, x2, y2, z2, toggle)
    return Velora.invoke(0xA70C70, "bool", x1, y1, z1, x2, y2, z2, toggle)
end

function ARE_ALL_NAVMESH_REGIONS_LOADED(x1, y1, z1, x2, y2, invoke<BOOL>(0xA70CB0, x1, y1, z1, x2, y2, invoke<int>(0xA70CE0, p0, p1, p2, p3, p4, p5, p6, p7, invoke<int>(0xA70D10, p0, p1, p2, p3, p4, p5, p6, p7, p8)
    return Velora.invoke(0xA70DD0, "bool", x1, y1, z1, x2, y2, invoke<BOOL>(0xA70CB0, x1, y1, z1, x2, y2, invoke<int>(0xA70CE0, p0, p1, p2, p3, p4, p5, p6, p7, invoke<int>(0xA70D10, p0, p1, p2, p3, p4, p5, p6, p7, p8)
end

function REMOVE_NAVMESH_BLOCKING_OBJECT(p0)
    Velora.invoke(0xA70E90, "void", p0)
end

function DOES_NAVMESH_BLOCKING_OBJECT_EXIST(invoke<BOOL>(0xA70EC0, x, invoke<float>(0xA70EF0, x1, y1, x2, invoke<float>(0xA70F20, x, invoke<float>(0xA70F60, x1, y1, x2, invoke<float>(0xA70F90, x1, y1, z1, x2, y2, invoke<float>(0xA70FD0, pedType, modelHash, x, y, z, heading, isNetwork, invoke<Ped>(0xA8FBF0, ped)
    return Velora.invoke(0xA8FC40, "bool", invoke<BOOL>(0xA70EC0, x, invoke<float>(0xA70EF0, x1, y1, x2, invoke<float>(0xA70F20, x, invoke<float>(0xA70F60, x1, y1, x2, invoke<float>(0xA70F90, x1, y1, z1, x2, y2, invoke<float>(0xA70FD0, pedType, modelHash, x, y, z, heading, isNetwork, invoke<Ped>(0xA8FBF0, ped)
end

function CLONE_PED(ped, isNetwork, bScriptHostPed, invoke<Ped>(0xA8FC50, ped, isNetwork, bScriptHostPed, copyHeadBlendFlag, invoke<Ped>(0xA8FCA0, ped, targetPed)
    return Velora.invoke(0xA8FCF0, "int", ped, isNetwork, bScriptHostPed, invoke<Ped>(0xA8FC50, ped, isNetwork, bScriptHostPed, copyHeadBlendFlag, invoke<Ped>(0xA8FCA0, ped, targetPed)
end

function CLONE_PED_TO_TARGET_ALT(ped, targetPed, p2)
    Velora.invoke(0xA8FD90, "void", ped, targetPed, p2)
end

function IS_PED_IN_VEHICLE(ped, vehicle, invoke<BOOL>(0xA8FE30, ped, invoke<BOOL>(0xA8FE60, ped, invoke<BOOL>(0xA8FF40, x1, y1, z1, x2, y2, invoke<BOOL>(0xA8FF70, invoke<BOOL>(0xA90020, invoke<BOOL>(0xA90080, invoke<BOOL>(0xA900E0, ped, invoke<BOOL>(0xA90140, invoke<BOOL>(0xA901C0, invoke<BOOL>(0xA90230, invoke<BOOL>(0xA90260, invoke<BOOL>(0xA902C0, vehicle, pedType, modelHash, seat, isNetwork, invoke<Ped>(0xA90320, ped, heading)
    return Velora.invoke(0xA90360, "bool", ped, vehicle, invoke<BOOL>(0xA8FE30, ped, invoke<BOOL>(0xA8FE60, ped, invoke<BOOL>(0xA8FF40, x1, y1, z1, x2, y2, invoke<BOOL>(0xA8FF70, invoke<BOOL>(0xA90020, invoke<BOOL>(0xA90080, invoke<BOOL>(0xA900E0, ped, invoke<BOOL>(0xA90140, invoke<BOOL>(0xA901C0, invoke<BOOL>(0xA90230, invoke<BOOL>(0xA90260, invoke<BOOL>(0xA902C0, vehicle, pedType, modelHash, seat, isNetwork, invoke<Ped>(0xA90320, ped, heading)
end

function FORCE_ALL_HEADING_VALUES_TO_ALIGN(ped)
    Velora.invoke(0xA90450, "void", ped)
end

function IS_PED_FACING_PED(ped, otherPed, invoke<BOOL>(0xA90460, invoke<BOOL>(0xA90490, invoke<BOOL>(0xA90500, ped, x1, y1, z1, x2, y2, z2, p7, invoke<BOOL>(0xA90560, x1, y1, z1, x2, y2, z2, p6, invoke<BOOL>(0xA905A0, invoke<BOOL>(0xA905E0, ped, accuracy)
    return Velora.invoke(0xA90640, "bool", ped, otherPed, invoke<BOOL>(0xA90460, invoke<BOOL>(0xA90490, invoke<BOOL>(0xA90500, ped, x1, y1, z1, x2, y2, z2, p7, invoke<BOOL>(0xA90560, x1, y1, z1, x2, y2, z2, p6, invoke<BOOL>(0xA905A0, invoke<BOOL>(0xA905E0, ped, accuracy)
end

function GET_PED_ACCURACY(invoke<int>(0xA906D0, multiplier)
    return Velora.invoke(0xA90740, "int", invoke<int>(0xA906D0, multiplier)
end

function IS_PED_MODEL(ped, invoke<BOOL>(0xA90770, ped, weaponHash)
    return Velora.invoke(0xA90830, "bool", ped, invoke<BOOL>(0xA90770, ped, weaponHash)
end

function REMOVE_PED_ELEGANTLY(ped)
    Velora.invoke(0xA90840, "void", ped)
end

function ADD_ARMOUR_TO_PED(ped, amount)
    Velora.invoke(0xA90850, "void", ped, amount)
end

function SET_PED_ARMOUR(ped, amount)
    Velora.invoke(0xA90930, "void", ped, amount)
end

function SET_PED_INTO_VEHICLE(ped, vehicle, seatIndex)
    Velora.invoke(0xA90A10, "void", ped, vehicle, seatIndex)
end

function SET_PED_ALLOW_VEHICLES_OVERRIDE(ped, toggle)
    Velora.invoke(0xA90A30, "void", ped, toggle)
end

function CAN_CREATE_RANDOM_PED(invoke<BOOL>(0xA90A90, posX, posY, invoke<Ped>(0xA90B50, vehicle, invoke<Ped>(0xA90BD0, ped)
    return Velora.invoke(0xA90CB0, "bool", invoke<BOOL>(0xA90A90, posX, posY, invoke<Ped>(0xA90B50, vehicle, invoke<Ped>(0xA90BD0, ped)
end

function SET_PED_CAN_BE_DRAGGED_OUT(ped, toggle)
    Velora.invoke(0xA90D10, "void", ped, toggle)
end

function SET_PED_ALLOW_HURT_COMBAT_FOR_ALL_MISSION_PEDS(toggle)
    Velora.invoke(0xA90D70, "void", toggle)
end

function IS_PED_MALE(invoke<BOOL>(0xA90D90, invoke<BOOL>(0xA90E00, ped, invoke<Vehicle>(0xA90E80, ped)
    return Velora.invoke(0xA90EB0, "bool", invoke<BOOL>(0xA90D90, invoke<BOOL>(0xA90E00, ped, invoke<Vehicle>(0xA90E80, ped)
end

function SET_PED_DENSITY_MULTIPLIER_THIS_FRAME(multiplier)
    Velora.invoke(0xA90F10, "void", multiplier)
end

function SET_SCENARIO_PED_DENSITY_MULTIPLIER_THIS_FRAME(p0, p1)
    Velora.invoke(0xA90F20, "void", p0, p1)
end

function SUPPRESS_AMBIENT_PED_AGGRESSIVE_CLEANUP_THIS_FRAME()
    Velora.invoke(0xA90F40, "void")
end

function SET_SCRIPTED_CONVERSION_COORD_THIS_FRAME(x, y, z)
    Velora.invoke(0xA90F50, "void", x, y, z)
end

function SET_PED_NON_CREATION_AREA(x1, y1, z1, x2, y2, z2)
    Velora.invoke(0xA90FB0, "void", x1, y1, z1, x2, y2, z2)
end

function CLEAR_PED_NON_CREATION_AREA()
    Velora.invoke(0xA91030, "void")
end

function INSTANTLY_FILL_PED_POPULATION()
    Velora.invoke(0xA91040, "void")
end

function IS_PED_ON_MOUNT(invoke<BOOL>(0xA91050, invoke<Ped>(0xA91090, invoke<BOOL>(0xA910D0, ped, invoke<BOOL>(0xA91130, ped, amount)
    return Velora.invoke(0xA911D0, "bool", invoke<BOOL>(0xA91050, invoke<Ped>(0xA91090, invoke<BOOL>(0xA910D0, ped, invoke<BOOL>(0xA91130, ped, amount)
end

function GET_PED_MONEY(invoke<int>(0xA91230, p0, p1)
    return Velora.invoke(0xA91280, "int", invoke<int>(0xA91230, p0, p1)
end

function SET_AMBIENT_PEDS_DROP_MONEY(p0)
    Velora.invoke(0xA912C0, "void", p0)
end

function SET_BLOCKING_OF_NON_TEMPORARY_EVENTS_FOR_AMBIENT_PEDS_THIS_FRAME(p0)
    Velora.invoke(0xA912F0, "void", p0)
end

function SET_PED_SUFFERS_CRITICAL_HITS(ped, toggle)
    Velora.invoke(0xA91310, "void", ped, toggle)
end

function SET_PED_UPPER_BODY_DAMAGE_ONLY(ped, toggle)
    Velora.invoke(0xA91360, "void", ped, toggle)
end

function IS_PED_SITTING_IN_VEHICLE(ped, invoke<BOOL>(0xA913C0, invoke<BOOL>(0xA913F0, invoke<BOOL>(0xA91480, invoke<BOOL>(0xA914B0, invoke<BOOL>(0xA91520, ped, p1, invoke<Vector3>(0xA91590, invoke<BOOL>(0xA91600, invoke<BOOL>(0xA91670, invoke<BOOL>(0xA916E0, invoke<BOOL>(0xA91750, invoke<BOOL>(0xA917C0, ped, toggle)
    return Velora.invoke(0xA91840, "bool", ped, invoke<BOOL>(0xA913C0, invoke<BOOL>(0xA913F0, invoke<BOOL>(0xA91480, invoke<BOOL>(0xA914B0, invoke<BOOL>(0xA91520, ped, p1, invoke<Vector3>(0xA91590, invoke<BOOL>(0xA91600, invoke<BOOL>(0xA91670, invoke<BOOL>(0xA916E0, invoke<BOOL>(0xA91750, invoke<BOOL>(0xA917C0, ped, toggle)
end

function GET_PED_DIES_IN_WATER(invoke<BOOL>(0xA91890, ped, toggle)
    return Velora.invoke(0xA918F0, "bool", invoke<BOOL>(0xA91890, ped, toggle)
end

function GET_PED_ARMOUR(invoke<int>(0xA91940, ped, toggle)
    return Velora.invoke(0xA91990, "int", invoke<int>(0xA91940, ped, toggle)
end

function SET_PED_CAN_BE_SHOT_IN_VEHICLE(ped, toggle)
    Velora.invoke(0xA919F0, "void", ped, toggle)
end

function GET_PED_LAST_DAMAGE_BONE(ped, invoke<BOOL>(0xA91A50, ped)
    return Velora.invoke(0xA91AC0, "bool", ped, invoke<BOOL>(0xA91A50, ped)
end

function SET_AI_WEAPON_DAMAGE_MODIFIER(value)
    Velora.invoke(0xA91B10, "void", value)
end

function RESET_AI_WEAPON_DAMAGE_MODIFIER()
    Velora.invoke(0xA91B30, "void")
end

function SET_AI_MELEE_WEAPON_DAMAGE_MODIFIER(modifier)
    Velora.invoke(0xA91B50, "void", modifier)
end

function RESET_AI_MELEE_WEAPON_DAMAGE_MODIFIER()
    Velora.invoke(0xA91B70, "void")
end

function SET_TREAT_AS_AMBIENT_PED_FOR_DRIVER_LOCKON(ped, p1)
    Velora.invoke(0xA91B90, "void", ped, p1)
end

function SET_PED_CAN_BE_TARGETTED(ped, toggle)
    Velora.invoke(0xA91BE0, "void", ped, toggle)
end

function SET_PED_CAN_BE_TARGETTED_BY_TEAM(ped, team, toggle)
    Velora.invoke(0xA91C40, "void", ped, team, toggle)
end

function SET_PED_CAN_BE_TARGETTED_BY_PLAYER(ped, player, toggle)
    Velora.invoke(0xA91CC0, "void", ped, player, toggle)
end

function SET_ALLOW_LOCKON_TO_PED_IF_FRIENDLY(ped, toggle)
    Velora.invoke(0xA91D40, "void", ped, toggle)
end

function SET_USE_CAMERA_HEADING_FOR_DESIRED_DIRECTION_LOCK_ON_TEST(ped, toggle)
    Velora.invoke(0xA91DA0, "void", ped, toggle)
end

function IS_PED_IN_ANY_POLICE_VEHICLE(invoke<BOOL>(0xA91E00, ped)
    return Velora.invoke(0xA91E70, "bool", invoke<BOOL>(0xA91E00, ped)
end

function IS_PED_IN_PARACHUTE_FREE_FALL(invoke<BOOL>(0xA91ED0, invoke<BOOL>(0xA91F90, invoke<BOOL>(0xA91FF0, invoke<BOOL>(0xA92050, invoke<BOOL>(0xA920B0, invoke<BOOL>(0xA92130, invoke<BOOL>(0xA92190, invoke<BOOL>(0xA921F0, invoke<BOOL>(0xA92250, invoke<BOOL>(0xA92280, invoke<int>(0xA92310, invoke<int>(0xA923E0, ped, tintIndex)
    return Velora.invoke(0xA92450, "bool", invoke<BOOL>(0xA91ED0, invoke<BOOL>(0xA91F90, invoke<BOOL>(0xA91FF0, invoke<BOOL>(0xA92050, invoke<BOOL>(0xA920B0, invoke<BOOL>(0xA92130, invoke<BOOL>(0xA92190, invoke<BOOL>(0xA921F0, invoke<BOOL>(0xA92250, invoke<BOOL>(0xA92280, invoke<int>(0xA92310, invoke<int>(0xA923E0, ped, tintIndex)
end

function GET_PED_PARACHUTE_TINT_INDEX(ped, outTintIndex)
    Velora.invoke(0xA924A0, "void", ped, outTintIndex)
end

function SET_PED_RESERVE_PARACHUTE_TINT_INDEX(ped, p1)
    Velora.invoke(0xA924F0, "void", ped, p1)
end

function CREATE_PARACHUTE_BAG_OBJECT(ped, p1, invoke<Object>(0xA92540, ped, toggle)
    return Velora.invoke(0xA925D0, "int", ped, p1, invoke<Object>(0xA92540, ped, toggle)
end

function IS_PED_DUCKING(invoke<BOOL>(0xA92630, invoke<BOOL>(0xA92690, ped, value)
    return Velora.invoke(0xA92750, "bool", invoke<BOOL>(0xA92630, invoke<BOOL>(0xA92690, ped, value)
end

function SET_PED_HIGHLY_PERCEPTIVE(ped, toggle)
    Velora.invoke(0xA927B0, "void", ped, toggle)
end

function SET_COP_PERCEPTION_OVERRIDES(seeingRange, seeingRangePeripheral, hearingRange, visualFieldMinAzimuthAngle, visualFieldMaxAzimuthAngle, fieldOfGazeMaxAngle, p6)
    Velora.invoke(0xA92800, "void", seeingRange, seeingRangePeripheral, hearingRange, visualFieldMinAzimuthAngle, visualFieldMaxAzimuthAngle, fieldOfGazeMaxAngle, p6)
end

function SET_PED_INJURED_ON_GROUND_BEHAVIOUR(ped, p1)
    Velora.invoke(0xA92880, "void", ped, p1)
end

function DISABLE_PED_INJURED_ON_GROUND_BEHAVIOUR(ped)
    Velora.invoke(0xA928F0, "void", ped)
end

function SET_PED_SEEING_RANGE(ped, value)
    Velora.invoke(0xA92940, "void", ped, value)
end

function SET_PED_HEARING_RANGE(ped, value)
    Velora.invoke(0xA929A0, "void", ped, value)
end

function SET_PED_VISUAL_FIELD_MIN_ANGLE(ped, value)
    Velora.invoke(0xA92A00, "void", ped, value)
end

function SET_PED_VISUAL_FIELD_MAX_ANGLE(ped, value)
    Velora.invoke(0xA92A60, "void", ped, value)
end

function SET_PED_VISUAL_FIELD_MIN_ELEVATION_ANGLE(ped, angle)
    Velora.invoke(0xA92AC0, "void", ped, angle)
end

function SET_PED_VISUAL_FIELD_MAX_ELEVATION_ANGLE(ped, angle)
    Velora.invoke(0xA92B20, "void", ped, angle)
end

function SET_PED_VISUAL_FIELD_PERIPHERAL_RANGE(ped, range)
    Velora.invoke(0xA92B80, "void", ped, range)
end

function SET_PED_VISUAL_FIELD_CENTER_ANGLE(ped, angle)
    Velora.invoke(0xA92BE0, "void", ped, angle)
end

function GET_PED_VISUAL_FIELD_CENTER_ANGLE(invoke<float>(0xA92C40, ped, p1, action)
    return Velora.invoke(0xA92CA0, "float", invoke<float>(0xA92C40, ped, p1, action)
end

function GET_PED_STEALTH_MOVEMENT(invoke<BOOL>(0xA92D60, invoke<int>(0xA92DC0, ped, groupId)
    return Velora.invoke(0xA92E40, "bool", invoke<BOOL>(0xA92D60, invoke<int>(0xA92DC0, ped, groupId)
end

function SET_PED_AS_GROUP_MEMBER(ped, groupId)
    Velora.invoke(0xA92E50, "void", ped, groupId)
end

function SET_PED_CAN_TELEPORT_TO_GROUP_LEADER(pedHandle, groupHandle, toggle)
    Velora.invoke(0xA92E60, "void", pedHandle, groupHandle, toggle)
end

function REMOVE_GROUP(groupId)
    Velora.invoke(0xA92E80, "void", groupId)
end

function REMOVE_PED_FROM_GROUP(ped)
    Velora.invoke(0xA92E90, "void", ped)
end

function IS_PED_GROUP_MEMBER(ped, invoke<BOOL>(0xA92EA0, invoke<BOOL>(0xA92ED0, groupHandle, separationRange)
    return Velora.invoke(0xA92F70, "bool", ped, invoke<BOOL>(0xA92EA0, invoke<BOOL>(0xA92ED0, groupHandle, separationRange)
end

function SET_PED_MIN_GROUND_TIME_FOR_STUNGUN(ped, ms)
    Velora.invoke(0xA92F80, "void", ped, ms)
end

function IS_PED_PRONE(invoke<BOOL>(0xA92FC0, ped, invoke<BOOL>(0xA93020, ped, invoke<Entity>(0xA93050, ped, invoke<BOOL>(0xA93080, invoke<BOOL>(0xA93130, invoke<BOOL>(0xA931C0, invoke<BOOL>(0xA931F0, ped, invoke<BOOL>(0xA93220, invoke<Ped>(0xA93250, invoke<Ped>(0xA93270, invoke<BOOL>(0xA93290, ped, invoke<BOOL>(0xA932C0, invoke<BOOL>(0xA932F0, invoke<BOOL>(0xA93320, invoke<BOOL>(0xA93350, ped, pinned, invoke<BOOL>(0xA93410, invoke<int>(0xA935A0, invoke<Vehicle>(0xA935C0, invoke<Entity>(0xA935E0, invoke<Hash>(0xA93640, invoke<int>(0xA93690, invoke<int>(0xA936E0, ped, x, y, z, invoke<int>(0xA93750, ped, hash)
    return Velora.invoke(0xA93820, "bool", invoke<BOOL>(0xA92FC0, ped, invoke<BOOL>(0xA93020, ped, invoke<Entity>(0xA93050, ped, invoke<BOOL>(0xA93080, invoke<BOOL>(0xA93130, invoke<BOOL>(0xA931C0, invoke<BOOL>(0xA931F0, ped, invoke<BOOL>(0xA93220, invoke<Ped>(0xA93250, invoke<Ped>(0xA93270, invoke<BOOL>(0xA93290, ped, invoke<BOOL>(0xA932C0, invoke<BOOL>(0xA932F0, invoke<BOOL>(0xA93320, invoke<BOOL>(0xA93350, ped, pinned, invoke<BOOL>(0xA93410, invoke<int>(0xA935A0, invoke<Vehicle>(0xA935C0, invoke<Entity>(0xA935E0, invoke<Hash>(0xA93640, invoke<int>(0xA93690, invoke<int>(0xA936E0, ped, x, y, z, invoke<int>(0xA93750, ped, hash)
end

function SET_PED_RELATIONSHIP_GROUP_HASH(ped, hash)
    Velora.invoke(0xA93880, "void", ped, hash)
end

function SET_RELATIONSHIP_BETWEEN_GROUPS(relationship, group1, group2)
    Velora.invoke(0xA93890, "void", relationship, group1, group2)
end

function CLEAR_RELATIONSHIP_BETWEEN_GROUPS(relationship, group1, group2)
    Velora.invoke(0xA93910, "void", relationship, group1, group2)
end

function ADD_RELATIONSHIP_GROUP(name, invoke<BOOL>(0xA93950, groupHash)
    return Velora.invoke(0xA939C0, "bool", name, invoke<BOOL>(0xA93950, groupHash)
end

function DOES_RELATIONSHIP_GROUP_EXIST(invoke<BOOL>(0xA939D0, ped1, invoke<int>(0xA93A00, invoke<Hash>(0xA93AB0, invoke<Hash>(0xA93B10, group1, invoke<int>(0xA93B70, group, p1)
    return Velora.invoke(0xA93BD0, "bool", invoke<BOOL>(0xA939D0, ped1, invoke<int>(0xA93A00, invoke<Hash>(0xA93AB0, invoke<Hash>(0xA93B10, group1, invoke<int>(0xA93B70, group, p1)
end

function TELL_GROUP_PEDS_IN_AREA_TO_ATTACK(ped, p1, p2, hash, p4, p5)
    Velora.invoke(0xA93C60, "void", ped, p1, p2, hash, p4, p5)
end

function SET_PED_CAN_BE_TARGETED_WITHOUT_LOS(ped, toggle)
    Velora.invoke(0xA93C80, "void", ped, toggle)
end

function SET_PED_TO_INFORM_RESPECTED_FRIENDS(ped, radius, maxFriends)
    Velora.invoke(0xA93CE0, "void", ped, radius, maxFriends)
end

function IS_PED_RESPONDING_TO_EVENT(ped, invoke<BOOL>(0xA93D60, ped, eventType, invoke<BOOL>(0xA93DC0, ped, patternHash)
    return Velora.invoke(0xA93E40, "bool", ped, invoke<BOOL>(0xA93D60, ped, eventType, invoke<BOOL>(0xA93DC0, ped, patternHash)
end

function SET_PED_SHOOT_RATE(ped, shootRate)
    Velora.invoke(0xA93E50, "void", ped, shootRate)
end

function SET_COMBAT_FLOAT(ped, combatType, p2)
    Velora.invoke(0xA93F00, "void", ped, combatType, p2)
end

function GET_COMBAT_FLOAT(ped, invoke<float>(0xA93F70, groupID, p1, sizeInMembers)
    return Velora.invoke(0xA93FF0, "float", ped, invoke<float>(0xA93F70, groupID, p1, sizeInMembers)
end

function DOES_GROUP_EXIST(invoke<BOOL>(0xA94080, invoke<int>(0xA940C0, invoke<BOOL>(0xA940E0, invoke<Player>(0xA94140, groupId, formationType)
    return Velora.invoke(0xA94160, "bool", invoke<BOOL>(0xA94080, invoke<int>(0xA940C0, invoke<BOOL>(0xA940E0, invoke<Player>(0xA94140, groupId, formationType)
end

function SET_GROUP_FORMATION_SPACING(groupId, x, y, z)
    Velora.invoke(0xA941D0, "void", groupId, x, y, z)
end

function RESET_GROUP_FORMATION_DEFAULT_SPACING(groupHandle)
    Velora.invoke(0xA94280, "void", groupHandle)
end

function GET_VEHICLE_PED_IS_USING(invoke<Vehicle>(0xA94300, invoke<Vehicle>(0xA94380, ped, toggle)
    return Velora.invoke(0xA943A0, "int", invoke<Vehicle>(0xA94300, invoke<Vehicle>(0xA94380, ped, toggle)
end

function APPLY_DAMAGE_TO_PED(ped, damageAmount, p2, p3)
    Velora.invoke(0xA94490, "void", ped, damageAmount, p2, p3)
end

function GET_TIME_PED_DAMAGED_BY_WEAPON(ped, invoke<int>(0xA94600, ped, toggle)
    return Velora.invoke(0xA946B0, "int", ped, invoke<int>(0xA94600, ped, toggle)
end

function SET_PED_NEVER_LEAVES_GROUP(ped, toggle)
    Velora.invoke(0xA94710, "void", ped, toggle)
end

function GET_PED_TYPE(invoke<int>(0xA94770, ped, toggle)
    return Velora.invoke(0xA947D0, "int", invoke<int>(0xA94770, ped, toggle)
end

function SET_PED_HEALTH_PENDING_LAST_DAMAGE_EVENT_OVERRIDE_FLAG(toggle)
    Velora.invoke(0xA94860, "void", toggle)
end

function SET_PED_MAX_HEALTH(ped, value)
    Velora.invoke(0xA94890, "void", ped, value)
end

function GET_PED_MAX_HEALTH(invoke<int>(0xA94900, ped, value)
    return Velora.invoke(0xA94950, "int", invoke<int>(0xA94900, ped, value)
end

function SET_PED_MAX_TIME_UNDERWATER(ped, value)
    Velora.invoke(0xA949D0, "void", ped, value)
end

function SET_CORPSE_RAGDOLL_FRICTION(ped, p1)
    Velora.invoke(0xA94A30, "void", ped, p1)
end

function SET_PED_VEHICLE_FORCED_SEAT_USAGE(ped, vehicle, seatIndex, flags, p4)
    Velora.invoke(0xA94A80, "void", ped, vehicle, seatIndex, flags, p4)
end

function CLEAR_ALL_PED_VEHICLE_FORCED_SEAT_USAGE(ped)
    Velora.invoke(0xA94AA0, "void", ped)
end

function SET_PED_CAN_BE_KNOCKED_OFF_BIKE(p0, p1)
    Velora.invoke(0xA94AF0, "void", p0, p1)
end

function SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(ped, state)
    Velora.invoke(0xA94B00, "void", ped, state)
end

function CAN_KNOCK_PED_OFF_VEHICLE(invoke<BOOL>(0xA94B80, ped)
    return Velora.invoke(0xA94C40, "bool", invoke<BOOL>(0xA94B80, ped)
end

function SET_PED_COORDS_NO_GANG(ped, posX, posY, posZ)
    Velora.invoke(0xA94C50, "void", ped, posX, posY, posZ)
end

function GET_PED_AS_GROUP_MEMBER(groupID, invoke<Ped>(0xA94CC0, invoke<Ped>(0xA94D40, ped, toggle)
    return Velora.invoke(0xA94DB0, "int", groupID, invoke<Ped>(0xA94CC0, invoke<Ped>(0xA94D40, ped, toggle)
end

function SET_PED_ALLOW_MINOR_REACTIONS_AS_MISSION_PED(ped, toggle)
    Velora.invoke(0xA94E10, "void", ped, toggle)
end

function IS_PED_SWIMMING(invoke<BOOL>(0xA94E60, invoke<BOOL>(0xA94EC0, ped, posX, posY, posZ)
    return Velora.invoke(0xA94F30, "bool", invoke<BOOL>(0xA94E60, invoke<BOOL>(0xA94EC0, ped, posX, posY, posZ)
end

function SET_PED_DIES_IN_VEHICLE(ped, toggle)
    Velora.invoke(0xA94FC0, "void", ped, toggle)
end

function SET_CREATE_RANDOM_COPS(toggle)
    Velora.invoke(0xA95020, "void", toggle)
end

function SET_CREATE_RANDOM_COPS_NOT_ON_SCENARIOS(toggle)
    Velora.invoke(0xA95050, "void", toggle)
end

function SET_CREATE_RANDOM_COPS_ON_SCENARIOS(toggle)
    Velora.invoke(0xA95070, "void", toggle)
end

function CAN_CREATE_RANDOM_COPS(ped, toggle)
    return Velora.invoke(0xA950B0, "bool", ped, toggle)
end

function SET_PED_CAN_SMASH_GLASS(ped, p1, p2)
    Velora.invoke(0xA95100, "void", ped, p1, p2)
end

function IS_PED_IN_ANY_TRAIN(invoke<BOOL>(0xA95170, invoke<BOOL>(0xA951F0, invoke<BOOL>(0xA95220, ped, toggle)
    return Velora.invoke(0xA952E0, "bool", invoke<BOOL>(0xA95170, invoke<BOOL>(0xA951F0, invoke<BOOL>(0xA95220, ped, toggle)
end

function SET_ENABLE_BOUND_ANKLES(ped, toggle)
    Velora.invoke(0xA95360, "void", ped, toggle)
end

function SET_ENABLE_SCUBA(ped, toggle)
    Velora.invoke(0xA953E0, "void", ped, toggle)
end

function SET_CAN_ATTACK_FRIENDLY(ped, toggle, p2)
    Velora.invoke(0xA95440, "void", ped, toggle, p2)
end

function GET_PED_ALERTNESS(invoke<int>(0xA954C0, ped, value)
    return Velora.invoke(0xA95520, "int", invoke<int>(0xA954C0, ped, value)
end

function SET_PED_GET_OUT_UPSIDE_DOWN_VEHICLE(ped, toggle)
    Velora.invoke(0xA95570, "void", ped, toggle)
end

function SET_PED_MOVEMENT_CLIPSET(ped, clipSet, transitionSpeed)
    Velora.invoke(0xA955D0, "void", ped, clipSet, transitionSpeed)
end

function RESET_PED_MOVEMENT_CLIPSET(ped, p1)
    Velora.invoke(0xA955F0, "void", ped, p1)
end

function SET_PED_STRAFE_CLIPSET(ped, clipSet)
    Velora.invoke(0xA95660, "void", ped, clipSet)
end

function RESET_PED_STRAFE_CLIPSET(ped)
    Velora.invoke(0xA95670, "void", ped)
end

function SET_PED_WEAPON_MOVEMENT_CLIPSET(ped, clipSet)
    Velora.invoke(0xA956D0, "void", ped, clipSet)
end

function RESET_PED_WEAPON_MOVEMENT_CLIPSET(ped)
    Velora.invoke(0xA956E0, "void", ped)
end

function SET_PED_DRIVE_BY_CLIPSET_OVERRIDE(ped, clipset)
    Velora.invoke(0xA95740, "void", ped, clipset)
end

function CLEAR_PED_DRIVE_BY_CLIPSET_OVERRIDE(ped)
    Velora.invoke(0xA95750, "void", ped)
end

function SET_PED_MOTION_IN_COVER_CLIPSET_OVERRIDE(ped, p1)
    Velora.invoke(0xA957A0, "void", ped, p1)
end

function CLEAR_PED_MOTION_IN_COVER_CLIPSET_OVERRIDE(ped)
    Velora.invoke(0xA957B0, "void", ped)
end

function CLEAR_PED_FALL_UPPER_BODY_CLIPSET_OVERRIDE(ped)
    Velora.invoke(0xA95800, "void", ped)
end

function SET_PED_IN_VEHICLE_CONTEXT(ped, context)
    Velora.invoke(0xA95850, "void", ped, context)
end

function RESET_PED_IN_VEHICLE_CONTEXT(ped)
    Velora.invoke(0xA958C0, "void", ped)
end

function IS_SCRIPTED_SCENARIO_PED_USING_CONDITIONAL_ANIM(ped, animDict, invoke<BOOL>(0xA95920, ped, animDict, animName, p3, p4)
    return Velora.invoke(0xA95950, "bool", ped, animDict, invoke<BOOL>(0xA95920, ped, animDict, animName, p3, p4)
end

function CLEAR_PED_ALTERNATE_WALK_ANIM(ped, p1)
    Velora.invoke(0xA95980, "void", ped, p1)
end

function SET_PED_ALTERNATE_MOVEMENT_ANIM(ped, stance, animDictionary, animationName, p4, p5)
    Velora.invoke(0xA95A20, "void", ped, stance, animDictionary, animationName, p4, p5)
end

function CLEAR_PED_ALTERNATE_MOVEMENT_ANIM(ped, stance, p2)
    Velora.invoke(0xA95A50, "void", ped, stance, p2)
end

function SET_PED_GESTURE_GROUP(ped, animGroupGesture)
    Velora.invoke(0xA95B00, "void", ped, animGroupGesture)
end

function GET_ANIM_INITIAL_OFFSET_POSITION(animDict, animName, x, y, z, xRot, yRot, zRot, p8, invoke<Vector3>(0xA95B90, animDict, animName, x, y, z, xRot, yRot, zRot, p8, invoke<Vector3>(0xA95CA0, ped, invoke<int>(0xA95DB0, ped, invoke<int>(0xA95E20, ped, invoke<int>(0xA95E50, ped, componentId, invoke<int>(0xA95EC0, ped, invoke<int>(0xA95EF0, ped, propId, invoke<int>(0xA95F20, ped, invoke<int>(0xA95F50, p0, invoke<BOOL>(0xA95FB0, invoke<int>(0xA95FE0, invoke<int>(0xA96000, ped, componentId, drawableId, invoke<BOOL>(0xA96020, ped, componentId, drawableId, textureId, paletteId)
    local x, y, z = Velora.invoke(0xA960A0, "vector3", animDict, animName, x, y, z, xRot, yRot, zRot, p8, invoke<Vector3>(0xA95B90, animDict, animName, x, y, z, xRot, yRot, zRot, p8, invoke<Vector3>(0xA95CA0, ped, invoke<int>(0xA95DB0, ped, invoke<int>(0xA95E20, ped, invoke<int>(0xA95E50, ped, componentId, invoke<int>(0xA95EC0, ped, invoke<int>(0xA95EF0, ped, propId, invoke<int>(0xA95F20, ped, invoke<int>(0xA95F50, p0, invoke<BOOL>(0xA95FB0, invoke<int>(0xA95FE0, invoke<int>(0xA96000, ped, componentId, drawableId, invoke<BOOL>(0xA96020, ped, componentId, drawableId, textureId, paletteId)
    return {x = x, y = y, z = z}
end

function SET_PED_RANDOM_COMPONENT_VARIATION(ped, p1)
    Velora.invoke(0xA96160, "void", ped, p1)
end

function SET_PED_RANDOM_PROPS(ped)
    Velora.invoke(0xA96200, "void", ped)
end

function SET_PED_DEFAULT_COMPONENT_VARIATION(ped)
    Velora.invoke(0xA962B0, "void", ped)
end

function SET_PED_BLEND_FROM_PARENTS(ped, p1, p2, p3, p4)
    Velora.invoke(0xA96330, "void", ped, p1, p2, p3, p4)
end

function SET_PED_HEAD_BLEND_DATA(ped, shapeFirstID, shapeSecondID, shapeThirdID, skinFirstID, skinSecondID, skinThirdID, shapeMix, skinMix, thirdMix, isParent)
    Velora.invoke(0xA96350, "void", ped, shapeFirstID, shapeSecondID, shapeThirdID, skinFirstID, skinSecondID, skinThirdID, shapeMix, skinMix, thirdMix, isParent)
end

function GET_PED_HEAD_BLEND_DATA(ped, invoke<BOOL>(0xA964B0, ped, shapeMix, skinMix, thirdMix)
    return Velora.invoke(0xA965A0, "bool", ped, invoke<BOOL>(0xA964B0, ped, shapeMix, skinMix, thirdMix)
end

function SET_HEAD_BLEND_EYE_COLOR(ped, index)
    Velora.invoke(0xA96620, "void", ped, index)
end

function GET_HEAD_BLEND_EYE_COLOR(invoke<int>(0xA96670, ped, overlayID, index, opacity)
    return Velora.invoke(0xA966D0, "int", invoke<int>(0xA96670, ped, overlayID, index, opacity)
end

function GET_PED_HEAD_OVERLAY(ped, invoke<int>(0xA96750, invoke<int>(0xA967C0, ped, overlayID, colorType, colorID, secondColorID)
    return Velora.invoke(0xA968E0, "int", ped, invoke<int>(0xA96750, invoke<int>(0xA967C0, ped, overlayID, colorType, colorID, secondColorID)
end

function SET_PED_HAIR_TINT(ped, colorID, highlightColorID)
    Velora.invoke(0xA96960, "void", ped, colorID, highlightColorID)
end

function GET_NUM_PED_HAIR_TINTS(hairColorIndex, outR, outG, outB)
    return Velora.invoke(0xA969E0, "int", hairColorIndex, outR, outG, outB)
end

function GET_PED_MAKEUP_TINT_COLOR(makeupColorIndex, outR, outG, outB)
    Velora.invoke(0xA96A30, "void", makeupColorIndex, outR, outG, outB)
end

function IS_PED_HAIR_TINT_FOR_CREATOR(invoke<BOOL>(0xA96A80, invoke<int>(0xA96AD0, invoke<BOOL>(0xA96B10, invoke<BOOL>(0xA96B60, invoke<BOOL>(0xA96BB0, invoke<int>(0xA96C00, invoke<BOOL>(0xA96C40, invoke<BOOL>(0xA96C90, invoke<BOOL>(0xA96CE0, modelHash, drawableId, invoke<int>(0xA96D30, ped, index, scale)
    return Velora.invoke(0xA96E10, "bool", invoke<BOOL>(0xA96A80, invoke<int>(0xA96AD0, invoke<BOOL>(0xA96B10, invoke<BOOL>(0xA96B60, invoke<BOOL>(0xA96BB0, invoke<int>(0xA96C00, invoke<BOOL>(0xA96C40, invoke<BOOL>(0xA96C90, invoke<BOOL>(0xA96CE0, modelHash, drawableId, invoke<int>(0xA96D30, ped, index, scale)
end

function HAS_PED_HEAD_BLEND_FINISHED(invoke<BOOL>(0xA96E80, ped)
    return Velora.invoke(0xA96EE0, "bool", invoke<BOOL>(0xA96E80, ped)
end

function SET_HEAD_BLEND_PALETTE_COLOR(ped, r, g, b, id)
    Velora.invoke(0xA96F30, "void", ped, r, g, b, id)
end

function DISABLE_HEAD_BLEND_PALETTE_COLOR(ped)
    Velora.invoke(0xA96FF0, "void", ped)
end

function GET_PED_HEAD_BLEND_FIRST_INDEX(invoke<int>(0xA97040, invoke<int>(0xA970A0, ped, slot, drawableId, invoke<int>(0xA97110, invoke<BOOL>(0xA971D0, ped)
    return Velora.invoke(0xA97230, "int", invoke<int>(0xA97040, invoke<int>(0xA970A0, ped, slot, drawableId, invoke<int>(0xA97110, invoke<BOOL>(0xA971D0, ped)
end

function SET_PED_PRELOAD_PROP_DATA(ped, componentId, drawableId, invoke<int>(0xA97280, invoke<BOOL>(0xA97340, ped)
    return Velora.invoke(0xA973A0, "int", ped, componentId, drawableId, invoke<int>(0xA97280, invoke<BOOL>(0xA97340, ped)
end

function GET_PED_PROP_INDEX(ped, componentId, invoke<int>(0xA973F0, ped, componentId, drawableId, TextureId, attach, p5)
    return Velora.invoke(0xA97450, "int", ped, componentId, invoke<int>(0xA973F0, ped, componentId, drawableId, TextureId, attach, p5)
end

function KNOCK_OFF_PED_PROP(ped, p1, p2, p3, p4)
    Velora.invoke(0xA97480, "void", ped, p1, p2, p3, p4)
end

function CLEAR_PED_PROP(ped, propId, p2)
    Velora.invoke(0xA97520, "void", ped, propId, p2)
end

function CLEAR_ALL_PED_PROPS(ped, p1)
    Velora.invoke(0xA97580, "void", ped, p1)
end

function DROP_AMBIENT_PROP(ped)
    Velora.invoke(0xA975D0, "void", ped)
end

function GET_PED_PROP_TEXTURE_INDEX(ped, invoke<int>(0xA97660, ped)
    return Velora.invoke(0xA976C0, "int", ped, invoke<int>(0xA97660, ped)
end

function SET_PED_SCUBA_GEAR_VARIATION(ped)
    Velora.invoke(0xA97710, "void", ped)
end

function CLEAR_PED_SCUBA_GEAR_VARIATION(ped)
    Velora.invoke(0xA97760, "void", ped)
end

function IS_USING_PED_SCUBA_GEAR_VARIATION(invoke<BOOL>(0xA977B0, ped, toggle)
    return Velora.invoke(0xA97810, "bool", invoke<BOOL>(0xA977B0, ped, toggle)
end

function SET_PED_BOUNDS_ORIENTATION(ped, p1, p2, x, y, z)
    Velora.invoke(0xA97830, "void", ped, p1, p2, x, y, z)
end

function REGISTER_TARGET(ped, target)
    Velora.invoke(0xA978D0, "void", ped, target)
end

function REGISTER_HATED_TARGETS_AROUND_PED(ped, radius)
    Velora.invoke(0xA97980, "void", ped, radius)
end

function GET_RANDOM_PED_AT_COORD(x, y, z, xRadius, yRadius, zRadius, invoke<Ped>(0xA97A20, x, y, z, radius, p4, p5, outPed, p7, p8, invoke<BOOL>(0xA97A50, value)
    return Velora.invoke(0xA97B50, "int", x, y, z, xRadius, yRadius, zRadius, invoke<Ped>(0xA97A20, x, y, z, radius, p4, p5, outPed, p7, p8, invoke<BOOL>(0xA97A50, value)
end

function GET_CAN_PED_BE_GRABBED_BY_SCRIPT(ped, p1, p2, p3, p4, p5, p6, p7, invoke<BOOL>(0xA97B70, driver, modifier)
    return Velora.invoke(0xA97C60, "bool", ped, p1, p2, p3, p4, p5, p6, p7, invoke<BOOL>(0xA97B70, driver, modifier)
end

function SET_DRIVER_ABILITY(driver, ability)
    Velora.invoke(0xA97CD0, "void", driver, ability)
end

function SET_DRIVER_AGGRESSIVENESS(driver, aggressiveness)
    Velora.invoke(0xA97D40, "void", driver, aggressiveness)
end

function CAN_PED_RAGDOLL(invoke<BOOL>(0xA97DB0, ped, time1, time2, ragdollType, p4, p5, invoke<BOOL>(0xA97E30, ped, time, p2, ragdollType, x, y, z, velocity, p8, p9, p10, p11, p12, invoke<BOOL>(0xA97E90, ped, toggle)
    return Velora.invoke(0xA97EE0, "bool", invoke<BOOL>(0xA97DB0, ped, time1, time2, ragdollType, p4, p5, invoke<BOOL>(0xA97E30, ped, time, p2, ragdollType, x, y, z, velocity, p8, p9, p10, p11, p12, invoke<BOOL>(0xA97E90, ped, toggle)
end

function IS_PED_RAGDOLL(invoke<BOOL>(0xA97F00, invoke<BOOL>(0xA97F70, ped)
    return Velora.invoke(0xA98000, "bool", invoke<BOOL>(0xA97F00, invoke<BOOL>(0xA97F70, ped)
end

function RESET_PED_RAGDOLL_TIMER(ped)
    Velora.invoke(0xA98080, "void", ped)
end

function SET_PED_CAN_RAGDOLL(ped, toggle)
    Velora.invoke(0xA980F0, "void", ped, toggle)
end

function IS_PED_RUNNING_MELEE_TASK(invoke<BOOL>(0xA98110, invoke<BOOL>(0xA98170, invoke<BOOL>(0xA981C0, ped, blockingFlag)
    return Velora.invoke(0xA98250, "bool", invoke<BOOL>(0xA98110, invoke<BOOL>(0xA98170, invoke<BOOL>(0xA981C0, ped, blockingFlag)
end

function CLEAR_RAGDOLL_BLOCKING_FLAGS(ped, blockingFlag)
    Velora.invoke(0xA98260, "void", ped, blockingFlag)
end

function SET_PED_ANGLED_DEFENSIVE_AREA(ped, p1, p2, p3, p4, p5, p6, p7, p8, p9)
    Velora.invoke(0xA982D0, "void", ped, p1, p2, p3, p4, p5, p6, p7, p8, p9)
end

function SET_PED_SPHERE_DEFENSIVE_AREA(ped, x, y, z, radius, p5, p6)
    Velora.invoke(0xA98300, "void", ped, x, y, z, radius, p5, p6)
end

function SET_PED_DEFENSIVE_SPHERE_ATTACHED_TO_PED(ped, target, xOffset, yOffset, zOffset, radius, p6)
    Velora.invoke(0xA983F0, "void", ped, target, xOffset, yOffset, zOffset, radius, p6)
end

function SET_PED_DEFENSIVE_SPHERE_ATTACHED_TO_VEHICLE(ped, target, xOffset, yOffset, zOffset, radius, p6)
    Velora.invoke(0xA98420, "void", ped, target, xOffset, yOffset, zOffset, radius, p6)
end

function SET_PED_DEFENSIVE_AREA_ATTACHED_TO_PED(ped, attachPed, p2, p3, p4, p5, p6, p7, p8, p9, p10)
    Velora.invoke(0xA98450, "void", ped, attachPed, p2, p3, p4, p5, p6, p7, p8, p9, p10)
end

function SET_PED_DEFENSIVE_AREA_DIRECTION(ped, p1, p2, p3, p4)
    Velora.invoke(0xA98490, "void", ped, p1, p2, p3, p4)
end

function REMOVE_PED_DEFENSIVE_AREA(ped, toggle)
    Velora.invoke(0xA98550, "void", ped, toggle)
end

function GET_PED_DEFENSIVE_AREA_POSITION(ped, invoke<Vector3>(0xA985B0, ped, invoke<BOOL>(0xA98620, ped, itemSet)
    local x, y, z = Velora.invoke(0xA986A0, "vector3", ped, invoke<Vector3>(0xA985B0, ped, invoke<BOOL>(0xA98620, ped, itemSet)
    return {x = x, y = y, z = z}
end

function REMOVE_PED_PREFERRED_COVER_SET(ped)
    Velora.invoke(0xA986F0, "void", ped)
end

function REVIVE_INJURED_PED(ped)
    Velora.invoke(0xA98740, "void", ped)
end

function RESURRECT_PED(ped)
    Velora.invoke(0xA987D0, "void", ped)
end

function SET_PED_NAME_DEBUG(ped, name)
    Velora.invoke(0xA98870, "void", ped, name)
end

function GET_PED_EXTRACTED_DISPLACEMENT(ped, invoke<Vector3>(0xA98880, ped, toggle)
    local x, y, z = Velora.invoke(0xA98960, "vector3", ped, invoke<Vector3>(0xA98880, ped, toggle)
    return {x = x, y = y, z = z}
end

function SET_PED_ENABLE_WEAPON_BLOCKING(ped, toggle)
    Velora.invoke(0xA989D0, "void", ped, toggle)
end

function SPECIAL_FUNCTION_DO_NOT_USE(ped, p1)
    Velora.invoke(0xA98A30, "void", ped, p1)
end

function RESET_PED_VISIBLE_DAMAGE(ped)
    Velora.invoke(0xA98AB0, "void", ped)
end

function APPLY_PED_BLOOD_DAMAGE_BY_ZONE(ped, p1, p2, p3, p4)
    Velora.invoke(0xA98B00, "void", ped, p1, p2, p3, p4)
end

function APPLY_PED_BLOOD(ped, boneIndex, xRot, yRot, zRot, woundType)
    Velora.invoke(0xA98C50, "void", ped, boneIndex, xRot, yRot, zRot, woundType)
end

function APPLY_PED_BLOOD_BY_ZONE(ped, p1, p2, p3, p4)
    Velora.invoke(0xA98D20, "void", ped, p1, p2, p3, p4)
end

function APPLY_PED_BLOOD_SPECIFIC(ped, p1, p2, p3, p4, p5, p6, p7, p8)
    Velora.invoke(0xA98E00, "void", ped, p1, p2, p3, p4, p5, p6, p7, p8)
end

function APPLY_PED_DAMAGE_DECAL(ped, damageZone, xOffset, yOffset, heading, scale, alpha, variation, fadeIn, decalName)
    Velora.invoke(0xA98F10, "void", ped, damageZone, xOffset, yOffset, heading, scale, alpha, variation, fadeIn, decalName)
end

function APPLY_PED_DAMAGE_PACK(ped, damagePack, damage, mult)
    Velora.invoke(0xA99030, "void", ped, damagePack, damage, mult)
end

function CLEAR_PED_BLOOD_DAMAGE(ped)
    Velora.invoke(0xA990E0, "void", ped)
end

function CLEAR_PED_BLOOD_DAMAGE_BY_ZONE(ped, p1)
    Velora.invoke(0xA99130, "void", ped, p1)
end

function HIDE_PED_BLOOD_DAMAGE_BY_ZONE(ped, p1, p2)
    Velora.invoke(0xA99180, "void", ped, p1, p2)
end

function CLEAR_PED_DAMAGE_DECAL_BY_ZONE(ped, p1, p2)
    Velora.invoke(0xA991F0, "void", ped, p1, p2)
end

function GET_PED_DECORATIONS_STATE(invoke<int>(0xA99290, ped, p1)
    return Velora.invoke(0xA99350, "int", invoke<int>(0xA99290, ped, p1)
end

function CLEAR_PED_WETNESS(ped)
    Velora.invoke(0xA993C0, "void", ped)
end

function SET_PED_WETNESS_HEIGHT(ped, height)
    Velora.invoke(0xA99420, "void", ped, height)
end

function SET_PED_WETNESS_ENABLED_THIS_FRAME(ped)
    Velora.invoke(0xA99490, "void", ped)
end

function SET_PED_WETNESS(ped, wetLevel)
    Velora.invoke(0xA994E0, "void", ped, wetLevel)
end

function CLEAR_PED_ENV_DIRT(ped)
    Velora.invoke(0xA99540, "void", ped)
end

function SET_PED_SWEAT(ped, sweat)
    Velora.invoke(0xA99580, "void", ped, sweat)
end

function ADD_PED_DECORATION_FROM_HASHES(ped, collection, overlay)
    Velora.invoke(0xA995D0, "void", ped, collection, overlay)
end

function ADD_PED_DECORATION_FROM_HASHES_IN_CORONA(ped, collection, overlay)
    Velora.invoke(0xA99670, "void", ped, collection, overlay)
end

function GET_PED_DECORATION_ZONE_FROM_HASHES(collection, invoke<int>(0xA99730, ped)
    return Velora.invoke(0xA99790, "int", collection, invoke<int>(0xA99730, ped)
end

function CLEAR_PED_DECORATIONS_LEAVE_SCARS(ped)
    Velora.invoke(0xA997E0, "void", ped)
end

function WAS_PED_SKELETON_UPDATED(invoke<BOOL>(0xA99860, ped, boneId, offsetX, offsetY, invoke<Vector3>(0xA998A0, startImmediately, messageId)
    return Velora.invoke(0xA99910, "bool", invoke<BOOL>(0xA99860, ped, boneId, offsetX, offsetY, invoke<Vector3>(0xA998A0, startImmediately, messageId)
end

function GIVE_PED_NM_MESSAGE(ped)
    Velora.invoke(0xA99980, "void", ped)
end

function ADD_SCENARIO_BLOCKING_AREA(x1, y1, z1, x2, y2, z2, p6, p7, p8, invoke<int>(0xA99990, REMOVE_SCENARIO_BLOCKING_AREAS()
    return Velora.invoke(0xA999F0, "int", x1, y1, z1, x2, y2, z2, p6, p7, p8, invoke<int>(0xA99990, REMOVE_SCENARIO_BLOCKING_AREAS()
end

function REMOVE_SCENARIO_BLOCKING_AREA(p0, p1)
    Velora.invoke(0xA99A10, "void", p0, p1)
end

function SET_SCENARIO_PEDS_SPAWN_IN_SPHERE_AREA(x, y, z, range, p4)
    Velora.invoke(0xA99A30, "void", x, y, z, range, p4)
end

function DOES_SCENARIO_BLOCKING_AREA_EXISTS(x1, y1, z1, x2, y2, invoke<BOOL>(0xA99AB0, ped, invoke<BOOL>(0xA99B40, invoke<BOOL>(0xA99B70, p0, p1, p2, invoke<BOOL>(0xA99BD0, ped, toggle)
    return Velora.invoke(0xA99C00, "bool", x1, y1, z1, x2, y2, invoke<BOOL>(0xA99AB0, ped, invoke<BOOL>(0xA99B40, invoke<BOOL>(0xA99B70, p0, p1, p2, invoke<BOOL>(0xA99BD0, ped, toggle)
end

function TRIGGER_PED_SCENARIO_PANICEXITTOFLEE(p0, p1, p2, invoke<BOOL>(0xA99C70, p0, p1, p2, invoke<BOOL>(0xA99CA0, ped)
    return Velora.invoke(0xA99D50, "bool", p0, p1, p2, invoke<BOOL>(0xA99C70, p0, p1, p2, invoke<BOOL>(0xA99CA0, ped)
end

function SET_PED_SHOULD_PLAY_IMMEDIATE_SCENARIO_EXIT(ped)
    Velora.invoke(0xA99DA0, "void", ped)
end

function SET_PED_SHOULD_PLAY_FLEE_SCENARIO_EXIT(ped, p1, p2, invoke<BOOL>(0xA99DF0, ped, p1)
    return Velora.invoke(0xA99EB0, "bool", ped, p1, p2, invoke<BOOL>(0xA99DF0, ped, p1)
end

function SET_PED_SHOULD_IGNORE_SCENARIO_NAV_CHECKS(p0, p1)
    Velora.invoke(0xA99F00, "void", p0, p1)
end

function SET_PED_SHOULD_PROBE_FOR_SCENARIO_EXITS_IN_ONE_FRAME(p0, p1)
    Velora.invoke(0xA99F60, "void", p0, p1)
end

function IS_PED_GESTURING(invoke<BOOL>(0xA99FB0, ped)
    return Velora.invoke(0xA9A000, "bool", invoke<BOOL>(0xA99FB0, ped)
end

function PLAY_FACIAL_ANIM(ped, animName, animDict)
    Velora.invoke(0xA9A050, "void", ped, animName, animDict)
end

function SET_FACIAL_CLIPSET(ped, animDict)
    Velora.invoke(0xA9A070, "void", ped, animDict)
end

function SET_FACIAL_IDLE_ANIM_OVERRIDE(ped, animName, animDict)
    Velora.invoke(0xA9A120, "void", ped, animName, animDict)
end

function CLEAR_FACIAL_IDLE_ANIM_OVERRIDE(ped)
    Velora.invoke(0xA9A140, "void", ped)
end

function SET_PED_CAN_PLAY_GESTURE_ANIMS(ped, toggle)
    Velora.invoke(0xA9A150, "void", ped, toggle)
end

function SET_PED_CAN_PLAY_VISEME_ANIMS(ped, toggle, p2)
    Velora.invoke(0xA9A1C0, "void", ped, toggle, p2)
end

function SET_PED_IS_IGNORED_BY_AUTO_OPEN_DOORS(ped, p1)
    Velora.invoke(0xA9A250, "void", ped, p1)
end

function SET_PED_CAN_PLAY_AMBIENT_ANIMS(ped, toggle)
    Velora.invoke(0xA9A2B0, "void", ped, toggle)
end

function SET_PED_CAN_PLAY_AMBIENT_BASE_ANIMS(ped, toggle)
    Velora.invoke(0xA9A300, "void", ped, toggle)
end

function TRIGGER_IDLE_ANIMATION_ON_PED(ped)
    Velora.invoke(0xA9A350, "void", ped)
end

function SET_PED_CAN_ARM_IK(ped, toggle)
    Velora.invoke(0xA9A3B0, "void", ped, toggle)
end

function SET_PED_CAN_HEAD_IK(ped, toggle)
    Velora.invoke(0xA9A460, "void", ped, toggle)
end

function SET_PED_CAN_LEG_IK(ped, toggle)
    Velora.invoke(0xA9A4C0, "void", ped, toggle)
end

function SET_PED_CAN_TORSO_IK(ped, toggle)
    Velora.invoke(0xA9A520, "void", ped, toggle)
end

function SET_PED_CAN_TORSO_REACT_IK(ped, p1)
    Velora.invoke(0xA9A580, "void", ped, p1)
end

function SET_PED_CAN_TORSO_VEHICLE_IK(ped, p1)
    Velora.invoke(0xA9A5E0, "void", ped, p1)
end

function SET_PED_CAN_USE_AUTO_CONVERSATION_LOOKAT(ped, toggle)
    Velora.invoke(0xA9A640, "void", ped, toggle)
end

function IS_PED_HEADTRACKING_PED(ped1, invoke<BOOL>(0xA9A690, ped, invoke<BOOL>(0xA9A6C0, ped, lookAt)
    return Velora.invoke(0xA9A6F0, "bool", ped1, invoke<BOOL>(0xA9A690, ped, invoke<BOOL>(0xA9A6C0, ped, lookAt)
end

function SET_PED_CLOTH_PIN_FRAMES(p0, p1)
    Velora.invoke(0xA9A700, "void", p0, p1)
end

function SET_PED_CLOTH_PACKAGE_INDEX(p0, p1)
    Velora.invoke(0xA9A750, "void", p0, p1)
end

function SET_PED_CLOTH_PRONE(p0, p1)
    Velora.invoke(0xA9A7A0, "void", p0, p1)
end

function SET_PED_CONFIG_FLAG(ped, flagId, value)
    Velora.invoke(0xA9A7F0, "void", ped, flagId, value)
end

function SET_PED_RESET_FLAG(ped, flagId, doReset)
    Velora.invoke(0xA9A8A0, "void", ped, flagId, doReset)
end

function GET_PED_CONFIG_FLAG(ped, flagId, invoke<BOOL>(0xA9A920, ped, invoke<BOOL>(0xA9A950, ped, index)
    return Velora.invoke(0xA9A9C0, "bool", ped, flagId, invoke<BOOL>(0xA9A920, ped, invoke<BOOL>(0xA9A950, ped, index)
end

function SET_PED_CAN_EVASIVE_DIVE(ped, toggle)
    Velora.invoke(0xA9AA20, "void", ped, toggle)
end

function IS_PED_EVASIVE_DIVING(ped, invoke<BOOL>(0xA9AA80, ped, x, y, z, toggle)
    return Velora.invoke(0xA9AB10, "bool", ped, invoke<BOOL>(0xA9AA80, ped, x, y, z, toggle)
end

function SET_PED_MODEL_IS_SUPPRESSED(modelHash, toggle)
    Velora.invoke(0xA9AB30, "void", modelHash, toggle)
end

function STOP_ANY_PED_MODEL_BEING_SUPPRESSED()
    Velora.invoke(0xA9AB50, "void")
end

function SET_PED_CAN_BE_TARGETED_WHEN_INJURED(ped, toggle)
    Velora.invoke(0xA9AB60, "void", ped, toggle)
end

function SET_PED_GENERATES_DEAD_BODY_EVENTS(ped, toggle)
    Velora.invoke(0xA9AC20, "void", ped, toggle)
end

function BLOCK_PED_FROM_GENERATING_DEAD_BODY_EVENTS_WHEN_DEAD(ped, toggle)
    Velora.invoke(0xA9AC40, "void", ped, toggle)
end

function SET_PED_WILL_ONLY_ATTACK_WANTED_PLAYER(p0, p1)
    Velora.invoke(0xA9AC90, "void", p0, p1)
end

function SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(ped, toggle)
    Velora.invoke(0xA9ACF0, "void", ped, toggle)
end

function GIVE_PED_HELMET(ped, cannotRemove, helmetFlag, textureIndex)
    Velora.invoke(0xA9AD50, "void", ped, cannotRemove, helmetFlag, textureIndex)
end

function REMOVE_PED_HELMET(ped, instantly)
    Velora.invoke(0xA9AD70, "void", ped, instantly)
end

function IS_PED_TAKING_OFF_HELMET(invoke<BOOL>(0xA9AD90, ped, canWearHelmet)
    return Velora.invoke(0xA9ADF0, "bool", invoke<BOOL>(0xA9AD90, ped, canWearHelmet)
end

function SET_PED_HELMET_FLAG(ped, helmetFlag)
    Velora.invoke(0xA9AE40, "void", ped, helmetFlag)
end

function SET_PED_HELMET_PROP_INDEX(ped, propIndex, p2)
    Velora.invoke(0xA9AE90, "void", ped, propIndex, p2)
end

function SET_PED_HELMET_VISOR_PROP_INDICES(ped, p1, p2, p3)
    Velora.invoke(0xA9AF30, "void", ped, p1, p2, p3)
end

function IS_PED_HELMET_VISOR_UP(invoke<BOOL>(0xA9AFB0, ped, textureIndex)
    return Velora.invoke(0xA9B030, "bool", invoke<BOOL>(0xA9AFB0, ped, textureIndex)
end

function IS_PED_WEARING_HELMET(invoke<BOOL>(0xA9B090, ped)
    return Velora.invoke(0xA9B0F0, "bool", invoke<BOOL>(0xA9B090, ped)
end

function GET_PED_HELMET_STORED_HAT_PROP_INDEX(invoke<int>(0xA9B150, invoke<int>(0xA9B1B0, invoke<BOOL>(0xA9B210, ped, toggle)
    return Velora.invoke(0xA9B240, "int", invoke<int>(0xA9B150, invoke<int>(0xA9B1B0, invoke<BOOL>(0xA9B210, ped, toggle)
end

function SET_PED_CAN_COWER_IN_COVER(ped, toggle)
    Velora.invoke(0xA9B2A0, "void", ped, toggle)
end

function SET_PED_CAN_PEEK_IN_COVER(ped, toggle)
    Velora.invoke(0xA9B300, "void", ped, toggle)
end

function SET_PED_PLAYS_HEAD_ON_HORN_ANIM_WHEN_DIES_IN_VEHICLE(ped, toggle)
    Velora.invoke(0xA9B360, "void", ped, toggle)
end

function SET_PED_LEG_IK_MODE(ped, mode)
    Velora.invoke(0xA9B370, "void", ped, mode)
end

function SET_PED_MOTION_BLUR(ped, toggle)
    Velora.invoke(0xA9B3D0, "void", ped, toggle)
end

function SET_PED_CAN_SWITCH_WEAPON(ped, toggle)
    Velora.invoke(0xA9B430, "void", ped, toggle)
end

function SET_PED_DIES_INSTANTLY_IN_WATER(ped, toggle)
    Velora.invoke(0xA9B490, "void", ped, toggle)
end

function SET_LADDER_CLIMB_INPUT_STATE(ped, p1)
    Velora.invoke(0xA9B4E0, "void", ped, p1)
end

function STOP_PED_WEAPON_FIRING_WHEN_DROPPED(ped)
    Velora.invoke(0xA9B540, "void", ped)
end

function SET_SCRIPTED_ANIM_SEAT_OFFSET(ped, p1)
    Velora.invoke(0xA9B580, "void", ped, p1)
end

function SET_PED_COMBAT_MOVEMENT(ped, combatMovement)
    Velora.invoke(0xA9B5D0, "void", ped, combatMovement)
end

function GET_PED_COMBAT_MOVEMENT(invoke<int>(0xA9B620, ped, abilityLevel)
    return Velora.invoke(0xA9B680, "int", invoke<int>(0xA9B620, ped, abilityLevel)
end

function SET_PED_COMBAT_RANGE(ped, combatRange)
    Velora.invoke(0xA9B6D0, "void", ped, combatRange)
end

function GET_PED_COMBAT_RANGE(invoke<int>(0xA9B720, ped, attributeId, enabled)
    return Velora.invoke(0xA9B780, "int", invoke<int>(0xA9B720, ped, attributeId, enabled)
end

function SET_PED_TARGET_LOSS_RESPONSE(ped, responseType)
    Velora.invoke(0xA9B7F0, "void", ped, responseType)
end

function IS_PED_PERFORMING_MELEE_ACTION(invoke<BOOL>(0xA9B840, invoke<BOOL>(0xA9B8B0, invoke<BOOL>(0xA9B950, invoke<BOOL>(0xA9B9E0, invoke<Ped>(0xA9BA50, invoke<BOOL>(0xA9BAE0, invoke<BOOL>(0xA9BB30, invoke<BOOL>(0xA9BB80, ped, attributeFlags, enable)
    return Velora.invoke(0xA9BBD0, "bool", invoke<BOOL>(0xA9B840, invoke<BOOL>(0xA9B8B0, invoke<BOOL>(0xA9B950, invoke<BOOL>(0xA9B9E0, invoke<Ped>(0xA9BA50, invoke<BOOL>(0xA9BAE0, invoke<BOOL>(0xA9BB30, invoke<BOOL>(0xA9BB80, ped, attributeFlags, enable)
end

function SET_PED_COWER_HASH(ped, p1)
    Velora.invoke(0xA9BC40, "void", ped, p1)
end

function SET_PED_STEERS_AROUND_DEAD_BODIES(ped, toggle)
    Velora.invoke(0xA9BCA0, "void", ped, toggle)
end

function SET_PED_STEERS_AROUND_PEDS(ped, toggle)
    Velora.invoke(0xA9BD00, "void", ped, toggle)
end

function SET_PED_STEERS_AROUND_OBJECTS(ped, toggle)
    Velora.invoke(0xA9BD50, "void", ped, toggle)
end

function SET_PED_STEERS_AROUND_VEHICLES(ped, toggle)
    Velora.invoke(0xA9BDB0, "void", ped, toggle)
end

function SET_PED_IS_AVOIDED_BY_OTHERS(p0, p1)
    Velora.invoke(0xA9BE10, "void", p0, p1)
end

function SET_PED_INCREASED_AVOIDANCE_RADIUS(ped)
    Velora.invoke(0xA9BE70, "void", ped)
end

function SET_PED_BLOCKS_PATHING_WHEN_DEAD(ped, toggle)
    Velora.invoke(0xA9BEB0, "void", ped, toggle)
end

function SET_PED_NO_TIME_DELAY_BEFORE_SHOT(p0)
    Velora.invoke(0xA9BF10, "void", p0)
end

function IS_ANY_PED_NEAR_POINT(x, y, z, invoke<BOOL>(0xA9BF50, ped, p1, p2)
    return Velora.invoke(0xA9C030, "bool", x, y, z, invoke<BOOL>(0xA9BF50, ped, p1, p2)
end

function IS_PED_HEADING_TOWARDS_POSITION(ped, x, y, z, invoke<BOOL>(0xA9C0C0, ped)
    return Velora.invoke(0xA9C0F0, "bool", ped, x, y, z, invoke<BOOL>(0xA9C0C0, ped)
end

function REQUEST_PED_VEHICLE_VISIBILITY_TRACKING(ped, p1)
    Velora.invoke(0xA9C130, "void", ped, p1)
end

function REQUEST_PED_RESTRICTED_VEHICLE_VISIBILITY_TRACKING(ped, p1)
    Velora.invoke(0xA9C190, "void", ped, p1)
end

function REQUEST_PED_USE_SMALL_BBOX_VISIBILITY_TRACKING(ped, p1)
    Velora.invoke(0xA9C1E0, "void", ped, p1)
end

function IS_TRACKED_PED_VISIBLE(invoke<BOOL>(0xA9C240, invoke<int>(0xA9C2A0, invoke<BOOL>(0xA9C300, ped, invoke<BOOL>(0xA9C360, ped1, invoke<BOOL>(0xA9C390, ped, invoke<BOOL>(0xA9C3C0, ped, invoke<BOOL>(0xA9C440, ped, invoke<int>(0xA9C4C0, ped, invoke<int>(0xA9C4F0, ped, value)
    return Velora.invoke(0xA9C500, "bool", invoke<BOOL>(0xA9C240, invoke<int>(0xA9C2A0, invoke<BOOL>(0xA9C300, ped, invoke<BOOL>(0xA9C360, ped1, invoke<BOOL>(0xA9C390, ped, invoke<BOOL>(0xA9C3C0, ped, invoke<BOOL>(0xA9C440, ped, invoke<int>(0xA9C4C0, ped, invoke<int>(0xA9C4F0, ped, value)
end

function GET_PED_ENVEFF_SCALE(invoke<float>(0xA9C5A0, ped, toggle)
    return Velora.invoke(0xA9C630, "float", invoke<float>(0xA9C5A0, ped, toggle)
end

function SET_PED_ENVEFF_CPV_ADD(ped, p1)
    Velora.invoke(0xA9C6B0, "void", ped, p1)
end

function SET_PED_ENVEFF_COLOR_MODULATOR(ped, p1, p2, p3)
    Velora.invoke(0xA9C750, "void", ped, p1, p2, p3)
end

function SET_PED_EMISSIVE_SCALE(ped, intensity)
    Velora.invoke(0xA9C820, "void", ped, intensity)
end

function GET_PED_EMISSIVE_SCALE(invoke<float>(0xA9C8C0, invoke<BOOL>(0xA9C950, ped, toggle)
    return Velora.invoke(0xA9C9C0, "float", invoke<float>(0xA9C8C0, invoke<BOOL>(0xA9C950, ped, toggle)
end

function REQUEST_RAGDOLL_BOUNDS_UPDATE(p0, p1)
    Velora.invoke(0xA9CA10, "void", p0, p1)
end

function SET_PED_AO_BLOB_RENDERING(ped, toggle)
    Velora.invoke(0xA9CA20, "void", ped, toggle)
end

function IS_PED_SHELTERED(invoke<BOOL>(0xA9CA80, x, y, z, roll, pitch, yaw, invoke<int>(0xA9CAE0, x, y, z, radius, invoke<int>(0xA9CB10, invoke<BOOL>(0xA9CB40, sceneID, x, y, z, roll, pitch, yaw, p7)
    return Velora.invoke(0xA9CB70, "bool", invoke<BOOL>(0xA9CA80, x, y, z, roll, pitch, yaw, invoke<int>(0xA9CAE0, x, y, z, radius, invoke<int>(0xA9CB10, invoke<BOOL>(0xA9CB40, sceneID, x, y, z, roll, pitch, yaw, p7)
end

function SET_SYNCHRONIZED_SCENE_PHASE(sceneID, phase)
    Velora.invoke(0xA9CC30, "void", sceneID, phase)
end

function GET_SYNCHRONIZED_SCENE_PHASE(invoke<float>(0xA9CC70, sceneID, rate)
    return Velora.invoke(0xA9CCB0, "float", invoke<float>(0xA9CC70, sceneID, rate)
end

function GET_SYNCHRONIZED_SCENE_RATE(invoke<float>(0xA9CD20, sceneID, toggle)
    return Velora.invoke(0xA9CD60, "float", invoke<float>(0xA9CD20, sceneID, toggle)
end

function IS_SYNCHRONIZED_SCENE_LOOPED(invoke<BOOL>(0xA9CDA0, sceneID, toggle)
    return Velora.invoke(0xA9CDE0, "bool", invoke<BOOL>(0xA9CDA0, sceneID, toggle)
end

function IS_SYNCHRONIZED_SCENE_HOLD_LAST_FRAME(invoke<BOOL>(0xA9CE30, sceneID, entity, boneIndex)
    return Velora.invoke(0xA9CE70, "bool", invoke<BOOL>(0xA9CE30, sceneID, entity, boneIndex)
end

function DETACH_SYNCHRONIZED_SCENE(sceneID)
    Velora.invoke(0xA9CEE0, "void", sceneID)
end

function TAKE_OWNERSHIP_OF_SYNCHRONIZED_SCENE(scene)
    Velora.invoke(0xA9CF10, "void", scene)
end

function FORCE_PED_MOTION_STATE(ped, motionStateHash, p2, p3, invoke<BOOL>(0xA9CF50, ped, speedX, invoke<BOOL>(0xA9CF90, ped, value)
    return Velora.invoke(0xA9D010, "bool", ped, motionStateHash, p2, p3, invoke<BOOL>(0xA9CF50, ped, speedX, invoke<BOOL>(0xA9CF90, ped, value)
end

function SET_PED_MIN_MOVE_BLEND_RATIO(ped, value)
    Velora.invoke(0xA9D060, "void", ped, value)
end

function SET_PED_MOVE_RATE_OVERRIDE(ped, value)
    Velora.invoke(0xA9D0C0, "void", ped, value)
end

function SET_PED_MOVE_RATE_IN_WATER_OVERRIDE(ped, p1)
    Velora.invoke(0xA9D140, "void", ped, p1)
end

function PED_HAS_SEXINESS_FLAG_SET(ped, invoke<BOOL>(0xA9D1C0, ped, invoke<int>(0xA9D220, ped, sizeAndPeds, invoke<int>(0xA9D250, invoke<BOOL>(0xA9D280, invoke<BOOL>(0xA9D2E0, ped, p1, p2, action)
    return Velora.invoke(0xA9D340, "bool", ped, invoke<BOOL>(0xA9D1C0, ped, invoke<int>(0xA9D220, ped, sizeAndPeds, invoke<int>(0xA9D250, invoke<BOOL>(0xA9D280, invoke<BOOL>(0xA9D2E0, ped, p1, p2, action)
end

function SET_MOVEMENT_MODE_OVERRIDE(ped, name)
    Velora.invoke(0xA9D360, "void", ped, name)
end

function SET_PED_CAPSULE(ped, value)
    Velora.invoke(0xA9D3C0, "void", ped, value)
end

function REGISTER_PEDHEADSHOT(invoke<int>(0xA9D410, invoke<int>(0xA9D480, invoke<int>(0xA9D4F0, id)
    return Velora.invoke(0xA9D560, "int", invoke<int>(0xA9D410, invoke<int>(0xA9D480, invoke<int>(0xA9D4F0, id)
end

function IS_PEDHEADSHOT_VALID(invoke<BOOL>(0xA9D580, invoke<BOOL>(0xA9D5C0, char>(0xA9D5F0, invoke<BOOL>(0xA9D620, id)
    return Velora.invoke(0xA9D660, "bool", invoke<BOOL>(0xA9D580, invoke<BOOL>(0xA9D5C0, char>(0xA9D5F0, invoke<BOOL>(0xA9D620, id)
end

function IS_PEDHEADSHOT_IMG_UPLOAD_AVAILABLE(ped, heatScale)
    return Velora.invoke(0xA9D6E0, "bool", ped, heatScale)
end

function DISABLE_PED_HEATSCALE_OVERRIDE(ped)
    Velora.invoke(0xA9D740, "void", ped)
end

function SPAWNPOINTS_START_SEARCH(p0, p1, p2, p3, p4, interiorFlags, scale, duration)
    Velora.invoke(0xA9D780, "void", p0, p1, p2, p3, p4, interiorFlags, scale, duration)
end

function SPAWNPOINTS_START_SEARCH_IN_ANGLED_AREA(x1, y1, z1, x2, y2, z2, width, interiorFlags, scale, duration)
    Velora.invoke(0xA9D800, "void", x1, y1, z1, x2, y2, z2, width, interiorFlags, scale, duration)
end

function SPAWNPOINTS_CANCEL_SEARCH()
    Velora.invoke(0xA9D8A0, "void")
end

function SPAWNPOINTS_IS_SEARCH_ACTIVE(randomInt, x, y, z)
    return Velora.invoke(0xA9D970, "bool", randomInt, x, y, z)
end

function SPAWNPOINTS_GET_SEARCH_RESULT_FLAGS(p0, p1)
    Velora.invoke(0xA9DA00, "void", p0, p1)
end

function SET_IK_TARGET(ped, ikIndex, entityLookAt, boneLookAt, offsetX, offsetY, offsetZ, p7, blendInDuration, blendOutDuration)
    Velora.invoke(0xA9DA60, "void", ped, ikIndex, entityLookAt, boneLookAt, offsetX, offsetY, offsetZ, p7, blendInDuration, blendOutDuration)
end

function FORCE_INSTANT_LEG_IK_SETUP(ped)
    Velora.invoke(0xA9DAA0, "void", ped)
end

function REQUEST_ACTION_MODE_ASSET(asset)
    Velora.invoke(0xA9DB00, "void", asset)
end

function HAS_ACTION_MODE_ASSET_LOADED(invoke<BOOL>(0xA9DB80, asset)
    return Velora.invoke(0xA9DBB0, "bool", invoke<BOOL>(0xA9DB80, asset)
end

function REQUEST_STEALTH_MODE_ASSET(asset)
    Velora.invoke(0xA9DC30, "void", asset)
end

function HAS_STEALTH_MODE_ASSET_LOADED(invoke<BOOL>(0xA9DCC0, asset)
    return Velora.invoke(0xA9DCF0, "bool", invoke<BOOL>(0xA9DCC0, asset)
end

function SET_PED_LOD_MULTIPLIER(ped, multiplier)
    Velora.invoke(0xA9DD80, "void", ped, multiplier)
end

function SET_PED_CAN_LOSE_PROPS_ON_DAMAGE(ped, toggle, p2)
    Velora.invoke(0xA9DDE0, "void", ped, toggle, p2)
end

function SET_FORCE_FOOTSTEP_UPDATE(ped, toggle)
    Velora.invoke(0xA9DE70, "void", ped, toggle)
end

function SET_FORCE_STEP_TYPE(ped, p1, type, p3)
    Velora.invoke(0xA9DEC0, "void", ped, p1, type, p3)
end

function IS_ANY_HOSTILE_PED_NEAR_POINT(ped, x, y, z, invoke<BOOL>(0xA9DF30, ped, toggle)
    return Velora.invoke(0xA9DF60, "bool", ped, x, y, z, invoke<BOOL>(0xA9DF30, ped, toggle)
end

function IS_TARGET_PED_IN_PERCEPTION_AREA(ped, targetPed, p2, p3, p4, invoke<BOOL>(0xA9DFC0, x, y, z, min, max)
    return Velora.invoke(0xA9E000, "bool", ped, targetPed, p2, p3, p4, invoke<BOOL>(0xA9DFC0, x, y, z, min, max)
end

function FORCE_ZERO_MASS_IN_COLLISIONS(ped)
    Velora.invoke(0xA9E070, "void", ped)
end

function SET_DISABLE_HIGH_FALL_DEATH(ped, toggle)
    Velora.invoke(0xA9E0B0, "void", ped, toggle)
end

function SET_PED_PHONE_PALETTE_IDX(p0, p1)
    Velora.invoke(0xA9E100, "void", p0, p1)
end

function SET_PED_STEER_BIAS(ped, value)
    Velora.invoke(0xA9E140, "void", ped, value)
end

function IS_PED_SWITCHING_WEAPON(invoke<BOOL>(0xA9E190, p0, p1, p2)
    return Velora.invoke(0xA9E1F0, "bool", invoke<BOOL>(0xA9E190, p0, p1, p2)
end

function SET_DISABLE_PED_MAP_COLLISION(ped)
    Velora.invoke(0xA9E270, "void", ped)
end

function ENABLE_MP_LIGHT(ped, toggle)
    Velora.invoke(0xA9E330, "void", ped, toggle)
end

function GET_MP_LIGHT_ENABLED(invoke<BOOL>(0xA9E380, ped)
    return Velora.invoke(0xA9E3E0, "bool", invoke<BOOL>(0xA9E380, ped)
end

function SET_ALLOW_STUNT_JUMP_CAMERA(ped, toggle)
    Velora.invoke(0xA9E430, "void", ped, toggle)
end

function ADD_ROPE(x, y, z, rotX, rotY, rotZ, length, ropeType, maxLength, minLength, windingSpeed, p11, p12, rigid, p14, breakWhenShot, invoke<int>(0xAA0760, ropeId)
    return Velora.invoke(0xAA07E0, "int", x, y, z, rotX, rotY, rotZ, length, ropeType, maxLength, minLength, windingSpeed, p11, p12, rigid, p14, breakWhenShot, invoke<int>(0xAA0760, ropeId)
end

function DELETE_CHILD_ROPE(ropeId)
    Velora.invoke(0xAA07F0, "void", ropeId)
end

function DOES_ROPE_EXIST(invoke<BOOL>(0xAA0810, ropeId, p1)
    return Velora.invoke(0xAA0850, "bool", invoke<BOOL>(0xAA0810, ropeId, p1)
end

function ROPE_DRAW_SHADOW_ENABLED(ropeId, toggle)
    Velora.invoke(0xAA08B0, "void", ropeId, toggle)
end

function LOAD_ROPE_DATA(ropeId, rope_preset)
    Velora.invoke(0xAA0910, "void", ropeId, rope_preset)
end

function PIN_ROPE_VERTEX(ropeId, vertex, x, y, z)
    Velora.invoke(0xAA0960, "void", ropeId, vertex, x, y, z)
end

function UNPIN_ROPE_VERTEX(ropeId, vertex)
    Velora.invoke(0xAA09D0, "void", ropeId, vertex)
end

function GET_ROPE_VERTEX_COUNT(invoke<int>(0xAA0A20, ropeId, ent1, ent2, ent1_x, ent1_y, ent1_z, ent2_x, ent2_y, ent2_z, length, p10, p11, p12, p13)
    return Velora.invoke(0xAA0A80, "int", invoke<int>(0xAA0A20, ropeId, ent1, ent2, ent1_x, ent1_y, ent1_z, ent2_x, ent2_y, ent2_z, length, p10, p11, p12, p13)
end

function ATTACH_ROPE_TO_ENTITY(ropeId, entity, x, y, z, p5)
    Velora.invoke(0xAA0AD0, "void", ropeId, entity, x, y, z, p5)
end

function DETACH_ROPE_FROM_ENTITY(ropeId, entity)
    Velora.invoke(0xAA0B90, "void", ropeId, entity)
end

function ROPE_SET_UPDATE_PINVERTS(ropeId)
    Velora.invoke(0xAA0C10, "void", ropeId)
end

function ROPE_SET_UPDATE_ORDER(ropeId, p1)
    Velora.invoke(0xAA0C50, "void", ropeId, p1)
end

function ROPE_SET_SMOOTH_REELIN(ropeId, p1)
    Velora.invoke(0xAA0C90, "void", ropeId, p1)
end

function IS_ROPE_ATTACHED_AT_BOTH_ENDS(invoke<BOOL>(0xAA0CF0, invoke<Vector3>(0xAA0D40, ropeId, invoke<Vector3>(0xAA0DD0, ropeId)
    return Velora.invoke(0xAA0E90, "bool", invoke<BOOL>(0xAA0CF0, invoke<Vector3>(0xAA0D40, ropeId, invoke<Vector3>(0xAA0DD0, ropeId)
end

function STOP_ROPE_WINDING(ropeId)
    Velora.invoke(0xAA0ED0, "void", ropeId)
end

function START_ROPE_UNWINDING_FRONT(ropeId)
    Velora.invoke(0xAA0F00, "void", ropeId)
end

function STOP_ROPE_UNWINDING_FRONT(ropeId)
    Velora.invoke(0xAA0F40, "void", ropeId)
end

function ROPE_CONVERT_TO_SIMPLE(ropeId)
    Velora.invoke(0xAA0F70, "void", ropeId)
end

function ROPE_LOAD_TEXTURES()
    Velora.invoke(0xAA0FD0, "void")
end

function ROPE_ARE_TEXTURES_LOADED(ROPE_UNLOAD_TEXTURES()
    return Velora.invoke(0xAA1020, "bool", ROPE_UNLOAD_TEXTURES()
end

function DOES_SCRIPT_OWN_ROPE(invoke<BOOL>(0xAA1040, ropeId, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13)
    return Velora.invoke(0xAA10C0, "bool", invoke<BOOL>(0xAA1040, ropeId, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13)
end

function ROPE_CHANGE_SCRIPT_OWNER(p0, p1, p2)
    Velora.invoke(0xAA11C0, "void", p0, p1, p2)
end

function ROPE_SET_REFFRAMEVELOCITY_COLLIDERORDER(ropeId, p1)
    Velora.invoke(0xAA11E0, "void", ropeId, p1)
end

function ROPE_GET_DISTANCE_BETWEEN_ENDS(invoke<float>(0xAA1220, ropeId, length)
    return Velora.invoke(0xAA1270, "float", invoke<float>(0xAA1220, ropeId, length)
end

function ROPE_RESET_LENGTH(ropeId, length)
    Velora.invoke(0xAA12C0, "void", ropeId, length)
end

function APPLY_IMPULSE_TO_CLOTH(posX, posY, posZ, vecX, vecY, vecZ, impulse)
    Velora.invoke(0xAA1320, "void", posX, posY, posZ, vecX, vecY, vecZ, impulse)
end

function SET_DAMPING(entity, vertex, value)
    Velora.invoke(0xAA1370, "void", entity, vertex, value)
end

function ACTIVATE_PHYSICS(entity)
    Velora.invoke(0xAA14F0, "void", entity)
end

function SET_CGOFFSET(entity, x, y, z)
    Velora.invoke(0xAA1540, "void", entity, x, y, z)
end

function GET_CGOFFSET(invoke<Vector3>(0xAA1550, entity)
    local x, y, z = Velora.invoke(0xAA15F0, "vector3", invoke<Vector3>(0xAA1550, entity)
    return {x = x, y = y, z = z}
end

function BREAK_ENTITY_GLASS(entity, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
    Velora.invoke(0xAA16D0, "void", entity, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
end

function GET_IS_ENTITY_A_FRAG(invoke<BOOL>(0xAA1700, object, toggle)
    return Velora.invoke(0xAA1760, "bool", invoke<BOOL>(0xAA1700, object, toggle)
end

function RESET_DISABLE_BREAKING(object)
    Velora.invoke(0xAA1800, "void", object)
end

function SET_DISABLE_FRAG_DAMAGE(object, toggle)
    Velora.invoke(0xAA1810, "void", object, toggle)
end

function SET_USE_KINEMATIC_PHYSICS(entity, toggle)
    Velora.invoke(0xAA18B0, "void", entity, toggle)
end

function SET_IN_STUNT_MODE(p0)
    Velora.invoke(0xAA1930, "void", p0)
end

function SET_IN_ARENA_MODE(toggle)
    Velora.invoke(0xAA1960, "void", toggle)
end

function GET_PLAYER_PED(invoke<Ped>(0xAA9310, invoke<Ped>(0xAA9360, player, model)
    return Velora.invoke(0xAA93A0, "int", invoke<Ped>(0xAA9310, invoke<Ped>(0xAA9360, player, model)
end

function CHANGE_PLAYER_PED(player, ped, p2, resetDamage)
    Velora.invoke(0xAA93B0, "void", player, ped, p2, resetDamage)
end

function GET_PLAYER_RGB_COLOUR(player, r, g, b)
    Velora.invoke(0xAA93E0, "void", player, r, g, b)
end

function GET_NUMBER_OF_PLAYERS(invoke<int>(0xAA9470, player, team)
    return Velora.invoke(0xAA94B0, "int", invoke<int>(0xAA9470, player, team)
end

function GET_NUMBER_OF_PLAYERS_IN_TEAM(invoke<int>(0xAA9520, char>(0xAA95B0, invoke<float>(0xAA9630, invoke<Vector3>(0xAA9660, player, position, p2, p3)
    return Velora.invoke(0xAA9700, "int", invoke<int>(0xAA9520, char>(0xAA95B0, invoke<float>(0xAA9630, invoke<Vector3>(0xAA9660, player, position, p2, p3)
end

function GET_WANTED_LEVEL_THRESHOLD(invoke<int>(0xAA9780, player, wantedLevel, disableNoMission)
    return Velora.invoke(0xAA97A0, "int", invoke<int>(0xAA9780, player, wantedLevel, disableNoMission)
end

function SET_PLAYER_WANTED_LEVEL_NO_DROP(player, wantedLevel, p2)
    Velora.invoke(0xAA97C0, "void", player, wantedLevel, p2)
end

function SET_PLAYER_WANTED_LEVEL_NOW(player, p1)
    Velora.invoke(0xAA9880, "void", player, p1)
end

function ARE_PLAYER_FLASHING_STARS_ABOUT_TO_DROP(invoke<BOOL>(0xAA9940, invoke<BOOL>(0xAA99B0, invoke<BOOL>(0xAA9A10, player, toggle)
    return Velora.invoke(0xAA9A80, "bool", invoke<BOOL>(0xAA9940, invoke<BOOL>(0xAA99B0, invoke<BOOL>(0xAA9A10, player, toggle)
end

function IS_PLAYER_WANTED_LEVEL_GREATER(player, invoke<BOOL>(0xAA9AF0, player)
    return Velora.invoke(0xAA9B40, "bool", player, invoke<BOOL>(0xAA9AF0, player)
end

function IS_PLAYER_DEAD(invoke<BOOL>(0xAA9BE0, invoke<BOOL>(0xAA9C20, player, bHasControl, flags)
    return Velora.invoke(0xAA9C60, "bool", invoke<BOOL>(0xAA9BE0, invoke<BOOL>(0xAA9C20, player, bHasControl, flags)
end

function GET_PLAYER_WANTED_LEVEL(invoke<int>(0xAA9C80, maxWantedLevel)
    return Velora.invoke(0xAA9CD0, "int", invoke<int>(0xAA9C80, maxWantedLevel)
end

function SET_POLICE_RADAR_BLIPS(toggle)
    Velora.invoke(0xAA9CF0, "void", toggle)
end

function SET_POLICE_IGNORE_PLAYER(player, toggle)
    Velora.invoke(0xAA9D10, "void", player, toggle)
end

function IS_PLAYER_PLAYING(invoke<BOOL>(0xAA9D80, player, toggle)
    return Velora.invoke(0xAA9DC0, "bool", invoke<BOOL>(0xAA9D80, player, toggle)
end

function SET_ALL_RANDOM_PEDS_FLEE(player, toggle)
    Velora.invoke(0xAA9E30, "void", player, toggle)
end

function SET_ALL_RANDOM_PEDS_FLEE_THIS_FRAME(player)
    Velora.invoke(0xAA9E80, "void", player)
end

function SET_ALL_NEUTRAL_RANDOM_PEDS_FLEE(player, toggle)
    Velora.invoke(0xAA9EB0, "void", player, toggle)
end

function SET_ALL_NEUTRAL_RANDOM_PEDS_FLEE_THIS_FRAME(player)
    Velora.invoke(0xAA9F10, "void", player)
end

function SET_LAW_PEDS_CAN_ATTACK_NON_WANTED_PLAYER_THIS_FRAME(player)
    Velora.invoke(0xAA9F40, "void", player)
end

function SET_IGNORE_LOW_PRIORITY_SHOCKING_EVENTS(player, toggle)
    Velora.invoke(0xAA9F70, "void", player, toggle)
end

function SET_WANTED_LEVEL_MULTIPLIER(multiplier)
    Velora.invoke(0xAA9FC0, "void", multiplier)
end

function SET_WANTED_LEVEL_DIFFICULTY(player, difficulty)
    Velora.invoke(0xAAA000, "void", player, difficulty)
end

function RESET_WANTED_LEVEL_DIFFICULTY(player)
    Velora.invoke(0xAAA050, "void", player)
end

function GET_WANTED_LEVEL_TIME_TO_ESCAPE(player, wantedLevel, lossTime)
    return Velora.invoke(0xAAA0B0, "int", player, wantedLevel, lossTime)
end

function RESET_WANTED_LEVEL_HIDDEN_ESCAPE_TIME(player)
    Velora.invoke(0xAAA100, "void", player)
end

function START_FIRING_AMNESTY(duration)
    Velora.invoke(0xAAA140, "void", duration)
end

function REPORT_CRIME(player, crimeType, wantedLvlThresh)
    Velora.invoke(0xAAA1A0, "void", player, crimeType, wantedLvlThresh)
end

function SUPPRESS_CRIME_THIS_FRAME(player, crimeType)
    Velora.invoke(0xAAA270, "void", player, crimeType)
end

function UPDATE_WANTED_POSITION_THIS_FRAME(player)
    Velora.invoke(0xAAA2C0, "void", player)
end

function SUPPRESS_LOSING_WANTED_LEVEL_IF_HIDDEN_THIS_FRAME(player)
    Velora.invoke(0xAAA2F0, "void", player)
end

function ALLOW_EVASION_HUD_IF_DISABLING_HIDDEN_EVASION_THIS_FRAME(player, p1)
    Velora.invoke(0xAAA320, "void", player, p1)
end

function FORCE_START_HIDDEN_EVASION(player)
    Velora.invoke(0xAAA390, "void", player)
end

function SUPPRESS_WITNESSES_CALLING_POLICE_THIS_FRAME(player)
    Velora.invoke(0xAAA3D0, "void", player)
end

function REPORT_POLICE_SPOTTED_PLAYER(player)
    Velora.invoke(0xAAA400, "void", player)
end

function SET_LAW_RESPONSE_DELAY_OVERRIDE(p0)
    Velora.invoke(0xAAA490, "void", p0)
end

function RESET_LAW_RESPONSE_DELAY_OVERRIDE()
    Velora.invoke(0xAAA4B0, "void")
end

function CAN_PLAYER_START_MISSION(invoke<BOOL>(0xAAA4C0, invoke<BOOL>(0xAAA500, player, invoke<BOOL>(0xAAA530, player, invoke<BOOL>(0xAAA5D0, invoke<BOOL>(0xAAA630, player, invoke<BOOL>(0xAAA680, player, invoke<BOOL>(0xAAA730, player, range)
    return Velora.invoke(0xAAA7A0, "bool", invoke<BOOL>(0xAAA4C0, invoke<BOOL>(0xAAA500, player, invoke<BOOL>(0xAAA530, player, invoke<BOOL>(0xAAA5D0, invoke<BOOL>(0xAAA630, player, invoke<BOOL>(0xAAA680, player, invoke<BOOL>(0xAAA730, player, range)
end

function SET_PLAYER_CAN_DO_DRIVE_BY(player, toggle)
    Velora.invoke(0xAAA7F0, "void", player, toggle)
end

function SET_PLAYER_CAN_BE_HASSLED_BY_GANGS(player, toggle)
    Velora.invoke(0xAAA840, "void", player, toggle)
end

function SET_PLAYER_CAN_USE_COVER(player, toggle)
    Velora.invoke(0xAAA890, "void", player, toggle)
end

function GET_MAX_WANTED_LEVEL(invoke<BOOL>(0xAAA8F0, player, toggle)
    return Velora.invoke(0xAAA940, "int", invoke<BOOL>(0xAAA8F0, player, toggle)
end

function RESET_PLAYER_STAMINA(player)
    Velora.invoke(0xAAA990, "void", player)
end

function RESTORE_PLAYER_STAMINA(player, p1)
    Velora.invoke(0xAAA9C0, "void", player, p1)
end

function GET_PLAYER_SPRINT_STAMINA_REMAINING(invoke<float>(0xAAAA20, invoke<float>(0xAAAA70, invoke<float>(0xAAAAE0, player, invoke<float>(0xAAAB40, invoke<int>(0xAAABB0, invoke<int>(0xAAABD0, invoke<BOOL>(0xAAAC10, invoke<BOOL>(0xAAACB0, invoke<BOOL>(0xAAAD00, player, invoke<BOOL>(0xAAAD40, player)
    return Velora.invoke(0xAAADD0, "float", invoke<float>(0xAAAA20, invoke<float>(0xAAAA70, invoke<float>(0xAAAAE0, player, invoke<float>(0xAAAB40, invoke<int>(0xAAABB0, invoke<int>(0xAAABD0, invoke<BOOL>(0xAAAC10, invoke<BOOL>(0xAAACB0, invoke<BOOL>(0xAAAD00, player, invoke<BOOL>(0xAAAD40, player)
end

function GET_PLAYERS_LAST_VEHICLE(invoke<Player>(0xAAAE70, invoke<int>(0xAAAE80, invoke<int>(0xAAAE90, invoke<int>(0xAAAED0, invoke<int>(0xAAAF10, invoke<int>(0xAAAF50, invoke<BOOL>(0xAAAF90, invoke<BOOL>(0xAAB080, cleanupFlags)
    return Velora.invoke(0xAAB0C0, "int", invoke<Player>(0xAAAE70, invoke<int>(0xAAAE80, invoke<int>(0xAAAE90, invoke<int>(0xAAAED0, invoke<int>(0xAAAF10, invoke<int>(0xAAAF50, invoke<BOOL>(0xAAAF90, invoke<BOOL>(0xAAB080, cleanupFlags)
end

function FORCE_CLEANUP_FOR_ALL_THREADS_WITH_THIS_NAME(name, cleanupFlags)
    Velora.invoke(0xAAB100, "void", name, cleanupFlags)
end

function FORCE_CLEANUP_FOR_THREAD_WITH_THIS_ID(id, cleanupFlags)
    Velora.invoke(0xAAB130, "void", id, cleanupFlags)
end

function GET_CAUSE_OF_MOST_RECENT_FORCE_CLEANUP(player, vehicle)
    return Velora.invoke(0xAAB1A0, "int", player, vehicle)
end

function SET_PLAYER_MAY_NOT_ENTER_ANY_VEHICLE(player)
    Velora.invoke(0xAAB1B0, "void", player)
end

function GIVE_ACHIEVEMENT_TO_PLAYER(invoke<BOOL>(0xAAB1F0, achievementId, invoke<BOOL>(0xAAB220, invoke<int>(0xAAB250, invoke<BOOL>(0xAAB280, p0)
    return Velora.invoke(0xAAB2F0, "bool", invoke<BOOL>(0xAAB1F0, achievementId, invoke<BOOL>(0xAAB220, invoke<int>(0xAAB250, invoke<BOOL>(0xAAB280, p0)
end

function IS_SYSTEM_UI_BEING_DISPLAYED(player, toggle)
    return Velora.invoke(0xAAB320, "bool", player, toggle)
end

function GET_PLAYER_INVINCIBLE(invoke<BOOL>(0xAAB3A0, invoke<BOOL>(0xAAB3E0, player, toggle)
    return Velora.invoke(0xAAB3F0, "bool", invoke<BOOL>(0xAAB3A0, invoke<BOOL>(0xAAB3E0, player, toggle)
end

function SET_PLAYER_CAN_COLLECT_DROPPED_MONEY(player, p1)
    Velora.invoke(0xAAB460, "void", player, p1)
end

function REMOVE_PLAYER_HELMET(player, p2)
    Velora.invoke(0xAAB4B0, "void", player, p2)
end

function GIVE_PLAYER_RAGDOLL_CONTROL(player, toggle)
    Velora.invoke(0xAAB500, "void", player, toggle)
end

function SET_PLAYER_LOCKON(player, toggle)
    Velora.invoke(0xAAB560, "void", player, toggle)
end

function SET_PLAYER_TARGETING_MODE(targetMode)
    Velora.invoke(0xAAB5A0, "void", targetMode)
end

function SET_PLAYER_TARGET_LEVEL(targetLevel)
    Velora.invoke(0xAAB610, "void", targetLevel)
end

function GET_IS_USING_FPS_THIRD_PERSON_COVER(player)
    return Velora.invoke(0xAAB640, "bool", player)
end

function HAS_PLAYER_DAMAGED_AT_LEAST_ONE_PED(invoke<BOOL>(0xAAB670, player)
    return Velora.invoke(0xAAB6C0, "bool", invoke<BOOL>(0xAAB670, player)
end

function HAS_PLAYER_DAMAGED_AT_LEAST_ONE_NON_ANIMAL_PED(invoke<BOOL>(0xAAB6F0, player, multiplier)
    return Velora.invoke(0xAAB740, "bool", invoke<BOOL>(0xAAB6F0, player, multiplier)
end

function SET_SWIM_MULTIPLIER_FOR_PLAYER(player, multiplier)
    Velora.invoke(0xAAB7A0, "void", player, multiplier)
end

function SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(player, multiplier)
    Velora.invoke(0xAAB800, "void", player, multiplier)
end

function GET_TIME_SINCE_LAST_ARREST(ASSISTED_MOVEMENT_CLOSE_ROUTE()
    return Velora.invoke(0xAAB8C0, "int", ASSISTED_MOVEMENT_CLOSE_ROUTE()
end

function ASSISTED_MOVEMENT_FLUSH_ROUTE()
    Velora.invoke(0xAAB910, "void")
end

function SET_PLAYER_FORCED_AIM(player, toggle)
    Velora.invoke(0xAAB940, "void", player, toggle)
end

function SET_PLAYER_FORCED_ZOOM(player, toggle)
    Velora.invoke(0xAAB980, "void", player, toggle)
end

function SET_PLAYER_FORCE_SKIP_AIM_INTRO(player, toggle)
    Velora.invoke(0xAAB9D0, "void", player, toggle)
end

function DISABLE_PLAYER_FIRING(player, toggle)
    Velora.invoke(0xAABA20, "void", player, toggle)
end

function DISABLE_PLAYER_THROW_GRENADE_WHILE_USING_GUN()
    Velora.invoke(0xAABAB0, "void")
end

function SET_DISABLE_AMBIENT_MELEE_MOVE(player, toggle)
    Velora.invoke(0xAABAD0, "void", player, toggle)
end

function SET_PLAYER_MAX_ARMOUR(player, value)
    Velora.invoke(0xAABB90, "void", player, value)
end

function SPECIAL_ABILITY_ACTIVATE(player, p1)
    Velora.invoke(0xAABBD0, "void", player, p1)
end

function SET_SPECIAL_ABILITY_MP(player, p1, p2)
    Velora.invoke(0xAABC30, "void", player, p1, p2)
end

function SPECIAL_ABILITY_DEACTIVATE_MP(player, p1)
    Velora.invoke(0xAABCA0, "void", player, p1)
end

function SPECIAL_ABILITY_DEACTIVATE(player, p1)
    Velora.invoke(0xAABCB0, "void", player, p1)
end

function SPECIAL_ABILITY_DEACTIVATE_FAST(player, p1)
    Velora.invoke(0xAABD10, "void", player, p1)
end

function SPECIAL_ABILITY_RESET(player, p1)
    Velora.invoke(0xAABD80, "void", player, p1)
end

function SPECIAL_ABILITY_CHARGE_ON_MISSION_FAILED(player, p1)
    Velora.invoke(0xAABDE0, "void", player, p1)
end

function SPECIAL_ABILITY_CHARGE_SMALL(player, p1, p2, p3)
    Velora.invoke(0xAABE40, "void", player, p1, p2, p3)
end

function SPECIAL_ABILITY_CHARGE_MEDIUM(player, p1, p2, p3)
    Velora.invoke(0xAABE70, "void", player, p1, p2, p3)
end

function SPECIAL_ABILITY_CHARGE_LARGE(player, p1, p2, p3)
    Velora.invoke(0xAABEA0, "void", player, p1, p2, p3)
end

function SPECIAL_ABILITY_CHARGE_CONTINUOUS(player, p1, p2)
    Velora.invoke(0xAABED0, "void", player, p1, p2)
end

function SPECIAL_ABILITY_CHARGE_ABSOLUTE(player, p1, p2, p3)
    Velora.invoke(0xAABF50, "void", player, p1, p2, p3)
end

function SPECIAL_ABILITY_CHARGE_NORMALIZED(player, normalizedValue, p2, p3)
    Velora.invoke(0xAABFD0, "void", player, normalizedValue, p2, p3)
end

function SPECIAL_ABILITY_FILL_METER(player, p1, p2)
    Velora.invoke(0xAAC060, "void", player, p1, p2)
end

function SPECIAL_ABILITY_DEPLETE_METER(player, p1, p2)
    Velora.invoke(0xAAC0E0, "void", player, p1, p2)
end

function SPECIAL_ABILITY_LOCK(playerModel, p1)
    Velora.invoke(0xAAC160, "void", playerModel, p1)
end

function SPECIAL_ABILITY_UNLOCK(playerModel, p1)
    Velora.invoke(0xAAC180, "void", playerModel, p1)
end

function IS_SPECIAL_ABILITY_UNLOCKED(invoke<BOOL>(0xAAC1A0, player, invoke<BOOL>(0xAAC1D0, player, invoke<BOOL>(0xAAC240, player, toggle, p2)
    return Velora.invoke(0xAAC2B0, "bool", invoke<BOOL>(0xAAC1A0, player, invoke<BOOL>(0xAAC1D0, player, invoke<BOOL>(0xAAC240, player, toggle, p2)
end

function IS_SPECIAL_ABILITY_ENABLED(player, invoke<BOOL>(0xAAC320, multiplier)
    return Velora.invoke(0xAAC390, "bool", player, invoke<BOOL>(0xAAC320, multiplier)
end

function UPDATE_SPECIAL_ABILITY_FROM_STAT(player, p1)
    Velora.invoke(0xAAC3B0, "void", player, p1)
end

function GET_IS_PLAYER_DRIVING_ON_HIGHWAY(invoke<BOOL>(0xAAC410, player, invoke<BOOL>(0xAAC490, player, invoke<BOOL>(0xAAC530, player, x, y, z, heading, p5, findCollisionLand, p7)
    return Velora.invoke(0xAAC560, "bool", invoke<BOOL>(0xAAC410, player, invoke<BOOL>(0xAAC490, player, invoke<BOOL>(0xAAC530, player, x, y, z, heading, p5, findCollisionLand, p7)
end

function UPDATE_PLAYER_TELEPORT(invoke<BOOL>(0xAAC5A0, STOP_PLAYER_TELEPORT()
    return Velora.invoke(0xAAC5F0, "bool", invoke<BOOL>(0xAAC5A0, STOP_PLAYER_TELEPORT()
end

function IS_PLAYER_TELEPORT_ACTIVE(invoke<float>(0xAAC620, player, regenRate)
    return Velora.invoke(0xAAC670, "bool", invoke<float>(0xAAC620, player, regenRate)
end

function GET_PLAYER_HEALTH_RECHARGE_MAX_PERCENT(invoke<float>(0xAAC6C0, player, limit)
    return Velora.invoke(0xAAC710, "float", invoke<float>(0xAAC6C0, player, limit)
end

function DISABLE_PLAYER_HEALTH_RECHARGE(player)
    Velora.invoke(0xAAC770, "void", player)
end

function SET_PLAYER_FALL_DISTANCE_TO_TRIGGER_RAGDOLL_OVERRIDE(player, p1)
    Velora.invoke(0xAAC7A0, "void", player, p1)
end

function SET_PLAYER_WEAPON_DAMAGE_MODIFIER(player, modifier)
    Velora.invoke(0xAAC7F0, "void", player, modifier)
end

function SET_PLAYER_WEAPON_DEFENSE_MODIFIER(player, modifier)
    Velora.invoke(0xAAC840, "void", player, modifier)
end

function SET_PLAYER_WEAPON_MINIGUN_DEFENSE_MODIFIER(player, modifier)
    Velora.invoke(0xAAC890, "void", player, modifier)
end

function SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(player, modifier, p2)
    Velora.invoke(0xAAC8E0, "void", player, modifier, p2)
end

function SET_PLAYER_MELEE_WEAPON_DEFENSE_MODIFIER(player, modifier)
    Velora.invoke(0xAAC940, "void", player, modifier)
end

function SET_PLAYER_VEHICLE_DAMAGE_MODIFIER(player, modifier)
    Velora.invoke(0xAAC990, "void", player, modifier)
end

function SET_PLAYER_VEHICLE_DEFENSE_MODIFIER(player, modifier)
    Velora.invoke(0xAAC9E0, "void", player, modifier)
end

function SET_PLAYER_MAX_EXPLOSIVE_DAMAGE(player, p1)
    Velora.invoke(0xAACA30, "void", player, p1)
end

function SET_PLAYER_EXPLOSIVE_DAMAGE_MODIFIER(player, p1)
    Velora.invoke(0xAACA80, "void", player, p1)
end

function SET_PLAYER_WEAPON_TAKEDOWN_DEFENSE_MODIFIER(player, p1)
    Velora.invoke(0xAACAD0, "void", player, p1)
end

function SET_PLAYER_PARACHUTE_TINT_INDEX(player, tintIndex)
    Velora.invoke(0xAACB20, "void", player, tintIndex)
end

function GET_PLAYER_PARACHUTE_TINT_INDEX(player, tintIndex)
    Velora.invoke(0xAACB60, "void", player, tintIndex)
end

function SET_PLAYER_RESERVE_PARACHUTE_TINT_INDEX(player, index)
    Velora.invoke(0xAACBA0, "void", player, index)
end

function GET_PLAYER_RESERVE_PARACHUTE_TINT_INDEX(player, index)
    Velora.invoke(0xAACBE0, "void", player, index)
end

function SET_PLAYER_PARACHUTE_PACK_TINT_INDEX(player, tintIndex)
    Velora.invoke(0xAACC20, "void", player, tintIndex)
end

function GET_PLAYER_PARACHUTE_PACK_TINT_INDEX(player, tintIndex)
    Velora.invoke(0xAACC60, "void", player, tintIndex)
end

function SET_PLAYER_HAS_RESERVE_PARACHUTE(player)
    Velora.invoke(0xAACCA0, "void", player)
end

function GET_PLAYER_HAS_RESERVE_PARACHUTE(invoke<BOOL>(0xAACCD0, player, enabled)
    return Velora.invoke(0xAACD10, "bool", invoke<BOOL>(0xAACCD0, player, enabled)
end

function SET_PLAYER_PARACHUTE_SMOKE_TRAIL_COLOR(player, r, g, b)
    Velora.invoke(0xAACD60, "void", player, r, g, b)
end

function GET_PLAYER_PARACHUTE_SMOKE_TRAIL_COLOR(player, r, g, b)
    Velora.invoke(0xAACE10, "void", player, r, g, b)
end

function SET_PLAYER_PHONE_PALETTE_IDX(player, flags)
    Velora.invoke(0xAACE90, "void", player, flags)
end

function SET_PLAYER_NOISE_MULTIPLIER(player, multiplier)
    Velora.invoke(0xAACEC0, "void", player, multiplier)
end

function SET_PLAYER_SNEAKING_NOISE_MULTIPLIER(player, multiplier)
    Velora.invoke(0xAACF10, "void", player, multiplier)
end

function CAN_PED_HEAR_PLAYER(player, invoke<BOOL>(0xAACF60, player, amount, gaitType, speed, p4, p5)
    return Velora.invoke(0xAAD010, "bool", player, invoke<BOOL>(0xAACF60, player, amount, gaitType, speed, p4, p5)
end

function RESET_PLAYER_INPUT_GAIT(player)
    Velora.invoke(0xAAD0C0, "void", player)
end

function SET_AUTO_GIVE_PARACHUTE_WHEN_ENTER_PLANE(player, toggle)
    Velora.invoke(0xAAD100, "void", player, toggle)
end

function SET_AUTO_GIVE_SCUBA_GEAR_WHEN_EXIT_VEHICLE(player, toggle)
    Velora.invoke(0xAAD150, "void", player, toggle)
end

function SET_PLAYER_STEALTH_PERCEPTION_MODIFIER(player, value)
    Velora.invoke(0xAAD1A0, "void", player, value)
end

function IS_REMOTE_PLAYER_IN_NON_CLONED_VEHICLE(invoke<BOOL>(0xAAD200, player)
    return Velora.invoke(0xAAD240, "bool", invoke<BOOL>(0xAAD200, player)
end

function SET_PLAYER_SIMULATE_AIMING(player, toggle)
    Velora.invoke(0xAAD270, "void", player, toggle)
end

function SET_PLAYER_CLOTH_PIN_FRAMES(player, p1)
    Velora.invoke(0xAAD2B0, "void", player, p1)
end

function SET_PLAYER_CLOTH_PACKAGE_INDEX(index)
    Velora.invoke(0xAAD2F0, "void", index)
end

function SET_PLAYER_CLOTH_LOCK_COUNTER(value)
    Velora.invoke(0xAAD320, "void", value)
end

function PLAYER_ATTACH_VIRTUAL_BOUND(p0, p1, p2, p3, p4, p5, p6, p7)
    Velora.invoke(0xAAD350, "void", p0, p1, p2, p3, p4, p5, p6, p7)
end

function PLAYER_DETACH_VIRTUAL_BOUND()
    Velora.invoke(0xAAD370, "void")
end

function HAS_PLAYER_BEEN_SPOTTED_IN_STOLEN_VEHICLE(invoke<BOOL>(0xAAD3D0, invoke<BOOL>(0xAAD420, player, p1, invoke<BOOL>(0xAAD4A0, x, y, z)
    return Velora.invoke(0xAAD510, "bool", invoke<BOOL>(0xAAD3D0, invoke<BOOL>(0xAAD420, player, p1, invoke<BOOL>(0xAAD4A0, x, y, z)
end

function RESET_WORLD_BOUNDARY_FOR_PLAYER()
    Velora.invoke(0xAAD570, "void")
end

function IS_PLAYER_RIDING_TRAIN(invoke<BOOL>(0xAAD5D0, invoke<BOOL>(0xAAD630, player, toggle)
    return Velora.invoke(0xAAD680, "bool", invoke<BOOL>(0xAAD5D0, invoke<BOOL>(0xAAD630, player, toggle)
end

function SET_PLAYER_PARACHUTE_VARIATION_OVERRIDE(player, p1, p2, p3, p4)
    Velora.invoke(0xAAD6D0, "void", player, p1, p2, p3, p4)
end

function CLEAR_PLAYER_PARACHUTE_VARIATION_OVERRIDE(player)
    Velora.invoke(0xAAD740, "void", player)
end

function SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(player, model)
    Velora.invoke(0xAAD770, "void", player, model)
end

function SET_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(player, model)
    Velora.invoke(0xAAD7B0, "void", player, model)
end

function GET_PLAYER_PARACHUTE_MODEL_OVERRIDE(invoke<Hash>(0xAAD7F0, invoke<Hash>(0xAAD830, player)
    return Velora.invoke(0xAAD870, "int", invoke<Hash>(0xAAD7F0, invoke<Hash>(0xAAD830, player)
end

function CLEAR_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(player)
    Velora.invoke(0xAAD8B0, "void", player)
end

function SET_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(player, model)
    Velora.invoke(0xAAD8F0, "void", player, model)
end

function CLEAR_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(player)
    Velora.invoke(0xAAD930, "void", player)
end

function DISABLE_PLAYER_VEHICLE_REWARDS(player)
    Velora.invoke(0xAAD970, "void", player)
end

function SET_PLAYER_SPECTATED_VEHICLE_RADIO_OVERRIDE(p0)
    Velora.invoke(0xAAD9A0, "void", p0)
end

function SET_PLAYER_BLUETOOTH_STATE(player, state)
    Velora.invoke(0xAAD9E0, "void", player, state)
end

function IS_PLAYER_BLUETOOTH_ENABLE(invoke<BOOL>(0xAADA30, player)
    return Velora.invoke(0xAADA80, "bool", invoke<BOOL>(0xAADA30, player)
end

function GET_PLAYER_FAKE_WANTED_LEVEL(invoke<int>(0xAADAB0, player1, player2, toggle)
    return Velora.invoke(0xAADB10, "int", invoke<int>(0xAADAB0, player1, player2, toggle)
end

function SET_APPLY_WAYPOINT_OF_PLAYER(player, hudColor)
    Velora.invoke(0xAADB90, "void", player, hudColor)
end

function IS_PLAYER_VEHICLE_WEAPON_TOGGLED_TO_NON_HOMING(invoke<BOOL>(0xAADBA0, p0)
    return Velora.invoke(0xAADC10, "bool", invoke<BOOL>(0xAADBA0, p0)
end

function SET_PLAYER_HOMING_DISABLED_FOR_ALL_VEHICLE_WEAPONS(p0, p1)
    Velora.invoke(0xAADC70, "void", p0, p1)
end

function ADD_PLAYER_TARGETABLE_ENTITY(player, entity)
    Velora.invoke(0xAADCF0, "void", player, entity)
end

function REMOVE_PLAYER_TARGETABLE_ENTITY(player, entity)
    Velora.invoke(0xAADD60, "void", player, entity)
end

function SET_PLAYER_PREVIOUS_VARIATION_DATA(player, p1, p2, p3, p4, p5)
    Velora.invoke(0xAADDD0, "void", player, p1, p2, p3, p4, p5)
end

function REMOVE_SCRIPT_FIRE_POSITION()
    Velora.invoke(0xAADE50, "void")
end

function SET_SCRIPT_FIRE_POSITION(coordX, coordY, coordZ)
    Velora.invoke(0xAADE90, "void", coordX, coordY, coordZ)
end

function REPLAY_START_EVENT(p0)
    Velora.invoke(0xAAE130, "void", p0)
end

function REPLAY_STOP_EVENT()
    Velora.invoke(0xAAE140, "void")
end

function REPLAY_CANCEL_EVENT()
    Velora.invoke(0xAAE150, "void")
end

function REPLAY_RECORD_BACK_FOR_TIME(p0, p1, p2)
    Velora.invoke(0xAAE160, "void", p0, p1, p2)
end

function REPLAY_CHECK_FOR_EVENT_THIS_FRAME(missionNameLabel, p1)
    Velora.invoke(0xAAE170, "void", missionNameLabel, p1)
end

function REPLAY_PREVENT_RECORDING_THIS_FRAME()
    Velora.invoke(0xAAE180, "void")
end

function REPLAY_RESET_EVENT_INFO()
    Velora.invoke(0xAAE190, "void")
end

function REPLAY_DISABLE_CAMERA_MOVEMENT_THIS_FRAME()
    Velora.invoke(0xAAE1A0, "void")
end

function RECORD_GREATEST_MOMENT(p0, p1, p2)
    Velora.invoke(0xAAE1B0, "void", p0, p1, p2)
end

function START_REPLAY_RECORDING(mode)
    Velora.invoke(0xDEADBEEF, "void", mode)
end

function STOP_REPLAY_RECORDING()
    Velora.invoke(0xAAE1C0, "void")
end

function CANCEL_REPLAY_RECORDING()
    Velora.invoke(0xDEADBEEF, "void")
end

function SAVE_REPLAY_RECORDING(invoke<BOOL>(0xDEADBEEF, p0, p1)
    return Velora.invoke(0xAAE2F0, "bool", invoke<BOOL>(0xDEADBEEF, p0, p1)
end

function REPLAY_SYSTEM_HAS_REQUESTED_A_SCRIPT_CLEANUP(SET_SCRIPTS_HAVE_CLEANED_UP_FOR_REPLAY_SYSTEM()
    return Velora.invoke(0xAAE310, "bool", SET_SCRIPTS_HAVE_CLEANED_UP_FOR_REPLAY_SYSTEM()
end

function SET_REPLAY_SYSTEM_PAUSED_FOR_SAVE(p0)
    Velora.invoke(0xAAE320, "void", p0)
end

function REPLAY_CONTROL_SHUTDOWN()
    Velora.invoke(0xAAE330, "void")
end

function ACTIVATE_ROCKSTAR_EDITOR(p0)
    Velora.invoke(0xAAE340, "void", p0)
end

function SAVEMIGRATION_IS_MP_ENABLED(p0, invoke<BOOL>(0xAAFCB0, scriptName)
    return Velora.invoke(0xAB0E40, "bool", p0, invoke<BOOL>(0xAAFCB0, scriptName)
end

function SET_SCRIPT_AS_NO_LONGER_NEEDED(scriptName)
    Velora.invoke(0xAB0EC0, "void", scriptName)
end

function HAS_SCRIPT_LOADED(invoke<BOOL>(0xAB0F20, invoke<BOOL>(0xAB0F70, scriptHash)
    return Velora.invoke(0xAB0FB0, "bool", invoke<BOOL>(0xAB0F20, invoke<BOOL>(0xAB0F70, scriptHash)
end

function SET_SCRIPT_WITH_NAME_HASH_AS_NO_LONGER_NEEDED(scriptHash)
    Velora.invoke(0xAB10A0, "void", scriptHash)
end

function HAS_SCRIPT_WITH_NAME_HASH_LOADED(invoke<BOOL>(0xAB1150, invoke<BOOL>(0xAB11F0, threadId)
    return Velora.invoke(0xAB1280, "bool", invoke<BOOL>(0xAB1150, invoke<BOOL>(0xAB11F0, threadId)
end

function IS_THREAD_ACTIVE(invoke<BOOL>(0xAB1290, char>(0xAB12D0, SCRIPT_THREAD_ITERATOR_RESET()
    return Velora.invoke(0xAB1350, "bool", invoke<BOOL>(0xAB1290, char>(0xAB12D0, SCRIPT_THREAD_ITERATOR_RESET()
end

function SCRIPT_THREAD_ITERATOR_GET_NEXT_THREAD_ID(TERMINATE_THIS_THREAD()
    return Velora.invoke(0xAB13A0, "int", TERMINATE_THIS_THREAD()
end

function GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(invoke<int>(0xAB13C0, invoke<int>(0xAB1430, eventGroup, invoke<BOOL>(0xAB1480, eventGroup, invoke<int>(0xAB14B0, eventGroup, eventIndex, eventData, invoke<BOOL>(0xAB14F0, eventGroup, eventData, eventDataSize, playerBits)
    return Velora.invoke(0xAB1540, "int", invoke<int>(0xAB13C0, invoke<int>(0xAB1430, eventGroup, invoke<BOOL>(0xAB1480, eventGroup, invoke<int>(0xAB14B0, eventGroup, eventIndex, eventData, invoke<BOOL>(0xAB14F0, eventGroup, eventData, eventDataSize, playerBits)
end

function SHUTDOWN_LOADING_SCREEN()
    Velora.invoke(0xAB1560, "void")
end

function SET_NO_LOADING_SCREEN(toggle)
    Velora.invoke(0xAB1570, "void", toggle)
end

function GET_NO_LOADING_SCREEN(COMMIT_TO_LOADINGSCREEN_SELCTION()
    return Velora.invoke(0xAB15A0, "bool", COMMIT_TO_LOADINGSCREEN_SELCTION()
end

function BG_IS_EXITFLAG_SET(BG_SET_EXITFLAG_RESPONSE()
    return Velora.invoke(0xAB15E0, "bool", BG_SET_EXITFLAG_RESPONSE()
end

function BG_START_CONTEXT_HASH(contextHash)
    Velora.invoke(0xAB1600, "void", contextHash)
end

function BG_END_CONTEXT_HASH(contextHash)
    Velora.invoke(0xAB1620, "void", contextHash)
end

function BG_START_CONTEXT(contextName)
    Velora.invoke(0xAB1640, "void", contextName)
end

function BG_END_CONTEXT(contextName)
    Velora.invoke(0xAB1670, "void", contextName)
end

function BG_DOES_LAUNCH_PARAM_EXIST(scriptIndex, invoke<BOOL>(0xAB16A0, scriptIndex, invoke<int>(0xAB1710, invoke<int>(0xAB1790, eventGroup, eventData, eventDataSize, playerBits)
    return Velora.invoke(0xDEADBEEF, "bool", scriptIndex, invoke<BOOL>(0xAB16A0, scriptIndex, invoke<int>(0xAB1710, invoke<int>(0xAB1790, eventGroup, eventData, eventDataSize, playerBits)
end

function REGISTER_SCRIPT_VARIABLE(variable)
    Velora.invoke(0xAAFE10, "void", variable)
end

function UNREGISTER_SCRIPT_VARIABLE(variable)
    Velora.invoke(0xAAFE40, "void", variable)
end

function FORCE_CHECK_SCRIPT_VARIABLES()
    Velora.invoke(0xAAFE70, "void")
end

function START_SHAPE_TEST_LOS_PROBE(x1, y1, z1, x2, y2, z2, flags, entity, invoke<int>(0xAB3290, x1, y1, z1, x2, y2, z2, flags, entity, invoke<int>(0xAB32C0, entity, flags1, invoke<int>(0xAB32F0, x, y, z, dimX, dimY, dimZ, rotX, rotY, rotZ, p9, flags, entity, invoke<int>(0xAB3320, entity, flags1, invoke<int>(0xAB3360, x1, y1, z1, x2, y2, z2, radius, flags, entity, invoke<int>(0xAB3390, x1, y1, z1, x2, y2, z2, radius, flags, entity, invoke<int>(0xAB33D0, pVec1, pVec2, flag, entity, invoke<int>(0xAB3410, shapeTestHandle, hit, endCoords, surfaceNormal, invoke<int>(0xAB34B0, shapeTestHandle, hit, endCoords, surfaceNormal, materialHash, invoke<int>(0xAB3560, entityHit)
    return Velora.invoke(0xAB3610, "int", x1, y1, z1, x2, y2, z2, flags, entity, invoke<int>(0xAB3290, x1, y1, z1, x2, y2, z2, flags, entity, invoke<int>(0xAB32C0, entity, flags1, invoke<int>(0xAB32F0, x, y, z, dimX, dimY, dimZ, rotX, rotY, rotZ, p9, flags, entity, invoke<int>(0xAB3320, entity, flags1, invoke<int>(0xAB3360, x1, y1, z1, x2, y2, z2, radius, flags, entity, invoke<int>(0xAB3390, x1, y1, z1, x2, y2, z2, radius, flags, entity, invoke<int>(0xAB33D0, pVec1, pVec2, flag, entity, invoke<int>(0xAB3410, shapeTestHandle, hit, endCoords, surfaceNormal, invoke<int>(0xAB34B0, shapeTestHandle, hit, endCoords, surfaceNormal, materialHash, invoke<int>(0xAB3560, entityHit)
end

function SC_INBOX_GET_TOTAL_NUM_MESSAGES(invoke<Hash>(0xAB5830, invoke<BOOL>(0xAB58A0, invoke<BOOL>(0xAB58D0, p0, context, invoke<BOOL>(0xAB5900, p0, invoke<BOOL>(0xAB5940, p0, context, invoke<BOOL>(0xAB59C0, invoke<BOOL>(0xAB5A00, char>(0xAB5A30, gamerHandle)
    return Velora.invoke(0xAB5A90, "int", invoke<Hash>(0xAB5830, invoke<BOOL>(0xAB58A0, invoke<BOOL>(0xAB58D0, p0, context, invoke<BOOL>(0xAB5900, p0, invoke<BOOL>(0xAB5940, p0, context, invoke<BOOL>(0xAB59C0, invoke<BOOL>(0xAB5A00, char>(0xAB5A30, gamerHandle)
end

function SC_INBOX_SEND_UGCSTATUPDATE_TO_RECIP_LIST(data)
    Velora.invoke(0xAB5B50, "void", data)
end

function SC_INBOX_MESSAGE_GET_UGCDATA(p0, invoke<BOOL>(0xAB5B90, invoke<BOOL>(0xDEADBEEF, index, invoke<BOOL>(0xAB5BC0, offset, limit)
    return Velora.invoke(0xAB5BF0, "bool", p0, invoke<BOOL>(0xAB5B90, invoke<BOOL>(0xDEADBEEF, index, invoke<BOOL>(0xAB5BC0, offset, limit)
end

function SC_EMAIL_GET_RETRIEVAL_STATUS(p0, invoke<BOOL>(0xAB5C60, p0, p1)
    return Velora.invoke(0xAB5CD0, "int", p0, invoke<BOOL>(0xAB5C60, p0, p1)
end

function SC_EMAIL_MESSAGE_PUSH_GAMER_TO_RECIP_LIST(gamerHandle)
    Velora.invoke(0xAB5D10, "void", gamerHandle)
end

function SC_EMAIL_MESSAGE_CLEAR_RECIP_LIST()
    Velora.invoke(0xAB5DB0, "void")
end

function SC_EMAIL_SEND_EMAIL(p0)
    Velora.invoke(0xAB5DC0, "void", p0)
end

function SC_EMAIL_SET_CURRENT_EMAIL_TAG(invoke<BOOL>(0xAB5E20, toggle)
    return Velora.invoke(0xAB5E50, "bool", invoke<BOOL>(0xAB5E20, toggle)
end

function SC_HAS_NEW_ROCKSTAR_MSG(attrHash, invoke<BOOL>(0xAB5EB0, attrHash, invoke<BOOL>(0xAB5EE0, attrHash, invoke<BOOL>(0xAB5F20, p0, invoke<BOOL>(0xAB5F60, name, invoke<BOOL>(0xAB5FA0, name, invoke<BOOL>(0xAB5FE0, invoke<BOOL>(0xAB6020, name, invoke<BOOL>(0xAB6090, invoke<BOOL>(0xAB60D0, string, invoke<BOOL>(0xAB6100, string, invoke<BOOL>(0xAB6150, invoke<BOOL>(0xAB6180, invoke<BOOL>(0xAB61E0, invoke<BOOL>(0xAB6240, invoke<int>(0xAB62A0, p0, invoke<BOOL>(0xAB63A0, invoke<BOOL>(0xAB63E0, invoke<BOOL>(0xAB6440, invoke<int>(0xAB64A0, token, char>(0xAB64F0, token, char>(0xAB6550, oldPlateText, newPlateText, invoke<BOOL>(0xAB65B0, plateText, plateData, invoke<BOOL>(0xAB6630, invoke<BOOL>(0xAB66A0, invoke<int>(0xAB6700, plateText, invoke<BOOL>(0xAB6750, invoke<BOOL>(0xAB6790, invoke<int>(0xAB67F0, p0, invoke<BOOL>(0xAB68A0, p0, invoke<BOOL>(0xAB68E0, p0, invoke<BOOL>(0xAB6920, invoke<BOOL>(0xAB6970, invoke<BOOL>(0xAB69B0, invoke<int>(0xAB69E0, p0, p1, invoke<BOOL>(0xAB6A10, p0, p1, invoke<BOOL>(0xAB6A60, p0, p1, invoke<BOOL>(0xAB6AB0, p0, invoke<BOOL>(0xAB6B00, invoke<BOOL>(0xAB6B50, p0, p1, invoke<BOOL>(0xAB6B80, p0, p1, invoke<BOOL>(0xAB6BD0, p0, p1, invoke<BOOL>(0xAB6C20, p0, invoke<BOOL>(0xAB6C70, invoke<BOOL>(0xAB6CC0, p0, invoke<BOOL>(0xAB6D10, p0, invoke<BOOL>(0xAB6DC0, SC_TRANSITION_NEWS_END()
    return Velora.invoke(0xAB6E00, "bool", attrHash, invoke<BOOL>(0xAB5EB0, attrHash, invoke<BOOL>(0xAB5EE0, attrHash, invoke<BOOL>(0xAB5F20, p0, invoke<BOOL>(0xAB5F60, name, invoke<BOOL>(0xAB5FA0, name, invoke<BOOL>(0xAB5FE0, invoke<BOOL>(0xAB6020, name, invoke<BOOL>(0xAB6090, invoke<BOOL>(0xAB60D0, string, invoke<BOOL>(0xAB6100, string, invoke<BOOL>(0xAB6150, invoke<BOOL>(0xAB6180, invoke<BOOL>(0xAB61E0, invoke<BOOL>(0xAB6240, invoke<int>(0xAB62A0, p0, invoke<BOOL>(0xAB63A0, invoke<BOOL>(0xAB63E0, invoke<BOOL>(0xAB6440, invoke<int>(0xAB64A0, token, char>(0xAB64F0, token, char>(0xAB6550, oldPlateText, newPlateText, invoke<BOOL>(0xAB65B0, plateText, plateData, invoke<BOOL>(0xAB6630, invoke<BOOL>(0xAB66A0, invoke<int>(0xAB6700, plateText, invoke<BOOL>(0xAB6750, invoke<BOOL>(0xAB6790, invoke<int>(0xAB67F0, p0, invoke<BOOL>(0xAB68A0, p0, invoke<BOOL>(0xAB68E0, p0, invoke<BOOL>(0xAB6920, invoke<BOOL>(0xAB6970, invoke<BOOL>(0xAB69B0, invoke<int>(0xAB69E0, p0, p1, invoke<BOOL>(0xAB6A10, p0, p1, invoke<BOOL>(0xAB6A60, p0, p1, invoke<BOOL>(0xAB6AB0, p0, invoke<BOOL>(0xAB6B00, invoke<BOOL>(0xAB6B50, p0, p1, invoke<BOOL>(0xAB6B80, p0, p1, invoke<BOOL>(0xAB6BD0, p0, p1, invoke<BOOL>(0xAB6C20, p0, invoke<BOOL>(0xAB6C70, invoke<BOOL>(0xAB6CC0, p0, invoke<BOOL>(0xAB6D10, p0, invoke<BOOL>(0xAB6DC0, SC_TRANSITION_NEWS_END()
end

function SC_PAUSE_NEWS_INIT_STARTER_PACK(invoke<BOOL>(0xAB6E20, invoke<BOOL>(0xAB6E60, SC_PAUSE_NEWS_SHUTDOWN()
    return Velora.invoke(0xAB6E90, "bool", invoke<BOOL>(0xAB6E20, invoke<BOOL>(0xAB6E60, SC_PAUSE_NEWS_SHUTDOWN()
end

function SC_ACCOUNT_INFO_GET_NICKNAME(invoke<BOOL>(0xAB6ED0, invoke<BOOL>(0xAB6F40, invoke<BOOL>(0xACF000, invoke<BOOL>(0xACF0B0, p0, p1, p2, invoke<BOOL>(0xACF0E0, p0)
    return Velora.invoke(0xACF120, "string", invoke<BOOL>(0xAB6ED0, invoke<BOOL>(0xAB6F40, invoke<BOOL>(0xACF000, invoke<BOOL>(0xACF0B0, p0, p1, p2, invoke<BOOL>(0xACF0E0, p0)
end

function STAT_LOAD_PENDING(invoke<BOOL>(0xACF150, invoke<BOOL>(0xACF1E0, invoke<BOOL>(0xACF250, invoke<BOOL>(0xACF280, invoke<int>(0xACF2B0, toggle)
    return Velora.invoke(0xACF300, "bool", invoke<BOOL>(0xACF150, invoke<BOOL>(0xACF1E0, invoke<BOOL>(0xACF250, invoke<BOOL>(0xACF280, invoke<int>(0xACF2B0, toggle)
end

function STAT_GET_BLOCK_SAVES(invoke<BOOL>(0xACF340, p0)
    return Velora.invoke(0xACF3C0, "bool", invoke<BOOL>(0xACF340, p0)
end

function STAT_LOAD_DIRTY_READ_DETECTED(STAT_CLEAR_DIRTY_READ_DETECTED()
    return Velora.invoke(0xACF430, "bool", STAT_CLEAR_DIRTY_READ_DETECTED()
end

function STAT_GET_LOAD_SAFE_TO_PROGRESS_TO_MP_FROM_SP(statName, value, invoke<BOOL>(0xACF4B0, statName, value, invoke<BOOL>(0xACF4E0, statName, value, invoke<BOOL>(0xACF520, statName, value, invoke<BOOL>(0xACF560, statName, value, numFields, invoke<BOOL>(0xACF5A0, statName, value, invoke<BOOL>(0xACF5E0, statName, x, y, z, invoke<BOOL>(0xACF620, statName, p1, p2, p3, invoke<BOOL>(0xACF660, statName, value, invoke<BOOL>(0xACF6A0, statName, invoke<BOOL>(0xACF6E0, statHash, outValue, invoke<BOOL>(0xACF710, statHash, outValue, invoke<BOOL>(0xACF7F0, statHash, outValue, invoke<BOOL>(0xACF820, statHash, outValue, numFields, invoke<BOOL>(0xACF850, statHash, char>(0xACF880, statName, outX, outY, outZ, invoke<BOOL>(0xACF8B0, statHash, outValue, p2, p3, invoke<BOOL>(0xACF8F0, char>(0xACF9C0, char>(0xACF9F0, statName, invoke<BOOL>(0xACFA20, statName, value)
    return Velora.invoke(0xACFA50, "bool", statName, value, invoke<BOOL>(0xACF4B0, statName, value, invoke<BOOL>(0xACF4E0, statName, value, invoke<BOOL>(0xACF520, statName, value, invoke<BOOL>(0xACF560, statName, value, numFields, invoke<BOOL>(0xACF5A0, statName, value, invoke<BOOL>(0xACF5E0, statName, x, y, z, invoke<BOOL>(0xACF620, statName, p1, p2, p3, invoke<BOOL>(0xACF660, statName, value, invoke<BOOL>(0xACF6A0, statName, invoke<BOOL>(0xACF6E0, statHash, outValue, invoke<BOOL>(0xACF710, statHash, outValue, invoke<BOOL>(0xACF7F0, statHash, outValue, invoke<BOOL>(0xACF820, statHash, outValue, numFields, invoke<BOOL>(0xACF850, statHash, char>(0xACF880, statName, outX, outY, outZ, invoke<BOOL>(0xACF8B0, statHash, outValue, p2, p3, invoke<BOOL>(0xACF8F0, char>(0xACF9C0, char>(0xACF9F0, statName, invoke<BOOL>(0xACFA20, statName, value)
end

function STAT_COMMUNITY_START_SYNCH(statName, p1, invoke<BOOL>(0xACFB10, p0)
    return Velora.invoke(0xACFB50, "bool", statName, p1, invoke<BOOL>(0xACFB10, p0)
end

function STAT_LOCAL_RESET_ALL_ONLINE_CHARACTER_STATS(p0)
    Velora.invoke(0xACFB60, "void", p0)
end

function STAT_GET_NUMBER_OF_DAYS(invoke<int>(0xACFBC0, invoke<int>(0xACFBE0, invoke<int>(0xACFC00, invoke<int>(0xACFC20, profileSetting, value)
    return Velora.invoke(0xACFC40, "int", invoke<int>(0xACFBC0, invoke<int>(0xACFBE0, invoke<int>(0xACFC00, invoke<int>(0xACFC20, profileSetting, value)
end

function STATS_COMPLETED_CHARACTER_CREATION(p0)
    Velora.invoke(0xACFCB0, "void", p0)
end

function PACKED_STAT_GET_INT_STAT_INDEX(invoke<int>(0xACFCC0, index, spStat, charStat, invoke<Hash>(0xACFCF0, index, spStat, charStat, invoke<Hash>(0xACFDD0, index, spStat, charStat, character, invoke<Hash>(0xACFEB0, index, invoke<BOOL>(0xACFF90, index, invoke<int>(0xAD0040, index, value, characterSlot)
    return Velora.invoke(0xAD00F0, "int", invoke<int>(0xACFCC0, index, spStat, charStat, invoke<Hash>(0xACFCF0, index, spStat, charStat, invoke<Hash>(0xACFDD0, index, spStat, charStat, character, invoke<Hash>(0xACFEB0, index, invoke<BOOL>(0xACFF90, index, invoke<int>(0xAD0040, index, value, characterSlot)
end

function SET_PACKED_STAT_INT_CODE(index, value, characterSlot)
    Velora.invoke(0xAD0140, "void", index, value, characterSlot)
end

function PLAYSTATS_BACKGROUND_SCRIPT_ACTION(action, value)
    Velora.invoke(0xAD0190, "void", action, value)
end

function PLAYSTATS_NPC_INVITE(p0)
    Velora.invoke(0xAD03A0, "void", p0)
end

function PLAYSTATS_AWARD_XP(amount, type, category)
    Velora.invoke(0xAD03B0, "void", amount, type, category)
end

function PLAYSTATS_RANK_UP(rank)
    Velora.invoke(0xAD03D0, "void", rank)
end

function PLAYSTATS_STARTED_SESSION_IN_OFFLINEMODE()
    Velora.invoke(0xAD03E0, "void")
end

function PLAYSTATS_ACTIVITY_DONE(p0, activityId)
    Velora.invoke(0xAD0470, "void", p0, activityId)
end

function PLAYSTATS_LEAVE_JOB_CHAIN(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD0510, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_MISSION_STARTED(p0, p1, p2, p3)
    Velora.invoke(0xAD05D0, "void", p0, p1, p2, p3)
end

function PLAYSTATS_MISSION_OVER(p0, p1, p2, p3, p4, p5)
    Velora.invoke(0xAD05F0, "void", p0, p1, p2, p3, p4, p5)
end

function PLAYSTATS_MISSION_CHECKPOINT(p0, p1, p2, p3)
    Velora.invoke(0xAD06A0, "void", p0, p1, p2, p3)
end

function PLAYSTATS_RANDOM_MISSION_DONE(name, p1, p2, p3)
    Velora.invoke(0xAD06D0, "void", name, p1, p2, p3)
end

function PLAYSTATS_ROS_BET(amount, act, player, cm)
    Velora.invoke(0xAD0700, "void", amount, act, player, cm)
end

function PLAYSTATS_RACE_CHECKPOINT(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD07B0, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_CREATE_MATCH_HISTORY_ID_2(playerAccountId, invoke<BOOL>(0xAD07E0, p0, p1, p2)
    return Velora.invoke(0xAD0810, "bool", playerAccountId, invoke<BOOL>(0xAD07E0, p0, p1, p2)
end

function PLAYSTATS_SHOP_ITEM(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD0830, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_CRATE_DROP_MISSION_DONE(p0, p1, p2, p3, p4, p5, p6, p7)
    Velora.invoke(0xAD0860, "void", p0, p1, p2, p3, p4, p5, p6, p7)
end

function PLAYSTATS_CRATE_CREATED(p0, p1, p2)
    Velora.invoke(0xAD0910, "void", p0, p1, p2)
end

function PLAYSTATS_HOLD_UP_MISSION_DONE(p0, p1, p2, p3)
    Velora.invoke(0xAD0940, "void", p0, p1, p2, p3)
end

function PLAYSTATS_IMPORT_EXPORT_MISSION_DONE(p0, p1, p2, p3)
    Velora.invoke(0xAD0970, "void", p0, p1, p2, p3)
end

function PLAYSTATS_RACE_TO_POINT_MISSION_DONE(p0, p1, p2, p3)
    Velora.invoke(0xAD09F0, "void", p0, p1, p2, p3)
end

function PLAYSTATS_ACQUIRED_HIDDEN_PACKAGE(p0)
    Velora.invoke(0xAD0AB0, "void", p0)
end

function PLAYSTATS_WEBSITE_VISITED(scaleformHash, p1)
    Velora.invoke(0xAD0AC0, "void", scaleformHash, p1)
end

function PLAYSTATS_FRIEND_ACTIVITY(p0, p1)
    Velora.invoke(0xAD0AD0, "void", p0, p1)
end

function PLAYSTATS_ODDJOB_DONE(totalTimeMs, p1, p2)
    Velora.invoke(0xAD0AE0, "void", totalTimeMs, p1, p2)
end

function PLAYSTATS_PROP_CHANGE(p0, p1, p2, p3)
    Velora.invoke(0xAD0AF0, "void", p0, p1, p2, p3)
end

function PLAYSTATS_CLOTH_CHANGE(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD0B80, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_WEAPON_MODE_CHANGE(weaponHash, componentHashTo, componentHashFrom)
    Velora.invoke(0xAD0C00, "void", weaponHash, componentHashTo, componentHashFrom)
end

function PLAYSTATS_CHEAT_APPLIED(cheat)
    Velora.invoke(0xAD0CC0, "void", cheat)
end

function PLAYSTATS_JOB_ACTIVITY_END(p0, p1, p2, p3)
    Velora.invoke(0xAD0CE0, "void", p0, p1, p2, p3)
end

function PLAYSTATS_JOB_BEND(p0, p1, p2, p3)
    Velora.invoke(0xAD0D00, "void", p0, p1, p2, p3)
end

function PLAYSTATS_JOB_LTS_END(p0, p1, p2, p3)
    Velora.invoke(0xAD0D20, "void", p0, p1, p2, p3)
end

function PLAYSTATS_JOB_LTS_ROUND_END(p0, p1, p2, p3)
    Velora.invoke(0xAD0D40, "void", p0, p1, p2, p3)
end

function PLAYSTATS_QUICKFIX_TOOL(element, item)
    Velora.invoke(0xAD0D60, "void", element, item)
end

function PLAYSTATS_IDLE_KICK(msStoodIdle)
    Velora.invoke(0xAD0E10, "void", msStoodIdle)
end

function PLAYSTATS_SET_JOIN_TYPE(joinType)
    Velora.invoke(0xAD0E90, "void", joinType)
end

function PLAYSTATS_HEIST_SAVE_CHEAT(hash, p1)
    Velora.invoke(0xAD0EA0, "void", hash, p1)
end

function PLAYSTATS_APPEND_DIRECTOR_METRIC(p0)
    Velora.invoke(0xAD0EB0, "void", p0)
end

function PLAYSTATS_AWARD_BAD_SPORT(id)
    Velora.invoke(0xAD0F30, "void", id)
end

function PLAYSTATS_PEGASUS_AS_PERSONAL_AIRCRAFT(modelHash)
    Velora.invoke(0xAD0FA0, "void", modelHash)
end

function _PLAYSTATS_SHOPMENU_NAV(p0, p1, p2)
    Velora.invoke(0xAD1020, "void", p0, p1, p2)
end

function PLAYSTATS_FM_EVENT_CHALLENGES(p0)
    Velora.invoke(0xAD10C0, "void", p0)
end

function PLAYSTATS_FM_EVENT_VEHICLETARGET(p0)
    Velora.invoke(0xAD10D0, "void", p0)
end

function PLAYSTATS_FM_EVENT_URBANWARFARE(p0)
    Velora.invoke(0xAD10E0, "void", p0)
end

function PLAYSTATS_FM_EVENT_CHECKPOINTCOLLECTION(p0)
    Velora.invoke(0xAD10F0, "void", p0)
end

function PLAYSTATS_FM_EVENT_ATOB(p0)
    Velora.invoke(0xAD1100, "void", p0)
end

function PLAYSTATS_FM_EVENT_PENNEDIN(p0)
    Velora.invoke(0xAD1110, "void", p0)
end

function PLAYSTATS_FM_EVENT_PASSTHEPARCEL(p0)
    Velora.invoke(0xAD1120, "void", p0)
end

function PLAYSTATS_FM_EVENT_HOTPROPERTY(p0)
    Velora.invoke(0xAD1130, "void", p0)
end

function PLAYSTATS_FM_EVENT_DEADDROP(p0)
    Velora.invoke(0xAD1140, "void", p0)
end

function PLAYSTATS_FM_EVENT_KINGOFTHECASTLE(p0)
    Velora.invoke(0xAD1150, "void", p0)
end

function PLAYSTATS_FM_EVENT_CRIMINALDAMAGE(p0)
    Velora.invoke(0xAD1160, "void", p0)
end

function PLAYSTATS_FM_EVENT_COMPETITIVEURBANWARFARE(p0)
    Velora.invoke(0xAD1170, "void", p0)
end

function PLAYSTATS_FM_EVENT_HUNTBEAST(p0)
    Velora.invoke(0xAD1180, "void", p0)
end

function PLAYSTATS_PIMENU_HIDE_OPTIONS(data)
    Velora.invoke(0xAD1190, "void", data)
end

function LEADERBOARDS_GET_NUMBER_OF_COLUMNS(p0, invoke<int>(0xAD1280, p0, p1, invoke<int>(0xAD12C0, p0, p1, invoke<int>(0xAD1310, p0, p1, invoke<int>(0xAD13C0, p0, p1, invoke<BOOL>(0xAD1430, p0, p1, invoke<BOOL>(0xAD14B0, p0, p1, p2, p3, p4, invoke<BOOL>(0xAD1530, p0, invoke<BOOL>(0xAD1570, p0, p1, p2, p3, p4, p5, invoke<BOOL>(0xDEADBEEF, p0, p1, invoke<BOOL>(0xAD15A0, p0, p1, invoke<BOOL>(0xAD15D0, p0, p1, invoke<BOOL>(0xAD1600, p0, p1, invoke<BOOL>(0xAD1630, p0, p1, invoke<BOOL>(0xAD1660, p0, gamerHandleCsv, invoke<BOOL>(0xAD1690, invoke<BOOL>(0xAD16C0, LEADERBOARDS2_READ_GET_ROW_DATA_END()
    return Velora.invoke(0xAD16F0, "int", p0, invoke<int>(0xAD1280, p0, p1, invoke<int>(0xAD12C0, p0, p1, invoke<int>(0xAD1310, p0, p1, invoke<int>(0xAD13C0, p0, p1, invoke<BOOL>(0xAD1430, p0, p1, invoke<BOOL>(0xAD14B0, p0, p1, p2, p3, p4, invoke<BOOL>(0xAD1530, p0, invoke<BOOL>(0xAD1570, p0, p1, p2, p3, p4, p5, invoke<BOOL>(0xDEADBEEF, p0, p1, invoke<BOOL>(0xAD15A0, p0, p1, invoke<BOOL>(0xAD15D0, p0, p1, invoke<BOOL>(0xAD1600, p0, p1, invoke<BOOL>(0xAD1630, p0, p1, invoke<BOOL>(0xAD1660, p0, gamerHandleCsv, invoke<BOOL>(0xAD1690, invoke<BOOL>(0xAD16C0, LEADERBOARDS2_READ_GET_ROW_DATA_END()
end

function LEADERBOARDS2_READ_GET_ROW_DATA_INFO(p0, invoke<BOOL>(0xAD1720, p0, invoke<int>(0xAD1860, p0, invoke<float>(0xAD1890, invoke<BOOL>(0xAD18C0, p0, p1, p2)
    return Velora.invoke(0xAD18F0, "bool", p0, invoke<BOOL>(0xAD1720, p0, invoke<int>(0xAD1860, p0, invoke<float>(0xAD1890, invoke<BOOL>(0xAD18C0, p0, p1, p2)
end

function LEADERBOARDS_WRITE_ADD_COLUMN_LONG(p0, p1, p2)
    Velora.invoke(0xAD1910, "void", p0, p1, p2)
end

function LEADERBOARDS_CACHE_DATA_ROW(invoke<BOOL>(0xAD1930, LEADERBOARDS_CLEAR_CACHE_DATA()
    return Velora.invoke(0xAD1960, "bool", invoke<BOOL>(0xAD1930, LEADERBOARDS_CLEAR_CACHE_DATA()
end

function LEADERBOARDS_CLEAR_CACHE_DATA_ID(p0)
    Velora.invoke(0xAD1980, "void", p0)
end

function LEADERBOARDS_GET_CACHE_EXISTS(invoke<BOOL>(0xAD19A0, invoke<int>(0xAD1A00, invoke<int>(0xAD1A60, p0, p1, invoke<BOOL>(0xAD1AA0, statHash, value, p2)
    return Velora.invoke(0xAD1AD0, "bool", invoke<BOOL>(0xAD19A0, invoke<int>(0xAD1A00, invoke<int>(0xAD1A60, p0, p1, invoke<BOOL>(0xAD1AA0, statHash, value, p2)
end

function PRESENCE_EVENT_UPDATESTAT_FLOAT(statHash, value, p2)
    Velora.invoke(0xAD1AF0, "void", statHash, value, p2)
end

function PRESENCE_EVENT_UPDATESTAT_INT_WITH_STRING(statHash, value, p2, string)
    Velora.invoke(0xAD1B10, "void", statHash, value, p2, string)
end

function GET_PLAYER_HAS_DRIVEN_ALL_VEHICLES(SET_HAS_POSTED_ALL_VEHICLES_DRIVEN()
    return Velora.invoke(0xAD1B80, "bool", SET_HAS_POSTED_ALL_VEHICLES_DRIVEN()
end

function SET_PROFILE_SETTING_PROLOGUE_COMPLETE()
    Velora.invoke(0xAD1BD0, "void")
end

function SET_PROFILE_SETTING_SP_CHOP_MISSION_COMPLETE()
    Velora.invoke(0xAD1C20, "void")
end

function SET_PROFILE_SETTING_CREATOR_RACES_DONE(value)
    Velora.invoke(0xAD1C70, "void", value)
end

function SET_PROFILE_SETTING_CREATOR_DM_DONE(value)
    Velora.invoke(0xAD1CD0, "void", value)
end

function SET_PROFILE_SETTING_CREATOR_CTF_DONE(value)
    Velora.invoke(0xAD1D30, "void", value)
end

function SET_JOB_ACTIVITY_ID_STARTED(p0, characterSlot)
    Velora.invoke(0xAD1D90, "void", p0, characterSlot)
end

function SET_FREEMODE_PROLOGUE_DONE(p0, characterSlot)
    Velora.invoke(0xAD1DA0, "void", p0, characterSlot)
end

function SET_FREEMODE_STRAND_PROGRESSION_STATUS(profileSetting, settingValue)
    Velora.invoke(0xAD1DB0, "void", profileSetting, settingValue)
end

function STAT_NETWORK_INCREMENT_ON_SUICIDE(p0, p1)
    Velora.invoke(0xAD1E00, "void", p0, p1)
end

function STAT_SET_CHEAT_IS_ACTIVE()
    Velora.invoke(0xAD1E80, "void")
end

function LEADERBOARDS2_WRITE_DATA_FOR_EVENT_TYPE(p0, invoke<BOOL>(0xAD1EA0, FORCE_CLOUD_MP_STATS_DOWNLOAD_AND_OVERWRITE_LOCAL_SAVE()
    return Velora.invoke(0xAD1ED0, "bool", p0, invoke<BOOL>(0xAD1EA0, FORCE_CLOUD_MP_STATS_DOWNLOAD_AND_OVERWRITE_LOCAL_SAVE()
end

function STAT_MIGRATE_CLEAR_FOR_RESTART()
    Velora.invoke(0xAD1F20, "void")
end

function STAT_MIGRATE_SAVEGAME_START(invoke<BOOL>(0xAD1F30, invoke<int>(0xAD1F70, p0, invoke<int>(0xAD1F80, invoke<int>(0xAD1F90, contentId, srcPlatform, invoke<BOOL>(0xAD1FC0, invoke<int>(0xAD1FD0, STAT_ENABLE_STATS_TRACKING()
    return Velora.invoke(0xAD1FE0, "bool", invoke<BOOL>(0xAD1F30, invoke<int>(0xAD1F70, p0, invoke<int>(0xAD1F80, invoke<int>(0xAD1F90, contentId, srcPlatform, invoke<BOOL>(0xAD1FC0, invoke<int>(0xAD1FD0, STAT_ENABLE_STATS_TRACKING()
end

function STAT_DISABLE_STATS_TRACKING()
    Velora.invoke(0xAD1FF0, "void")
end

function STAT_IS_STATS_TRACKING_ENABLED(statType, invoke<BOOL>(0xAD2020, invoke<BOOL>(0xAD20A0, invoke<BOOL>(0xAD2220, value)
    return Velora.invoke(0xAD22A0, "bool", statType, invoke<BOOL>(0xAD2020, invoke<BOOL>(0xAD20A0, invoke<BOOL>(0xAD2220, value)
end

function SET_SAVE_MIGRATION_TRANSACTION_ID_WARNING(transactionId)
    Velora.invoke(0xAD22E0, "void", transactionId)
end

function GET_BOSS_GOON_UUID(characterSlot, p1, p2)
    Velora.invoke(0xAD2320, "void", characterSlot, p1, p2)
end

function PLAYSTATS_BW_BOSSONBOSSDEATHMATCH(p0)
    Velora.invoke(0xAD2390, "void", p0)
end

function PLAYSTATS_BW_YATCHATTACK(p0)
    Velora.invoke(0xAD23A0, "void", p0)
end

function PLAYSTATS_BW_HUNT_THE_BOSS(p0)
    Velora.invoke(0xAD23B0, "void", p0)
end

function PLAYSTATS_BW_SIGHTSEER(p0)
    Velora.invoke(0xAD23C0, "void", p0)
end

function PLAYSTATS_BW_ASSAULT(p0)
    Velora.invoke(0xAD23D0, "void", p0)
end

function PLAYSTATS_BW_BELLY_OF_THE_BEAST(p0)
    Velora.invoke(0xAD23E0, "void", p0)
end

function PLAYSTATS_BW_HEAD_HUNTER(p0)
    Velora.invoke(0xAD23F0, "void", p0)
end

function PLAYSTATS_BW_FRAGILE_GOODS(p0)
    Velora.invoke(0xAD2400, "void", p0)
end

function PLAYSTATS_BW_AIR_FREIGHT(p0)
    Velora.invoke(0xAD2410, "void", p0)
end

function PLAYSTATS_BC_CAR_JACKING(p0)
    Velora.invoke(0xAD2420, "void", p0)
end

function PLAYSTATS_BC_SMASH_AND_GRAB(p0)
    Velora.invoke(0xAD2430, "void", p0)
end

function PLAYSTATS_BC_PROTECTION_RACKET(p0)
    Velora.invoke(0xAD2440, "void", p0)
end

function PLAYSTATS_BC_MOST_WANTED(p0)
    Velora.invoke(0xAD2450, "void", p0)
end

function PLAYSTATS_BC_FINDERS_KEEPERS(p0)
    Velora.invoke(0xAD2460, "void", p0)
end

function PLAYSTATS_BC_POINT_TO_POINT(p0)
    Velora.invoke(0xAD2470, "void", p0)
end

function PLAYSTATS_BC_CASHING(p0)
    Velora.invoke(0xAD2480, "void", p0)
end

function PLAYSTATS_BC_SALVAGE(p0)
    Velora.invoke(0xAD2490, "void", p0)
end

function PLAYSTATS_SPENT_PI_CUSTOM_LOADOUT(amount)
    Velora.invoke(0xAD24A0, "void", amount)
end

function PLAYSTATS_BUY_CONTRABAND_MISSION(data)
    Velora.invoke(0xAD2570, "void", data)
end

function PLAYSTATS_SELL_CONTRABAND_MISSION(data)
    Velora.invoke(0xAD2580, "void", data)
end

function PLAYSTATS_DEFEND_CONTRABAND_MISSION(data)
    Velora.invoke(0xAD2590, "void", data)
end

function PLAYSTATS_RECOVER_CONTRABAND_MISSION(data)
    Velora.invoke(0xAD25A0, "void", data)
end

function PLAYSTATS_HIT_CONTRABAND_DESTROY_LIMIT(p0)
    Velora.invoke(0xAD25B0, "void", p0)
end

function START_BEING_BOSS(p0)
    Velora.invoke(0xAD2640, "void", p0)
end

function START_BEING_GOON(p0, p1, p2)
    Velora.invoke(0xAD2660, "void", p0, p1, p2)
end

function END_BEING_BOSS(p0, p1)
    Velora.invoke(0xAD26F0, "void", p0, p1)
end

function END_BEING_GOON(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD2710, "void", p0, p1, p2, p3, p4)
end

function HIRED_LIMO(p0, p1)
    Velora.invoke(0xAD2730, "void", p0, p1)
end

function ORDER_BOSS_VEHICLE(p0, p1, vehicleHash)
    Velora.invoke(0xAD27B0, "void", p0, p1, vehicleHash)
end

function CHANGE_UNIFORM(p0, p1, p2)
    Velora.invoke(0xAD2860, "void", p0, p1, p2)
end

function CHANGE_GOON_LOOKING_FOR_WORK(p0)
    Velora.invoke(0xAD28F0, "void", p0)
end

function SEND_METRIC_GHOSTING_TO_PLAYER(p0)
    Velora.invoke(0xAD2910, "void", p0)
end

function SEND_METRIC_VIP_POACH(p0, p1, p2)
    Velora.invoke(0xAD2920, "void", p0, p1, p2)
end

function SEND_METRIC_PUNISH_BODYGUARD(p0)
    Velora.invoke(0xAD29F0, "void", p0)
end

function PLAYSTATS_START_TRACKING_STUNTS()
    Velora.invoke(0xAD2AA0, "void")
end

function PLAYSTATS_STOP_TRACKING_STUNTS()
    Velora.invoke(0xAD2AB0, "void")
end

function PLAYSTATS_MISSION_ENDED(p0)
    Velora.invoke(0xAD2AC0, "void", p0)
end

function PLAYSTATS_IMPEXP_MISSION_ENDED(p0)
    Velora.invoke(0xAD2AD0, "void", p0)
end

function PLAYSTATS_CHANGE_MC_ROLE(p0, p1, p2, p3, role, p5, p6)
    Velora.invoke(0xAD2AE0, "void", p0, p1, p2, p3, role, p5, p6)
end

function PLAYSTATS_CHANGE_MC_OUTFIT(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD2B10, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_SWITCH_MC_EMBLEM(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD2B30, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_MC_REQUEST_BIKE(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD2B50, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_MC_KILLED_RIVAL_MC_MEMBER(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD2B70, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_ABANDONED_MC(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD2B90, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_EARNED_MC_POINTS(p0, p1, p2, p3, p4, p5)
    Velora.invoke(0xAD2BB0, "void", p0, p1, p2, p3, p4, p5)
end

function PLAYSTATS_MC_FORMATION_ENDS(p0, p1, p2, p3, p4, p5, p6)
    Velora.invoke(0xAD2BD0, "void", p0, p1, p2, p3, p4, p5, p6)
end

function PLAYSTATS_MC_CLUBHOUSE_ACTIVITY(p0, p1, p2, p3, p4, p5, p6, p7)
    Velora.invoke(0xAD2C00, "void", p0, p1, p2, p3, p4, p5, p6, p7)
end

function PLAYSTATS_RIVAL_BEHAVIOR(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)
    Velora.invoke(0xAD2C40, "void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)
end

function PLAYSTATS_COPY_RANK_INTO_NEW_SLOT(p0, p1, p2, p3, p4, p5, p6)
    Velora.invoke(0xAD2D70, "void", p0, p1, p2, p3, p4, p5, p6)
end

function PLAYSTATS_DUPE_DETECTED(data)
    Velora.invoke(0xAD2E30, "void", data)
end

function PLAYSTATS_BAN_ALERT(p0)
    Velora.invoke(0xAD2EF0, "void", p0)
end

function PLAYSTATS_GUNRUNNING_MISSION_ENDED(data)
    Velora.invoke(0xAD2F60, "void", data)
end

function PLAYSTATS_GUNRUNNING_RND(p0)
    Velora.invoke(0xAD2F70, "void", p0)
end

function PLAYSTATS_BUSINESS_BATTLE_ENDED(p0)
    Velora.invoke(0xAD3040, "void", p0)
end

function PLAYSTATS_WAREHOUSE_MISSION_ENDED(p0)
    Velora.invoke(0xAD3050, "void", p0)
end

function PLAYSTATS_NIGHTCLUB_MISSION_ENDED(p0)
    Velora.invoke(0xAD3060, "void", p0)
end

function PLAYSTATS_DJ_USAGE(p0, p1)
    Velora.invoke(0xAD3070, "void", p0, p1)
end

function PLAYSTATS_MINIGAME_USAGE(p0, p1, p2)
    Velora.invoke(0xAD3100, "void", p0, p1, p2)
end

function PLAYSTATS_STONE_HATCHET_ENDED(data)
    Velora.invoke(0xAD31A0, "void", data)
end

function PLAYSTATS_SMUGGLER_MISSION_ENDED(data)
    Velora.invoke(0xAD31B0, "void", data)
end

function PLAYSTATS_FM_HEIST_PREP_ENDED(data)
    Velora.invoke(0xAD31C0, "void", data)
end

function PLAYSTATS_INSTANCED_HEIST_ENDED(data, p1, p2, p3)
    Velora.invoke(0xAD31D0, "void", data, p1, p2, p3)
end

function PLAYSTATS_DAR_CHECKPOINT(data)
    Velora.invoke(0xAD31F0, "void", data)
end

function PLAYSTATS_ENTER_SESSION_PACK(data)
    Velora.invoke(0xAD3200, "void", data)
end

function PLAYSTATS_DRONE_USAGE(p0, p1, p2)
    Velora.invoke(0xAD3210, "void", p0, p1, p2)
end

function PLAYSTATS_SPIN_WHEEL(p0, p1, p2, p3)
    Velora.invoke(0xAD32B0, "void", p0, p1, p2, p3)
end

function PLAYSTATS_ARENA_WARS_SPECTATOR(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD3370, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_ARENA_WARS_ENDED(data)
    Velora.invoke(0xAD3430, "void", data)
end

function PLAYSTATS_SWITCH_PASSIVE_MODE(p0, p1, p2, p3)
    Velora.invoke(0xAD3440, "void", p0, p1, p2, p3)
end

function PLAYSTATS_COLLECTIBLE_PICKED_UP(p0, objectHash, p2, p3, moneyAmount, rpAmount, chipsAmount, p7, p8, p9, p10)
    Velora.invoke(0xAD34E0, "void", p0, objectHash, p2, p3, moneyAmount, rpAmount, chipsAmount, p7, p8, p9, p10)
end

function PLAYSTATS_CASINO_STORY_MISSION_ENDED(p0, p1)
    Velora.invoke(0xAD3600, "void", p0, p1)
end

function PLAYSTATS_CASINO_CHIP(p0)
    Velora.invoke(0xAD3670, "void", p0)
end

function PLAYSTATS_CASINO_ROULETTE(p0)
    Velora.invoke(0xAD3730, "void", p0)
end

function PLAYSTATS_CASINO_BLACKJACK(p0)
    Velora.invoke(0xAD3740, "void", p0)
end

function PLAYSTATS_CASINO_THREE_CARD_POKER(p0)
    Velora.invoke(0xAD3750, "void", p0)
end

function PLAYSTATS_CASINO_SLOT_MACHINE(p0)
    Velora.invoke(0xAD38A0, "void", p0)
end

function PLAYSTATS_CASINO_INSIDE_TRACK(p0)
    Velora.invoke(0xAD39E0, "void", p0)
end

function PLAYSTATS_CASINO_LUCKY_SEVEN(p0)
    Velora.invoke(0xAD3B20, "void", p0)
end

function PLAYSTATS_CASINO_ROULETTE_LIGHT(p0)
    Velora.invoke(0xAD3C70, "void", p0)
end

function PLAYSTATS_CASINO_BLACKJACK_LIGHT(p0)
    Velora.invoke(0xAD3D50, "void", p0)
end

function PLAYSTATS_CASINO_THREE_CARD_POKER_LIGHT(p0)
    Velora.invoke(0xAD3E70, "void", p0)
end

function PLAYSTATS_CASINO_SLOT_MACHINE_LIGHT(p0)
    Velora.invoke(0xAD3F50, "void", p0)
end

function PLAYSTATS_CASINO_INSIDE_TRACK_LIGHT(p0)
    Velora.invoke(0xAD4040, "void", p0)
end

function PLAYSTATS_ARCADE_GAME(p0, p1, p2, p3, p4, p5, p6)
    Velora.invoke(0xAD4130, "void", p0, p1, p2, p3, p4, p5, p6)
end

function PLAYSTATS_ARCADE_LOVE_MATCH(p0, p1)
    Velora.invoke(0xAD41F0, "void", p0, p1)
end

function PLAYSTATS_FREEMODE_CASINO_MISSION_ENDED(data)
    Velora.invoke(0xAD4290, "void", data)
end

function PLAYSTATS_HEIST3_DRONE(p0)
    Velora.invoke(0xAD42A0, "void", p0)
end

function PLAYSTATS_HEIST3_HACK(p0, p1, p2, p3, p4, p5)
    Velora.invoke(0xAD4340, "void", p0, p1, p2, p3, p4, p5)
end

function PLAYSTATS_NPC_PHONE(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)
    Velora.invoke(0xAD43F0, "void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)
end

function PLAYSTATS_ARCADE_CABINET(p0)
    Velora.invoke(0xAD4400, "void", p0)
end

function PLAYSTATS_HEIST3_FINALE(p0)
    Velora.invoke(0xAD44B0, "void", p0)
end

function PLAYSTATS_HEIST3_PREP(p0)
    Velora.invoke(0xAD4510, "void", p0)
end

function PLAYSTATS_MASTER_CONTROL(p0, p1, p2, p3)
    Velora.invoke(0xAD4570, "void", p0, p1, p2, p3)
end

function PLAYSTATS_QUIT_MODE(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD4610, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_MISSION_VOTE(p0)
    Velora.invoke(0xAD4700, "void", p0)
end

function PLAYSTATS_NJVS_VOTE(p0)
    Velora.invoke(0xAD4710, "void", p0)
end

function PLAYSTATS_KILL_YOURSELF()
    Velora.invoke(0xDEADBEEF, "void")
end

function PLAYSTATS_FM_MISSION_END(p0, p1, p2)
    Velora.invoke(0xAD4830, "void", p0, p1, p2)
end

function PLAYSTATS_HEIST4_PREP(p0)
    Velora.invoke(0xAD4850, "void", p0)
end

function PLAYSTATS_HEIST4_FINALE(p0)
    Velora.invoke(0xAD48B0, "void", p0)
end

function PLAYSTATS_HEIST4_HACK(p0, p1, p2, p3, p4)
    Velora.invoke(0xAD4910, "void", p0, p1, p2, p3, p4)
end

function PLAYSTATS_SUB_WEAP(p0, p1, p2, p3)
    Velora.invoke(0xAD49C0, "void", p0, p1, p2, p3)
end

function PLAYSTATS_FAST_TRVL(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
    Velora.invoke(0xAD4A60, "void", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
end

function PLAYSTATS_HUB_ENTRY(p0)
    Velora.invoke(0xAD4BA0, "void", p0)
end

function PLAYSTATS_DJ_MISSION_ENDED(p0)
    Velora.invoke(0xAD4C70, "void", p0)
end

function PLAYSTATS_ROBBERY_PREP(p0)
    Velora.invoke(0xAD4C80, "void", p0)
end

function PLAYSTATS_ROBBERY_FINALE(p0)
    Velora.invoke(0xAD4CE0, "void", p0)
end

function PLAYSTATS_EXTRA_EVENT(p0)
    Velora.invoke(0xAD4D40, "void", p0)
end

function PLAYSTATS_CARCLUB_POINTS(p0)
    Velora.invoke(0xAD4DE0, "void", p0)
end

function PLAYSTATS_CARCLUB_CHALLENGE(p0, p1, p2, p3)
    Velora.invoke(0xAD4ED0, "void", p0, p1, p2, p3)
end

function PLAYSTATS_CARCLUB_PRIZE(p0, vehicleModel)
    Velora.invoke(0xAD4F70, "void", p0, vehicleModel)
end

function PLAYSTATS_AWARD_NAV(p0, p1, p2, p3)
    Velora.invoke(0xAD4FF0, "void", p0, p1, p2, p3)
end

function PLAYSTATS_INST_MISSION_END(p0)
    Velora.invoke(0xAD5120, "void", p0)
end

function PLAYSTATS_HUB_EXIT(p0)
    Velora.invoke(0xAD5180, "void", p0)
end

function PLAYSTATS_INVENTORY(p0)
    Velora.invoke(0xAD5320, "void", p0)
end

function _PLAYSTATS_ACID_MISSION_END(p0)
    Velora.invoke(0xAD53D0, "void", p0)
end

function _PLAYSTATS_ACID_RND(p0)
    Velora.invoke(0xAD5430, "void", p0)
end

function _PLAYSTATS_IDLE(p0, p1, p2)
    Velora.invoke(0xAD5500, "void", p0, p1, p2)
end

function _PLAYSTATS_PLAYER_STYLE(p0)
    Velora.invoke(0xAD55D0, "void", p0)
end

function LOAD_ALL_OBJECTS_NOW()
    Velora.invoke(0xAD9170, "void")
end

function LOAD_SCENE(x, y, z)
    Velora.invoke(0xAD9190, "void", x, y, z)
end

function NETWORK_UPDATE_LOAD_SCENE(interiorID, toggle)
    return Velora.invoke(0xAD9260, "bool", interiorID, toggle)
end

function REQUEST_MODEL(model)
    Velora.invoke(0xAD9290, "void", model)
end

function REQUEST_MENU_PED_MODEL(model)
    Velora.invoke(0xAD92A0, "void", model)
end

function HAS_MODEL_LOADED(invoke<BOOL>(0xAD92C0, interior, roomName)
    return Velora.invoke(0xAD9380, "bool", invoke<BOOL>(0xAD92C0, interior, roomName)
end

function SET_MODEL_AS_NO_LONGER_NEEDED(model)
    Velora.invoke(0xAD9400, "void", model)
end

function IS_MODEL_IN_CDIMAGE(invoke<BOOL>(0xAD9480, invoke<BOOL>(0xAD94F0, invoke<BOOL>(0xAD9560, invoke<BOOL>(0xAD95D0, x, y, z)
    return Velora.invoke(0xAD9640, "bool", invoke<BOOL>(0xAD9480, invoke<BOOL>(0xAD94F0, invoke<BOOL>(0xAD9560, invoke<BOOL>(0xAD95D0, x, y, z)
end

function REQUEST_COLLISION_FOR_MODEL(model)
    Velora.invoke(0xAD9680, "void", model)
end

function HAS_COLLISION_FOR_MODEL_LOADED(invoke<BOOL>(0xAD9690, x, y, z)
    return Velora.invoke(0xAD9730, "bool", invoke<BOOL>(0xAD9690, x, y, z)
end

function DOES_ANIM_DICT_EXIST(invoke<BOOL>(0xAD9770, animDict)
    return Velora.invoke(0xAD97D0, "bool", invoke<BOOL>(0xAD9770, animDict)
end

function HAS_ANIM_DICT_LOADED(invoke<BOOL>(0xAD97E0, animDict)
    return Velora.invoke(0xAD9860, "bool", invoke<BOOL>(0xAD97E0, animDict)
end

function REQUEST_ANIM_SET(animSet)
    Velora.invoke(0xAD98E0, "void", animSet)
end

function HAS_ANIM_SET_LOADED(invoke<BOOL>(0xAD98F0, animSet)
    return Velora.invoke(0xAD9980, "bool", invoke<BOOL>(0xAD98F0, animSet)
end

function REQUEST_CLIP_SET(clipSet)
    Velora.invoke(0xAD9A10, "void", clipSet)
end

function HAS_CLIP_SET_LOADED(invoke<BOOL>(0xAD9A20, clipSet)
    return Velora.invoke(0xAD9AB0, "bool", invoke<BOOL>(0xAD9A20, clipSet)
end

function REQUEST_IPL(iplName)
    Velora.invoke(0xAD9B40, "void", iplName)
end

function REMOVE_IPL(iplName)
    Velora.invoke(0xAD9BC0, "void", iplName)
end

function IS_IPL_ACTIVE(invoke<BOOL>(0xAD9BD0, toggle)
    return Velora.invoke(0xAD9C20, "bool", invoke<BOOL>(0xAD9BD0, toggle)
end

function LOAD_GLOBAL_WATER_FILE(waterType)
    Velora.invoke(0xAD9C40, "void", waterType)
end

function GET_GLOBAL_WATER_FILE(toggle)
    return Velora.invoke(0xAD9C70, "int", toggle)
end

function SET_REDUCE_PED_MODEL_BUDGET(toggle)
    Velora.invoke(0xAD9C90, "void", toggle)
end

function SET_REDUCE_VEHICLE_MODEL_BUDGET(toggle)
    Velora.invoke(0xAD9CB0, "void", toggle)
end

function SET_DITCH_POLICE_MODELS(toggle)
    Velora.invoke(0xAD9CD0, "void", toggle)
end

function GET_NUMBER_OF_STREAMING_REQUESTS(REQUEST_PTFX_ASSET()
    return Velora.invoke(0xAD9D00, "int", REQUEST_PTFX_ASSET()
end

function HAS_PTFX_ASSET_LOADED(REMOVE_PTFX_ASSET()
    return Velora.invoke(0xAD9D30, "bool", REMOVE_PTFX_ASSET()
end

function REQUEST_NAMED_PTFX_ASSET(fxName)
    Velora.invoke(0xAD9D40, "void", fxName)
end

function HAS_NAMED_PTFX_ASSET_LOADED(invoke<BOOL>(0xAD9D50, fxName)
    return Velora.invoke(0xAD9D80, "bool", invoke<BOOL>(0xAD9D50, fxName)
end

function SET_VEHICLE_POPULATION_BUDGET(p0)
    Velora.invoke(0xAD9D90, "void", p0)
end

function SET_PED_POPULATION_BUDGET(p0)
    Velora.invoke(0xAD9DB0, "void", p0)
end

function CLEAR_FOCUS()
    Velora.invoke(0xAD9DD0, "void")
end

function SET_FOCUS_POS_AND_VEL(x, y, z, offsetX, offsetY, offsetZ)
    Velora.invoke(0xAD9DE0, "void", x, y, z, offsetX, offsetY, offsetZ)
end

function SET_FOCUS_ENTITY(entity)
    Velora.invoke(0xAD9E50, "void", entity)
end

function IS_ENTITY_FOCUS(invoke<BOOL>(0xAD9ED0, p0)
    return Velora.invoke(0xAD9F30, "bool", invoke<BOOL>(0xAD9ED0, p0)
end

function SET_MAPDATACULLBOX_ENABLED(name, toggle)
    Velora.invoke(0xAD9FB0, "void", name, toggle)
end

function SET_ALL_MAPDATA_CULLED(p0)
    Velora.invoke(0xAD9FD0, "void", p0)
end

function STREAMVOL_CREATE_SPHERE(x, y, z, rad, p4, invoke<int>(0xAD9FE0, p0, p1, p2, p3, p4, p5, p6, p7, invoke<int>(0xADA0E0, p0, p1, p2, p3, p4, p5, invoke<int>(0xADA1C0, unused)
    return Velora.invoke(0xADA270, "int", x, y, z, rad, p4, invoke<int>(0xAD9FE0, p0, p1, p2, p3, p4, p5, p6, p7, invoke<int>(0xADA0E0, p0, p1, p2, p3, p4, p5, invoke<int>(0xADA1C0, unused)
end

function STREAMVOL_HAS_LOADED(invoke<BOOL>(0xADA290, invoke<BOOL>(0xADA2C0, posX, posY, posZ, offsetX, offsetY, offsetZ, radius, invoke<BOOL>(0xADA2E0, x, y, z, radius, invoke<BOOL>(0xADA390, NEW_LOAD_SCENE_STOP()
    return Velora.invoke(0xADA420, "bool", invoke<BOOL>(0xADA290, invoke<BOOL>(0xADA2C0, posX, posY, posZ, offsetX, offsetY, offsetZ, radius, invoke<BOOL>(0xADA2E0, x, y, z, radius, invoke<BOOL>(0xADA390, NEW_LOAD_SCENE_STOP()
end

function IS_NEW_LOAD_SCENE_ACTIVE(from, to, flags, switchType)
    return Velora.invoke(0xADA4D0, "bool", from, to, flags, switchType)
end

function STOP_PLAYER_SWITCH()
    Velora.invoke(0xADA590, "void")
end

function IS_PLAYER_SWITCH_IN_PROGRESS(x1, y1, z1, x2, y2, invoke<int>(0xADA600, p0)
    return Velora.invoke(0xADA6A0, "bool", x1, y1, z1, x2, y2, invoke<int>(0xADA600, p0)
end

function GET_PLAYER_SWITCH_JUMP_CUT_INDEX(cameraCoordX, cameraCoordY, cameraCoordZ, camRotationX, camRotationY, camRotationZ, camFov, camFarClip, rotationOrder)
    return Velora.invoke(0xADA6E0, "int", cameraCoordX, cameraCoordY, cameraCoordZ, camRotationX, camRotationY, camRotationZ, camFov, camFarClip, rotationOrder)
end

function SET_PLAYER_SWITCH_ESTABLISHING_SHOT(name)
    Velora.invoke(0xADA7D0, "void", name)
end

function ALLOW_PLAYER_SWITCH_PAN()
    Velora.invoke(0xADA830, "void")
end

function ALLOW_PLAYER_SWITCH_OUTRO()
    Velora.invoke(0xADA870, "void")
end

function ALLOW_PLAYER_SWITCH_ASCENT()
    Velora.invoke(0xADA8B0, "void")
end

function ALLOW_PLAYER_SWITCH_DESCENT()
    Velora.invoke(0xADA8F0, "void")
end

function IS_SWITCH_READY_FOR_DESCENT(ENABLE_SWITCH_PAUSE_BEFORE_DESCENT()
    return Velora.invoke(0xADA970, "bool", ENABLE_SWITCH_PAUSE_BEFORE_DESCENT()
end

function DISABLE_SWITCH_OUTRO_FX()
    Velora.invoke(0xADA9B0, "void")
end

function SWITCH_TO_MULTI_FIRSTPART(ped, flags, switchType)
    Velora.invoke(0xADAA00, "void", ped, flags, switchType)
end

function SWITCH_TO_MULTI_SECONDPART(ped)
    Velora.invoke(0xADAA80, "void", ped)
end

function IS_SWITCH_TO_MULTI_FIRSTPART_FINISHED(SET_SCENE_STREAMING_TRACKS_CAM_POS_THIS_FRAME()
    return Velora.invoke(0xADABA0, "bool", SET_SCENE_STREAMING_TRACKS_CAM_POS_THIS_FRAME()
end

function GET_LODSCALE(scaling)
    return Velora.invoke(0xADABD0, "float", scaling)
end

function REMAP_LODSCALE_RANGE_THIS_FRAME(p0, p1, p2, p3)
    Velora.invoke(0xADABF0, "void", p0, p1, p2, p3)
end

function SUPPRESS_HD_MAP_STREAMING_THIS_FRAME()
    Velora.invoke(0xADAC20, "void")
end

function SET_RENDER_HD_ONLY(toggle)
    Velora.invoke(0xADAC30, "void", toggle)
end

function FORCE_ALLOW_TIME_BASED_FADING_THIS_FRAME()
    Velora.invoke(0xADAC70, "void")
end

function IPL_GROUP_SWAP_START(iplName1, iplName2)
    Velora.invoke(0xADAC80, "void", iplName1, iplName2)
end

function IPL_GROUP_SWAP_CANCEL()
    Velora.invoke(0xADAC90, "void")
end

function IPL_GROUP_SWAP_IS_READY(IPL_GROUP_SWAP_FINISH()
    return Velora.invoke(0xADACE0, "bool", IPL_GROUP_SWAP_FINISH()
end

function IPL_GROUP_SWAP_IS_ACTIVE(srl)
    return Velora.invoke(0xADAD20, "bool", srl)
end

function IS_SRL_LOADED(BEGIN_SRL()
    return Velora.invoke(0xADAD70, "bool", BEGIN_SRL()
end

function END_SRL()
    Velora.invoke(0xADAD80, "void")
end

function SET_SRL_TIME(p0)
    Velora.invoke(0xADAD90, "void", p0)
end

function SET_SRL_POST_CUTSCENE_CAMERA(p0, p1, p2, p3, p4, p5)
    Velora.invoke(0xADADB0, "void", p0, p1, p2, p3, p4, p5)
end

function SET_SRL_READAHEAD_TIMES(p0, p1, p2, p3)
    Velora.invoke(0xADAE00, "void", p0, p1, p2, p3)
end

function SET_SRL_LONG_JUMP_MODE(p0)
    Velora.invoke(0xADAE20, "void", p0)
end

function SET_SRL_FORCE_PRESTREAM(p0)
    Velora.invoke(0xADAE40, "void", p0)
end

function SET_HD_AREA(x, y, z, radius)
    Velora.invoke(0xADAE60, "void", x, y, z, radius)
end

function CLEAR_HD_AREA()
    Velora.invoke(0xADAEB0, "void")
end

function INIT_CREATOR_BUDGET()
    Velora.invoke(0xADAEC0, "void")
end

function SHUTDOWN_CREATOR_BUDGET()
    Velora.invoke(0xADAED0, "void")
end

function ADD_MODEL_TO_CREATOR_BUDGET(invoke<BOOL>(0xADAEE0, modelHash)
    return Velora.invoke(0xADAF90, "bool", invoke<BOOL>(0xADAEE0, modelHash)
end

function GET_USED_CREATOR_BUDGET(name, toggle)
    return Velora.invoke(0xADB100, "float", name, toggle)
end

function TASK_PAUSE(ped, ms)
    Velora.invoke(0xAF1EE0, "void", ped, ms)
end

function TASK_STAND_STILL(ped, time)
    Velora.invoke(0xAF1F50, "void", ped, time)
end

function TASK_JUMP(ped, usePlayerLaunchForce, doSuperJump, useFullSuperJumpForce)
    Velora.invoke(0xAF1FE0, "void", ped, usePlayerLaunchForce, doSuperJump, useFullSuperJumpForce)
end

function TASK_COWER(ped, duration)
    Velora.invoke(0xAF2060, "void", ped, duration)
end

function TASK_HANDS_UP(ped, duration, facingPed, timeToFacePed, flags)
    Velora.invoke(0xAF20E0, "void", ped, duration, facingPed, timeToFacePed, flags)
end

function UPDATE_TASK_HANDS_UP_DURATION(ped, duration)
    Velora.invoke(0xAF21B0, "void", ped, duration)
end

function TASK_OPEN_VEHICLE_DOOR(ped, vehicle, timeOut, seat, speed)
    Velora.invoke(0xAF2210, "void", ped, vehicle, timeOut, seat, speed)
end

function TASK_ENTER_VEHICLE(ped, vehicle, timeout, seat, speed, flag, overrideEntryClipsetName)
    Velora.invoke(0xAF2230, "void", ped, vehicle, timeout, seat, speed, flag, overrideEntryClipsetName)
end

function TASK_LEAVE_VEHICLE(ped, vehicle, flags)
    Velora.invoke(0xAF2260, "void", ped, vehicle, flags)
end

function TASK_GET_OFF_BOAT(ped, boat)
    Velora.invoke(0xAF2280, "void", ped, boat)
end

function TASK_SKY_DIVE(ped, instant)
    Velora.invoke(0xAF2300, "void", ped, instant)
end

function TASK_PARACHUTE(ped, giveParachuteItem, instant)
    Velora.invoke(0xAF2320, "void", ped, giveParachuteItem, instant)
end

function TASK_PARACHUTE_TO_TARGET(ped, x, y, z)
    Velora.invoke(0xAF23A0, "void", ped, x, y, z)
end

function SET_PARACHUTE_TASK_TARGET(ped, x, y, z)
    Velora.invoke(0xAF2430, "void", ped, x, y, z)
end

function SET_PARACHUTE_TASK_THRUST(ped, thrust)
    Velora.invoke(0xAF24B0, "void", ped, thrust)
end

function TASK_RAPPEL_FROM_HELI(ped, minHeightAboveGround)
    Velora.invoke(0xAF2520, "void", ped, minHeightAboveGround)
end

function TASK_VEHICLE_DRIVE_TO_COORD(ped, vehicle, x, y, z, speed, p6, vehicleModel, drivingMode, stopRange, straightLineDistance)
    Velora.invoke(0xAF25A0, "void", ped, vehicle, x, y, z, speed, p6, vehicleModel, drivingMode, stopRange, straightLineDistance)
end

function TASK_VEHICLE_DRIVE_TO_COORD_LONGRANGE(ped, vehicle, x, y, z, speed, driveMode, stopRange)
    Velora.invoke(0xAF2620, "void", ped, vehicle, x, y, z, speed, driveMode, stopRange)
end

function TASK_VEHICLE_DRIVE_WANDER(ped, vehicle, speed, drivingStyle)
    Velora.invoke(0xAF2640, "void", ped, vehicle, speed, drivingStyle)
end

function TASK_FOLLOW_TO_OFFSET_OF_ENTITY(ped, entity, offsetX, offsetY, offsetZ, movementSpeed, timeout, stoppingRange, persistFollowing)
    Velora.invoke(0xAF2710, "void", ped, entity, offsetX, offsetY, offsetZ, movementSpeed, timeout, stoppingRange, persistFollowing)
end

function TASK_GO_STRAIGHT_TO_COORD(ped, x, y, z, speed, timeout, targetHeading, distanceToSlide)
    Velora.invoke(0xAF2740, "void", ped, x, y, z, speed, timeout, targetHeading, distanceToSlide)
end

function TASK_GO_STRAIGHT_TO_COORD_RELATIVE_TO_ENTITY(ped, entity, x, y, z, moveBlendRatio, time)
    Velora.invoke(0xAF2770, "void", ped, entity, x, y, z, moveBlendRatio, time)
end

function TASK_ACHIEVE_HEADING(ped, heading, timeout)
    Velora.invoke(0xAF2790, "void", ped, heading, timeout)
end

function TASK_FLUSH_ROUTE()
    Velora.invoke(0xAF27B0, "void")
end

function TASK_EXTEND_ROUTE(x, y, z)
    Velora.invoke(0xAF27C0, "void", x, y, z)
end

function TASK_FOLLOW_POINT_ROUTE(ped, speed, mode)
    Velora.invoke(0xAF2800, "void", ped, speed, mode)
end

function TASK_GO_TO_ENTITY(entity, target, duration, distance, moveBlendRatio, slowDownDistance, flags)
    Velora.invoke(0xAF2820, "void", entity, target, duration, distance, moveBlendRatio, slowDownDistance, flags)
end

function TASK_SMART_FLEE_COORD(ped, x, y, z, distance, time, preferPavements, quitIfOutOfRange)
    Velora.invoke(0xAF2850, "void", ped, x, y, z, distance, time, preferPavements, quitIfOutOfRange)
end

function TASK_SMART_FLEE_PED(ped, fleeTarget, safeDistance, fleeTime, preferPavements, updateToNearestHatedPed)
    Velora.invoke(0xAF2880, "void", ped, fleeTarget, safeDistance, fleeTime, preferPavements, updateToNearestHatedPed)
end

function TASK_REACT_AND_FLEE_PED(ped, fleeTarget)
    Velora.invoke(0xAF28B0, "void", ped, fleeTarget)
end

function TASK_SHOCKING_EVENT_REACT(ped, eventHandle)
    Velora.invoke(0xAF28C0, "void", ped, eventHandle)
end

function TASK_WANDER_IN_AREA(ped, x, y, z, radius, minimalLength, timeBetweenWalks)
    Velora.invoke(0xAF28D0, "void", ped, x, y, z, radius, minimalLength, timeBetweenWalks)
end

function TASK_WANDER_STANDARD(ped, heading, flags)
    Velora.invoke(0xAF29E0, "void", ped, heading, flags)
end

function TASK_WANDER_SPECIFIC(ped, conditionalAnimGroupStr, conditionalAnimStr, heading)
    Velora.invoke(0xAF2A00, "void", ped, conditionalAnimGroupStr, conditionalAnimStr, heading)
end

function TASK_VEHICLE_PARK(ped, vehicle, x, y, z, heading, mode, radius, keepEngineOn)
    Velora.invoke(0xAF2A20, "void", ped, vehicle, x, y, z, heading, mode, radius, keepEngineOn)
end

function TASK_STEALTH_KILL(killer, target, stealthKillActionResultHash, desiredMoveBlendRatio, stealthFlags)
    Velora.invoke(0xAF2A50, "void", killer, target, stealthKillActionResultHash, desiredMoveBlendRatio, stealthFlags)
end

function TASK_PLANT_BOMB(ped, x, y, z, heading)
    Velora.invoke(0xAF2A70, "void", ped, x, y, z, heading)
end

function TASK_FOLLOW_NAV_MESH_TO_COORD(ped, x, y, z, moveBlendRatio, time, targetRadius, flags, targetHeading)
    Velora.invoke(0xAF2AB0, "void", ped, x, y, z, moveBlendRatio, time, targetRadius, flags, targetHeading)
end

function TASK_FOLLOW_NAV_MESH_TO_COORD_ADVANCED(ped, x, y, z, moveBlendRatio, time, targetRadius, flags, slideToCoordHeading, maxSlopeNavigable, clampMaxSearchDistance, targetHeading)
    Velora.invoke(0xADE430, "void", ped, x, y, z, moveBlendRatio, time, targetRadius, flags, slideToCoordHeading, maxSlopeNavigable, clampMaxSearchDistance, targetHeading)
end

function SET_PED_PATH_CAN_USE_CLIMBOVERS(ped, Toggle)
    Velora.invoke(0xAF2AE0, "void", ped, Toggle)
end

function SET_PED_PATH_CAN_USE_LADDERS(ped, Toggle)
    Velora.invoke(0xAF2B40, "void", ped, Toggle)
end

function SET_PED_PATH_CAN_DROP_FROM_HEIGHT(ped, Toggle)
    Velora.invoke(0xAF2BA0, "void", ped, Toggle)
end

function SET_PED_PATH_CLIMB_COST_MODIFIER(ped, modifier)
    Velora.invoke(0xAF2C00, "void", ped, modifier)
end

function SET_PED_PATH_MAY_ENTER_WATER(ped, mayEnterWater)
    Velora.invoke(0xAF2C70, "void", ped, mayEnterWater)
end

function SET_PED_PATH_PREFER_TO_AVOID_WATER(ped, avoidWater)
    Velora.invoke(0xAF2CD0, "void", ped, avoidWater)
end

function SET_PED_PATH_AVOID_FIRE(ped, avoidFire)
    Velora.invoke(0xAF2D30, "void", ped, avoidFire)
end

function SET_GLOBAL_MIN_BIRD_FLIGHT_HEIGHT(height)
    Velora.invoke(0xAF2D90, "void", height)
end

function GET_NAVMESH_ROUTE_DISTANCE_REMAINING(ped, distanceRemaining, invoke<int>(0xAF2DC0, invoke<int>(0xAF2EA0, invoke<BOOL>(0xAF2EC0, ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets)
    return Velora.invoke(0xAF2F40, "int", ped, distanceRemaining, invoke<int>(0xAF2DC0, invoke<int>(0xAF2EA0, invoke<BOOL>(0xAF2EC0, ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets)
end

function TASK_GO_TO_COORD_ANY_MEANS_EXTRA_PARAMS(ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets, extraVehToTargetDistToPreferVehicle, driveStraightLineDistance, extraFlags, warpTimerMS)
    Velora.invoke(0xAF2F70, "void", ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets, extraVehToTargetDistToPreferVehicle, driveStraightLineDistance, extraFlags, warpTimerMS)
end

function TASK_GO_TO_COORD_ANY_MEANS_EXTRA_PARAMS_WITH_CRUISE_SPEED(ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets, extraVehToTargetDistToPreferVehicle, driveStraightLineDistance, extraFlags, cruiseSpeed, targetArriveDist)
    Velora.invoke(0xAF2FB0, "void", ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets, extraVehToTargetDistToPreferVehicle, driveStraightLineDistance, extraFlags, cruiseSpeed, targetArriveDist)
end

function TASK_PLAY_ANIM(ped, animDictionary, animationName, blendInSpeed, blendOutSpeed, duration, flag, playbackRate, lockX, lockY, lockZ)
    Velora.invoke(0xAF3000, "void", ped, animDictionary, animationName, blendInSpeed, blendOutSpeed, duration, flag, playbackRate, lockX, lockY, lockZ)
end

function TASK_PLAY_ANIM_ADVANCED(ped, animDict, animName, posX, posY, posZ, rotX, rotY, rotZ, animEnterSpeed, animExitSpeed, duration, flag, animTime, rotOrder, ikFlags)
    Velora.invoke(0xAF3090, "void", ped, animDict, animName, posX, posY, posZ, rotX, rotY, rotZ, animEnterSpeed, animExitSpeed, duration, flag, animTime, rotOrder, ikFlags)
end

function STOP_ANIM_TASK(entity, animDictionary, animationName, blendDelta)
    Velora.invoke(0xAF3180, "void", entity, animDictionary, animationName, blendDelta)
end

function TASK_SCRIPTED_ANIMATION(ped, priorityLowData, priorityMidData, priorityHighData, blendInDelta, blendOutDelta)
    Velora.invoke(0xAF31A0, "void", ped, priorityLowData, priorityMidData, priorityHighData, blendInDelta, blendOutDelta)
end

function PLAY_ENTITY_SCRIPTED_ANIM(entity, priorityLowData, priorityMidData, priorityHighData, blendInDelta, blendOutDelta)
    Velora.invoke(0xAF31D0, "void", entity, priorityLowData, priorityMidData, priorityHighData, blendInDelta, blendOutDelta)
end

function STOP_ANIM_PLAYBACK(entity, priority, secondary)
    Velora.invoke(0xAF3200, "void", entity, priority, secondary)
end

function SET_ANIM_WEIGHT(entity, weight, priority, index, secondary)
    Velora.invoke(0xAF32A0, "void", entity, weight, priority, index, secondary)
end

function SET_ANIM_PHASE(entity, phase, priority, secondary)
    Velora.invoke(0xAF32C0, "void", entity, phase, priority, secondary)
end

function SET_ANIM_RATE(entity, rate, priority, secondary)
    Velora.invoke(0xAF3370, "void", entity, rate, priority, secondary)
end

function SET_ANIM_LOOPED(entity, looped, priority, secondary)
    Velora.invoke(0xAF3420, "void", entity, looped, priority, secondary)
end

function TASK_PLAY_PHONE_GESTURE_ANIMATION(ped, animDict, animation, boneMaskType, blendInDuration, blendOutDuration, isLooping, holdLastFrame)
    Velora.invoke(0xAF3450, "void", ped, animDict, animation, boneMaskType, blendInDuration, blendOutDuration, isLooping, holdLastFrame)
end

function TASK_STOP_PHONE_GESTURE_ANIMATION(ped, blendOutOverride)
    Velora.invoke(0xAF3490, "void", ped, blendOutOverride)
end

function IS_PLAYING_PHONE_GESTURE_ANIM(invoke<BOOL>(0xAF3510, invoke<float>(0xAF35A0, invoke<float>(0xAF3640, vehicle, animationSet, animationName)
    return Velora.invoke(0xAF36E0, "bool", invoke<BOOL>(0xAF3510, invoke<float>(0xAF35A0, invoke<float>(0xAF3640, vehicle, animationSet, animationName)
end

function TASK_LOOK_AT_COORD(entity, x, y, z, duration, flags, priority)
    Velora.invoke(0xAF3700, "void", entity, x, y, z, duration, flags, priority)
end

function TASK_LOOK_AT_ENTITY(ped, lookAt, duration, flags, priority)
    Velora.invoke(0xAF3720, "void", ped, lookAt, duration, flags, priority)
end

function TASK_CLEAR_LOOK_AT(ped)
    Velora.invoke(0xAF3740, "void", ped)
end

function OPEN_SEQUENCE_TASK(taskSequenceId)
    Velora.invoke(0xAF3750, "void", taskSequenceId)
end

function CLOSE_SEQUENCE_TASK(taskSequenceId)
    Velora.invoke(0xAF37C0, "void", taskSequenceId)
end

function TASK_PERFORM_SEQUENCE(ped, taskSequenceId)
    Velora.invoke(0xAF3810, "void", ped, taskSequenceId)
end

function TASK_PERFORM_SEQUENCE_LOCALLY(ped, taskSequenceId)
    Velora.invoke(0xAF3820, "void", ped, taskSequenceId)
end

function CLEAR_SEQUENCE_TASK(taskSequenceId)
    Velora.invoke(0xAF3830, "void", taskSequenceId)
end

function SET_SEQUENCE_TO_REPEAT(taskSequenceId, repeat)
    Velora.invoke(0xAF3870, "void", taskSequenceId, repeat)
end

function GET_SEQUENCE_PROGRESS(invoke<int>(0xAF3940, ped, invoke<BOOL>(0xAF3960, ped, invoke<int>(0xAF3A00, invoke<int>(0xAF3A70, ped, delayTime, flags)
    return Velora.invoke(0xAF3A90, "int", invoke<int>(0xAF3940, ped, invoke<BOOL>(0xAF3960, ped, invoke<int>(0xAF3A00, invoke<int>(0xAF3A70, ped, delayTime, flags)
end

function TASK_AIM_GUN_SCRIPTED(ped, scriptTask, disableBlockingClip, instantBlendToAim)
    Velora.invoke(0xAF3AB0, "void", ped, scriptTask, disableBlockingClip, instantBlendToAim)
end

function TASK_AIM_GUN_SCRIPTED_WITH_TARGET(ped, target, x, y, z, gunTaskType, disableBlockingClip, forceAim)
    Velora.invoke(0xAF3AE0, "void", ped, target, x, y, z, gunTaskType, disableBlockingClip, forceAim)
end

function UPDATE_TASK_AIM_GUN_SCRIPTED_TARGET(ped, target, x, y, z, disableBlockingClip)
    Velora.invoke(0xAF3B10, "void", ped, target, x, y, z, disableBlockingClip)
end

function GET_CLIP_SET_FOR_SCRIPTED_GUN_TASK(char>(0xAF3B30, ped, entity, duration, instantBlendToAim)
    return Velora.invoke(0xAF3B70, "string", char>(0xAF3B30, ped, entity, duration, instantBlendToAim)
end

function TASK_TURN_PED_TO_FACE_ENTITY(ped, entity, duration)
    Velora.invoke(0xAF3B90, "void", ped, entity, duration)
end

function TASK_AIM_GUN_AT_COORD(ped, x, y, z, time, instantBlendToAim, playAnimIntro)
    Velora.invoke(0xAF3BB0, "void", ped, x, y, z, time, instantBlendToAim, playAnimIntro)
end

function TASK_SHOOT_AT_COORD(ped, x, y, z, duration, firingPattern)
    Velora.invoke(0xAF3BE0, "void", ped, x, y, z, duration, firingPattern)
end

function TASK_SHUFFLE_TO_NEXT_VEHICLE_SEAT(ped, vehicle, useAlternateShuffle)
    Velora.invoke(0xAF3C00, "void", ped, vehicle, useAlternateShuffle)
end

function CLEAR_PED_TASKS(ped)
    Velora.invoke(0xAF3C20, "void", ped)
end

function CLEAR_PED_SECONDARY_TASK(ped)
    Velora.invoke(0xAF3CA0, "void", ped)
end

function TASK_EVERYONE_LEAVE_VEHICLE(vehicle)
    Velora.invoke(0xAF3D30, "void", vehicle)
end

function TASK_GOTO_ENTITY_OFFSET(ped, entity, time, seekRadius, seekAngleDeg, moveBlendRatio, gotoEntityOffsetFlags)
    Velora.invoke(0xAF3D40, "void", ped, entity, time, seekRadius, seekAngleDeg, moveBlendRatio, gotoEntityOffsetFlags)
end

function TASK_GOTO_ENTITY_OFFSET_XY(ped, entity, duration, targetRadius, offsetX, offsetY, moveBlendRatio, gotoEntityOffsetFlags)
    Velora.invoke(0xAF3D70, "void", ped, entity, duration, targetRadius, offsetX, offsetY, moveBlendRatio, gotoEntityOffsetFlags)
end

function TASK_TURN_PED_TO_FACE_COORD(ped, x, y, z, duration)
    Velora.invoke(0xAF3DA0, "void", ped, x, y, z, duration)
end

function TASK_VEHICLE_TEMP_ACTION(driver, vehicle, action, time)
    Velora.invoke(0xAF3E90, "void", driver, vehicle, action, time)
end

function TASK_VEHICLE_MISSION(driver, vehicle, vehicleTarget, missionType, cruiseSpeed, drivingStyle, targetReached, straightLineDistance, DriveAgainstTraffic)
    Velora.invoke(0xAF3EB0, "void", driver, vehicle, vehicleTarget, missionType, cruiseSpeed, drivingStyle, targetReached, straightLineDistance, DriveAgainstTraffic)
end

function TASK_VEHICLE_MISSION_PED_TARGET(ped, vehicle, pedTarget, missionType, maxSpeed, drivingStyle, minDistance, straightLineDistance, DriveAgainstTraffic)
    Velora.invoke(0xAF3F00, "void", ped, vehicle, pedTarget, missionType, maxSpeed, drivingStyle, minDistance, straightLineDistance, DriveAgainstTraffic)
end

function TASK_VEHICLE_MISSION_COORS_TARGET(ped, vehicle, x, y, z, mission, cruiseSpeed, drivingStyle, targetReached, straightLineDistance, DriveAgainstTraffic)
    Velora.invoke(0xAF3F40, "void", ped, vehicle, x, y, z, mission, cruiseSpeed, drivingStyle, targetReached, straightLineDistance, DriveAgainstTraffic)
end

function TASK_VEHICLE_ESCORT(ped, vehicle, targetVehicle, mode, speed, drivingStyle, minDistance, minHeightAboveTerrain, noRoadsDistance)
    Velora.invoke(0xAF3FD0, "void", ped, vehicle, targetVehicle, mode, speed, drivingStyle, minDistance, minHeightAboveTerrain, noRoadsDistance)
end

function TASK_VEHICLE_FOLLOW(driver, vehicle, targetEntity, speed, drivingStyle, minDistance)
    Velora.invoke(0xAF4000, "void", driver, vehicle, targetEntity, speed, drivingStyle, minDistance)
end

function TASK_VEHICLE_CHASE(driver, targetEnt)
    Velora.invoke(0xAF4020, "void", driver, targetEnt)
end

function TASK_VEHICLE_HELI_PROTECT(pilot, vehicle, entityToFollow, targetSpeed, drivingFlags, radius, altitude, heliFlags)
    Velora.invoke(0xAF4030, "void", pilot, vehicle, entityToFollow, targetSpeed, drivingFlags, radius, altitude, heliFlags)
end

function SET_TASK_VEHICLE_CHASE_BEHAVIOR_FLAG(ped, flag, set)
    Velora.invoke(0xAF4060, "void", ped, flag, set)
end

function SET_TASK_VEHICLE_CHASE_IDEAL_PURSUIT_DISTANCE(ped, distance)
    Velora.invoke(0xAF40F0, "void", ped, distance)
end

function TASK_HELI_CHASE(pilot, entityToFollow, x, y, z)
    Velora.invoke(0xAF4160, "void", pilot, entityToFollow, x, y, z)
end

function TASK_PLANE_CHASE(pilot, entityToFollow, x, y, z)
    Velora.invoke(0xAF4180, "void", pilot, entityToFollow, x, y, z)
end

function TASK_PLANE_LAND(pilot, plane, runwayStartX, runwayStartY, runwayStartZ, runwayEndX, runwayEndY, runwayEndZ)
    Velora.invoke(0xAF41A0, "void", pilot, plane, runwayStartX, runwayStartY, runwayStartZ, runwayEndX, runwayEndY, runwayEndZ)
end

function CLEAR_DEFAULT_PRIMARY_TASK(ped)
    Velora.invoke(0xAF41C0, "void", ped)
end

function CLEAR_PRIMARY_VEHICLE_TASK(vehicle)
    Velora.invoke(0xAF4240, "void", vehicle)
end

function CLEAR_VEHICLE_CRASH_TASK(vehicle)
    Velora.invoke(0xAF42A0, "void", vehicle)
end

function TASK_PLANE_GOTO_PRECISE_VTOL(ped, vehicle, x, y, z, flightHeight, minHeightAboveTerrain, useDesiredOrientation, desiredOrientation, autopilot)
    Velora.invoke(0xAF4300, "void", ped, vehicle, x, y, z, flightHeight, minHeightAboveTerrain, useDesiredOrientation, desiredOrientation, autopilot)
end

function TASK_SUBMARINE_GOTO_AND_STOP(ped, submarine, x, y, z, autopilot)
    Velora.invoke(0xAF4350, "void", ped, submarine, x, y, z, autopilot)
end

function TASK_HELI_MISSION(pilot, aircraft, targetVehicle, targetPed, destinationX, destinationY, destinationZ, missionFlag, maxSpeed, radius, targetHeading, maxHeight, minHeight, slowDownDistance, behaviorFlags)
    Velora.invoke(0xAF4370, "void", pilot, aircraft, targetVehicle, targetPed, destinationX, destinationY, destinationZ, missionFlag, maxSpeed, radius, targetHeading, maxHeight, minHeight, slowDownDistance, behaviorFlags)
end

function TASK_HELI_ESCORT_HELI(pilot, heli1, heli2, offsetX, offsetY, offsetZ)
    Velora.invoke(0xAF43D0, "void", pilot, heli1, heli2, offsetX, offsetY, offsetZ)
end

function TASK_PLANE_MISSION(pilot, aircraft, targetVehicle, targetPed, destinationX, destinationY, destinationZ, missionFlag, angularDrag, targetReached, targetHeading, maxZ, minZ, precise)
    Velora.invoke(0xAF43F0, "void", pilot, aircraft, targetVehicle, targetPed, destinationX, destinationY, destinationZ, missionFlag, angularDrag, targetReached, targetHeading, maxZ, minZ, precise)
end

function TASK_PLANE_TAXI(pilot, aircraft, x, y, z, cruiseSpeed, targetReached)
    Velora.invoke(0xAF4450, "void", pilot, aircraft, x, y, z, cruiseSpeed, targetReached)
end

function TASK_BOAT_MISSION(pedDriver, vehicle, targetVehicle, targetPed, x, y, z, mission, maxSpeed, drivingStyle, targetReached, boatFlags)
    Velora.invoke(0xAF4470, "void", pedDriver, vehicle, targetVehicle, targetPed, x, y, z, mission, maxSpeed, drivingStyle, targetReached, boatFlags)
end

function TASK_DRIVE_BY(driverPed, targetPed, targetVehicle, targetX, targetY, targetZ, distanceToShoot, pedAccuracy, pushUnderneathDrivingTaskIfDriving, firingPattern)
    Velora.invoke(0xAF44C0, "void", driverPed, targetPed, targetVehicle, targetX, targetY, targetZ, distanceToShoot, pedAccuracy, pushUnderneathDrivingTaskIfDriving, firingPattern)
end

function SET_DRIVEBY_TASK_TARGET(shootingPed, targetPed, targetVehicle, x, y, z)
    Velora.invoke(0xAF4500, "void", shootingPed, targetPed, targetVehicle, x, y, z)
end

function CLEAR_DRIVEBY_TASK_UNDERNEATH_DRIVING_TASK(ped)
    Velora.invoke(0xAF4520, "void", ped)
end

function IS_DRIVEBY_TASK_UNDERNEATH_DRIVING_TASK(invoke<BOOL>(0xAF45B0, invoke<BOOL>(0xAF4640, shootingPed, targetPed, targetVehicle, x, y, z, taskMode, ignoreTargetVehDeadCheck)
    return Velora.invoke(0xAF46E0, "bool", invoke<BOOL>(0xAF45B0, invoke<BOOL>(0xAF4640, shootingPed, targetPed, targetVehicle, x, y, z, taskMode, ignoreTargetVehDeadCheck)
end

function IS_MOUNTED_WEAPON_TASK_UNDERNEATH_DRIVING_TASK(invoke<BOOL>(0xAF4710, ped, usePhone, desiredPhoneMode)
    return Velora.invoke(0xAF4780, "bool", invoke<BOOL>(0xAF4710, ped, usePhone, desiredPhoneMode)
end

function TASK_USE_MOBILE_PHONE_TIMED(ped, duration)
    Velora.invoke(0xAF47A0, "void", ped, duration)
end

function TASK_CHAT_TO_PED(ped, target, flags, goToLocationX, goToLocationY, goToLocationZ, headingDegs, idleTime)
    Velora.invoke(0xAF47B0, "void", ped, target, flags, goToLocationX, goToLocationY, goToLocationZ, headingDegs, idleTime)
end

function TASK_WARP_PED_INTO_VEHICLE(ped, vehicle, seat)
    Velora.invoke(0xAF47D0, "void", ped, vehicle, seat)
end

function TASK_SHOOT_AT_ENTITY(entity, target, duration, firingPattern)
    Velora.invoke(0xAF47F0, "void", entity, target, duration, firingPattern)
end

function TASK_CLIMB(ped, usePlayerLaunchForce)
    Velora.invoke(0xAF4810, "void", ped, usePlayerLaunchForce)
end

function TASK_CLIMB_LADDER(ped, fast)
    Velora.invoke(0xAF4870, "void", ped, fast)
end

function TASK_RAPPEL_DOWN_WALL_USING_CLIPSET_OVERRIDE(ped, x1, y1, z1, x2, y2, z2, minZ, ropeHandle, clipSet, p10)
    Velora.invoke(0xAF48E0, "void", ped, x1, y1, z1, x2, y2, z2, minZ, ropeHandle, clipSet, p10)
end

function GET_TASK_RAPPEL_DOWN_WALL_STATE(invoke<int>(0xAF4910, ped)
    return Velora.invoke(0xAF49D0, "int", invoke<int>(0xAF4910, ped)
end

function TASK_PERFORM_SEQUENCE_FROM_PROGRESS(ped, taskIndex, progress1, progress2)
    Velora.invoke(0xAF49E0, "void", ped, taskIndex, progress1, progress2)
end

function SET_NEXT_DESIRED_MOVE_STATE(nextMoveState)
    Velora.invoke(0xAF4A00, "void", nextMoveState)
end

function SET_PED_DESIRED_MOVE_BLEND_RATIO(ped, newMoveBlendRatio)
    Velora.invoke(0xAF4A10, "void", ped, newMoveBlendRatio)
end

function GET_PED_DESIRED_MOVE_BLEND_RATIO(invoke<float>(0xAF4A20, ped, target, distanceToStopAt, StartAimingDist)
    return Velora.invoke(0xAF4A70, "float", invoke<float>(0xAF4A20, ped, target, distanceToStopAt, StartAimingDist)
end

function TASK_SET_DECISION_MAKER(ped, decisionMakerId)
    Velora.invoke(0xAF4B20, "void", ped, decisionMakerId)
end

function TASK_SET_SPHERE_DEFENSIVE_AREA(ped, x, y, z, radius)
    Velora.invoke(0xAF4B30, "void", ped, x, y, z, radius)
end

function TASK_CLEAR_DEFENSIVE_AREA(ped)
    Velora.invoke(0xAF4B50, "void", ped)
end

function TASK_PED_SLIDE_TO_COORD(ped, x, y, z, heading, speed)
    Velora.invoke(0xAF4B60, "void", ped, x, y, z, heading, speed)
end

function TASK_PED_SLIDE_TO_COORD_HDG_RATE(ped, x, y, z, heading, speed, headingChangeRate)
    Velora.invoke(0xAF4B80, "void", ped, x, y, z, heading, speed, headingChangeRate)
end

function ADD_COVER_POINT(x, y, z, direction, usage, height, arc, invoke<ScrHandle>(0xAF4BA0, coverpoint)
    return Velora.invoke(0xAF4C50, "int", x, y, z, direction, usage, height, arc, invoke<ScrHandle>(0xAF4BA0, coverpoint)
end

function DOES_SCRIPTED_COVER_POINT_EXIST_AT_COORDS(x, y, invoke<BOOL>(0xAF4C90, invoke<Vector3>(0xAF4D20, x, y, z, radius)
    return Velora.invoke(0xAF4DF0, "bool", x, y, invoke<BOOL>(0xAF4C90, invoke<Vector3>(0xAF4D20, x, y, z, radius)
end

function TASK_COMBAT_PED(ped, targetPed, combatFlags, threatResponseFlags)
    Velora.invoke(0xAF4EB0, "void", ped, targetPed, combatFlags, threatResponseFlags)
end

function TASK_COMBAT_PED_TIMED(ped, target, time, flags)
    Velora.invoke(0xAF4ED0, "void", ped, target, time, flags)
end

function TASK_SEEK_COVER_FROM_POS(ped, x, y, z, duration, allowPeekingAndFiring)
    Velora.invoke(0xAF4EF0, "void", ped, x, y, z, duration, allowPeekingAndFiring)
end

function TASK_SEEK_COVER_FROM_PED(ped, target, duration, allowPeekingAndFiring)
    Velora.invoke(0xAF4F10, "void", ped, target, duration, allowPeekingAndFiring)
end

function TASK_SEEK_COVER_TO_COVER_POINT(ped, coverpoint, x, y, z, time, allowPeekingAndFiring)
    Velora.invoke(0xAF4F30, "void", ped, coverpoint, x, y, z, time, allowPeekingAndFiring)
end

function TASK_SEEK_COVER_TO_COORDS(ped, x1, y1, z1, x2, y2, z2, timeout, shortRoute)
    Velora.invoke(0xAF4F50, "void", ped, x1, y1, z1, x2, y2, z2, timeout, shortRoute)
end

function TASK_PUT_PED_DIRECTLY_INTO_COVER(ped, x, y, z, time, allowPeekingAndFiring, blendInDuration, forceInitialFacingDirection, forceFaceLeft, identifier, doEntry)
    Velora.invoke(0xAF4F80, "void", ped, x, y, z, time, allowPeekingAndFiring, blendInDuration, forceInitialFacingDirection, forceFaceLeft, identifier, doEntry)
end

function TASK_WARP_PED_DIRECTLY_INTO_COVER(ped, time, allowPeekingAndFiring, forceInitialFacingDirection, forceFaceLeft, identifier)
    Velora.invoke(0xAF5090, "void", ped, time, allowPeekingAndFiring, forceInitialFacingDirection, forceFaceLeft, identifier)
end

function TASK_EXIT_COVER(ped, exitType, x, y, z)
    Velora.invoke(0xAF50D0, "void", ped, exitType, x, y, z)
end

function TASK_PUT_PED_DIRECTLY_INTO_MELEE(ped, meleeTarget, blendInDuration, timeInMelee, strafePhaseSync, aiCombatFlags)
    Velora.invoke(0xAF50F0, "void", ped, meleeTarget, blendInDuration, timeInMelee, strafePhaseSync, aiCombatFlags)
end

function TASK_TOGGLE_DUCK(ped, toggleType)
    Velora.invoke(0xAF5110, "void", ped, toggleType)
end

function TASK_GUARD_CURRENT_POSITION(ped, maxPatrolProximity, defensiveAreaRadius, setDefensiveArea)
    Velora.invoke(0xAF51A0, "void", ped, maxPatrolProximity, defensiveAreaRadius, setDefensiveArea)
end

function TASK_GUARD_ASSIGNED_DEFENSIVE_AREA(ped, x, y, z, heading, maxPatrolProximity, timer)
    Velora.invoke(0xAF51C0, "void", ped, x, y, z, heading, maxPatrolProximity, timer)
end

function TASK_GUARD_SPHERE_DEFENSIVE_AREA(ped, defendPositionX, defendPositionY, defendPositionZ, heading, maxPatrolProximity, time, x, y, z, defensiveAreaRadius)
    Velora.invoke(0xAF51E0, "void", ped, defendPositionX, defendPositionY, defendPositionZ, heading, maxPatrolProximity, time, x, y, z, defensiveAreaRadius)
end

function TASK_STAND_GUARD(ped, x, y, z, heading, scenarioName)
    Velora.invoke(0xAF5210, "void", ped, x, y, z, heading, scenarioName)
end

function SET_DRIVE_TASK_CRUISE_SPEED(driver, cruiseSpeed)
    Velora.invoke(0xAF5230, "void", driver, cruiseSpeed)
end

function SET_DRIVE_TASK_MAX_CRUISE_SPEED(ped, speed)
    Velora.invoke(0xAF5240, "void", ped, speed)
end

function SET_DRIVE_TASK_DRIVING_STYLE(ped, drivingStyle)
    Velora.invoke(0xAF5260, "void", ped, drivingStyle)
end

function ADD_COVER_BLOCKING_AREA(startX, startY, startZ, endX, endY, endZ, blockObjects, blockVehicles, blockMap, blockPlayer)
    Velora.invoke(0xAF52F0, "void", startX, startY, startZ, endX, endY, endZ, blockObjects, blockVehicles, blockMap, blockPlayer)
end

function REMOVE_ALL_COVER_BLOCKING_AREAS()
    Velora.invoke(0xAF53A0, "void")
end

function REMOVE_COVER_BLOCKING_AREAS_AT_POSITION(x, y, z)
    Velora.invoke(0xAF53C0, "void", x, y, z)
end

function REMOVE_SPECIFIC_COVER_BLOCKING_AREAS(startX, startY, startZ, endX, endY, endZ, blockObjects, blockVehicles, blockMap, blockPlayer)
    Velora.invoke(0xAF5420, "void", startX, startY, startZ, endX, endY, endZ, blockObjects, blockVehicles, blockMap, blockPlayer)
end

function TASK_START_SCENARIO_IN_PLACE(ped, scenarioName, unkDelay, playEnterAnim)
    Velora.invoke(0xAF54D0, "void", ped, scenarioName, unkDelay, playEnterAnim)
end

function TASK_START_SCENARIO_AT_POSITION(ped, scenarioName, x, y, z, heading, duration, sittingScenario, teleport)
    Velora.invoke(0xAF54F0, "void", ped, scenarioName, x, y, z, heading, duration, sittingScenario, teleport)
end

function TASK_USE_NEAREST_SCENARIO_TO_COORD(ped, x, y, z, distance, duration)
    Velora.invoke(0xAF5530, "void", ped, x, y, z, distance, duration)
end

function TASK_USE_NEAREST_SCENARIO_TO_COORD_WARP(ped, x, y, z, radius, timeToLeave)
    Velora.invoke(0xAF55E0, "void", ped, x, y, z, radius, timeToLeave)
end

function TASK_USE_NEAREST_SCENARIO_CHAIN_TO_COORD(ped, x, y, z, maxRange, timeToLeave)
    Velora.invoke(0xAF5690, "void", ped, x, y, z, maxRange, timeToLeave)
end

function TASK_USE_NEAREST_SCENARIO_CHAIN_TO_COORD_WARP(ped, x, y, z, radius, timeToLeave)
    Velora.invoke(0xAF56B0, "void", ped, x, y, z, radius, timeToLeave)
end

function DOES_SCENARIO_EXIST_IN_AREA(x, y, z, radius, invoke<BOOL>(0xAF56D0, x, y, z, scenarioName, radius, invoke<BOOL>(0xAF5770, x, y, z, maxRange, invoke<BOOL>(0xAF5830, invoke<BOOL>(0xAF5860, ped, animDict, animName)
    return Velora.invoke(0xAF58C0, "bool", x, y, z, radius, invoke<BOOL>(0xAF56D0, x, y, z, scenarioName, radius, invoke<BOOL>(0xAF5770, x, y, z, maxRange, invoke<BOOL>(0xAF5830, invoke<BOOL>(0xAF5860, ped, animDict, animName)
end

function DOES_SCENARIO_GROUP_EXIST(invoke<BOOL>(0xAF58E0, invoke<BOOL>(0xAF5960, scenarioGroup, enabled)
    return Velora.invoke(0xAF5A00, "bool", invoke<BOOL>(0xAF58E0, invoke<BOOL>(0xAF5960, scenarioGroup, enabled)
end

function RESET_SCENARIO_GROUPS_ENABLED()
    Velora.invoke(0xAF5A90, "void")
end

function SET_EXCLUSIVE_SCENARIO_GROUP(scenarioGroup)
    Velora.invoke(0xAF5AA0, "void", scenarioGroup)
end

function RESET_EXCLUSIVE_SCENARIO_GROUP()
    Velora.invoke(0xAF5B20, "void")
end

function IS_SCENARIO_TYPE_ENABLED(invoke<BOOL>(0xAF5B40, scenarioType, toggle)
    return Velora.invoke(0xAF5BD0, "bool", invoke<BOOL>(0xAF5B40, scenarioType, toggle)
end

function RESET_SCENARIO_TYPES_ENABLED()
    Velora.invoke(0xAF5C60, "void")
end

function IS_PED_ACTIVE_IN_SCENARIO(invoke<BOOL>(0xAF5C70, invoke<BOOL>(0xAF5CF0, ped, blockIdleClips, removeIdleClipIfPlaying)
    return Velora.invoke(0xAF5D20, "bool", invoke<BOOL>(0xAF5C70, invoke<BOOL>(0xAF5CF0, ped, blockIdleClips, removeIdleClipIfPlaying)
end

function TASK_COMBAT_HATED_TARGETS_IN_AREA(ped, x, y, z, radius, combatFlags)
    Velora.invoke(0xAF5DA0, "void", ped, x, y, z, radius, combatFlags)
end

function TASK_COMBAT_HATED_TARGETS_AROUND_PED(ped, radius, combatFlags)
    Velora.invoke(0xAF5EA0, "void", ped, radius, combatFlags)
end

function TASK_COMBAT_HATED_TARGETS_AROUND_PED_TIMED(ped, radius, time, combatFlags)
    Velora.invoke(0xAF5F90, "void", ped, radius, time, combatFlags)
end

function TASK_THROW_PROJECTILE(ped, x, y, z, ignoreCollisionEntityIndex, createInvincibleProjectile)
    Velora.invoke(0xAF6090, "void", ped, x, y, z, ignoreCollisionEntityIndex, createInvincibleProjectile)
end

function TASK_SWAP_WEAPON(ped, drawWeapon)
    Velora.invoke(0xAF60B0, "void", ped, drawWeapon)
end

function TASK_RELOAD_WEAPON(ped, drawWeapon)
    Velora.invoke(0xAF6130, "void", ped, drawWeapon)
end

function IS_PED_GETTING_UP(invoke<BOOL>(0xAF6150, ped, target, minFireLoops, startState, forceShootOnGround, shootFromGroundTimer)
    return Velora.invoke(0xAF61B0, "bool", invoke<BOOL>(0xAF6150, ped, target, minFireLoops, startState, forceShootOnGround, shootFromGroundTimer)
end

function IS_PED_IN_WRITHE(invoke<BOOL>(0xAF61E0, patrolRoute)
    return Velora.invoke(0xAF6240, "bool", invoke<BOOL>(0xAF61E0, patrolRoute)
end

function CLOSE_PATROL_ROUTE()
    Velora.invoke(0xAF6260, "void")
end

function ADD_PATROL_ROUTE_NODE(nodeId, nodeType, posX, posY, posZ, headingX, headingY, headingZ, duration)
    Velora.invoke(0xAF6270, "void", nodeId, nodeType, posX, posY, posZ, headingX, headingY, headingZ, duration)
end

function ADD_PATROL_ROUTE_LINK(nodeId1, nodeId2)
    Velora.invoke(0xAF6300, "void", nodeId1, nodeId2)
end

function CREATE_PATROL_ROUTE()
    Velora.invoke(0xAF6320, "void")
end

function DELETE_PATROL_ROUTE(patrolRoute)
    Velora.invoke(0xAF6330, "void", patrolRoute)
end

function GET_PATROL_TASK_INFO(ped, timeLeftAtNode, invoke<BOOL>(0xAF6370, ped, patrolRouteName, alertState, canChatToPeds, useHeadLookAt)
    return Velora.invoke(0xAF6410, "bool", ped, timeLeftAtNode, invoke<BOOL>(0xAF6370, ped, patrolRouteName, alertState, canChatToPeds, useHeadLookAt)
end

function TASK_STAY_IN_COVER(ped)
    Velora.invoke(0xAF64B0, "void", ped)
end

function ADD_VEHICLE_SUBTASK_ATTACK_COORD(ped, x, y, z)
    Velora.invoke(0xAF6510, "void", ped, x, y, z)
end

function ADD_VEHICLE_SUBTASK_ATTACK_PED(ped, target)
    Velora.invoke(0xAF6520, "void", ped, target)
end

function TASK_VEHICLE_SHOOT_AT_PED(ped, target, fireTolerance)
    Velora.invoke(0xAF6530, "void", ped, target, fireTolerance)
end

function TASK_VEHICLE_AIM_AT_PED(ped, target)
    Velora.invoke(0xAF6550, "void", ped, target)
end

function TASK_VEHICLE_SHOOT_AT_COORD(ped, x, y, z, fireTolerance)
    Velora.invoke(0xAF6560, "void", ped, x, y, z, fireTolerance)
end

function TASK_VEHICLE_AIM_AT_COORD(ped, x, y, z)
    Velora.invoke(0xAF6580, "void", ped, x, y, z)
end

function TASK_VEHICLE_GOTO_NAVMESH(ped, vehicle, x, y, z, speed, behaviorFlag, stoppingRange)
    Velora.invoke(0xAF6590, "void", ped, vehicle, x, y, z, speed, behaviorFlag, stoppingRange)
end

function TASK_GO_TO_COORD_WHILE_AIMING_AT_COORD(ped, x, y, z, aimAtX, aimAtY, aimAtZ, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, navFlags, instantBlendToAim, firingPattern)
    Velora.invoke(0xAF65B0, "void", ped, x, y, z, aimAtX, aimAtY, aimAtZ, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, navFlags, instantBlendToAim, firingPattern)
end

function TASK_GO_TO_COORD_WHILE_AIMING_AT_ENTITY(ped, x, y, z, aimAtID, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, navFlags, instantBlendToAim, firingPattern, time)
    Velora.invoke(0xAF6610, "void", ped, x, y, z, aimAtID, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, navFlags, instantBlendToAim, firingPattern, time)
end

function TASK_GO_TO_COORD_AND_AIM_AT_HATED_ENTITIES_NEAR_COORD(pedHandle, goToLocationX, goToLocationY, goToLocationZ, focusLocationX, focusLocationY, focusLocationZ, speed, shootAtEnemies, distanceToStopAt, noRoadsDistance, useNavMesh, navFlags, taskFlags, firingPattern)
    Velora.invoke(0xAF6680, "void", pedHandle, goToLocationX, goToLocationY, goToLocationZ, focusLocationX, focusLocationY, focusLocationZ, speed, shootAtEnemies, distanceToStopAt, noRoadsDistance, useNavMesh, navFlags, taskFlags, firingPattern)
end

function TASK_GO_TO_ENTITY_WHILE_AIMING_AT_COORD(ped, entity, aimX, aimY, aimZ, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, instantBlendToAim, firingPattern)
    Velora.invoke(0xAF66E0, "void", ped, entity, aimX, aimY, aimZ, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, instantBlendToAim, firingPattern)
end

function TASK_GO_TO_ENTITY_WHILE_AIMING_AT_ENTITY(ped, entityToWalkTo, entityToAimAt, speed, shootatEntity, targetRadius, slowDistance, useNavMesh, instantBlendToAim, firingPattern)
    Velora.invoke(0xAF6740, "void", ped, entityToWalkTo, entityToAimAt, speed, shootatEntity, targetRadius, slowDistance, useNavMesh, instantBlendToAim, firingPattern)
end

function SET_HIGH_FALL_TASK(ped, minTime, maxTime, entryType)
    Velora.invoke(0xAF67A0, "void", ped, minTime, maxTime, entryType)
end

function REQUEST_WAYPOINT_RECORDING(name)
    Velora.invoke(0xAF67C0, "void", name)
end

function GET_IS_WAYPOINT_RECORDING_LOADED(invoke<BOOL>(0xAF6800, name)
    return Velora.invoke(0xAF6840, "bool", invoke<BOOL>(0xAF6800, name)
end

function WAYPOINT_RECORDING_GET_NUM_POINTS(name, invoke<BOOL>(0xAF6880, name, point, invoke<BOOL>(0xAF68E0, name, invoke<float>(0xAF6950, name, x, y, z, invoke<BOOL>(0xAF69F0, ped, name, p2, p3, p4)
    return Velora.invoke(0xAF6AA0, "bool", name, invoke<BOOL>(0xAF6880, name, point, invoke<BOOL>(0xAF68E0, name, invoke<float>(0xAF6950, name, x, y, z, invoke<BOOL>(0xAF69F0, ped, name, p2, p3, p4)
end

function IS_WAYPOINT_PLAYBACK_GOING_ON_FOR_PED(invoke<BOOL>(0xAF6B60, invoke<int>(0xAF6BE0, invoke<float>(0xAF6CE0, ped, x, y, invoke<BOOL>(0xAF6D70, name, invoke<float>(0xAF6E20, invoke<BOOL>(0xAF6E80, p0, p1, p2)
    return Velora.invoke(0xAF6F10, "bool", invoke<BOOL>(0xAF6B60, invoke<int>(0xAF6BE0, invoke<float>(0xAF6CE0, ped, x, y, invoke<BOOL>(0xAF6D70, name, invoke<float>(0xAF6E20, invoke<BOOL>(0xAF6E80, p0, p1, p2)
end

function WAYPOINT_PLAYBACK_RESUME(p0, p1, p2, p3)
    Velora.invoke(0xAF6FB0, "void", p0, p1, p2, p3)
end

function WAYPOINT_PLAYBACK_OVERRIDE_SPEED(p0, p1, p2)
    Velora.invoke(0xAF7050, "void", p0, p1, p2)
end

function WAYPOINT_PLAYBACK_USE_DEFAULT_SPEED(p0)
    Velora.invoke(0xAF7110, "void", p0)
end

function USE_WAYPOINT_RECORDING_AS_ASSISTED_MOVEMENT_ROUTE(name, p1, p2, p3)
    Velora.invoke(0xAF7180, "void", name, p1, p2, p3)
end

function WAYPOINT_PLAYBACK_START_AIMING_AT_PED(ped, target, p2)
    Velora.invoke(0xAF71A0, "void", ped, target, p2)
end

function WAYPOINT_PLAYBACK_START_AIMING_AT_COORD(ped, x, y, z, p4)
    Velora.invoke(0xAF7260, "void", ped, x, y, z, p4)
end

function WAYPOINT_PLAYBACK_START_SHOOTING_AT_PED(ped, ped2, p2, p3)
    Velora.invoke(0xAF7330, "void", ped, ped2, p2, p3)
end

function WAYPOINT_PLAYBACK_START_SHOOTING_AT_COORD(ped, x, y, z, p4, firingPattern)
    Velora.invoke(0xAF7350, "void", ped, x, y, z, p4, firingPattern)
end

function WAYPOINT_PLAYBACK_STOP_AIMING_OR_SHOOTING(ped)
    Velora.invoke(0xAF7370, "void", ped)
end

function ASSISTED_MOVEMENT_REQUEST_ROUTE(route)
    Velora.invoke(0xAF73E0, "void", route)
end

function ASSISTED_MOVEMENT_REMOVE_ROUTE(route)
    Velora.invoke(0xAF73F0, "void", route)
end

function ASSISTED_MOVEMENT_IS_ROUTE_LOADED(invoke<BOOL>(0xAF7430, route, props)
    return Velora.invoke(0xAF74B0, "bool", invoke<BOOL>(0xAF7430, route, props)
end

function ASSISTED_MOVEMENT_OVERRIDE_LOAD_DISTANCE_THIS_FRAME(dist)
    Velora.invoke(0xAF74C0, "void", dist)
end

function TASK_VEHICLE_FOLLOW_WAYPOINT_RECORDING(ped, vehicle, WPRecording, p3, p4, p5, p6, p7, p8, p9)
    Velora.invoke(0xAF74E0, "void", ped, vehicle, WPRecording, p3, p4, p5, p6, p7, p8, p9)
end

function IS_WAYPOINT_PLAYBACK_GOING_ON_FOR_VEHICLE(invoke<BOOL>(0xAF7530, invoke<int>(0xAF75B0, invoke<int>(0xAF7630, vehicle)
    return Velora.invoke(0xAF76C0, "bool", invoke<BOOL>(0xAF7530, invoke<int>(0xAF75B0, invoke<int>(0xAF7630, vehicle)
end

function VEHICLE_WAYPOINT_PLAYBACK_RESUME(vehicle)
    Velora.invoke(0xAF77C0, "void", vehicle)
end

function VEHICLE_WAYPOINT_PLAYBACK_USE_DEFAULT_SPEED(vehicle)
    Velora.invoke(0xAF7830, "void", vehicle)
end

function VEHICLE_WAYPOINT_PLAYBACK_OVERRIDE_SPEED(vehicle, speed)
    Velora.invoke(0xAF78A0, "void", vehicle, speed)
end

function TASK_SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(ped, toggle)
    Velora.invoke(0xAF7920, "void", ped, toggle)
end

function TASK_FORCE_MOTION_STATE(ped, state, forceRestart)
    Velora.invoke(0xAF79A0, "void", ped, state, forceRestart)
end

function TASK_MOVE_NETWORK_BY_NAME(ped, task, multiplier, allowOverrideCloneUpdate, animDict, flags)
    Velora.invoke(0xAF79C0, "void", ped, task, multiplier, allowOverrideCloneUpdate, animDict, flags)
end

function TASK_MOVE_NETWORK_ADVANCED_BY_NAME(ped, network, x, y, z, rotX, rotY, rotZ, rotOrder, blendDuration, allowOverrideCloneUpdate, animDict, flags)
    Velora.invoke(0xAF79F0, "void", ped, network, x, y, z, rotX, rotY, rotZ, rotOrder, blendDuration, allowOverrideCloneUpdate, animDict, flags)
end

function TASK_MOVE_NETWORK_BY_NAME_WITH_INIT_PARAMS(ped, network, initialParameters, blendDuration, allowOverrideCloneUpdate, animDict, flags)
    Velora.invoke(0xAF7A40, "void", ped, network, initialParameters, blendDuration, allowOverrideCloneUpdate, animDict, flags)
end

function TASK_MOVE_NETWORK_ADVANCED_BY_NAME_WITH_INIT_PARAMS(ped, network, initialParameters, x, y, z, rotX, rotY, rotZ, rotOrder, blendDuration, allowOverrideCloneUpdate, dictionary, flags)
    Velora.invoke(0xAF7A70, "void", ped, network, initialParameters, x, y, z, rotX, rotY, rotZ, rotOrder, blendDuration, allowOverrideCloneUpdate, dictionary, flags)
end

function IS_TASK_MOVE_NETWORK_ACTIVE(invoke<BOOL>(0xAF7AD0, invoke<BOOL>(0xAF7B60, ped, invoke<BOOL>(0xAF7C10, ped, invoke<BOOL>(0xAF7C20, char>(0xAF7C30, ped, clipSet, variableClipSet)
    return Velora.invoke(0xAF7CE0, "bool", invoke<BOOL>(0xAF7AD0, invoke<BOOL>(0xAF7B60, ped, invoke<BOOL>(0xAF7C10, ped, invoke<BOOL>(0xAF7C20, char>(0xAF7C30, ped, clipSet, variableClipSet)
end

function SET_TASK_MOVE_NETWORK_SIGNAL_FLOAT(ped, signalName, value)
    Velora.invoke(0xAF7D00, "void", ped, signalName, value)
end

function SET_TASK_MOVE_NETWORK_SIGNAL_LOCAL_FLOAT(ped, signalName, value)
    Velora.invoke(0xAF7D20, "void", ped, signalName, value)
end

function SET_TASK_MOVE_NETWORK_SIGNAL_FLOAT_LERP_RATE(ped, signalName, value)
    Velora.invoke(0xAF7DD0, "void", ped, signalName, value)
end

function SET_TASK_MOVE_NETWORK_SIGNAL_BOOL(ped, signalName, value)
    Velora.invoke(0xAF7E80, "void", ped, signalName, value)
end

function GET_TASK_MOVE_NETWORK_SIGNAL_FLOAT(ped, invoke<float>(0xAF7EA0, ped, invoke<BOOL>(0xAF7F50, ped, invoke<BOOL>(0xAF7FF0, ped, invoke<BOOL>(0xAF8090, invoke<BOOL>(0xAF8200, invoke<BOOL>(0xAF8220, invoke<BOOL>(0xAF8260, invoke<BOOL>(0xAF82A0, invoke<BOOL>(0xAF82C0, invoke<BOOL>(0xAF8370, invoke<BOOL>(0xAF8420, invoke<BOOL>(0xAF84D0, invoke<BOOL>(0xAF8570, ped, scene, animDictionary, animationName, blendIn, blendOut, flags, ragdollBlockingFlags, moverBlendDelta, ikFlags)
    return Velora.invoke(0xAF85D0, "float", ped, invoke<float>(0xAF7EA0, ped, invoke<BOOL>(0xAF7F50, ped, invoke<BOOL>(0xAF7FF0, ped, invoke<BOOL>(0xAF8090, invoke<BOOL>(0xAF8200, invoke<BOOL>(0xAF8220, invoke<BOOL>(0xAF8260, invoke<BOOL>(0xAF82A0, invoke<BOOL>(0xAF82C0, invoke<BOOL>(0xAF8370, invoke<BOOL>(0xAF8420, invoke<BOOL>(0xAF84D0, invoke<BOOL>(0xAF8570, ped, scene, animDictionary, animationName, blendIn, blendOut, flags, ragdollBlockingFlags, moverBlendDelta, ikFlags)
end

function TASK_AGITATED_ACTION_CONFRONT_RESPONSE(ped, ped2)
    Velora.invoke(0xAF8620, "void", ped, ped2)
end

function TASK_SWEEP_AIM_ENTITY(ped, animDict, lowAnimName, medAnimName, hiAnimName, runtime, targetEntity, turnRate, blendInDuration)
    Velora.invoke(0xAF8630, "void", ped, animDict, lowAnimName, medAnimName, hiAnimName, runtime, targetEntity, turnRate, blendInDuration)
end

function UPDATE_TASK_SWEEP_AIM_ENTITY(ped, entity)
    Velora.invoke(0xAF8670, "void", ped, entity)
end

function TASK_SWEEP_AIM_POSITION(ped, animDict, lowAnimName, medAnimName, hiAnimName, runtime, x, y, z, turnRate, blendInDuration)
    Velora.invoke(0xAF8680, "void", ped, animDict, lowAnimName, medAnimName, hiAnimName, runtime, x, y, z, turnRate, blendInDuration)
end

function UPDATE_TASK_SWEEP_AIM_POSITION(ped, x, y, z)
    Velora.invoke(0xAF86C0, "void", ped, x, y, z)
end

function TASK_ARREST_PED(ped, target)
    Velora.invoke(0xAF8750, "void", ped, target)
end

function IS_PED_RUNNING_ARREST_TASK(invoke<BOOL>(0xAF8760, invoke<BOOL>(0xAF87F0, ped)
    return Velora.invoke(0xAF8800, "bool", invoke<BOOL>(0xAF8760, invoke<BOOL>(0xAF87F0, ped)
end

function IS_PED_CUFFED(invoke<BOOL>(0xAF8850, modelHash, x, y, z, heading, isNetwork, bScriptHostVeh, invoke<Vehicle>(0xB1AFB0, vehicle)
    return Velora.invoke(0xB1B000, "bool", invoke<BOOL>(0xAF8850, modelHash, x, y, z, heading, isNetwork, bScriptHostVeh, invoke<Vehicle>(0xB1AFB0, vehicle)
end

function SET_VEHICLE_ALLOW_HOMING_MISSLE_LOCKON(vehicle, toggle, p2)
    Velora.invoke(0xB1B010, "void", vehicle, toggle, p2)
end

function SET_VEHICLE_ALLOW_HOMING_MISSLE_LOCKON_SYNCED(vehicle, canBeLockedOn, p2)
    Velora.invoke(0xB1B130, "void", vehicle, canBeLockedOn, p2)
end

function SET_VEHICLE_ALLOW_NO_PASSENGERS_LOCKON(veh, toggle)
    Velora.invoke(0xB1B190, "void", veh, toggle)
end

function GET_VEHICLE_HOMING_LOCKON_STATE(invoke<int>(0xB1B230, invoke<int>(0xB1B280, p0, p1)
    return Velora.invoke(0xB1B2D0, "int", invoke<int>(0xB1B230, invoke<int>(0xB1B280, p0, p1)
end

function IS_VEHICLE_MODEL(vehicle, invoke<BOOL>(0xB1B330, invoke<BOOL>(0xB1B3F0, x, y, z, heading, p4, p5, modelHash, p7, p8, p9, p10, p11, p12, p13, p14, p15, invoke<int>(0xB1B450, vehicleGenerator)
    return Velora.invoke(0xB1B620, "bool", vehicle, invoke<BOOL>(0xB1B330, invoke<BOOL>(0xB1B3F0, x, y, z, heading, p4, p5, modelHash, p7, p8, p9, p10, p11, p12, p13, p14, p15, invoke<int>(0xB1B450, vehicleGenerator)
end

function SET_SCRIPT_VEHICLE_GENERATOR(vehicleGenerator, enabled)
    Velora.invoke(0xB1B6A0, "void", vehicleGenerator, enabled)
end

function SET_ALL_VEHICLE_GENERATORS_ACTIVE_IN_AREA(x1, y1, z1, x2, y2, z2, toggle, p7)
    Velora.invoke(0xB1B730, "void", x1, y1, z1, x2, y2, z2, toggle, p7)
end

function SET_ALL_VEHICLE_GENERATORS_ACTIVE()
    Velora.invoke(0xB1B760, "void")
end

function SET_ALL_LOW_PRIORITY_VEHICLE_GENERATORS_ACTIVE(active)
    Velora.invoke(0xB1B770, "void", active)
end

function SET_VEHICLE_GENERATOR_AREA_OF_INTEREST(x, y, z, radius)
    Velora.invoke(0xB1B790, "void", x, y, z, radius)
end

function CLEAR_VEHICLE_GENERATOR_AREA_OF_INTEREST()
    Velora.invoke(0xB1B7D0, "void")
end

function SET_VEHICLE_ON_GROUND_PROPERLY(vehicle, invoke<BOOL>(0xB1B7E0, p0, p1, p2, invoke<BOOL>(0xB1B890, invoke<BOOL>(0xB1B9D0, vehicle)
    return Velora.invoke(0xB1BA30, "bool", vehicle, invoke<BOOL>(0xB1B7E0, p0, p1, p2, invoke<BOOL>(0xB1B890, invoke<BOOL>(0xB1B9D0, vehicle)
end

function REMOVE_VEHICLE_UPSIDEDOWN_CHECK(vehicle)
    Velora.invoke(0xB1BA80, "void", vehicle)
end

function IS_VEHICLE_STOPPED(invoke<BOOL>(0xB1BAA0, vehicle, includeDriver, invoke<int>(0xB1BB00, invoke<int>(0xB1BB90, invoke<int>(0xB1BBF0, vehicle, invoke<BOOL>(0xB1BC90, vehicle, invoke<BOOL>(0xB1BD30, invoke<BOOL>(0xB1BDB0, multiplier)
    return Velora.invoke(0xB1BE10, "bool", invoke<BOOL>(0xB1BAA0, vehicle, includeDriver, invoke<int>(0xB1BB00, invoke<int>(0xB1BB90, invoke<int>(0xB1BBF0, vehicle, invoke<BOOL>(0xB1BC90, vehicle, invoke<BOOL>(0xB1BD30, invoke<BOOL>(0xB1BDB0, multiplier)
end

function SET_RANDOM_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME(multiplier)
    Velora.invoke(0xB1BE40, "void", multiplier)
end

function SET_PARKED_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME(multiplier)
    Velora.invoke(0xB1BE60, "void", multiplier)
end

function SET_DISABLE_RANDOM_TRAINS_THIS_FRAME(toggle)
    Velora.invoke(0xB1BE80, "void", toggle)
end

function SET_AMBIENT_VEHICLE_RANGE_MULTIPLIER_THIS_FRAME(value)
    Velora.invoke(0xB1BEA0, "void", value)
end

function SET_FAR_DRAW_VEHICLES(toggle)
    Velora.invoke(0xB1BEE0, "void", toggle)
end

function SET_NUMBER_OF_PARKED_VEHICLES(value)
    Velora.invoke(0xB1BF00, "void", value)
end

function SET_VEHICLE_DOORS_LOCKED(vehicle, doorLockStatus)
    Velora.invoke(0xB1BF10, "void", vehicle, doorLockStatus)
end

function SET_VEHICLE_INDIVIDUAL_DOORS_LOCKED(vehicle, doorId, doorLockStatus)
    Velora.invoke(0xB1BF60, "void", vehicle, doorId, doorLockStatus)
end

function SET_VEHICLE_HAS_MUTED_SIRENS(vehicle, toggle)
    Velora.invoke(0xB1BFF0, "void", vehicle, toggle)
end

function SET_VEHICLE_DOORS_LOCKED_FOR_PLAYER(vehicle, player, toggle)
    Velora.invoke(0xB1C090, "void", vehicle, player, toggle)
end

function GET_VEHICLE_DOORS_LOCKED_FOR_PLAYER(vehicle, invoke<BOOL>(0xB1C0B0, vehicle, toggle)
    return Velora.invoke(0xB1C120, "bool", vehicle, invoke<BOOL>(0xB1C0B0, vehicle, toggle)
end

function SET_VEHICLE_DOORS_LOCKED_FOR_NON_SCRIPT_PLAYERS(vehicle, toggle)
    Velora.invoke(0xB1C1D0, "void", vehicle, toggle)
end

function SET_VEHICLE_DOORS_LOCKED_FOR_TEAM(vehicle, team, toggle)
    Velora.invoke(0xB1C230, "void", vehicle, team, toggle)
end

function SET_VEHICLE_DOORS_LOCKED_FOR_ALL_TEAMS(vehicle, toggle)
    Velora.invoke(0xB1C2B0, "void", vehicle, toggle)
end

function SET_VEHICLE_DONT_TERMINATE_TASK_WHEN_ACHIEVED(vehicle)
    Velora.invoke(0xB1C310, "void", vehicle)
end

function EXPLODE_VEHICLE(vehicle, isAudible, isInvisible)
    Velora.invoke(0xB1C3F0, "void", vehicle, isAudible, isInvisible)
end

function SET_VEHICLE_OUT_OF_CONTROL(vehicle, killDriver, explodeOnImpact)
    Velora.invoke(0xB1C4A0, "void", vehicle, killDriver, explodeOnImpact)
end

function SET_VEHICLE_TIMED_EXPLOSION(vehicle, ped, toggle)
    Velora.invoke(0xB1C580, "void", vehicle, ped, toggle)
end

function ADD_VEHICLE_PHONE_EXPLOSIVE_DEVICE(vehicle)
    Velora.invoke(0xB1C5A0, "void", vehicle)
end

function CLEAR_VEHICLE_PHONE_EXPLOSIVE_DEVICE()
    Velora.invoke(0xB1C620, "void")
end

function HAS_VEHICLE_PHONE_EXPLOSIVE_DEVICE(DETONATE_VEHICLE_PHONE_EXPLOSIVE_DEVICE()
    return Velora.invoke(0xB1C6D0, "bool", DETONATE_VEHICLE_PHONE_EXPLOSIVE_DEVICE()
end

function SET_TAXI_LIGHTS(vehicle, state)
    Velora.invoke(0xB1C740, "void", vehicle, state)
end

function IS_TAXI_LIGHT_ON(invoke<BOOL>(0xB1C7D0, garageName, invoke<BOOL>(0xB1C840, vehicle, colorPrimary, colorSecondary)
    return Velora.invoke(0xB1C8B0, "bool", invoke<BOOL>(0xB1C7D0, garageName, invoke<BOOL>(0xB1C840, vehicle, colorPrimary, colorSecondary)
end

function SET_VEHICLE_FULLBEAM(vehicle, toggle)
    Velora.invoke(0xB1C950, "void", vehicle, toggle)
end

function SET_VEHICLE_IS_RACING(vehicle, toggle)
    Velora.invoke(0xB1C9F0, "void", vehicle, toggle)
end

function SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle, r, g, b)
    Velora.invoke(0xB1CAA0, "void", vehicle, r, g, b)
end

function GET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle, r, g, b)
    Velora.invoke(0xB1CB70, "void", vehicle, r, g, b)
end

function CLEAR_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle)
    Velora.invoke(0xB1CBF0, "void", vehicle)
end

function GET_IS_VEHICLE_PRIMARY_COLOUR_CUSTOM(invoke<BOOL>(0xB1CC40, vehicle, r, g, b)
    return Velora.invoke(0xB1CCA0, "bool", invoke<BOOL>(0xB1CC40, vehicle, r, g, b)
end

function GET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle, r, g, b)
    Velora.invoke(0xB1CD70, "void", vehicle, r, g, b)
end

function CLEAR_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle)
    Velora.invoke(0xB1CDF0, "void", vehicle)
end

function GET_IS_VEHICLE_SECONDARY_COLOUR_CUSTOM(invoke<BOOL>(0xB1CE40, vehicle, fade)
    return Velora.invoke(0xB1CEA0, "bool", invoke<BOOL>(0xB1CE40, vehicle, fade)
end

function GET_VEHICLE_ENVEFF_SCALE(invoke<float>(0xB1CF10, vehicle, state)
    return Velora.invoke(0xB1CF90, "float", invoke<float>(0xB1CF10, vehicle, state)
end

function SET_GOON_BOSS_VEHICLE(vehicle, toggle)
    Velora.invoke(0xB1D040, "void", vehicle, toggle)
end

function SET_OPEN_REAR_DOORS_ON_EXPLOSION(vehicle, toggle)
    Velora.invoke(0xB1D0A0, "void", vehicle, toggle)
end

function FORCE_SUBMARINE_SURFACE_MODE(vehicle, toggle)
    Velora.invoke(0xB1D100, "void", vehicle, toggle)
end

function FORCE_SUBMARINE_NEURTAL_BUOYANCY(p0, p1)
    Velora.invoke(0xB1D170, "void", p0, p1)
end

function SET_SUBMARINE_CRUSH_DEPTHS(vehicle, p1, depth1, depth2, depth3)
    Velora.invoke(0xB1D1D0, "void", vehicle, p1, depth1, depth2, depth3)
end

function GET_SUBMARINE_IS_UNDER_DESIGN_DEPTH(invoke<BOOL>(0xB1D270, invoke<int>(0xB1D2F0, p0, p1)
    return Velora.invoke(0xB1D350, "bool", invoke<BOOL>(0xB1D270, invoke<int>(0xB1D2F0, p0, p1)
end

function _SET_BOUNDS_AFFECT_WATER_PROBES(vehicle, toggle)
    Velora.invoke(0xB1D3B0, "void", vehicle, toggle)
end

function SET_BOAT_ANCHOR(vehicle, toggle)
    Velora.invoke(0xB1D410, "void", vehicle, toggle)
end

function CAN_ANCHOR_BOAT_HERE(invoke<BOOL>(0xB1D430, invoke<BOOL>(0xB1D4B0, vehicle, toggle)
    return Velora.invoke(0xB1D530, "bool", invoke<BOOL>(0xB1D430, invoke<BOOL>(0xB1D4B0, vehicle, toggle)
end

function SET_FORCE_LOW_LOD_ANCHOR_MODE(vehicle, p1)
    Velora.invoke(0xB1D550, "void", vehicle, p1)
end

function SET_BOAT_LOW_LOD_ANCHOR_DISTANCE(vehicle, value)
    Velora.invoke(0xB1D5B0, "void", vehicle, value)
end

function IS_BOAT_ANCHORED(invoke<BOOL>(0xB1D610, vehicle, toggle)
    return Velora.invoke(0xB1D680, "bool", invoke<BOOL>(0xB1D610, vehicle, toggle)
end

function SET_BOAT_WRECKED(vehicle)
    Velora.invoke(0xB1D6E0, "void", vehicle)
end

function SET_VEHICLE_SIREN(vehicle, toggle)
    Velora.invoke(0xB1D730, "void", vehicle, toggle)
end

function IS_VEHICLE_SIREN_ON(invoke<BOOL>(0xB1D790, invoke<BOOL>(0xB1D820, vehicle, toggle)
    return Velora.invoke(0xB1D8B0, "bool", invoke<BOOL>(0xB1D790, invoke<BOOL>(0xB1D820, vehicle, toggle)
end

function REMOVE_VEHICLE_STUCK_CHECK(vehicle)
    Velora.invoke(0xB1D950, "void", vehicle)
end

function GET_VEHICLE_COLOURS(vehicle, colorPrimary, colorSecondary)
    Velora.invoke(0xB1D970, "void", vehicle, colorPrimary, colorSecondary)
end

function IS_VEHICLE_SEAT_FREE(vehicle, seatIndex, invoke<BOOL>(0xB1D9D0, vehicle, seatIndex, invoke<Ped>(0xB1DA00, vehicle, invoke<Ped>(0xB1DA30, vehicle, lightsOn, invoke<BOOL>(0xB1DAB0, vehicle, wheelID, invoke<BOOL>(0xB1DB40, vehicle, speed)
    return Velora.invoke(0xB1DC20, "bool", vehicle, seatIndex, invoke<BOOL>(0xB1D9D0, vehicle, seatIndex, invoke<Ped>(0xB1DA00, vehicle, invoke<Ped>(0xB1DA30, vehicle, lightsOn, invoke<BOOL>(0xB1DAB0, vehicle, wheelID, invoke<BOOL>(0xB1DB40, vehicle, speed)
end

function SET_VEHICLE_FORWARD_SPEED_XY(vehicle, speed)
    Velora.invoke(0xB1DC90, "void", vehicle, speed)
end

function BRING_VEHICLE_TO_HALT(vehicle, distance, duration, p3)
    Velora.invoke(0xB1DD00, "void", vehicle, distance, duration, p3)
end

function SET_VEHICLE_STEER_FOR_BUILDINGS(vehicle, p1)
    Velora.invoke(0xB1DD20, "void", vehicle, p1)
end

function SET_VEHICLE_CAUSES_SWERVING(vehicle, toggle)
    Velora.invoke(0xB1DD80, "void", vehicle, toggle)
end

function SET_IGNORE_PLANES_SMALL_PITCH_CHANGE(p0, p1)
    Velora.invoke(0xB1DDF0, "void", p0, p1)
end

function STOP_BRINGING_VEHICLE_TO_HALT(vehicle)
    Velora.invoke(0xB1DE50, "void", vehicle)
end

function IS_VEHICLE_BEING_BROUGHT_TO_HALT(invoke<BOOL>(0xB1DEC0, forklift)
    return Velora.invoke(0xB1DF40, "bool", invoke<BOOL>(0xB1DEC0, forklift)
end

function SET_FORKLIFT_FORK_HEIGHT(vehicle, height)
    Velora.invoke(0xB1DF50, "void", vehicle, height)
end

function IS_ENTITY_ATTACHED_TO_HANDLER_FRAME(vehicle, invoke<BOOL>(0xB1DF60, invoke<BOOL>(0xB1DF90, invoke<Vehicle>(0xB1E050, vehicle, invoke<BOOL>(0xB1E070, vehicle, entity)
    return Velora.invoke(0xB1E0A0, "bool", vehicle, invoke<BOOL>(0xB1DF60, invoke<BOOL>(0xB1DF90, invoke<Vehicle>(0xB1E050, vehicle, invoke<BOOL>(0xB1E070, vehicle, entity)
end

function DETACH_CONTAINER_FROM_HANDLER_FRAME(vehicle)
    Velora.invoke(0xB1E0B0, "void", vehicle)
end

function SET_VEHICLE_DISABLE_HEIGHT_MAP_AVOIDANCE(vehicle, p1)
    Velora.invoke(0xB1E0C0, "void", vehicle, p1)
end

function SET_BOAT_DISABLE_AVOIDANCE(vehicle, p1)
    Velora.invoke(0xB1E1B0, "void", vehicle, p1)
end

function IS_HELI_LANDING_AREA_BLOCKED(invoke<BOOL>(0xB1E210, vehicle)
    return Velora.invoke(0xB1E280, "bool", invoke<BOOL>(0xB1E210, vehicle)
end

function SET_HELI_TURBULENCE_SCALAR(vehicle, p1)
    Velora.invoke(0xB1E2F0, "void", vehicle, p1)
end

function SET_CAR_BOOT_OPEN(vehicle)
    Velora.invoke(0xB1E350, "void", vehicle)
end

function SET_VEHICLE_TYRE_BURST(vehicle, index, onRim, p3)
    Velora.invoke(0xB1E3C0, "void", vehicle, index, onRim, p3)
end

function SET_VEHICLE_DOORS_SHUT(vehicle, closeInstantly)
    Velora.invoke(0xB1E3E0, "void", vehicle, closeInstantly)
end

function SET_VEHICLE_TYRES_CAN_BURST(vehicle, toggle)
    Velora.invoke(0xB1E400, "void", vehicle, toggle)
end

function GET_VEHICLE_TYRES_CAN_BURST(invoke<BOOL>(0xB1E460, vehicle, enabled)
    return Velora.invoke(0xB1E4C0, "bool", invoke<BOOL>(0xB1E460, vehicle, enabled)
end

function SET_VEHICLE_DOOR_OPEN(vehicle, doorId, loose, openInstantly)
    Velora.invoke(0xB1E560, "void", vehicle, doorId, loose, openInstantly)
end

function SET_VEHICLE_DOOR_AUTO_LOCK(vehicle, doorId, toggle)
    Velora.invoke(0xB1E590, "void", vehicle, doorId, toggle)
end

function SET_FLEEING_VEHICLES_USE_SWITCHED_OFF_NODES(p0)
    Velora.invoke(0xB1E630, "void", p0)
end

function REMOVE_VEHICLE_WINDOW(vehicle, windowIndex)
    Velora.invoke(0xB1E650, "void", vehicle, windowIndex)
end

function ROLL_DOWN_WINDOWS(vehicle)
    Velora.invoke(0xB1E6D0, "void", vehicle)
end

function ROLL_DOWN_WINDOW(vehicle, windowIndex)
    Velora.invoke(0xB1E6E0, "void", vehicle, windowIndex)
end

function ROLL_UP_WINDOW(vehicle, windowIndex)
    Velora.invoke(0xB1E750, "void", vehicle, windowIndex)
end

function SMASH_VEHICLE_WINDOW(vehicle, windowIndex)
    Velora.invoke(0xB1E7C0, "void", vehicle, windowIndex)
end

function FIX_VEHICLE_WINDOW(vehicle, windowIndex)
    Velora.invoke(0xB1E7D0, "void", vehicle, windowIndex)
end

function POP_OUT_VEHICLE_WINDSCREEN(vehicle)
    Velora.invoke(0xB1E840, "void", vehicle)
end

function POP_OFF_VEHICLE_ROOF_WITH_IMPULSE(vehicle, x, y, z)
    Velora.invoke(0xB1E8A0, "void", vehicle, x, y, z)
end

function SET_VEHICLE_LIGHTS(vehicle, state)
    Velora.invoke(0xB1E950, "void", vehicle, state)
end

function SET_VEHICLE_USE_PLAYER_LIGHT_SETTINGS(vehicle, toggle)
    Velora.invoke(0xB1EA50, "void", vehicle, toggle)
end

function SET_VEHICLE_HEADLIGHT_SHADOWS(vehicle, p1)
    Velora.invoke(0xB1EAA0, "void", vehicle, p1)
end

function SET_VEHICLE_ALARM(vehicle, state)
    Velora.invoke(0xB1EB00, "void", vehicle, state)
end

function START_VEHICLE_ALARM(vehicle)
    Velora.invoke(0xB1EB50, "void", vehicle)
end

function IS_VEHICLE_ALARM_ACTIVATED(invoke<BOOL>(0xB1EBA0, vehicle, toggle)
    return Velora.invoke(0xB1EC10, "bool", invoke<BOOL>(0xB1EBA0, vehicle, toggle)
end

function SET_VEHICLE_FORCE_INTERIORLIGHT(vehicle, toggle)
    Velora.invoke(0xB1ECB0, "void", vehicle, toggle)
end

function SET_VEHICLE_LIGHT_MULTIPLIER(vehicle, multiplier)
    Velora.invoke(0xB1ED00, "void", vehicle, multiplier)
end

function ATTACH_VEHICLE_TO_TRAILER(vehicle, trailer, radius)
    Velora.invoke(0xB1ED50, "void", vehicle, trailer, radius)
end

function ATTACH_VEHICLE_ON_TO_TRAILER(vehicle, trailer, offsetX, offsetY, offsetZ, coordsX, coordsY, coordsZ, rotationX, rotationY, rotationZ, disableCollisions)
    Velora.invoke(0xB1EE30, "void", vehicle, trailer, offsetX, offsetY, offsetZ, coordsX, coordsY, coordsZ, rotationX, rotationY, rotationZ, disableCollisions)
end

function STABILISE_ENTITY_ATTACHED_TO_HELI(vehicle, entity, p2)
    Velora.invoke(0xB1EE50, "void", vehicle, entity, p2)
end

function DETACH_VEHICLE_FROM_TRAILER(vehicle)
    Velora.invoke(0xB1EF00, "void", vehicle)
end

function IS_VEHICLE_ATTACHED_TO_TRAILER(invoke<BOOL>(0xB1EF90, vehicle, p1)
    return Velora.invoke(0xB1F050, "bool", invoke<BOOL>(0xB1EF90, vehicle, p1)
end

function SET_TRAILER_LEGS_RAISED(vehicle)
    Velora.invoke(0xB1F0E0, "void", vehicle)
end

function SET_TRAILER_LEGS_LOWERED(vehicle)
    Velora.invoke(0xB1F140, "void", vehicle)
end

function SET_VEHICLE_TYRE_FIXED(vehicle, tyreIndex)
    Velora.invoke(0xB1F1A0, "void", vehicle, tyreIndex)
end

function SET_VEHICLE_NUMBER_PLATE_TEXT(vehicle, plateText)
    Velora.invoke(0xB1F230, "void", vehicle, plateText)
end

function GET_VEHICLE_NUMBER_PLATE_TEXT(char>(0xB1F280, vehicle, plateIndex)
    return Velora.invoke(0xB1F300, "string", char>(0xB1F280, vehicle, plateIndex)
end

function GET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(invoke<int>(0xB1F350, toggle)
    return Velora.invoke(0xB1F3B0, "int", invoke<int>(0xB1F350, toggle)
end

function CREATE_MISSION_TRAIN(variation, x, y, z, direction, p5, invoke<Vehicle>(0xB1F3D0, trackId, state)
    return Velora.invoke(0xB1F420, "int", variation, x, y, z, direction, p5, invoke<Vehicle>(0xB1F3D0, trackId, state)
end

function SET_TRAIN_TRACK_SPAWN_FREQUENCY(trackIndex, frequency)
    Velora.invoke(0xB1F450, "void", trackIndex, frequency)
end

function ALLOW_TRAIN_TO_BE_REMOVED_BY_POPULATION(p0)
    Velora.invoke(0xB1F480, "void", p0)
end

function DELETE_ALL_TRAINS()
    Velora.invoke(0xB1F4D0, "void")
end

function SET_TRAIN_SPEED(train, speed)
    Velora.invoke(0xB1F4E0, "void", train, speed)
end

function SET_TRAIN_CRUISE_SPEED(train, speed)
    Velora.invoke(0xB1F550, "void", train, speed)
end

function SET_RANDOM_BOATS(toggle)
    Velora.invoke(0xB1F5C0, "void", toggle)
end

function SET_RANDOM_BOATS_MP(toggle)
    Velora.invoke(0xB1F5E0, "void", toggle)
end

function SET_GARBAGE_TRUCKS(toggle)
    Velora.invoke(0xB1F600, "void", toggle)
end

function DOES_VEHICLE_HAVE_STUCK_VEHICLE_CHECK(invoke<BOOL>(0xB1F620, recording, invoke<int>(0xB1F6A0, recording, script)
    return Velora.invoke(0xB1F6D0, "bool", invoke<BOOL>(0xB1F620, recording, invoke<int>(0xB1F6A0, recording, script)
end

function HAS_VEHICLE_RECORDING_BEEN_LOADED(recording, invoke<BOOL>(0xB1F750, recording, script)
    return Velora.invoke(0xB1F790, "bool", recording, invoke<BOOL>(0xB1F750, recording, script)
end

function GET_POSITION_OF_VEHICLE_RECORDING_ID_AT_TIME(id, invoke<Vector3>(0xB1F7E0, recording, time, invoke<Vector3>(0xB1F870, id, invoke<Vector3>(0xB1F920, recording, time, invoke<Vector3>(0xB1F9B0, invoke<float>(0xB1FA60, recording, invoke<float>(0xB1FA90, invoke<float>(0xB1FAD0, invoke<float>(0xB1FB20, vehicle, recording, script, p3)
    local x, y, z = Velora.invoke(0xB1FB70, "vector3", id, invoke<Vector3>(0xB1F7E0, recording, time, invoke<Vector3>(0xB1F870, id, invoke<Vector3>(0xB1F920, recording, time, invoke<Vector3>(0xB1F9B0, invoke<float>(0xB1FA60, recording, invoke<float>(0xB1FA90, invoke<float>(0xB1FAD0, invoke<float>(0xB1FB20, vehicle, recording, script, p3)
    return {x = x, y = y, z = z}
end

function START_PLAYBACK_RECORDED_VEHICLE_WITH_FLAGS(vehicle, recording, script, flags, time, drivingStyle)
    Velora.invoke(0xB1FB90, "void", vehicle, recording, script, flags, time, drivingStyle)
end

function FORCE_PLAYBACK_RECORDED_VEHICLE_UPDATE(vehicle, p1)
    Velora.invoke(0xB1FBB0, "void", vehicle, p1)
end

function STOP_PLAYBACK_RECORDED_VEHICLE(vehicle)
    Velora.invoke(0xB1FBD0, "void", vehicle)
end

function PAUSE_PLAYBACK_RECORDED_VEHICLE(vehicle)
    Velora.invoke(0xB1FC20, "void", vehicle)
end

function UNPAUSE_PLAYBACK_RECORDED_VEHICLE(vehicle)
    Velora.invoke(0xB1FC70, "void", vehicle)
end

function IS_PLAYBACK_GOING_ON_FOR_VEHICLE(invoke<BOOL>(0xB1FCC0, invoke<BOOL>(0xB1FD20, invoke<int>(0xB1FD90, vehicle)
    return Velora.invoke(0xB1FDE0, "bool", invoke<BOOL>(0xB1FCC0, invoke<BOOL>(0xB1FD20, invoke<int>(0xB1FD90, vehicle)
end

function SET_PLAYBACK_SPEED(vehicle, speed)
    Velora.invoke(0xB1FE30, "void", vehicle, speed)
end

function START_PLAYBACK_RECORDED_VEHICLE_USING_AI(vehicle, recording, script, speed, drivingStyle)
    Velora.invoke(0xB1FE90, "void", vehicle, recording, script, speed, drivingStyle)
end

function SKIP_TIME_IN_PLAYBACK_RECORDED_VEHICLE(vehicle, time)
    Velora.invoke(0xB1FEB0, "void", vehicle, time)
end

function SET_PLAYBACK_TO_USE_AI(vehicle, drivingStyle)
    Velora.invoke(0xB1FF10, "void", vehicle, drivingStyle)
end

function SET_PLAYBACK_TO_USE_AI_TRY_TO_REVERT_BACK_LATER(vehicle, time, drivingStyle, p3)
    Velora.invoke(0xB1FF60, "void", vehicle, time, drivingStyle, p3)
end

function SET_ADDITIONAL_ROTATION_FOR_RECORDED_VEHICLE_PLAYBACK(vehicle, x, y, z, p4)
    Velora.invoke(0xB1FFD0, "void", vehicle, x, y, z, p4)
end

function SET_POSITION_OFFSET_FOR_RECORDED_VEHICLE_PLAYBACK(vehicle, x, y, z)
    Velora.invoke(0xB1FFF0, "void", vehicle, x, y, z)
end

function SET_GLOBAL_POSITION_OFFSET_FOR_RECORDED_VEHICLE_PLAYBACK(vehicle, x, y, z)
    Velora.invoke(0xB20050, "void", vehicle, x, y, z)
end

function SET_SHOULD_LERP_FROM_AI_TO_FULL_RECORDING(vehicle, p1)
    Velora.invoke(0xB200B0, "void", vehicle, p1)
end

function EXPLODE_VEHICLE_IN_CUTSCENE(vehicle, p1)
    Velora.invoke(0xB20150, "void", vehicle, p1)
end

function ADD_VEHICLE_STUCK_CHECK_WITH_WARP(p0, p1, p2, p3, p4, p5, p6)
    Velora.invoke(0xB201D0, "void", p0, p1, p2, p3, p4, p5, p6)
end

function SET_VEHICLE_MODEL_IS_SUPPRESSED(model, suppressed)
    Velora.invoke(0xB20280, "void", model, suppressed)
end

function GET_RANDOM_VEHICLE_IN_SPHERE(x, y, z, radius, modelHash, invoke<Vehicle>(0xB202A0, p0, p1, p2, p3, p4, p5, invoke<Vehicle>(0xB20320, p0, p1, p2, p3, p4, p5, invoke<Vehicle>(0xB203A0, x, y, z, radius, modelHash, invoke<Vehicle>(0xB20420, train, invoke<Vehicle>(0xB20450, invoke<BOOL>(0xB20540, train)
    return Velora.invoke(0xB205C0, "int", x, y, z, radius, modelHash, invoke<Vehicle>(0xB202A0, p0, p1, p2, p3, p4, p5, invoke<Vehicle>(0xB20320, p0, p1, p2, p3, p4, p5, invoke<Vehicle>(0xB203A0, x, y, z, radius, modelHash, invoke<Vehicle>(0xB20420, train, invoke<Vehicle>(0xB20450, invoke<BOOL>(0xB20540, train)
end

function SET_MISSION_TRAIN_AS_NO_LONGER_NEEDED(train, p1)
    Velora.invoke(0xB205D0, "void", train, p1)
end

function SET_MISSION_TRAIN_COORDS(train, x, y, z)
    Velora.invoke(0xB205E0, "void", train, x, y, z)
end

function IS_THIS_MODEL_A_BOAT(invoke<BOOL>(0xB20680, invoke<BOOL>(0xB20700, invoke<BOOL>(0xB20780, invoke<BOOL>(0xB20800, invoke<BOOL>(0xB20880, invoke<BOOL>(0xB20900, invoke<BOOL>(0xB20980, invoke<BOOL>(0xB20A00, invoke<BOOL>(0xB20A80, invoke<BOOL>(0xB20B00, invoke<BOOL>(0xB20B80, vehicle)
    return Velora.invoke(0xB20C00, "bool", invoke<BOOL>(0xB20680, invoke<BOOL>(0xB20700, invoke<BOOL>(0xB20780, invoke<BOOL>(0xB20800, invoke<BOOL>(0xB20880, invoke<BOOL>(0xB20900, invoke<BOOL>(0xB20980, invoke<BOOL>(0xB20A00, invoke<BOOL>(0xB20A80, invoke<BOOL>(0xB20B00, invoke<BOOL>(0xB20B80, vehicle)
end

function SET_HELI_BLADES_SPEED(vehicle, speed)
    Velora.invoke(0xB20CC0, "void", vehicle, speed)
end

function FORCE_SUB_THROTTLE_FOR_TIME(vehicle, p1, p2)
    Velora.invoke(0xB20DA0, "void", vehicle, p1, p2)
end

function SET_VEHICLE_CAN_BE_TARGETTED(vehicle, state)
    Velora.invoke(0xB20E30, "void", vehicle, state)
end

function SET_DONT_ALLOW_PLAYER_TO_ENTER_VEHICLE_IF_LOCKED_FOR_PLAYER(vehicle, p1)
    Velora.invoke(0xB20ED0, "void", vehicle, p1)
end

function SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(vehicle, state)
    Velora.invoke(0xB20FD0, "void", vehicle, state)
end

function SET_VEHICLE_HAS_UNBREAKABLE_LIGHTS(vehicle, toggle)
    Velora.invoke(0xB21070, "void", vehicle, toggle)
end

function SET_VEHICLE_RESPECTS_LOCKS_WHEN_HAS_DRIVER(vehicle, p1)
    Velora.invoke(0xB21110, "void", vehicle, p1)
end

function SET_VEHICLE_CAN_EJECT_PASSENGERS_IF_LOCKED(p0, p1)
    Velora.invoke(0xB211B0, "void", p0, p1)
end

function GET_VEHICLE_DIRT_LEVEL(invoke<float>(0xB21200, vehicle, dirtLevel)
    return Velora.invoke(0xB21250, "float", invoke<float>(0xB21200, vehicle, dirtLevel)
end

function GET_DOES_VEHICLE_HAVE_DAMAGE_DECALS(invoke<BOOL>(0xB212C0, vehicle, invoke<BOOL>(0xB21320, vehicle, value, instantly, disableAutoStart)
    return Velora.invoke(0xB213B0, "bool", invoke<BOOL>(0xB212C0, vehicle, invoke<BOOL>(0xB21320, vehicle, value, instantly, disableAutoStart)
end

function SET_VEHICLE_UNDRIVEABLE(vehicle, toggle)
    Velora.invoke(0xB213E0, "void", vehicle, toggle)
end

function SET_VEHICLE_PROVIDES_COVER(vehicle, toggle)
    Velora.invoke(0xB214B0, "void", vehicle, toggle)
end

function SET_VEHICLE_DOOR_CONTROL(vehicle, doorId, speed, angle)
    Velora.invoke(0xB21550, "void", vehicle, doorId, speed, angle)
end

function SET_VEHICLE_DOOR_LATCHED(vehicle, doorId, p2, p3, p4)
    Velora.invoke(0xB21570, "void", vehicle, doorId, p2, p3, p4)
end

function GET_VEHICLE_DOOR_ANGLE_RATIO(vehicle, invoke<float>(0xB215A0, vehicle, invoke<Ped>(0xB21640, vehicle, doorId, closeInstantly)
    return Velora.invoke(0xB21670, "float", vehicle, invoke<float>(0xB215A0, vehicle, invoke<Ped>(0xB21640, vehicle, doorId, closeInstantly)
end

function SET_VEHICLE_DOOR_BROKEN(vehicle, doorId, deleteDoor)
    Velora.invoke(0xB21690, "void", vehicle, doorId, deleteDoor)
end

function SET_VEHICLE_CAN_BREAK(vehicle, toggle)
    Velora.invoke(0xB216B0, "void", vehicle, toggle)
end

function DOES_VEHICLE_HAVE_ROOF(invoke<BOOL>(0xB21720, p0)
    return Velora.invoke(0xB21780, "bool", invoke<BOOL>(0xB21720, p0)
end

function SET_VEHICLE_AVOID_PLAYER_VEHICLE_RIOT_VAN_MISSION(p0)
    Velora.invoke(0xB217D0, "void", p0)
end

function SET_CARJACK_MISSION_REMOVAL_PARAMETERS(p0, p1)
    Velora.invoke(0xB21820, "void", p0, p1)
end

function IS_BIG_VEHICLE(invoke<BOOL>(0xB21840, invoke<int>(0xB218A0, vehicle, colorCombination)
    return Velora.invoke(0xB21910, "bool", invoke<BOOL>(0xB21840, invoke<int>(0xB218A0, vehicle, colorCombination)
end

function GET_VEHICLE_COLOUR_COMBINATION(invoke<int>(0xB21920, vehicle, colorIndex)
    return Velora.invoke(0xB21940, "int", invoke<int>(0xB21920, vehicle, colorIndex)
end

function GET_VEHICLE_XENON_LIGHT_COLOR_INDEX(invoke<int>(0xB21990, vehicle, toggle)
    return Velora.invoke(0xB219F0, "int", invoke<int>(0xB21990, vehicle, toggle)
end

function SET_VEHICLE_WILL_FORCE_OTHER_VEHICLES_TO_STOP(vehicle, toggle)
    Velora.invoke(0xB21A90, "void", vehicle, toggle)
end

function SET_VEHICLE_ACT_AS_IF_HAS_SIREN_ON(vehicle, p1)
    Velora.invoke(0xB21B30, "void", vehicle, p1)
end

function SET_VEHICLE_USE_MORE_RESTRICTIVE_SPAWN_CHECKS(vehicle, p1)
    Velora.invoke(0xB21B90, "void", vehicle, p1)
end

function SET_VEHICLE_MAY_BE_USED_BY_GOTO_POINT_ANY_MEANS(vehicle, p1)
    Velora.invoke(0xB21BF0, "void", vehicle, p1)
end

function GET_RANDOM_VEHICLE_MODEL_IN_MEMORY(p0, modelHash, successIndicator)
    Velora.invoke(0xB21C60, "void", p0, modelHash, successIndicator)
end

function GET_VEHICLE_DOOR_LOCK_STATUS(invoke<int>(0xB21C70, vehicle, invoke<int>(0xB21CC0, veh, invoke<BOOL>(0xB21D40, vehicle, doorId, isBreakable)
    return Velora.invoke(0xB21DF0, "int", invoke<int>(0xB21C70, vehicle, invoke<int>(0xB21CC0, veh, invoke<BOOL>(0xB21D40, vehicle, doorId, isBreakable)
end

function IS_VEHICLE_BUMPER_BOUNCING(vehicle, invoke<BOOL>(0xB21E90, vehicle, invoke<BOOL>(0xB21F20, x1, x2, y1, y2, z1, invoke<BOOL>(0xB21F50, invoke<BOOL>(0xB22000, invoke<int>(0xB22060, invoke<Hash>(0xB22080, vehicle, invoke<Hash>(0xB220E0, train, toggle)
    return Velora.invoke(0xB22160, "bool", vehicle, invoke<BOOL>(0xB21E90, vehicle, invoke<BOOL>(0xB21F20, x1, x2, y1, y2, z1, invoke<BOOL>(0xB21F50, invoke<BOOL>(0xB22000, invoke<int>(0xB22060, invoke<Hash>(0xB22080, vehicle, invoke<Hash>(0xB220E0, train, toggle)
end

function SET_VEHICLE_EXTRA_COLOURS(vehicle, pearlescentColor, wheelColor)
    Velora.invoke(0xB22180, "void", vehicle, pearlescentColor, wheelColor)
end

function GET_VEHICLE_EXTRA_COLOURS(vehicle, pearlescentColor, wheelColor)
    Velora.invoke(0xB22220, "void", vehicle, pearlescentColor, wheelColor)
end

function SET_VEHICLE_EXTRA_COLOUR_5(vehicle, color)
    Velora.invoke(0xB22280, "void", vehicle, color)
end

function GET_VEHICLE_EXTRA_COLOUR_5(vehicle, color)
    Velora.invoke(0xB222F0, "void", vehicle, color)
end

function SET_VEHICLE_EXTRA_COLOUR_6(vehicle, color)
    Velora.invoke(0xB22340, "void", vehicle, color)
end

function GET_VEHICLE_EXTRA_COLOUR_6(vehicle, color)
    Velora.invoke(0xB223B0, "void", vehicle, color)
end

function STOP_ALL_GARAGE_ACTIVITY()
    Velora.invoke(0xB22400, "void")
end

function SET_VEHICLE_FIXED(vehicle)
    Velora.invoke(0xB22410, "void", vehicle)
end

function SET_VEHICLE_DEFORMATION_FIXED(vehicle)
    Velora.invoke(0xB22480, "void", vehicle)
end

function SET_VEHICLE_CAN_ENGINE_MISSFIRE(vehicle, toggle)
    Velora.invoke(0xB224D0, "void", vehicle, toggle)
end

function SET_VEHICLE_CAN_LEAK_OIL(vehicle, toggle)
    Velora.invoke(0xB22580, "void", vehicle, toggle)
end

function SET_VEHICLE_CAN_LEAK_PETROL(vehicle, toggle)
    Velora.invoke(0xB22630, "void", vehicle, toggle)
end

function SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(vehicle, toggle)
    Velora.invoke(0xB226E0, "void", vehicle, toggle)
end

function SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(vehicle, toggle)
    Velora.invoke(0xB22790, "void", vehicle, toggle)
end

function SET_DISABLE_VEHICLE_ENGINE_FIRES(vehicle, toggle)
    Velora.invoke(0xB22840, "void", vehicle, toggle)
end

function SET_VEHICLE_LIMIT_SPEED_WHEN_PLAYER_INACTIVE(vehicle, toggle)
    Velora.invoke(0xB228F0, "void", vehicle, toggle)
end

function SET_VEHICLE_STOP_INSTANTLY_WHEN_PLAYER_INACTIVE(vehicle, toggle)
    Velora.invoke(0xB229A0, "void", vehicle, toggle)
end

function SET_DISABLE_PRETEND_OCCUPANTS(vehicle, toggle)
    Velora.invoke(0xB22A40, "void", vehicle, toggle)
end

function REMOVE_VEHICLES_FROM_GENERATORS_IN_AREA(x1, y1, z1, x2, y2, z2, p6)
    Velora.invoke(0xB22AF0, "void", x1, y1, z1, x2, y2, z2, p6)
end

function SET_VEHICLE_STEER_BIAS(vehicle, value)
    Velora.invoke(0xB22B10, "void", vehicle, value)
end

function IS_VEHICLE_EXTRA_TURNED_ON(vehicle, invoke<BOOL>(0xB22B60, vehicle, extraId, disable)
    return Velora.invoke(0xB22BD0, "bool", vehicle, invoke<BOOL>(0xB22B60, vehicle, extraId, disable)
end

function DOES_EXTRA_EXIST(vehicle, invoke<BOOL>(0xB22BF0, vehicle, invoke<BOOL>(0xB22C80, vehicle, p1)
    return Velora.invoke(0xB22D30, "bool", vehicle, invoke<BOOL>(0xB22BF0, vehicle, invoke<BOOL>(0xB22C80, vehicle, p1)
end

function LOWER_CONVERTIBLE_ROOF(vehicle, instantlyLower)
    Velora.invoke(0xB22DA0, "void", vehicle, instantlyLower)
end

function RAISE_CONVERTIBLE_ROOF(vehicle, instantlyRaise)
    Velora.invoke(0xB22DF0, "void", vehicle, instantlyRaise)
end

function GET_CONVERTIBLE_ROOF_STATE(invoke<int>(0xB22E40, vehicle, invoke<BOOL>(0xB22EA0, vehicle, invoke<BOOL>(0xB22F20, vehicle, noAnimation)
    return Velora.invoke(0xB22F70, "int", invoke<int>(0xB22E40, vehicle, invoke<BOOL>(0xB22EA0, vehicle, invoke<BOOL>(0xB22F20, vehicle, noAnimation)
end

function IS_VEHICLE_IN_SUBMARINE_MODE(invoke<BOOL>(0xB22FC0, invoke<BOOL>(0xB23020, vehicle, xOffset, yOffset, zOffset, damage, radius, focusOnModel)
    return Velora.invoke(0xB230C0, "bool", invoke<BOOL>(0xB22FC0, invoke<BOOL>(0xB23020, vehicle, xOffset, yOffset, zOffset, damage, radius, focusOnModel)
end

function SET_VEHICLE_OCCUPANTS_TAKE_EXPLOSIVE_DAMAGE(vehicle, toggle)
    Velora.invoke(0xB230F0, "void", vehicle, toggle)
end

function GET_VEHICLE_ENGINE_HEALTH(invoke<float>(0xB23140, vehicle, health)
    return Velora.invoke(0xB231A0, "float", invoke<float>(0xB23140, vehicle, health)
end

function SET_PLANE_ENGINE_HEALTH(vehicle, health)
    Velora.invoke(0xB232A0, "void", vehicle, health)
end

function GET_VEHICLE_PETROL_TANK_HEALTH(invoke<float>(0xB23340, vehicle, health)
    return Velora.invoke(0xB233A0, "float", invoke<float>(0xB23340, vehicle, health)
end

function IS_VEHICLE_STUCK_TIMER_UP(vehicle, p1, invoke<BOOL>(0xB233F0, vehicle, nullAttributes)
    return Velora.invoke(0xB23480, "bool", vehicle, p1, invoke<BOOL>(0xB233F0, vehicle, nullAttributes)
end

function IS_VEHICLE_DRIVEABLE(vehicle, invoke<BOOL>(0xB234D0, vehicle, owned)
    return Velora.invoke(0xB23560, "bool", vehicle, invoke<BOOL>(0xB234D0, vehicle, owned)
end

function SET_VEHICLE_NEEDS_TO_BE_HOTWIRED(vehicle, toggle)
    Velora.invoke(0xB23600, "void", vehicle, toggle)
end

function SET_VEHICLE_BLIP_THROTTLE_RANDOMLY(vehicle, p1)
    Velora.invoke(0xB236A0, "void", vehicle, p1)
end

function SET_POLICE_FOCUS_WILL_TRACK_VEHICLE(vehicle, toggle)
    Velora.invoke(0xB23740, "void", vehicle, toggle)
end

function START_VEHICLE_HORN(vehicle, duration, mode, forever)
    Velora.invoke(0xB237E0, "void", vehicle, duration, mode, forever)
end

function SET_VEHICLE_IN_CAR_MOD_SHOP(vehicle, toggle)
    Velora.invoke(0xB238B0, "void", vehicle, toggle)
end

function SET_VEHICLE_HAS_STRONG_AXLES(vehicle, toggle)
    Velora.invoke(0xB23910, "void", vehicle, toggle)
end

function GET_DISPLAY_NAME_FROM_VEHICLE_MODEL(char>(0xB239B0, char>(0xB23A30, vehicle, offsetX, offsetY, invoke<Vector3>(0xB23AB0, vehicle, livery)
    return Velora.invoke(0xB23B80, "string", char>(0xB239B0, char>(0xB23A30, vehicle, offsetX, offsetY, invoke<Vector3>(0xB23AB0, vehicle, livery)
end

function GET_VEHICLE_LIVERY(invoke<int>(0xB23BE0, invoke<int>(0xB23C40, vehicle, livery)
    return Velora.invoke(0xB23CA0, "int", invoke<int>(0xB23BE0, invoke<int>(0xB23C40, vehicle, livery)
end

function GET_VEHICLE_LIVERY2(invoke<int>(0xB23D00, invoke<int>(0xB23D60, vehicle, invoke<BOOL>(0xB23DC0, invoke<BOOL>(0xB23E40, invoke<BOOL>(0xB23EA0, vehicle, toggle)
    return Velora.invoke(0xB23F10, "int", invoke<int>(0xB23D00, invoke<int>(0xB23D60, vehicle, invoke<BOOL>(0xB23DC0, invoke<BOOL>(0xB23E40, invoke<BOOL>(0xB23EA0, vehicle, toggle)
end

function IS_HELI_PART_BROKEN(vehicle, p1, p2, invoke<BOOL>(0xB23F90, invoke<float>(0xB24040, invoke<float>(0xB240C0, invoke<float>(0xB24140, vehicle, health)
    return Velora.invoke(0xB241C0, "bool", vehicle, p1, p2, invoke<BOOL>(0xB23F90, invoke<float>(0xB24040, invoke<float>(0xB240C0, invoke<float>(0xB24140, vehicle, health)
end

function SET_HELI_TAIL_ROTOR_HEALTH(vehicle, health)
    Velora.invoke(0xB24220, "void", vehicle, health)
end

function SET_HELI_TAIL_BOOM_CAN_BREAK_OFF(vehicle, invoke<BOOL>(0xB24280, vehicle, name)
    return Velora.invoke(0xB242D0, "bool", vehicle, invoke<BOOL>(0xB24280, vehicle, name)
end

function SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE(vehicle, toggle)
    Velora.invoke(0xB242E0, "void", vehicle, toggle)
end

function SET_VEHICLE_EXPLODES_ON_EXPLOSION_DAMAGE_AT_ZERO_BODY_HEALTH(vehicle, toggle)
    Velora.invoke(0xB24380, "void", vehicle, toggle)
end

function SET_ALLOW_VEHICLE_EXPLODES_ON_CONTACT(vehicle, toggle)
    Velora.invoke(0xB243D0, "void", vehicle, toggle)
end

function SET_VEHICLE_DISABLE_TOWING(vehicle, toggle)
    Velora.invoke(0xB24470, "void", vehicle, toggle)
end

function GET_VEHICLE_HAS_LANDING_GEAR(invoke<BOOL>(0xB24510, vehicle, state)
    return Velora.invoke(0xB24570, "bool", invoke<BOOL>(0xB24510, vehicle, state)
end

function GET_LANDING_GEAR_STATE(invoke<int>(0xB245F0, x, y, z, invoke<BOOL>(0xB24670, vehicle)
    return Velora.invoke(0xB24770, "int", invoke<int>(0xB245F0, x, y, z, invoke<BOOL>(0xB24670, vehicle)
end

function REMOVE_VEHICLE_HIGH_DETAIL_MODEL(vehicle)
    Velora.invoke(0xB24940, "void", vehicle)
end

function IS_VEHICLE_HIGH_DETAIL(invoke<BOOL>(0xB24980, vehicleHash, vehicleAsset)
    return Velora.invoke(0xB249E0, "bool", invoke<BOOL>(0xB24980, vehicleHash, vehicleAsset)
end

function HAS_VEHICLE_ASSET_LOADED(invoke<BOOL>(0xB24A90, vehicleAsset)
    return Velora.invoke(0xB24AC0, "bool", invoke<BOOL>(0xB24A90, vehicleAsset)
end

function SET_VEHICLE_TOW_TRUCK_ARM_POSITION(vehicle, position)
    Velora.invoke(0xB24B40, "void", vehicle, position)
end

function ATTACH_VEHICLE_TO_TOW_TRUCK(towTruck, vehicle, rear, hookOffsetX, hookOffsetY, hookOffsetZ)
    Velora.invoke(0xB24BF0, "void", towTruck, vehicle, rear, hookOffsetX, hookOffsetY, hookOffsetZ)
end

function DETACH_VEHICLE_FROM_TOW_TRUCK(towTruck, vehicle)
    Velora.invoke(0xB24C10, "void", towTruck, vehicle)
end

function DETACH_VEHICLE_FROM_ANY_TOW_TRUCK(invoke<BOOL>(0xB24C20, towTruck, invoke<BOOL>(0xB24C50, invoke<Entity>(0xB24C80, vehicle, p1, invoke<Entity>(0xB24D30, vehicle, position, p2)
    return Velora.invoke(0xB24DF0, "bool", invoke<BOOL>(0xB24C20, towTruck, invoke<BOOL>(0xB24C50, invoke<Entity>(0xB24C80, vehicle, p1, invoke<Entity>(0xB24D30, vehicle, position, p2)
end

function SET_VEHICLE_TANK_TURRET_POSITION(vehicle, position, p2)
    Velora.invoke(0xB24E10, "void", vehicle, position, p2)
end

function SET_VEHICLE_TURRET_TARGET(vehicle, p1, x, y, z, p5)
    Velora.invoke(0xB24E30, "void", vehicle, p1, x, y, z, p5)
end

function SET_VEHICLE_TANK_STATIONARY(vehicle, p1)
    Velora.invoke(0xB24E50, "void", vehicle, p1)
end

function SET_VEHICLE_TURRET_SPEED_THIS_FRAME(vehicle, speed)
    Velora.invoke(0xB24EB0, "void", vehicle, speed)
end

function DISABLE_VEHICLE_TURRET_MOVEMENT_THIS_FRAME(vehicle)
    Velora.invoke(0xB24EC0, "void", vehicle)
end

function SET_VEHICLE_FLIGHT_NOZZLE_POSITION(vehicle, angleRatio)
    Velora.invoke(0xB24ED0, "void", vehicle, angleRatio)
end

function SET_VEHICLE_FLIGHT_NOZZLE_POSITION_IMMEDIATE(vehicle, angle)
    Velora.invoke(0xB24F40, "void", vehicle, angle)
end

function GET_VEHICLE_FLIGHT_NOZZLE_POSITION(invoke<float>(0xB24FB0, vehicle, toggle)
    return Velora.invoke(0xB25020, "float", invoke<float>(0xB24FB0, vehicle, toggle)
end

function GENERATE_VEHICLE_CREATION_POS_FROM_PATHS(outVec, p1, outVec1, p3, p4, p5, p6, p7, invoke<BOOL>(0xB25080, vehicle, toggle)
    return Velora.invoke(0xB25170, "bool", outVec, p1, outVec1, p3, p4, p5, p6, p7, invoke<BOOL>(0xB25080, vehicle, toggle)
end

function IS_VEHICLE_IN_BURNOUT(invoke<BOOL>(0xB251D0, vehicle, toggle)
    return Velora.invoke(0xB25240, "bool", invoke<BOOL>(0xB251D0, vehicle, toggle)
end

function SET_VEHICLE_REDUCE_GRIP_LEVEL(vehicle, val)
    Velora.invoke(0xB252C0, "void", vehicle, val)
end

function SET_VEHICLE_INDICATOR_LIGHTS(vehicle, turnSignal, toggle)
    Velora.invoke(0xB25320, "void", vehicle, turnSignal, toggle)
end

function SET_VEHICLE_BRAKE_LIGHTS(vehicle, toggle)
    Velora.invoke(0xB25430, "void", vehicle, toggle)
end

function SET_VEHICLE_TAIL_LIGHTS(vehicle, toggle)
    Velora.invoke(0xB254D0, "void", vehicle, toggle)
end

function SET_VEHICLE_HANDBRAKE(vehicle, toggle)
    Velora.invoke(0xB25530, "void", vehicle, toggle)
end

function SET_VEHICLE_BRAKE(vehicle, toggle)
    Velora.invoke(0xB25600, "void", vehicle, toggle)
end

function INSTANTLY_FILL_VEHICLE_POPULATION()
    Velora.invoke(0xB25650, "void")
end

function HAS_INSTANT_FILL_VEHICLE_POPULATION_FINISHED(toggle)
    return Velora.invoke(0xB25680, "bool", toggle)
end

function NETWORK_CAP_EMPTY_CROWDING_VEHICLES_REMOVAL(p0)
    Velora.invoke(0xB256A0, "void", p0)
end

function GET_VEHICLE_TRAILER_VEHICLE(vehicle, invoke<BOOL>(0xB256B0, invoke<Vehicle>(0xB25780, vehicle, toggle)
    return Velora.invoke(0xB257F0, "bool", vehicle, invoke<BOOL>(0xB256B0, invoke<Vehicle>(0xB25780, vehicle, toggle)
end

function SET_VEHICLE_RUDDER_BROKEN(vehicle, toggle)
    Velora.invoke(0xB25890, "void", vehicle, toggle)
end

function SET_CONVERTIBLE_ROOF_LATCH_STATE(vehicle, state)
    Velora.invoke(0xB25A10, "void", vehicle, state)
end

function GET_VEHICLE_ESTIMATED_MAX_SPEED(invoke<float>(0xB25A70, invoke<float>(0xB25AA0, invoke<float>(0xB25AD0, invoke<float>(0xB25B00, invoke<float>(0xB25B30, invoke<float>(0xB25BE0, invoke<float>(0xB25CB0, invoke<float>(0xB25D90, invoke<float>(0xB25E70, invoke<float>(0xB25F30, invoke<float>(0xB25F60, invoke<float>(0xB25F90, invoke<float>(0xB26050, invoke<float>(0xB26090, invoke<float>(0xB260E0, invoke<float>(0xB26130, invoke<float>(0xB26180, x, y, z, radius, speed, invoke<int>(0xB261D0, invoke<BOOL>(0xB26280, vehicle)
    return Velora.invoke(0xB262C0, "float", invoke<float>(0xB25A70, invoke<float>(0xB25AA0, invoke<float>(0xB25AD0, invoke<float>(0xB25B00, invoke<float>(0xB25B30, invoke<float>(0xB25BE0, invoke<float>(0xB25CB0, invoke<float>(0xB25D90, invoke<float>(0xB25E70, invoke<float>(0xB25F30, invoke<float>(0xB25F60, invoke<float>(0xB25F90, invoke<float>(0xB26050, invoke<float>(0xB26090, invoke<float>(0xB260E0, invoke<float>(0xB26130, invoke<float>(0xB26180, x, y, z, radius, speed, invoke<int>(0xB261D0, invoke<BOOL>(0xB26280, vehicle)
end

function CLOSE_BOMB_BAY_DOORS(vehicle)
    Velora.invoke(0xB26340, "void", vehicle)
end

function GET_ARE_BOMB_BAY_DOORS_OPEN(invoke<BOOL>(0xB263C0, invoke<BOOL>(0xB26450, heli, toggle, canBeUsedByAI)
    return Velora.invoke(0xB26520, "bool", invoke<BOOL>(0xB263C0, invoke<BOOL>(0xB26450, heli, toggle, canBeUsedByAI)
end

function DOES_VEHICLE_HAVE_SEARCHLIGHT(invoke<BOOL>(0xB26540, ped, vehicle, seatIndex, side, invoke<BOOL>(0xB265F0, vehicle, invoke<Vector3>(0xB26630, vehicle, invoke<BOOL>(0xB26720, invoke<int>(0xB267D0, vehicle, modKit)
    return Velora.invoke(0xB26830, "bool", invoke<BOOL>(0xB26540, ped, vehicle, seatIndex, side, invoke<BOOL>(0xB265F0, vehicle, invoke<Vector3>(0xB26630, vehicle, invoke<BOOL>(0xB26720, invoke<int>(0xB267D0, vehicle, modKit)
end

function GET_VEHICLE_MOD_KIT(invoke<int>(0xB268A0, invoke<int>(0xB26900, invoke<int>(0xB26970, vehicle, WheelType)
    return Velora.invoke(0xB269D0, "int", invoke<int>(0xB268A0, invoke<int>(0xB26900, invoke<int>(0xB26970, vehicle, WheelType)
end

function GET_NUM_MOD_COLORS(paintType, invoke<int>(0xB26A70, vehicle, paintType, color, pearlescentColor)
    return Velora.invoke(0xB26B10, "int", paintType, invoke<int>(0xB26A70, vehicle, paintType, color, pearlescentColor)
end

function SET_VEHICLE_MOD_COLOR_2(vehicle, paintType, color)
    Velora.invoke(0xB26BA0, "void", vehicle, paintType, color)
end

function GET_VEHICLE_MOD_COLOR_1(vehicle, paintType, color, pearlescentColor)
    Velora.invoke(0xB26C30, "void", vehicle, paintType, color, pearlescentColor)
end

function GET_VEHICLE_MOD_COLOR_2(vehicle, paintType, color)
    Velora.invoke(0xB26CE0, "void", vehicle, paintType, color)
end

function GET_VEHICLE_MOD_COLOR_1_NAME(vehicle, char>(0xB26D80, char>(0xB26E10, invoke<BOOL>(0xB26E90, vehicle, modType, invoke<BOOL>(0xB26EF0, vehicle, modType, modIndex, customTires)
    return Velora.invoke(0xB26F80, "string", vehicle, char>(0xB26D80, char>(0xB26E10, invoke<BOOL>(0xB26E90, vehicle, modType, invoke<BOOL>(0xB26EF0, vehicle, modType, modIndex, customTires)
end

function GET_VEHICLE_MOD(vehicle, invoke<int>(0xB27060, vehicle, invoke<int>(0xB27140, vehicle, invoke<int>(0xB27210, vehicle, modType)
    return Velora.invoke(0xB272B0, "int", vehicle, invoke<int>(0xB27060, vehicle, invoke<int>(0xB27140, vehicle, invoke<int>(0xB27210, vehicle, modType)
end

function TOGGLE_VEHICLE_MOD(vehicle, modType, toggle)
    Velora.invoke(0xB27380, "void", vehicle, modType, toggle)
end

function IS_TOGGLE_MOD_ON(vehicle, invoke<BOOL>(0xB27410, vehicle, modType, char>(0xB27490, vehicle, char>(0xB27540, vehicle, char>(0xB275E0, vehicle, modType, invoke<int>(0xB27660, vehicle, modType, invoke<Hash>(0xB27690, vehicle, modType, modIndex)
    return Velora.invoke(0xB276C0, "bool", vehicle, invoke<BOOL>(0xB27410, vehicle, modType, char>(0xB27490, vehicle, char>(0xB27540, vehicle, char>(0xB275E0, vehicle, modType, invoke<int>(0xB27660, vehicle, modType, invoke<Hash>(0xB27690, vehicle, modType, modIndex)
end

function HAS_PRELOAD_MODS_FINISHED(invoke<BOOL>(0xB27760, vehicle)
    return Velora.invoke(0xB277C0, "bool", invoke<BOOL>(0xB27760, vehicle)
end

function SET_VEHICLE_TYRE_SMOKE_COLOR(vehicle, r, g, b)
    Velora.invoke(0xB27810, "void", vehicle, r, g, b)
end

function GET_VEHICLE_TYRE_SMOKE_COLOR(vehicle, r, g, b)
    Velora.invoke(0xB27870, "void", vehicle, r, g, b)
end

function SET_VEHICLE_WINDOW_TINT(vehicle, tint)
    Velora.invoke(0xB278E0, "void", vehicle, tint)
end

function GET_VEHICLE_WINDOW_TINT(invoke<int>(0xB27930, vehicle, r, g, b)
    return Velora.invoke(0xB279C0, "int", invoke<int>(0xB27930, vehicle, r, g, b)
end

function GET_VEHICLE_COLOURS_WHICH_CAN_BE_SET(invoke<int>(0xB279E0, invoke<Hash>(0xB27A00, vehicle, health)
    return Velora.invoke(0xB27A50, "int", invoke<int>(0xB279E0, invoke<Hash>(0xB27A00, vehicle, health)
end

function GET_IS_LEFT_VEHICLE_HEADLIGHT_DAMAGED(invoke<BOOL>(0xB27BC0, invoke<BOOL>(0xB27C40, invoke<BOOL>(0xB27CC0, vehicle, value)
    return Velora.invoke(0xB27D20, "bool", invoke<BOOL>(0xB27BC0, invoke<BOOL>(0xB27C40, invoke<BOOL>(0xB27CC0, vehicle, value)
end

function SET_VEHICLE_MAX_SPEED(vehicle, speed)
    Velora.invoke(0xB27D30, "void", vehicle, speed)
end

function SET_VEHICLE_STAYS_FROZEN_WHEN_CLEANED_UP(vehicle, toggle)
    Velora.invoke(0xB27D80, "void", vehicle, toggle)
end

function SET_VEHICLE_ACT_AS_IF_HIGH_SPEED_FOR_FRAG_SMASHING(vehicle, p1)
    Velora.invoke(0xB27E20, "void", vehicle, p1)
end

function SET_PEDS_CAN_FALL_OFF_THIS_VEHICLE_FROM_LARGE_FALL_DAMAGE(vehicle, toggle, p2)
    Velora.invoke(0xB27EB0, "void", vehicle, toggle, p2)
end

function ADD_VEHICLE_COMBAT_ANGLED_AVOIDANCE_AREA(p0, p1, p2, p3, p4, p5, invoke<int>(0xB27F80, p0)
    return Velora.invoke(0xB28020, "int", p0, p1, p2, p3, p4, p5, invoke<int>(0xB27F80, p0)
end

function IS_ANY_PED_RAPPELLING_FROM_HELI(invoke<BOOL>(0xB28060, vehicle, value)
    return Velora.invoke(0xB28090, "bool", invoke<BOOL>(0xB28060, vehicle, value)
end

function SET_VEHICLE_INFLUENCES_WANTED_LEVEL(p0, p1)
    Velora.invoke(0xB280E0, "void", p0, p1)
end

function SET_VEHICLE_IS_WANTED(vehicle, state)
    Velora.invoke(0xB28170, "void", vehicle, state)
end

function SWING_BOAT_BOOM_TO_RATIO(vehicle, ratio)
    Velora.invoke(0xB28210, "void", vehicle, ratio)
end

function SWING_BOAT_BOOM_FREELY(vehicle, toggle)
    Velora.invoke(0xB282B0, "void", vehicle, toggle)
end

function ALLOW_BOAT_BOOM_TO_ANIMATE(vehicle, toggle)
    Velora.invoke(0xB28350, "void", vehicle, toggle)
end

function GET_BOAT_BOOM_POSITION_RATIO(invoke<float>(0xB283F0, vehicle, p1, p2)
    return Velora.invoke(0xB28490, "float", invoke<float>(0xB283F0, vehicle, p1, p2)
end

function GET_IS_VEHICLE_ENGINE_RUNNING(invoke<BOOL>(0xB28510, vehicle, toggle)
    return Velora.invoke(0xB28570, "bool", invoke<BOOL>(0xB28510, vehicle, toggle)
end

function SET_BIKE_ON_STAND(vehicle, x, y)
    Velora.invoke(0xB28630, "void", vehicle, x, y)
end

function SET_VEHICLE_NOT_STEALABLE_AMBIENTLY(vehicle, p1)
    Velora.invoke(0xB286B0, "void", vehicle, p1)
end

function LOCK_DOORS_WHEN_NO_LONGER_NEEDED(vehicle)
    Velora.invoke(0xB28750, "void", vehicle)
end

function SET_LAST_DRIVEN_VEHICLE(vehicle)
    Velora.invoke(0xB287A0, "void", vehicle)
end

function GET_LAST_DRIVEN_VEHICLE(CLEAR_LAST_DRIVEN_VEHICLE()
    return Velora.invoke(0xB28820, "int", CLEAR_LAST_DRIVEN_VEHICLE()
end

function SET_VEHICLE_HAS_BEEN_DRIVEN_FLAG(vehicle, toggle)
    Velora.invoke(0xB28830, "void", vehicle, toggle)
end

function SET_TASK_VEHICLE_GOTO_PLANE_MIN_HEIGHT_ABOVE_TERRAIN(plane, height)
    Velora.invoke(0xB288D0, "void", plane, height)
end

function SET_VEHICLE_LOD_MULTIPLIER(vehicle, multiplier)
    Velora.invoke(0xB288E0, "void", vehicle, multiplier)
end

function SET_VEHICLE_CAN_SAVE_IN_GARAGE(vehicle, toggle)
    Velora.invoke(0xB28930, "void", vehicle, toggle)
end

function GET_VEHICLE_NUM_OF_BROKEN_OFF_PARTS(invoke<int>(0xB289D0, invoke<int>(0xB28A30, p0, p1)
    return Velora.invoke(0xB28A90, "int", invoke<int>(0xB289D0, invoke<int>(0xB28A30, p0, p1)
end

function SET_VEHICLE_GENERATES_ENGINE_SHOCKING_EVENTS(vehicle, toggle)
    Velora.invoke(0xB28B30, "void", vehicle, toggle)
end

function COPY_VEHICLE_DAMAGES(sourceVehicle, targetVehicle)
    Velora.invoke(0xB28BD0, "void", sourceVehicle, targetVehicle)
end

function DISABLE_VEHICLE_EXPLOSION_BREAK_OFF_PARTS()
    Velora.invoke(0xB28C60, "void")
end

function SET_LIGHTS_CUTOFF_DISTANCE_TWEAK(distance)
    Velora.invoke(0xB28C70, "void", distance)
end

function SET_VEHICLE_SHOOT_AT_TARGET(driver, entity, xTarget, yTarget, zTarget)
    Velora.invoke(0xB28C90, "void", driver, entity, xTarget, yTarget, zTarget)
end

function GET_VEHICLE_LOCK_ON_TARGET(vehicle, invoke<BOOL>(0xB28CB0, vehicle, toggle)
    return Velora.invoke(0xB28D20, "bool", vehicle, invoke<BOOL>(0xB28CB0, vehicle, toggle)
end

function SET_VEHICLE_CUSTOM_PATH_NODE_STREAMING_RADIUS(vehicle, p1)
    Velora.invoke(0xB28DC0, "void", vehicle, p1)
end

function GET_VEHICLE_PLATE_TYPE(invoke<int>(0xB28E20, vehicle)
    return Velora.invoke(0xB28E80, "int", invoke<int>(0xB28E20, vehicle)
end

function IS_VEHICLE_VISIBLE(invoke<BOOL>(0xB28EC0, vehicle, toggle)
    return Velora.invoke(0xB28F30, "bool", invoke<BOOL>(0xB28EC0, vehicle, toggle)
end

function SET_ENABLE_VEHICLE_SLIPSTREAMING(toggle)
    Velora.invoke(0xB28F90, "void", toggle)
end

function SET_VEHICLE_SLIPSTREAMING_SHOULD_TIME_OUT(toggle)
    Velora.invoke(0xB28FB0, "void", toggle)
end

function GET_VEHICLE_CURRENT_TIME_IN_SLIP_STREAM(invoke<float>(0xB28FD0, invoke<BOOL>(0xB29020, vehicle, toggle)
    return Velora.invoke(0xB29080, "float", invoke<float>(0xB28FD0, invoke<BOOL>(0xB29020, vehicle, toggle)
end

function SET_VEHICLE_ACTIVE_DURING_PLAYBACK(vehicle, toggle)
    Velora.invoke(0xB29190, "void", vehicle, toggle)
end

function IS_VEHICLE_SPRAYABLE(invoke<BOOL>(0xB29230, vehicle, toggle)
    return Velora.invoke(0xB29290, "bool", invoke<BOOL>(0xB29230, vehicle, toggle)
end

function DISABLE_VEHCILE_DYNAMIC_AMBIENT_SCALES(vehicle, p1, p2)
    Velora.invoke(0xB29340, "void", vehicle, p1, p2)
end

function ENABLE_VEHICLE_DYNAMIC_AMBIENT_SCALES(vehicle)
    Velora.invoke(0xB293C0, "void", vehicle)
end

function IS_PLANE_LANDING_GEAR_INTACT(invoke<BOOL>(0xB29400, invoke<BOOL>(0xB29480, plane, invoke<BOOL>(0xB294F0, vehicle, toggle)
    return Velora.invoke(0xB29560, "bool", invoke<BOOL>(0xB29400, invoke<BOOL>(0xB29480, plane, invoke<BOOL>(0xB294F0, vehicle, toggle)
end

function IS_VEHICLE_STOLEN(invoke<BOOL>(0xB29610, vehicle, isStolen)
    return Velora.invoke(0xB29670, "bool", invoke<BOOL>(0xB29610, vehicle, isStolen)
end

function SET_PLANE_TURBULENCE_MULTIPLIER(vehicle, multiplier)
    Velora.invoke(0xB29700, "void", vehicle, multiplier)
end

function ARE_WINGS_OF_PLANE_INTACT(invoke<BOOL>(0xB29780, vehicle)
    return Velora.invoke(0xB29810, "bool", invoke<BOOL>(0xB29780, vehicle)
end

function DETACH_VEHICLE_FROM_CARGOBOB(vehicle, cargobob)
    Velora.invoke(0xB29820, "void", vehicle, cargobob)
end

function DETACH_VEHICLE_FROM_ANY_CARGOBOB(invoke<BOOL>(0xB29830, cargobob, invoke<BOOL>(0xB29890, cargobob, invoke<BOOL>(0xB298A0, invoke<Vehicle>(0xB298D0, invoke<Entity>(0xB298F0, vehicle, cargobob, p2, x, y, z)
    return Velora.invoke(0xB29910, "bool", invoke<BOOL>(0xB29830, cargobob, invoke<BOOL>(0xB29890, cargobob, invoke<BOOL>(0xB298A0, invoke<Vehicle>(0xB298D0, invoke<Entity>(0xB298F0, vehicle, cargobob, p2, x, y, z)
end

function ATTACH_ENTITY_TO_CARGOBOB(p0, p1, p2, p3, p4, p5)
    Velora.invoke(0xB29930, "void", p0, p1, p2, p3, p4, p5)
end

function SET_CARGOBOB_FORCE_DONT_DETACH_VEHICLE(cargobob, toggle)
    Velora.invoke(0xB29950, "void", cargobob, toggle)
end

function SET_CARGOBOB_EXCLUDE_FROM_PICKUP_ENTITY(p0, p1)
    Velora.invoke(0xB29970, "void", p0, p1)
end

function CAN_CARGOBOB_PICK_UP_ENTITY(p0, invoke<BOOL>(0xB29980, invoke<Vector3>(0xB299B0, invoke<BOOL>(0xB29B10, cargobob, state)
    return Velora.invoke(0xB29BC0, "bool", p0, invoke<BOOL>(0xB29980, invoke<Vector3>(0xB299B0, invoke<BOOL>(0xB29B10, cargobob, state)
end

function REMOVE_PICK_UP_ROPE_FOR_CARGOBOB(cargobob)
    Velora.invoke(0xB29BD0, "void", cargobob)
end

function SET_PICKUP_ROPE_LENGTH_FOR_CARGOBOB(cargobob, length1, length2, p3)
    Velora.invoke(0xB29C30, "void", cargobob, length1, length2, p3)
end

function SET_PICKUP_ROPE_LENGTH_WITHOUT_CREATING_ROPE_FOR_CARGOBOB(p0, p1, p2)
    Velora.invoke(0xB29C50, "void", p0, p1, p2)
end

function SET_CARGOBOB_PICKUP_ROPE_DAMPING_MULTIPLIER(p0, p1)
    Velora.invoke(0xB29C70, "void", p0, p1)
end

function SET_CARGOBOB_PICKUP_ROPE_TYPE(p0, p1)
    Velora.invoke(0xB29C80, "void", p0, p1)
end

function DOES_CARGOBOB_HAVE_PICKUP_MAGNET(invoke<BOOL>(0xB29CE0, cargobob, isActive)
    return Velora.invoke(0xB29D90, "bool", invoke<BOOL>(0xB29CE0, cargobob, isActive)
end

function SET_CARGOBOB_PICKUP_MAGNET_STRENGTH(cargobob, strength)
    Velora.invoke(0xB29DB0, "void", cargobob, strength)
end

function SET_CARGOBOB_PICKUP_MAGNET_FALLOFF(cargobob, p1)
    Velora.invoke(0xB29E60, "void", cargobob, p1)
end

function SET_CARGOBOB_PICKUP_MAGNET_REDUCED_STRENGTH(cargobob, p1)
    Velora.invoke(0xB29F10, "void", cargobob, p1)
end

function SET_CARGOBOB_PICKUP_MAGNET_REDUCED_FALLOFF(cargobob, p1)
    Velora.invoke(0xB29FC0, "void", cargobob, p1)
end

function SET_CARGOBOB_PICKUP_MAGNET_PULL_STRENGTH(cargobob, p1)
    Velora.invoke(0xB2A070, "void", cargobob, p1)
end

function SET_CARGOBOB_PICKUP_MAGNET_PULL_ROPE_LENGTH(vehicle, p1)
    Velora.invoke(0xB2A120, "void", vehicle, p1)
end

function SET_CARGOBOB_PICKUP_MAGNET_SET_TARGETED_MODE(vehicle, cargobob)
    Velora.invoke(0xB2A1D0, "void", vehicle, cargobob)
end

function SET_CARGOBOB_PICKUP_MAGNET_SET_AMBIENT_MODE(vehicle, p1, p2)
    Velora.invoke(0xB2A1E0, "void", vehicle, p1, p2)
end

function SET_CARGOBOB_PICKUP_MAGNET_ENSURE_PICKUP_ENTITY_UPRIGHT(vehicle, p1)
    Velora.invoke(0xB2A200, "void", vehicle, p1)
end

function DOES_VEHICLE_HAVE_WEAPONS(invoke<BOOL>(0xB2A2A0, vehicle, p1)
    return Velora.invoke(0xB2A320, "bool", invoke<BOOL>(0xB2A2A0, vehicle, p1)
end

function DISABLE_VEHICLE_WEAPON(disabled, weaponHash, vehicle, owner)
    Velora.invoke(0xB2A380, "void", disabled, weaponHash, vehicle, owner)
end

function IS_VEHICLE_WEAPON_DISABLED(weaponHash, vehicle, invoke<BOOL>(0xB2A3A0, vehicle, toggle)
    return Velora.invoke(0xB2A3D0, "bool", weaponHash, vehicle, invoke<BOOL>(0xB2A3A0, vehicle, toggle)
end

function SET_VEHICLE_ACTIVE_FOR_PED_NAVIGATION(vehicle, toggle)
    Velora.invoke(0xB2A470, "void", vehicle, toggle)
end

function GET_VEHICLE_CLASS(invoke<int>(0xB2A530, invoke<int>(0xB2A590, vehicle)
    return Velora.invoke(0xB2A600, "int", invoke<int>(0xB2A530, invoke<int>(0xB2A590, vehicle)
end

function SET_VEHICLE_CAN_BE_USED_BY_FLEEING_PEDS(vehicle, toggle)
    Velora.invoke(0xB2A650, "void", vehicle, toggle)
end

function SET_AIRCRAFT_PILOT_SKILL_NOISE_SCALAR(vehicle, p1)
    Velora.invoke(0xB2A700, "void", vehicle, p1)
end

function SET_VEHICLE_DROPS_MONEY_WHEN_BLOWN_UP(vehicle, toggle)
    Velora.invoke(0xB2A7A0, "void", vehicle, toggle)
end

function SET_VEHICLE_KEEP_ENGINE_ON_WHEN_ABANDONED(vehicle, toggle)
    Velora.invoke(0xB2A820, "void", vehicle, toggle)
end

function SET_VEHICLE_IMPATIENCE_TIMER(vehicle, p1)
    Velora.invoke(0xB2A8C0, "void", vehicle, p1)
end

function SET_VEHICLE_HANDLING_OVERRIDE(vehicle, hash)
    Velora.invoke(0xB2A910, "void", vehicle, hash)
end

function SET_VEHICLE_EXTENDED_REMOVAL_RANGE(vehicle, range)
    Velora.invoke(0xB2A960, "void", vehicle, range)
end

function SET_VEHICLE_STEERING_BIAS_SCALAR(p0, p1)
    Velora.invoke(0xB2A9A0, "void", p0, p1)
end

function SET_HELI_CONTROL_LAGGING_RATE_SCALAR(helicopter, multiplier)
    Velora.invoke(0xB2AA00, "void", helicopter, multiplier)
end

function SET_VEHICLE_FRICTION_OVERRIDE(vehicle, friction)
    Velora.invoke(0xB2AA70, "void", vehicle, friction)
end

function SET_VEHICLE_WHEELS_CAN_BREAK_OFF_WHEN_BLOW_UP(vehicle, toggle)
    Velora.invoke(0xB2AAC0, "void", vehicle, toggle)
end

function ARE_PLANE_CONTROL_PANELS_INTACT(vehicle, invoke<BOOL>(0xB2AB60, vehicle, height)
    return Velora.invoke(0xB2ABD0, "bool", vehicle, invoke<BOOL>(0xB2AB60, vehicle, height)
end

function SET_VEHICLE_NO_EXPLOSION_DAMAGE_FROM_DRIVER(vehicle, toggle)
    Velora.invoke(0xB2AC40, "void", vehicle, toggle)
end

function CLEAR_VEHICLE_ROUTE_HISTORY(vehicle)
    Velora.invoke(0xB2AC90, "void", vehicle)
end

function DOES_VEHICLE_EXIST_WITH_DECORATOR(invoke<Vehicle>(0xB2ACE0, vehicle, toggle)
    return Velora.invoke(0xB2AD10, "int", invoke<Vehicle>(0xB2ACE0, vehicle, toggle)
end

function SET_VEHICLE_EXCLUSIVE_DRIVER(vehicle, ped, index)
    Velora.invoke(0xB2ADB0, "void", vehicle, ped, index)
end

function IS_PED_EXCLUSIVE_DRIVER_OF_VEHICLE(ped, vehicle, invoke<BOOL>(0xB2ADD0, vehicle, propeller)
    return Velora.invoke(0xB2AE90, "bool", ped, vehicle, invoke<BOOL>(0xB2ADD0, vehicle, propeller)
end

function SET_VEHICLE_FORCE_AFTERBURNER(vehicle, toggle)
    Velora.invoke(0xB2AF50, "void", vehicle, toggle)
end

function SET_DONT_PROCESS_VEHICLE_GLASS(vehicle, toggle)
    Velora.invoke(0xB2AFF0, "void", vehicle, toggle)
end

function SET_DISABLE_WANTED_CONES_RESPONSE(vehicle, toggle)
    Velora.invoke(0xB2B040, "void", vehicle, toggle)
end

function SET_USE_DESIRED_Z_CRUISE_SPEED_FOR_LANDING(vehicle, toggle)
    Velora.invoke(0xB2B090, "void", vehicle, toggle)
end

function SET_ARRIVE_DISTANCE_OVERRIDE_FOR_VEHICLE_PERSUIT_ATTACK(vehicle, p1)
    Velora.invoke(0xB2B0E0, "void", vehicle, p1)
end

function SET_VEHICLE_READY_FOR_CLEANUP(p0)
    Velora.invoke(0xB2B130, "void", p0)
end

function SET_DISTANT_CARS_ENABLED(toggle)
    Velora.invoke(0xB2B170, "void", toggle)
end

function SET_VEHICLE_NEON_COLOUR(vehicle, r, g, b)
    Velora.invoke(0xB2B190, "void", vehicle, r, g, b)
end

function SET_VEHICLE_NEON_INDEX_COLOUR(vehicle, index)
    Velora.invoke(0xB2B250, "void", vehicle, index)
end

function GET_VEHICLE_NEON_COLOUR(vehicle, r, g, b)
    Velora.invoke(0xB2B2E0, "void", vehicle, r, g, b)
end

function SET_VEHICLE_NEON_ENABLED(vehicle, index, toggle)
    Velora.invoke(0xB2B360, "void", vehicle, index, toggle)
end

function GET_VEHICLE_NEON_ENABLED(vehicle, invoke<BOOL>(0xB2B410, p0)
    return Velora.invoke(0xB2B4C0, "bool", vehicle, invoke<BOOL>(0xB2B410, p0)
end

function SUPPRESS_NEONS_ON_VEHICLE(vehicle, toggle)
    Velora.invoke(0xB2B4E0, "void", vehicle, toggle)
end

function SET_DISABLE_SUPERDUMMY(vehicle, p1)
    Velora.invoke(0xB2B530, "void", vehicle, p1)
end

function REQUEST_VEHICLE_DIAL(vehicle)
    Velora.invoke(0xB2B5C0, "void", vehicle)
end

function GET_VEHICLE_BODY_HEALTH(invoke<float>(0xB2B610, vehicle, value)
    return Velora.invoke(0xB2B670, "float", invoke<float>(0xB2B610, vehicle, value)
end

function GET_VEHICLE_SIZE(vehicle, out1, out2)
    Velora.invoke(0xB2B6F0, "void", vehicle, out1, out2)
end

function GET_FAKE_SUSPENSION_LOWERING_AMOUNT(invoke<float>(0xB2B790, multiplier)
    return Velora.invoke(0xB2B800, "float", invoke<float>(0xB2B790, multiplier)
end

function GET_NUMBER_OF_VEHICLE_DOORS(invoke<int>(0xB2B820, vehicle, toggle)
    return Velora.invoke(0xB2B870, "int", invoke<int>(0xB2B820, vehicle, toggle)
end

function SET_CAN_ADJUST_GROUND_CLEARANCE(vehicle, p1)
    Velora.invoke(0xB2B890, "void", vehicle, p1)
end

function GET_VEHICLE_HEALTH_PERCENTAGE(vehicle, maxEngineHealth, maxPetrolTankHealth, maxBodyHealth, maxMainRotorHealth, maxTailRotorHealth, invoke<float>(0xB2B920, invoke<BOOL>(0xB2B9E0, vehicle, p1)
    return Velora.invoke(0xB2BA40, "float", vehicle, maxEngineHealth, maxPetrolTankHealth, maxBodyHealth, maxMainRotorHealth, maxTailRotorHealth, invoke<float>(0xB2B920, invoke<BOOL>(0xB2B9E0, vehicle, p1)
end

function SET_VEHICLE_KERS_ALLOWED(vehicle, toggle)
    Velora.invoke(0xB2BA90, "void", vehicle, toggle)
end

function GET_VEHICLE_HAS_KERS(invoke<BOOL>(0xB2BAF0, vehicle, toggle)
    return Velora.invoke(0xB2BB50, "bool", invoke<BOOL>(0xB2BAF0, vehicle, toggle)
end

function SET_HELI_RESIST_TO_EXPLOSION(vehicle, toggle)
    Velora.invoke(0xB2BBF0, "void", vehicle, toggle)
end

function SET_DISABLE_BMX_EXTRA_TRICK_FORCES(p0)
    Velora.invoke(0xB2BCA0, "void", p0)
end

function SET_HYDRAULIC_SUSPENSION_RAISE_FACTOR(vehicle, wheelId, value)
    Velora.invoke(0xB2BCC0, "void", vehicle, wheelId, value)
end

function GET_HYDRAULIC_SUSPENSION_RAISE_FACTOR(vehicle, invoke<float>(0xB2BCE0, vehicle, toggle)
    return Velora.invoke(0xB2BDD0, "float", vehicle, invoke<float>(0xB2BCE0, vehicle, toggle)
end

function SET_HYDRAULIC_VEHICLE_STATE(vehicle, state)
    Velora.invoke(0xB2BDF0, "void", vehicle, state)
end

function SET_HYDRAULIC_WHEEL_STATE(vehicle, wheelId, state, value, p4)
    Velora.invoke(0xB2BE00, "void", vehicle, wheelId, state, value, p4)
end

function HAS_VEHICLE_PETROLTANK_SET_ON_FIRE_BY_ENTITY(p0, invoke<BOOL>(0xB2BE20, vehicle)
    return Velora.invoke(0xB2BEC0, "bool", p0, invoke<BOOL>(0xB2BE20, vehicle)
end

function SET_VEHICLE_BOBBLEHEAD_VELOCITY(x, y, p2)
    Velora.invoke(0xB2BF20, "void", x, y, p2)
end

function GET_VEHICLE_IS_DUMMY(invoke<BOOL>(0xB2BF80, vehicle, invoke<BOOL>(0xB2BFE0, vehicle, invoke<BOOL>(0xB2C080, p0, invoke<BOOL>(0xB2C0D0, p0, p1)
    return Velora.invoke(0xB2C120, "bool", invoke<BOOL>(0xB2BF80, vehicle, invoke<BOOL>(0xB2BFE0, vehicle, invoke<BOOL>(0xB2C080, p0, invoke<BOOL>(0xB2C0D0, p0, p1)
end

function SET_BIKE_EASY_TO_LAND(vehicle, toggle)
    Velora.invoke(0xB2C170, "void", vehicle, toggle)
end

function SET_INVERT_VEHICLE_CONTROLS(vehicle, state)
    Velora.invoke(0xB2C1C0, "void", vehicle, state)
end

function SET_SPEED_BOOST_EFFECT_DISABLED(disabled)
    Velora.invoke(0xB2C210, "void", disabled)
end

function SET_SLOW_DOWN_EFFECT_DISABLED(disabled)
    Velora.invoke(0xB2C230, "void", disabled)
end

function SET_FORMATION_LEADER(vehicle, x, y, z, p4)
    Velora.invoke(0xB2C250, "void", vehicle, x, y, z, p4)
end

function RESET_FORMATION_LEADER()
    Velora.invoke(0xB2C2F0, "void")
end

function GET_IS_BOAT_CAPSIZED(invoke<BOOL>(0xB2C300, p0, p1)
    return Velora.invoke(0xB2C360, "bool", invoke<BOOL>(0xB2C300, p0, p1)
end

function SET_SCRIPT_RAMP_IMPULSE_SCALE(vehicle, impulseScale)
    Velora.invoke(0xB2C3B0, "void", vehicle, impulseScale)
end

function GET_IS_DOOR_VALID(vehicle, invoke<BOOL>(0xB2C400, vehicle, seconds)
    return Velora.invoke(0xB2C480, "bool", vehicle, invoke<BOOL>(0xB2C400, vehicle, seconds)
end

function GET_HAS_ROCKET_BOOST(invoke<BOOL>(0xB2C550, invoke<BOOL>(0xB2C5B0, vehicle, active)
    return Velora.invoke(0xB2C620, "bool", invoke<BOOL>(0xB2C550, invoke<BOOL>(0xB2C5B0, vehicle, active)
end

function GET_HAS_RETRACTABLE_WHEELS(invoke<BOOL>(0xB2C640, invoke<BOOL>(0xB2C6A0, vehicle)
    return Velora.invoke(0xB2C710, "bool", invoke<BOOL>(0xB2C640, invoke<BOOL>(0xB2C6A0, vehicle)
end

function SET_WHEELS_RETRACTED_INSTANTLY(vehicle)
    Velora.invoke(0xB2C760, "void", vehicle)
end

function GET_CAR_HAS_JUMP(invoke<BOOL>(0xB2C7B0, vehicle, toggle)
    return Velora.invoke(0xB2C810, "bool", invoke<BOOL>(0xB2C7B0, vehicle, toggle)
end

function SET_CLEAR_FREEZE_WAITING_ON_COLLISION_ONCE_PLAYER_ENTERS(vehicle, toggle)
    Velora.invoke(0xB2C860, "void", vehicle, toggle)
end

function SET_VEHICLE_WEAPON_RESTRICTED_AMMO(vehicle, weaponIndex, capacity)
    Velora.invoke(0xB2C8B0, "void", vehicle, weaponIndex, capacity)
end

function GET_VEHICLE_WEAPON_RESTRICTED_AMMO(vehicle, invoke<int>(0xB2C910, invoke<BOOL>(0xB2C970, invoke<BOOL>(0xB2C9E0, vehicle, active)
    return Velora.invoke(0xB2CA50, "int", vehicle, invoke<int>(0xB2C910, invoke<BOOL>(0xB2C970, invoke<BOOL>(0xB2C9E0, vehicle, active)
end

function IS_VEHICLE_PARACHUTE_DEPLOYED(invoke<BOOL>(0xB2CAC0, vehicle, toggle)
    return Velora.invoke(0xB2CB30, "bool", invoke<BOOL>(0xB2CAC0, vehicle, toggle)
end

function VEHICLE_SET_ENABLE_RAMP_CAR_SIDE_IMPULSE(p0, p1)
    Velora.invoke(0xB2CBA0, "void", p0, p1)
end

function VEHICLE_SET_ENABLE_NORMALISE_RAMP_CAR_VERTICAL_VELOCTIY(p0, p1)
    Velora.invoke(0xB2CC00, "void", p0, p1)
end

function VEHICLE_SET_JET_WASH_FORCE_ENABLED(p0)
    Velora.invoke(0xB2CC60, "void", p0)
end

function SET_VEHICLE_WEAPON_CAN_TARGET_OBJECTS(vehicle, toggle)
    Velora.invoke(0xB2CC80, "void", vehicle, toggle)
end

function SET_VEHICLE_USE_BOOST_BUTTON_FOR_WHEEL_RETRACT(toggle)
    Velora.invoke(0xB2CCD0, "void", toggle)
end

function VEHICLE_SET_PARACHUTE_MODEL_OVERRIDE(vehicle, modelHash)
    Velora.invoke(0xB2CD10, "void", vehicle, modelHash)
end

function VEHICLE_SET_PARACHUTE_MODEL_TINT_INDEX(vehicle, textureVariation)
    Velora.invoke(0xB2CD70, "void", vehicle, textureVariation)
end

function VEHICLE_SET_OVERRIDE_EXTENABLE_SIDE_RATIO(p0, invoke<int>(0xB2CE00, p0, invoke<int>(0xB2CE10, p0, invoke<int>(0xB2CE20, invoke<int>(0xB2CE30, p0, p1)
    return Velora.invoke(0xB2CE60, "int", p0, invoke<int>(0xB2CE00, p0, invoke<int>(0xB2CE10, p0, invoke<int>(0xB2CE20, invoke<int>(0xB2CE30, p0, p1)
end

function SET_OVERRIDE_VEHICLE_DOOR_TORQUE(p0, p1, p2)
    Velora.invoke(0xB2CE70, "void", p0, p1, p2)
end

function SET_WHEELIE_ENABLED(vehicle, enabled)
    Velora.invoke(0xB2CF00, "void", vehicle, enabled)
end

function SET_DISABLE_HELI_EXPLODE_FROM_BODY_DAMAGE(p0, p1)
    Velora.invoke(0xB2CF50, "void", p0, p1)
end

function SET_DISABLE_EXPLODE_FROM_BODY_DAMAGE_ON_COLLISION(vehicle, value)
    Velora.invoke(0xB2CFB0, "void", vehicle, value)
end

function SET_TRAILER_ATTACHMENT_ENABLED(p0, p1)
    Velora.invoke(0xB2D050, "void", p0, p1)
end

function SET_ROCKET_BOOST_FILL(vehicle, percentage)
    Velora.invoke(0xB2D0A0, "void", vehicle, percentage)
end

function SET_GLIDER_ACTIVE(vehicle, state)
    Velora.invoke(0xB2D1A0, "void", vehicle, state)
end

function SET_SHOULD_RESET_TURRET_IN_SCRIPTED_CAMERAS(vehicle, shouldReset)
    Velora.invoke(0xB2D200, "void", vehicle, shouldReset)
end

function SET_VEHICLE_DISABLE_COLLISION_UPON_CREATION(vehicle, disable)
    Velora.invoke(0xB2D250, "void", vehicle, disable)
end

function SET_GROUND_EFFECT_REDUCES_DRAG(toggle)
    Velora.invoke(0xB2D2E0, "void", toggle)
end

function SET_DISABLE_MAP_COLLISION(vehicle)
    Velora.invoke(0xB2D300, "void", vehicle)
end

function SET_DISABLE_PED_STAND_ON_TOP(vehicle, toggle)
    Velora.invoke(0xB2D370, "void", vehicle, toggle)
end

function SET_VEHICLE_DAMAGE_SCALES(vehicle, p1, p2, p3, p4)
    Velora.invoke(0xB2D3C0, "void", vehicle, p1, p2, p3, p4)
end

function SET_PLANE_SECTION_DAMAGE_SCALE(vehicle, p1, p2)
    Velora.invoke(0xB2D450, "void", vehicle, p1, p2)
end

function SET_HELI_CAN_PICKUP_ENTITY_THAT_HAS_PICK_UP_DISABLED(vehicle, toggle)
    Velora.invoke(0xB2D520, "void", vehicle, toggle)
end

function SET_VEHICLE_BOMB_AMMO(vehicle, bombCount)
    Velora.invoke(0xB2D570, "void", vehicle, bombCount)
end

function GET_VEHICLE_BOMB_AMMO(invoke<int>(0xB2D5C0, vehicle, counterMeasureCount)
    return Velora.invoke(0xB2D620, "int", invoke<int>(0xB2D5C0, vehicle, counterMeasureCount)
end

function GET_VEHICLE_COUNTERMEASURE_AMMO(invoke<int>(0xB2D670, vehicle, x, y, z)
    return Velora.invoke(0xB2D6D0, "int", invoke<int>(0xB2D670, vehicle, x, y, z)
end

function GET_CAN_VEHICLE_BE_PLACED_HERE(vehicle, x, y, z, rotX, rotY, rotZ, p7, invoke<BOOL>(0xB2D760, vehicle, toggle)
    return Velora.invoke(0xB2D7A0, "bool", vehicle, x, y, z, rotX, rotY, rotZ, p7, invoke<BOOL>(0xB2D760, vehicle, toggle)
end

function SET_SPECIAL_FLIGHT_MODE_RATIO(vehicle, ratio)
    Velora.invoke(0xB2D820, "void", vehicle, ratio)
end

function SET_SPECIAL_FLIGHT_MODE_TARGET_RATIO(vehicle, targetRatio)
    Velora.invoke(0xB2D890, "void", vehicle, targetRatio)
end

function SET_SPECIAL_FLIGHT_MODE_ALLOWED(vehicle, toggle)
    Velora.invoke(0xB2D900, "void", vehicle, toggle)
end

function SET_DISABLE_HOVER_MODE_FLIGHT(vehicle, toggle)
    Velora.invoke(0xB2D960, "void", vehicle, toggle)
end

function GET_OUTRIGGERS_DEPLOYED(invoke<BOOL>(0xB2D9C0, invoke<Vector3>(0xB2DA30, vehicle, deploy, p2)
    return Velora.invoke(0xB2DAD0, "bool", invoke<BOOL>(0xB2D9C0, invoke<Vector3>(0xB2DA30, vehicle, deploy, p2)
end

function ARE_FOLDING_WINGS_DEPLOYED(invoke<BOOL>(0xB2DB40, vehicle, toggle)
    return Velora.invoke(0xB2DC50, "bool", invoke<BOOL>(0xB2DB40, vehicle, toggle)
end

function SET_TURRET_HIDDEN(vehicle, index, toggle)
    Velora.invoke(0xB2DCA0, "void", vehicle, index, toggle)
end

function SET_HOVER_MODE_WING_RATIO(vehicle, ratio)
    Velora.invoke(0xB2DD40, "void", vehicle, ratio)
end

function SET_DISABLE_TURRET_MOVEMENT(vehicle, turretId)
    Velora.invoke(0xB2DDA0, "void", vehicle, turretId)
end

function SET_FORCE_FIX_LINK_MATRICES(vehicle)
    Velora.invoke(0xB2DE30, "void", vehicle)
end

function SET_TRANSFORM_RATE_FOR_ANIMATION(vehicle, transformRate)
    Velora.invoke(0xB2DE70, "void", vehicle, transformRate)
end

function SET_TRANSFORM_TO_SUBMARINE_USES_ALTERNATE_INPUT(vehicle, toggle)
    Velora.invoke(0xB2DED0, "void", vehicle, toggle)
end

function SET_VEHICLE_COMBAT_MODE(toggle)
    Velora.invoke(0xB2DF40, "void", toggle)
end

function SET_VEHICLE_DETONATION_MODE(toggle)
    Velora.invoke(0xB2DF50, "void", toggle)
end

function SET_VEHICLE_SHUNT_ON_STICK(toggle)
    Velora.invoke(0xB2DF60, "void", toggle)
end

function GET_IS_VEHICLE_SHUNTING(invoke<BOOL>(0xB2DFE0, invoke<BOOL>(0xB2E050, invoke<Vehicle>(0xB2E0C0, toggle)
    return Velora.invoke(0xB2E120, "bool", invoke<BOOL>(0xB2DFE0, invoke<BOOL>(0xB2E050, invoke<Vehicle>(0xB2E0C0, toggle)
end

function SET_OVERRIDE_NITROUS_LEVEL(vehicle, toggle, level, power, rechargeTime, disableSound)
    Velora.invoke(0xB2E140, "void", vehicle, toggle, level, power, rechargeTime, disableSound)
end

function SET_INCREASE_WHEEL_CRUSH_DAMAGE(vehicle, toggle)
    Velora.invoke(0xB2E540, "void", vehicle, toggle)
end

function SET_DISABLE_WEAPON_BLADE_FORCES(toggle)
    Velora.invoke(0xB2E590, "void", toggle)
end

function SET_USE_DOUBLE_CLICK_FOR_CAR_JUMP(toggle)
    Velora.invoke(0xB2E5B0, "void", toggle)
end

function GET_DOES_VEHICLE_HAVE_TOMBSTONE(invoke<BOOL>(0xB2E5D0, vehicle, toggle)
    return Velora.invoke(0xB2E630, "bool", invoke<BOOL>(0xB2E5D0, vehicle, toggle)
end

function GET_IS_VEHICLE_DISABLED_BY_EMP(invoke<BOOL>(0xB2E6E0, toggle)
    return Velora.invoke(0xB2E740, "bool", invoke<BOOL>(0xB2E6E0, toggle)
end

function GET_TYRE_HEALTH(vehicle, invoke<float>(0xB2E760, vehicle, wheelIndex, health)
    return Velora.invoke(0xB2E7F0, "float", vehicle, invoke<float>(0xB2E760, vehicle, wheelIndex, health)
end

function GET_TYRE_WEAR_RATE(vehicle, invoke<float>(0xB2E8B0, vehicle, wheelIndex, multiplier)
    return Velora.invoke(0xB2E940, "float", vehicle, invoke<float>(0xB2E8B0, vehicle, wheelIndex, multiplier)
end

function SET_TYRE_WEAR_RATE_SCALE(vehicle, wheelIndex, multiplier)
    Velora.invoke(0xB2E9D0, "void", vehicle, wheelIndex, multiplier)
end

function SET_TYRE_MAXIMUM_GRIP_DIFFERENCE_DUE_TO_WEAR_RATE(vehicle, wheelIndex, multiplier)
    Velora.invoke(0xB2EA50, "void", vehicle, wheelIndex, multiplier)
end

function SET_AIRCRAFT_IGNORE_HIGHTMAP_OPTIMISATION(vehicle, p1)
    Velora.invoke(0xB2EAD0, "void", vehicle, p1)
end

function SET_REDUCED_SUSPENSION_FORCE(vehicle, enable)
    Velora.invoke(0xB2EB30, "void", vehicle, enable)
end

function SET_DRIFT_TYRES(vehicle, toggle)
    Velora.invoke(0xB2EB90, "void", vehicle, toggle)
end

function GET_DRIFT_TYRES_SET(invoke<BOOL>(0xB2EBE0, vehicle, toggle)
    return Velora.invoke(0xB2EC40, "bool", invoke<BOOL>(0xB2EBE0, vehicle, toggle)
end

function SET_CHECK_FOR_ENOUGH_ROOM_FOR_PED(vehicle, p1)
    Velora.invoke(0xB2ECA0, "void", vehicle, p1)
end

function GET_WATER_HEIGHT(x, y, z, invoke<BOOL>(0xB2F950, x, y, z, invoke<BOOL>(0xB2F980, x1, y1, z1, x2, y2, z2, invoke<BOOL>(0xB2FAF0, x1, y1, z1, x2, y2, z2, flags, invoke<int>(0xB2FB60, x, y, z, flags, invoke<int>(0xB2FC20, x, y, radius, height)
    return Velora.invoke(0xB2FD00, "bool", x, y, z, invoke<BOOL>(0xB2F950, x, y, z, invoke<BOOL>(0xB2F980, x1, y1, z1, x2, y2, z2, invoke<BOOL>(0xB2FAF0, x1, y1, z1, x2, y2, z2, flags, invoke<int>(0xB2FB60, x, y, z, flags, invoke<int>(0xB2FC20, x, y, radius, height)
end

function ADD_EXTRA_CALMING_QUAD(xLow, yLow, xHigh, yHigh, invoke<int>(0xB2FD20, calmingQuad)
    return Velora.invoke(0xB2FD60, "int", xLow, yLow, xHigh, yHigh, invoke<int>(0xB2FD20, calmingQuad)
end

function SET_DEEP_OCEAN_SCALER(intensity)
    Velora.invoke(0xB2FD70, "void", intensity)
end

function GET_DEEP_OCEAN_SCALER(height)
    return Velora.invoke(0xB2FDA0, "float", height)
end

function RESET_DEEP_OCEAN_SCALER()
    Velora.invoke(0xB2FDB0, "void")
end

function ENABLE_LASER_SIGHT_RENDERING(toggle)
    Velora.invoke(0xB38580, "void", toggle)
end

function GET_WEAPON_COMPONENT_TYPE_MODEL(invoke<Hash>(0xB385A0, invoke<Hash>(0xB38660, invoke<Hash>(0xB38730, invoke<Hash>(0xB387A0, invoke<int>(0xB38810, componentHash, invoke<Hash>(0xB388A0, ped, weaponHash, bForceInHand)
    return Velora.invoke(0xB38980, "int", invoke<Hash>(0xB385A0, invoke<Hash>(0xB38660, invoke<Hash>(0xB38730, invoke<Hash>(0xB387A0, invoke<int>(0xB38810, componentHash, invoke<Hash>(0xB388A0, ped, weaponHash, bForceInHand)
end

function GET_CURRENT_PED_WEAPON(ped, weaponHash, invoke<BOOL>(0xB389A0, ped, invoke<Entity>(0xB38A40, ped, invoke<Hash>(0xB38AB0, ped, invoke<BOOL>(0xB38B20, ped, invoke<BOOL>(0xB38B50, ped)
    return Velora.invoke(0xB38BD0, "bool", ped, weaponHash, invoke<BOOL>(0xB389A0, ped, invoke<Entity>(0xB38A40, ped, invoke<Hash>(0xB38AB0, ped, invoke<BOOL>(0xB38B20, ped, invoke<BOOL>(0xB38B50, ped)
end

function IS_PED_ARMED(ped, invoke<BOOL>(0xB38C10, invoke<BOOL>(0xB38C40, ped, weaponHash, invoke<BOOL>(0xB38CB0, invoke<BOOL>(0xB38CE0, ped, invoke<Hash>(0xB38D50, ped, invoke<int>(0xB38E00, ped, weaponHash, ammo)
    return Velora.invoke(0xB38E30, "bool", ped, invoke<BOOL>(0xB38C10, invoke<BOOL>(0xB38C40, ped, weaponHash, invoke<BOOL>(0xB38CB0, invoke<BOOL>(0xB38CE0, ped, invoke<Hash>(0xB38D50, ped, invoke<int>(0xB38E00, ped, weaponHash, ammo)
end

function SET_PED_AMMO(ped, weaponHash, ammo, p3)
    Velora.invoke(0xB38EA0, "void", ped, weaponHash, ammo, p3)
end

function SET_PED_INFINITE_AMMO(ped, toggle, weaponHash)
    Velora.invoke(0xB38EC0, "void", ped, toggle, weaponHash)
end

function SET_PED_INFINITE_AMMO_CLIP(ped, toggle)
    Velora.invoke(0xB38EE0, "void", ped, toggle)
end

function SET_PED_STUN_GUN_FINITE_AMMO(p0, p1)
    Velora.invoke(0xB38F50, "void", p0, p1)
end

function GIVE_WEAPON_TO_PED(ped, weaponHash, ammoCount, isHidden, bForceInHand)
    Velora.invoke(0xB38FD0, "void", ped, weaponHash, ammoCount, isHidden, bForceInHand)
end

function GIVE_DELAYED_WEAPON_TO_PED(ped, weaponHash, ammoCount, bForceInHand)
    Velora.invoke(0xB39000, "void", ped, weaponHash, ammoCount, bForceInHand)
end

function REMOVE_ALL_PED_WEAPONS(ped, p1)
    Velora.invoke(0xB39020, "void", ped, p1)
end

function REMOVE_WEAPON_FROM_PED(ped, weaponHash)
    Velora.invoke(0xB390A0, "void", ped, weaponHash)
end

function HIDE_PED_WEAPON_FOR_SCRIPTED_CUTSCENE(ped, toggle)
    Velora.invoke(0xB39120, "void", ped, toggle)
end

function SET_PED_CURRENT_WEAPON_VISIBLE(ped, visible, deselectWeapon, p3, p4)
    Velora.invoke(0xB391B0, "void", ped, visible, deselectWeapon, p3, p4)
end

function SET_PED_DROPS_WEAPONS_WHEN_DEAD(ped, toggle)
    Velora.invoke(0xB391F0, "void", ped, toggle)
end

function HAS_PED_BEEN_DAMAGED_BY_WEAPON(ped, weaponHash, invoke<BOOL>(0xB39250, ped)
    return Velora.invoke(0xB392C0, "bool", ped, weaponHash, invoke<BOOL>(0xB39250, ped)
end

function HAS_ENTITY_BEEN_DAMAGED_BY_WEAPON(entity, weaponHash, invoke<BOOL>(0xB39320, entity)
    return Velora.invoke(0xB393A0, "bool", entity, weaponHash, invoke<BOOL>(0xB39320, entity)
end

function SET_PED_DROPS_WEAPON(ped)
    Velora.invoke(0xB39400, "void", ped)
end

function SET_PED_DROPS_INVENTORY_WEAPON(ped, weaponHash, xOffset, yOffset, zOffset, ammoCount)
    Velora.invoke(0xB39410, "void", ped, weaponHash, xOffset, yOffset, zOffset, ammoCount)
end

function GET_MAX_AMMO_IN_CLIP(ped, weaponHash, invoke<int>(0xB39430, ped, weaponHash, invoke<BOOL>(0xB396D0, ped, weaponHash, invoke<BOOL>(0xB397B0, ped, weaponHash, invoke<BOOL>(0xB397E0, ped, ammoTypeHash, invoke<BOOL>(0xB398A0, ped, ammoTypeHash, ammo)
    return Velora.invoke(0xB39960, "int", ped, weaponHash, invoke<int>(0xB39430, ped, weaponHash, invoke<BOOL>(0xB396D0, ped, weaponHash, invoke<BOOL>(0xB397B0, ped, weaponHash, invoke<BOOL>(0xB397E0, ped, ammoTypeHash, invoke<BOOL>(0xB398A0, ped, ammoTypeHash, ammo)
end

function SET_PED_AMMO_BY_TYPE(ped, ammoTypeHash, ammo)
    Velora.invoke(0xB399D0, "void", ped, ammoTypeHash, ammo)
end

function GET_PED_AMMO_BY_TYPE(ped, invoke<int>(0xB39A40, ped, p1)
    return Velora.invoke(0xB39AB0, "int", ped, invoke<int>(0xB39A40, ped, p1)
end

function SET_PICKUP_AMMO_AMOUNT_SCALER(p0)
    Velora.invoke(0xB39B00, "void", p0)
end

function GET_PED_AMMO_TYPE_FROM_WEAPON(ped, invoke<Hash>(0xB39B20, ped, invoke<Hash>(0xB39B50, ped, invoke<BOOL>(0xB39C00, ped, gadgetHash, p2)
    return Velora.invoke(0xB39D00, "int", ped, invoke<Hash>(0xB39B20, ped, invoke<Hash>(0xB39B50, ped, invoke<BOOL>(0xB39C00, ped, gadgetHash, p2)
end

function GET_IS_PED_GADGET_EQUIPPED(ped, invoke<BOOL>(0xB39D20, invoke<Hash>(0xB39D90, ped, weaponHash, p2)
    return Velora.invoke(0xB39DF0, "bool", ped, invoke<BOOL>(0xB39D20, invoke<Hash>(0xB39D90, ped, weaponHash, p2)
end

function REMOVE_ALL_PROJECTILES_OF_TYPE(weaponHash, explode)
    Velora.invoke(0xB39E10, "void", weaponHash, explode)
end

function GET_LOCKON_DISTANCE_OF_CURRENT_PED_WEAPON(invoke<float>(0xB39EA0, invoke<float>(0xB39ED0, driver, vehicle, weaponHash, invoke<BOOL>(0xB39F00, ped, weaponHash, componentHash)
    return Velora.invoke(0xB39F30, "float", invoke<float>(0xB39EA0, invoke<float>(0xB39ED0, driver, vehicle, weaponHash, invoke<BOOL>(0xB39F00, ped, weaponHash, componentHash)
end

function REMOVE_WEAPON_COMPONENT_FROM_PED(ped, weaponHash, componentHash)
    Velora.invoke(0xB39FA0, "void", ped, weaponHash, componentHash)
end

function HAS_PED_GOT_WEAPON_COMPONENT(ped, weaponHash, invoke<BOOL>(0xB3A010, ped, weaponHash, invoke<BOOL>(0xB3A040, invoke<BOOL>(0xB3A070, invoke<BOOL>(0xB3A0D0, weaponHash, p1, p2)
    return Velora.invoke(0xB3A180, "bool", ped, weaponHash, invoke<BOOL>(0xB3A010, ped, weaponHash, invoke<BOOL>(0xB3A040, invoke<BOOL>(0xB3A070, invoke<BOOL>(0xB3A0D0, weaponHash, p1, p2)
end

function HAS_WEAPON_ASSET_LOADED(invoke<BOOL>(0xB3A240, weaponHash)
    return Velora.invoke(0xB3A270, "bool", invoke<BOOL>(0xB3A240, weaponHash)
end

function CREATE_WEAPON_OBJECT(weaponHash, ammoCount, x, y, z, showWorldModel, scale, p7, p8, invoke<Object>(0xB3A360, weaponObject, componentHash)
    return Velora.invoke(0xB3A3C0, "int", weaponHash, ammoCount, x, y, z, showWorldModel, scale, p7, p8, invoke<Object>(0xB3A360, weaponObject, componentHash)
end

function REMOVE_WEAPON_COMPONENT_FROM_WEAPON_OBJECT(object, componentHash)
    Velora.invoke(0xB3A410, "void", object, componentHash)
end

function HAS_WEAPON_GOT_WEAPON_COMPONENT(weapon, invoke<BOOL>(0xB3A490, weaponObject, ped)
    return Velora.invoke(0xB3A520, "bool", weapon, invoke<BOOL>(0xB3A490, weaponObject, ped)
end

function DOES_WEAPON_TAKE_WEAPON_COMPONENT(weaponHash, invoke<BOOL>(0xB3A530, ped, invoke<Object>(0xB3A560, ped, loadoutHash)
    return Velora.invoke(0xB3A590, "bool", weaponHash, invoke<BOOL>(0xB3A530, ped, invoke<Object>(0xB3A560, ped, loadoutHash)
end

function SET_PED_WEAPON_TINT_INDEX(ped, weaponHash, tintIndex)
    Velora.invoke(0xB3A5E0, "void", ped, weaponHash, tintIndex)
end

function GET_PED_WEAPON_TINT_INDEX(ped, invoke<int>(0xB3A600, weapon, tintIndex)
    return Velora.invoke(0xB3A630, "int", ped, invoke<int>(0xB3A600, weapon, tintIndex)
end

function GET_WEAPON_OBJECT_TINT_INDEX(invoke<int>(0xB3A680, invoke<int>(0xB3A6E0, ped, weaponHash, camoComponentHash, colorIndex)
    return Velora.invoke(0xB3A750, "int", invoke<int>(0xB3A680, invoke<int>(0xB3A6E0, ped, weaponHash, camoComponentHash, colorIndex)
end

function GET_PED_WEAPON_COMPONENT_TINT_INDEX(ped, weaponHash, invoke<int>(0xB3A770, weaponObject, camoComponentHash, colorIndex)
    return Velora.invoke(0xB3A7A0, "int", ped, weaponHash, invoke<int>(0xB3A770, weaponObject, camoComponentHash, colorIndex)
end

function GET_WEAPON_OBJECT_COMPONENT_TINT_INDEX(weaponObject, invoke<int>(0xB3A840, ped, invoke<int>(0xB3A8D0, weaponObject, p1)
    return Velora.invoke(0xB3A900, "int", weaponObject, invoke<int>(0xB3A840, ped, invoke<int>(0xB3A8D0, weaponObject, p1)
end

function GET_WEAPON_HUD_STATS(weaponHash, invoke<BOOL>(0xB3A950, componentHash, invoke<BOOL>(0xB3AA00, weaponHash, invoke<float>(0xB3AAA0, invoke<int>(0xB3AAD0, invoke<float>(0xB3AB50, ped, xBias, yBias)
    return Velora.invoke(0xB3ABD0, "bool", weaponHash, invoke<BOOL>(0xB3A950, componentHash, invoke<BOOL>(0xB3AA00, weaponHash, invoke<float>(0xB3AAA0, invoke<int>(0xB3AAD0, invoke<float>(0xB3AB50, ped, xBias, yBias)
end

function SET_PED_SHOOT_ORDNANCE_WEAPON(ped, invoke<Object>(0xB3AC40, weaponObject)
    return Velora.invoke(0xB3AC70, "int", ped, invoke<Object>(0xB3AC40, weaponObject)
end

function SET_WEAPON_DAMAGE_MODIFIER(weaponHash, damageMultiplier)
    Velora.invoke(0xB3AD20, "void", weaponHash, damageMultiplier)
end

function SET_WEAPON_AOE_MODIFIER(weaponHash, multiplier)
    Velora.invoke(0xB3AD80, "void", weaponHash, multiplier)
end

function SET_WEAPON_EFFECT_DURATION_MODIFIER(p0, p1)
    Velora.invoke(0xB3ADE0, "void", p0, p1)
end

function IS_PED_CURRENT_WEAPON_SILENCED(invoke<BOOL>(0xB3AE40, invoke<BOOL>(0xB3AEB0, invoke<BOOL>(0xB3AF30, ped, toggle)
    return Velora.invoke(0xB3AF40, "bool", invoke<BOOL>(0xB3AE40, invoke<BOOL>(0xB3AEB0, invoke<BOOL>(0xB3AF30, ped, toggle)
end

function SET_WEAPON_ANIMATION_OVERRIDE(ped, animStyle)
    Velora.invoke(0xB3AFB0, "void", ped, animStyle)
end

function GET_WEAPON_DAMAGE_TYPE(invoke<int>(0xB3B040, ped)
    return Velora.invoke(0xB3B0B0, "int", invoke<int>(0xB3B040, ped)
end

function CAN_USE_WEAPON_ON_PARACHUTE(invoke<BOOL>(0xB3B110, x, y, z, radius, p4, p5, p6, invoke<int>(0xB3B140, p0, p1, p2, p3, p4, p5, p6, p7, p8, radius, invoke<int>(0xB3B1B0, invoke<BOOL>(0xB3B3A0, REMOVE_ALL_AIR_DEFENCE_SPHERES()
    return Velora.invoke(0xB3B3D0, "bool", invoke<BOOL>(0xB3B110, x, y, z, radius, p4, p5, p6, invoke<int>(0xB3B140, p0, p1, p2, p3, p4, p5, p6, p7, p8, radius, invoke<int>(0xB3B1B0, invoke<BOOL>(0xB3B3A0, REMOVE_ALL_AIR_DEFENCE_SPHERES()
end

function SET_PLAYER_TARGETTABLE_FOR_AIR_DEFENCE_SPHERE(player, zoneId, enable)
    Velora.invoke(0xB3B3E0, "void", player, zoneId, enable)
end

function IS_AIR_DEFENCE_SPHERE_IN_AREA(x, y, z, radius, invoke<BOOL>(0xB3B420, zoneId, x, y, z)
    return Velora.invoke(0xB3B4B0, "bool", x, y, z, radius, invoke<BOOL>(0xB3B420, zoneId, x, y, z)
end

function DOES_AIR_DEFENCE_SPHERE_EXIST(invoke<BOOL>(0xB3B530, ped, weaponHash, toggle)
    return Velora.invoke(0xB3B560, "bool", invoke<BOOL>(0xB3B530, ped, weaponHash, toggle)
end

function SET_CAN_PED_SELECT_ALL_WEAPONS(ped, toggle)
    Velora.invoke(0xB3B580, "void", ped, toggle)
end

function GET_ZONE_AT_COORDS(x, y, invoke<int>(0xB3C500, invoke<int>(0xB3C590, invoke<int>(0xB3C5D0, x, y, char>(0xB3C620, zoneId, toggle)
    return Velora.invoke(0xB3C6D0, "int", x, y, invoke<int>(0xB3C500, invoke<int>(0xB3C590, invoke<int>(0xB3C5D0, x, y, char>(0xB3C620, zoneId, toggle)
end

function GET_ZONE_SCUMMINESS(invoke<int>(0xB3C6F0, scheduleId, vehicleHash)
    return Velora.invoke(0xB3C720, "int", invoke<int>(0xB3C6F0, scheduleId, vehicleHash)
end

function CLEAR_POPSCHEDULE_OVERRIDE_VEHICLE_MODEL(scheduleId)
    Velora.invoke(0xB3C730, "void", scheduleId)
end
