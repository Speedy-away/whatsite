Relief CFG by steezys
Thank you for downloading, must use ps4 version of Black Ops

When your done selecting the mods go to the "ENJOY" option and close the menu that way you can still knife in game without activating any mods since it has no functionality.


Controls
Open: Dpad UP
Scroll: Dpad Left & Right 
Select: R3
Close: Select

maybe more stuff soon

youtube/@steezys
This was made using CFG Menu Maker Tool!

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣶⣶⣶⣶⣶⣶⠖⢀⣀⣤⣤⣄⡀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀
⠀⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⣭⣭⣭⣭⢹⣿⣷⡀
⠀⠀⠀⠀⢀⣴⣾⠿⠟⢋⣩⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⢸⣿⣿⣷
⠀⠀⠀⠀⠉⠉⣀⣴⣾⣿⣿⣿⣿⣿⣿⡿⠛⠛⠛⣿⣿⡇⣿⣿⣿⣿⣸⣿⣿⣿
⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⡿⠋⣠⣄⢠⣄⠘⣿⣿⣮⣽⣯⣵⣿⣿⣿⠻
⠀⠀⣴⣿⣿⣿⣿⣿⣿⡿⠟⠋⣁⣴⣿⣿⣿⣿⣿⡆⣿⣿⣿⣿⣿⣿⣿⣿⠟⠀
⠀⣼⣿⣿⣿⣿⠟⢋⣁⣀⣤⣾⣿⣿⣿⣿⣿⣯⣭⣭⣬⣭⣭⣭⣭⡭⠵⠶⠶⠀
⢰⣿⣿⠋⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣶⣶⣶⣶⣾⣿⣿⣿⠀
⣿⣿⠃⢀⣴⣿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⢻⣿⣿⡇
⠻⠏⠀⢸⣿⣿⡄⠀⠈⠉⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠋⠀⠀⠀⢸⣿⣿⡇
⠀⠀⠀⢸⣿⣿⣷⣄⠀⠀⠀⠈⢻⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⢀⣴⣿⣿⣿⠇
⠀⠀⠀⠸⣿⣿⣿⣿⣿⣶⣤⣀⣀⣿⣿⣿⣿⣿⣿⣃⣀⣤⣴⣾⣿⣿⣿⣿⡿⠀
⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⢻⣿⣿⣿⣿⣿⣿⣿⡿⠟⠉⠀⠀
⠀⠀⠀⠀⠀⠀⢠⣽⢻⣿⣿⣿⣿⣿⣯⣤⣀⣬⣿⣿⣿⣿⣿⣿⢫⣾⡆⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢼⣿⡏⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢟⣿⣿⠇⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠸⣿⣿⣾⢻⡿⣿⣿⢿⡿⣿⣿⢿⡿⡿⣿⢱⣿⣿⠟⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⡇⡁⠀⠀⠀⡁⡁⢀⢀⠀⠀⡄⢸⣿⠏⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣷⣿⣾⣾⣿⣷⣿⣿⣾⣿⣿⣿⣾⣿⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⡿⠿⠿⠿⠿⠟⠛⠛⠛⠻⠿⠿⠿⠃⠀⠀⠀⠀⠀⠀