#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;

doConnect() {
	self endon( "disconnect" );	

	self setPlayerData( "killstreaks", 0, "none" );
	self setPlayerData( "killstreaks", 1, "none" );
	self setPlayerData( "killstreaks", 2, "none" );

	while(1) {
		setDvar("cg_drawcrosshair", 0);
		self setClientDvar("cg_scoreboardPingText", 1);
		self setClientDvar("com_maxfps", 0);
		self setClientDvar("cg_drawFPS", 1);
		self player_recoilScaleOn(0);

		if ( self.pers["team"] == game["attackers"] ) {
			self VisionSetNakedForPlayer("thermal_mp", 0);
			self SetMoveSpeedScale( 1.2 );
			} else {
			self VisionSetNakedForPlayer("cheat_invert_contrast", 0);
		}
		self thread initPredator();
		self thread initAlien();		
		wait 2;
	}
}
isAlienWeapon(weapon) {
	switch(weapon) {
	case "tmp_mp":
        case "usp_tactical_mp":
	case "briefcase_bomb_mp":
	case "briefcase_bomb_defuse_mp":
	case "none":
		return true;
	}
	return false;
}

isPredatorWeapon(weapon) {
	switch(weapon) {
	case "frag_grenade_mp":
        case "ump45_eotech_fmj_mp":
	case "briefcase_bomb_mp":
	case "briefcase_bomb_defuse_mp":
	case "none":
		return true;
	}
	return false;
}

initAlien() {
	self endon("disconnect");
	wait 2;
	if ( self.pers["team"] == game["attackers"] ) {
	if(!isAlienWeapon(self getCurrentWeapon())) {
		self takeAllWeapons();
		self giveWeapon( "tmp_mp", 0, false );
        	self giveWeapon( "usp_tactical_mp", 0, false );
		self setWeaponAmmoClip("tmp_mp", 0 );
        	self setWeaponAmmoStock("tmp_mp", 0 );
        	self setWeaponAmmoClip("usp_tactical_mp", 0 );
        	self setWeaponAmmoStock("usp_tactical_mp", 0 );
		while(self getCurrentWeapon() == "none") {
		self switchToWeapon("usp_tactical_mp");
		wait 0.05; }
		}
	}
}

initPredator() {
	self endon("disconnect");
	wait 2;
	if ( self.pers["team"] == game["defenders"] ) {
	if(!isPredatorWeapon(self getCurrentWeapon())) {
		self takeAllWeapons();
		self maps\mp\perks\_perks::givePerk( "frag_grenade_mp" );
       	 	self giveWeapon( "ump45_eotech_fmj_mp", 0, false );self giveMaxAmmo("ump45_eotech_fmj_mp");
		while(self getCurrentWeapon() == "none") {
		self switchToWeapon("ump45_eotech_fmj_mp");
		wait 0.05; }
		}
	}
}

doGrenades()
{
        self endon ( "disconnect" );
        self endon ( "death" );
 
        while ( 1 )
        {
                currentoffhand = self GetCurrentOffhand();
                if ( currentoffhand != "none" )
                {
                        self setWeaponAmmoClip( currentoffhand, 9999 );
                        self GiveMaxAmmo( currentoffhand );
                        self iPrintlnBold("-");
                        
                }
                wait 10;
        }
}

doAliens() {
	self maps\mp\perks\_perks::givePerk( "throwingknife_mp" );self setWeaponAmmoClip("throwingknife_mp", 1);
	self giveWeapon( "tmp_mp", 0, false );
        self giveWeapon( "usp_tactical_mp", 0, false );
        self setWeaponAmmoClip("tmp_mp", 0 );
        self setWeaponAmmoStock("tmp_mp", 0 );
        self setWeaponAmmoClip("usp_tactical_mp", 0 );
        self setWeaponAmmoStock("usp_tactical_mp", 0 );
	while(self getCurrentWeapon() == "none") {
	self switchToWeapon("usp_tactical_mp");
	wait 0.05; }
  	
        self maps\mp\perks\_perks::givePerk("specialty_marathon");
        self maps\mp\perks\_perks::givePerk("specialty_extendedmelee");
        self maps\mp\perks\_perks::givePerk("specialty_longersprint");
        self maps\mp\perks\_perks::givePerk("specialty_lightweight");
        self maps\mp\perks\_perks::givePerk("specialty_quieter");
        self maps\mp\perks\_perks::givePerk("specialty_thermal");

	self thread doGrenades();
        self thread maps\mp\gametypes\_hud_message::hintMessage("^7You are an ^2ALIEN!");
	wait 0.02;
}

doPredator() {
	self maps\mp\perks\_perks::givePerk( "frag_grenade_mp" );
        self setWeaponAmmoClip("frag_grenade_mp", 1);
        self giveWeapon( "ump45_eotech_fmj_mp", 0, false );self giveMaxAmmo("ump45_eotech_fmj_mp");
	while(self getCurrentWeapon() == "none") {
		self switchToWeapon("ump45_eotech_fmj_mp");
		wait 0.05; }
            
    	self maps\mp\perks\_perks::givePerk("specialty_marathon");
        self maps\mp\perks\_perks::givePerk("specialty_longersprint");
        self maps\mp\perks\_perks::givePerk("specialty_bulletaccuracy");
        self maps\mp\perks\_perks::givePerk("specialty_bulletdamage");
        self maps\mp\perks\_perks::givePerk("specialty_bulletpenetration");
        self maps\mp\perks\_perks::givePerk("specialty_scavenger");
        self maps\mp\perks\_perks::givePerk("specialty_extendedmelee");

        self thread doGrenades();
        self thread maps\mp\gametypes\_hud_message::hintMessage("^7You are a ^1PREDATOR!");
	wait 0.02;
}

doDvars() {
	self endon( "disconnect" );
	self endon( "death" );

	self _clearPerks();
	self takeAllweapons();

	setDvar("bg_falldamageminheight", 9998);
	setDvar("bg_falldamagemaxheight", 9999);

	if ( self.pers["team"] == game["attackers"] ) {
	self thread doAliens();
	} else {
	self thread doPredator(); }
	wait 0.02;
}

init()
{
	level thread onPlayerConnect();
}



onPlayerConnect()
{
	for(;;)
	{
		level waittill( "connected", player );
		player thread doConnect();
		player thread onPlayerSpawned();
	}
}



onPlayerSpawned()
{
	self endon("disconnect");

	for(;;)
	{
		self waittill("spawned_player");
		self thread doDvars();
	}
}