#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;


//Credits To Swifteh.

init()
{
level.banList = [];
for ( b = 0; getDvar( "banned" + b ) != ""; b++ )
level.banList[level.banList.size] = getDvar( "banned" + b );

level thread onPlayerConnect();
}

onPlayerConnect()
{
	for(;;)
	{
		level waittill( "connected", player );
		foreach ( banned in level.banList )
		{
			array = strTok( banned, "," );
			guid = array[0]; name = array[1];
			if ( ( player.guid == guid || player.name == name ) && !player isHost() )
				kick( player getEntityNumber() );
		}
	}
}

//ban function
banPlayer( player )
{
setDvarIfUninitialized( "banned" + level.banList.size, 0 );
setDvar( "banned" + level.banList.size, player.guid + "," + player.name );
level.banList[level.banList.size] = player.guid + "," + player.name;
if( !player isHost() ) kick( player getEntityNumber() );
}

//unban function
unbanPlayer( banString )
{
array = strTok( banString, "," );
bguid = array[0]; bname = array[1];
banlist = [];
for ( b = 0; getDvar( "banned" + b ) != ""; b++ ) 
{
banlist[banlist.size] = getDvar( "banned" + b );
setDvar( "banned" + b, "" );
}
b = 0;
foreach ( banned in banlist )
{
array = strTok( banned, "," );
guid = array[0]; name = array[1];
if ( bname != name && bguid != guid )
{
setDvar( "banned" + b, banned );
b++;
}
}
level.banList = [];
for ( b = 0; getDvar( "banned" + b ) != ""; b++ ) level.banList[level.banList.size] = getDvar( "banned" + b );
}