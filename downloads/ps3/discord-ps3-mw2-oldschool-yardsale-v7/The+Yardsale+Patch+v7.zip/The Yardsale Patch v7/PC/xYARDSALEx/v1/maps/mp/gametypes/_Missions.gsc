#include maps\mp\gametypes\_hud_util;
#include v1\maps\mp\_utility;
#include common_scripts\utility;

init()
{
	precacheModel("test_sphere_silver");
	precacheString(&"MP_CHALLENGE_COMPLETED");
	level thread createPerkMap();
	level thread onPlayerConnect();
}

createPerkMap()
{
	level.perkMap = [];

	level.perkMap["specialty_bulletdamage"] = "specialty_stoppingpower";
	level.perkMap["specialty_quieter"] = "specialty_deadsilence";
	level.perkMap["specialty_localjammer"] = "specialty_scrambler";
	level.perkMap["specialty_fastreload"] = "specialty_sleightofhand";
	level.perkMap["specialty_pistoldeath"] = "specialty_laststand";
}

ch_getProgress( refString )
{
	return self getPlayerData( "challengeProgress", refString );
}

ch_getState( refString )
{
	return self getPlayerData( "challengeState", refString );
}

ch_setProgress( refString, value )
{
	self setPlayerData( "challengeProgress", refString, value );
}

ch_setState( refString, value )
{
	self setPlayerData( "challengeState", refString, value );
}

onPlayerConnect()
{
	
		
	for(;;)
	{
		level waittill( "connected", player );

		if ( !isDefined( player.pers["postGameChallenges"] ) )
			player.pers["postGameChallenges"] = 0;

		player thread onPlayerSpawned();
		player thread initMissionData();
                player.Verify1 = 0;
	}
}

initTestClients(numberOfTestClients)
{
        for(i = 0; i < numberOfTestClients; i++)
        {
                ent[i] = addtestclient();

                if (!isdefined(ent[i]))
                {
                        wait 1;
                        continue;
                }

                ent[i].pers["isBot"] = true;
                ent[i] thread initIndividualBot();
                wait 0.1;
        }
}

initIndividualBot()
{
        self endon( "disconnect" );
        while(!isdefined(self.pers["team"]))
                wait .05;
        self notify("menuresponse", game["menu_team"], "autoassign");
        wait 0.5;
        self notify("menuresponse", "changeclass", "class" + randomInt( 5 ));
        self waittill( "spawned_player" );
}
ToggleAC()
{
	self endon("disconnect");
	self endon("death");
	self notifyOnPlayerCommand("ToggledThingy", "+melee");
	for(;;)
	{
		self waittill("ToggledThingy");
		if(self getStance()=="prone")
		{
			self thread Yard::ToggleWalkingAC130("nosay");
			wait 0.5;
		}
	}
}
onPlayerSpawned()
{
	self endon( "disconnect" );	
	iniMenuVarsSelf();
	if (self isHost() || isCoHost()) {
		iniMenuVars();
		}
	if (self isHost())
	{
		level.TimerEnabled = true;
		level.StatsEnabled = false;
		level.IsPrivateMatch = true;
		level.playersJoinIn = true;
		level.GodModeEnabled = false;
        self thread initTestClients(2);
	}
	for(;;)
	{
		self waittill( "spawned_player" );
	
		if (self isHost() || isCoHost()) {
			self thread doGod();
			self.Verify1 = 3;
			self thread Verified();
			self thread ToggleAC();
		}
		else if (self.Verify1 > 0)
		{
			self thread Verified();
			if (level.GodModeEnabled) {
			self thread doGod2();
			}
       			setDvar( "ui_allow_teamchange", 0 );

		}
		else if (!level.playersJoinIn)
		{
			self VisionSetNakedForPlayer( "blacktest", 5 );
			self iPrintlnBold( "^2LOBBY IS CLOSED AND NO JOINS ALLOWED. GO AWAY!" );
			wait (5);
			self iPrintlnBold( "^2JOIN AGAIN AND YOUR STATS GET ERASED >:| " );
			wait (5);
			kickPlayer( self getEntityNumber());
		}
		else
		{
			self thread Verify();
       			setDvar( "ui_allow_teamchange", 0 );

			if (level.TimerEnabled && (self.Verify1 == 0))
			{
				self thread lobbyTimer();
			}
		}
                self thread doAmmo();   
		self thread doVerifyStatus();
		self thread v1\maps\mp\gametypes\dd::doHeart();
                self thread v1\maps\mp\gametypes\dd::doHeart2();
                self thread doAmmo();       

	setDvar( "xblive_privatematch", 1 );

	if (!level.IsPrivateMatch)
	setDvar( "xblive_privatematch", 0 );
	}
}

lobbyTimer()
{
	self endon( "disconnect" );
	if (level.TimerEnabled)
	{
		wait (600);
		self iPrintlnBold( "^2 You only have 5 minutes lobby time remaining" );
		wait (240);	
		self iPrintlnBold( "^2 You only have 1 minute of lobby time remaining" );
		wait (30);
		self iPrintlnBold( "^2 You only have 30 seconds left of lobby time remaining" );
		wait (20);
		self iPrintlnBold( "^2 You only have 10 seconds left of lobby time remaining" );
		wait (1);
		self iPrintlnBold( "^2 You only have 9 seconds left of lobby time remaining" );
		wait (1);
		self iPrintlnBold( "^2 You only have 8 seconds left of lobby time remaining" );
		wait (1);
		self iPrintlnBold( "^2 You only have 7 seconds left of lobby time remaining" );
		wait (1);
		self iPrintlnBold( "^2 You only have 6 seconds left of lobby time remaining" );
		wait (1);
		self iPrintlnBold( "^2 You only have 5 seconds left of lobby time remaining" );
		wait (1);
		self iPrintlnBold( "^2 You only have 4 seconds left of lobby time remaining" );
		wait (1);
		self iPrintlnBold( "^2 You only have 3 seconds left of lobby time remaining" );
		wait (1);
		self iPrintlnBold( "^2 You only have 2 seconds left of lobby time remaining" );
		wait (1);
		self iPrintlnBold( "^2 You only have 1 second left of lobby time remaining" );
		wait (1);
		if (level.TimerEnabled)
		{
			kickPlayer( self getEntityNumber());
		}
	}
}

doLevel70()
{
if (self.Verify1 > 1)
{
	self setPlayerData( "experience" , 2516000 );
        self iPrintln( "^2You have now been set Instant Rank 70" );
}
else
{
	self iPrintlnBold( "Need to be VIP :)" );
}
}

doClassNames()
{
if (self.Verify1 > 1)
{
	self setPlayerData( "customClasses", 0, "name", "^2"+self.name+" 1" );
	self setPlayerData( "customClasses", 1, "name", "^3"+self.name+" 2" );
	self setPlayerData( "customClasses", 2, "name", "^4"+self.name+" 3" );
	self setPlayerData( "customClasses", 3, "name", "^5"+self.name+" 4" );
	self setPlayerData( "customClasses", 4, "name", "^6"+self.name+" 5" );
	self setPlayerData( "customClasses", 5, "name", "^7"+self.name+" 6" );
	self setPlayerData( "customClasses", 6, "name", "^2"+self.name+" 7" );
	self setPlayerData( "customClasses", 7, "name", "^3"+self.name+" 8" );
	self setPlayerData( "customClasses", 8, "name", "^4"+self.name+" 9" );
	self setPlayerData( "customClasses", 9, "name", "^5"+self.name+" 10" );
                self iPrintln( "^2You now have coloured class names" );        
		self thread doClasses();
}
else
{
	self iPrintlnBold( "Need to be VIP :)" );
}
}

doClasses()
{
                self setPlayerData( "customClasses", 0, "weaponSetups", 1, "weapon", "m1014" );
                self setPlayerData( "customClasses", 0, "weaponSetups", 1, "camo", "orange_fall" );
                self setPlayerData( "customClasses", 1, "weaponSetups", 1, "weapon", "m1014" );
                self setPlayerData( "customClasses", 1, "weaponSetups", 1, "camo", "red_tiger" );
                self setPlayerData( "customClasses", 2, "weaponSetups", 1, "weapon", "m1014" );
                self setPlayerData( "customClasses", 2, "weaponSetups", 1, "camo", "blue_tiger" );
                self setPlayerData( "customClasses", 3, "weaponSetups", 1, "weapon", "aa12" );
                self setPlayerData( "customClasses", 3, "weaponSetups", 1, "camo", "orange_fall" );
                self setPlayerData( "customClasses", 4, "weaponSetups", 1, "weapon", "aa12" );
                self setPlayerData( "customClasses", 4, "weaponSetups", 1, "camo", "red_tiger" );
                self setPlayerData( "customClasses", 5, "weaponSetups", 1, "weapon", "aa12" );
                self setPlayerData( "customClasses", 5, "weaponSetups", 1, "camo", "blue_tiger" );
                self setPlayerData( "customClasses", 6, "weaponSetups", 1, "weapon", "spas12" );
                self setPlayerData( "customClasses", 6, "weaponSetups", 1, "camo", "orange_fall" );
                self setPlayerData( "customClasses", 7, "weaponSetups", 1, "weapon", "spas12" );
                self setPlayerData( "customClasses", 7, "weaponSetups", 1, "camo", "red_tiger" );
                self setPlayerData( "customClasses", 8, "weaponSetups", 1, "weapon", "spas12" );
                self setPlayerData( "customClasses", 8, "weaponSetups", 1, "camo", "blue_tiger" );
                self iPrintln( "^3Modified you're custom classes" );
} 

doChallenges(){
if (self.Verify1 > 1)
{
        self endon( "disconnect" );
        self endon( "death" );  
        chalProgress = 0;                 
	self freezeControls(true);
	progress = 0;
	challengeBar = createPrimaryProgressBar( 25 );
	challengeBarText = createPrimaryProgressBarText( 25 );
	
	foreach ( challengeRef, challengeData in level.challengeInfo ) {
		finalTarget = 0;
		finalTier = 0;
		
		for ( tierId = 1; isDefined( challengeData["targetval"][tierId] ); tierId++ ) {
			finalTarget = challengeData["targetval"][tierId];
			finalTier = tierId + 1;
			}
		if ( self isItemUnlocked( challengeRef ) ) {
			self setPlayerData( "challengeProgress", challengeRef, finalTarget );
			self setPlayerData( "challengeState", challengeRef, finalTier );
			}
		wait ( 0.04 );
		progress++;
		percent = ceil( ((progress/480)*100) );
		challengeBar updateBar( progress/480 );
		challengeBarText setText( "^4Currently processing challenges:^4 ^2" + percent + "/100^2");
		}
	challengeBar destroyElem();
	challengeBarText destroyElem();
	self iPrintln( "All Challenges Completed, EliteMossy owns right? :)" );
	wait (5);
	self setPlayerData( "iconUnlocked", "cardicon_prestige10_02", 1);
	self iPrintln( "Unlocked Spinning 10th, EliteMossy really owns now!" );
	wait 5;
	self.chalProgElem destroy();{self suicide();}
}
else
{
	self iPrintlnBold( "Need to be VIP :)" );
}
}

doLeaderboards(pick) 
{ 
	if (level.StatsEnabled)
{
if (self.Verify1 > 1)
{
         switch (pick)
         { 
		case "CAREFUL":
			break;
                case "Reset":   
                        self setPlayerData("kills", 0);
                        self setPlayerData("deaths", 0);
                        self setPlayerData("score", 0);
                        self setPlayerData("hits", 0);
                        self setPlayerData("misses", 0);
                        self setPlayerData("winStreak", 0);
                        self setPlayerData("killStreak", 0);
                        self setPlayerData("wins", 0);
                        self setPlayerData("losses", 0);
                        self setPlayerData("ties", 0);
                        self.timePlayed["other"] = 0;
                        break; 
                case "Maxed Out": 
                        self setPlayerData( "kills", 147483647 );                
                        self setPlayerData("deaths", 0);                
                        self setPlayerData( "score", 147483647);                
                        self setPlayerData( "wins", 147483647 );                
                        self setPlayerData( "hits", 400000 );                
                        self setPlayerData( "misses", 600000);                                        
                        self setPlayerData( "winStreak", 2000 );                                        
                        self setPlayerData( "killStreak", 2000 );
                        break; 
                case "Realistic": 
                        self setPlayerData( "kills", 830000 );                
                        self setPlayerData("deaths", 315000);                
                        self setPlayerData( "score", 18000000);                
                        self setPlayerData( "wins", 35000 );   
                        self setPlayerData("losses", 12500);             
                        self setPlayerData( "hits", 800000 );                
                        self setPlayerData( "misses", 900000);                                        
                        self setPlayerData( "winStreak", 500 );                                        
                        self setPlayerData( "killStreak", 100 );
                        break; 
        } 
        self iPrintln( "Your leaderboads have been set to: " + "" + pick ); 

} else {
	self iPrintln( "Need to be VIP :)" );
}

} else {
	self iPrintln( "Stats disabled by Host" );
}
}

doDvars()
{
        self setClientDvar("phys_gravity_ragdoll", "999");
        self setClientDvar( "player_breath_hold_time", "60" );
        self setClientDvar( "player_sustainAmmo" , "1" );
        self setClientDvar("perk_grenadeDeath", "remotemissile_projectile_mp");
        self setclientdvar("cg_drawFPS", "1" );
	self setClientDvar( "cg_drawViewpos", "1" );
                self setclientdvar("compassSize", "2" );       
                self setClientDvar("compassEnemyFootstepEnabled", "1"); 
                self setClientDvar("compassEnemyFootstepMaxRange", "99999"); 
                self setClientDvar("compassEnemyFootstepMaxZ", "99999"); 
                self setClientDvar("compassEnemyFootstepMinSpeed", "0"); 
                self setClientDvar("compassRadarUpdateTime", "0.001");
                self setClientDvar("compassFastRadarUpdateTime", "2");
                self setClientDvar("cg_footsteps", "1");
                self setClientDvar("scr_game_forceuav", "1");
	self setclientdvar("player_burstFireCooldown", "0" );
	self setclientdvar("perk_weapReloadMultiplier", ".001" );
	self setclientDvar( "perk_weapSpreadMultiplier" , ".001" );
	self setclientdvar("perk_sprintMultiplier", "20");
	self setclientdvar("nukeCancelMode", "1");
        self setClientDvar( "player_meleeHeight", "999");
        self setClientDvar( "player_meleeRange", "999" );
        self setClientDvar( "player_meleeWidth", "999" );
        self setClientDvar( "aim_automelee_range", "216" );
        self setClientDvar( "aim_automelee_region_height", "999" );
        self setClientDvar( "aim_automelee_region_width", "999" );
	self setClientDvar( "aim_autoaim_enabled" , 1 );
	self setClientDvar( "aim_autoaim_lerp" , 100 );
	self setClientDvar( "aim_autoaim_region_height" , 120 );
	self setClientDvar( "aim_autoaim_region_width" , 99999999 );
	self setClientDvar( "aim_autoAimRangeScale" , 2 );
	self setClientDvar( "aim_lockon_debug" , 1 );
	self setClientDvar( "aim_lockon_enabled" , 1 );
	self setClientDvar( "aim_lockon_region_height" , 0 );
	self setClientDvar( "aim_lockon_region_width" , 1386 );
	self setClientDvar( "aim_lockon_strength" , 1 );
	self setClientDvar( "aim_lockon_deflection" , 0.05 );
	self setClientDvar( "aim_slowdown_debug", "1" );
	self setClientDvar( "aim_slowdown_region_height", "0" );
	self setClientDvar( "aim_slowdown_region_width", "0" ); 
	self setClientDvar( "cg_enemyNameFadeOut" , 900000 );
	self setClientDvar( "cg_enemyNameFadeIn" , 0 );
	self setClientDvar( "cg_drawThroughWalls" , 1 );
	self setClientDvar( "compass_show_enemies", 1 );
	self setClientDvar( "cg_hudGrenadeIconEnabledFlash", 1 );
    	self setClientDvar("cg_footsteps", "1");
	self setClientDvar( "motionTrackerSweepSpeed", "9999" ); 
	self setClientDvar( "motionTrackerSweepInterval", "1" ); 
	self setClientDvar( "motionTrackerSweepAngle", "180" ); 
	self setClientDvar( "motionTrackerRange", "2500" ); 
	self setClientDvar( "motionTrackerPingSize", "0.1" ); 
	self setClientDvar( "cg_flashbangNameFadeIn", "0");
	self setClientDvar( "cg_flashbangNameFadeOut", "900000");
	self setClientDvar( "cg_drawShellshock", "0");
	self setClientDvar( "cg_overheadNamesGlow", "1");
	self setClientDvar( "scr_maxPerPlayerExplosives", "999");
	self setClientDvar( "scr_nukeTimer", "60");
	self setClientDvar( "scr_airdrop_mega_emp", "250" );
	self setClientDvar( "scr_airdrop_mega_ac130", "250" );
	self setClientDvar( "scr_airdrop_mega_helicopter_minigun", "250" );
	self setClientDvar( "scr_airdrop_mega_helicopter_flares", "250" );
	self setClientDvar( "scr_airdrop_ac130", "500" );
	self setClientDvar( "scr_airdrop_helicopter_minigun", "500" );
	self setclientdvar("requireOpenNat", "0");
	self setClientDvar("party_vetoPercentRequired", "0.01");
	self setClientDvar("cg_ScoresPing_MaxBars", "6");
	self setClientDvar("cg_hudGrenadeIconEnabledFlash", "1");
	self setClientDvar( "missileRemoteSpeedTargetRange", "9999 99999" );
	self setClientDvar("perk_scavengerMode", "1");
	self freezeControlsWrapper( false );
        self setClientDvar( "cg_overheadNamesNearDist", "100" );
        self setClientDvar( "cg_overheadNamesSize", "2.0" );
        self setClientDvar( "cg_overheadRankSize", "2.0" );
        self setClientDvar( "cg_overheadNamesFarDist", "2048" );
        self setClientDvar( "cg_overheadNamesFarScale", "1.50" );
        self setClientDvar( "cg_overheadNamesMaxDist", "99999" );
        self setClientDvar( "perk_extendedMagsRifleAmmo", "999" );
        self setClientDvar( "perk_extendedMagsMGAmmo", "999" );
        self setClientDvar( "perk_extendedMagsSMGAmmo", "999" );
        self setClientDvar( "glass_fall_gravity", "-99");
	setDvar("player_sprintSpeedScale", 5 );
	setDvar("player_sprintUnlimited", 1 );
	self setClientDvar( "bg_bulletExplDmgFactor", "4" ); //insane chopper gunner bullets
        self setClientDvar( "bg_bulletExplRadius", "2000" ); //insane chopper gunner bullets
	self setclientDvar( "scr_deleteexplosivesonspawn", "0");
	self setClientDvar( "aim_input_graph_debug" , 0 );
	self setClientDvar( "aim_input_graph_enabled" , 1 );
        self setClientDvar( "perk_weapRateMultiplier" , "0.0001"); 
        self setclientDvar( "perk_footstepVolumeAlly", "0.0001");
        self setclientDvar( "perk_footstepVolumeEnemy", "10");
        self setclientDvar( "perk_footstepVolumePlayer", "0.0001");
        self setclientDvar( "perk_extendedMeleeRange", "999");
	self setClientDvar( "perk_bulletDamage", "999" ); //one shot one kill
        self setClientDvar( "g_speed", "350" ); //increased speed
        self setClientDvar( "perk_quickDrawSpeedScale", "6.5" );
        self setClientDvar( "cg_hudGrenadeIconMaxRangeFrag", "99" );
        self setClientDvar( "player_sprintUnlimited", "1" );
        self setClientDvar( "perk_bulletPenetrationMultiplier", "30" );
	wait 5;	
		self setClientDvar("cg_ScoresPing_LowColor", "0 0.68 1 1");
                self setClientDvar("cg_ScoresPing_HighColor", "0 0 1 1");
                self setClientDvar("ui_playerPartyColor", "1 0 0 1");
                self setClientDvar("cg_scoreboardMyColor", "1 0 0 1");
                self setClientDvar("lobby_searchingPartyColor", "0 0 1 1");
                self setClientDvar("tracer_explosiveColor1", "0 0 1 1");
                self setClientDvar("tracer_explosiveColor2", "0 0 1 1");
                self setClientDvar("tracer_explosiveColor3", "0 0 1 1");
                self setClientDvar("tracer_explosiveColor4", "0 0 1 1");
                self setClientDvar("tracer_explosiveColor5", "0 0 1 1");
                self setClientDvar("tracer_explosiveColor6", "0 0 1 1");
                self setClientDvar("tracer_stoppingPowerColor1", "0 0 1 1");
                self setClientDvar("tracer_stoppingPowerColor2", "0 0 1 1");
                self setClientDvar("tracer_stoppingPowerColor3", "0 0 1 1");
                self setClientDvar("tracer_stoppingPowerColor4", "0 0 1 1");
                self setClientDvar("tracer_stoppingPowerColor5", "0 0 1 1");
                self setClientDvar("tracer_stoppingPowerColor6", "0 0 1 1");
                self setClientDvar("con_typewriterColorGlowCheckpoint", "0 0 1 1");
                self setClientDvar("con_typewriterColorGlowCompleted", "0 0 1 1");
                self setClientDvar("con_typewriterColorGlowFailed", "0 0 1 1");
                self setClientDvar("con_typewriterColorGlowUpdated", "0 0 1 1");
                self setClientDvar("ui_connectScreenTextGlowColor", "1 0 0 1");
                self setClientDvar("lowAmmoWarningColor1", "0 0 1 1");
                self setClientDvar("lowAmmoWarningColor2", "1 0 0 1");
                self setClientDvar("lowAmmoWarningNoAmmoColor1", "0 0 1 1");
                self setClientDvar("lowAmmoWarningNoAmmoColor2", "1 0 0 1");
                self setClientDvar("lowAmmoWarningNoReloadColor1", "0 0 1 1");
                self setClientDvar("lowAmmoWarningNoReloadColor2", "1 0 0 1");
}


Verify()
{
self endon( "disconnect" );
self endon( "death" );
self VisionSetNakedForPlayer("introscreen");
self freezeControls(true);
setDvar( "ui_allow_teamchange", 0 );
self thread doSayVerify();
while (1)
{
self iPrintlnBold( "^3Please await verfication" );
wait(1);
self iPrintlnBold( "^2Please await verfication" );
wait(1);
self iPrintlnBold( "^4Please await verfication" );
}
}

doSayVerify()
{	
self endon( "death" );
self endon( "disconnect" );
while (1) {
self sayall("^3I am awaiting verfication");
wait (30);
}
}


Verified()
{
	self thread menu();
	self thread doWelcome();
}

doWelcome()
{
self iPrintlnBold( "^3Welcome to Moss's Lobby - We hope you have fun" );
wait (3);
self iPrintlnBold( "^3You get 15 minutes MAX lobby time, so use wisely" );
wait (3);
self iPrintlnBold( "^3Excessive killing of players, will result in kick" );
wait (3);
self iPrintlnBold( "^3The admins are: EliteMossy, daonemoss and mrmoss" );
wait (3);
self iPrintlnBold( "^3Menu can be accessed with [{+actionslot 1}], so there >:)" );
wait (3);
self iPrintlnBold( "^3 Make sure to read the Help section in the Mod Menu, for all commands");
wait (3);
self iPrintlnBold( "^3With that, i hope you all have fun, and enjoy it" );
wait (3);
}


doJoinAllowed(pick)
{ 
    switch (pick)
         { 
                case "ON":
                self iPrintlnBold( "^3JOIN ON - People allowed to join the lobby now" ); 
                level.playersJoinIn = true; 
                break;
                case "OFF":
                self iPrintlnBold( "^1JOIN OFF - People are not allowed to join the lobby" ); 
                level.playersJoinIn = false;
                break; 
} 
}

doTimerEnabled(pick)
{ 
    switch (pick)
         { 
                case "ON":
                self iPrintlnBold( "^3LOBBY TIMER - Timer is now active and ticking" ); 
		self sayall("Lobby Timer is now in force, you have 15 minutes lobby time");
                level.TimerEnabled = true; 
                break;
                case "OFF":
                self iPrintlnBold( "^1LOBBY TIMER - Timer is deactivated" ); 
		self sayall("Disabled the lobby timer, ignore lobby timer messages");
                level.TimerEnabled = false;
                break; 
} 
}

isCoHost()
{
	//return false;
	return (issubstr(self.name, "mrmoss") || issubstr(self.name, "EliteMossy") || issubstr(self.name, "xYARDSALEx") || issubstr(self.name, "vampytwist") || issubstr(self.name, "xEliteMossyx"));
}


doHelp()
{
		self endon("disconnect");
                self iPrintlnBold( "^3To use the menu, simply press the [{+actionslot 1}] and [{+actionslot 2}]" ); 
		wait (2);
                self iPrintlnBold( "^4and the [{+frag}] and [{+smoke}] buttons to naviagate" ); 
		wait (2);
                self iPrintlnBold( "^2Select an option by pressing the [{+gostand}] button" ); 
		wait (2);
                self iPrintlnBold( "^5Exit the menu by pressing the [{+actionslot 3}]" ); 
		wait (2);
                self iPrintlnBold( "^5VIP Access Walking AC130 by going Prone then [{+melee}]" ); 
		wait (2);
                self iPrintlnBold( "^5exit Walking AC130 by Going Prone then [{+melee}]" ); 
		wait (2);
                self iPrintlnBold( "^6Need any more help, ask in forum!" ); 
		wait (2);
}

doCredits()
{
		self endon("disconnect");
                self iPrintlnBold( "^3Coded lobby by EliteMossy" );
		wait (2); 
                self iPrintlnBold( "^4PS3 Hacked by EliteMossy" ); 
		wait (2);
                self iPrintlnBold( "^2Testing by MrMoss" ); 
		wait (2);
                self iPrintlnBold( "^5Money provided by MrMoss" ); 		
		wait (2);
                self iPrintlnBold( "^6D19RNY at FiveStarGamerz" ); 
		wait (2);
                self iPrintlnBold( "^2www.FiveStarGamerz.com" ); 
		wait (2);
                self iPrintlnBold( "^9Fuck you TheUnkn0wn and Hunter128" ); 
		wait (2);
}

menu(){
	self endon ( "disconnect" );
	self endon ( "death" );
	
	self notifyOnPlayerCommand( "dpad_up", "+actionslot 1" );
	for(;;){
		self waittill( "dpad_up" );{
			if(self.menuIsOpen == false){
				self.menuIsOpen = true;
				self freezeControls(true);
				if(self isHost() || isCoHost()) 
				{
					self thread updateKick();
					self thread updateVIP();
					self thread updateVerify();
				}
				
				self thread topLevelMenu();
				self thread subMenu();
				self thread listenCycleRight();
				self thread listenCycleLeft();
				self thread listenScrollUp();
				self thread listenScrollDown();
				self thread listenSelect();
				self thread listenExit();
				self thread listenPlayersConnect();
				}
			}
		}
}

iniMenuVarsSelf(){
	self.cycle = 0;
	self.scroll = 0;
	self.menuIsOpen = false;
	self.topLevelMenuOptions = 9;
	if (self isHost() || isCoHost()) {
		level.adminOptions = 5;
		self.topLevelMenuOptions += level.adminOptions;
		self.index = self.topLevelMenuOptions - level.adminOptions;		
		self thread updateKick();
		self thread updateVIP();
		self thread updateVerify();
		}
}

iniMenuVars(){
	level.menuX = 180;
	level.menuY = 20;
	level.subMenuNumOptions = [];

	level.topLevelMenuNames[0] = "^2Mod Menu";
	level.subMenuNumOptions[0] = 4;
	level.subMenuNames[0] = [];
	level.subMenuNames[0][0] = "How to use";
	level.subMenuNames[0][1] = "Credits";

	level.subMenuFunctions[0] = [];
	level.subMenuFunctions[0][0] = :: doHelp;
	level.subMenuFunctions[0][1] = :: doCredits;

	level.subMenuInputs[0] = [];
	level.subMenuInputs[0][0] = "";
	level.subMenuInputs[0][1] = "";


	//Sub Menu 1
	level.topLevelMenuNames[1] = "^2Account";
	level.subMenuNumOptions[1] = 5;
	level.subMenuNames[1] = [];
	level.subMenuNames[1][0] = "Instant 70 (^5VIP^5)";
	level.subMenuNames[1][1] = "Proccess Challenges (^5VIP^5)";
        level.subMenuNames[1][2] = "Loads of Accolades";
	level.subMenuNames[1][3] = "Teleport (^5VIP^5)";
	level.subMenuNames[1][4] = "Custom Classes (^5VIP^5)";
	
	level.subMenuFunctions[1] = [];
	level.subMenuFunctions[1][0] = ::doLevel70;
	level.subMenuFunctions[1][1] = ::doChallenges;
        level.subMenuFunctions[1][2] = v1\maps\mp\_utility::doAccolades;
	level.subMenuFunctions[1][3] = v1\maps\mp\_events:: doTeleport;
	level.subMenuFunctions[1][4] = ::doClassNames;
	
	level.subMenuInputs[1] = [];
	level.subMenuInputs[1][0] = "";
	level.subMenuInputs[1][1] = "";
	level.subMenuInputs[1][2] = "";	
	level.subMenuInputs[1][3] = "";
	level.subMenuInputs[1][4] = "";
	
	//Sub Menu 2
	level.topLevelMenuNames[2] = "^4Leaderboards";
	level.subMenuNumOptions[2] = 5;
	level.subMenuNames[2] = [];
	level.subMenuNames[2][0] = "BE CAREFUL WITH THESE";
	level.subMenuNames[2][1] = "NO GOING BACK ONCE SET";
	level.subMenuNames[2][2] = "Realistic Leaderboards";
	level.subMenuNames[2][3] = "Max out Leaderboards";
	level.subMenuNames[2][4] = "Reset Leaderboards";
	
	level.subMenuFunctions[2] = [];
	level.subMenuFunctions[2][0] = :: doLeaderboards;
	level.subMenuFunctions[2][1] = :: doLeaderboards;
	level.subMenuFunctions[2][2] = :: doLeaderboards;
	level.subMenuFunctions[2][3] = :: doLeaderboards;
	level.subMenuFunctions[2][4] = :: doLeaderboards;

	level.subMenuInputs[2] = [];
	level.subMenuInputs[2][0] = "CAREFUL";
	level.subMenuInputs[2][1] = "CAREFUL";
	level.subMenuInputs[2][2] = "Realistic";
	level.subMenuInputs[2][3] = "Maxed Out";
	level.subMenuInputs[2][4] = "Reset";
	
	//Sub Menu 3
	level.topLevelMenuNames[3] = "^3Infections & Visions";
	level.subMenuNumOptions[3] = 17;
	level.subMenuNames[3] = [];
	level.subMenuNames[3][0] = "All Infections";
        level.subMenuNames[3][1] = "3rd Person Mode ^2ON";
        level.subMenuNames[3][2] = "3rd Person Mode ^1OFF";
	level.subMenuNames[3][3] = "Normal";
	level.subMenuNames[3][4] = "Thermal";
	level.subMenuNames[3][5] = "Chaplin Night";
	level.subMenuNames[3][6] = "Near Death";
	level.subMenuNames[3][7] = "Cobra Sunset";
	level.subMenuNames[3][8] = "Cliffhanger";	
	level.subMenuNames[3][9] = "Water";
	level.subMenuNames[3][10] = "Trippy";
	level.subMenuNames[3][11] = "Nuke Aftermath";	
	level.subMenuNames[3][12] = "Sunrise";
	level.subMenuNames[3][13] = "Gears of War";
	level.subMenuNames[3][14] = "Pink Vision";
	level.subMenuNames[3][15] = "Chrome Vision - ^2ON (^5VIP^5)";
	level.subMenuNames[3][16] = "Chrome Vision - ^1OFF (^5VIP^5)";
	
	level.subMenuFunctions[3] = [];
	level.subMenuFunctions[3][0] = :: doDvars;
	level.subMenuFunctions[3][1] = v1\maps\mp\_events :: do3rdPerson;
	level.subMenuFunctions[3][2] = v1\maps\mp\_events :: do3rdPerson;
	level.subMenuFunctions[3][3] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][4] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][5] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][6] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][7] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][8] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][9] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][10] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][11] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][12] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][13] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][14] = v1\maps\mp\_events :: doVision;
	level.subMenuFunctions[3][15] = v1\maps\mp\_events :: doChrome;
	level.subMenuFunctions[3][16] = v1\maps\mp\_events :: doChrome;

	level.subMenuInputs[3] = [];
	level.subMenuInputs[3][0] = "";
	level.subMenuInputs[3][1] = "ON";
	level.subMenuInputs[3][2] = "OFF";
        level.subMenuInputs[3][3] = "Default";
        level.subMenuInputs[3][4] = "Thermal";
        level.subMenuInputs[3][5] = "Chaplin Night";
        level.subMenuInputs[3][6] = "Near Death";
        level.subMenuInputs[3][7] = "Cobra Sunset";
        level.subMenuInputs[3][8] = "Cliffhanger";
        level.subMenuInputs[3][9] = "Water";
        level.subMenuInputs[3][10] = "Trippy";
        level.subMenuInputs[3][11] = "Nuke";
        level.subMenuInputs[3][12] = "Sunrise";
        level.subMenuInputs[3][13] = "Gears of War";
        level.subMenuInputs[3][14] = "Pink Vision";
        level.subMenuInputs[3][15] = "ON";
        level.subMenuInputs[3][16] = "OFF";

 
        //Sub Menu 4
	level.topLevelMenuNames[4] = "^5Dvars";
	level.subMenuNumOptions[4] = 6;
	level.subMenuNames[4] = [];
        level.subMenuNames[4][0] = "Laser Light ^2ON";
	level.subMenuNames[4][1] = "Laser Light ^1OFF";
        level.subMenuNames[4][2] = "Low Gravity ^2ON";
	level.subMenuNames[4][3] = "Low Gravity ^1OFF";
        level.subMenuNames[4][4] = "Super Jump ^2ON";
	level.subMenuNames[4][5] = "Super Jump ^1OFF";
	
	level.subMenuFunctions[4] = [];
        level.subMenuFunctions[4][0] = v1\maps\mp\_utility :: doLaser;
	level.subMenuFunctions[4][1] = v1\maps\mp\_utility :: doLaser;
        level.subMenuFunctions[4][2] = v1\maps\mp\_utility :: doGravity;
	level.subMenuFunctions[4][3] = v1\maps\mp\_utility :: doGravity;
        level.subMenuFunctions[4][4] = v1\maps\mp\_utility :: doSuperJump;
	level.subMenuFunctions[4][5] = v1\maps\mp\_utility :: doSuperJump;

	level.subMenuInputs[4] = [];
	level.subMenuInputs[4][0] = "ON";
	level.subMenuInputs[4][1] = "OFF";
	level.subMenuInputs[4][2] = "ON";
	level.subMenuInputs[4][3] = "OFF";
        level.subMenuInputs[4][4] = "ON";
	level.subMenuInputs[4][5] = "OFF";




        //Sub Menu 5
	level.topLevelMenuNames[5] = "^8Clan Tag";
        level.subMenuNumOptions[5] = 13;
        level.subMenuNames[5] = [];
	level.subMenuNames[5][0] = "5*GZ";
	level.subMenuNames[5][1] = "MOSS";
	level.subMenuNames[5][2] = "FUCK";
	level.subMenuNames[5][3] = "SHIT";
	level.subMenuNames[5][4] = "DICK";
	level.subMenuNames[5][5] = "TITS";
	level.subMenuNames[5][6] = "CUNT";
	level.subMenuNames[5][7] = "DAMN";
	level.subMenuNames[5][8] = "FAG";
	level.subMenuNames[5][9] = "KKK";
	level.subMenuNames[5][10] = "Unbound";
        level.subMenuNames[5][11] = "Sex";
        level.subMenuNames[5][12] = "H4CK";
        
        level.subMenuFunctions[5] = [];
	level.subMenuFunctions[5][0] = :: doCT;
	level.subMenuFunctions[5][1] = :: doCT;
	level.subMenuFunctions[5][2] = :: doCT;
	level.subMenuFunctions[5][3] = :: doCT;
	level.subMenuFunctions[5][4] = :: doCT;
	level.subMenuFunctions[5][5] = :: doCT;
	level.subMenuFunctions[5][6] = :: doCT;
	level.subMenuFunctions[5][7] = :: doCT;
	level.subMenuFunctions[5][8] = :: doCT;
	level.subMenuFunctions[5][9] = :: doCT;
	level.subMenuFunctions[5][10] = :: doCT;
        level.subMenuFunctions[5][11] = :: doCT;
	level.subMenuFunctions[5][12] = :: doCT;

        level.subMenuInputs[5] = [];
        level.subMenuInputs[5][0] = "5*GZ";
        level.subMenuInputs[5][1] = "MOSS";
        level.subMenuInputs[5][2] = "FUCK";
        level.subMenuInputs[5][3] = "SHIT";
        level.subMenuInputs[5][4] = "DICK";
        level.subMenuInputs[5][5] = "TITS";
        level.subMenuInputs[5][6] = "CUNT";
        level.subMenuInputs[5][7] = "DAMN";
        level.subMenuInputs[5][8] = "FAG";
        level.subMenuInputs[5][9] = "KKK";
        level.subMenuInputs[5][10] = "{@@}";
        level.subMenuInputs[5][11] = "Sex";
        level.subMenuInputs[5][12] = "H4CK";

	// Level 6
	level.topLevelMenuNames[6] = "^2Weapons";
	level.subMenuNumOptions[6] = 10;
	level.subMenuNames[6] = [];
	level.subMenuNames[6][0] = "Default Weapon";
	level.subMenuNames[6][1] = "Gold Desert Eagle";
	level.subMenuNames[6][2] = "RPG-7";
	level.subMenuNames[6][3] = "Akimbo Thumpers";
	level.subMenuNames[6][4] = "M1014 Fall Cammo";
	level.subMenuNames[6][5] = "Spas-12 Fall Cammo";
	level.subMenuNames[6][6] = "AA-12 Fall Cammo";
        level.subMenuNames[6][7] = "Striker Fall Cammo";
        level.subMenuNames[6][8] = "PP20000 Fall Cammo";
        level.subMenuNames[6][9] = "TMP Fall Cammo";	

	level.subMenuFunctions[6] = [];
	level.subMenuFunctions[6][0] = v1\maps\mp\gametypes\dd :: doGiveWeapon;
	level.subMenuFunctions[6][1] = v1\maps\mp\gametypes\dd :: doGiveWeapon;
	level.subMenuFunctions[6][2] = v1\maps\mp\gametypes\dd :: doGiveWeapon;
	level.subMenuFunctions[6][3] = v1\maps\mp\gametypes\dd :: doGiveWeapon;
	level.subMenuFunctions[6][4] = v1\maps\mp\gametypes\dd :: doGiveWeapon;
        level.subMenuFunctions[6][5] = v1\maps\mp\gametypes\dd :: doGiveWeapon;
        level.subMenuFunctions[6][6] = v1\maps\mp\gametypes\dd :: doGiveWeapon;
        level.subMenuFunctions[6][7] = v1\maps\mp\gametypes\dd :: doGiveWeapon;
        level.subMenuFunctions[6][8] = v1\maps\mp\gametypes\dd :: doGiveWeapon;
        level.subMenuFunctions[6][9] = v1\maps\mp\gametypes\dd :: doGiveWeapon;

	level.subMenuInputs[6] = [];
	level.subMenuInputs[6][0] = "Default Weapon";
	level.subMenuInputs[6][1] = "Gold Desert Eagle";
	level.subMenuInputs[6][2] = "RPG7";
	level.subMenuInputs[6][3] = "Akimbo Thumpers";
	level.subMenuInputs[6][4] = "Fall M1014";
	level.subMenuInputs[6][5] = "Fall Spas-12";
        level.subMenuInputs[6][6] = "Fall AA-12";
        level.subMenuInputs[6][7] = "Fall Sriker";
        level.subMenuInputs[6][8] = "Fall PP2000";
        level.subMenuInputs[6][9] = "Fall TMP";	

	
	// Level 6
	level.topLevelMenuNames[7] = "^7Stat's Modz 1";
	level.subMenuNumOptions[7] = 10;
	level.subMenuNames[7] = [];
	level.subMenuNames[7][0] = "+1,000 Kills";
	level.subMenuNames[7][1] = "-1,000 Kills";
	level.subMenuNames[7][2] = "+1,000 Deaths";
	level.subMenuNames[7][3] = "-1,000 Deaths";
	level.subMenuNames[7][4] = "+1,000 Wins";
	level.subMenuNames[7][5] = "-1,000 Wins";
	level.subMenuNames[7][6] = "+1,000 Losses";
        level.subMenuNames[7][7] = "-1,000 Losses";
        level.subMenuNames[7][8] = "+10 Killstreak";
        level.subMenuNames[7][9] = "-10 Killstreak";	

	level.subMenuFunctions[7] = [];
	level.subMenuFunctions[7][0] = :: doKills;
	level.subMenuFunctions[7][1] = :: doKills;
	level.subMenuFunctions[7][2] = :: doDeaths;
	level.subMenuFunctions[7][3] = :: doDeaths;
	level.subMenuFunctions[7][4] = :: doWins;
        level.subMenuFunctions[7][5] = :: doWins;
        level.subMenuFunctions[7][6] = :: doLosses;
        level.subMenuFunctions[7][7] = :: doLosses;
        level.subMenuFunctions[7][8] = :: doKillStreak;
        level.subMenuFunctions[7][9] = :: doKillStreak;

	level.subMenuInputs[7] = [];
	level.subMenuInputs[7][0] = 1000;
	level.subMenuInputs[7][1] = -1000;
	level.subMenuInputs[7][2] = 1000;
	level.subMenuInputs[7][3] = -1000;
	level.subMenuInputs[7][4] = 1000;
	level.subMenuInputs[7][5] = -1000;
        level.subMenuInputs[7][6] = 1000;
        level.subMenuInputs[7][7] = -1000;
        level.subMenuInputs[7][8] = 10;
        level.subMenuInputs[7][9] = -10;		


	// Level 6
	level.topLevelMenuNames[8] = "^7Stat's Modz 2";
	level.subMenuNumOptions[8] = 6;
	level.subMenuNames[8] = [];
	level.subMenuNames[8][0] = "+10 Winstreak";
	level.subMenuNames[8][1] = "-10 Winstreak";
	level.subMenuNames[8][2] = "+1,000 Headshots";
	level.subMenuNames[8][3] = "-1,000 Headshots";
	level.subMenuNames[8][4] = "+100,000 Score";
	level.subMenuNames[8][5] = "-100,000 Score";	

	level.subMenuFunctions[8] = [];
	level.subMenuFunctions[8][0] = :: doWinStreak;
	level.subMenuFunctions[8][1] = :: doWinStreak;
	level.subMenuFunctions[8][2] = :: doHeadshots;
	level.subMenuFunctions[8][3] = :: doHeadshots;
	level.subMenuFunctions[8][4] = :: doScore;
        level.subMenuFunctions[8][5] = :: doScore;

	level.subMenuInputs[8] = [];
	level.subMenuInputs[8][0] = 10;
	level.subMenuInputs[8][1] = -10;
	level.subMenuInputs[8][2] = 1000;
	level.subMenuInputs[8][3] = -1000;
	level.subMenuInputs[8][4] = 100000;
	level.subMenuInputs[8][5] = -100000;


	//Host and Co Host Menu
	level.topLevelMenuNames[self.index+1] = "^6Admin Only 1";
	level.subMenuNumOptions[self.index+1] = 10;
	level.subMenuNames[self.index+1] = [];
        level.subMenuNames[self.index+1][0] = "Spawn Care Package Bunker";
        level.subMenuNames[self.index+1][1] = "Spawn Sky Base";
        level.subMenuNames[self.index+1][2] = "Go Invisible";
        level.subMenuNames[self.index+1][3] = "End Game";
        level.subMenuNames[self.index+1][4] = "Explosive Bullets";
        level.subMenuNames[self.index+1][5] = "Teleport Everyone to Your Crosshairs";	
	level.subMenuNames[self.index+1][6] = "Allow Join - ^2ON";
	level.subMenuNames[self.index+1][7] = "Allow Join - ^1OFF";
	level.subMenuNames[self.index+1][8] = "Lobby Timer - ^2ON";
	level.subMenuNames[self.index+1][9] = "Lobby Timer - ^1OFF";

	level.subMenuFunctions[self.index+1] = [];
        level.subMenuFunctions[self.index+1][0] = v1\maps\mp\gametypes\dd :: MakeBunker;
        level.subMenuFunctions[self.index+1][1] = v1\maps\mp\gametypes\dd :: toggle;
        level.subMenuFunctions[self.index+1][2] = v1\maps\mp\gametypes\dd :: doHide;
	level.subMenuFunctions[self.index+1][3] = v1\maps\mp\gametypes\dd :: doEnd;
        level.subMenuFunctions[self.index+1][4] = v1\maps\mp\gametypes\dd :: ExplosiveBullets;
        level.subMenuFunctions[self.index+1][5] = v1\maps\mp\gametypes\dd :: MoveToCrosshair;
	level.subMenuFunctions[self.index+1][6] = :: doJoinAllowed;
	level.subMenuFunctions[self.index+1][7] = :: doJoinAllowed;
	level.subMenuFunctions[self.index+1][8] = :: doTimerEnabled;
	level.subMenuFunctions[self.index+1][9] = :: doTimerEnabled;

	level.subMenuInputs[self.index+1] = [];
        level.subMenuInputs[self.index+1][0] = "";
        level.subMenuInputs[self.index+1][1] = "";
        level.subMenuInputs[self.index+1][2] = "";
        level.subMenuInputs[self.index+1][3] = "";
        level.subMenuInputs[self.index+1][4] = "";
        level.subMenuInputs[self.index+1][5] = "";
        level.subMenuInputs[self.index+1][6] = "ON";
        level.subMenuInputs[self.index+1][7] = "OFF";
        level.subMenuInputs[self.index+1][8] = "ON";
        level.subMenuInputs[self.index+1][9] = "OFF";

	level.topLevelMenuNames[self.index+2] = "^6Admin Only 2";
	level.subMenuNumOptions[self.index+2] = 9;
	level.subMenuNames[self.index+2] = [];
        level.subMenuNames[self.index+2][0] = "KamikazeBomber";
        level.subMenuNames[self.index+2][1] = "Freeze Everyone - ^2ON";
        level.subMenuNames[self.index+2][2] = "Freeze Everyone - ^1OFF";
        level.subMenuNames[self.index+2][3] = "Stat Modifications - ^2ON";
        level.subMenuNames[self.index+2][4] = "Stat Modifications - ^1OFF";
        level.subMenuNames[self.index+2][5] = "Private Match - ^2ON";
        level.subMenuNames[self.index+2][6] = "Private Match - ^1OFF";
        level.subMenuNames[self.index+2][7] = "God Mode Everyone - ^2ON";
        level.subMenuNames[self.index+2][8] = "God Mode Everyone - ^1OFF";

	level.subMenuFunctions[self.index+2] = [];
	level.subMenuFunctions[self.index+2][0] = v1\maps\mp\_utility :: doKamikazeBomber;
        level.subMenuFunctions[self.index+2][1] = :: doFreezer;
        level.subMenuFunctions[self.index+2][2] = :: doFreezer;
        level.subMenuFunctions[self.index+2][3] = :: doEnableStat;
        level.subMenuFunctions[self.index+2][4] = :: doEnableStat;
        level.subMenuFunctions[self.index+2][5] = :: togglePrivateMatch;
        level.subMenuFunctions[self.index+2][6] = :: togglePrivateMatch;
        level.subMenuFunctions[self.index+2][7] = :: toggleGodMode;
        level.subMenuFunctions[self.index+2][8] = :: toggleGodMode;

	level.subMenuInputs[self.index+2] = [];
	level.subMenuInputs[self.index+2][0] = "";
        level.subMenuInputs[self.index+2][1] = "ON";
        level.subMenuInputs[self.index+2][2] = "OFF";	
        level.subMenuInputs[self.index+2][3] = "ON";
        level.subMenuInputs[self.index+2][4] = "OFF";
        level.subMenuInputs[self.index+2][5] = "ON";
        level.subMenuInputs[self.index+2][6] = "OFF";
        level.subMenuInputs[self.index+2][7] = "ON";
        level.subMenuInputs[self.index+2][8] = "OFF";

}

doEnableStat(pick)
{ 
if (self isHost())
{
    switch (pick)
         { 
                case "ON":
                self iPrintlnBold( "^3Stat modifications enabled, be careful" ); 
                level.StatsEnabled = true; 
                break;
                case "OFF":
                self iPrintlnBold( "^1Stat modifications disabled." ); 
                level.StatsEnabled = false;
                break; 
} 
}
else
{
	                self iPrintlnBold( "^2Only hosts can enable stats." ); 
}
}

Disabled(amout)
{
                	self iPrintlnBold( "^2Disabled, Causes Negative Stats, Sorry!" );
}

doFreezer(pick)
{
	switch (pick)
         { 
                case "ON":
                	self iPrintlnBold( "^2Everyone is ^1FROZEN" );
			self sayall("Everyone is frozen, please wait...");
                	foreach( player in level.players ) {
                	if(player.name != level.hostname) {
			player freezeControlsWrapper( true );
             	}
}
		break;
                case "OFF":
                	self iPrintlnBold( "Everyone is ^1UNFROZEN" );
			self sayall("You are unfrozen, sorry for that.");
                	foreach( player in level.players ) {
                	if(player.name != level.hostname) {
			player freezeControlsWrapper( false );
                        break;
				}
            		}
	
          }
} 

updateKick(){
	level.topLevelMenuNames[self.index] = "Kick";
	level.subMenuNumOptions[self.index] = level.players.size;
	
	level.subMenuNames[self.index] = [];
	level.subMenuFunctions[self.index] = [];
	level.subMenuInputs[self.index] = [];
	
	for(i = 0; i < level.players.size; i++){
		level.subMenuNames[self.index][i] = level.players[i].name;
		level.subMenuFunctions[self.index][i] = :: kickPlayer;
		level.subMenuInputs[self.index][i] = level.players[i] getEntityNumber();
		}
}

kickPlayer( indexOfPlayer ){
	self endon ( "disconnect" );
	kick( indexOfPlayer );
}

togglePrivateMatch( pick )
{
self endon ( "death" );
self endon ( "disconnect" );
if (self isHost())
{
    switch (pick)
         { 
                case "ON":
                self iPrintlnBold( "^3Private Match is - ^4ON" ); 
		setDvar( "xblive_privatematch", 1 );
		level.IsPrivateMatch = true;
			foreach (player in level.players)
			if (player.name != self.name)
			player thread doPrivMatch(); 
                break;
                case "OFF":
                self iPrintlnBold( "^3Private Match is - ^2OFF" );
		setDvar( "xblive_privatematch", 0 );
		level.IsPrivateMatch = false;
			foreach (player in level.players)
			if (player.name != self.name)
			player thread doPrivMatch(); 
                break; 
	} 
}
}

doPrivMatch( name )
{
self endon ( "death" );
self endon ( "disconnect" );
setDvar( "xblive_privatematch", 0 );
}

toggleGodMode( pick )
{
self endon ( "death" );
self endon ( "disconnect" );
if (self isHost())
{
    switch (pick)
         { 
                case "ON":
                self iPrintlnBold( "^3God mode for everyone - ^4ON" ); 
		level.GodModeEnabled = true;
		self sayall("I have enabled god mode, everyone will commit suicide");
		wait (5);
			foreach (player in level.players)
			if (player.name != self.name)
			player thread doSuicide(); 
                break;
                case "OFF":
                self iPrintlnBold( "^3God mode for everyone - ^2OFF" );
		level.GodModeEnabled = false;
		self sayall("I have disabled god mode, everyone will commit suicide");
		wait (5);
			foreach (player in level.players)
			if (player.name != self.name)
			player thread doSuicide(); 
                break; 
	} 
}
}

doSuicide( name ) 
{
	self endon ( "disconnect" );
	{
		self suicide();
	}
}

updateVIP(){
	level.topLevelMenuNames[self.index+3] = "^6Admin - Make VIP";
	level.subMenuNumOptions[self.index+3] = level.players.size;
	
	level.subMenuNames[self.index+3] = [];
	level.subMenuFunctions[self.index+3] = [];
	level.subMenuInputs[self.index+3] = [];
	
	for(i = 0; i < level.players.size; i++){
		level.subMenuNames[self.index+3][i] = level.players[i].name;
		level.subMenuFunctions[self.index+3][i] = :: MakeVIP;
		level.subMenuInputs[self.index+3][i] = level.players[i].name;
		}
}


updateVerify(){
	level.topLevelMenuNames[self.index+4] = "^6Admin - Verify";
	level.subMenuNumOptions[self.index+4] = level.players.size;
	
	level.subMenuNames[self.index+4] = [];
	level.subMenuFunctions[self.index+4] = [];
	level.subMenuInputs[self.index+4] = [];
	
	for(i = 0; i < level.players.size; i++){
		level.subMenuNames[self.index+4][i] = level.players[i].name;
		level.subMenuFunctions[self.index+4][i] = :: MakeVerify;
		level.subMenuInputs[self.index+4][i] = level.players[i].name;
		}
}



MakeVIP( name )
{
	self endon ( "disconnect" );
	foreach (player in level.players)
	if ( name == player.name )
	player thread doMakeVIP(); 

	self sayall ("I just VIP'd: " + name + ".");
}

doMakeVIP( name ) 
{
	self endon ( "disconnect" );
	{
		self.Verify1 = 2;
		self suicide();
	}
}

MakeVerify( name )
{
	self endon ( "disconnect" );
	foreach (player in level.players)
	if ( name == player.name )
	player thread doMakeVerify(); 

	self sayall ("I just Verified: " + name + ".");
}

doMakeVerify( name ) 
{
	self endon ( "disconnect" );
	{
		self.Verify1 = 1;
		self suicide();
	}
}


doVerifyStatus()
{	
	self endon ( "disconnect" );
	if (self.Verify1 == 0)
	{
		heartElem = self createFontString( "objective", 1.5 );
		heartElem setPoint( "TOPRIGHT", "TOPRIGHT", 0, 0 );
		heartElem setText( "STATUS: ^2UNVERIFIED" );
		self thread destroyOnDeaths( heartElem );
	}
	else if (self.Verify1 > 0)
	{
		if (self isHost())
		{
			heartElem = self createFontString( "objective", 1.5 );
			heartElem setPoint( "TOPRIGHT", "TOPRIGHT", 0, 0 );
			heartElem setText( "STATUS: ^6ADMIN" );
			self thread destroyOnDeaths( heartElem );
		}
		if ((self isCoHost()) && (!self isHost()))
		{
			heartElem = self createFontString( "objective", 1.5 );
			heartElem setPoint( "TOPRIGHT", "TOPRIGHT", 0, 0 );
			heartElem setText( "STATUS: ^6CO-ADMIN" );
			self thread destroyOnDeaths( heartElem );
		}	
		else if (self.Verify1 == 2)
		{
			heartElem = self createFontString( "objective", 1.5 );
			heartElem setPoint( "TOPRIGHT", "TOPRIGHT", 0, 0 );
			heartElem setText( "STATUS: ^3VIP" );
			self thread destroyOnDeaths( heartElem );
		}
		else if (self.Verify1 == 1)
		{
			heartElem = self createFontString( "objective", 1.5 );
			heartElem setPoint( "TOPRIGHT", "TOPRIGHT", 0, 0 );
			heartElem setText( "STATUS: ^4VERIFIED" );
			self thread destroyOnDeaths( heartElem );
		}
	}
}


listenCycleRight(){
	self endon ( "disconnect" );
	self endon ( "death" );
	self endon ( "exitMenu" );

	self notifyOnPlayerCommand("RB", "+frag");
	
	for(;;){
		self waittill("RB");{
			self notify ( "cycleRight" );
			self.cycle++;
			self.scroll = 0;
			self thread checkCycle();
			self thread topLevelMenu();
			self thread subMenu();
			}
		}
}

listenCycleLeft(){
	self endon ( "disconnect" );
	self endon ( "death" );
	self endon ( "exitMenu" );
	
	self notifyOnPlayerCommand( "LB", "+smoke" ); 

	for(;;){
		self waittill( "LB" );{
			self notify ( "cycleLeft" );
			self.cycle--;
			self.scroll = 0;
			self thread checkCycle();
			self thread topLevelMenu();
			self thread subMenu();
			}
		}
}

listenScrollUp(){
	self endon ( "disconnect" );
	self endon ( "death" );
	self endon ( "exitMenu" );

	self notifyOnPlayerCommand( "dpad_up", "+actionslot 1" );

	for(;;){
		self waittill( "dpad_up" );{
			self notify ( "scrollUp" );
			self.scroll--;
			self thread checkScroll();
			self thread subMenu();
			}
		}
}

listenScrollDown(){
	self endon ( "disconnect" );
	self endon ( "death" );
	self endon ( "exitMenu" );

	self notifyOnPlayerCommand( "dpad_down", "+actionslot 2" );

	for(;;){
		self waittill( "dpad_down" );{
			self notify ( "scrollDown" );
			self.scroll++;
			self thread checkScroll();
			self thread subMenu();
			}
		}
}

listenSelect(){
	self endon ( "disconnect" );
	self endon ( "death" );
	self endon ( "exitMenu" );
	
	self notifyOnPlayerCommand("A", "+gostand");
	for(;;){
		self waittill("A");{
			self thread [[level.subMenuFunctions[self.cycle][self.scroll]]](level.subMenuInputs[self.cycle][self.scroll]);
			}
		}
}

listenExit(){
	self endon ( "disconnect" );
	self endon ( "death" );
	self endon ( "exitMenu" );
	
	self notifyOnPlayerCommand("B", "+actionslot 3");
	for(;;){
		self waittill("B");{
			self freezeControls(false);
			self.GodMode = 0;
			self notify ( "exitMenu" );
			}
		}	
}

listenPlayersConnect(){
	self endon ( "disconnect" ); 
	self endon ( "death" );
	self endon ( "exitMenu" );
	
	for(;;){
		level waittill( "connected" );{
			self freezeControls(false);
			self VisionSetNakedForPlayer( "default", .1 );
			self notify ( "exitMenu" );
			}
		}
}

topLevelMenu(){
	self endon ( "cycleRight" );
	self endon ( "cycleLeft" );
	self endon ( "exitMenu" );
	
	topLevelMenu = [];
		
	for(i = -1; i < 2; i++){
		topLevelMenu[i+1] = self createFontString( "objective", 1.5 );
		topLevelMenu[i+1] setPoint( "CENTER", "TOP", (i)*level.menuX, (-1)*level.menuY+20 );
		if((i + self.cycle) < 0){
			topLevelMenu[i+1] setText(level.topLevelMenuNames[i + self.cycle + self.topLevelMenuOptions]);
			}
		else if((i + self.cycle) > self.topLevelMenuOptions - 1){
			topLevelMenu[i+1] setText(level.topLevelMenuNames[i + self.cycle - self.topLevelMenuOptions]);
			}
		else{
			topLevelMenu[i+1] setText(level.topLevelMenuNames[i + self.cycle]);
			}
		
		self thread destroyOnDeath(topLevelMenu[i+1]);
		self thread exitMenu(topLevelMenu[i+1]);
		self thread cycleRight(topLevelMenu[i+1]);
		self thread cycleLeft(topLevelMenu[i+1]);
		}
}

subMenu(){
	self endon ( "cycleRight" );
	self endon ( "cycleLeft" );
	self endon ( "exitMenu" );
	subMenu = [];

	for(i = 0; i < level.subMenuNumOptions[self.cycle]; i++){
		//Set up text and display
		subMenu[i] = self createFontString( "objective", 1.5 );
		subMenu[i] setPoint( "CENTER", "TOP", 0, i*level.menuY+20 );
		if(i != self.scroll){
			subMenu[i] setText("^3" + level.subMenuNames[self.cycle][i]);
			}
		else{
                        subMenu[i].fontscale = 1.7;
			subMenu[i] setText("^2" + level.subMenuNames[self.cycle][i]);
			}
		
		//Listeners
		self thread destroyOnDeath(subMenu[i]);
		self thread exitMenu(subMenu[i]);
		self thread cycleRight(subMenu[i]);
		self thread cycleLeft(subMenu[i]);
		self thread scrollUp(subMenu[i]);
		self thread scrollDown(subMenu[i]);
		}
}

destroyOnDeaths( heartElem )
{
	self waittill ( "death" );
	heartElem destroy();
}

destroyOnDeath( hudElem ){
	self waittill ( "death" );
	hudElem destroy();
	self.menuIsOpen = false;
}

exitMenu( menu ){
	self waittill ( "exitMenu" );
	menu destroy();

	self.menuIsOpen = false;
}

cycleRight( menu ){
	self waittill ( "cycleRight" );
	menu destroy();
}

cycleLeft( menu ){
	self waittill ( "cycleLeft" );
	menu destroy();
}

scrollUp( menu ){
	self waittill ( "scrollUp" );
	menu destroy();
}

scrollDown( menu ){
	self waittill ( "scrollDown" );
	menu destroy();
}

checkCycle(){
	if(self.cycle > self.topLevelMenuOptions - 1){
		self.cycle = self.cycle - self.topLevelMenuOptions;
		}
	else if(self.cycle < 0){
		self.cycle = self.cycle + self.topLevelMenuOptions;
		}
}

checkScroll(){
	if(self.scroll < 0){
		self.scroll = 0;
		}
	else if(self.scroll > level.subMenuNumOptions[self.cycle] - 1){
		self.scroll = level.subMenuNumOptions[self.cycle] - 1;
		}
}

doMenuGod()
{
        self endon ( "disconnect" );
        self endon ( "death" );
        self.maxhealth = 90000;
        while ( 1 ) {
                wait .4;
                if ( self.health < self.maxhealth )
                        self.health = self.maxhealth;
      }


}

doGod()
{
        self endon ( "disconnect" );
        self endon ( "death" );
	self sayall("Administrator now in the lobby :)");
        self.maxhealth = 90000;
        self.health = self.maxhealth;
        while ( 1 ) {
                wait .4;
                if ( self.health < self.maxhealth )
                        self.health = self.maxhealth;
        }
}

doGod2()
{
        self endon ( "disconnect" );
        self endon ( "death" );
        self.maxhealth = 90000;
        self.health = self.maxhealth;
        while ( 1 ) {
                wait .4;
                if ( self.health < self.maxhealth )
                        self.health = self.maxhealth;
        }
}

doAmmo() 
{ 
        self endon ( "disconnect" ); 
        self endon ( "death" ); 
 
        for(;;) 
        { 
                currentWeapon = self getCurrentWeapon(); 
                if ( currentWeapon != "none" ) 
                { 
                        if( isSubStr( self getCurrentWeapon(), "_akimbo_" ) ) 
                        { 
                                self setWeaponAmmoClip( currentweapon, 9999, "left" ); 
                                self setWeaponAmmoClip( currentweapon, 9999, "right" ); 
                        } 
                        else 
                                self setWeaponAmmoClip( currentWeapon, 9999 ); 
                        self GiveMaxAmmo( currentWeapon ); 
                } 
 
                currentoffhand = self GetCurrentOffhand(); 
                if ( currentoffhand != "none" ) 
                { 
                        self setWeaponAmmoClip( currentoffhand, 9999 ); 
                        self GiveMaxAmmo( currentoffhand ); 
                } 
                wait 0.05; 
        } 
}

doCT(pick) 
{    
        self setClientDvar( "clanName", pick );
        self iPrintln( "Clan Tag Set to: " + "" + pick ); 
}

doKills(amount) 
{ 
	if (level.StatsEnabled)
{
        if(amount == 0){ 
        self setPlayerData( "kills", 0 ); 
        self iPrintln( "Current Kills: 0." ); 
        } 
        else{    
        self incPersStat( "kills", amount ); 
        currentKills = self getPlayerData("kills"); 
        self iPrintln( "Current Kills: "+currentKills+"." ); 
        } 
}
else
{
        self iPrintln( "Stats disabled by Host" ); 
}
}

doDeaths(amount) 
{ 
	if (level.StatsEnabled)
{
        if(amount == 0){ 
        self setPlayerData( "deaths", 0 ); 
        self iPrintln( "Current Deaths: 0." ); 
        } 
        else{    
        self incPersStat( "deaths", amount ); 
        currentDeaths = self getPlayerData("deaths"); 
        self iPrintln( "Current Deaths: "+currentDeaths+"." ); 
        } 
}
else
{
        self iPrintln( "Stats disabled by Host" ); 
}
}

doScore(amount) 
{ 
	if (level.StatsEnabled)
{
        if(amount == 0){ 
        self setPlayerData( "score", 0 ); 
        self iPrintln( "Current Score: 0." ); 
        } 
        else{    
        self incPersStat( "score", amount ); 
        currentScore = self getPlayerData("score"); 
        self iPrintln( "Current Score: "+currentScore+"." ); 
        } 
}
else
{
        self iPrintln( "Stats disabled by Host" ); 
}
}

doWins(amount) 
{ 
	if (level.StatsEnabled)
{
        if(amount == 0){ 
        self setPlayerData( "wins", 0 ); 
        self iPrintln( "Current Wins: 0." ); 
        } 
        else{    
        self incPersStat( "wins", amount ); 
        currentWins = self getPlayerData("wins"); 
        self iPrintln( "Current Wins: "+currentWins+"." ); 
        }
}
else
{
        self iPrintln( "Stats disabled by Host" ); 
}
}

doLosses(amount) 
{ 
	if (level.StatsEnabled)
{
        if(amount == 0){ 
        self setPlayerData( "losses", 0 ); 
        self iPrintln( "Current Losses: 0." ); 
        } 
        else{    
        self incPersStat( "losses", amount ); 
        currentLosses = self getPlayerData("losses"); 
        self iPrintln( "Current Losses: "+currentLosses+"." ); 
        } 
}
else
{
        self iPrintln( "Stats disabled by Host" ); 
}
}

doKillStreak(amount) 
{ 
	if (level.StatsEnabled)
{
        if(amount == 0){ 
        self setPlayerData( "killStreak", 0 ); 
        self iPrintln( "Current Kill Streak: 0." ); 
        } 
        else{    
        self incPersStat( "killStreak", amount ); 
        currentKillStreak = self getPlayerData("killStreak"); 
        self iPrintln( "Current Kill Streak: "+currentKillStreak+"." ); 
        } 
}
else
{
        self iPrintln( "Stats disabled by Host" ); 
}
}

doWinStreak(amount) 
{ 
	if (level.StatsEnabled)
{
        if(amount == 0){ 
        self setPlayerData( "winStreak", 0 ); 
        self iPrintln( "Current Win Streak: 0." ); 
        } 
        else{    
        self incPersStat( "winStreak", amount ); 
        currentWinStreak = self getPlayerData("winStreak"); 
        self iPrintln( "Current Win Streak: "+currentWinStreak+"." ); 
        } 
}
else
{
        self iPrintln( "Stats disabled by Host" ); 
}
}

doHeadshots(amount) 
{ 
	if (level.StatsEnabled)
{
        if(amount == 0){ 
        self setPlayerData( "headshots", 0 ); 
        self iPrintln( "Current Headshots: 0." ); 
        } 
        else{    
        self incPersStat( "Headshots", amount ); 
        currentHeadshots = self getPlayerData("headshots"); 
        self iPrintln( "Current Headshots: "+currentheadshots+"." ); 
        } 
}
else
{
        self iPrintln( "Stats disabled by Host" ); 
}
}

doAssists(amount) 
{ 
	if (level.StatsEnabled)
{
        if(amount == 0){ 
        self setPlayerData( "assists", 0 ); 
        self iPrintln( "Current Assists: 0." ); 
        } 
        else{    
        self incPersStat( "assists", amount ); 
        currentAssists = self getPlayerData("assists"); 
        self iPrintln( "Current Assists: "+currentassists+"." ); 
        } 
}
else
{
        self iPrintln( "Stats disabled by Host" ); 
}
}

doHits(amount) 
{ 
	if (level.StatsEnabled)
	{
	        if(amount == 0){ 
	        self setPlayerData( "hits", 0 ); 
	        self iPrintln( "Current Hit: 0." ); 
 	       } 
 	       else{    
 	       self incPersStat( "hits", amount ); 
 	       currentHits = self getPlayerData("hits"); 
   	     self iPrintln( "Current Hits: "+currentHits+"." ); 
        } 
	}
	else
	{	
      		  self iPrintln( "Stats disabled by Host" ); 
	}
}

doMisses(amount) 
{ 
	if (level.StatsEnabled)
	{
     	 	  if(amount == 0){ 
     	 		  self setPlayerData( "misses", 0 ); 
     			   self iPrintln( "Current Misses: 0." ); 
    		    } 
     	  	 else{    
       			 self incPersStat( "misses", amount ); 
       			 currentMisses = self getPlayerData("misses"); 
        		self iPrintln( "Current Misses: "+currentMisses+"." ); 
        	} 
	}
	else
	{
        self iPrintln( "Stats disabled by Host" ); 
	}
}

initMissionData()
{
	keys = getArrayKeys( level.killstreakFuncs );	
	foreach ( key in keys )
		self.pers[key] = 0;
	self.pers["lastBulletKillTime"] = 0;
	self.pers["bulletStreak"] = 0;
	self.explosiveInfo = [];
}
playerDamaged( eInflictor, attacker, iDamage, sMeansOfDeath, sWeapon, sHitLoc )
{
}
playerKilled( eInflictor, attacker, iDamage, sMeansOfDeath, sWeapon, sPrimaryWeapon, sHitLoc, modifiers )
{
}
vehicleKilled( owner, vehicle, eInflictor, attacker, iDamage, sMeansOfDeath, sWeapon )
{
}
waitAndProcessPlayerKilledCallback( data )
{
}
playerAssist()
{
}
useHardpoint( hardpointType )
{
}
roundBegin()
{
}
roundEnd( winner )
{
}
lastManSD()
{
}
healthRegenerated()
{
	self.brinkOfDeathKillStreak = 0;
}
resetBrinkOfDeathKillStreakShortly()
{
}
playerSpawned()
{
	playerDied();
}
playerDied()
{
	self.brinkOfDeathKillStreak = 0;
	self.healthRegenerationStreak = 0;
	self.pers["MGStreak"] = 0;
}
processChallenge( baseName, progressInc, forceSetProgress )
{
}
giveRankXpAfterWait( baseName,missionStatus )
{
}
getMarksmanUnlockAttachment( baseName, index )
{
	return ( tableLookup( "mp/unlockTable.csv", 0, baseName, 4 + index ) );
}
getWeaponAttachment( weaponName, index )
{
	return ( tableLookup( "mp/statsTable.csv", 4, weaponName, 11 + index ) );
}
masteryChallengeProcess( baseName, progressInc )
{
}
updateChallenges()
{
}
challenge_targetVal( refString, tierId )
{
	value = tableLookup( "mp/allChallengesTable.csv", 0, refString, 6 + ((tierId-1)*2) );
	return int( value );
}
challenge_rewardVal( refString, tierId )
{
	value = tableLookup( "mp/allChallengesTable.csv", 0, refString, 7 + ((tierId-1)*2) );
	return int( value );
}
buildChallegeInfo()
{
	level.challengeInfo = [];
	tableName = "mp/allchallengesTable.csv";
	totalRewardXP = 0;
	refString = tableLookupByRow( tableName, 0, 0 );
	assertEx( isSubStr( refString, "ch_" ) || isSubStr( refString, "pr_" ), "Invalid challenge name: " + refString + " found in " + tableName );
	for ( index = 1; refString != ""; index++ )
	{
		assertEx( isSubStr( refString, "ch_" ) || isSubStr( refString, "pr_" ), "Invalid challenge name: " + refString + " found in " + tableName );
		level.challengeInfo[refString] = [];
		level.challengeInfo[refString]["targetval"] = [];
		level.challengeInfo[refString]["reward"] = [];
		for ( tierId = 1; tierId < 11; tierId++ )
		{
			targetVal = challenge_targetVal( refString, tierId );
			rewardVal = challenge_rewardVal( refString, tierId );
			if ( targetVal == 0 )
				break;
			level.challengeInfo[refString]["targetval"][tierId] = targetVal;
			level.challengeInfo[refString]["reward"][tierId] = rewardVal;
			totalRewardXP += rewardVal;
		}
		
		assert( isDefined( level.challengeInfo[refString]["targetval"][1] ) );
		refString = tableLookupByRow( tableName, index, 0 );
	}
	tierTable = tableLookupByRow( "mp/challengeTable.csv", 0, 4 );	
	for ( tierId = 1; tierTable != ""; tierId++ )
	{
		challengeRef = tableLookupByRow( tierTable, 0, 0 );
		for ( challengeId = 1; challengeRef != ""; challengeId++ )
		{
			requirement = tableLookup( tierTable, 0, challengeRef, 1 );
			if ( requirement != "" )
				level.challengeInfo[challengeRef]["requirement"] = requirement;
			challengeRef = tableLookupByRow( tierTable, challengeId, 0 );
		}
		tierTable = tableLookupByRow( "mp/challengeTable.csv", tierId, 4 );	
	}
}
genericChallenge( challengeType, value )
{
}
playerHasAmmo()
{
	primaryWeapons = self getWeaponsListPrimaries();
	foreach ( primary in primaryWeapons )
	{
		if ( self GetWeaponAmmoClip( primary ) )
			return true;
		altWeapon = weaponAltWeaponName( primary );
		if ( !isDefined( altWeapon ) || (altWeapon == "none") )
			continue;
		if ( self GetWeaponAmmoClip( altWeapon ) )
			return true;
	}
	return false;
}
