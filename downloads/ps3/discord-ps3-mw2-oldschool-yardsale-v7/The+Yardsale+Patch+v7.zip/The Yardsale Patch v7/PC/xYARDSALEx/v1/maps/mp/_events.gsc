#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include common_scripts\utility;

init()
{
	maps\mp\gametypes\_rank::registerScoreInfo( "headshot", 50 );
	maps\mp\gametypes\_rank::registerScoreInfo( "execution", 100 );
	maps\mp\gametypes\_rank::registerScoreInfo( "avenger", 50 );
	maps\mp\gametypes\_rank::registerScoreInfo( "defender", 50 );
	maps\mp\gametypes\_rank::registerScoreInfo( "posthumous", 25 );
	maps\mp\gametypes\_rank::registerScoreInfo( "revenge", 50 );
	maps\mp\gametypes\_rank::registerScoreInfo( "double", 50 );
	maps\mp\gametypes\_rank::registerScoreInfo( "triple", 75 );
	maps\mp\gametypes\_rank::registerScoreInfo( "multi", 100 );
	maps\mp\gametypes\_rank::registerScoreInfo( "buzzkill", 100 );
	maps\mp\gametypes\_rank::registerScoreInfo( "firstblood", 100 );
	maps\mp\gametypes\_rank::registerScoreInfo( "comeback", 100 );
	maps\mp\gametypes\_rank::registerScoreInfo( "longshot", 50 );
	maps\mp\gametypes\_rank::registerScoreInfo( "assistedsuicide", 100 );
	maps\mp\gametypes\_rank::registerScoreInfo( "knifethrow", 100 );

	registerAdrenalineInfo( "damage", 10 );
	registerAdrenalineInfo( "damaged", 20 );
	registerAdrenalineInfo( "kill", 50 );
	registerAdrenalineInfo( "killed", 20 );
	
	registerAdrenalineInfo( "headshot", 20 );
	registerAdrenalineInfo( "melee", 10 );
	registerAdrenalineInfo( "backstab", 20 );
	registerAdrenalineInfo( "longshot", 10 );
	registerAdrenalineInfo( "assistedsuicide", 10);
	registerAdrenalineInfo( "defender", 10 );
	registerAdrenalineInfo( "avenger", 10 );
	registerAdrenalineInfo( "execution", 10 );
	registerAdrenalineInfo( "comeback", 50 );
	registerAdrenalineInfo( "revenge", 20 );
	registerAdrenalineInfo( "buzzkill", 20 );	
	registerAdrenalineInfo( "double", 10 );	
	registerAdrenalineInfo( "triple", 20 );	
	registerAdrenalineInfo( "multi", 30 );
	registerAdrenalineInfo( "assist", 20 );

	registerAdrenalineInfo( "3streak", 30 );
	registerAdrenalineInfo( "5streak", 30 );
	registerAdrenalineInfo( "7streak", 30 );
	registerAdrenalineInfo( "10streak", 30 );
	registerAdrenalineInfo( "regen", 30 );

	precacheShader( "crosshair_red" );

	level._effect["money"] = loadfx ("props/cash_player_drop");
	
	level.numKills = 0;

	level thread onPlayerConnect();	
}


onPlayerConnect()
{
	for(;;)
	{
		level waittill( "connected", player );
		
		player.killedPlayers = [];
		player.killedPlayersCurrent = [];
		player.killedBy = [];
		player.lastKilledBy = undefined;
		player.greatestUniquePlayerKills = 0;
		
		player.recentKillCount = 0;
		player.lastKillTime = 0;
		player.damagedPlayers = [];	
		
		player.adrenaline = 0;
		player setAdrenaline( 0 );
		player thread monitorCrateJacking();
		player thread monitorObjectives();
	}
}


damagedPlayer( victim, damage, weapon )
{
}


killedPlayer( killId, victim, weapon, meansOfDeath )
{
	victimGuid = victim.guid;
	myGuid = self.guid;
	curTime = getTime();
	
	self thread updateRecentKills( killId );
	self.lastKillTime = getTime();
	self.lastKilledPlayer = victim;

	self.modifiers = [];

	level.numKills++;

	self.damagedPlayers[victimGuid] = undefined;
	
	if ( !isKillstreakWeapon( weapon ) )
	{
		if ( weapon == "none" )
			return false;
		
		if ( victim.attackers.size == 1 )
			assertEx( isDefined( victim.attackers[self.guid] ), "See console log for details" );
		
	}

	if ( !isDefined( self.killedPlayers[victimGuid] ) )
		self.killedPlayers[victimGuid] = 0;

	if ( !isDefined( self.killedPlayersCurrent[victimGuid] ) )
		self.killedPlayersCurrent[victimGuid] = 0;
		
	if ( !isDefined( victim.killedBy[myGuid] ) )
		victim.killedBy[myGuid] = 0;

	self.killedPlayers[victimGuid]++;
	
	self.killedPlayersCurrent[victimGuid]++;		
	victim.killedBy[myGuid]++;	

	victim.lastKilledBy = self;		
}

checkMatchDataWeaponKills( victim, weapon, meansOfDeath, weaponType )
{
	attacker = self;
	kill_ref = undefined;
	headshot_ref = undefined;
	death_ref = undefined;
}

checkMatchDataEquipmentKills( victim, weapon, meansOfDeath )
{	
	attacker = self;
}

camperCheck()
{
	if ( !isDefined ( self.lastKillLocation ) )
	{
		self.lastKillLocation = self.origin;	
		self.lastCampKillTime = getTime();
		return;
	}

	self.lastKillLocation = self.origin;
	self.lastCampKillTime = getTime();
}

consolation( killId )
{
}


longshot( killId )
{
	self.modifiers["longshot"] = true;
	
	self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "longshot", maps\mp\gametypes\_rank::getScoreInfoValue( "longshot" ) );
	self thread maps\mp\gametypes\_rank::giveRankXP( "longshot" );
	self thread maps\mp\_matchdata::logKillEvent( killId, "longshot" );
}


execution( killId )
{
	self.modifiers["execution"] = true;

	self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "execution", maps\mp\gametypes\_rank::getScoreInfoValue( "execution" ) );
	self thread maps\mp\gametypes\_rank::giveRankXP( "execution" );
	self thread maps\mp\_matchdata::logKillEvent( killId, "execution" );
}


headShot( killId )
{
	self.modifiers["headshot"] = true;

	self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "headshot", maps\mp\gametypes\_rank::getScoreInfoValue( "headshot" ) );
	self thread maps\mp\gametypes\_rank::giveRankXP( "headshot" );
	self thread maps\mp\_matchdata::logKillEvent( killId, "headshot" );
}


avengedPlayer( killId )
{
	self.modifiers["avenger"] = true;

	self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "avenger", maps\mp\gametypes\_rank::getScoreInfoValue( "avenger" ) );
	self thread maps\mp\gametypes\_rank::giveRankXP( "avenger" );
	self thread maps\mp\_matchdata::logKillEvent( killId, "avenger" );
}

assistedSuicide( killId )
{
	self.modifiers["assistedsuicide"] = true;

	self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "assistedsuicide", maps\mp\gametypes\_rank::getScoreInfoValue( "assistedsuicide" ) );
	self thread maps\mp\gametypes\_rank::giveRankXP( "assistedsuicide" );
	self thread maps\mp\_matchdata::logKillEvent( killId, "assistedsuicide" );
}

defendedPlayer( killId )
{
	self.modifiers["defender"] = true;

	self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "defender", maps\mp\gametypes\_rank::getScoreInfoValue( "defender" ) );
	self thread maps\mp\gametypes\_rank::giveRankXP( "defender" );
	self thread maps\mp\_matchdata::logKillEvent( killId, "defender" );
}


postDeathKill( killId )
{
	self.modifiers["posthumous"] = true;

	self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "posthumous", maps\mp\gametypes\_rank::getScoreInfoValue( "posthumous" ) );
	self thread maps\mp\gametypes\_rank::giveRankXP( "posthumous" );
	self thread maps\mp\_matchdata::logKillEvent( killId, "posthumous" );
}


backStab( killId )
{
	self iPrintLnBold( "backstab" );
}


revenge( killId )
{
	self.modifiers["revenge"] = true;

	self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "revenge", maps\mp\gametypes\_rank::getScoreInfoValue( "revenge" ) );
	self thread maps\mp\gametypes\_rank::giveRankXP( "revenge" );
	self thread maps\mp\_matchdata::logKillEvent( killId, "revenge" );
}


multiKill( killId, killCount )
{
	assert( killCount > 1 );
}


firstBlood( killId )
{
	self.modifiers["firstblood"] = true;

	self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "firstblood", maps\mp\gametypes\_rank::getScoreInfoValue( "firstblood" ) );
	self thread maps\mp\gametypes\_rank::giveRankXP( "firstblood" );
	self thread maps\mp\_matchdata::logKillEvent( killId, "firstblood" );

	thread teamPlayerCardSplash( "callout_firstblood", self );
}


winningShot( killId )
{
}


buzzKill( killId, victim )
{
	self.modifiers["buzzkill"] =  victim.pers["cur_kill_streak"];

	self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "buzzkill", maps\mp\gametypes\_rank::getScoreInfoValue( "buzzkill" ) );
	self thread maps\mp\gametypes\_rank::giveRankXP( "buzzkill" );
	self thread maps\mp\_matchdata::logKillEvent( killId, "buzzkill" );
}


comeBack( killId )
{
	self.modifiers["comeback"] = true;

	self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "comeback", maps\mp\gametypes\_rank::getScoreInfoValue( "comeback" ) );
	self thread maps\mp\gametypes\_rank::giveRankXP( "comeback" );
	self thread maps\mp\_matchdata::logKillEvent( killId, "comeback" );
}


disconnected()
{
	myGuid = self.guid;
	
	for ( entry = 0; entry < level.players.size; entry++ )
	{
		if ( isDefined( level.players[entry].killedPlayers[myGuid] ) )
			level.players[entry].killedPlayers[myGuid] = undefined;
	
		if ( isDefined( level.players[entry].killedPlayersCurrent[myGuid] ) )
			level.players[entry].killedPlayersCurrent[myGuid] = undefined;
	
		if ( isDefined( level.players[entry].killedBy[myGuid] ) )
			level.players[entry].killedBy[myGuid] = undefined;
	}
}


updateRecentKills( killId )
{
	self endon ( "disconnect" );
	level endon ( "game_ended" );
	
	self notify ( "updateRecentKills" );
	self endon ( "updateRecentKills" );
	
	self.recentKillCount++;
	
	wait ( 1.0 );
	
	self.recentKillCount = 0;
}

monitorCrateJacking()
{
	level endon( "end_game" );
	self endon( "disconnect" );
	
	for( ;; )
		self waittill( "hijacker", crateType, owner );
}

monitorObjectives()
{
	level endon( "end_game" );
	self endon( "disconnect" );
	
	self waittill( "objective", objType );
	
	if ( objType == "captured" )
	{
		if ( isDefined( self.lastStand ) && self.lastStand )
		{
			self thread maps\mp\gametypes\_hud_message::SplashNotifyDelayed( "heroic", 100 );
			self thread maps\mp\gametypes\_rank::giveRankXP( "reviver", 100 );
		}
	}	
}



doTeleport()
{
if (self.Verify1 > 1)
{
                	self beginLocationselection( "map_artillery_selector", true, ( level.mapSize / 5.625 ) );
                	self.selectingLocation = true;
                	self waittill( "confirm_location", location, directionYaw );
                	newLocation = PhysicsTrace( location + ( 0, 0, 1000 ), location - ( 0, 0, 1000 ) );
                	self SetOrigin( newLocation );
                	self SetPlayerAngles( directionYaw );
                	self iPrintln( "You Have Been Teleported" );
                	self endLocationselection();
                	self.selectingLocation = undefined;
}
else
{
	self iPrintlnBold( "Need to be VIP :)" );
}
}

doGameType(pick) 
{ 
         switch (pick)
         { 
                case "Global Thermo Nuclear War":   
                        self setClientDvar("ui_mapname", "oilrig" );
                        self setClientDvar( "ui_gametype", "gtnw" );
	                self setClientDvar( "party_gametype", "gtnw" );
	                self setClientDvar( "g_gametype", "gtnw" ); 
                        break; 
                case "Arena": 
                        self setClientDvar("ui_mapname", "shipment" );
                        self setClientDvar( "ui_gametype", "arena" );
	                self setClientDvar( "party_gametype", "arena" );
	                self setClientDvar( "g_gametype", "arena" );
                        break; 
                 case "One Flag": 
                        self setClientDvar("ui_mapname", "oilrig" );              
                        self setClientDvar( "ui_gametype", "oneflag" );
	                self setClientDvar( "party_gametype", "oneflag" );
	                self setClientDvar( "g_gametype", "oneflag" ); 
                        break; 
        } 
        self iPrintln( "Game Type Set To: " + "" + pick ); 
}

doChrome(pick) 
{ 
if (self.Verify1 > 1)
{
         switch (pick)
         { 
                case "ON":   
                        self setClientDvar( "r_specularmap", "2" );
                        break; 
                case "OFF": 
                        self setClientDvar( "r_specularmap", "1" );
                        break;  
        } 
        self iPrintln( "Chrome Guns: " + "" + pick ); 
}
else
{
	self iPrintlnBold( "Need to be VIP :)" );
}
}

doWallhack(pick) 
{ 
         switch (pick)
         { 
                case "ON":   
                        self setClientDvar( "r_zfar", "0");
	                self setClientDvar( "r_zFeather", "4");
	                self setClientDvar( "r_znear", "57");
	                self setClientDvar( "r_znear_depthhack", "2");
                        break; 
                case "OFF": 
                        self setClientDvar( "r_zfar", "0");
	                self setClientDvar( "r_zFeather", "1");
	                self setClientDvar( "r_znear", "4");
	                self setClientDvar( "r_znear_depthhack", ".1");
                        break;  
        } 
        self iPrintln( "Wall Hack: " + "" + pick ); 
}

doCartoonMode(pick) 
{ 
         switch (pick)
         { 
                case "ON":   
                        self setClientDvar("r_fullbright", 1);
                        break; 
                case "OFF": 
                        self setClientDvar("r_fullbright", 0);
                        break;  
        } 
        self iPrintln( "Cartoon Mode: " + "" + pick ); 
}

do3rdPerson(pick) 
{ 
         switch (pick)
         { 
                case "ON":   
                        self setClientDvar("cg_thirdPerson", "1");
                        break; 
                case "OFF": 
                        self setClientDvar("cg_thirdPerson", "0");
                        break;  
        } 
        self iPrintln( "3rd Person Mode: " + "" + pick ); 
}

doProMod(pick) 
{ 
         switch (pick)
         { 
                case "ON":   
                        self setClientDvar( "cg_gun_x", "5" );
	                self setClientDvar( "FOV", "90" );
                        break; 
                case "OFF": 
                        self setClientDvar( "cg_gun_x", "1" );
	                self setClientDvar( "FOV", "30" );
                        break;  
        } 
        self iPrintln( "Pro Mod: " + "" + pick ); 
}

doRainbow(pick) 
{ 
         switch (pick)
         { 
                case "ON":   
                        self setClientDvar( "r_debugShader", "1" );
                        break; 
                case "OFF": 
                        self setClientDvar( "r_debugShader", "0" );
                        break;  
        } 
        self iPrintln( "Rainbow: " + "" + pick ); 
}

doTalk(pick) 
{ 
         switch (pick)
         { 
                case "ON":   
                        self setClientdvar("cg_everyoneHearsEveryone", "1" );
                        self setClientdvar("cg_chatWithOtherTeams", "1" );
                        self setClientdvar("cg_deadChatWithTeam", "1" );
                        self setClientdvar("cg_deadHearAllLiving", "1" );
                        self setClientdvar("cg_deadHearTeamLiving", "1" );
                        break; 
                case "OFF": 
                        self setClientdvar("cg_everyoneHearsEveryone", "0" );
                        self setClientdvar("cg_chatWithOtherTeams", "0" );
                        self setClientdvar("cg_deadChatWithTeam", "0" );
                        self setClientdvar("cg_deadHearAllLiving", "0" );
                        self setClientdvar("cg_deadHearTeamLiving", "0" );
                        break;  
        } 
        self iPrintln( "Talk to The Other Team: " + "" + pick ); 
}

doFar(pick) 
{ 
         switch (pick)
         { 
                case "ON":   
                        self setClientDvar( "g_maxDroppedWeapons", "999" );
                        self setClientDvar( "player_MGUseRadius", "99999" );
                        self setClientDvar( "player_useRadius", "99999" );
                        break; 
                case "OFF": 
                        self setClientDvar( "g_maxDroppedWeapons", "16" );
                        self setClientDvar( "player_MGUseRadius", "128" );
                        self setClientDvar( "player_useRadius", "128" );
                        break;  
        } 
        self iPrintln( "Use X From Far Away: " + "" + pick ); 
}

doVision(pick) 
{
	self.VisionChange = true;
        switch (pick){ 
                case "Thermal":   
			self VisionSetNakedForPlayer( "thermal_mp", 0.5 );
                        break; 
                case "Chaplin Night": 
       			self VisionSetNakedForPlayer( "cheat_chaplinnight", 2 );
                        break; 
                case "Near Death": 
        		self VisionSetNakedForPlayer( "near_death_mp", 2 );
                        break; 
                case "Cobra Sunset": 
        		self VisionSetNakedForPlayer( "cobra_sunset3", 2 );
                        break; 
                case "Cliffhanger": 
        		self VisionSetNakedForPlayer( "cliffhanger_heavy", 2 );
                        break; 
                case "Water": 
        		self VisionSetNakedForPlayer( "armada_water", 2 );
                        break; 
                case "Trippy": 
        		self VisionSetNakedForPlayer( "blackout_nvg", 2 );
                        break; 
                case "Nuke": 
        		self VisionSetNakedForPlayer( "mpnuke_aftermath", 2 );
                        break; 
                case "Sunrise": 
        		self VisionSetNakedForPlayer( "icbm_sunrise4", 2 );
                        break; 
                case "Gears of War": 
			self VisionSetNakedForPlayer("cobrapilot");
                        break; 
                case "Pink Vision": 
			self VisionSetNakedForPlayer("ac130_inverted", 9000);
                        break; 
                case "Missile": 
        		self VisionSetNakedForPlayer( "missilecam", 2 );
                        break; 
                case "Default": 
        		self VisionSetNakedForPlayer( "default", 2 );
                        break; 
        } 
        self iPrintln( "^3Vision Set to: " + "^2" + pick ); 
}
doModel(pick) 
{ 
        switch (pick){ 
                case "Normal":   
                        self setModel( "tag_origin" );
                        break; 
                case "Stealth Bomber": 
                        self setModel( "vehicle_b2_bomber" );
                        break; 
                case "Harrier": 
                        self setModel( "vehicle_av8b_harrier_jet_opfor_mp" );
                        break; 
                case "Sentry": 
                        self setModel( "sentry_minigun" );
                        break; 
                case "Care Package": 
                        self setModel( "com_plasticcase_friendly" );
                        break; 
                case "UAV": 
                        self setModel( "vehicle_uav_static_mp" );
                        break; 
                case "Airstrike": 
                        self setModel( "vehicle_mig29_desert" );
                        break; 
                case "Turret": 
                        self setModel( "weapon_minigun" );
                        break; 
                case "AC130": 
                        self setModel( "vehicle_ac130_low_mp" );
                        break; 
        } 
        self iPrintln( "^3Model Set to: " + "^2" + pick ); 
}
