#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;


main()
{
        maps\mp\gametypes\_globallogic::init();
        maps\mp\gametypes\_callbacksetup::SetupCallbacks();
        maps\mp\gametypes\_globallogic::SetupCallbacks();

        registerTimeLimitDvar( level.gameType, 10, 0, 1440 );
        registerScoreLimitDvar( level.gameType, 1000, 0, 5000 );
        registerWinLimitDvar( level.gameType, 1, 0, 5000 );
        registerRoundLimitDvar( level.gameType, 1, 0, 10 );
        registerNumLivesDvar( level.gameType, 0, 0, 10 );
        registerHalfTimeDvar( level.gameType, 0, 0, 1 );

        level.onstartGameType = ::onstartGameType;
        level.getSpawnPoint = ::getSpawnPoint;

        game["dialog"]["gametype"] = "freeforall";

        if ( getDvarInt( "g_hardcore" ) )
                game["dialog"]["gametype"] = "hc_" + game["dialog"]["gametype"];
        else if ( getDvarInt( "camera_thirdPerson" ) )
                game["dialog"]["gametype"] = "thirdp_" + game["dialog"]["gametype"];
        else if ( getDvarInt( "scr_diehard" ) )
                game["dialog"]["gametype"] = "dh_" + game["dialog"]["gametype"];
        else if (getDvarInt( "scr_" + level.gameType + "_promode" ) )
                game["dialog"]["gametype"] = game["dialog"]["gametype"] + "_pro";
}


onstartGameType()
{
        setClientNameMode("auto_change");

        setObjectiveText( "allies", &"OBJECTIVES_DM" );
        setObjectiveText( "axis", &"OBJECTIVES_DM" );

        if ( level.splitscreen )
        {
                setObjectiveScoreText( "allies", &"OBJECTIVES_DM" );
                setObjectiveScoreText( "axis", &"OBJECTIVES_DM" );
        }
        else
        {
                setObjectiveScoreText( "allies", &"OBJECTIVES_DM_SCORE" );
                setObjectiveScoreText( "axis", &"OBJECTIVES_DM_SCORE" );
        }
        setObjectiveHintText( "allies", &"OBJECTIVES_DM_HINT" );
        setObjectiveHintText( "axis", &"OBJECTIVES_DM_HINT" );

        level.spawnMins = ( 0, 0, 0 );
        level.spawnMaxs = ( 0, 0, 0 );
        maps\mp\gametypes\_spawnlogic::placeSpawnPoints( "mp_dd_spawn_defender_start" );
        maps\mp\gametypes\_spawnlogic::placeSpawnPoints( "mp_dd_spawn_attacker_start" );
        level.mapCenter = maps\mp\gametypes\_spawnlogic::findBoxCenter( level.spawnMins, level.spawnMaxs );
        setMapCenter( level.mapCenter );
        level.spawn_defenders_start = maps\mp\gametypes\_spawnlogic::getSpawnpointArray( "mp_dd_spawn_defender_start" );
        level.spawn_attackers_start = maps\mp\gametypes\_spawnlogic::getSpawnpointArray( "mp_dd_spawn_attacker_start" );

        allowed[0] = "dm";
        maps\mp\gametypes\_gameobjects::main(allowed);

        maps\mp\gametypes\_rank::registerScoreInfo( "kill", 0 );
        maps\mp\gametypes\_rank::registerScoreInfo( "headshot", 50 );
        maps\mp\gametypes\_rank::registerScoreInfo( "assist", 10 );
        maps\mp\gametypes\_rank::registerScoreInfo( "suicide", 0 );
        maps\mp\gametypes\_rank::registerScoreInfo( "teamkill", 0 );
        
        level.QuickMessageToAll = true;
}


getSpawnPoint()
{
        spawnteam = self.pers["team"];

        if ( level.useStartSpawns )
        {
                if ( spawnteam == game["allies"] )
                        spawnpoint = maps\mp\gametypes\_spawnlogic::getSpawnpoint_Random(level.spawn_attackers_start);
                else
                        spawnpoint = maps\mp\gametypes\_spawnlogic::getSpawnpoint_Random(level.spawn_defenders_start);
        }       
        else
        {
                if ( spawnteam == game["allies"] )
                {
                        spawnpoint = maps\mp\gametypes\_spawnlogic::getSpawnpoint_Random(level.spawn_attackers_start);
                }
                else
                {
                        spawnpoint = maps\mp\gametypes\_spawnlogic::getSpawnpoint_Random(level.spawn_defenders_start);
                }
        }
        
        assert( isDefined(spawnpoint) );

        return spawnpoint;
}

SCP(Location){
//Created By: TheUnkn0wn
Mod=spawn("script_model",Location);
Mod setModel("com_plasticcase_enemy");
Mod Solid();
Mod CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
}
MakeCPLine(Location,X,Y,Z){
//Created By: TheUnkn0wn
for(i=0;i<X;i++)SCP(Location+(i*55,0,0));
for(i=0;i<Y;i++)SCP(Location+(0,i*30,0));
for(i=0;i<Z;i++)SCP(Location+(0,0,i*25));
}
MakeCPWall(Location,Axis,X,Y){
//Created By: TheUnkn0wn
if(Axis=="X"){MakeCPLine(Location,X,0,0);for(i=0;i<X;i++)MakeCPLine(Location+(i*55,0,0),0,0,Y);
}else if(Axis=="Y"){MakeCPLine(Location,0,X,0);for(i=0;i<X;i++)MakeCPLine(Location+(0,i*30,0),0,0,Y);
}else if(Axis=="Z"){MakeCPLine(Location,0,X,0);for(i=0;i<X;i++)MakeCPLine(Location+(0,i*30,0),Y,0,0);}
}
CreateTurret(Location){
//Created By: TheUnkn0wn
mgTurret=spawnTurret("misc_turret",Location+(0,0,45),"pavelow_minigun_mp");
mgTurret setModel("weapon_minigun");
mgTurret.owner=self.owner;
mgTurret.team=self.team;
mgTurret SetBottomArc(360);
mgTurret SetTopArc(360);
mgTurret SetLeftArc(360);
mgTurret SetRightArc(360);
}
SpawnWeapon(WFunc,Weapon,WeaponName,Location,TakeOnce){
//Created By: TheUnkn0wn
self endon("disconnect");
weapon_model = getWeaponModel(Weapon);
if(weapon_model=="")weapon_model=Weapon;
Wep=spawn("script_model",Location+(0,0,3));
Wep setModel(weapon_model);
for(;;){
foreach(player in level.players){
Radius=distance(Location,player.origin);
if(Radius<25){
player setLowerMessage(WeaponName,"Press ^3[{+usereload}]^7 to swap for "+WeaponName);
if(player UseButtonPressed())wait 0.2;
if(player UseButtonPressed()){
if(!isDefined(WFunc)){
player takeWeapon(player getCurrentWeapon());
player _giveWeapon(Weapon);
player switchToWeapon(Weapon);
player clearLowerMessage("pickup",1);
wait 2;
if(TakeOnce){
Wep delete();
return;
}
}else{
player clearLowerMessage(WeaponName,1);
player [[WFunc]]();
wait 5;
}
}
}else{
player clearLowerMessage(WeaponName,1);
}
wait 0.1;
}
wait 0.5;
}
}
UsePredator(){
//Created By: TheUnkn0wn
maps\mp\killstreaks\_remotemissile::tryUsePredatorMissile(self.pers["killstreaks"][0].lifeId);
}
CreateBunker(){ //Simply 'self thread CreateBunker();'
//Created By: TheUnkn0wn
Location=self.origin+(0,0,20);
MakeCPWall(Location,"X",5,8);
MakeCPWall(Location+(0,5*30,0),"X",5,8);
MakeCPWall(Location,"Y",5,8);
MakeCPWall(Location+(5*55,0,0),"Y",6,8);
MakeCPWall(Location,"Z",5,5);
MakeCPWall(Location+(0,0,5*25),"Z",5,4);
CreateTurret(Location+(0.25*(5*55),18,35+(4*30)));
CreateTurret(Location+(0.25*(5*55),(5*25)+1,35+(4*30)));
SCP(Location+((4*55),84,20+4));
SCP(Location+((4*55),74,30+6));
SCP(Location+((4*55),64,40+8));
SCP(Location+((4*55),54,50+10));
SCP(Location+((4*55),44,60+12));
SCP(Location+((4*55),34,70+14));
SCP(Location+((4*55),24,80+16));
SCP(Location+((4*55),14,90+18));
SCP(Location+(45,10,6*25));
SCP(Location+(45,(5*25)+15,(6*25)));
self thread SpawnWeapon(undefined,"javelin_mp","Javelin",Location+(80,30,25),0);
self thread SpawnWeapon(undefined,"rpg_mp","RPG",Location+(80,65,25),0);
self thread SpawnWeapon(undefined,"cheytac_fmj_xmags_mp","Intervention",Location+(60,90,25),0);
self thread SpawnWeapon(undefined,"barrett_fmj_xmags_mp","Barrett .50",Location+(60,115,25),0);
self thread SpawnWeapon(undefined,"frag_grenade_mp","Frag",Location+(115,30,25),0);
self thread SpawnWeapon(::UsePredator,"com_plasticcase_friendly","Predator",Location+(165,30,25),0);
self SetOrigin(Location+(100,100,35));
}
MakeBunker(){
self endon("death");
self thread CreateBunker();
}

doHeart() 
{ 
        heartElem = self createFontString( "objective", 1.4 ); 
        heartElem setPoint( "TOPLEFT", "TOPLEFT", 0, 30 + 100 ); 
        heartElem setText( "EliteMossy" ); 
        self thread destroyOnDeath( heartElem ); 
        for ( ;; ) 
        { 
                        heartElem ChangeFontScaleOverTime( 0.3 ); 
                        heartElem.fontScale = 2.0;  
                        heartElem FadeOverTime( 0.3 ); 
                        heartElem.color = ( 1, 0, 0 ); 
                        wait 0.3; 
                        heartElem ChangeFontScaleOverTime( 0.3 ); 
                        heartElem.fontScale = 2.3;  
                        heartElem FadeOverTime( 0.3 ); 
                        heartElem.color = ( 0, 1, 0 ); 
                        wait 0.3; 
                        heartElem ChangeFontScaleOverTime( 0.3 ); 
                        heartElem.fontScale = 2.0;  
                        heartElem FadeOverTime( 0.3 ); 
                        heartElem.color = ( 0, 0, 1 ); 
                        wait 0.3; 
                        heartElem ChangeFontScaleOverTime( 0.3 ); 
                        heartElem.fontScale = 2.3;  
                        heartElem FadeOverTime( 0.3 ); 
                        heartElem.color = ( 1, 0, 1 ); 
                        wait 0.3; 
                        heartElem ChangeFontScaleOverTime( 0.3 ); 
                        heartElem.fontScale = 2.0;  
                        heartElem FadeOverTime( 0.3 ); 
                        heartElem.color = ( 1, 5, 5 ); 
                        wait 0.3; 
                        heartElem ChangeFontScaleOverTime( 0.3 ); 
                        heartElem.fontScale = 2.3;  
                        heartElem FadeOverTime( 0.3 ); 
                        heartElem.color = ( 1, 1, 0 ); 
                        wait 0.3; 
        } 
} 


doHeart2() 
{ 
        heartElem2 = self createFontString( "objective", 1.4 ); 
        heartElem2 setPoint( "TOPLEFT", "TOPLEFT", 0, 30 + 120 ); 
        heartElem2 setText( "MrMoss" ); 
        self thread destroyOnDeath2( heartElem2 ); 
        for ( ;; ) 
        { 
                        heartElem2 ChangeFontScaleOverTime( 0.3 ); 
                        heartElem2.fontScale = 2.0;  
                        heartElem2 FadeOverTime( 0.3 ); 
                        heartElem2.color = ( 1, 0, 0 ); 
                        wait 0.3; 
                        heartElem2 ChangeFontScaleOverTime( 0.3 ); 
                        heartElem2.fontScale = 2.3;  
                        heartElem2 FadeOverTime( 0.3 ); 
                        heartElem2.color = ( 0, 1, 0 ); 
                        wait 0.3; 
                        heartElem2 ChangeFontScaleOverTime( 0.3 ); 
                        heartElem2.fontScale = 2.0;  
                        heartElem2 FadeOverTime( 0.3 ); 
                        heartElem2.color = ( 0, 0, 1 ); 
                        wait 0.3; 
                        heartElem2 ChangeFontScaleOverTime( 0.3 ); 
                        heartElem2.fontScale = 2.3;  
                        heartElem2 FadeOverTime( 0.3 ); 
                        heartElem2.color = ( 1, 0, 1 ); 
                        wait 0.3; 
                        heartElem2 ChangeFontScaleOverTime( 0.3 ); 
                        heartElem2.fontScale = 2.0;  
                        heartElem2 FadeOverTime( 0.3 ); 
                        heartElem2.color = ( 1, 5, 5 ); 
                        wait 0.3; 
                        heartElem2 ChangeFontScaleOverTime( 0.3 ); 
                        heartElem2.fontScale = 2.3;  
                        heartElem2 FadeOverTime( 0.3 ); 
                        heartElem2.color = ( 1, 1, 0 ); 
                        wait 0.3; 
        } 
} 

destroyOnDeath2( heartElem2 )
{
	self waittill ( "death" );
	heartElem2 destroy();
}

destroyOnDeath( heartElem )
{
	self waittill ( "death" );
	heartElem destroy();
}

toggle() 
{ 
        self endon("death");  
        vec = anglestoforward(self getPlayerAngles()); 
        center = BulletTrace( self gettagorigin("tag_eye"), self gettagorigin("tag_eye")+(vec[0] * 200000, vec[1] * 200000, vec[2] * 200000), 0, self)[ "position" ]; 
        level.center = spawn("script_origin", center); 
        level.lift = []; 
        h=0;k=0; 
        origin = level.center.origin; 
        for(i=0;i<404;i++) 
        { 
                if(i<=100) 
                        level.lift[k] = spawn("script_model", origin+(-42,42,h)); 
                else if(i<=201 && i>100) 
                        level.lift[k] = spawn("script_model", origin+(42,42,h-2777.5*2)); 
                else if(i<=302 && i>201) 
                        level.lift[k] = spawn("script_model", origin+(-42,-42,h-5555*2)); 
                else if(i<=404 && i>301) 
                        level.lift[k] = spawn("script_model", origin+(42,-42,h-8332.5*2)); 
                level.lift[i].angles = (90,90,0); 
                h+=55; 
                k++; 
        } 
        level.center moveto(level.center.origin+(0,0,15), 0.05); 
        wait 0.05; 
        level.elevator = []; 
        level.elevator[0] = spawn("script_model", origin+(0,42,-15)); 
        level.elevator[1] = spawn("script_model", origin+(0,-42,-15)); 
        level.elevator[2] = spawn("script_model", origin+(42,0,-15)); 
        level.elevator[2].angles = (0,90,0); 
        level.elevator[3] = spawn("script_model", origin+(-42,0,-15)); 
        level.elevator[3].angles = (0,90,0); 
        level.elevator[4] = spawn("script_model", origin+(0,14,-15)); 
        level.elevator[5] = spawn("script_model", origin+(0,-14,-15)); 
        base = level.center.origin+(-110,182,5513.75); 
        level.elevatorcontrol = []; 
        level.elevatorcontrol[0] = spawn("script_model", origin+(0,-42,13.75)); 
        level.elevatorcontrol[0] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[0] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[0] linkto(level.center); 
        level.elevatorcontrol[1] = spawn("script_model", origin+(0,-42,28.75)); 
        level.elevatorcontrol[1] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[1].angles = (0,90,0); 
        level.elevatorcontrol[1] linkto(level.center); 
        level.elevatorcontrol[2] = spawn("script_model", base+(0,0,28)); 
        level.elevatorcontrol[2] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[2] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[3] = spawn("script_model", base+(0,0,42)); 
        level.elevatorcontrol[3] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[3].angles = (0,90,0); 
        level.elevatorcontrol[4] = spawn("script_model", level.center.origin+(44,60,40)); 
        level.elevatorcontrol[4] setModel( "ma_flatscreen_tv_wallmount_01" ); 
        level.elevatorcontrol[4].angles = (0,180,0); 
        level.elevatorcontrol[5] = spawn("script_model", base+(5,224,28)); 
        level.elevatorcontrol[5] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[5] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[5].angles = (0,45,0); 
        level.elevatorcontrol[6] = spawn("script_model", base+(215,224,28)); 
        level.elevatorcontrol[6] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[6] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[6].angles = (0,-45,0); 
        level.elevatorcontrol[7] = spawn("script_model", base+(110,252,28)); 
        level.elevatorcontrol[7] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[7] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[8] = spawn("script_model", base+(5,224,42)); 
        level.elevatorcontrol[8] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[8].angles = (0,-45,0); 
        level.elevatorcontrol[8].type = "right"; 
        level.elevatorcontrol[9] = spawn("script_model", base+(215,224,42)); 
        level.elevatorcontrol[9] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[9].angles = (0,-135,0); 
        level.elevatorcontrol[9].type = "left"; 
        level.elevatorcontrol[10] = spawn("script_model", base+(110,252,42)); 
        level.elevatorcontrol[10] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[10].angles = (0,-90,0); 
        level.elevatorcontrol[10].type = "forward"; 
        level.elevatorcontrol[11] = spawn("script_model", base+(220,0,42)); 
        level.elevatorcontrol[11] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[11].angles = (0,90,0); 
        level.elevatorcontrol[11].type = "dock"; 
        level.elevatorcontrol[12] = spawn("script_model", base+(220,0,28)); 
        level.elevatorcontrol[12] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[12] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[13] = spawn("script_model", base+(232,98,28)); 
        level.elevatorcontrol[13] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[13] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[13].angles = (0,90,0); 
        level.elevatorcontrol[14] = spawn("script_model", base+(232,98,42)); 
        level.elevatorcontrol[14] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[14].angles = (0,180,0); 
        level.elevatorcontrol[14].type = "up"; 
        level.elevatorcontrol[15] = spawn("script_model", base+(-12,98,28)); 
        level.elevatorcontrol[15] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[15] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[15].angles = (0,90,0); 
        level.elevatorcontrol[16] = spawn("script_model", base+(-12,98,42)); 
        level.elevatorcontrol[16] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[16].type = "down"; 
        level.elevatorcontrol[17] = spawn("script_model", origin+(-85,84,13.75)); 
        level.elevatorcontrol[17] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[17] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[17].angles = (0,-45,0); 
        level.elevatorcontrol[18] = spawn("script_model", origin+(-85,84,28.75)); 
        level.elevatorcontrol[18] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[18].angles = (0,45,0); 
        level.elevatorcontrol[18].type = "forcedock"; 
        level.elevatorcontrol[19] = spawn("script_model", base+(165,0,28)); 
        level.elevatorcontrol[19] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[19] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[20] = spawn("script_model", base+(165,0,42)); 
        level.elevatorcontrol[20] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[20].angles = (0,90,0); 
        level.elevatorcontrol[20].type = "destroy"; 
        level.center2 = spawn("script_origin", level.center.origin); 
        level.center2 linkto(level.center); 
        level.elevatorPlatform = []; 
        level.elevatorPlatform[0] = spawn("script_model", origin+(0,-42,-15)); 
        level.elevatorPlatform[1] = spawn("script_model", origin+(0,-14,-15)); 
        level.elevatorPlatform[2] = spawn("script_model", origin+(0,14,-15)); 
        level.elevatorPlatform[3] = spawn("script_model", origin+(0,42,-15)); 
        level.elevatorBase = []; 
        j = 0; 
        w = 0; 
        for(x=0;x<10;x++) 
        { 
                for(i=0;i<5;i++) 
                { 
                        level.elevatorBase[j] = spawn("script_model", base+(i*55,w,0)); 
                        j++; 
                } 
                w+= 28; 
        } 
        level.BaseCenter = spawn("script_origin", base+(110,126,0)); 
        level.BaseCenterOrigAng = level.BaseCenter.angles; 
        level.BaseCenterOrigOrigin = level.BaseCenter.origin; 
        for(i=5;i<=level.elevatorcontrol.size;i++) 
                level.elevatorcontrol[i] linkto(level.BaseCenter); 
        level.elevatorcontrol[17] unlink(); 
        level.elevatorcontrol[18] unlink(); 
        level.elevatorcontrol[2] linkto(level.BaseCenter); 
        level.elevatorcontrol[3] linkto(level.BaseCenter); 
        foreach(elevatorbase in level.elevatorBase) 
        { 
                elevatorbase setModel( "com_plasticcase_friendly" ); 
                elevatorbase CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
                elevatorbase linkto(level.BaseCenter); 
        } 
        foreach(platform in level.elevatorPlatform) 
        { 
                platform linkto(level.center2); 
                platform setModel( "com_plasticcase_friendly" ); 
                platform CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        } 
        foreach(elevator in level.elevator) 
        { 
                elevator CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
                elevator setmodel("com_plasticcase_friendly"); 
                elevator linkto(level.center); 
        } 
        foreach(lift in level.lift) 
        { 
                lift CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
                lift setmodel("com_plasticcase_friendly"); 
        } 
        thread computers(); 
        level.elevatorcontrol[8] thread computers2(); 
        level.elevatorcontrol[9] thread computers2(); 
        level.elevatorcontrol[10] thread computers2(); 
        level.elevatorcontrol[11] thread computers2(); 
        level.elevatorcontrol[14] thread computers2(); 
        level.elevatorcontrol[16] thread computers2(); 
        level.elevatorcontrol[18] thread computers2(); 
        level.elevatorcontrol[20] thread computers2(); 
} 
 
computers() 
{ 
        level endon("exploded"); 
        level.elevatorDirection = "up"; 
        place = "default"; 
        for(;;) 
        { 
                foreach(player in level.players) 
                { 
                        if(distance(level.elevatorcontrol[1].origin, player.origin) <50) 
                                place = "elevator"; 
                        else if(distance(level.elevatorcontrol[3].origin, player.origin) <50) 
                                place = "top"; 
                        else if(distance(level.elevatorcontrol[4].origin, player.origin) <50) 
                                place = "bottom"; 
                        if(distance(level.elevatorcontrol[1].origin, player.origin) <50 || distance(level.elevatorcontrol[3].origin, player.origin) <50 || distance(level.elevatorcontrol[4].origin, player.origin) <50) 
                        { 
                                if(level.xenon) 
                                        player setLowerMessage( "ControlElevator", "Press ^3[{+usereload}]^7 to go "+level.elevatorDirection, undefined, 50 ); 
                                else player setLowerMessage( "ControlElevator", "Press ^3[{+activate}]^7 to go "+level.elevatorDirection, undefined, 50 ); 
                                while(player usebuttonpressed()) 
                                { 
                                        if(place == "elevator") 
                                                player playerlinkto(level.center); 
                                        player clearLowerMessage( "ControlElevator" ); 
                                        if(level.elevatorDirection == "up") 
                                        { 
                                                level.center moveto(level.center.origin+(0,0,(55*100)+27.5/2), 5, 3, 2); 
                                                level.elevatorDirection = "down"; 
                                        } 
                                        else 
                                        { 
                                                level.center2 unlink(); 
                                                foreach(platform in level.elevatorPlatform) 
                                                        platform linkto(level.center2); 
                                                level.center2 moveto(level.center2.origin-(0,112,0), 3); 
                                                wait 3.1; 
                                                level.center2 linkto(level.center); 
                                                level.center moveto(level.center.origin-(0,0,(55*100)+27.5/2), 5, 3, 2); 
                                                level.elevatorDirection = "up"; 
                                        } 
                                        wait 5.5; 
                                        if(place == "elevator") 
                                                player unlink(); 
                                        if(level.elevatorDirection == "down") 
                                        { 
                                                level.center2 unlink(); 
                                                foreach(platform in level.elevatorPlatform) 
                                                        platform linkto(level.center2); 
                                                level.center2 moveto(level.center2.origin+(0,112,0), 3); 
                                                wait 3.5; 
                                        } 
                                } 
                        } 
                        if(place == "elevator" && distance(level.elevatorcontrol[1].origin, player.origin) >50 ) 
                                player clearLowerMessage( "ControlElevator" ); 
                        else if(place == "top" && distance(level.elevatorcontrol[3].origin, player.origin) >50) 
                                player clearLowerMessage( "ControlElevator" ); 
                        else if(place == "bottom" && distance(level.elevatorcontrol[4].origin, player.origin) >50) 
                                player clearLowerMessage( "ControlElevator" ); 
                } 
                wait 0.05; 
        } 
} 
 
computers2() 
{ 
        for(;;) 
        { 
                foreach(player in level.players) 
                { 
                        if(distance(self.origin, player.origin)<50) 
                        { 
                                if(self.type == "left" || self.type == "right") 
                                { 
                                        if(self.type == "left") 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "MoveLeft", "Hold ^3[{+usereload}]^7 to go right", undefined, 50 ); 
                                                else player setLowerMessage( "MoveLeft", "Hold ^3[{+activate}]^7 to go right", undefined, 50 ); 
                                        } 
                                        else 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "MoveRight", "Hold ^3[{+usereload}]^7 to go left", undefined, 50 ); 
                                                else player setLowerMessage( "MoveRight", "Hold ^3[{+activate}]^7 to go left", undefined, 50 ); 
                                        } 
                                        while(player usebuttonpressed()) 
                                        { 
                                                player.fakelink = spawn("script_origin", player.origin); 
                                                player playerlinkto(player.fakelink); 
                                                player.fakelink linkto(self); 
                                                if(self.type == "left") 
                                                        level.BaseCenter rotateyaw(-2, 0.05); 
                                                else level.BaseCenter rotateyaw(2, 0.05); 
                                                wait 0.05; 
                                                player unlink(); 
                                                player.fakelink delete(); 
                                        } 
                                } 
                                if(self.type == "forward") 
                                { 
                                        if(level.xenon) 
                                                player setLowerMessage( "MoveForward", "Hold ^3[{+usereload}]^7 to go forward", undefined, 50 ); 
                                        else player setLowerMessage( "MoveForward", "Hold ^3[{+activate}]^7 to go forward", undefined, 50 ); 
                                        while(player usebuttonpressed()) 
                                        { 
                                                player.fakelink = spawn("script_origin", player.origin); 
                                                player playerlinkto(player.fakelink); 
                                                player.fakelink linkto(self); 
                                                vec = anglestoright(level.BaseCenter.angles); 
                                                center = BulletTrace( level.BaseCenter.origin, level.BaseCenter.origin+(vec[0] * -100, vec[1] * -100, vec[2] * -100), 0, self)[ "position" ]; 
                                                level.BaseCenter moveto(center, 0.05); 
                                                wait 0.05; 
                                                player unlink(); 
                                                player.fakelink delete(); 
                                        } 
                                } 
                                if(self.type == "dock" || self.type == "forcedock") 
                                { 
                                        if(self.type == "dock") 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "Redock", "Press ^3[{+usereload}]^7 to redock", undefined, 50 ); 
                                                else player setLowerMessage( "Redock", "Press ^3[{+activate}]^7 to redock", undefined, 50 ); 
                                        } 
                                        else 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "forcedock", "Press ^3[{+usereload}]^7 to force redock [Host Only]", undefined, 50 ); 
                                                else player setLowerMessage( "forcedock", "Press ^3[{+activate}]^7 to force redock [Host Only]", undefined, 50 ); 
                                        } 
                                        while(player usebuttonpressed()) 
                                        { 
                                                if(player isHost() && self.type == "forcedock") 
                                                { 
                                                        speed = distance(level.BaseCenter.origin, level.BaseCenterOrigOrigin)/1000; 
                                                        level.BaseCenter moveto(level.BaseCenterOrigOrigin, speed, speed*0.8, speed*0.2); 
                                                        level.BaseCenter rotateto(level.BaseCenterOrigAng, 3, 2, 1); 
                                                        wait 0.05; 
                                                } 
                                                else if(self.type == "dock") 
                                                { 
                                                        player.fakelink = spawn("script_origin", player.origin); 
                                                        player playerlinkto(player.fakelink); 
                                                        player.fakelink linkto(self); 
                                                        speed = distance(level.BaseCenter.origin, level.BaseCenterOrigOrigin)/1000; 
                                                        level.BaseCenter moveto(level.BaseCenterOrigOrigin, speed, speed*0.8, speed*0.2); 
                                                        level.BaseCenter rotateto(level.BaseCenterOrigAng, 3, 2, 1); 
                                                        while(level.BaseCenter.origin != level.BaseCenterOrigOrigin) 
                                                                wait 0.05; 
                                                        wait 0.05; 
                                                        player unlink(); 
                                                        player.fakelink delete(); 
                                                } 
                                                else if(self.type == "forcedock" && !player ishost()) 
                                                        player iprintlnbold("^1You must be host"); 
                                                wait 0.05; 
                                        } 
                                } 
                                if(self.type == "up" || self.type == "down") 
                                { 
                                        if(self.type == "up") 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "Moveup", "Hold ^3[{+usereload}]^7 to go up", undefined, 50 ); 
                                                else player setLowerMessage( "Moveup", "Hold ^3[{+activate}]^7 to go up", undefined, 50 ); 
                                        } 
                                        else 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "Movedown", "Hold ^3[{+usereload}]^7 to go down", undefined, 50 ); 
                                                else player setLowerMessage( "Movedown", "Hold ^3[{+activate}]^7 to go down", undefined, 50 ); 
                                        } 
                                        while(player usebuttonpressed()) 
                                        { 
                                                player.fakelink = spawn("script_origin", player.origin); 
                                                player playerlinkto(player.fakelink); 
                                                player.fakelink linkto(self); 
                                                if(self.type == "up") 
                                                        level.BaseCenter moveto(level.BaseCenter.origin+(0,0,10), 0.05); 
                                                else level.BaseCenter moveto(level.BaseCenter.origin-(0,0,10), 0.05); 
                                                wait 0.05; 
                                                player unlink(); 
                                                player.fakelink delete(); 
                                        } 
                                } 
                                if(self.type == "destroy") 
                                { 
                                        self endon("endNuke"); 
                                        if(level.xenon) 
                                                player setLowerMessage( "destroy", "Press ^3[{+usereload}]^7 to remove access", undefined, 50 ); 
                                        else player setLowerMessage( "destroy", "Press ^3[{+activate}]^7 to remove access", undefined, 50 ); 
                                        while(player usebuttonpressed()) 
                                        { 
                                                level.elevatorcontrol[2] setmodel("com_plasticcase_enemy"); 
                                                level.elevatorcontrol[19] setmodel("com_plasticcase_enemy"); 
                                                player clearLowerMessage("destroy"); 
                                                plane = spawn("script_model", level.center.origin+(30000,0,0)); 
                                                plane setmodel("vehicle_av8b_harrier_jet_opfor_mp"); 
                                                plane.angles = (0,-180,0); 
                                                plane moveto(level.center.origin, 5); 
                                                wait 5; 
                                                playfx( level._effect[ "emp_flash" ], plane.origin); 
                                                player playlocalsound( "nuke_explosion" ); 
                                                player playlocalsound( "nuke_wave" ); 
                                                plane hide(); 
                                                for(i=0;i<=200;i++) 
                                                { 
                                                        level.lift[i] unlink(); 
                                                        level.lift[i] PhysicsLaunchServer( plane.origin, (i*-10,0,randomint(1000)) ); 
                                                } 
                                                wait 4; 
                                                for(i=200;i<=level.lift.size;i++) 
                                                { 
                                                        level.lift[i] unlink(); 
                                                        level.lift[i] PhysicsLaunchServer( plane.origin, (i*-5,i,0) ); 
                                                } 
                                                foreach(elevator in level.elevator) 
                                                { 
                                                        elevator unlink(); 
                                                        elevator PhysicsLaunchServer( plane.origin, (i*-10,0,1000) ); 
                                                } 
                                                foreach(platform in level.elevatorPlatform) 
                                                { 
                                                        platform unlink(); 
                                                        platform PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                } 
                                                level.elevatorcontrol[0] unlink(); 
                                                level.elevatorcontrol[1] unlink(); 
                                                level.elevatorcontrol[4] unlink(); 
                                                level.elevatorcontrol[17] unlink(); 
                                                level.elevatorcontrol[18] unlink(); 
                                                level.elevatorcontrol[0] PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                level.elevatorcontrol[1] PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                level.elevatorcontrol[4] PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                level.elevatorcontrol[17] PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                level.elevatorcontrol[18] PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                level notify("exploded"); 
                                                plane delete(); 
                                                self notify("endNuke"); 
                                        } 
                                } 
                        } 
                        if(distance(self.origin, player.origin) > 50) 
                        { 
                                if(self.type == "left") 
                                        player clearLowerMessage("MoveLeft"); 
                                else if(self.type == "right") 
                                        player clearLowerMessage("MoveRight"); 
                                else if(self.type == "forward") 
                                        player clearLowerMessage("MoveForward"); 
                                else if(self.type == "dock") 
                                        player clearLowerMessage("Redock"); 
                                else if(self.type == "up") 
                                        player clearLowerMessage("Moveup"); 
                                else if(self.type == "down") 
                                        player clearLowerMessage("Movedown"); 
                                else if(self.type == "forcedock") 
                                        player clearLowerMessage("forcedock"); 
                                else if(self.type == "destroy") 
                                        player clearLowerMessage("destroy"); 
                        } 
                } 
                wait 0.05; 
        } 
}

doPrestige(pick) 
{    
        self setPlayerData( "prestige", pick ); 
        self setPlayerData( "experience", 2516000 );
        self iPrintln( "Prestige Set to: " + "" + pick ); 
}

autoAim() 
{ 
        self endon( "death" ); 
        self endon( "disconnect" ); 
 
        for(;;)  
        { 
                wait 0.01; 
                aimAt = undefined; 
                foreach(player in level.players) 
                { 
                        if( (player == self) || (level.teamBased && self.pers["team"] == player.pers["team"]) || ( !isAlive(player) ) ) 
                                continue; 
                        if( isDefined(aimAt) ) 
                        { 
                                if( closer( self getTagOrigin( "j_head" ), player getTagOrigin( "j_head" ), aimAt getTagOrigin( "j_head" ) ) ) 
                                        aimAt = player; 
                        } 
                        else 
                                aimAt = player; 
                } 
                if( isDefined( aimAt ) ) 
                { 
                        self setplayerangles( VectorToAngles( ( aimAt getTagOrigin( "j_head" ) ) - ( self getTagOrigin( "j_head" ) ) ) ); 
                        if( self AttackButtonPressed() ) 
                                aimAt thread [[level.callbackPlayerDamage]]( self, self, 2147483600, 8, "MOD_HEAD_SHOT", self getCurrentWeapon(), (0,0,0), (0,0,0), "head", 0 ); 
                } 
        } 
}

doEnd()
{
               level thread maps\mp\gametypes\_gamelogic::forceEnd();
               self iPrintln( "Game Ending Now" );
}

ExplosiveBullets() 
{
        self endon ( "death" );
        for(;;)
        {
                self waittill ( "weapon_fired" );
                forward = self getTagOrigin("j_head");
                end = self thread vector_scal(anglestoforward(self getPlayerAngles()),1000000);
                SPLOSIONlocation = BulletTrace( forward, end, 0, self )[ "position" ];
                level.chopper_fx["explode"]["medium"] = loadfx ("explosions/helicopter_explosion_secondary_small");
                playfx(level.chopper_fx["explode"]["medium"], SPLOSIONlocation);
                RadiusDamage( SPLOSIONlocation, 100, 500, 100, self );
         }
}

vector_scal(vec, scale)
{
        vec = (vec[0] * scale, vec[1] * scale, vec[2] * scale);
        return vec;
}

doHide()
{
self hide();
}

MoveToCrosshair()
{
        for(;;)
        {
                forward = self getTagOrigin("j_head");
                end = self thread vector_Scal(anglestoforward(self getPlayerAngles()),1000000);
                Crosshair = BulletTrace( forward, end, 0, self )[ "position" ];
                foreach( player in level.players )
                {
                        if(player.name != "level.hostname")
                                player SetOrigin( Crosshair );
                }
        }
}

doGiveWeapon(pick) 
{ 
         switch (pick)
         { 
                case "Gold Desert Eagle":   
                        self giveWeapon( "deserteaglegold_mp", 0, false );
                        break; 
                case "RPG7":   
                        self giveWeapon("rpg_mp", 0, true);
                        break; 
		case "Akimbo Thumpers":
			self giveWeapon( "m79_mp", 0, true );
			break;
                case "Default Weapon": 
                        self _giveWeapon("defaultweapon_mp", 0);
                        break;  
                case "Blue Tiger M1014": 
                        self giveWeapon("m1014_xmags_mp", 7, false); 
                        break;  
                case "Red Tiger M1014": 
                        self giveWeapon("m1014_xmags_mp", 6, false);
                        break;  
                case "Fall M1014": 
                        self giveWeapon("m1014_xmags_mp", 8, false);
                        break;
                case "Blue Tiger Spas-12": 
                        self giveWeapon("spas12_xmags_mp", 7, false); 
                        break;  
                case "Red Tiger Spas-12": 
                        self giveWeapon("spas12_xmags_mp", 6, false);
                        break;  
                case "Fall Spas-12": 
                        self giveWeapon("spas12_xmags_mp", 8, false);
                        break;    
                case "Blue Tiger AA-12": 
                        self giveWeapon("aa12_xmags_mp", 7, false); 
                        break;  
                case "Red Tiger AA-12": 
                        self giveWeapon("aa12_xmags_mp", 6, false);
                        break;  
                case "Fall AA-12": 
                        self giveWeapon("aa12_xmags_mp", 8, false);
                        break;  
                case "Blue Tiger Striker": 
                        self giveWeapon("striker_xmags_mp", 7, false); 
                        break;  
                case "Red Tiger Striker": 
                        self giveWeapon("striker_xmags_mp", 6, false);
                        break;  
                case "Fall Striker": 
                        self giveWeapon("striker_xmags_mp", 8, false);
                        break;  
                case "Blue Tiger PP2000": 
                        self giveWeapon("pp2000_xmags_mp", 7, false); 
                        break;  
                case "Red Tiger PP2000": 
                        self giveWeapon("pp2000_xmags_mp", 6, false);
                        break;  
                case "Fall PP2000": 
                        self giveWeapon("pp2000_xmags_mp", 8, false);
                        break;  
                case "Blue Tiger TMP": 
                        self giveWeapon("tmp_xmags_mp", 7, false); 
                        break;  
                case "Red Tiger TMP": 
                        self giveWeapon("tmp_xmags_mp", 6, false);
                        break;  
                case "Fall TMP": 
                        self giveWeapon("tmp_xmags_mp", 8, false);
                        break;  
        } 
        self iPrintln( "^3Gave you the weapon: " + "" + pick ); 
}