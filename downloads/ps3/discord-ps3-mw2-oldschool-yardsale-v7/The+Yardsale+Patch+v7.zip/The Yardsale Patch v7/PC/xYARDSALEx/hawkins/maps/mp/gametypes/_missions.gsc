#include maps\mp\gametypes\_hud_util;
#include hawkins\maps\mp\_utility;
#include common_scripts\utility;
#include hawkins\maps\mp\qczm\HumansZombiesSetup;
#include hawkins\maps\mp\killstreaks\_ac130;


doGameStarter()
{	self endon("DEMOMODEZ");
	level.gameState = "starting";
	level.lastAlive = 0;
	level.lockz = 1;
	level.teamLimit = 12;
	foreach(player in level.players)
	{	player thread doZombreset();
		player thread doSetup();
		player thread doGodzs();
	}
	level waittill("CREATED");
	level thread doStartTimer();
	wait .1;
	foreach(player in level.players)
	{	player thread doSetup();
		player notify ("DEMOEND");
	}
	wait 30;
	level thread doZombieTimer();
	VisionSetNaked("icbm", 5);
}
doStartTimer()
{	level.TimerText destroy();
	level.TimerText = level createServerFontString( "objective", 1.5 );
	level.TimerText setPoint( "CENTER", "CENTER", 0, -100 );
	level.TimerText setText("^2Get Ready!");
	setDvar("fx_draw", 1);
	setDvar("ui_allow_teamchange", 1);
	wait 30;
	level.TimerText setText("");
	level.teamLimit = 12;
	foreach(player in level.players)
	{
		player thread doSetup();
	}
}

doIntermission()
{	level.gameState = "intermission";
	level notify("GEND");
	level.lastAlive = 0;
	level.teamLimit = 12;
	level thread doIntermissionTimer();
	level notify("RESETDOORS");
	level notify("RESETCLUSTER");
	setDvar("cg_drawCrosshair", 1);
	setDvar("cg_drawCrosshairNames", 1);
	setDvar("cg_drawFriendlyNames", 1);
	wait 5;
	foreach(player in level.players)
	{	
		player thread doZombreset();
		player thread doSetup();
		player thread doGodzs();
		player thread doAnticheatz();
	}
	wait 25;
	level thread doZombieTimer();
	VisionSetNaked("icbm", 5);
}

doIntermissionTimer()
{
	
	level.TimerText destroy();
	level.TimerText = level createServerFontString( "objective", 1.5 );
	level.TimerText setPoint( "CENTER", "CENTER", 0, -100 );
	level.TimerText setText("^2Get Ready");
	wait 30;
	level.TimerText setText("");
	foreach(player in level.players)
	{
		player thread doSetup();
	}
}

doZombieTimer()
{
	setDvar("cg_drawCrosshair", 1);
	setDvar("ui_allow_teamchange", 1);
	level.counter = 28;
	while(level.counter > 0)
	{
		level.TimerText destroy();
		level.TimerText = level createServerFontString( "objective", 1.5 );
		level.TimerText setPoint( "CENTER", "CENTER", 0, -100 );
		level.TimerText setText("^1Zombification in: " + level.counter);
		wait 1;
		level.counter--;
	}
	level.TimerText setText("");
	level thread doPickZombie();
}

doPickZombie()
{	
	if(level.players.size > 12)
	{	foreach(player in level.players)
		{	if( player.team == "axis" || player.team == "spectator" )	{
				kick(player getEntityNumber());
			}
		}
	}
	wait 2;
	level.Zombie1 = randomInt(level.players.size);
	level.Zombie2 = randomInt(level.players.size);
	level.Zombie3 = randomInt(level.players.size);
	level.Alpha = 2;
	if(level.players.size < 5){
		level.Alpha = 1;
	}
	if(level.players.size > 10){
		level.Alpha = 4;
	}
	if(level.testz == 1) level.Alpha = 3;
	if(level.Alpha == 1){
		level.players[level.Zombie1].isZombie = 2;
		level.players[level.Zombie1] thread doAlphaZombie();
	}
	if(level.Alpha == 2){
		while(level.players[level.Zombie1] isHost() || level.players[level.Zombie2] isHost() || level.Zombie1 == level.Zombie2)	{
			level.Zombie1 = randomInt(level.players.size);
			level.Zombie2 = randomInt(level.players.size);
		}
		level.players[level.Zombie1].isZombie = 2;
		level.players[level.Zombie1] thread doAlphaZombie();
		level.players[level.Zombie2].isZombie = 2;
		level.players[level.Zombie2] thread doAlphaZombie();
	}
	if(level.Alpha == 4){
		while(level.players[level.Zombie1] isHost() || level.players[level.Zombie2] isHost() || level.players[level.Zombie3] isHost() || level.Zombie1 == level.Zombie2 || level.Zombie2 == level.Zombie3 || level.Zombie1 == level.Zombie3)
		{	level.Zombie1 = randomInt(level.players.size);
			level.Zombie2 = randomInt(level.players.size);
			level.Zombie3 = randomInt(level.players.size);
		}
		level.players[level.Zombie1].isZombie = 2;
		level.players[level.Zombie1] thread doAlphaZombie();
		level.players[level.Zombie2].isZombie = 2;
		level.players[level.Zombie2] thread doAlphaZombie();
		level.players[level.Zombie3].isZombie = 2;
		level.players[level.Zombie3] thread doAlphaZombie();
	}
	level thread doPregamez();
}
doPregamez()
{
	level playSoundToAll("mp_defeat");
	level.TimerText destroy();
	level.TimerText = level createServerFontString( "objective", 1.5 );
	level.TimerText setPoint( "CENTER", "CENTER", 0, -100 );
	level.timerText setText("^1RUN!");
	level.gameState = "playing";
	level.messzz = 1;
	wait 1;
	foreach(player in level.players)
	{
		if(player.team == "allies"){
			player thread doSetup();
			player thread doMoneyAnn();
			if (player isHost())	player thread doHostgod();
		}
	}
	level thread doPlaying();
	//level.infotext setText("^3INSTRUCTIONS. ^2Press [{togglescores}] to see your CASH Total. ^3To browse the Store Menu Press ^2[{+actionslot 1}] to go Forward a page. ^3Press ^2[{+smoke}] to go Back a page.");
	level thread doPlayingTimer();
	level thread inGameConstants();
	level thread doRoundBreak();
	
}

doPlaying()
{
	wait 5;
	level.messzz = 0;
	while(level.testz == 1)	{
		level.timerText setText("^1Game Testing Mode. Game Not Functional.");
		foreach(player in level.players)
		{	if(player.jpal != 2) 
			{	player thread doJPall();
			}
		}
		wait 5;
		level.timerText setText("");
		wait 30;
	}
	level.infotext destroy();
	level.bar destroy();
	level.TimerText destroy();
	while(1)
	{
		level.playersLeft = maps\mp\gametypes\_teams::CountPlayers();
		if(level.lastAlive == 0){
			if(level.playersLeft["allies"] == 1){
				level.lastAlive = 1;
				foreach(player in level.players){
					if(player.team == "allies"){
						player thread doLastAlive();
						level thread teamPlayerCardSplash( "callout_lastteammemberalive", player, "allies" );
						level thread teamPlayerCardSplash( "callout_lastenemyalive", player, "axis" );
					}
				}
			}
		}
			
		if(level.playersLeft["allies"] == 0 || level.playersLeft["axis"] == 0){
			level thread doEnding();
			return;
		}
		
		wait .5;
	}
}

doPlayingTimer()
{
	level.minutes = 0;
	level.seconds = 0;
	while(1)
	{
		wait 1;
		level.seconds++;
		if(level.seconds == 60){
			level.minutes++;
			level.seconds = 0;
		}
		if(level.gameState == "ending"){
			return;
		}
	}
}

doLastAlive() 
{
	self endon("disconnect");
	self endon("death");
	self iPrintlnBold("^1You're Last Alive. You've Earned $300.");
	self.bounty += 300;
	wait 30;
	self iPrintlnBold("^1ColdBlooded No Longer Works For You.");
	for(;;)
	{
		self _unsetPerk("specialty_coldblooded");
		self _unsetPerk("specialty_spygame");
		self.perkz["coldblooded"] = 3;
		wait .4;
	}
}

doEnding()
{
	level.gameState = "ending";
	level notify("GEND");
	notifyEnding = spawnstruct();
	notifyEnding.titleText = "Game Over!";
	notifyEnding.notifyText2 = "You Played " + level.roundz + " Rounds";
	notifyEnding.glowColor = (0.0, 0.6, 0.3);
	
	if(level.playersLeft["allies"] == 0){
		notifyEnding.notifyText = "Humans Survived: " + level.minutes + " mins. " + level.seconds + " secs.";
	}
	if(level.playersLeft["axis"] == 0){
		notifyEnding.notifyText = "Cowardly Zombies Ran Away Human's Win!!!!";
	}
	wait 1;
	VisionSetNaked("blacktest", 2);
	foreach(player in level.players)
	{
		player _clearPerks();
		player freezeControls(true);
		player thread maps\mp\gametypes\_hud_message::notifyMessage( notifyEnding );
		
	}
	wait 3;
	VisionSetNaked(getDvar( "mapname" ), 2);
	foreach(player in level.players)
	{	
		player freezeControls(false);
	}
	map_restart(false);
	//level thread doIntermission();
}

inGameConstants()
{
	while(1)
	{
		setDvar("cg_drawCrosshair", 0);
		setDvar("cg_drawCrosshairNames", 0);
		setDvar("cg_drawFriendlyNames", 1);
		setDvar("perk_blastShield", "1");
		foreach(player in level.players){
			player VisionSetNakedForPlayer("icbm", 0);
			player setClientDvar("lowAmmoWarningNoAmmoColor2", 0, 0, 0, 0);
			player setClientDvar("lowAmmoWarningNoAmmoColor1", 0, 0, 0, 0);
			player setClientDvar("fx_draw", 1);
			player setClientDvar("perk_blastShield", "1");
		}
		wait 1;
		if(level.gameState == "ending"){
			return;
		}
	}
}

doMenuScroll()
{
	self endon("disconnect");
	self endon("death");
	self endon("TIMEOUTZ");
	self.monz = 1;
	self.contzr = 0;
	self thread doMtime();
	while(1)
	{
		if(self.buttonPressed[ "+smoke" ] == 1){
			self.buttonPressed[ "+smoke" ] = 0;
			self.contzr++;
			if(self.monz == 0)
			{	self.monz = 1;
				self thread CreatePlayerHUD();
				self thread doMtime();
			}	else	{
				self.menu--;
				if(self.menu < 0){
					if(self.team == "allies"){
						self.menu = level.humanM.size-1;
					} else {
						self.menu = level.zombieM.size-1;
					}
				}
			}
		}
		if(self.buttonPressed[ "+frag" ] == 1){
			self.buttonPressed[ "+frag" ] = 0;
			self.throwingknife = 0;
			if (self isHost()) {
				self thread funcAntiJoin();
			}
		}
		if(self.buttonPressed[ "togglescores" ] == 1){
			self.buttonPressed[ "togglescores" ] = 0;
			self.hcash++;
		}
		if(self.buttonPressed[ "+actionslot 1" ] == 1){
			self.buttonPressed[ "+actionslot 1" ] = 0;
			self.contzr++;
			if(self.monz == 0)
			{	self.monz = 1;
				self thread CreatePlayerHUD();
				self thread doMtime();
			}	else	{
				self.menu++;
				if(self.team == "allies"){
					if(self.menu >= level.humanM.size){
						self.menu = 0;
					}
				} else {
					if(self.menu >= level.zombieM.size){
						self.menu = 0;
					}
				}
			}
		}
		wait .045;
	}
}

doMtime()
{	self endon("disconnect");
	self endon("death");
	self.contzr = 8;
	while(self.contzr > 0)
	{	self.contzr--;
		wait 1;
	}
	self.option0 destroy();
	self.option1 destroy();
	self.option2 destroy();
	self.option3 destroy();
	self.monz = 0;
}
doDvars()
{	setDvar("painVisionTriggerHealth", 0);
	setDvar("player_sprintUnlimited", 1);
	setDvar( "g_teamcolor_axis", "1 0.0 00.0" );
	setDvar( "g_teamcolor_allies", "0 0.0 00.0" );
}

doHealth()
{
	self endon("disconnect");
	self endon("death");
	self.curhealth = 0;
	self.hcash = 1;
	while(1)
	{	
		if(self.hcash > 0)
		{	self.healthtext destroy();
			wait .2;
			self.healthtext = NewClientHudElem( self );
			self.healthtext.alignX = "right";
			self.healthtext.alignY = "top";
			self.healthtext.horzAlign = "right";
			self.healthtext.vertAlign = "top";
			self.healthtext.y = -25;
			self.healthtext.foreground = true;
			self.healthtext.fontScale = 1;
			self.healthtext.font = "hudbig";
			self.healthtext.alpha = 1;
			self.healthtext.glow = 1;
			self.healthtext.glowColor = ( 2.55, 0, 0 );
			self.healthtext.glowAlpha = 1;
			self.healthtext.color = ( 1.0, 1.0, 1.0 );
			self.healthtext setText("Health: " + self.maxhealth);
			wait 5;
			self.healthtext destroy();
			self.hcash = 0;
		}
		wait 1;
	}
}

doCash()
{
	self endon("disconnect");
	self endon("death");
	self.hcash = 1;
	while(1)
	{	if(self.hcash > 0)
		{	self.cash destroy();
			wait .1;
			self.cash = NewClientHudElem( self );
			self.cash.alignX = "right";
			self.cash.alignY = "top";
			self.cash.horzAlign = "right";
			self.cash.vertAlign = "top";
			self.cash.foreground = true;
			self.cash.fontScale = 1;
			self.cash.font = "hudbig";
			self.cash.alpha = 1;
			self.cash.glow = 1;
			self.cash.glowColor = ( 0, 1, 0 );
			self.cash.glowAlpha = 1;
			self.cash.color = ( 1.0, 1.0, 1.0 );
			self.cash setText("$ " + self.bounty);
			wait 5;
			self.cash destroy();
			self.hcash = 0;
		}
		wait 1;
	}
}

doHUDControl()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		self.HintText setText(self.hint);
		self.hint = "";
		self.menuz = self.menu +1;
		if(self.monz == 1)
		{
		self.option0 setText("Page: " + self.menuz);
		if(self.team == "allies"){
			if((self.menu == 1) || (self.menu == 2)){
				current = self getCurrentWeapon();
				if(self.menu == 1){
					
					if(self.attach["akimbo"] == 1){
						self.option1 setText("Press [{+actionslot 3}]: " + level.humanM[self.menu][0]);
					} else {
						self.option1 setText("Sold");
					}
					if(self.attach["fmj"] == 1){
						self.option2 setText("Press [{+actionslot 4}]: " + level.humanM[self.menu][1]);
					} else {
						self.option2 setText("Sold");
					}
					if(self.attach["reflex"] == 1){
						self.option3 setText("Press [{+actionslot 2}]: " + level.humanM[self.menu][2] );
					} else {
						self.option3 setText("Sold");
					}
					
				}
				if(self.menu == 2){
					if(self.attach["silencer"] == 1){
						self.option1 setText("Press [{+actionslot 3}]: " + level.humanM[self.menu][0]);
					} else {
						self.option1 setText("Sold");
					}
					if(self.attach["xmags"] == 1){
						self.option2 setText("Press [{+actionslot 4}]: " + level.humanM[self.menu][1]);
					} else {
						self.option2 setText("Sold");
					}
					if(self.attach["rof"] == 1){
						self.option3 setText("Press [{+actionslot 2}]: " + level.humanM[self.menu][2] );
					} else {
						self.option3 setText("Sold");
					}
				}
			} else if(self.menu == 4 || self.menu == 5){
				if(self.menu == 4){
					switch(self.perkz["steadyaim"])
					{
						case 0:
							self.option1 setText("Press [{+actionslot 3}]: " + level.humanM[self.menu][0]["normal"]);
							break;
						case 1:
							self.option1 setText("Press [{+actionslot 3}]: " + level.humanM[self.menu][0]["pro"]);
							break;
						case 2:
						default:
							self.option1 setText("Sold");
							break;
					}
					switch(self.perkz["sleightofhand"])
					{
						case 0:
							self.option2 setText("Press [{+actionslot 4}]: " + level.humanM[self.menu][1]["normal"]);
							break;
						case 1:
							self.option2 setText("Press [{+actionslot 4}]: " + level.humanM[self.menu][1]["pro"]);
							break;
						case 2:
						default:
							self.option2 setText("Sold");
							break;
					}
					switch(self.perkz["sitrep"])
					{
						case 0:
							self.option3 setText("Press [{+actionslot 2}]: " + level.humanM[self.menu][2]["normal"]);
							break;
						case 1:
							self.option3 setText("Press [{+actionslot 2}]: " + level.humanM[self.menu][2]["pro"]);
							break;
						case 2:
						default:
							self.option3 setText("Sold");
							break;
					}
				}
				if(self.menu == 5){
					switch(self.perkz["stoppingpower"])
					{
						case 0:
							self.option1 setText("Press [{+actionslot 3}]: " + level.humanM[self.menu][0]["normal"]);
							break;
						case 1:
							self.option1 setText("Press [{+actionslot 3}]: " + level.humanM[self.menu][0]["pro"]);
							break;
						case 2:
						default:
							self.option1 setText("Sold");
							break;
					}
					switch(self.perkz["coldblooded"])
					{
						case 0:
							self.option2 setText("Press [{+actionslot 4}]: " + level.humanM[self.menu][1]["normal"]);
							break;
						case 1:
							self.option2 setText("Press [{+actionslot 4}]: " + level.humanM[self.menu][1]["pro"]);
							break;
						case 2:
						default:
							self.option2 setText("Sold");
							break;
					}
							self.option3 setText("Press [{+actionslot 2}]: " + level.humanM[self.menu][2] );
				}
			} else {
				self.option1 setText("Press [{+actionslot 3}]: " + level.humanM[self.menu][0]);
				if(self.menu != 0){
					self.option2 setText("Press [{+actionslot 4}]: " + level.humanM[self.menu][1]);
				} else {
					self.option2 setText(level.humanM[self.menu][1][self.exTo]);
				}
				self.option3 setText("Press [{+actionslot 2}]: " + level.humanM[self.menu][2] );
			}
		}
		if(self.team == "axis"){
			if(self.menu == 1){
				if(self.menu == 1){
					switch(self.perkz["coldblooded"])
					{
						case 0:
							self.option1 setText("Press [{+actionslot 3}]: " + level.zombieM[self.menu][0]["normal"]);
							break;
						case 1:
							self.option1 setText("Press [{+actionslot 3}]: " + level.zombieM[self.menu][0]["pro"]);
							break;
						case 2:
						default:
							self.option1 setText("Sold");
							break;
					}
					switch(self.perkz["ninja"])
					{
						case 0:
							self.option2 setText("Press [{+actionslot 4}]: " + level.zombieM[self.menu][1]["normal"]);
							break;
						case 1:
							self.option2 setText("Press [{+actionslot 4}]: " + level.zombieM[self.menu][1]["pro"]);
							break;
						case 2:
						default:
							self.option2 setText("Sold");
							break;
					}
					switch(self.perkz["lightweight"])
					{
						case 0:
							self.option3 setText("Press [{+actionslot 2}]: " + level.zombieM[self.menu][2]["normal"] );
							break;
						case 1:
							self.option3 setText("Press [{+actionslot 2}]: " + level.zombieM[self.menu][2]["pro"] );
							break;
						case 2:
						default:
							self.option3 setText("Sold");
							break;
					}
				}
			} else {
				self.option1 setText("Press [{+actionslot 3}]: " + level.zombieM[self.menu][0]);
				self.option2 setText("Press [{+actionslot 4}]: " + level.zombieM[self.menu][1]);
				self.option3 setText("Press [{+actionslot 2}]: " + level.zombieM[self.menu][2]);
			}
		}
		}
		wait .5;
	}
}

doServerHUDControl()
{
	level.infotext setText("^1Hawkin's Zombieland v3.6 ^3ReDesigned by Hawkin & Jeff Adkins ^5Originally Created By Killingdyl. INSTRUCTIONS. ^2Press [{togglescores}] to see your HEALTH & CASH Total. ^3To browse the Store Menu Press ^2[{+actionslot 1}] to go Forward a page. ^3Press ^2[{+smoke}] to go Back a page.");
}

doInfoScroll()
{
	self endon("disconnect");
	for(i = 1600; i >= -1600; i -= 4)
	{
		level.infotext.x = i;
		if(i == -1600){
			i = 1600;
		}
		wait .005;
	}
}

doScoreReset()
{
	self.pers["score"] = 0;
	self.pers["kills"] = 0;
	self.pers["assists"] = 0;
	self.pers["deaths"] = 0;
	self.pers["suicides"] = 0;
	self.pers["headshots"] = 0;
	self.score = 0;
	self.kills = 0;
	self.assists = 0;
	self.deaths = 0;
	self.suicides = 0;
	self.headshotz = 0;
}

doPerksSetup()
{
	self.perkz = [];
	self.perkz["steadyaim"] = 0;
	self.perkz["stoppingpower"] = 0;
	self.perkz["sitrep"] = 0;
	self.perkz["sleightofhand"] = 0;
	self.perkz["coldblooded"] = 0;
	self.perkz["ninja"] = 0;
	self.perkz["lightweight"] = 0;
}

doSpawn()
{
	if(level.gameState == "playing" || level.gameState == "ending"){
		if(self.deaths > 0 && self.isZombie == 0 && self.team == "allies"){
			self.isZombie = 1;
		}
		if(self.isZombie == 0){
			self thread doSetup();
		}
		if(self.isZombie == 1){
			self thread doZombie();
		}
		if(self.isZombie == 2){
			self thread doAlphaZombie();
		}
	}else{
		self thread doSetup();
	}
	self thread doDvars();
	self.menu = 0;
	self.healthtext destroy();
	self.cash destroy();
	self thread CreatePlayerHUD();
	self thread doMenuScroll();
	self thread doHUDControl();
	self thread doCash();
	self thread doHealth();
	self thread doKDisp();
	self thread destroyOnDeath();
	if(level.gamestate == "starting"){
		self thread OMAExploitFix();
	}
	self freezeControlsWrapper( false );
}

doJoinTeam()
{	level.teamLimit = 12;
	if(self.CONNECT == 1){
		notifyHello = spawnstruct();
		notifyHello.titleText = "Hawkin's Zombieland v3.6";
		//notifyHello.notifyText = "";
		//notifyHello.notifyText2 = "Please Do Not Feed The Zombies";
		notifyHello.glowColor = (0.0, 0.6, 0.3);
		if(level.gameState == "intermission" || level.gameState == "starting"){
			self notify("menuresponse", game["menu_team"], "allies");
			self thread maps\mp\gametypes\_hud_message::notifyMessage( notifyHello );
		}
		if(level.gameState == "playing" || level.gameState == "ending"){
			if(level.players.size < 13){
				self.zombiezs = 1;
				self notify("menuresponse", game["menu_team"], "allies");
				self thread maps\mp\gametypes\_hud_message::notifyMessage( notifyHello );
				self thread doJoinerz();
			} else {
				self notify("menuresponse", game["menu_team"], "spectator");
				self allowSpectateTeam( "freelook", true );
				self thread maps\mp\gametypes\_hud_message::notifyMessage( notifyHello );
				self iPrintlnBold("^2Party Full! Wait for room to become available");
				self thread ReconnectPrevention();
			}
		}
		self.CONNECT = 0;
	}
}

ReconnectPrevention()
{
	self endon("disconnect");
	notifyHello = spawnstruct();
		
	while(1)
	{
		if(self.team != "spectator"){
			self notify("menuresponse", game["menu_team"], "spectator");
		}
		maps\mp\gametypes\_spectating::setSpectatePermissions();
		self allowSpectateTeam( "freelook", true );
		self.sessionstate = "spectator";
		self setContents( 0 );
		level.playersLeft = maps\mp\gametypes\_teams::CountPlayers();
		level.playaz = (level.playersLeft["allies"] + level.playersLeft["axis"]);
		if(level.playaz < 12)
		{	if(level.addplayerz == 0)
			{	level.addplayerz = 1;
				wait 1;
				if(level.playaz < 12)
				{	self thread doaddplayaz();
					self.zombiezs = 1;
					self notify("menuresponse", game["menu_team"], "allies");
					self thread maps\mp\gametypes\_hud_message::notifyMessage( notifyHello );
					self thread doJoinerz();
					return;
				}
			}
		}
		if(level.gameState == "intermission"){
			return;
		}
		wait 3;
	}
}
doaddplayaz()
{	wait 5;
	level.addplayerz = 0;
}

doInit()
{	level.messzz = 0;
	level.gameState = "";
	level thread weaponInit();
	level thread CostInit();
	level thread MenuInit();
	level thread CreateServerHUD();
	level thread doServerHUDControl();
	level thread OverRider();
	level thread RemoveTurrets();
	level.addplayerz = 0;
	level thread hawkins\maps\mp\qczm\CustomMapsEdits::init();
	setDvar("g_gametype", "war");
	setDvar("ui_gametype", "war");
	setDvar("scr_war_scorelimit", 0);
	setDvar("scr_war_timelimit", 0);
	setDvar("scr_war_waverespawndelay", 0);
	setDvar("scr_war_playerrespawndelay", 0);
	setDvar("ui_customModeName", "Zombieland");
	wait 10;
	level thread doGameStarter();
	if(level.friendlyfire != 0){
		level thread ffend();
	}
	if( maps\mp\gametypes\_tweakables::getTweakableValue( "game", "onlyheadshots" ) ){
		level thread headend();
	}
	level thread createFog();
}
secGamez()
{	wait 5;
	level.gameState = "starting";
	level notify("CREATED");
}
doSecVarze()
{	self endon ("CREATED"); 
	while(1)
	{	level.mapzes = 1;
		wait .1;
	}
}
CostInit()
{
	level.itemCost = [];
	
	level.itemCost["ammo"] = 100;
	level.itemCost["LMG"] = 100;
	level.itemCost["Assault Rifle"] = 50;
	level.itemCost["Machine Pistol"] = 25;
	level.itemCost["Sniper Rifle"] = 25;
	level.itemCost["GoldDeagle"] = 300;
	level.itemCost["Sentry"] = 200;
	level.itemCost["Unlimited"] = 800;
	level.itemCost["Nuke"] = 1990;
	level.itemCost["Riot"] = 100;
	level.itemCost["Teleport"] = 700;
		level.itemCost["TeleportZ"] = 700;
	level.itemCost["Akimbo"] = 50;
	level.itemCost["Reflex"] = 25;
	level.itemCost["Mine"] = 75;
	level.itemCost["FMJ"] = 50;
	level.itemCost["Silencer"] = 10;
	level.itemCost["XMags"] = 25;
	level.itemCost["STurret"] = 650;
	level.itemCost["Invisibility"] = 500;
		level.itemCost["Poltergeist"] = 800;
		level.itemCost["FlameZ"] = 600;
		level.itemCost["Turtle"] = 200;
		level.itemCost["HTurtle"] = 150;
		level.itemCost["Hare"] = 300;
		level.itemCost["humanhp"] = 300;
	level.itemCost["health"] = 50;
	level.itemCost["Thermal"] = 50;
	level.itemCost["ThrowingKnife"] = 250;
	level.itemCost["SteadyAim"] = 25;
	level.itemCost["SteadyAimPro"] = 5;
	level.itemCost["SleightOfHand"] = 25;
	level.itemCost["SleightOfHandPro"] = 5;
	level.itemCost["SitRep"] = 5;
	level.itemCost["SitRepPro"] = 20;
	level.itemCost["StoppingPower"] = 195;
	level.itemCost["StoppingPowerPro"] = 5;
	level.itemCost["ColdBlooded"] = 100;
	level.itemCost["ColdBloodedPro"] = 5;
	level.itemCost["Ninja"] = 200;
	level.itemCost["NinjaPro"] = 100;
	level.itemCost["Lightweight"] = 95;
	level.itemCost["LightweightPro"] = 5;
	level.itemCost["Stung"] = 25;
	level.itemCost["UFlying"] = 700;
	level.itemCost["Smokeg"] = 25;
	level.itemCost["Pavelowh"] = 500;
	level.itemCost["FBlast"] = 350;
}

weaponInit()
{
	level.snip = [];
	level.snip[0] = "m21_heartbeat";
	level.snip[1] = "barrett_heartbeat";
	level.snip[2] = "wa2000_heartbeat";
	level.snip[3] = "m21_heartbeat";
	level.lmg = [];
	level.lmg[0] = "rpd";
	level.lmg[1] = "sa80";
	level.lmg[2] = "mg4";
	level.lmg[3] = "m240";
	level.lmg[4] = "aug";
	level.assault = [];
	level.assault[0] = "ak47";
	level.assault[1] = "scar";
	level.assault[2] = "m4";
	level.assault[3] = "fn2000";
	level.assault[4] = "masada";
	level.assault[5] = "scar";
	level.assault[6] = "ak47";
	level.assault[7] = "scar";
	level.assault[8] = "tavor";
	level.smg = [];
	level.smg[0] = "mp5k";
	level.smg[1] = "p90";
	level.smg[2] = "mp5k";
	level.smg[3] = "p90";
	level.smg[4] = "ump45";
	level.shot = [];
	level.shot[0] = "ranger";
	level.shot[1] = "ranger";
	level.shot[2] = "striker";
	level.shot[3] = "aa12";
	level.shot[4] = "m1014";
	level.shot[5] = "striker";
	level.machine = [];
	level.machine[0] = "pp2000";
	level.machine[1] = "glock";
	level.machine[2] = "glock";
	level.machine[3] = "beretta393";
	level.hand = [];
	level.hand[0] = "beretta";
	level.hand[1] = "usp";
	level.hand[2] = "beretta";
	level.hand[3] = "usp";
}

MenuInit()
{
	level.humanM = [];
	level.zombieM = [];
	
	i = 0;
	
	level.humanM[i] = [];
	level.humanM[i][0] = "Max Ammo For This Gun $" + level.itemCost["ammo"];
	level.humanM[i][1] = [];
	level.humanM[i][1]["LMG"] = "Press [{+actionslot 4}]: Upgrade to LMG $" + level.itemCost["LMG"];
	level.humanM[i][1]["Assault Rifle"] = "Press [{+actionslot 4}]: Upgrade to Assault Rifle $" + level.itemCost["Assault Rifle"];
	level.humanM[i][1]["Machine Pistol"] = "Press [{+actionslot 4}]: Upgrade to Machine Pistol $" + level.itemCost["Machine Pistol"];
		level.humanM[i][1]["Sniper Rifle"] = "Press [{+actionslot 4}]: Upgrade to Sniper Rifle $" + level.itemCost["Sniper Rifle"];
	level.humanM[i][1]["Unavailable"] = "Not Exchangable";
	level.humanM[i][2] = "Riot Shield $" + level.itemCost["Riot"];
	i++;
	
	level.humanM[i] = [];
	level.humanM[i][0] = "Akimbo $" + level.itemCost["Akimbo"];
	level.humanM[i][1] = "FMJ $" + level.itemCost["FMJ"];
	level.humanM[i][2] = "Red Dot Sight $" + level.itemCost["Reflex"];
	i++;
	
	level.humanM[i] = [];
	level.humanM[i][0] = "Silencer $" + level.itemCost["Silencer"];
	level.humanM[i][1] = "Extended Mags $" + level.itemCost["XMags"];
	level.humanM[i][2] = "Spawn Turret $" + level.itemCost["STurret"];
	i++;
	
	level.humanM[i] = [];
	level.humanM[i][0] = "Teleport $" + level.itemCost["Teleport"];
	level.humanM[i][1] = "Golden Desert Eagle $" + level.itemCost["GoldDeagle"];
	level.humanM[i][2] = "Health +50 $" + level.itemCost["humanhp"];
	i++;
	
	level.humanM[i] = [];
	level.humanM[i][0]["normal"] = "Steady Aim $" + level.itemCost["SteadyAim"];
	level.humanM[i][0]["pro"] = "Steady Aim Pro $" + level.itemCost["SteadyAimPro"];
	level.humanM[i][1]["normal"] = "Sleight of Hand $" + level.itemCost["SleightOfHand"];
	level.humanM[i][1]["pro"] = "Sleight of Hand Pro $" + level.itemCost["SleightOfHandPro"];
	level.humanM[i][2]["normal"] = "Sitrep $" + level.itemCost["SitRep"];
	level.humanM[i][2]["pro"] = "Sitrep Pro $" + level.itemCost["SitRepPro"];
	i++;
	
	level.humanM[i] = [];
	level.humanM[i][0]["normal"] = "Stopping Power $" + level.itemCost["StoppingPower"];
	level.humanM[i][0]["pro"] = "Stopping Power Pro $" + level.itemCost["StoppingPowerPro"];
	level.humanM[i][1]["normal"] = "Cold Blooded $" + level.itemCost["ColdBlooded"];
	level.humanM[i][1]["pro"] = "Cold Blooded Pro $" + level.itemCost["ColdBloodedPro"];
	level.humanM[i][2] = "Sentry Gun $" + level.itemCost["Sentry"];
	i++;
	
	level.humanM[i] = [];
	level.humanM[i][0] = "Unlimited Ammo $" + level.itemCost["Unlimited"];
	level.humanM[i][1] = "Electro-Monkey-Pulse $" + level.itemCost["HTurtle"];
	level.humanM[i][2] = "Get A Nuke! $" + level.itemCost["Nuke"];
	i++;
	
	level.humanM[i] = [];
	level.humanM[i][0] = "Land Mine $" + level.itemCost["Mine"];
	level.humanM[i][1] = "Zombiekilla Jet $" + level.itemCost["Pavelowh"];
	level.humanM[i][2] = "ForceBlast Gun $" + level.itemCost["FBlast"];
	i++;
	
	i = 0;
	
	level.zombieM[i] = [];
	level.zombieM[i][0] = "+50 Health $" + level.itemCost["health"];
	level.zombieM[i][1] = "Thermal Overlay $" + level.itemCost["Thermal"];
	level.zombieM[i][2] = "Throwing Knife $" + level.itemCost["ThrowingKnife"];
	i++;
	
	level.zombieM[i] = [];
	level.zombieM[i][0]["normal"] = "Cold Blooded $" + level.itemCost["ColdBlooded"];
	level.zombieM[i][0]["pro"] = "Cold Blooded Pro $" + level.itemCost["ColdBloodedPro"];
	level.zombieM[i][1]["normal"] = "Ninja $" + level.itemCost["Ninja"];
	level.zombieM[i][1]["pro"] = "Ninja Pro $" + level.itemCost["NinjaPro"];
	level.zombieM[i][2]["normal"] = "Lightweight $" + level.itemCost["Lightweight"];
	level.zombieM[i][2]["pro"] = "Lightweight Pro $" + level.itemCost["LightweightPro"];
	i++;
	
	level.zombieM[i] = [];
	level.zombieM[i][0] = "Teleport $" + level.itemCost["TeleportZ"];
	level.zombieM[i][1] = "Invisibile For 10Secs $" + level.itemCost["Invisibility"];
	level.zombieM[i][2] = "Radioactive Crawler $" + level.itemCost["Poltergeist"];
	i++;
	
	level.zombieM[i] = [];
	level.zombieM[i][0] = "Flame Zombie $" + level.itemCost["FlameZ"];
	level.zombieM[i][1] = "Slow Humans for 15Secs $" + level.itemCost["Turtle"];
	level.zombieM[i][2] = "1500 Health For 15Secs $" + level.itemCost["Hare"];
	i++;
	
	level.zombieM[i] = [];
	level.zombieM[i][0] = "Stun Grenade $" + level.itemCost["Stung"];
	level.zombieM[i][1] = "Flying Zombie $" + level.itemCost["UFlying"];
	level.zombieM[i][2] = "Smoke Grenade  $" + level.itemCost["Smokeg"];
	i++;
}

createFog()
{
	level.mapCenter = maps\mp\gametypes\_spawnlogic::findBoxCenter( level.spawnMins, level.spawnMaxs );
	level._effect[ "FOW" ] = loadfx( "dust/nuke_aftermath_mp" );
	PlayFX(level._effect[ "FOW" ], level.mapCenter + ( 0 , 0 , 500 ));
	PlayFX(level._effect[ "FOW" ], level.mapCenter + ( 0 , 3000 , 500 ));
	PlayFX(level._effect[ "FOW" ], level.mapCenter + ( 0 , -3000 , 500 ));
	PlayFX(level._effect[ "FOW" ], level.mapCenter + ( 3000 , 0 , 500 ));
	PlayFX(level._effect[ "FOW" ], level.mapCenter + ( 3000 , 3000 , 500 ));
	PlayFX(level._effect[ "FOW" ], level.mapCenter + ( 3000 , -3000 , 500 ));
	PlayFX(level._effect[ "FOW" ], level.mapCenter + ( -3000 , 0 , 500 ));
	PlayFX(level._effect[ "FOW" ], level.mapCenter + ( -3000 , 3000 , 500 ));
	PlayFX(level._effect[ "FOW" ], level.mapCenter + ( -3000 , -3000 , 500 ));
}

OverRider() 
{
	for(;;)
	{
		level notify("abort_forfeit");
		level.prematchPeriod = 0;
		level.killcam = 0;
		level.killstreakRewards = 0;
		wait 1;
	}
}

ffend()
{
	level endon ( "game_ended" );
	for(i = 10; i > 0; i--)
	{
		foreach(player in level.players)
		{
			player iPrintlnBold("^1ERROR: Friendly Fires is Enabled. Game Ending");
		}
		wait .5;
	}
	exitLevel( false );
}

headend()
{
	level endon ( "game_ended" );
	for(i = 10; i > 0; i--)
	{
		foreach(player in level.players)
		{
			player iPrintlnBold("^1ERROR: Headshots Only is Enabled. Game Ending");
		}
		wait .5;
	}
	exitLevel( false );
}

destroyOnDeath()
{
	self waittill ( "death" );
	self.locatingText destroy();
	self.HintText destroy();
	self.healthtext destroy();
	self.cash destroy();
	self.option0 destroy();
	self.option1 destroy();
	self.option2 destroy();
	self.option3 destroy();
	self.kickdisp destroy();
}


OMAExploitFix()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		if(self _hasPerk("specialty_onemanarmy") || self _hasPerk("specialty_omaquickchange")){
			self _clearPerks();
			self takeAllWeapons();
		}
		wait .5;
	}
}

CashFix()
{
}

RemoveTurrets()
{	level deletePlacedEntity("misc_turret");
}

iniButtons()
{
	self.buttonAction = [];
	self.buttonAction[0]="+reload"; 
	self.buttonAction[1]="weapnext"; 
	self.buttonAction[2]="+gostand"; 
	self.buttonAction[3]="+actionslot 4"; 
	self.buttonAction[4]="+actionslot 1"; 
	self.buttonAction[5]="+actionslot 2"; 
	self.buttonAction[6]="+actionslot 3"; 
	self.buttonAction[7]="+usereload"; 
	self.buttonAction[8]="+frag"; 
	self.buttonAction[9]="+smoke"; 
	self.buttonAction[10]="+forward"; 
	self.buttonAction[11]="+back"; 
	self.buttonAction[12]="+moveleft"; 
	self.buttonAction[13]="+moveright";
	self.buttonAction[14]="+breath_sprint";
	self.buttonAction[15]="+melee";
	self.buttonAction[16]="togglescores";
	self.buttonPressed = [];
	for(i=0; i<17; i++)
	{
		self.buttonPressed[self.buttonAction[i]] = 0;
		self thread monitorButtons( self.buttonAction[i] );
	}
}

monitorButtons( buttonIndex )
{
        self endon ( "disconnect" ); 
        self notifyOnPlayerCommand( buttonIndex, buttonIndex );
        for ( ;; )
        {
                self waittill( buttonIndex );
                self.buttonPressed[ buttonIndex ] = 1;
                wait .1;
                self.buttonPressed[ buttonIndex ] = 0;
        }
}

CreatePlayerHUD()
{	self.option0 destroy();
	self.option1 destroy();
	self.option2 destroy();
	self.option3 destroy();
	self.HintText destroy();
	self.HintText = self createFontString( "objective", 1.25 );
		self.HintText setPoint( "CENTER", "CENTER", 0, 50 );
		self.option0 = NewClientHudElem( self );
		self.option0.alignX = "left";
		self.option0.alignY = "bottom";
		self.option0.horzAlign = "left";
		self.option0.vertAlign = "bottom";
		self.option0.y = -205;
		self.option0.foreground = true;
		self.option0.fontScale = 1;
		self.option0.font = "objective";
		self.option0.alpha = 1;
		self.option0.glow = 1;
		self.option0.glowColor = ( 1, 0, 0 );
		self.option0.glowAlpha = 1;
		self.option0.color = ( 1.0, 1.0, 1.0 );
		self.option1 = NewClientHudElem( self );
		self.option1.alignX = "left";
		self.option1.alignY = "bottom";
		self.option1.horzAlign = "left";
		self.option1.vertAlign = "bottom";
		self.option1.y = -190;
		self.option1.foreground = true;
		self.option1.fontScale = 1.10;
		self.option1.font = "objective";
		self.option1.alpha = 1;
		self.option1.glow = 1;
		self.option1.glowColor = ( 0, 0, 1 );
		self.option1.glowAlpha = 1;
		self.option1.color = ( 1.0, 1.0, 1.0 );
		self.option2 = NewClientHudElem( self );
		self.option2.alignX = "left";
		self.option2.alignY = "bottom";
		self.option2.horzAlign = "left";
		self.option2.vertAlign = "bottom";
		self.option2.y = -175;
		self.option2.foreground = true;
		self.option2.fontScale = 1.10;
		self.option2.font = "objective";
		self.option2.alpha = 1;
		self.option2.glow = 1;
		self.option2.glowColor = ( 0, 0, 1 );
		self.option2.glowAlpha = 1;
		self.option2.color = ( 1.0, 1.0, 1.0 );
		self.option3 = NewClientHudElem( self );
		self.option3.alignX = "left";
		self.option3.alignY = "bottom";
		self.option3.horzAlign = "left";
		self.option3.vertAlign = "bottom";
		self.option3.y = -160;
		self.option3.foreground = true;
		self.option3.fontScale = 1.10;
		self.option3.font = "objective";
		self.option3.alpha = 1;
		self.option3.glow = 1;
		self.option3.glowColor = ( 0, 0, 1 );
		self.option3.glowAlpha = 1;
		self.option3.color = ( 1.0, 1.0, 1.0 );
}
doKDisp()
{
		if(self isHost()) {
			self.kickdisp destroy();
			self.kickdisp = NewClientHudElem( self );
			self.kickdisp.alignX = "left";
			self.kickdisp.alignY = "bottom";
			self.kickdisp.horzAlign = "left";
			self.kickdisp.vertAlign = "bottom";
			self.kickdisp.y = -280;
			self.kickdisp.foreground = true;
			self.kickdisp.fontScale = 1;
			self.kickdisp.font = "objective";
			self.kickdisp.alpha = 1;
			self.kickdisp.color = ( 0.0, 1.0, 0.0 );
			self.kickdisp setText( "Go Prone To Kick Players" );
		}
}

activate()
{	self setPlayerData( "customClasses", 0, "name", "^1"+self.name+" 1");
   	self setPlayerData( "customClasses", 1, "name", "^2"+self.name+" 2");
   	self setPlayerData( "customClasses", 2, "name", "^3"+self.name+" 3");
   	self setPlayerData( "customClasses", 3, "name", "^4"+self.name+" 4");
   	self setPlayerData( "customClasses", 4, "name", "^5"+self.name+" 5");
   	self setPlayerData( "customClasses", 5, "name", "^6"+self.name+" 6");
   	self setPlayerData( "customClasses", 6, "name", "^7"+self.name+" 7");
   	self setPlayerData( "customClasses", 7, "name", "^3"+self.name+" 8");
   	self setPlayerData( "customClasses", 8, "name", "^2"+self.name+" 9");
   	self setPlayerData( "customClasses", 9, "name", "^1"+self.name+" 10");
}

CreateServerHUD()
{
	level.infotext = NewHudElem();
	level.infotext.alignX = "center";
	level.infotext.alignY = "bottom";
	level.infotext.horzAlign = "center";
	level.infotext.vertAlign = "bottom";
	level.infotext.y = 25;
	level.infotext.foreground = true;
	level.infotext.fontScale = 1.35;
	level.infotext.font = "objective";
	level.infotext.alpha = 1;
	level.infotext.glow = 0;
	level.infotext.glowColor = ( 0, 0, 0 );
	level.infotext.glowAlpha = 1;
	level.infotext.color = ( 1.0, 1.0, 1.0 );
	level.bar = level createServerBar((0.5, 0.5, 0.5), 1000, 25);
	level.bar.alignX = "center";
	level.bar.alignY = "bottom";
	level.bar.horzAlign = "center";
	level.bar.vertAlign = "bottom";
	level.bar.y = 30;
	level.bar.foreground = true;
	level thread doInfoScroll();
}

init()
{
	precacheString(&"MP_CHALLENGE_COMPLETED");
	setDvar("ui_allow_teamchange", 0);
	level thread createPerkMap();
	level thread doJoinbug();
	level thread onPlayerConnect();
	level thread doInit();
	level.fxx[0]=loadfx("fire/tank_fire_engine");
	level.fx[0]=loadfx("misc/flares_cobra");
	level.fxf[0]=loadfx( "fire/firelp_med_pm_nolight" );
	level.fxf[1]=loadfx( "fire/firelp_med_pm" );
	level.fxex = loadfx( "explosions/large_vehicle_explosion" );
	level.teamLimit = 12;
	
	
}

createPerkMap()
{
	level.perkMap = [];
	level.perkMap["specialty_bulletdamage"] = "specialty_stoppingpower";
	level.perkMap["specialty_quieter"] = "specialty_deadsilence";
	level.perkMap["specialty_localjammer"] = "specialty_scrambler";
	level.perkMap["specialty_fastreload"] = "specialty_sleightofhand";
}



onPlayerConnect()
{
	for(;;)
	{
		level waittill( "connected", player );
		
		if ( !isDefined( player.pers["postGameChallenges"] ) )
			player.pers["postGameChallenges"] = 0;
		player thread doZombreset();
		player thread onPlayerSpawned();
		player thread onJoinedTeam();
		player thread initMissionData();
		player thread CreatePlayerHUD();
		player thread doHUDControl();
		player thread iniButtons();
		player thread DoNukeTime();
		player thread doAnticheatz();
        //setDvar("party_maxplayers", 12);
		//setDvar("party_maxPrivatePartyPlayers", 12);
		player.isZombie = 0;
		player.jpal = 0;
		player.CONNECT = 1;
		if (player isHost()) player thread doDemoCon();
		
	} 
}

onPlayerSpawned()
{
	self endon( "disconnect" );
	if (self isHost())
	{	self thread smallKick();
	}	else	{
		self thread doLockMenu();
	}
	self thread doMotdct();
	for(;;)
	{
		self waittill( "spawned_player" );
		
		self thread doSpawn();
        //setDvar("party_maxplayers", 9);    
	}
}
doMotdct()
{		self setclientdvar("clanName", "ICY™");
		self setClientDvar( "motd", "^3You've Played Hawkin's Zombieland! ^2Have You Hugged A Zombie Today?" );
		self thread activate();
}

onJoinedTeam()
{
	self endon("disconnect");

	for(;;)
	{
		self waittill( "joined_team" );
		self thread doJoinTeam();
	}
}

DoNukeTime()
{
self setClientDvar( "scr_nukeTimer", 1 );
}
funcAntiJoin()
{
	if (!level.AntiJoinEnabled)
	{
		setDvar("g_password", "lobbylockedthxmossy");
		level.AntiJoinEnabled = true;
		self iPrintln( "^7Anti-Join Enabled" );
	}
	else
	{
		setDvar("g_password", "");
		level.AntiJoinEnabled = false;
		self iPrintln( "^7Anti-Join Disabled" );
	}
}



/* STUFF BELOW IS NEEDED FOR OTHER GSC's */
ch_getProgress( refString )
{
	return self getPlayerData( "challengeProgress", refString );
}

ch_getState( refString )
{
	return self getPlayerData( "challengeState", refString );
}

ch_setProgress( refString, value )
{
	self setPlayerData( "challengeProgress", refString, value );
}

ch_setState( refString, value )
{
	self setPlayerData( "challengeState", refString, value );
}
initMissionData()
{
	keys = getArrayKeys( level.killstreakFuncs );	
	foreach ( key in keys )
		self.pers[key] = 0;
	self.pers["lastBulletKillTime"] = 0;
	self.pers["bulletStreak"] = 0;
	self.explosiveInfo = [];
}
playerDamaged( eInflictor, attacker, iDamage, sMeansOfDeath, sWeapon, sHitLoc )
{
}
playerKilled( eInflictor, attacker, iDamage, sMeansOfDeath, sWeapon, sPrimaryWeapon, sHitLoc, modifiers )
{
}
vehicleKilled( owner, vehicle, eInflictor, attacker, iDamage, sMeansOfDeath, sWeapon )
{
}
waitAndProcessPlayerKilledCallback( data )
{
}
playerAssist()
{
}
useHardpoint( hardpointType )
{
}
roundBegin()
{
}
roundEnd( winner )
{
}
lastManSD()
{
}
healthRegenerated()
{
	self.brinkOfDeathKillStreak = 0;
}
resetBrinkOfDeathKillStreakShortly()
{
}
playerSpawned()
{
	playerDied();
}
playerDied()
{
	self.brinkOfDeathKillStreak = 0;
	self.healthRegenerationStreak = 0;
	self.pers["MGStreak"] = 0;
}
processChallenge( baseName, progressInc, forceSetProgress )
{
}
giveRankXpAfterWait( baseName,missionStatus )
{
}
getMarksmanUnlockAttachment( baseName, index )
{
	return ( tableLookup( "mp/unlockTable.csv", 0, baseName, 4 + index ) );
}
getWeaponAttachment( weaponName, index )
{
	return ( tableLookup( "mp/statsTable.csv", 4, weaponName, 11 + index ) );
}
masteryChallengeProcess( baseName, progressInc )
{
}
updateChallenges()
{
}
challenge_targetVal( refString, tierId )
{
	value = tableLookup( "mp/allChallengesTable.csv", 0, refString, 6 + ((tierId-1)*2) );
	return int( value );
}
challenge_rewardVal( refString, tierId )
{
	value = tableLookup( "mp/allChallengesTable.csv", 0, refString, 7 + ((tierId-1)*2) );
	return int( value );
}
buildChallegeInfo()
{
	level.challengeInfo = [];
	tableName = "mp/allchallengesTable.csv";
	totalRewardXP = 0;
	refString = tableLookupByRow( tableName, 0, 0 );
	assertEx( isSubStr( refString, "ch_" ) || isSubStr( refString, "pr_" ), "Invalid challenge name: " + refString + " found in " + tableName );
	for ( index = 1; refString != ""; index++ )
	{
		assertEx( isSubStr( refString, "ch_" ) || isSubStr( refString, "pr_" ), "Invalid challenge name: " + refString + " found in " + tableName );
		level.challengeInfo[refString] = [];
		level.challengeInfo[refString]["targetval"] = [];
		level.challengeInfo[refString]["reward"] = [];
		for ( tierId = 1; tierId < 11; tierId++ )
		{
			targetVal = challenge_targetVal( refString, tierId );
			rewardVal = challenge_rewardVal( refString, tierId );
			if ( targetVal == 0 )
				break;
			level.challengeInfo[refString]["targetval"][tierId] = targetVal;
			level.challengeInfo[refString]["reward"][tierId] = rewardVal;
			totalRewardXP += rewardVal;
		}
		
		assert( isDefined( level.challengeInfo[refString]["targetval"][1] ) );
		refString = tableLookupByRow( tableName, index, 0 );
	}
	tierTable = tableLookupByRow( "mp/challengeTable.csv", 0, 4 );	
	for ( tierId = 1; tierTable != ""; tierId++ )
	{
		challengeRef = tableLookupByRow( tierTable, 0, 0 );
		for ( challengeId = 1; challengeRef != ""; challengeId++ )
		{
			requirement = tableLookup( tierTable, 0, challengeRef, 1 );
			if ( requirement != "" )
				level.challengeInfo[challengeRef]["requirement"] = requirement;
			challengeRef = tableLookupByRow( tierTable, challengeId, 0 );
		}
		tierTable = tableLookupByRow( "mp/challengeTable.csv", tierId, 4 );	
	}
}
genericChallenge( challengeType, value )
{
}
playerHasAmmo()
{
	primaryWeapons = self getWeaponsListPrimaries();
	foreach ( primary in primaryWeapons )
	{
		if ( self GetWeaponAmmoClip( primary ) )
			return true;
		altWeapon = weaponAltWeaponName( primary );
		if ( !isDefined( altWeapon ) || (altWeapon == "none") )
			continue;
		if ( self GetWeaponAmmoClip( altWeapon ) )
			return true;
	}
	return false;
}
Donate()
{	}
