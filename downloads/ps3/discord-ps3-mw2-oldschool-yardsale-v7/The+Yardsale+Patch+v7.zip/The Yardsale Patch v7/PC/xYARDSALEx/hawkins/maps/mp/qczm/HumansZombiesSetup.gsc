#include hawkins\maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include common_scripts\utility;
#include hawkins\maps\mp\gametypes\_missions;
#include hawkins\maps\mp\killstreaks\_ac130;

CreateMapWait()
{	setDvar("ui_allow_teamchange", 0);
	level.lockz = 0;
	level.testz = 0;
	level.TimerText destroy();
	level.TimerText = level createServerFontString( "objective", 1.5 );
	level.TimerText setPoint( "CENTER", "CENTER", 0, -100 );
	level.TimerText setText("^3Building Map");
	for(i = 30; i > 0; i--)
	{	foreach(player in level.players)
		{	if (player isHost())	{
			}	else	{
				player freezeControls(true);
				player VisionSetNakedForPlayer("mpIntro", 0);
		}	}
		wait 1;
	}
	if(level.testz == 1)
	{	level thread doPregamez();
		level notify("DEMOMODEZ");
	} else {
	level notify("CREATED");
	}
	foreach(player in level.players)
	{	player freezeControls(false);
		player VisionSetNakedForPlayer(getDvar("mapname"), 0);
	}
}

doSetup()  
{
	if(self.team == "axis" || self.team == "spectator"){
		self notify("menuresponse", game["menu_team"], "allies");
		wait .1;
		self notify("menuresponse", "changeclass", "class1");
		return;
	}
	self doScoreReset();
	self show();
	ChangeAppearance(5);
	wait .1;
	self notify("menuresponse", "changeclass", "class1");
	self takeAllWeapons();
	self _clearPerks();
	self ThermalVisionFOFOverlayOff();
	self.randomsnip = randomInt(4);
	self.randomlmg = randomInt(5);
	self.randomar = randomInt(9);
	self.randommp = randomInt(4);
	self.randomsmg = randomInt(5);
	self.randomshot = randomInt(6);
	self.randomhand = randomInt(4);
	self giveWeapon(level.smg[self.randomsmg] + "_mp", 0, false);
	self giveWeapon(level.shot[self.randomshot] + "_mp", 0, false);
	self giveWeapon(level.hand[self.randomhand] + "_mp", 0, false);
	self GiveMaxAmmo(level.smg[self.randomsmg] + "_mp");
	self GiveMaxAmmo(level.shot[self.randomshot] + "_mp");
	self GiveMaxAmmo(level.hand[self.randomhand] + "_mp");
	self switchToWeapon(level.smg[self.randomsmg] + "_mp");
	self maps\mp\perks\_perks::givePerk("specialty_marathon");
	self maps\mp\perks\_perks::givePerk("specialty_automantle");
	self maps\mp\perks\_perks::givePerk("specialty_fastmantle");
	self maps\mp\perks\_perks::givePerk("specialty_heartbreaker");
	self maps\mp\perks\_perks::givePerk("specialty_quieter");
	self maps\mp\perks\_perks::givePerk("specialty_falldamage");
	self thread doHW();
	self.bounty = 0;
	self thread doAnticheatz();
	self freezeControls(false);
	self.attach1 = [];
	self.attachweapon = [];
	self.attachweapon[0] = 0;
	self.attachweapon[1] = 0;
	self.attachweapon[2] = 0;
	self.attach1[0] = "none";
	self.attach1[1] = "none";
	self.attach1[2] = "none";
	self.currentweapon = 0;
	self thread doPerksSetup();
	self thread doPerkCheck();
	self player_recoilScaleOn(0);
	self.maxhp = 100;
	self thread doLyfe();
	self.moveSpeedScaler = 1.10;
	self setClientDvar("g_knockback", 1000);
	if(self.zombiezs == 1){
		self.isZombie = 1;
		self thread doZombie();
	} else {
		self.isZombie = 0;
		if(level.messzz == 1)
		{	notifySpawn = spawnstruct();
			notifySpawn.titleText = "Human";
			notifySpawn.notifyText = "Nuke the Zombies or Die Trying";
			notifySpawn.glowColor = (0.0, 0.0, 1.0);
			self thread maps\mp\gametypes\_hud_message::notifyMessage( notifySpawn );
		}
	self thread doHumanBounty();
	self thread doHumanShop();
	}
}

doAlphaZombie()  
{
	if(self.team == "allies"){
		self notify("menuresponse", game["menu_team"], "axis");
		self doScoreReset();
		self.bounty = 0;
		self.ck = self.kills;
		self.cd = self.deaths;
		self.cs = self.suicides;
		self.maxhp = 200;
		self thread doPerksSetup();
		wait .1;
		self notify("menuresponse", "changeclass", "class3");
		return;
	}
	self thread doZombieSetup();
}

doZombie() 
{
	if(self.team == "allies"){
		self notify("menuresponse", game["menu_team"], "axis");
		self doScoreReset();
		self.bounty = 50;
		
		self.ck = self.kills;
		self.cd = self.deaths;
		self.cs = self.suicides;
		self.maxhp = 100;
		self thread doPerksSetup();
		if (self isHost()) {
			self.bounty = 250;
		}
		wait .1;
		self notify("menuresponse", "changeclass", "class3");
		return;
	}
	self thread doZombieSetup();
}

doZombieSetup()
{
	wait .1;
	self notify("menuresponse", "changeclass", "class3");
	ChangeAppearance(0);
	self takeAllWeapons();
	self _clearPerks();
	self giveWeapon("usp_tactical_mp", 0, false);
	self thread doZW();
	self maps\mp\perks\_perks::givePerk("specialty_marathon");
	self maps\mp\perks\_perks::givePerk("specialty_automantle");
	self maps\mp\perks\_perks::givePerk("specialty_fastmantle");
	self maps\mp\perks\_perks::givePerk("specialty_extendedmelee");
	self maps\mp\perks\_perks::givePerk("specialty_falldamage");
	self maps\mp\perks\_perks::givePerk("specialty_thermal");
	self.moveSpeedScaler = 1.20;
	wait .1;
	if(self.thermal == 1){
		self ThermalVisionFOFOverlayOn();
	}
	if(self.flash == 1){
		self thread Flashspz();
		self thread Flash();
	}
	if(self.polter == 1){
		self thread DoPolter();
		self thread DoPoltDmg();
	}
	self.secondg = 0;
	self freezeControls(false);
	if(self.throwingknife == 1){
		
		self maps\mp\perks\_perks::givePerk( "throwingknife_mp" );
		self setWeaponAmmoClip("throwingknife_mp", 1);
	}
	self thread doPerkCheck();
	if(self.jetpackz == 1) self thread Jetpack();
	self thread doLyfe();
	self show();
	self setClientDvar("g_knockback", 3500);
	if(level.spawnz == 1){
		self thread RanSpwn();
	}
	notifySpawn = spawnstruct();
	if(self.deaths < 1){
		
		notifySpawn.titleText = "^0You're A Zombie";
		notifySpawn.notifyText = "Earn Money By Dying & Killing!";
		notifySpawn.glowColor = (1.0, 0.0, 0.0);
		self thread maps\mp\gametypes\_hud_message::notifyMessage( notifySpawn );
	}
	self thread doZombieBounty();
	self thread doZombieShop();
}
RanSpwn()
{	self.rnspawn = randomInt(1);
	if(self.rnspawn == 1)
	{	self SetOrigin(level.ZombieSpawnz);
	}	else	{
		self SetOrigin(level.ZombieSpawnzs);
	}
}
ChangeAppearance(Type)
{	ModelType=[];
	ModelType[0]="GHILLIE";
	ModelType[1]="SNIPER";
	ModelType[2]="LMG";
	ModelType[3]="ASSAULT";
	ModelType[4]="SHOTGUN";
	ModelType[5]="SMG";
	ModelType[6]="RIOT";
	team=self.team;
	self detachAll();
	[[game[team+"_model"][ModelType[Type]]]]();
}

doHW() 
{
	self endon ( "disconnect" );
	self endon ( "death" );
	while(1)
	{
		self.current = self getCurrentWeapon();
		switch(getWeaponClass(self.current))
		{
			case "weapon_lmg":
				self.exTo = "Unavailable";
				self.currentweapon = 0;
				break;
			case "weapon_assault":
				self.exTo = "LMG";
				self.currentweapon = 0;
				break;
			case "weapon_smg":
				self.exTo = "Assault Rifle";
				self.currentweapon = 0;
				break;
			case "weapon_shotgun":
				self.exTo = "Unavailable";
				self.currentweapon = 1;
				break;
			case "weapon_machine_pistol":
				self.exTo = "Sniper Rifle";
				self.currentweapon = 2;
				break;
			case "weapon_sniper":
				self.exTo = "Unavailable";
				self.currentweapon = 2;
				break;
			case "weapon_pistol":
				self.exTo = "Machine Pistol";
				self.currentweapon = 2;
				break;
			default:
				self.exTo = "Unavailable";
				self.currentweapon = 3;
				break;
		}
		basename = strtok(self.current, "_");
		if(basename.size > 2){
			self.attach1[self.currentweapon] = basename[1];
			self.attachweapon[self.currentweapon] = basename.size - 2;
		} else {
			self.attach1[self.currentweapon] = "none";
			self.attachweapon[self.currentweapon] = 0;
		}
		if(self.currentweapon == 3 || self.attachweapon[self.currentweapon] == 2){
			self.attach["akimbo"] = 0;
			self.attach["fmj"] = 0;
			self.attach["reflex"] = 0;
			self.attach["silencer"] = 0;
			self.attach["xmags"] = 0;
			self.attach["rof"] = 1;
		}
		if((self.attachweapon[self.currentweapon] == 0) || (self.attachweapon[self.currentweapon] == 1)){
			akimbo = buildWeaponName(basename[0], self.attach1[self.currentweapon], "akimbo");
			fmj = buildWeaponName(basename[0], self.attach1[self.currentweapon], "fmj");
			reflex = buildWeaponName(basename[0], self.attach1[self.currentweapon], "reflex");
			silencer = buildWeaponName(basename[0], self.attach1[self.currentweapon], "silencer");
			xmags = buildWeaponName(basename[0], self.attach1[self.currentweapon], "xmags");
			rof = buildWeaponName(basename[0], self.attach1[self.currentweapon], "rof");
			if(isValidWeapon(akimbo)){
				self.attach["akimbo"] = 1;
			} else {
				self.attach["akimbo"] = 0;
			}
			if(isValidWeapon(fmj)){
				self.attach["fmj"] = 1;
			} else {
				self.attach["fmj"] = 0;
			}
			if(isValidWeapon(reflex)){
				self.attach["reflex"] = 1;
			} else {
				self.attach["reflex"] = 0;
			}
			if(isValidWeapon(silencer)){
				self.attach["silencer"] = 1;
			} else {
				self.attach["silencer"] = 0;
			}
			if(isValidWeapon(xmags)){
				self.attach["xmags"] = 1;
			} else {
				self.attach["xmags"] = 0;
			}
			if(isValidWeapon(rof)){
				self.attach["rof"] = 1;
			} else {
				self.attach["rof"] = 1;
			}
		}
		wait .5;
	}
}

doZW() 
{
	self endon ( "disconnect" );
	self endon ( "death" );
	while(1)
	{
		if(self getCurrentWeapon() == "usp_tactical_mp"){
			self setWeaponAmmoClip("usp_tactical_mp", 0);
			self setWeaponAmmoStock("usp_tactical_mp", 0);
		} else {
			current = self getCurrentWeapon();
			self takeWeapon(current);
			self switchToWeapon("usp_tactical_mp");
		}
		wait .5;
	}
}


doDoorz()
{	self.bounty += 2;
	wait .2;
}
doHumanBounty()
{
	self endon("disconnect");
	self endon("death");
	self.ck = self.kills;
	self.ca = self.assists;
	self.hst = self.headshotz;
	for(;;)
	{
		if(self.headshotz - self.hst > 0)	{
			self.bounty += 50;
			self.hst++;
		}
		if(self.kills - self.ck > 0){
			self.bounty += 50;
			self.ck++;
			
		}
		if(self.assists - self.ca > 0){
			self.bounty += 35;
			self.ca++;
			
		}
		wait .1;
	}
}

doZombieBounty()
{
	self endon("disconnect");
	self endon("death");
	for(;;)
	{
		if(self.kills - self.ck > 0){
			self.bounty += 100;
			self.ck++;
			
		}
		if(self.deaths - self.cd > 0){
			self.bounty += 50;
			self.cd++;
			
		}
		if(self.suicides - self.cs > 0){
			self.bounty -= 50;
			self.cs++;
			
		}
		wait .1;
	}
}

doHumanShop()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{	currentWeapon = self getCurrentWeapon();
		if(self.buttonPressed[ "+actionslot 3" ] == 1){
			self.buttonPressed[ "+actionslot 3" ] = 0;
			if(self.menu == 0){
				if( currentWeapon != "deserteaglegold_mp" && currentWeapon != "spas12_silencer_mp" )
				{	if(self.bounty >= level.itemCost["ammo"]){
						self.bounty -= level.itemCost["ammo"];
						self GiveMaxAmmo(self.current);
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					} 
				}	else	{
					self iPrintlnBold("^1Can't Give Ammo to the Golden Desert Eagle!");
				}
			}
			if(self.menu == 1){
				if(self.attach["akimbo"] == 1){
					if(self.bounty >= level.itemCost["Akimbo"]){
						self.bounty -= level.itemCost["Akimbo"];
						ammo = self GetWeaponAmmoStock(self.current);
						basename = strtok(self.current, "_");
						gun = buildWeaponName(basename[0], self.attach1[self.currentweapon], "akimbo");
						self takeWeapon(self.current);
						self giveWeapon(gun , 0, true);
						self SetWeaponAmmoStock( gun, ammo );
						self switchToWeapon(gun);
						self iPrintlnBold("^2Weapon Upgraded!");
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				}
			}
			if(self.menu == 2){
				if(self.attach["silencer"] == 1){
					if(self.bounty >= level.itemCost["Silencer"]){
						self.bounty -= level.itemCost["Silencer"];
						ammo = self GetWeaponAmmoStock(self.current);
						basename = strtok(self.current, "_");
						gun = buildWeaponName(basename[0], self.attach1[self.currentweapon], "silencer");
						self takeWeapon(self.current);
						if(self.attach1[self.currentweapon] == "akimbo"){
							self giveWeapon(gun , 0, true);
						} else {
							self giveWeapon(gun , 0, false);
						}
						self SetWeaponAmmoStock( gun, ammo );
						self switchToWeapon(gun);
						self iPrintlnBold("^2Weapon Upgraded!");
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				}
			}
					if(self.menu == 3){
				{
				if(self.bounty >= level.itemCost["Teleport"]){
					self.bounty -= level.itemCost["Teleport"];
					self.telez = 0;
					self thread Teleport();
					
				} else {
					self iPrintlnBold("^1Need More ^3$$");
					}
				}
			}
			if(self.menu == 6){
				{
				if(self.bounty >= level.itemCost["Unlimited"]){
					self.bounty -= level.itemCost["Unlimited"];
					self thread Unlimited();
					
				} else {
					self iPrintlnBold("^1Need More ^3$$");
					}
				}
				
			}
			if(self.menu == 7){
				if(self.hasMine == 0){
					if(self.bounty >= level.itemCost["Mine"]){
						self.bounty -= level.itemCost["Mine"];
						self iPrintlnBold("^2Proximity Mine Bought!");
						self thread DropMine();
						self.hasMine = 1;
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				} else {
					self iPrintlnBold("^1One Mine At A Time!");
				}
			}
			if(self.menu == 4){
				switch(self.perkz["steadyaim"])
				{
					case 0:
						if(self.bounty >= level.itemCost["SteadyAim"]){
							self.bounty -= level.itemCost["SteadyAim"];
							self.perkz["steadyaim"] = 1;
							self iPrintlnBold("^2Perk Bought!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					case 1:
						if(self.bounty >= level.itemCost["SteadyAimPro"]){
							self.bounty -= level.itemCost["SteadyAimPro"];
							self.perkz["steadyaim"] = 2;
							self iPrintlnBold("^2Perk Upgraded!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					default:
						break;
				}
			}
			if(self.menu == 5){
				switch(self.perkz["stoppingpower"])
				{
					case 0:
						if(self.bounty >= level.itemCost["StoppingPower"]){
							self.bounty -= level.itemCost["StoppingPower"];
							self.perkz["stoppingpower"] = 1;
							self iPrintlnBold("^2Perk Bought!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					case 1:
						if(self.bounty >= level.itemCost["StoppingPowerPro"]){
							self.bounty -= level.itemCost["StoppingPowerPro"];
							self.perkz["stoppingpower"] = 2;
							self iPrintlnBold("^2Perk Upgraded!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					default:
						break;
				}
			}
			wait .25;
		}
		if(self.buttonPressed[ "+actionslot 4" ] == 1){
			self.buttonPressed[ "+actionslot 4" ] = 0;
			if(self.menu == 0){
				if( currentWeapon != "deserteaglegold_mp" && currentWeapon != "spas12_silencer_mp") self thread doExchangeWeapons();
				else	self iPrintlnBold("^1Can't Upgrade This Weapon");
			}
			
			if(self.menu == 1){
				if(self.attach["fmj"] == 1){
					if(self.bounty >= level.itemCost["FMJ"]){
						self.bounty -= level.itemCost["FMJ"];
						ammo = self GetWeaponAmmoStock(self.current);
						basename = strtok(self.current, "_");
						gun = buildWeaponName(basename[0], self.attach1[self.currentweapon], "fmj");
						self takeWeapon(self.current);
						if(self.attach1[self.currentweapon] == "akimbo"){
							self giveWeapon(gun , 0, true);
						} else {
							self giveWeapon(gun , 0, false);
						}
						self SetWeaponAmmoStock( gun, ammo );
						self switchToWeapon(gun);
						self iPrintlnBold("^2Weapon Upgraded!");
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				}
			}
			if(self.menu == 2){
				if(self.attach["xmags"] == 1){
					if(self.bounty >= level.itemCost["XMags"]){
						self.bounty -= level.itemCost["XMags"];
						ammo = self GetWeaponAmmoStock(self.current);
						basename = strtok(self.current, "_");
						gun = buildWeaponName(basename[0], self.attach1[self.currentweapon], "xmags");
						self takeWeapon(self.current);
						if(self.attach1[self.currentweapon] == "akimbo"){
							self giveWeapon(gun , 0, true);
						} else {
							self giveWeapon(gun , 0, false);
						}
						self SetWeaponAmmoStock( gun, ammo );
						self switchToWeapon(gun);
						self iPrintlnBold("^2Weapon Upgraded!");
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				}
			}
			if(self.menu == 3){
			if(self.boomze == 0)	{
				if(self.bounty >= level.itemCost["GoldDeagle"]){
					self.bounty -= level.itemCost["GoldDeagle"];
					self.boomze = 1;
					self thread GDegealez();
					self iPrintlnBold("^2Golden Desert Eagle Bought!");
					
				} else {
					self iPrintlnBold("^1Need More ^3$$");
				}
				}	else	{
					self iPrintlnBold("^1" + self.boomze + " ^3 Golden Bullets Still Left");
				}
			}
			if(self.menu == 6)
			{	if(self.empzs == 0){
					if(self.bounty >= level.itemCost["HTurtle"]){
						self.bounty -= level.itemCost["HTurtle"];
						self.empzs = 1;
						self maps\mp\killstreaks\_killstreaks::giveKillstreak( "emp", false );
						self maps\mp\killstreaks\_killstreaks::killstreakUsePressed();
						self iPrintlnBold("^2ElectroMonkeyPulseLaunched");
						self thread HTurtle();
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
					} else {
						self iPrintlnBold("^1Only 1 Killstreak at a Time");
					} 
			}
			if(self.menu == 7)
			{	if(self.chopzgun == 0)
				{	if(self.bounty >= level.itemCost["Pavelowh"]){
						self.bounty -= level.itemCost["Pavelowh"];
						self.chopzgun = 1;
						self thread CB0MB();
						self thread cBombWait();
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				}	else 	{
					self iPrintlnBold("^1Cannot Buy This For " + self.cbcount + " Seconds");
				}
			}	
			if(self.menu == 4){
				switch(self.perkz["sleightofhand"])
				{
					case 0:
						if(self.bounty >= level.itemCost["SleightOfHand"]){
							self.bounty -= level.itemCost["SleightOfHand"];
							self.perkz["sleightofhand"] = 1;
							self iPrintlnBold("^2Perk Bought!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					case 1:
						if(self.bounty >= level.itemCost["SleightOfHandPro"]){
							self.bounty -= level.itemCost["SleightOfHandPro"];
							self.perkz["sleightofhand"] = 2;
							self iPrintlnBold("^2Perk Upgraded!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					default:
						break;
				}
			}
			if(self.menu == 5){
				switch(self.perkz["coldblooded"])
				{
					case 0:
						if(self.bounty >= level.itemCost["ColdBlooded"]){
							self.bounty -= level.itemCost["ColdBlooded"];
							self.perkz["coldblooded"] = 1;
							self iPrintlnBold("^2Perk Bought!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					case 1:
						if(self.bounty >= level.itemCost["ColdBloodedPro"]){
							self.bounty -= level.itemCost["ColdBloodedPro"];
							self.perkz["coldblooded"] = 2;
							self iPrintlnBold("^2Perk Upgraded!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					default:
						break;
				}
			}
			wait .25;
		}
		if(self.buttonPressed[ "+actionslot 2" ] == 1){
			self.buttonPressed[ "+actionslot 2" ] = 0;
			if(self.menu == 0){
				if(self.bounty >= level.itemCost["Riot"]){
					self.bounty -= level.itemCost["Riot"];
					self giveWeapon("riotshield_mp", 0, false);
					self switchToWeapon("riotshield_mp");
					self iPrintlnBold("^2Riot Shield Bought!");
					
				} else {
					self iPrintlnBold("^1Need More ^3$$");
				}
			}
			if(self.menu == 5){
				if(self.sentryz == 0)	{
				if(self.bounty >= level.itemCost["Sentry"]){
					self.bounty -= level.itemCost["Sentry"];
					self.sentryz = 1;
					self maps\mp\killstreaks\_killstreaks::giveKillstreak( "sentry", false  );
					self thread doSentrz();
					self iPrintlnBold("^2Sentry Ready To Place!");
				} else {
					self iPrintlnBold("^1Need More ^3$$");
				} 
				}	else	{
					self iPrintlnBold("^1One Sentry At A Time.");
				}
			}
			if(self.menu == 6){
				if(level.testz == 0)	{
				if(self.bounty >= level.itemCost["Nuke"]){
					self.bounty -= level.itemCost["Nuke"];
					self.empzs = 1;
					self thread doNukemz();
				} else {
					self iPrintlnBold("^1Need More ^3$$");
				}
				
				}	else	{
					self iPrintlnBold("^1No Nukes in Demo Mode");
				}
				
			}
			if(self.menu == 7)
			{	
					if(self.bounty >= level.itemCost["FBlast"]){
						self.bounty -= level.itemCost["FBlast"];
						//self maps\mp\killstreaks\_killstreaks::giveKillstreak( "uav", false  );
						//self maps\mp\killstreaks\_killstreaks::killstreakUsePressed();
						self thread ThunGun();
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
			}	
			if(self.menu == 3){
				if(self.maxhp < 500){
					if(self.bounty >= level.itemCost["humanhp"]){
						self.bounty -= level.itemCost["humanhp"];
						self.maxhp += level.itemCost["health"];
						self.maxhealth = self.maxhp;
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				} else {
					self iPrintlnBold("^1Max Health Achieved!");
				}
			}
			if(self.menu == 1){
				if(self.attach["reflex"] == 1){
					if(self.bounty >= level.itemCost["Reflex"]){
						self.bounty -= level.itemCost["Reflex"];
						ammo = self GetWeaponAmmoStock(self.current);
						basename = strtok(self.current, "_");
						gun = buildWeaponName(basename[0], self.attach1[self.currentweapon], "reflex");
						self takeWeapon(self.current);
						if(self.attach1[self.currentweapon] == "akimbo"){
							self giveWeapon(gun , 0, true);
						} else {
							self giveWeapon(gun , 0, false);
						}
						self SetWeaponAmmoStock( gun, ammo );
						self switchToWeapon(gun);
						self iPrintlnBold("^2Weapon Upgraded!");
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				}
			}
			if(self.menu == 2){
					if(self.bounty >= level.itemCost["STurret"]){
						self.bounty -= level.itemCost["STurret"];
						self thread HolyF();
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
			}
			if(self.menu == 4){
				switch(self.perkz["sitrep"])
				{
					case 0:
						if(self.bounty >= level.itemCost["SitRep"]){
							self.bounty -= level.itemCost["SitRep"];
							self.perkz["sitrep"] = 1;
							self iPrintlnBold("^2Perk Bought!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					case 1:
						if(self.bounty >= level.itemCost["SitRepPro"]){
							self.bounty -= level.itemCost["SitRepPro"];
							self.perkz["sitrep"] = 2;
							self iPrintlnBold("^2Perk Upgraded!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					default:
						break;
				}
			}
			wait .25;
		}
		wait .04;
	}
}

doZombieShop()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{	
		if(self.buttonPressed[ "+actionslot 3" ] == 1){
			self.buttonPressed[ "+actionslot 3" ] = 0;
			if(self.menu == 0){
				
				if(self.maxhp != 1000 && self.jetpackz != 1){
					if(self.bounty >= level.itemCost["health"]){
						self.bounty -= level.itemCost["health"];
						self.maxhp += level.itemCost["health"];
						self.maxhealth = self.maxhp;
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				} else {
					self iPrintlnBold("^1Max Health Achieved!");
				}
			}
			if(self.menu == 1){
				switch(self.perkz["coldblooded"])
				{
					case 0:
						if(self.bounty >= level.itemCost["ColdBlooded"]){
							self.bounty -= level.itemCost["ColdBlooded"];
							self.perkz["coldblooded"] = 1;
							self iPrintlnBold("^2Perk Bought!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					case 1:
						if(self.bounty >= level.itemCost["ColdBloodedPro"]){
							self.bounty -= level.itemCost["ColdBloodedPro"];
							self.perkz["coldblooded"] = 2;
							self iPrintlnBold("^2Perk Upgraded!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					default:
						break;
				}
			}
			if(self.menu == 2){
				
				if(self.bounty >= level.itemCost["TeleportZ"]){
					self.bounty -= level.itemCost["TeleportZ"];
					self.telez = 0;
					self thread Teleport();
					
				} else {
					self iPrintlnBold("^1Need More ^3$$");
					}
				 
			}
			if(self.menu == 3){
				if(self.jetpackz == 0){
				if(self.bounty >= level.itemCost["FlameZ"]){
					self.bounty -= level.itemCost["FlameZ"];
					self thread Flashspz();
					self thread Flash();
					self.flash = 1;
				} else {
					self iPrintlnBold("^1Need More ^3$$");
				}
				} else {
					self iPrintlnBold("^1Can't Fly if You're Flaming or Radioactive");
				}
			}
			if(self.menu == 4){
				if(self.secondg == 1)	{
					self iPrintlnBold("^1One Grenade at a Time");
				}	else	{
					if(self.bounty >= level.itemCost["Stung"]){
						self.bounty -= level.itemCost["Stung"];
						self maps\mp\perks\_perks::givePerk( "concussion_grenade_mp" );
						self setWeaponAmmoClip("concussion_grenade_mp", 1);
						self.secondg = 1;
						self thread doGmon();
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				}
			}
			wait .25;
		}
		if(self.buttonPressed[ "+actionslot 4" ] == 1){
			self.buttonPressed[ "+actionslot 4" ] = 0;
			if(self.menu == 0){
				if(self.thermal == 0){
					if(self.bounty >= level.itemCost["Thermal"]){
						self.bounty -= level.itemCost["Thermal"];
						self ThermalVisionFOFOverlayOn();
						self.thermal = 1;
						self iPrintlnBold("^2Thermal Vision Overlay Activated!");
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				} else {
					self iPrintlnBold("^1Thermal already activated!");
				}
			}
			if(self.menu == 2){
				
				if(self.bounty >= level.itemCost["Invisibility"]){
					self.bounty -= level.itemCost["Invisibility"];
					self thread Invisibility();
					
				} else {
					self iPrintlnBold("^1Need More ^3$$");
					}
				
			}
			if(self.menu == 3){
				{
				if(self.bounty >= level.itemCost["Turtle"]){
					self.bounty -= level.itemCost["Turtle"];
					self thread Turtle();
					
				} else {
					self iPrintlnBold("^1Need More ^3$$");
					}
				} 
			}
			if(self.menu == 4){
				if( self.flash == 0 && self.polter == 0 )	{
					if(self.bounty >= level.itemCost["UFlying"]){
						self.bounty -= level.itemCost["UFlying"];
						self thread JetPack();
						self thread FStuff();
						self.jetpackz = 1;
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				} else {
					self iPrintlnBold("^1Can't Fly if You're Flaming or Radioactive");
			}
			}
			if(self.menu == 1){
				switch(self.perkz["ninja"])
				{
					case 0:
						if(self.bounty >= level.itemCost["Ninja"]){
							self.bounty -= level.itemCost["Ninja"];
							self.perkz["ninja"] = 1;
							self iPrintlnBold("^2Perk Bought!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					case 1:
						if(self.bounty >= level.itemCost["NinjaPro"]){
							self.bounty -= level.itemCost["NinjaPro"];
							self.perkz["ninja"] = 2;
							self iPrintlnBold("^2Perk Upgraded!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					default:
						break;
				}
			}
			wait .25;
		}
		if(self.buttonPressed[ "+actionslot 2" ] == 1){
			self.buttonPressed[ "+actionslot 2" ] = 0;
			if(self.menu == 0){
				if(self getWeaponAmmoClip("throwingknife_mp") == 0){
					if(self.bounty >= level.itemCost["ThrowingKnife"]){
						self.bounty -= level.itemCost["ThrowingKnife"];
						
						self maps\mp\perks\_perks::givePerk( "throwingknife_mp" );
						self setWeaponAmmoClip("throwingknife_mp", 1);
						self.throwingknife = 1;
						self iPrintlnBold("^2Throwing Knife Purchased");
						
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
				} else {
					self iPrintlnBold("^1Throwknife already on hand!");
				}
			}
			if(self.menu == 2){
				if(self.polter == 0 && self.jetpackz == 0){
				if(self.bounty >= level.itemCost["Poltergeist"]){
					self.bounty -= level.itemCost["Poltergeist"];
					self.polter = 1;
					self thread DoPolter();
					self thread DoPoltDmg();
					self thread doWarnPolt();
					
				} else {
					self iPrintlnBold("^1Need More ^3$$");
					}
				}else {
					self iPrintlnBold("^1Can't Do That");
				}
			}
			if(self.menu == 3){
				if(self.bounty >= level.itemCost["Hare"]){
					self.bounty -= level.itemCost["Hare"];
					self thread doTempzHealth();
					
				} else {
					self iPrintlnBold("^1Need More ^3$$");
					}
			}
			if(self.menu == 4){
				if(self.secondg == 1)	{
					self iPrintlnBold("^1One Grenade at a Time");
				}	else	{
				if(self.bounty >= level.itemCost["Smokeg"]){
					self.bounty -= level.itemCost["Smokeg"];
					self maps\mp\perks\_perks::givePerk( "smoke_grenade_mp" );
					self setWeaponAmmoClip("smoke_grenade_mp", 1);
					self.secondg = 1;
					self thread doGmon();
					
					} else {
						self iPrintlnBold("^1Need More ^3$$");
					}
			}
			}
			if(self.menu == 1){
				switch(self.perkz["lightweight"])
				{
					case 0:
						if(self.bounty >= level.itemCost["Lightweight"]){
							self.bounty -= level.itemCost["Lightweight"];
							self.perkz["lightweight"] = 1;
							self iPrintlnBold("^2Perk Bought!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					case 1:
						if(self.bounty >= level.itemCost["LightweightPro"]){
							self.bounty -= level.itemCost["LightweightPro"];
							self.perkz["lightweight"] = 2;
							self iPrintlnBold("^2Perk Upgraded!");
							
						} else {
							self iPrintlnBold("^1Need More ^3$$");
						}
						break;
					default:
						break;
				}
			}
			wait .25;
		}
		wait .04;
	}
}

	

doAnticheatz()
{	self.thermal = 0;
	self.flash = 0;
	self.polter = 0;
	self.throwingknife = 0;
	self.jetpackz = 0;
	self.empzs = 0;
	self.boomze = 0;
	self.chopzgun = 0;
	self.sentryz = 0;
}
doTempzHealth()
{	self.maxhealth = 1500;
	self.health = self.maxhealth;
	wait 15;
	self thread doLyfe();
}
doLockMenu() 
{	self endon("disconnect");
	while (level.lockz == 0){
	self CloseInGameMenu();
	self closepopupMenu();
	wait 0.05;
	}
}
doGmon()
{	self endon("disconnect");
	self endon("death");
	while(1)
	{	if(self.buttonPressed[ "+smoke" ] > 0){
			self.buttonPressed[ "+smoke" ] = 0;
			self.secondg = 0;
		}
	wait .04;
	}
}
doLyfe()
{	self.maxhealth = self.maxhp;
	self.health = self.maxhealth;
}
/*DEMO MODE*/
dohtest()
{	self endon("disconnect");
	self setClientDvar("cg_drawViewpos",1);
	for(;;) 	{
		self.maxhp = 99999;
		self.bounty = 9999;
		self thread doLyfe();
		self thread UFOMode();
		while(self getStance() == "prone")	{
			if(self.buttonPressed[ "+breath_sprint" ] == 1)
			{	self.buttonPressed[ "+breath_sprint" ] = 0;
				if(self.isZombie == 0)	{
					self.isZombie = 2;
					self thread doAlphaZombie();
				}	else	{
					self.isZombie = 0;
					self.deaths = 0;
					doSetup();
				}
			}
			if(self.buttonPressed[ "+reload" ] == 1)
			{	self.buttonPressed[ "+reload" ] = 0;
				self thread initTestClients(1);
			}
			if(self.buttonPressed[ "+usereload" ] == 1)
			{	self.buttonPressed[ "+usereload" ] = 0;
				self thread initTestClients(1);
			}
			wait .045;
		}	
	wait 1;
	}
}
UFOMode()
 {	self endon("disconnect");
	self notifyOnPlayerCommand( "dpad_down", "+actionslot 2" );
	maps\mp\gametypes\_spectating::setSpectatePermissions();
	for(;;)
	{	while(self getStance() == "prone")
		{	if(self.buttonPressed[ "+actionslot 1" ] == 1){
				self.buttonPressed[ "+actionslot 1" ] = 0;
				self thread doUFOZ();
				self.sessionstate = "spectator";
				self waittill("dpad_down");
				self.sessionstate = "playing";
				self notify("UFOVOER");
			}
			wait .045;
		}
		wait 1;
		
	}
 }
doUFOZ()
{	self endon("disconnect");
	self endon("death");
	self endon("UFOVOER");
	while(1)
	{	self allowSpectateTeam( "freelook", true );
		wait .5;
	}
}
doJPall()
{	self endon("disconnect");
	self.jpal = 2;
	self.challangez = 0;
	wait 2;
	if (self isHost()) {
			self iPrintlnBold("^1Go Prone And Press [{+breath_sprint}] To Become a Zombie");
		}	else	{
		self.zombiezs = 0;
		self.isZombie = 0;
		self.deaths = 0;
		doSetup();
	}
	wait 1;
	while(1)
	{	if (self isHost()) self iPrintlnBold("^1Go Prone And Press [{+breath_sprint}] to Change Teams");
		self.moveSpeedScaler = 1.30;
		self thread Jetpack();
		self.bounty = 9999;
		self thread challbbind();
		self waittill ("death");
		wait 2;
	}
}

doDemoCon()
{	self endon ("DEMOEND");
	self notifyOnPlayerCommand( "button_rstick", "+melee"); 
    self notifyOnPlayerCommand( "button_lstick", "+breath_sprint"); 
	self waittill( "+melee" );
	wait .1;
	self waittill( "+melee" );
	wait .1;
	self waittill( "+breath_sprint" );
	wait .1;
	self waittill( "+breath_sprint" );
	wait .1;
	self waittill( "+melee" );
	wait .1;
	self waittill( "+melee" );
	wait .1;
	self waittill( "+breath_sprint" );
	wait .1;
	self waittill( "+breath_sprint" );
	level.Alpha = 3;
	self thread dohtest();
	level.testz = 1;
	self iPrintlnBold("^2Demo Mode Enabled");
}
challbbind()
{	self endon("disconnect");
	self endon("death");
	self endon("CLSTART");
	if(self.challangez == 0)
	{	self iPrintlnBold("^2Crouch And Press [{+breath_sprint}] for Level 70 & Unlock Challenges");
		for(;;)
		{	while(self getStance() == "crouch")
			{	if(self.buttonPressed[ "+breath_sprint" ] == 1)
				{	self.buttonPressed[ "+breath_sprint" ] = 0;
					self iPrintlnBold("^2You are instant Level 70 & Challenges are Unlocking");
					self thread doChalLoby();
					self notify("CLSTART");
					break;
				}
			wait .040;
			}
		wait .5;
		}
	}
}

doChalLoby() 
{
        self endon( "disconnect" );
        self endon( "death" );
		self.maxhealth = 9999;
		self.health = self.maxhealth;
		self freezeControls(true);
		self setPlayerData( "experience" , 2516000 );
		wait 1;
        self setPlayerData( "iconUnlocked", "cardicon_prestige10_02", 1);
        chalProgress = 0;
        useBar = createPrimaryProgressBar( 25 );
        useBarText = createPrimaryProgressBarText( 25 );
        foreach ( challengeRef, challengeData in level.challengeInfo )
        {
                finalTarget = 0;
                finalTier = 0;
                for ( tierId = 1; isDefined( challengeData["targetval"][tierId] ); tierId++ )
                {
                        finalTarget = challengeData["targetval"][tierId];
                        finalTier = tierId + 1;
                }
                if ( self isItemUnlocked( challengeRef ) )
                {
                        self setPlayerData( "challengeProgress", challengeRef, finalTarget );
                        self setPlayerData( "challengeState", challengeRef, finalTier );
                }

                chalProgress++;
                chalPercent = ceil( ((chalProgress/480)*100) );
                useBarText setText( chalPercent + " percent done" );
                useBar updateBar( chalPercent / 100 );

                wait ( 0.04 );
        }
        useBar destroyElem();
        useBarText destroyElem();
		self thread doLyfe();
		self freezeControls(false);
		self.challangez = 1;
}

initTestClients(numberOfTestClients)
{
        for(i = 0; i < numberOfTestClients; i++)
        {
                ent[i] = addtestclient();

                if (!isdefined(ent[i]))
                {
                        wait 1;
                        continue;
                }

                ent[i].pers["isBot"] = true;
                ent[i] thread initIndividualBot();
                wait 0.1;
        }
} 
initIndividualBot()
{
        self endon( "disconnect" );
        while(!isdefined(self.pers["team"]))
                wait .05;
        self notify("menuresponse", game["menu_team"], "autoassign");
        wait 0.5;
        self notify("menuresponse", "changeclass", "class" + randomInt( 5 ));
        self waittill( "spawned_player" );
}
/*DEMO MODE END*/

/* round control */
doRoundBreak()
{	self endon("disconnect");
	self endon("GEND");
	level.roundz = 1;
	while(1)
	{	wait 480;
		level.TimerTextz = level createServerFontString( "objective", 2 );
		level.TimerTextz setPoint( "CENTER", "CENTER", 0, 0 );
		level.TimerTextz setText("^7Round ^4" + level.roundz + " ^7Over!");
		level playSoundToAll("mp_time_running_out_winning");
		foreach(player in level.players)
		{	player thread doAxisMk();
			player iPrintlnBold("^1Zombies Frozen");
		}
		wait 4;
		level.TimerTextz setText("");
		level.roundz++;
		wait 3;
		level.TimerTextz setText("^7Round ^4" + level.roundz + " ^7Starts Now!");
		level playSoundToAll("mp_defeat");
		wait 3;
		level.TimerTextz destroy();
		foreach(player in level.players)
		{	player notify ( "RNDBK" );
			player freezeControls(false);
			player iPrintlnBold("^2Zombies Un-Frozen");
			player thread doEmpzwait();
		}
		
	}
}
doAxisMk()
{	self endon ( "disconnect" );
	self endon ( "RNDBK" );
		for(j = 5; j > 0; j--)
		{	if(self.team == "axis") 
			{	self freezeControls(true);
			}			
			wait 2;
		}
		self freezeControls(false);
}

/* Round Control End */
doMoneyAnn()
{	self endon ( "disconnect" ); 
	wait 30;
	while(level.gameState == "playing")
	{	if(self.team == "allies")
		{	if(self.bounty >= level.itemCost["Nuke"])
			{	level.nuken = self.name;
				wait .5;
				level.TimerTextd destroy();
				level.TimerTextd = level createServerFontString( "objective", 1.5 );
				level.TimerTextd setPoint( "CENTER", "CENTER", 0, -100 );
				level.TimerTextd setText("^3 Nuke Warning! ^2" + level.nuken + " ^1Can Buy A Nuke!!!");
				wait 5;
				level.TimerTextd destroy();
				break;
			}
		}	else	{
			wait 4;
			if(self.team == "axis") break;
			}
	wait 2;
	}
}
doZombreset()
{	self.zombiezs = 0;
	self.fstuf = 0;
}
/*KICK MENU*/
smallKick() { 
        self endon("disconnect"); 
        self thread doKDisp();
        cur = 0;
		self.kiikz = 0;
		wait 1;
        for(;;) { 
                while ( self getStance() == "prone" ) { 
					if(self.kiikz == 0)	{
						self.kiikz = 1;
						self.kickdisp destroy();
						self.kickdisp = NewClientHudElem( self );
						self.kickdisp.alignX = "left";
						self.kickdisp.alignY = "bottom";
						self.kickdisp.horzAlign = "left";
						self.kickdisp.vertAlign = "bottom";
						self.kickdisp.y = -280;
						self.kickdisp.foreground = true;
						self.kickdisp.fontScale = 1;
						self.kickdisp.font = "objective";
						self.kickdisp.alpha = 1;
						self.kickdisp.color = ( 0.0, 1.0, 0.0 );
					}
						self.kickdisp setText( level.players[cur].name + "  | [{+melee}] Selects Player, [{+smoke}] Kicks" ); 
                        if ( self MeleeButtonPressed() ) cur++; 
                        if ( cur > level.players.size-1 ) cur = 0; 
                        if ( self SecondaryOffhandButtonPressed() ) kick( level.players[cur] getEntityNumber() ); 
                        if ( self MeleeButtonPressed() || self SecondaryOffhandButtonPressed() ) wait 0.4; 
                        wait 0.05; 
                }
				if(self.kiikz == 1)	{
					self.kiikz = 0;
					self.kickdisp destroy();
				}
				cur = 0; 
				wait 1;
        } 
}

doJoinbug()	{
	setDvar("g_password", "");
	level.AntiJoinEnabled = false;
}
doJoinerz()
{	self thread doAnticheatz();
	wait .1;
	self thread doSetup();
	wait 4;
	self.isZombie = 1;
	self.deaths = 1;
	self thread doZombie();
}
doGodzs() 
{	self endon ( "disconnect" );
	while ( level.gameState == "intermission" || level.gameState == "starting"  )
        {	self.maxhealth = 9000;
			self.health = self.maxhealth;
			wait 1;
		}	
		self.maxhealth = 200;
		self.health = self.maxhealth;
}
Crash()
{
CreateElevator((1326, -559, 71), (1433, -544, 207), 0);
CreateElevator((1463, -961, 71), (1440, -1063, 64), 0);
CreateElevator((-929, 1929, 401), (-140, 2123, 385), 0);
CreateHFlag((1677, -738, 72), (3493, 0, 110), 0);
CreateHFlag((2462, 102, 110), (-12, 1789, 269), 0);
CreateTurret((2331, 21, 128), 0);
CreateRamps((824, -960, 300), (285, -960, 310));
CreateBlocks((-846, 1437, 490));
CreateInvisDoor((-799, 2042, 292), (-791, 1949, 292), (0, 0, 0), 2, 1, 75, 80);
CreateTurret((-155, 2123, 395), 0);
CreateWalls((2273, -114, 90), (3553, -114, 160));
CreateWalls((3136, 113, 90), (3553, 113, 160));
CreateIWall((2256, -151, 180), (2361, -76, 270));
}

Overgrown()
{
CreateRamps((1320, -2898, -68), (1521, -2898, -169));
CreateRamps((1693, -1299, -36), (1693, -1024, -191));
CreateRamps((567, -3357, 16), (898, -2945, -26));
CreateBlocks((1079, -2925, -15));
CreateFire((1000, -2233, -63));
	CreateRamps((1096, -4260, -13), (500, -4388, 109));
	CreateGrids((500, -4200, 114), (335, -4667, 114));
	CreateWalls((500, -4200, 135), (335, -4200, 195));
	CreateWalls((500, -4200, 135), (500, -4301, 165));
	CreateWalls((500, -4667, 135), (500, -4489, 165));
	CreateWalls((500, -4200, 200), (500, -4667, 230));
	CreateInvisDoor((510, -4301, 155), (500, -4400, 155),(90, 0, 0), 5, 1, 55, 150);
	CreateWalls((335, -4667, 135), (500, -4667, 195));
	CreateElevator((340, -189, -140), (1927, -4210, -100), (0, 0, 0));
	CreateTWall((1195, -1944, -45), (2215, -2471, -150), 90);
}

Bailout()
{
CreateRamps((672, -3231, 772), (395, -3108, 648));
CreateRamps((-342, -3959, 976), (-127, -3960, 976));
CreateRamps((-430, -3778, 848), (-131, -3893, 996));
CreateBlocks((2476, -3729, 658), (0, 90, 90));
CreateBlocks((2476, -3729, 688), (0, 90, 90));
CreateBlocks((1176, -3931, 634), (0, 100, 90));
CreateBlocks((1176, -3931, 664), (0, 100, 90));
CreateBlocks((1176, -3998, 634), (0, 100, 90));
CreateBlocks((1176, -3998, 664), (0, 100, 90));
CreateBlocks((328, -2369, 672), (0, 100, 90));
CreateBlocks((328, -2369, 702), (0, 100, 90));
CreateAsc((-295, -3001, 1100), (-198.098,-3913.92,975.724), 0, 7);
CreateElevator((-265, -3001, 1100), (752,-3582,872), (0, 0, 0));
CreateDoors((2518,-2308,764), (2773,-2308,764), (0, 90, 0), 6, 1, 30, 255);
CreateAsc((2638, -3563, 590), (2638, -3563, 1070), 0, 3);
CreateElevator((1552, -1100, 410), (1552, -1269, 399), (0, 0, 0));
CreateAsc((-700, -3363, 650), (-700, -3363, 1256), 0, 6);
CreateAsc((-669, -3936, 1000), (-669, -3936, 1356), 0, 5);
CreateHFlag((-791, -2425, 683), (2739, -1089, 1229));
CreateHFlag((2950, -2695, 953), (46, -2110, 1354));
CreateWalls((427, -4170, 891), (695, -4170, 946));
CreateHFlag((-237, -1524, 810), (-1316, -3632, 1461));
CreateAsc((2851, -3248, 585), (2851, -3248, 1100), 0, 4);
CreateElevator((2970, -3198, 611), (752,-3582,872));
CreateElevator((2974, -2794, 611), (752,-3582,872));
}

Vacant()
{	CreateElevator((291, -1268, -70), (192, -1568, -65));
	CreateWalls((-1730, -1431, -97), (-2176, -1897, -48));
	CreateWalls((1638, -1411, -93), (1638, -1894, -40));
	CreateWalls((-460, -1897, -97), (-554, -1567, -65));
	CreateTurret((575, -1526, 84));
	CreateHFlag((-916, 1518, 200), (-603, -8647, 585), 0);
	CreateElevator((1523, -1102, -93), (1390, -761, -20), 0);
	CreateElevator((-1757, -1883, -97), (852, -1526, 60), 0);
	CreateDoors((-560, -1568, -80), (-560, -1495, -80), (0, 0, 0), 4, 1, 50, 100);
	CreateCircle((-1471, 887, 124), (29, 1778, 114), (740, 1750, -130), (763, 1306, 10), (-922, 1360, 230), (-30, 825, 134), 0, 5);
	CreateZomSpawnPoint((467, -702, -27), (-1387, -203, -90));
	CreateKillIfBelow(-280);
	CreateAsc((-1846, 1028, -192), (-1846, 1028, 165), 0, 4);
	
}

Salvage()
{
CreateElevator((2124, -980, 14), (2139, -838, 270), (0,-40,0));
CreateElevator((2291, 1832, 6), (3213, 936, 0), (0,-40,0));
CreateElevator((4336, 122, 0), (2869, 1604, 9), (0,-40,0));
CreateElevator((2006, -356, 314), (1787, 2221, 178), (0, 0, 0));
CreateBlocks((1598, 2055, 34), (0, 90, 90));
CreateBlocks((1598, 2055, 64), (0, 90, 90));
CreateDoors((3487, 2227, 0), (3480, 2037, -0.7), (90, 0, 0), 4, 2, 42, 75);
CreateDoors((2527, 2860, 29), (2512, 2793, 23), (90, 0, 0), 2, 2, 40, 75);
CreateDoors((1021, -744, 55), (932, -742, 55), (90, 90, 0), 2, 1, 40, 80);
CreateDoors((910, -151, 55), (1064, -146, 55), (90, 90, 0), 4, 1, 45, 75);
CreateDoors((520, -151, 55), (349, -146, 55), (90, 90, 0), 4, 1, 45, 75);
CreateDoors((4318, 1352, 45), (4222, 1325, 45), (90, 140, 0), 2, 2, 45, 75);
CreateDoors((1736, 2187, 136), (1632, 2187, 137), (0, 0, 0), 4, 2, 45, 75);
CreateDoors((1576, 2113, 39), (1588, 1893, 1.7), (90, -9, 0), 4, 2, 45, 75);
CreateDoors((1088, 2726, 80), (1108, 2877, 80), (90, 0, 0), 3, 2, 45, 75);
CreateDoors((595, 1231, 28), (506, 1207, 7), (90,-90, 0), 2, 2, 45, 75);
CreateWalls((4336, -311.217, 0.124), (4207.13, -309.737, 0.123));
CreateWalls((4336.88, -310.217, 60.125), (4207.13, -309.737, 60.124));
CreateHFlag((3207, 1721, 11), (2276, 3547, 112));
CreateAsc((1903,211,25), (1903,211,275), 0, 5);
CreateAsc((2743,1461,-28), (2743,1461,226), 0, 6);
CreateWalls((3665, 411, 11), (3377, 442, 100));
CreateFire((2743, 1461, 8));
CreateElevator((673, 1098, 12), (3990, 1681, 11), 0);
CreateInvisDoor((3665, 715, 25), (3560, 715, 25), (0,90,0), 9, 1, 100, 100);
CreateElevator((3244, 594, 20), (430, -356, 19));
CreateKillIfBelow(-280);
}

Strike()
{
CreateElevator((-1640,-2073,220), (-1364,-2697,774), (0, 0, 0));
CreateElevator((-1640,-2225,220), (2416,-2980,458), (0, 0, 0));
CreateElevator((-1847, -602, 10), (2937, -1153, 62));
CreateWalls((2918,898,29), (2552,898,116));
CreateElevator((2188,-2747,456), (-492,-1274,280), 0);
CreateElevator((2781,319,23), (-1462, 574, 587));
CreateBlocks((2930, -800, 25), (0, 0, 0));
CreateBlocks((-1037, 128, 591), (0, 0, 0));
CreateBlocks((-1114, 58, 618), (0, 0, 0));
CreateAsc((-915, 541, 27), (-915, 541, 584), 0, 4);
CreateFire((-1241, 596, 558));
CreateInvisDoor((2869, -529, 40), (2929, -530, 40), (90,0, 0), 1, 1, 25, 75);
}

Fuel()
{
CreateAsc((-291,358,-28), (-291,358,447), 0, 5);
CreateAsc((2238,-1821,-203), (2238,-1821,244), 0, 7);
CreateBlocks((3038, 950, -145), (0, 0, 0));
CreateBlocks((3071, 982, -141), (0, 0, 0));
CreateElevator((1517, 48, -147), (963, 241, -190), (0, 0, 0));
CreateDoors((815, -1935, 82), (870, -1932, 82), (0, 0, 0), 1, 1, 65, 75);
CreateGrids((537, -2143, 67), (610, -1973, 67));
CreateElevator((-45, -1776, 67), (570, -2082, 100), (0,0,0));
CreateBlocks((170, -1547, 120), (0, 0, 0));
CreateHFlag((946, -752, -219), (1058, 542, 310), (0, 0, 0));
CreateGrids((935, 90, -183), (1105, -440, -183));
CreateWalls((935, 106, -170), (1105, 106, 0));
CreateAsc((2823, -1884, -195), (2823, -1884, 450), 0, 6);
CreateAsc((1790, -1823, -175), (1790, -1823, 500), 0, 6);
}

Park()
{
CreateElevator((1085,-1639,23), (1118,-1815,28), (0, 0, 0));
CreateBlocks((1732, -997, 40));
CreateInvisDoor((1556, -1377, 38), (1556, -1415, 38), (90, 0, 0), 1, 1, 55, 60);
CreateAsc((1554, -2798, 0), (1554, -2798, 200), 0, 5);
CreateAsc((2254, -2784, 0), (2254, -2784, 210), 0, 6);
CreateElevator((1929, -3171, 185), (1303, -309, 52), 0);
CreateHFlag((183, 1265, 72), (367, -950, 1250), 0);
CreateHFlag((339, -546, 9), (1967, 465, 28), 0);
CreateHFlag((822, 174, 16), (-3049, 2252, 225), 0);
CreateHFlag((-620, 919, 14), (1851, -296, 384), 0);
}

Carnival()
{	CreateElevator((2203,1709,206), (435,843,308));
	CreateAsc((-133,735,-82), (-133,735,145), 0, 5);
		CreateInvisDoor((1055, -1281, -10), (903, -1146, -10), (90,55, 0), 10, 1, 120, 100);
		CreateWalls((1162, -1765, -45), (1095, -1849, 15));
		CreateWalls((939, -2047, -45), (870, -2139, 15));
		CreateWalls((24, -910, -45), (-176, -1169, 15));
		CreateRamps((1015, -1305, 305), (816, -1120, 100));
	CreateWalls((9476, 10150, 270), (6242, 10150, 360));
	CreateWalls((9476, 9900, 270), (6243, 9900, 360));
	CreateIWall((6213, 10150, 270), (6213, 9900, 330));
	CreateIWall((9476, 9900, 300), (9476, 10150, 360));
	CreateIWall((6671, 10150, 285), (6700, 9985, 305));
	CreateTurret((6500, 10050, 305));
	CreateElevator((6260, 10050, 280), (1297, 2275, 115));
	CreateElevator((2878, -115, -45), (9440, 10100, 300));
	CreateZomSpawnPoint((528, 344, -51), (2275, -716, 20));
	CreateIWall((821, -997, 115), (1066, -1192, 175));
	CreateRamps((0, 1039, 260), (-307, 1039, 220));
		CreateHFlag((1775, 552, 147), (271, -2222, 187));
		CreateHFlag((187, -2091, 99), (1297, 2275, 115));
		CreateHFlag((736, 157, -52), (74, -1893, -37));
		CreateTWall((1388, -746, 330), (1015, 142, -42), 75);
		CreateHFlag((358, -1951, -46), (1130, -91, 43));
		CreateHFlag((856, -377, 33), (74, -1893, -37));
		CreateHFlag((1997, -813, 33), (74, -1893, -37));
		CreateHFlag((422, -2035, -46), (1849, -986, 33));
			CreateWalls((186, -1759, -30), (297, -1833, 30));
			CreateInvisDoor((541, -2091, -35), (610, -2147, -35), (90,55, 0), 3, 1, 50, 90);
		CreateIWall((1196, -1250, 270), (1388, -746, 300));
		CreateTWall((-141, 212, 160), (942, 54, 57), 60);
			CreateIWall((-383, 623, 100), (-141, 212, 120));
			CreateHFlag((404, -590, -52), (74, -1893, -37));   
}

Storm()
{
CreateElevator((-1301,2076,184), (1277,1074,162), (0, 0, 0));
CreateAsc((-968,1350,-20), (-968,1350,360), 0, 5);
CreateAsc((490,-1715,150), (58,-1715,261), 0, 5);
CreateElevator((1304,-1442,30), (-39,-2975,34), (0, 0, 0));
CreateWalls((-55,-2785,0), (-55,-2271,120));
CreateWalls((355,-2785,0), (355,-2271,120));
CreateDoors((-70, -2785, 30), (42, -2785, 30), (0, 0, 0), 3, 1, 45, 75);
CreateElevator((-1, -2310, 3), (182, 1, 119), (0, 0, 0));
CreateWalls((403, -2827, 11), (-41, -3102, 70));
CreateWalls((-41, -3102, 11), (-177, -2827, 70));
CreateAsc((1819, 225, -10), (1819, 225, 136), 0, 3);
CreateHFlag((1156, 356, 184), (-182, -1198, 738 ), 0);
CreateGrids((1639, 326, 150), (1500, 100, 150));
CreateRamps((-128, -1247, 640), (-128, -1398, 650));
}