#include common_scripts\utility;
#include hawkins\maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include hawkins\maps\mp\qczm\HumansZombiesSetup;
#include hawkins\maps\mp\killstreaks\_ac130;

init()
{	level.spawnz = 0;
	level.doCustomMap = 0;
	level.doorwait = 2;
	level.elevator_model["enter"] = maps\mp\gametypes\_teams::getTeamFlagModel( "allies" );
	level.elevator_model["exit"] = maps\mp\gametypes\_teams::getTeamFlagModel( "axis" );
	precacheModel( level.elevator_model["enter"] );
	precacheModel( level.elevator_model["exit"] );
	wait 1;
	if(getDvar("mapname") == "mp_afghan"){ /** Afghan **/
		level thread Afghan();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_boneyard"){ /** Scrapyard **/
		level thread Scrapyard();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_brecourt"){ /** Wasteland **/
		level thread Wasteland();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_checkpoint"){ /** Karachi **/
		level thread Karachi();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_derail"){ /** Derail **/
		level thread Derail();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_estate"){ /** Estate **/
		level thread Estate();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_favela"){ /** Favela **/
		level thread Favela();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_highrise"){ /** HighRise **/
		level thread HighRise();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_nightshift"){ /** Skidrow **/
		level thread Skidrow();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_invasion"){ /** Invasion **/
		level thread Invasion();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_quarry"){ /** Quarry **/
		level thread Quarry();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_rundown"){ /** Rundown **/
		level thread Rundown();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_rust"){ /** Rust **/
		level thread Rust();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_subbase"){ /** SubBase **/
		level thread SubBase();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_terminal"){ /** Terminal **/
		level thread Terminal();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_underpass"){ /** Underpass **/
		level thread Underpass();
		level.doCustomMap = 1;
	}
		if(getDvar("mapname") == "mp_overgrown"){ /** Overgrown **/
		level thread Overgrown();
		level.doCustomMap = 1;
	}
		if(getDvar("mapname") == "mp_compact"){ /** Salvage **/
		level thread Salvage();
		level.doCustomMap = 1;
	}
		if(getDvar("mapname") == "mp_complex"){ /** Bailout **/
		level thread Bailout();
		level.doCustomMap = 1;
	}
		if(getDvar("mapname") == "mp_crash"){ /** Crash **/
		level thread Crash();
		level.doCustomMap = 1;
	}
		if(getDvar("mapname") == "mp_storm"){ /** Storm **/
		level thread Storm();
		level.doCustomMap = 1;
	}
		if(getDvar("mapname") == "mp_strike"){ /** Strike **/
		level thread Strike();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_vacant"){ /** Vacant **/
		level thread Vacant();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_fuel2"){ /** Fuel **/
		level thread Fuel();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_trailerpark"){ /** Trailer Park **/
		level thread Park();
		level.doCustomMap = 1;
	}
	if(getDvar("mapname") == "mp_abandon"){ /** Carnival **/
		level thread Carnival();
		level.doCustomMap = 1;
	}
	if(level.doCustomMap == 1){
		level.gameState = "starting";
		level thread CreateMapWait();
	} else {
		level.gameState = "starting";
		wait 15;
		level notify("CREATED");
	}
}

Afghan()
{
	CreateAsc((1060.82,1173.72,141.214), (940.837,1481.67,466.945), 0, 5);
	CreateElevator((915, 1475, 480), (899, 1627, 800), (0,0,0));
    CreateElevator((952, 1831, 760), (944, 1824, 1307), (0,0,0));
	CreateElevator((2145, 1492, 1307), (3742, 4977, 501), (0,0,0));
	CreateRamps((745, 1608, 1300), (745, 1795, 1407));
	CreateDoors((565, 1540, 1344), (653, 1540, 1344), (90, 90, 0), 3, 1, 55, 60);
	CreateGrids((695, 1795, 1407), (533, 1540, 1407), (0, 0, 0));
	CreateWalls((533, 1795, 1307), (773, 1795, 1440));
	CreateWalls((790, 1795, 1307), (790, 1540, 1440));
	CreateWalls((515, 1540, 1307), (515, 1795, 1440));
	CreateWalls((773, 1540, 1307), (715, 1540, 1407));
	CreateWalls((590, 1540, 1307), (533, 1540, 1407));
	CreateRamps((585, 1495, 1407), (907, 495, 1707));
	CreateRamps((900, 1609, 760), (952, 1831, 760));
	CreateElevator((3159, 4483, 630), (1594, 3385, 930));
	CreateElevator((1308, 1580, 80), (899, 1627, 800));
	CreateHFlag((5997, 6286, 115), (9127, 3496, 135));
	CreateHFlag((9253, 2755, 105), (8492, -233, 0));
	CreateRamps((645, 1309, 1445), (826, 1309, 1460));
	CreateWalls((2400, -121, 152), (2400, -10, 190));
	CreateBlocks((2411, -146, 132), 0);
	CreateInvisDoor((1612, -91, 160), (1612, -167, 160), (0, 0, 0), 2, 1, 55, 85);
	CreateElevator((2017, -270 , 147), (-1303, 990, 125));
	CreateTurret((1961, -9, 175), 0);
}

Derail()
{
		CreateElevator((-110, 2398, 124), (-125, 2263, 333), (0, 270, 0));
        CreateRamps((-124, 2002, 437), (-124, 2189, 332));
		CreateWalls((937, -4025, 131), (995, -5536, 191));
		CreateWalls((593, -5536, 131), (625, -3981, 191));
		CreateIWall((937, -4025, 191), (995, -5536, 310));
		CreateIWall((593, -5536, 191), (625, -3981, 310));
		CreateBlocks((700, -4475, 130), (0, 0, 0));
		CreateWalls((569, -4520, 130), (978, -4520, 178));
		CreateWalls((960, -5052, 130), (623, -5126, 160));
		CreateElevator((177, 505, 617), (95, -2598, 340));
		CreateElevator((1002, -3660, 119), (788, -3860, 188));
		CreateElevator((944, -6079, 140), (95, -2598, 340));
		CreateDoors((780, -5621, 114), (946, -5621, 114), (0, 0, 90), 4, 4, 70, 150);
		CreateElevator((1182, 2878, 140), (538, -3273, 127));
		CreateElevator((538, -2973, 127), (1182, 2978, 150));
		CreateBlocks((896, -4551, 130), (0, 0, 0));
		CreateGrids((720, -5203, 240), (935, -5291, 240), 0);
		CreateElevator((759, -6079, 140), (839, -5274, 275));
			CreateHFlag((-2399, 390, 60), (700, 4717, 340));
			CreateHFlag((3020, -2101, 70), (77, 3997, 157), (0, 180, 0));
			CreateHFlag((-141, 4402, 175), (77, 3997, 157));
			CreateElevator((-619, 4440, 335), (264, 2904, 195));
			CreateRamps((-458, 4381, 311), (-458, 4034, 130));
			CreateIWall((-85, 3947, 170), (-85, 4357, 200));
			CreateBlocks((-45, 4347, 130), 0);
			CreateFire((-461, 4017, 150));
			//CreateFire((-129, 1966, 453));
			CreateTWall((400, 5800, 450), (788, -3860, 188), 900);
			CreateTWall((700, 5800, 450), (788, -3860, 188), 900);
}

Estate()
{
CreateElevator((665, 921, 490), (159, 378, 539), (0, 0, 0));
CreateElevator((132, 795, 920), (-1284, 1504, 920), (0, 0, 0));
        CreateBlocks((-371, 919, 245), (0, 100, 90));
        CreateBlocks((-383, 991, 245), (0, 100, 90));
        CreateBlocks((-349, 1115, 245), (0, 50, 90));
        CreateBlocks((-302, 1166, 245), (0, 50, 90));
        CreateBlocks((-55, 1231, 245), (0, -20, 90));
        CreateBlocks((8, 1217, 245), (0, -20, 90));
        CreateBlocks((102, 1188, 245), (0, -20, 90));
        CreateBlocks((162, 1168, 245), (0, -20, 90));
        CreateBlocks((1333, -92, 210), (0, 0, 90));
        CreateBlocks((-336, 739, 705), (0, 100, 90));
        CreateRamps((-344, 768, 710), (-214, 1252, 920));
        CreateGrids((-171, 1266, 920), (106, 830, 920), (0, 0, 0));
        CreateBlocks((-216, 1279, 920), (0, 0, 0));
        CreateDoors((-320, 1002, 840), (-260, 1002, 840), (0, -15, 90), 6, 2, 40, 75);
        CreateDoors((-300, 1148, 910), (-240, 1148, 910), (0, -15, 90), 6, 2, 40, 100);
        CreateElevator((-1230, 1193, -390), (-1543, 3205, 970), (0, -152, 0));
        CreateElevator((-675, 2037, -105), (1181, 2762 ,970), (0, 0, 0));
        CreateRamps((-3500, 3217, 260), (-3122, 3131, -115));
        CreateBlocks((-430, 1026, 940), (0, 100, 90));
        CreateBlocks((-430, 1075, 965), (0, 100, 90));
        CreateElevator((127, 627, 329), (384, 546, 465), (0, 0, 0));
        CreateRamps((-325, 721, 700), (-42, 729, 649));
        CreateRamps((15, 742, 649), (65, 928, 630));
        CreateBlocks((-3213, 1132, -156), (0, 90, 90));
        CreateBlocks((-3213, 1082, -156), (0, 90, 90));
        CreateBlocks((-3213, 1007, -156), (0, 90, 90));
        CreateElevator((-4469, 2689, -289), (1197, 3957, 157), (0, 0, 0));
        CreateElevator((669, 929, 563), (828, 822, 330), (0, 0, 0));
        CreateRamps((-506.143, 1053.75, 976.286), (-403.282, 649.006, 729.349));
        CreateRamps((-403.282, 649.006, 729.349), (5, 540.669, 729.349));
        CreateHFlag((-1923, 3851, 235), (-5, 544, 770), (0, -76, 0));
        CreateBlocks((-1923.3, 3851.14, 220.149), (0, 90, 90));
        CreateAsc((455,813,650), (155,813,920), 0, 5);
}

Favela()
{
CreateWalls((2445, 3065, 280), (2583, 2863, 310));
CreateWalls((2445, 3065, 340), (2583, 2863, 370));
CreateWalls((2130, 2613, 280), (2081, 2712, 310));
CreateWalls((2130, 2613, 340), (2081, 2712, 370));
CreateElevator((880, 2254, 282), (1177, 2402 ,281), (0, 0, 0));
CreateElevator((2404, 2992, 280), (10555.5, 18403.8, 13635.1), (0, 177.408, 0));
CreateInvisDoor((2081, 2712, 300), (2028, 2780, 300), (90,90, 55), 3, 2, 55, 100);
        CreateBlocks((9967.6, 18352.8, 13633.5), (90, 90, 90));
        CreateAsc((10010.5,18404.3,13635.1), (10047.6,18425,13864.9), 0, 5);
		CreateElevator((9386, 18434, 13645), (431, 2040, 1528));
        CreateBlocks((-2315.64, 5495, 350), (90, 90, 90));
        CreateBlocks((-2231.83, 737.505, 110), (90, 90, 90));
CreateElevator((496, 175, 5), (215.916, 2228.5, 281.523)); 
        CreateBlocks((10592.2, 18406, 13675), (90, 90, 90));
        CreateBlocks((10558, 18452, 13675), (90, 90, 90));
        CreateBlocks((10558, 18353.4, 13675), (90, 90, 90));
CreateElevator((2484, 2792, 280), (-184, -715, 72));
CreateTWall((10010,18404,9000), (-1450, 2658, 590), 4000);
		CreateHFlag((-2315, 5404, 307), (591, 1285, 384));
		CreateHFlag((474, 887, 355), (431, 2000, 1528));
	CreateInvisDoor((1481, 913, 220), (1483, 967, 220), (90,90,0), 1, 1, 30, 90);
	CreateHFlag((427, 1238, 459), (1617, 855, 211));
	CreateHFlag((1567, 1085, 211), (431, 2040, 1528));
	CreateInvisDoor((-1530, -591, 75), (-1440, -591, 90), (0,0,0), 1, 1, 30, 100);
		CreateIWall((-1623, -276, 65), (-1708, -515, 125));
		CreateIWall((-1708, -515, 125), (-1529, -585, 65));
		CreateIWall((-1529, -585, 125), (-1351, -926, 5));
		CreateElevator((-1244, -560, 18), (-1255, -669, 13));
		CreateRamps((-1452, -600, 55), (-1423, -765, 0));
	CreateElevator((-1639, -412, 51), (-746, -1735, 50));
	CreateElevator((-410, -1211, 65), (-515, 644, 459));
	CreateFire((-741, -1246, 59));
	CreateIWall((-757, -1576, 68), (-387, -1576, 98));
	CreateIWall((-380, -1374, 80), (-621, -1380, 110));
	CreateIWall((-621, -1380, 110), (-661, -1182, 80));
	CreateIWall((-617, -1785, 120), (-219, -1798, 90));
		CreateElevator((-938, 3145, 295), (-1011, 2967, 300)); 
		CreateIBlock((-836, -1032, 163), (0,90,0));
		CreateBlocks((-332, -1153, 163), (0,90,0));
		CreateIBlock((-836, -1032, 133), (0,90,0));
		CreateBlocks((-302, -1153, 163), (0,90,0));
		CreateTWall((-979, -1244, 220), (-515, 644, 459), 120);
}
HighRise() 
{ 		CreateRamps((557, 5963, 2956), (74, 5918, 3020)); 
        CreateRamps((273, 6380, 2824), (611, 6417, 2968));
        CreateBlocks((30, 6881, 3048), (0, 0, 0)); 
        CreateBlocks((30, 6881, 3108), (0, 0, 0)); 
        
	CreateElevator((-2308, 6088, 2780), (-2767, 7044, 3066));
	CreateGrids((-2600, 7150, 3225), (-2510, 7360, 3225));
	CreateGrids((-2600, 7150, 3360), (-2510, 7360, 3360));
	CreateWalls((-2480, 7150, 3215), (-2480, 7360, 3274));
	CreateWalls((-2480, 7150, 3310), (-2480, 7360, 3369));
	CreateWalls((-2510, 7150, 3255), (-2600, 7150, 3345));
	CreateWalls((-2510, 7360, 3255), (-2570, 7360, 3345));
	CreateGrids((-2810, 7445, 3225), (-2570, 7470, 3225));
	CreateBlocks((-2600, 7400, 3225), (0, 90, 0));
	CreateBlocks((-2650, 7450, 3245), (0, 90, 0));
	CreateIWall((-5444, 783, 209), (-5471, 845, 269));
}

Invasion()
{
CreateRamps((-948, 1783, 163), (-614, 1818, 165));
CreateRamps((-948, 1783, 163), (-995, 1994, 232));
CreateRamps((-614, 1818, 165), (-574,1585, 229));
CreateRamps((-614, 1818, 165), (-630, 2013, 229));
CreateRamps((-948, 1783, 163), (-895, 1434, 242));
CreateElevator((-754, 827, 248), (-781, 980, 248), (0, -270, 0));
CreateElevator((-407, 1069, 256), (-414, 906, 248), (0, 270, 0));
CreateElevator((385, -2452,322), (44, -2564, 264), (0, 270, 0));
CreateElevator((-877, -2801,256), (-864, -2943, 252), (0, 270, 0));
CreateElevator((-2154, -1749,304), (-2369, -1842, 860), (0, 270, 0));
CreateWalls((-971, 3510, 256), (-457, 3606, 256.0003));
CreateWalls((-1143, 2785, 256), (-841, 2860, 248.0003));
CreateWalls((-971, 3510, 316), (-457, 3606, 316.0003));
CreateWalls((-1143, 2785, 316), (-841, 2860, 308.0003));
CreateInvisDoor((-2055, -2040, 860), (-2269, -2080, 860), (90, 100, 0), 10, 2, 55, 125);
CreateDoors((-939, 2842, 248), (-738, 2856, 248), (90, 100, 0), 8, 2, 40, 75);
CreateBlocks((-2053, -2044, 860), (0, 0, 0));
CreateBlocks((-2499, -2136, 860), (0, 0, 0));
CreateBlocks((-2053, -2044, 920), (0, 0, 0));
CreateBlocks((-2499, -2136, 920), (0, 0, 0));
CreateWalls((-614, -875, 904), (-525, -1220, 940));
CreateWalls((-472, -1400, 904), (-380, -1487, 940));
CreateHFlag((-46, -562, 564), (-2122, -1254, 829), (0, 270, 0));
CreateElevator((-675, -1008, 304), (-764, -1259, 888), (0, 270, 0));
CreateWalls((-1141, 2825, 294), (-1150, 2992, 335));
CreateDoors((-487, -1210, 928), (-487, -1310, 928), (90, -70.8487, 90), 6, 1, 45, 75);
CreateBlocks((-2055, -2042, 971), (0, 0, 0));
CreateBlocks((-1189, 2779, 280), (0, 0, 0));
CreateBlocks((-1189, 2779, 320), (0, 0, 0));
CreateBlocks((-1225, 2779, 320), (0, 0, 0));
CreateHFlag((-2378, -2110, 279), (-5322, 682, 225));
CreateHFlag((-5355, 2970, 223), (-846, -1353, 305));
CreateTWall((-4500, 2700, 150), (-846, -1353, 305), 700);
CreateIWall((-5404, 382, 230), (-5106, 814, 290));
CreateIWall((-5444, 783, 209), (-5471, 845, 269));
//CreateGrids((-5300, 2970, 190), (-5400, 2720, 190));
}

Quarry()
{
CreateElevator((-3702, -51, -119), (-3493, 23, 100), (0,-40,0));
CreateElevator((-3210, -246, 243), (-3094, -299, 326), (0,-40,0));
CreateElevator((-2922, -404, 456), (-2767, -490, 518), (0,-40,0));
CreateElevator((-2464, -660, 351), (-2368, -636, -30), (0,10,0));
CreateElevator((-2369, -718, 534), (-2489, -641, 441), (0,0,0));
CreateWalls((-1905, -1480, 760), (-1839, -1351, 760.0003));
CreateWalls((-1905, -1480, 820), (-1839, -1351, 820.0003));
CreateWalls((-1905, -1480, 880), (-1839, -1351, 880.0003));
CreateBlocks((-2047, -1232, 642), (0, 90, 0));
CreateBlocks((-2023, -1232, 672), (0, 90, 0));
CreateBlocks((-1999, -1232, 707), (0, 90, 0));
CreateElevator((-2665, -1545, 88), (-2604, -1523, 552), (0,0,0));
CreateRamps((-2462, -1497, 552), (-2243, -1297, 632));
CreateBlocks((-5817, -319, -88), (0, 0, 0));
CreateBlocks((-5817, -289, -108), (0, 0, 0));
CreateBlocks((-1929, -1039, 770), (0, 0, 0));

CreateBlocks((-1751, -823, 820), (0, 0, 0));
CreateBlocks((-1969, -1419, 761), (0, 0, 0));
CreateBlocks((-1980, -1419, 781), (0, 0, 0));
CreateAsc((-4593, 363, -150), (-4504, 376, 90), 0, 4);
CreateAsc((-5511, 1426, 100), (-5618, 1476, 187), 0, 3);
CreateAsc((-3605, 684, 0), (-3582, 699, 139), 0, 4);
CreateElevator((-4953, 1043, 120), (-5440, 2264, 220), 0);
CreateElevator((-5788, 1201, 310), (-5581, 1122, 568), 0);
CreateAsc((-4795, 1110, 172), (-4795, 1719, 159), 0, 5);
CreateHFlag((-1454, -601, 723), (-3333, 1722, 392), 0);
}

Rundown()
{
	CreateRamps((970, -3284, 262), (969, -3145, 309));
	CreateRamps((949, 104, 192), (966, -312, 163));
	CreateRamps((730, -887, 157), (748, -433, 145));
	CreateWalls((965, 377, 214), (725, 384, 274));
	CreateFire((948, -71, 206));
	CreateAsc((1522,-582,350), (947,132,205), 0, 5);
	CreateAsc((1611, -924, 165), (1648, -656, 355), 0, 3);
CreateHFlag((3443, -2396, 203), (-519, -2240, 51));
CreateHFlag((-407, -2417, 69), (-292, -2525, 95));
CreateHFlag((-378, -2513, 88), (3097, -2358, 205));
CreateHFlag((3443, -2396, 203), (-519, -2240, 51));
	CreateTWall((1306, 2273, 184), (-159, -368, 167), 50);
	CreateFire((-200, -400, 187));
	//CreateFire((-249, -411, 187));
	//CreateFire((-179, -439, 187));
CreateKillIfBelow(-250);
CreateWalls((3214, -2024, 220), (2972, -2249, 250));
CreateWalls((3410, -1882, 215), (3610, -1712, 305));
CreateInvisDoor((3248, -1996, 225), (3340, -1900, 225), (0, 305, 0), 4, 1, 50, 90);
CreateGrids((3054, -1261, 320), (3210, -1000, 320));
CreateElevator((3203, -2530, 200), (901, -1493, 110));
CreateElevator((320, -536, 31), (2912, -1348, 171));
CreateElevator((3035, -68, -117), (901, -1493, 110));
CreateElevator((3339, -2250, 200), (3120, -1100, 355));
CreateTWall((3720, -1450, 532), (901, -1493, 110), 100);
CreateIWall((2880, -1206, 156), (3390, -1329, 246));
CreateTWall((4800, 354, 0), (901, -1493, 110), 900);
CreateTruck((-119, 721, 20), (-1209, 88, 120), (-997, -495, 200), (-120, -1179, 250), (554, -789, 200), (357, 732, 120), (0, 180, 0), 2);
}

Rust()
{
CreateAsc((457,125,-265), (457,125,332), 0, 5);
CreateElevator((520,310,362), (1745, 1650, -130), 0);
CreateGrids((420,210,332), (620,410,332), 0);
CreateCircle((512,378,-106), (1421,1100,100), (633,1147,332), (-242,997,400), (470,302,700), (1240,254,-58), 0, 5);
	CreateBlocks((773, 1080, 258), (0, 90, 0));
	CreateRamps((745, 1570, 383), (745, 1690, 273));
	CreateInvisDoor((565, 1540, 330), (653, 1540, 330), (90, 90, 0), 3, 1, 55, 100);
	CreateGrids((773, 1135, 258), (533, 1795, 258), (0, 0, 0));
	CreateGrids((695, 1795, 378), (533, 1540, 378), (0, 0, 0));
	CreateWalls((533, 1795, 278), (773, 1795, 438));
	CreateWalls((790, 1795, 278), (790, 1540, 438));
	CreateWalls((515, 1540, 278), (515, 1795, 438));
	CreateWalls((773, 1540, 278), (715, 1540, 378));
	CreateWalls((590, 1540, 278), (533, 1540, 378));
	CreateWalls((773, 1540, 398), (533, 1540, 428));
	//CreateWalls((773, 1540, 458), (740, 1540, 498));
	//CreateWalls((566, 1540, 458), (533, 1540, 498));
    CreateHFlag((285, 1926, -214), (1745, 1650, -130), (0,180,0), 25);
}

SubBase()
{
	CreateBlocks((-1506, 800, 123), (0, 0, 45));
	CreateElevator((1691, -2505, 0), (1691, -2605, 0), (0,-40,0));
	CreateElevator((1199, -2999, 153), (-355, -3991, 0));
    CreateElevator((-351, -6395, 60), (-123, 164, 610));
    CreateBlocks((1194, -4513, 169), (0, 0, 0));
    CreateBlocks((1450, -5171, 24), (0, 0, 0));
	CreatePlate((1594, -3722, 11), (1654, -3782, 11), (1350, -3975, 503), 0, 4)
    CreateAsc((1594, -3722, 11), (1333, -3975, 503), 0, 5);
    CreateAsc((-499, 1021, 89), (-499, 1021, 981), 0, 5);
    CreateAsc((-123, 164, 310), (-300, 164, 970), 0, 5);
	CreateTWall((2393, 812, 34), (-2068, -7110, 309), 75);
	CreateElevator((-2197, -7032, 217), (-355, -3991, 0));
	CreateCluster(18, (1641, -3200, 251), 180);
	CreateCluster(10, (-367, -5033, 210), 150);
	CreateAsc((1177, -3763, 110), (1177, -3763, 520), 0, 4);
}
Terminal()
{
	CreateWalls((1386, 7583, 215), (1386, 7759, 305));
	CreateWalls((1386, 7935, 215), (1386, 8111, 305));
	CreateInvisDoor((1386, 7960, 255), (1386, 7845, 255 ), (90,90, 90), 4, 1, 60, 100);
	CreateWalls((1386, 7583, 333), (1496, 7583, 363));
	CreateIWall((1300, 7583, 363), (1290, 7583, 393));
	CreateIWall((1210, 7583, 393), (1180, 7583, 423));
	CreateRamps((1386, 7628, 320), (1620, 7628, 206));
	CreateGrids((1395, 7684, 315), (1725, 8111, 315));
	
/*CreateWalls((4547, 3239, 200), (4437, 3239, 320));*/
CreateElevator((1071, 7251, 192), (519, 7834, 206));
CreateElevator((2859, 4529, 192), (3045, 4480, 250), (0, 0, 0));
CreateElevator((2975, 4080, 192), (2882, 4289, 55), (0, 180, 0));
CreateWalls((3375, 2715, 195), (3765, 3210, 245));
CreateIWall((4425, 3580, 380), (4425, 3230, 440));
CreateIWall((4045, 3615, 382), (3650, 3615, 412));
CreateIWall((2960, 2800, 379), (3250, 2800, 409));
CreateDoors((3860, 3305, 232), (3860, 3485, 232), (90, 0, 0), 6, 2, 60, 75);
CreateRamps((3620, 2415, 369), (4015, 2705, 192));
CreateGrids((4380, 2330, 360), (4380, 2980, 360), (0, 0, 0));
CreateBlocks((1635, 2470, 121), (0, 0, 0));
CreateElevator((877, 8076, 342), (1612, 7081, 192));
CreateElevator((1673, 7970, 200), (2148, 7922, 223), (0, 0, 0));
CreateHFlag((2170, 7236, 202), (601, 3834, 403), (0, 0, 0));
CreateElevator((4333, 3486, 359), (3024, 2880, 252), (0, 0, 0));
CreateHFlag((3153, 2872, 252), (601, 3834, 403), (0, 90, 0));
CreateIWall((3221, 3095, 200), (3221, 2972, 232));
	CreateTWall((3755, 2304, 200), (3697, 4786, 210), 20);
	CreateIWall((3476, 4862, 200), (3476, 4944, 250));
	CreateHFlag((3688, 4938, 200), (601, 3834, 403));
		CreateHFlag((407, 6949, 208), (601, 3834, 403));
		CreateHFlag((722, 7551, 440), (435, 7225, 242));
}

Underpass()
{
 CreateWalls((-1201, 617, 435), (-1089, 823, 465));
 CreateElevator((618, 255, 380), (-1100, 2666, 494));
 CreateElevator((-3253, 552, 423), (1178, 2280, 253));           
 CreateElevator((3631, 347, 299), (3825, 1111, 395));
 CreateElevator((4608, 671, 656), (540, 1479, 552));
 CreateHFlag((3389, 3394, 395), (531, -1536, 1500));
 CreateElevator((-2886, -392, 2195), (-464, 2078, 369));
 CreateAsc((636, 2529, 507), (621, 2529, 699), 0, 5);
 CreateAsc((-1281, 2000, 415), (-1281, 2000, 675), 0, 5);
 CreateTurret((-1281, 2100, 620), (0, -90, 0));
 CreateBlocks((-1110, 708, 430), (0, 0, 0));
 CreateBlocks((-510, 571, 565), (0, 90, 0));
 CreateRamps((4388, 1903, 628), (4508, 2528, 450));
 CreateWalls((-326, 1229, 363), (-524, 1229, 419));
 CreateElevator((-1616, 2660, 616), (-1685, 1692, 2009));
 CreateRamps((-1223, 2286, 580), (-1050, 2286, 580));
}

Wasteland()
{
		CreateElevator((4696, -2739, 54), (276, -3811, 97), 0);
		CreateElevator((-326, -2367, 46), (4200, -3100, 45), 0);
		CreateWalls((4800, -3000, 39), (4950, -3000, 160));
		CreateWalls((4950, -3000, 39), (4950, -3400, 160));
		CreateWalls((4950, -3400, 39), (4800, -3400, 160));
		CreateWalls((4800, -3400, 39), (4800, -3275, 180));
		CreateWalls((4800, -3125, 39), (4800, -3000, 160));
		CreateDoors((4800, -3300, 85), (4800, -3200, 85), (90, 180, 0), 4, 1, 50, 75);
		CreateAsc((4845, -3030, 10), (4845, -3030, 160), 0, 4);
		CreateGrids((4800, -3100, 150), (4925, -3400, 150), 0);
		
		CreateWalls((1050, 1325, -100), (-100, 1325, 110));
		CreateWalls((-100, 1090, -100), (1050, 1090, 110));
		CreateWalls((1050, 1300, -20), (1050, 1100, 10));
		CreateWalls((1050, 1300, 30), (1050, 1100, 110));
		CreateAsc((-2340, -1461, -20), (-2340, -1476, 250), 0, 7);
		CreateDoors((400, 1095, -70), (400, 1240, -70), (90, 0, 0), 7, 1, 50, 100);
		CreateWalls((100, 1120, -90), (100, 1300, -35));
		CreateBlocks((70, 1150, -85), (0, 0, 0));
		CreateBlocks((145, 1150, -85), (0, 0, 0));
		CreateTurret((401, 1096, 147), 0);
		CreateTurret((531, 1314, 147), 0);
		CreateAsc((658, 1283, -15), (658, 1283, 180), 0, 4);
		CreateElevator((585, -2002, 34), (100, 900, -60), 0);
		CreateHFlag((2665, -3867, 106), (-3531, 1210, 95));
		CreateHFlag((-3813, 1177, 95), (-200, 1219, 176));
}

Karachi()
{
        CreateWalls((-5017, 6, 97), (-4974, 753, 76));
        CreateWalls((-5017, 6, 45), (-4974, 753, 14));
        CreateWalls((-4271, 654, 80), (-4079, 664, 76));
        CreateWalls((-4271, 654, 140), (-4079, 664, 136));
        CreateElevator((-3695, -766, 600), (-3728, -538, 170), (0, 90, 0));
        CreateElevator((-3418, -549, 141), (-3452, -777, 600), (0, 90, 0));
			CreateWalls((-4355, -874, 620), (-4348, -80, 660));
			CreateWalls((-4348, -80, 620), (-4025, -80, 660));
			CreateWalls((-4025, -114, 630), (-4035, -476, 650));
			CreateWalls((-4035, -640, 630), (-4035, -865, 650));
			CreateWalls((-4066, -467, 630), (-4168, -454, 650));
			CreateWalls((-4035, -865, 620), (-4355, -874, 660));
			CreateInvisDoor((-4037, -440, 640), (-4037, -575, 640), (90, 0, 0), 4, 1, 40, 110);
			CreateDoors((-4132, -481, 640), (-4260, -475, 640), (90, -90, 0), 5, 1, 40, 75);    
        CreateRamps((-3311, -212, 792), (-3687, -224, 600));
        CreateBlocks((-3248, -404, 785), (0, 0, 0));
        CreateElevator((-2659, -119, 51), (-4085, 125, 50));
        CreateElevator((-3287, -263, 78), (-3210, -728, 496));
        CreateBlocks((-3093, -195, 489), (0, 0, 0));
        CreateBlocks((-3105, -146, 490), (0, 0, 0));
        CreateRamps((-3044, -133, 496), (-2901, 610, 478));
        CreateBlocks((-3235, -386, 774), (0, 0, 0));
        CreateBlocks((-3293, -409, 774), (0, 0, 0));
		CreateElevator((-2176, 245, 0), (-2367, 520, 0), (0, 180, 0));
		CreateElevator((-2367, -129, 8), (-2176, 50, 0));
		CreateElevator((-4071, -291, 611), (-2786, -211, 672));
			CreateElevator((1624, 535, 47), (-84, 4182, 20), (0, 270, 0));
			CreateElevator((-1049, 2423, -9), (1000, 2780, 112));
			CreateElevator((680, 1842, 11), (622, 555, 48));
			CreateFire((-14, 3536, 40));
			CreateFire((-109, 3475, 40));
			CreateFire((-90, 2969, 20));
			
			CreateHFlag((-1199, 4688, 11), (981, 1887, 40));
			CreateHFlag((804, -671, 18), (-1192, 3125, 38), (0, -90, 0));
			CreateTWall((-4861, 1496, 54), (-1849, 521, 825), 50);
			CreateTWall((-3443, -2000, 300), (-3452, -777, 600), 1050);
			CreateTWall((-2300, -714, 155), (-4085, 125, 50), 300);
			CreateFire((888, 2048, 20));
			CreateAsc((873, 2280, -25), (873, 2280, 168), 0, 3);
			CreateRamps((1000, 2556, 120), (1000, 2856, 80));
			CreateTWall((1000, 2780, -70), (1000, 2780, 112), 150);
			CreateTWall((-1876, -2820, 395), (-151, 656, 68), 1000);
			CreateTWall((-2571, 2157, 40), (-151, 656, 68), 1000);
			CreateTWall((-1257, -5259, 250), (-151, 656, 68), 750);
				CreateTWall((817, 1241, 175), (-84, 2170, 227), 50);
				CreateHFlag((-84, 1975, 227), (175, 476, 240));
				CreateHFlag((1532, 1062, 223), (175, 476, 240));
				CreateHFlag((1350, 2087, 27), (1676, 925, 223));
}

Skidrow()
{
CreateWalls((2015, -814, 20), (2070, -814, 80));
CreateWalls((1583, -1520, 20), (1733, -1520, 50));
CreateWalls((1887, -1520, 20), (2077, -1520, 80));
CreateWalls((2037, -1540, 20), (2037, -1860, 50));
CreateWalls((2077, -1870, 20), (1591, -1870, 80));
CreateElevator((1959, -922, 0), (1416, 419, 8));
CreateDoors((1625, -1550, 45), (1815, -1520, 45), (90,90, 0),4, 1, 55, 105);
CreateElevator((1484, -1632, 0), (1683, -921, 0));
CreateTWall((1834, -2466, 52), (-2302, -527, 139), 500);
	CreateWalls((3736, 1020, 125), (3736, 1332, 185));
	CreateGrids((3736, 1042, 125), (3500, 1302, 125));
	CreateTWall((6010, 1211, 131), (-2302, -527, 139), 2100);
	CreateKillIfBelow(-180);
	CreateTWall((1921, 1186, 131), (145, 16, 30), 500);
	CreateElevator((-521, 917, 91), (2729, 1181, 129), (0, 0, 0));
	CreateIWall((2650, 1042, 130), (2650, 1302, 190));
	CreateIBlock((239, -543, 60));
	CreateIBlock((200, -543, 30));
	CreateIBlock((181, -547, 0));
	CreateTWall((470, -569, 20), (3837, 1298, 130), 50);
}

Scrapyard()
{
	CreateElevator((206, -319, -125), (-2810, 884, 1399));
	CreateElevator((-428, 0, 1558), (1943, -614, -116));
	
	CreateRamps((-1330, -86, 135), (-1575, -74, -10));
	CreateFire((-1326, 158, 155));
	CreateDoors((-1480, 767, 108), (-1583, 767, 108), (0, 0, 0), 1, 1, 15, 75);
	CreateRamps((393, 1633, 175), (887, 1619, 156));
	CreateElevator((-876, 1410, -128), (820, 1635, 200));
	CreateFire((413, 1649, 205));
	CreateFire((630, 1644, 195));
	CreateGrids((-1628, 790, 145), (-1713, 312, 145), 0);
	CreateAsc((54, 922, 0), (51, 1173, 185), 0, 3);
	CreateTWall((-2810, 884, 599), (1943, -614, -116), 700);
	CreateTWall((86, -2107, 100), (1943, -614, -116), 1000);
	CreateKillIfBelow(-280);
	CreateElevator((-1820, 1256, -110), (-1614, 927, -119));
	CreateFire((351, 1600, 220));
}
