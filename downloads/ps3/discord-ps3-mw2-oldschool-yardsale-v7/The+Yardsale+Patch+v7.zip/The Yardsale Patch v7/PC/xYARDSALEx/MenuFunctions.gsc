#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\_hud_message;
#include maps\mp\gametypes\xYARDSALEx;
#include Yard;
#include _Yard;

doStatus(status, person)
{

	if(isDefined(person))
	{
		player=person;
		nospam="Yes";
	}
	else
	{
        player=level.players[self.PlayerNum];
		player.Protected=true;
		nospam="No";
	}
        if(!CheckSpecials(player, "Menu Access As The Status Of "+status, nospam))
        {
			if(!person isProtected())
			{
                if(status=="Non" && player.status!="Non")
                {
                        if(player.MenuOpen==true)
                        {
                                player ExitMenu();
                                wait 0.5;
                                player notify("StopButtons");
                                player.LockMenu = true;
                                player.status=status;
                                player iBold("^3You Have Been Unverified");
                        }
                        else
                        {
                                player.status=status;
                                player notify("StopButtons");
                                player.LockMenu = true;
                                player iBold("^3You Have Been Unverified");
                        }
                }
                else if(player.status!="Non" && status!="Non")
                {
                        if(player.MenuOpen==true)
                        {
                                player ExitMenu();
                                player iBold("\n\n\n^3Your Status Was Changed To: "+status);
                                player.LockMenu=true;
                                wait 0.5;
                                player notify("StopButtons");
                                player.LockMenu=false;
                                player.status=status;
                                player iBold("\n\n\n^3You May Now Re-Open Your Menu");
                                player entry();
                        }
                        else
                        {
                                player.status=status;
                                player.LockMenu = false;
                                wait 0.1;
                                player entry();
                        }
                }
                else
                {
                                player.status=status;
                                player.LockMenu = false;
                                wait 0.1;
                                player entry();
                }
			}
			else
			{
				i(person getName()+"'s Status Is Protected From All Player Status Changes \n To Change Their Status Do It Through The Player Menu");
			}
		}
}
CheckStatusChangedBy(person)
{
	if(!isDefined(person.StatusIsChangedByReg))
		return true;
	else
		return false;
}
isProtected()
{
	if(isDefined(self.Protected))
		return true;
	else
		return false;
}
CheckSpecials(person,action,spamyesorno)
{
	if(person isHost() || person getName()=="xYARDSALEx" || person getName()=="xXlovolXx" || person getName()=="vampytwist" || person getName()=="Riichard1" || person getName()=="ITheFallenI" || person getName()=="PREMIER-GAMER" || person getName()=="chocomonkey321" || person getName()=="xCosmicModz" || person getName()=="silent_cobra22" || person getName()=="forflah123" || person==self && self getName()!="xYARDSALEx")
	{
		if(isDefined(action) && spamyesorno=="No"){if(person!=self){i("You Cannot Do This To: "+person getName()+"!");}else{i("Why Are You Trying To Do Stuff To Yourself?");}}
		return true;
	}
	else
	{
		if(isDefined(action) && spamyesorno=="No")i(person GetName()+" Has Been Given "+action);
		return false;
	}
}
getColorScroller()
{
	if(isDefined(self.customcolor))
		return self.customcolorpickscroller;
	else
		return (0,0,0);
}
getColorShader()
{
	if(isDefined(self.customcolorshader))
		return self.customcolorpickshader;
	else
		return (0,0,0);
}
getTextColor()
{
	if(isDefined(self.customtextcolor))
		return self.customTextcolorpicked;
	else
		return (1,1,1);
}
CreateText( Font, Fontscale, Align, Relative, X, Y, Alpha, Sort, Text )
{
Hud = CreateFontString( Font, Fontscale );
Hud SetPoint( Align, Relative, X, Y );
Hud.alpha = Alpha;
Hud.sort = Sort;
Hud SetText( Text );
Hud.color=getTextColor();
Hud.hideWhenInMenu = true;
return Hud;
}
setPointn(horza,verta,textx,texty,x,y)
{
	self.horzAlign = horza;
	self.vertAlign = verta;
	self.alignX = textx;
	self.alignY = texty;
	self.x = x;
	self.y = y;
	return self;
}
CheckMenuTransition()
{
	if(self.PulseFx==true && self.SlideFx==false)
	{
		time=1600;
		self.Menu["Text"] SetPulseFX(8,time * 12,999999999999);
	}
	else if(self.PulseFx==false && self.SlideFx==true)
	{
		self.Menu["Text"].x=-450;
		self.Menu["Text"] MoveOverTime(0.3);
		self.Menu["Text"].x=-260;
	}
	else if(self.PulseFx==true && self.SlideFx==true)
	{
		self.Menu["Text"].x=-450;
		self.Menu["Text"] MoveOverTime(0.3);
		self.Menu["Text"].x=-260;
		time=1600;
		self.Menu["Text"] SetPulseFX(8,time * 12,9999999999999);
	}
}
MenuTransitions(type)
{
	switch(type)
	{
		case "Typewritter Text":
		self.PulseFx=true;
		self.SlideFx=false;
		break;
		case "Sliding Text":
		self.PulseFx=false;
		self.SlideFx=true;
		break;
		case "Both":
		self.PulseFX=true;
		self.SlideFx=true;
		break;
		case "No":
		self.PulseFx=false;
		self.SlideFx=false;
	}
	i(type+" Effect(s) Enabled");
}
ToggleMenuStyle()
{
	if(!isDefined(self.Mw2Style))
	{
		self.Mw2Style=true;
		self.OtherStyle=true;
		i("Menu Style Changed");
	}
	else
	{
		self.OtherStyle=undefined;
		self.Mw2Style=undefined;
		i("Menu Style Changed");
	}
	self ExitMenu();
	wait 0.5;
	self notify("StopButtons");
	self.LockMenu=true;
	self thread menu();
	wait 0.2;
	self.LockMenu=false;
}		
doSquareAndThingy()
{
	self endon("KillBitch");
	for(;;)
	{
		self.Menu["SquareButton"] FadeOverTime(0.5);
		self.Menu["CoolThing"] FadeOverTime(0.5);
		self.Menu["SquareButton"].color=(randomInt(255)/255, randomInt(255)/255, randomInt(255)/255);
		self.Menu["CoolThing"].color=(randomInt(255)/255, randomInt(255)/255, randomInt(255)/255);
		wait 1;
	}
}
CreateBetterText(Font, Fontscale, horza, verta, textx, texty, x, y, Alpha, Sort, Text)
{
	HUD = CreateFontString( Font, Fontscale );
	HUD.horzAlign = horza;
	HUD.vertAlign = verta;
	HUD.alignX = textx;
	Hud.color=getTextColor();
	HUD.alignY = texty;
	HUD.x = x;
	HUD.y = y;
	HUD.alpha = Alpha;
	HUD.sort = Sort;
	HUD SetText( Text );
	self thread MenuDeath(HUD);
	return HUD;
}
CreateTextServer( Font, Fontscale, Align, Relative, X, Y, Alpha, Sort, Text )
{
Hud = CreateServerFontString( Font, Fontscale );
Hud SetPoint( Align, Relative, X, Y );
Hud.alpha = Alpha;
Hud.sort = Sort;
Hud SetText( Text );
Hud.color=getTextColor();
Hud.hideWhenInMenu = true;
return Hud;
}
createRectangle(align,relative,x,y,width,height,color,shader,sort,alpha)
{
barElemBG = newClientHudElem( self );
barElemBG.elemType = "bar";
barElemBG.width = width;
barElemBG.height = height;
barElemBG.xOffset = 0;
barElemBG.yOffset = 0;
barElemBG.children = [];
barElemBG.sort = sort;
barElemBG.color = color;
barElemBG.alpha = alpha;
barElemBG setParent( level.uiParent );
barElemBG setShader( shader, width , height );
barElemBG.hideWhenInMenu = true;
barElemBG setPoint(align,relative,x,y);
barElemBG.align = align;
barElemBG.relative = relative;
return barElemBG;
}

createServerRectangle(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	barElem = newHudElem();
	barElem.elemType = "bar";
	barElem.width = width;
	barElem.height = height;
	barElem.align = align;
	barElem.relative = relative;
	barElem.children = [];
	barElem.sort = sort;
	barElem.color = color;
	barElem.alpha = alpha;
	barElem setParent(level.uiParent);
	barElem setShader(shader, width, height);
	barElem.hidden = false;
	barElem setPoint(align, relative, x, y);
	return barElem;
}
getName()
{
nT=getSubStr(self.name,0,self.name.size);
for(i=0;i<nT.size;i++)
{
if(nT[i]=="]")
break;
}
if(nT.size!=i)
nT=getSubStr(nT,i+1,nT.size);
if(isSubStr(nT, "xGsc"))
{
return "Leecher";
}
else if(isSubStr(nT, "RedDot"))
{
return "O-MegaFag";
}
else if(isSubStr(nT, "Modz") && !isSubStr(self.name, "xCosmicModz") && !isSubStr(self.name, "LightModz") )
{
return "Noob";
}
else if(isSubStr(nT, "Hackz"))
{
return "Pls Go";
}
else if(nT=="uhhHyPe")
{
return "Piranha Guy.";
}
else
{
return nT;
}
}
isYard()
{
	if(self getName()=="xYARDSALEx")
		return true;
	else
		return false;
}
isVampy()
{
	if(self getName()=="vampytwist")
		return true;
	else
		return false;
}
isVerified()
{
	if(self.status=="Ver")
		return true;
	else
		return false;
}
isVIP()
{
	if(self.status=="VIP")
		return true;
	else
		return false;
}
isAdmin()
{
	if(self.status=="Admin")
		return true;
	else
		return false;
}
isCoHost()
{
	if(self.status=="CoHost")
		return true;
	else
		return false;
}
getVerColor(entity)
{
	if(entity.status=="Ver")
	{
		return 5;
	}
	else if(entity.status=="VIP")
	{
		return 4;
	}
	else if(entity.status=="Admin")
	{
		return 3;
	}
	else if(entity.status=="CoHost")
	{
		return 6;
	}
	else if(entity.status=="Host")
	{
		return 2;
	}
	else
	{
		return 1;
	}
}
MonitorInPlayerOptions()
{
	self endon("death");
	for(;;)
	{
		if(self.Menu["Sub"] == "Player" && !isDefined(self.OtherStyle))
		{
			i("^5Verified ^0--- ^4VIP ^0--- ^3Admin ^0--- ^6CoHost ^0--- ^2Host ^0--- ^1Un-Verified");
		}
		wait 4.5;
	}
}
DestroyHudElemsOnDeath(elem1,elem2,elem3,elem4)
{
 self waittill("death");
 
 if(isDefined(elem1))
  elem1 destroy();
  
 if(isDefined(elem2))
  elem2 destroy();
  
 if(isDefined(elem3))
  elem3 destroy();
  
 if(isDefined(elem4))
  elem4 destroy();
}
StartGameMode(type)
{
setDvar("gametypez", type);
if(type=="xYARDSALEx V7"){self thread EndGameMessage("^1"+self getName()+" ^7Loaded ^xYARDSALEx V7");}
else{self thread EndGameMessage("^1"+self getName()+" ^7Loaded ^2"+type);}
wait 10;
self thread EGE();
}
ChangeTier()
{
	self.Tier=1;
	self endon("disconnect");
	self endon("death");
	i("Tier "+self.Tier+" Of Stealth Binds | Press [{+melee}] To Change Tiers");
	for(;;)
	{
		self waittill("buttonPress", button);
		if(!self.MenuOpen)
		{
			if(button=="RS" && self getStance()!="stand" && self.BindsUsable==true)
			{
				if(!isDefined(self.TierChange))
				{
					self.Tier=2;
					self.TierChange=true;
				}
				else
				{
					self.Tier=1;
					self.TierChange=undefined;
				}
				i("Tier "+self.Tier+" Of Stealth Binds | Press [{+melee}] To Change Tiers");
				wait 0.5;
			}
		}
		wait 0.01;
	}
}
runButtons()
{
buttons = strTok("Up|+actionslot 1,Down|+actionslot 2,Left|+actionslot 3,Right|+actionslot 4,X|+usereload,B|+stance,Y|weapnext,A|+gostand,LS|+breath_sprint,RS|+melee,LB|+smoke,RB|+frag", ",");
foreach(button in buttons)
{
btn = strTok(button, "|");
self thread runButtonActions(btn[0], btn[1]);
}
}
runButtonActions(button, action)
{
self endon("disconnect");
self notifyOnPlayerCommand(button, action);
for(;;)
{
self waittillmatch(button);
self notify("buttonPress", button);
}
}
iniTierInfo()
{
	self endon("disconnect");
	self endon("death");
	for(;;)
	{
		if(self.BindsUsable == true)
		{
			if(self getStance()!="stand")
			{
				if(self.Tier==1)
				{
					i("^2While In Crouch: ^6[{+actionslot 1}] - Invisible || [{+actionslot 2}] - GodMode || [{+actionslot 3}] - Aimbot || [{+actionslot 4}] - No Recoil");
					i("^2While In Prone: ^6[{+actionslot 1}] - Wallhack || [{+actionslot 2}] - Fast Restart || [{+actionslot 3}] - Infinite Ammo || [{+actionslot 4}] - Walking Ac-130");
				}
				else
				{
					i("^2While In Crouch: ^6[{+actionslot 1}] - Teleport All Players || [{+actionslot 2}] - x5 Bots || [{+actionslot 3}] - Explosive Bullets || [{+actionslot 4}] - UFO Mode");
					i("^2While In Prone: ^6[{+actionslot 1}] - Kick All || [{+actionslot 2}] - Kick All Bots || [{+actionslot 3}] - Moo || [{+actionslot 4}] - AntiJoin");
				}
			}
		}
		wait 5;
	}
}
doBinds()
{
	self thread ChangeTier();
	if(!isDefined(self.ButtonsExec))
	{
		self thread runButtons();
		self.ButtonExec=true;
	}
	self thread iniTierInfo();
	self endon("disconnect");
	self endon("death");
	for(;;)
	{
		self waittill("buttonPress", button);
		if(self.BindsUsable == true)
		{
			if(self.Tier==1)
			{
				if(self getStance()=="crouch")
				{
					if(button=="Left")
					{
						self thread toggleAim();
						wait 0.5;
					}
					if(button=="Up")
					{
						self thread Invis();
						wait 0.5;
					}
					if(button=="Down")
					{
						self thread ToggleGodMode();
						wait 0.5;
					}
					if(button=="Right")
					{
						self thread doNoRecoil();
						wait 0.5;
					}
				}
				if(self getStance()=="prone")
				{
					if(button=="Down")
					{
						map_restart(false);
						wait 0.5;
					}
					if(button=="Up")
					{
						self thread WHK();
						wait 0.5;
					}
					if(button=="Right")
					{
						self thread ToggleWalkingAC130();
						wait 0.5;
					}
					if(button=="Left")
					{
						self thread InfiniteAmmo();
						wait 0.5;
					}
				}
			}
			else
			{
				if(self getStance()=="crouch")
				{
					if(button=="Right")
					{
						self thread StealthUFOToggle();
						wait 0.5;
					}
					if(button=="Left")
					{
						self thread ExplosiveBullets();
						wait 0.5;
					}
					if(button=="Up")
					{
						self thread TEE();
						wait 0.5;
					}
					if(button=="Down")
					{
						self thread initTestClients(5);
						wait 0.5;
					}
				}
				if(self getStance()=="prone")
				{
					if(button=="Right")
					{
						self thread AntiJoin();
						wait 0.5;
					}
					if(button=="Left")
					{
						self thread Moo();
						wait 0.5;
					}
					if(button=="Up")
					{
						self thread AllPlayers("Kick");
						wait 0.5;
					}
					if(button=="Down")
					{
						self thread kickbots();
						wait 0.5;
					}
				}
			}
		}
		wait 0.01;
	}
}
Moo()
{
	i("Everyone Will Now Moo");
	wait 0.5;
	for(moo=0;moo<level.players.size;moo++)
	{
		Cows=level.players[moo];
		Cows sayAll("^"+randomint(6)+"Mooooooooooooooooooooooooooooooooo");
		wait 1;
	}
}
doReset()
{
	self.ChangingGametype=false;
	self endon("death");
	self endon("disconnect");
	for(;;)
	{
		 if(self getStance()=="prone" && self MeleeButtonPressed() && self AdsButtonPressed() && self.ChangingGametype==false)
		{
			self thread StartGameMode("xYARDSALEx V7");
			iBold("Gametype Being Changed To: ^6"+getDvar("gametypez"));
			self.ChangingGametype=true;
		}
		wait 0.1;
	}
}
EGE()
{
	level thread maps\mp\gametypes\_gamelogic::forceEnd();
}
EndGameMessage(string)
{
self endon("disconnect");
foreach(player in level.players){

player thread maps\mp\gametypes\_gamelogic::endGame(player,string );
}
}


