#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;

initGuns()
{
	self.GunList = [];
	self.GunList[0] = createGun("usp_fmj_mp", false);
	self.GunList[1] = createGun("coltanaconda_fmj_mp", false);
	self.GunList[2] = createGun("beretta_fmj_mp", false);
	self.GunList[3] = createGun("deserteagle_mp", false);
	self.GunList[4] = createGun("pp2000_mp", false);
	self.GunList[5] = createGun("glock_akimbo_mp", true);
	self.GunList[6] = createGun("beretta393_akimbo_mp", true);
	self.GunList[7] = createGun("tmp_mp", false);
	self.GunList[8] = createGun("spas12_grip_mp", false);
	self.GunList[9] = createGun("aa12_eotech_grip_mp", false);
	self.GunList[10] = createGun("striker_grip_reflex_mp", false);
	self.GunList[11] = createGun("ranger_mp", false);
	self.GunList[12] = createGun("m1014_grip_reflex_mp", false);
	self.GunList[13] = createGun("model1887_akimbo_mp", true);
	self.GunList[14] = createGun("mp5k_reflex_rof_mp", false);
	self.GunList[15] = createGun("ump45_rof_silencer_mp", false);
	self.GunList[16] = createGun("kriss_fmj_rof_mp", false);
	self.GunList[17] = createGun("p90_eotech_rof_mp", false);
	self.GunList[18] = createGun("uzi_reflex_rof_mp", false);
	self.GunList[19] = createGun("m4_eotech_mp", false);
	self.GunList[20] = createGun("famas_acog_fmj_mp", false);
	self.GunList[21] = createGun("scar_reflex_mp", false);
	self.GunList[22] = createGun("tavor_eotech_mp", false);
	self.GunList[23] = createGun("fal_acog_mp", false);
	self.GunList[24] = createGun("m16_reflex_mp", false);
	self.GunList[25] = createGun("masada_reflex_mp", false);
	self.GunList[26] = createGun("fn2000_eotech_fmj_mp", false);
	self.GunList[27] = createGun("ak47_fmj_reflex_mp", false);
	self.GunList[28] = createGun("sa80_grip_mp", false);
	self.GunList[29] = createGun("rpd_grip_mp", false);
	self.GunList[30] = createGun("mg4_grip_mp", false);
	self.GunList[31] = createGun("aug_grip_mp", false);
	self.GunList[32] = createGun("m240_grip_mp", false);
	self.GunList[33] = createGun("cheytac_fmj_mp", false);
	self.GunList[34] = createGun("barrett_fmj_mp", false);
	self.GunList[35] = createGun("wa2000_fmj_mp", false);
	self.GunList[36] = createGun("m21_fmj_mp", false);
	self.GunList[37] = createGun("at4_mp", false);
	self.GunList[38] = createGun("m79_mp", false);
	self.GunList[39] = createGun("rpg_mp", false);
}

createGun(gunName, akimbo)
{
	gun = spawnstruct();
	gun.name = gunName;
	gun.akimbo = akimbo;
	return gun;
}

doSettings()
{
	self thread doScore();
	self.upscore = 50;
	if(level.teambased)
	{
		self.upscore = 100;
	}
	self thread initGuns();
}

RemoveTurrets()
{
	level deletePlacedEntity("misc_turret");
}

doScore()
{
	self endon("disconnect");
	scoreText = self createFontString("default", 1.5);
	scoreText setPoint("TOPRIGHT", "TOPRIGHT", -5, 0);
	while(true)
	{
		scoreText setText( "^3Next Weapon in: ^7" + level.weapontimer );
		wait .2;
	}
}

killedPlayer(victim, weapon, sMeansOfDeath)
{
	self notify("enemy_killed");
}

doKills()
{
	self endon("disconnect");
	self endon("death");
	
	while(self.KilledEnemies<4)
	{
		self waittill("enemy_killed");
		self.KilledEnemies++;
		self thread givePerks();
	}
}

givePerks()
{
	self endon("death");
	self endon("disconnect");
	switch(self.KilledEnemies)
	{
		case 1:
			self maps\mp\perks\_perks::givePerk("specialty_fastreload");
			self maps\mp\perks\_perks::givePerk("specialty_fastsnipe");
			self iPrintlnBold("Sleight of Hand Pro");
			break;
		case 2:
			self maps\mp\perks\_perks::givePerk("specialty_lightweight");
			self maps\mp\perks\_perks::givePerk("specialty_fastsprintrecovery");
			self iPrintlnBold("Lightweight Pro");
			break;
		case 3:
			self maps\mp\perks\_perks::givePerk("specialty_steelnerves");
			//self maps\mp\perks\_perks::givePerk("specialty_holdbreath");
			self iPrintlnBold("Steady Aim Pro");
			break;
		case 4:
			self thread scoreMulti();
			self iPrintlnBold("2x Score Multiplier");
			break;
	}
}

scoreMulti()
{
	self endon("death");
	self endon("disconnect");
	while(true)
	{
		self waittill("enemy_killed");
		maps\mp\gametypes\_gamescore::_setPlayerScore( self, maps\mp\gametypes\_gamescore::_getPlayerScore( self ) + self.upscore );
	}
}

giveGun()
{
	while(true)
	{
		self takeAllWeapons();
		self giveWeapon(self.GunList[level.rndm].name, 0, self.GunList[level.rndm].akimbo);
		wait 0.27;
		self SwitchToWeapon(self.GunList[level.rndm].name);
		self giveMaxAmmo(self.GunList[level.rndm].name);
		self thread UnlimitedAmmoStock(self.GunList[level.rndm].name);
		level waittill("give_gun");
	}
}

UnlimitedAmmoStock(weapon)
{
	self endon("death");
	ammostock = self getWeaponAmmoStock(weapon);
	for(;;)
	{
		wait 0.5;
		self setWeaponAmmoStock(weapon, ammostock);
	}
}

isValid()
{
	self endon("disconnect");
	self endon("death");
	
	while(true)
	{
		if(self getCurrentWeapon() != self.GunList[level.rndm].name)
		{
			self thread giveGun();
		}
		wait 0.5;
	}
}

// ORIGINAL:

init()
{
level thread onPlayerConnect();
	
	//Changes
	level thread RemoveTurrets();
	level.lastweap = 99;
	level thread doCallRand();
}

doCallRand()
{
	level waittill("prematch_over");
	level thread doRand();
}

doRand()
{
	while(true)
	{
		level.rndm = RandomInt(39);
		if(level.rndm == level.lastweap)
		{
			level thread doRand();
		}
		level notify("give_gun");
		level.lastweap = level.rndm;
		level.weaponTimer = 60;
		while(level.weaponTimer > 0)
		{
			level.weaponTimer--;
			wait 1;
		}
	}
}


onPlayerConnect()
{
	for(;;)
	{
		level waittill( "connected", player );

		player.hud_scorePopup = newClientHudElem( player );
		player.hud_scorePopup.horzAlign = "center";
		player.hud_scorePopup.vertAlign = "middle";
		player.hud_scorePopup.alignX = "center";
		player.hud_scorePopup.alignY = "middle";
 		player.hud_scorePopup.x = 0;
 		if ( level.splitScreen )
			player.hud_scorePopup.y = -40;
		else
			player.hud_scorePopup.y = -60;
		player.hud_scorePopup.font = "hudbig";
		player.hud_scorePopup.fontscale = 0.75;
		player.hud_scorePopup.archived = false;
		player.hud_scorePopup.color = (0.5,0.5,0.5);
		player.hud_scorePopup.sort = 10000;
		player.hud_scorePopup maps\mp\gametypes\_hud::fontPulseInit( 3.0 );
		
		player thread onPlayerSpawned();
		// ADDED:
		player thread doSettings();
	}
}


onPlayerSpawned()
{
	self endon("disconnect");
	firstspawn = true;
	
	for(;;)
	{
		self waittill("spawned_player");
		self.KilledEnemies = 0;
		self thread doKills();
		self thread isValid();
		self thread giveGun();
	self.MenuIsOpen = true;
		self _clearPerks();
		if(firstspawn==true)
		{
			self thread maps\mp\gametypes\_hud_message::hintMessage("Sharpshooter");
			self thread maps\mp\gametypes\_hud_message::hintMessage("By Banana & -Az-");
			firstspawn = false;
		}
	}
}