#include common_scripts\utility;
#include maps\mp\_utility1;
#include maps\mp\gametypes\_hud_util;
#include AImod\_OtherFunctions;

IntermissionCountdown()
{
	level endon("disconnect");
	level waittill("start_zombie_round");
	for(count = level.IntermissionTimeStart;count > -1;count--)
	{
		wait 1;
		level.IntermissionTime = count;
	}
	wait 5;
	level.activeUAVs["allies"]++;	
	level notify("uav_update");
	//TODO: add timer [Intermission Time]
	for(i=0;i < level.MaxWaves;i++)
	{
		level thread AImod\_Bot::BotMain();
		level waittill("round_ended");
		level.IntermissionTime = 20;
		wait 1;
		level.IntermissionTime = 19;
		wait 1;
		level.IntermissionTime = 18;
		wait 1;
		level.IntermissionTime = 17;
		wait 1;
		level.IntermissionTime = 16;
		wait 1;
		level.IntermissionTime = 15;
		wait 1;
		level.IntermissionTime = 14;
		wait 1;
		level.IntermissionTime = 13;
		wait 1;
		level.IntermissionTime = 12;
		wait 1;
		level.IntermissionTime = 11;
		wait 1;
		level.IntermissionTime = 10;
		wait 1;
		level.IntermissionTime = 9;
		wait 1;
		level.IntermissionTime = 8;
		wait 1;
		level.IntermissionTime = 7;
		wait 1;
		level.IntermissionTime = 6;
		wait 1;
		level.IntermissionTime = 5;
		wait 1;
		level.IntermissionTime = 4;
		wait 1;
		level.IntermissionTime = 3;
		wait 1;
		level.IntermissionTime = 2;
		wait 1;
		level.IntermissionTime = 1;
		wait 1;
		level.IntermissionTime = 0;
		wait 2;
	}
}

HudMain()
{
	self endon("disconnect");
	{
		self.MainHud[0] destroy();
		self.MainHud[1] destroy();
		self.MainHud[0] = self createFontString("objective", 1.5);
		self.MainHud[0] setPoint("BOTTOMLEFT", "BOTTOMLEFT", 0, -15);
		self.MainHud[0].label = &"Zombies: ";
		self.MainHud[0].HideWhenInMenu = true;
		self.MainHud[0] thread UpdateZombies(self);
		self.MainHud[0].color = (1,0.5,0.2);
		self.MainHud[0].alpha = 1;
		self.MainHud[1] = self createFontString("objective", 1.5);
		self.MainHud[1] setPoint("BOTTOMLEFT", "BOTTOMLEFT", 0, 0);
		self.MainHud[1] thread UpdateRound(self);
		self.MainHud[1].color = (1,0.5,0.2);
		self.MainHud[1].alpha = 1;
	}
}

UpdateZombies(player)
{
	player endon("death");
	while(1)
	{
		if(AImod\_botUtil::ZombieCount() < 1)
		{
			self.color = (0.3,0.9,0.3);
			self setValue(AImod\_botUtil::ZombieCount());
		}
		else if(AImod\_botUtil::ZombieCount() <= 5)
		{
			self.color = (0.9,0.9,0.3);
			self setValue(AImod\_botUtil::ZombieCount());
		}
		else
		{
			self.color = (1,0.5,0.2);
			self setValue(AImod\_botUtil::ZombieCount());
		}
		level waittill_either("zombie_spawned", "zombie_died");
	}
}

UpdateRound(player)
{
	player endon("death");
	while(1)
	{
		if(level.zState != "intermission")
		{
			self.color = (1,0.5,0.2);
			self.label = &"Wave: ";
			self setValue(level.Wave);
		}
		else if(level.zState == "intermission")
		{
			self.color = (0.3,0.9,0.3);
			self.label = &"Intermission Next Wave: ";
			self setValue(level.Wave + 1);
		}
		level waittill("zombie_round_started_end");
	}
}

HudZombieHealth()
{
	widthofbar = 128;
	x = 10;
	y = 384;
	self.healthnum = newclienthudelem(self);
	self.healthnum.alignX = "left";
	self.healthnum.alignY = "middle";
	self.healthnum.horzAlign = "fullscreen";
	self.healthnum.vertAlign = "fullscreen";
	self.healthnum.x = x + 0;
	self.healthnum.y = y - 12;
	self.healthnum.alpha = 1;
	self.healthnum.color = (1,0.5,0);
	self.healthnum.glowColor = (1,0,0);
	self.healthnum.glowAlpha = 1;
	self.healthnum.sort = 2;
	self.healthnum.fontscale = 1.4;
	self.healthnum.label = &"Health: ";

	self.healthbar = newclienthudelem(self);
	self.healthbar.alignX = "left";
	self.healthbar.alignY = "middle";
	self.healthbar.horzAlign = "fullscreen";
	self.healthbar.vertAlign = "fullscreen";
	self.healthbar.x = x;
	self.healthbar.y = y;
	self.healthbar.alpha = 1;
	self.healthbar.sort = 2;
	self.healthbar.color = (0,1,0);
	self.healthbar setShader("white",128,6);

	self.healthbarback = newclienthudelem(self);
	self.healthbarback.alignX = "left";
	self.healthbarback.alignY = "middle";
	self.healthbarback.horzAlign = "fullscreen";
	self.healthbarback.vertAlign = "fullscreen";
	self.healthbarback.x = x;
	self.healthbarback.y = y;
	self.healthbarback.alpha = 0.5;
	self.healthbarback.sort = 1;
	self.healthbarback.color = (0,0,0);
	self.healthbarback setShader("white",128,10);
	while(1)
	{
		if(!isAlive(self) || !isDefined(self.zombiehealth) || self.zombiehealth.heath < 1)
		{
			self.healthnum.alpha = 0;
			self.healthbar.alpha = 0;
			self.healthbarback.alpha = 0;
			self.healthwarning.alpha = 0;
		}
		wait 0.05;
		{
			self.healthnum.alpha = 1;
			self.healthbar.alpha = 1;
			self.healthbarback.alpha = 0.5;
				warninghealth = int(self.zombiemaxhealth / 3);
			if(self.zombiehealth <= warninghealth)
				self.healthwarning.alpha = 1;
			else
				self.healthwarning.alpha = 0;
			width = int(self.zombiehealth/self.zombiemaxhealth*128);
			if(width <= 0)
				width = 1;
			green = (self.zombiehealth/self.zombiemaxhealth);
				red = (1 - green);
			self.healthbar setShader("white", width, 6);
			self.healthbar.color = (red,green,0);
			self.healthnum setValue(self.zombiehealth);
		}
	}
}