#include common_scripts\utility;
#include maps\mp\_utility1;
#include maps\mp\gametypes\_hud_util;
#include AImod\_OtherFunctions;
#include AImod\_zombie_spawns;

PickLevelModel()
{
	/* 
	0 = Arabian Models 
	1 = Arctic Models 
	2 = Airborne Models
	3 = Militia Models
	0 = TF141 Forest Models 
	1 = TF141 Desert Models 
	2 = TF141 Arctic Models
	3 = US Army Models
	4 = Seal Udt Models
	*/
	switch(getDvar("mapname"))
	{
		case "mp_afghan":
		level.zombieModel = 0;
		break;
		case "mp_derail":
		level.zombieModel = 1;
		break;
		case "mp_estate":
		level.zombieModel = 2;
		break;
		case "mp_favela":
		level.zombieModel = 3;
		break;
		case "mp_highrise":
		level.zombieModel = 2;
		break;
		case "mp_invasion":
		level.zombieModel = 0;
		break;
		case "mp_checkpoint":
		level.zombieModel = 0;
		break;
		case "mp_quarry":
		level.zombieModel = 3;
		break;
		case "mp_rundown":
		level.zombieModel = 3;
		break;
		case "mp_rust":
		level.zombieModel = 0;
		break;
		case "mp_boneyard":
		level.zombieModel = 0;
		break;
		case "mp_nightshift":
		level.zombieModel = 2;
		break;
		case "mp_subbase":
		level.zombieModel = 1;
		break;
		case "mp_terminal":
		level.zombieModel = 2;
		break;
		case "mp_underpass":
		level.zombieModel = 3;
		break;
		case "mp_brecourt":
		level.zombieModel = 2;
		break;
		case "mp_complex":
		level.zombieModel = 2;
		break;
		case "mp_crash":
		level.zombieModel = 0;
		break;
		case "mp_overgrown":
		level.zombieModel = 2;
		break;
		case "mp_compact":
		level.zombieModel = 1;
		break;
		case "mp_storm":
		level.zombieModel = 2;
		break;
		case "mp_abandon":
		level.zombieModel = 3;
		break;
		case "mp_fuel2":
		level.zombieModel = 0;
		break;
		case "mp_strike":
		level.zombieModel = 0;
		break;
		case "mp_trailerpark":
		level.zombieModel = 0;
		break;
		case "mp_vacant":
		level.zombieModel = 2;
		break;
		case "estate":
		level.zombieModel = 2;
		break;
		case "arcadia":
		level.zombieModel = 2;
		break;
		case "airport":
		level.zombieModel = 2;
		break;
		case "co_hunted":
		level.zombieModel = 2;
		break;
		case "oilrig":
		level.zombieModel = 1;
		break;
	}
	switch(getDvar("mapname"))
	{
		case "mp_afghan":
		level.friendlyModel = 1;
		break;
		case "mp_derail":
		level.friendlyModel = 2;
		break;
		case "mp_estate":
		level.friendlyModel = 0;
		break;
		case "mp_favela":
		level.friendlyModel = 1;
		break;
		case "mp_highrise":
		level.friendlyModel = 3;
		break;
		case "mp_invasion":
		level.friendlyModel = 3;
		break;
		case "mp_checkpoint":
		level.friendlyModel = 4;
		break;
		case "mp_quarry":
		level.friendlyModel = 1;
		break;
		case "mp_rundown":
		level.friendlyModel = 1;
		break;
		case "mp_rust":
		level.friendlyModel = 1;
		break;
		case "mp_boneyard":
		level.friendlyModel = 1;
		break;
		case "mp_nightshift":
		level.friendlyModel = 3;
		break;
		case "mp_subbase":
		level.friendlyModel = 4;
		break;
		case "mp_terminal":
		level.friendlyModel = 3;
		break;
		case "mp_underpass":
		level.friendlyModel = 1;
		break;
		case "mp_brecourt":
		level.friendlyModel = 0;
		break;
		case "mp_complex":
		level.friendlyModel = 3;
		break;
		case "mp_crash":
		level.friendlyModel = 1;
		break;
		case "mp_overgrown":
		level.friendlyModel = 0;
		break;
		case "mp_compact":
		level.friendlyModel = 2;
		break;
		case "mp_storm":
		level.friendlyModel = 1;
		break;
		case "mp_abandon":
		level.friendlyModel = 3;
		break;
		case "mp_fuel2":
		level.friendlyModel = 3;
		break;
		case "mp_strike":
		level.friendlyModel = 3;
		break;
		case "mp_trailerpark":
		level.friendlyModel = 3;
		break;
		case "mp_vacant":
		level.friendlyModel = 3;
		break;
		case "estate":
		level.friendlyModel = 0;
		break;
		case "arcadia":
		level.friendlyModel = 3;
		break;
		case "airport":
		level.friendlyModel = 3;
		break;
		case "co_hunted":
		level.friendlyModel = 0;
		break;
		case "oilrig":
		level.friendlyModel = 4;
		break;
	}
}

ZombieCount()
{
	zombCount = 0;
	for(i = 0;i < level.BotsForWave;i++)
	{
		if(isDefined(level.bots[i]) && level.bots[i].crate1.health >= 1 && level.bots[i].pers["isAlive"] == "true") 
			zombCount++;
	}
	return zombCount;
}

SpawnTrigger(Torigin, gotoOrigin, width, height, map_name)
{
	trig = spawn("trigger_radius", Torigin,0,width,height);
	trig.goto = gotoOrigin;
	trig thread waitfortrig(map_name);
	return trig;
}

waitfortrig(map_name)
{
	while(getdvar("mapname") == map_name)
	{
		self waittill("trigger",player);
		if(player.sessionstate != "playing") 
		{
			continue;
		}
		player setOrigin(self.goto);
		player iPrintlnBold("Anti-Glitch");
		wait 0.05;
	}
}

GetMapSpawnPoint( )
{
	level endon("game_ended");
	waypoint = [];
	switch( getDvar("mapname") )
	{
		case "mp_afghan":
		if(level.edit == 0)
		{
			waypoint[waypoint.size] = (-3883,-553,-1448);
			waypoint[waypoint.size] = (-3975,3,-1448);
			waypoint[waypoint.size] = (-3828,-1164,-1448);
			waypoint[waypoint.size] = (-4523,1006,-1449);
			waypoint[waypoint.size] = (-4422,1209,-1449);
		}
		else if(level.edit == 1)
		{
			waypoint[waypoint.size] = (9201,1505,120);
			waypoint[waypoint.size] = (8659,1252,100);
			waypoint[waypoint.size] = (8356,1223,59);
			waypoint[waypoint.size] = (7308,2900,36);
			waypoint[waypoint.size] = (7260,2234,-51);
		}
		break;
		case "mp_highrise": 
		if(level.edit == 0)
		{
			waypoint[waypoint.size] = (-2727,11367,2275);
			waypoint[waypoint.size] = (-1677,11280,2179);
			waypoint[waypoint.size] = (-1684,11124,2179);
			waypoint[waypoint.size] = (-558,9998,2179);
			waypoint[waypoint.size] = (-2362,11359,2275);
		}
		else if(level.edit == 1)
		{
			waypoint[waypoint.size] = ZombieSpawnsHighrise2(level.progressmap);
		}
		break;
		case "mp_quarry":
		{
			waypoint[waypoint.size] = (-1327,1228,912);
			waypoint[waypoint.size] = (-1323,1105,912);
			waypoint[waypoint.size] = (-1324,1023,912);
		}
		break;
		case "mp_brecourt":
		{
			waypoint[waypoint.size] = (10961,6828,358);
			waypoint[waypoint.size] = (10955,6688,358);
			waypoint[waypoint.size] = (9850,8886,358);
			waypoint[waypoint.size] = (9693,8883,358);
			waypoint[waypoint.size] = (12867,7423,1486);
			waypoint[waypoint.size] = (12856,7070,1486);
		}
		break;
		case "mp_rust": 
		if(level.edit == 0)
		{
			waypoint[waypoint.size] = (3703,-6900,-220);
			waypoint[waypoint.size] = (2638,-6917,-258);
			waypoint[waypoint.size] = (2524,-6328,-231);
			waypoint[waypoint.size] = (4281,-10529,-162);
			waypoint[waypoint.size] = (4489,-10224,-199);
			waypoint[waypoint.size] = (-1342,-9528,-243);
			waypoint[waypoint.size] = (-1294,-9813,-191);
			waypoint[waypoint.size] = (-1165,-9661,-213);
		}
		else if(level.edit == 1)
		{
			waypoint[waypoint.size] = (532,-9970,-75);
			waypoint[waypoint.size] = (842,-10000,-92);
			waypoint[waypoint.size] = (1154,-9684,-131);
			waypoint[waypoint.size] = (1483,-9520,-164);
			waypoint[waypoint.size] = (-651,-5268,-201);
			waypoint[waypoint.size] = (-712,-5424,-217);
			waypoint[waypoint.size] = (-2660,-6704,-252);
			waypoint[waypoint.size] = (-2775,-7030,-245);
		}
		else if(level.edit == 2)
		{
			waypoint[waypoint.size] = (579,-1930,-166);
			waypoint[waypoint.size] = (783,-1575,-223);
			waypoint[waypoint.size] = (103,-1115,-243);
			waypoint[waypoint.size] = (-710,-2793,-255);
			waypoint[waypoint.size] = (-431,-2856,-221);
			waypoint[waypoint.size] = (-1635,-2680,-113);
			waypoint[waypoint.size] = (-3075,-2165,47);
			waypoint[waypoint.size] = (-3283,-1893,69);
			waypoint[waypoint.size] = (-3376,-1452,29);
			waypoint[waypoint.size] = (-2028,145,-248);
		}
		break;
		case "mp_terminal":
		{
			waypoint[waypoint.size] = (2814,2838,63);
			waypoint[waypoint.size] = (45,4253,51);
			waypoint[waypoint.size] = (11,4157,51);
			waypoint[waypoint.size] = (2917,3983,95);
			waypoint[waypoint.size] = (2426,4398,198);
		}
		break;
		case "mp_boneyard":
		{
			waypoint[waypoint.size] = (-674,-3297,-12);
			waypoint[waypoint.size] = (1287,-2771,-52);
			waypoint[waypoint.size] = (1268,-2908,-52);
			waypoint[waypoint.size] = (1205,-2046,-52);
			waypoint[waypoint.size] = (1440,-4082,-52);
			waypoint[waypoint.size] = (-1036,-3259,-12);
			waypoint[waypoint.size] = (-1212,-2318,-7);
		}
		break;
		case "mp_underpass":
		{
			waypoint[waypoint.size] = (2811,3147,400);
			waypoint[waypoint.size] = (3009,2663,424);
			waypoint[waypoint.size] = (2799,2946,395);
			waypoint[waypoint.size] = (4036,3602,432);
		}
		break;
		case "mp_derail":
		if(level.edit == 0)
		{
			waypoint[waypoint.size] = (981,3216,192);
			waypoint[waypoint.size] = (1042,3240,192);
			waypoint[waypoint.size] = (914,1633,198);
			waypoint[waypoint.size] = (933,1567,176);
			waypoint[waypoint.size] = (2760,819,186);
			waypoint[waypoint.size] = (2987,823,188);
			waypoint[waypoint.size] = (2541,3475,247);
			waypoint[waypoint.size] = (1695,2781,129);
		}
		if(level.edit == 1)
		{
			waypoint[waypoint.size] = (779,-3849,143);
			waypoint[waypoint.size] = (848,-3842,141);
			waypoint[waypoint.size] = (925,-3820,142);
			waypoint[waypoint.size] = (843,-4019,139);
			waypoint[waypoint.size] = (576,-4018,125);
			waypoint[waypoint.size] = (1063,-4184,136);
		}
		break;
		case "mp_nightshift": 
		if(level.edit == 0)
		{
			waypoint[waypoint.size] = (-103,-1894,11);
			waypoint[waypoint.size] = (48,927,91);
			waypoint[waypoint.size] = (48,805,91);
			waypoint[waypoint.size] = (-1856,-2192,11);
			waypoint[waypoint.size] = (-1803,-2203,16);
			waypoint[waypoint.size] = (-323,-713,7);
			waypoint[waypoint.size] = (-364,-538,7);
		}
		else if(level.edit == 1)
		{
			waypoint[waypoint.size] = (-610,-1922,16);
			waypoint[waypoint.size] = (1904,-1258,3);
			waypoint[waypoint.size] = (-205,-745,16);
			waypoint[waypoint.size] = (-107,672,24);
			waypoint[waypoint.size] = (-6,593,24);
			waypoint[waypoint.size] = (-611,-1873,16);
		}
		else if(level.edit == 2)
		{
			waypoint[waypoint.size] = (1963,-3377,8);
			waypoint[waypoint.size] = (1740,-3359,16);
			waypoint[waypoint.size] = (1666,-3366,16);
			waypoint[waypoint.size] = (1599,-3368,16);
		}
		break;
		case "mp_estate":
		{
			waypoint[waypoint.size] = (-2602,-2388,-490);
			waypoint[waypoint.size] = (-2698,-2395,-491);
			waypoint[waypoint.size] = (-2771,-2384,-489);
			waypoint[waypoint.size] = (-4069,-5,106);
			waypoint[waypoint.size] = (-4164,-81,100);
			waypoint[waypoint.size] = (-2316,-2096,-610);
		}
		break;
		case "mp_favela":
		if(level.edit == 0)
		{
			waypoint[waypoint.size] = (2951,3108,296);
			waypoint[waypoint.size] = (2892,3025,296);
			waypoint[waypoint.size] = (2699,3120,296);
		}
		if(level.edit == 1)
		{
			waypoint[waypoint.size] = (-4460,549,-854);
			waypoint[waypoint.size] = (-4764,1051,-877);
			waypoint[waypoint.size] = (-4945,1542,-901);
			waypoint[waypoint.size] = (-5048,2363,-935);
			waypoint[waypoint.size] = (-5257,2878,-966);
		}
		if(level.edit == 2)
		{
			waypoint[waypoint.size] = (-1875,-7895,-820);
			waypoint[waypoint.size] = (-2368,-7172,-820);
			waypoint[waypoint.size] = (-2979,-7269,-820);
			waypoint[waypoint.size] = (-2591,-7756,-820);
			waypoint[waypoint.size] = (-4692,-9608,-418);
		}
		break;
		case "mp_invasion":
		{
			waypoint[waypoint.size] = (4707,12271,4);
			waypoint[waypoint.size] = (4656,11899,9);
			waypoint[waypoint.size] = (4139,11325,-37);
			waypoint[waypoint.size] = (2401,8462,16);
			waypoint[waypoint.size] = (2460,8366,16);
		}
		break;
		case "mp_checkpoint":
		{
			waypoint[waypoint.size] = (2584,5298,-15);
			waypoint[waypoint.size] = (2280,5295,-15);
			waypoint[waypoint.size] = (-42,3239,16);
			waypoint[waypoint.size] = (-39,3020,16);
			waypoint[waypoint.size] = (4030,2730,-28);
			waypoint[waypoint.size] = (4083,3150,-28);
			waypoint[waypoint.size] = (-68,2785,19);
			waypoint[waypoint.size] = (4308,2511,3);
		}
		break;
		case "mp_subbase":
		{
			waypoint[waypoint.size] = (-422,-6429,16);
			waypoint[waypoint.size] = (-339,-6430,16);
			waypoint[waypoint.size] = (-252,-6434,16);
		}
		break;
		case "mp_trailerpark":
		{
			waypoint[waypoint.size] = (2772,-2118,16);
			waypoint[waypoint.size] = (2785,-2068,16);
			waypoint[waypoint.size] = (2754,-1988,17);
			waypoint[waypoint.size] = (-1299,-2064,16);
			waypoint[waypoint.size] = (-1176,-1980,16);
			waypoint[waypoint.size] = (-1203,-2142,16);
		}
		break;
		case "mp_rundown":
		{
			waypoint[waypoint.size] = (445,1859,121);
			waypoint[waypoint.size] = (1581,2081,-5);
			waypoint[waypoint.size] = (-86,2560,146);
			waypoint[waypoint.size] = (117,2234,213);
			waypoint[waypoint.size] = (514,3748,41);
		}
		break;
		case "mp_compact":
		{
			waypoint[waypoint.size] = (3764,2701,285);
			waypoint[waypoint.size] = (1050,2000,116);
			waypoint[waypoint.size] = (1072,1943,133);
			waypoint[waypoint.size] = (3763,2759,285);
		}
		break;
		case "mp_strike":
		{
			waypoint[waypoint.size] = (-3888,1311,17);
			waypoint[waypoint.size] = (-3879,1459,16);
		}
		break;
		case "mp_complex":
		{
			waypoint[waypoint.size] = (197,-1142,416);
			waypoint[waypoint.size] = (-577,692,402);
			waypoint[waypoint.size] = (1369,744,395);
			waypoint[waypoint.size] = (-2105,-164,412);
			waypoint[waypoint.size] = (-2076,-426,412);
			waypoint[waypoint.size] = (-1925,-1220,412);
		}
		break;
		case "mp_abandon":
		{
			waypoint[waypoint.size] = (-1249,1119,3);
			waypoint[waypoint.size] = (-2064,1635,3);
			waypoint[waypoint.size] = (-1143,1217,3);
			waypoint[waypoint.size] = (-842,2015,3);
			waypoint[waypoint.size] = (-290,3437,3);
			waypoint[waypoint.size] = (-829,4036,3);
			waypoint[waypoint.size] = (-2844,5341,3);
			waypoint[waypoint.size] = (-3144,5303,3);
			waypoint[waypoint.size] = (-3674,4526,3);
			waypoint[waypoint.size] = (-4415,3575,3);
			waypoint[waypoint.size] = (-4112,1326,1);
			waypoint[waypoint.size] = (-3793,1030,1);
			waypoint[waypoint.size] = (-3395,777,1);
		}
		break;
		case "mp_vacant":
		{
			waypoint[waypoint.size] = (-1768,1765,-87);
			waypoint[waypoint.size] = (-1830,1769,-87);
			waypoint[waypoint.size] = (-734,1782,-97);
			waypoint[waypoint.size] = (68,-1375,-88);
			waypoint[waypoint.size] = (494,-1189,-85);
			waypoint[waypoint.size] = (-972,-1366,-91);
		}
		break;
		case "mp_storm":
		{
			waypoint[waypoint.size] = (5136,-1295,48);
			waypoint[waypoint.size] = (5120,-1105,48);
			waypoint[waypoint.size] = (4957,851,-47);
			waypoint[waypoint.size] = (4787,794,-48);
			waypoint[waypoint.size] = (2851,-1777,8);
			waypoint[waypoint.size] = (4210,-837,8);
		}
		break;
		case "mp_fuel2":
		{
			waypoint[waypoint.size] = (-5488,3207,-125);
			waypoint[waypoint.size] = (-5784,3263,-125);
			waypoint[waypoint.size] = (-6124,3322,-125);
			waypoint[waypoint.size] = (-6633,3433,-128);
			waypoint[waypoint.size] = (-5712,3658,-125);
			waypoint[waypoint.size] = (-5319,3649,-125);
		}
		break;
		case "mp_overgrown":
		{
			waypoint[waypoint.size] = (-2766,-6210,-143);
			waypoint[waypoint.size] = (-2773,-6079,-143);
			waypoint[waypoint.size] = (-2766,-5974,-143);
			waypoint[waypoint.size] = (-2764,-5577,-144);
			waypoint[waypoint.size] = (-1999,-6752,-143);
			waypoint[waypoint.size] = (-1461,-6547,-144);
			waypoint[waypoint.size] = (-1169,-6295,-144);
			waypoint[waypoint.size] = (-879,-6137,-150);
			waypoint[waypoint.size] = (-1522,-6546,-144);
		}
		break;
		case "mp_crash":
		{
			waypoint[waypoint.size] = (-908,-3844,61);
			waypoint[waypoint.size] = (-1052,-3826,61);
			waypoint[waypoint.size] = (-1156,-3821,62);
			waypoint[waypoint.size] = (-426,-1637,88);
			waypoint[waypoint.size] = (-472,-1567,93);
			waypoint[waypoint.size] = (-436,-1701,88);
		}
		break;
		case "estate":
		{
			waypoint[waypoint.size] = (946,147,184);
			waypoint[waypoint.size] = (515,1031,168);
			waypoint[waypoint.size] = (469,1038,168);
			waypoint[waypoint.size] = (325,-537,23);
			waypoint[waypoint.size] = (269,-529,23);
			waypoint[waypoint.size] = (834,653,33);
		}
		break;
		case "arcadia":
		{
			waypoint[waypoint.size] = (2797,-6722,2388);
			waypoint[waypoint.size] = (2758,-6797,2388);
			waypoint[waypoint.size] = (2726,-6861,2388);
			waypoint[waypoint.size] = (5439,-8426,2385);
			waypoint[waypoint.size] = (5482,-8351,2388);
			waypoint[waypoint.size] = (5533,-8248,2388);
		}
		break;
		case "airport":
		{
			waypoint[waypoint.size] = (-4823,3246,107);
			waypoint[waypoint.size] = (-4792,2698,-52);
			waypoint[waypoint.size] = (-5588,3342,-52);
		}
		break;
		case "co_hunted":
		{
			waypoint[waypoint.size] = (3206,8298,196);
			waypoint[waypoint.size] = (1719,9493,239);
			waypoint[waypoint.size] = (4378,9375,147);
			waypoint[waypoint.size] = (4656,8803,131);
		}
		break;
		case "oilrig":
		{
			waypoint[waypoint.size] = (1080,1205,-1383);
			waypoint[waypoint.size] = (1069,1026,-1379);
			waypoint[waypoint.size] = (1006,790,-1383);
			waypoint[waypoint.size] = (820,619,-1383);
		}
		break;
	}
	waypoint = waypoint[randomInt(waypoint.size)];
	return Waypoint;
}

GetHeadSpawnModelZombie( )
{
	/* 
	0 = Arabian Models 
	1 = Arctic Models 
	2 = Airborne Models
	3 = Militia Models
	0 = TF141 Forest Models 
	1 = TF141 Desert Models 
	2 = TF141 Arctic Models
	3 = US Army Models
	4 = Seal Udt Models
	*/
	rModel = undefined;
	switch(level.zombieModel)
	{
		case 0:
		switch(randomInt(5))
		{
			case 0: rModel = "head_opforce_arab_a";
			break;
			case 1: rModel = "head_opforce_arab_b";
			break;
			case 2: rModel = "head_opforce_arab_c";
			break;
			case 3: rModel = "head_opforce_arab_d_hat";
			break;
			case 4: rModel = "head_opforce_arab_e";
			break;
		}
		break;
		case 1:
		switch(randomInt(4))
		{
			case 0: rModel = "head_opforce_arctic_a";
			break;
			case 1: rModel = "head_opforce_arctic_b";
			break;
			case 2: rModel = "head_opforce_arctic_c";
			break;
			case 3: rModel = "head_opforce_arctic_d";
			break;
		}
		break;
		case 2:
		switch(randomInt(5))
		{
			case 0: rModel = "head_airborne_a";
			break;
			case 1: rModel = "head_airborne_b";
			break;
			case 2: rModel = "head_airborne_c";
			break;
			case 3: rModel = "head_airborne_d";
			break;
			case 4: rModel = "head_airborne_e";
			break;
		}
		break;
		case 3:
		switch(randomInt(4))
		{
			case 0: rModel = "head_militia_ba_blk";
			break;
			case 1: rModel = "head_militia_bb_blk_hat";
			break;
			case 2: rModel = "head_militia_bc_blk";
			break;
			case 3: rModel = "head_militia_bd_blk";
			break;
		}
		break;
	}
	return rModel;
}

GetBossSpawnModel( )
{
	/* 
	0 = Arabian Models 
	1 = Arctic Models 
	2 = Airborne Models
	3 = Militia Models
	0 = TF141 Forest Models 
	1 = TF141 Desert Models 
	2 = TF141 Arctic Models
	3 = US Army Models
	4 = Seal Udt Models
	*/
	rModel = undefined;
	switch(level.zombieModel)
	{
		case 0:
		rModel = "mp_body_riot_op_arab";
		break;
		case 1:
		rModel = "mp_body_riot_op_arctic";
		break;
		case 2:
		rModel = "mp_body_riot_op_airborne";
		break;
		case 3:
		rModel = "mp_body_riot_op_militia";
		break;
	}
	return rModel;
}

GetBossHeadSpawnModel( )
{
	/* 
	0 = Arabian Models 
	1 = Arctic Models 
	2 = Airborne Models
	3 = Militia Models
	0 = TF141 Forest Models 
	1 = TF141 Desert Models 
	2 = TF141 Arctic Models
	3 = US Army Models
	4 = Seal Udt Models
	*/
	rModel = undefined;
	switch(level.zombieModel)
	{
		case 0:
		rModel = "head_riot_op_arab";
		break;
		case 1:
		rModel = "head_riot_op_arctic";
		break;
		case 2:
		rModel = "head_riot_op_airborne";
		break;
		case 3:
		rModel = "head_riot_op_militia";
		break;
	}
	return rModel;
}

GetCrawlerHeadModel( )
{
	level endon("game_ended");
	rModel = "";
	switch( getDvar("mapname") )
	{
		case "mp_underpass": rModel = "head_op_sniper_ghillie_forest";
		break;
		case "mp_quarry": rModel = "head_allies_sniper_ghillie_desert";
		break;
		case "mp_afghan": rModel = "head_allies_sniper_ghillie_desert";
		break;
		case "mp_strike": rModel = "head_allies_sniper_ghillie_desert";
		break;
		case "mp_rust": rModel = "head_allies_sniper_ghillie_desert";
		break;
		case "mp_boneyard": rModel = "head_allies_sniper_ghillie_desert";
		break;
		case "mp_trailerpark": rModel = "head_opforce_arab_d_hat";
		break;
		case "mp_derail": rModel = "head_allies_sniper_ghillie_arctic";
		break;
		case "mp_compact": rModel = "head_opforce_arctic_c";
		break;
		case "mp_highrise": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "mp_terminal": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "mp_complex": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "mp_brecourt": rModel = "head_allies_sniper_ghillie_forest";
		break;
		case "mp_nightshift": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "mp_estate": rModel = "head_allies_sniper_ghillie_forest";
		break;
		case "mp_favela": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "mp_invasion": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "mp_checkpoint": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "mp_subbase": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "mp_rundown": rModel = "head_allies_sniper_ghillie_desert";
		break;
		case "mp_abandon": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "mp_vacant": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "mp_storm": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "mp_fuel2": rModel = "head_allies_sniper_ghillie_desert";
		break;
		case "mp_overgrown": rModel = "head_allies_sniper_ghillie_forest";
		break;
		case "mp_crash": rModel = "head_allies_sniper_ghillie_urban";
		break;
		case "estate": rModel = "head_allies_sniper_ghillie_forest";
		break;
		case "arcadia": rModel = "head_allies_sniper_ghillie_urban";
		break;
	}
	return rModel;
}

GetCrawlerSpawnModel( )
{
	level endon("game_ended");
	rModel = "";
	switch( getDvar("mapname") )
	{
		case "mp_underpass": rModel = "mp_body_op_sniper_ghillie_forest";
		break;
		case "mp_quarry": rModel = "mp_body_ally_sniper_ghillie_desert";
		break;
		case "mp_afghan": rModel = "mp_body_ally_sniper_ghillie_desert";
		break;
		case "mp_strike": rModel = "mp_body_ally_sniper_ghillie_desert";
		break;
		case "mp_rust": rModel = "mp_body_ally_sniper_ghillie_desert";
		break;
		case "mp_boneyard": rModel = "mp_body_ally_sniper_ghillie_desert";
		break;
		case "mp_trailerpark": rModel = "mp_body_opforce_arab_lmg_a";
		break;
		case "mp_derail": rModel = "mp_body_ally_sniper_ghillie_arctic";
		break;
		case "mp_compact": rModel = "mp_body_opforce_arctic_lmg_c";
		break;
		case "mp_highrise": rModel = "mp_body_ally_sniper_ghillie_urban";
		break;
		case "mp_terminal": rModel = "mp_body_ally_sniper_ghillie_urban";
		break;
		case "mp_complex": rModel = "mp_body_ally_sniper_ghillie_urban";
		break;
		case "mp_brecourt": rModel = "mp_body_ally_sniper_ghillie_forest";
		break;
		case "mp_nightshift": rModel = "mp_body_op_sniper_ghillie_urban";
		break;
		case "mp_estate": rModel = "mp_body_op_sniper_ghillie_forest";
		break;
		case "mp_favela": rModel = "mp_body_ally_sniper_ghillie_urban";
		break;
		case "mp_invasion": rModel = "mp_body_op_sniper_ghillie_urban";
		break;
		case "mp_checkpoint": rModel = "mp_body_ally_sniper_ghillie_urban";
		break;
		case "mp_subbase": rModel = "mp_body_ally_sniper_ghillie_urban";
		break;
		case "mp_rundown": rModel = "mp_body_ally_sniper_ghillie_desert";
		break;
		case "mp_abandon": rModel = "mp_body_ally_sniper_ghillie_urban";
		break;
		case "mp_vacant": rModel = "mp_body_op_sniper_ghillie_urban";
		break;
		case "mp_storm": rModel = "mp_body_op_sniper_ghillie_urban";
		break;
		case "mp_fuel2": rModel = "mp_body_ally_sniper_ghillie_desert";
		break;
		case "mp_overgrown": rModel = "mp_body_op_sniper_ghillie_forest";
		break;
		case "mp_crash": rModel = "mp_body_op_sniper_ghillie_urban";
		break;
		case "estate": rModel = "mp_body_op_sniper_ghillie_forest";
		break;
		case "arcadia": rModel = "mp_body_op_sniper_ghillie_urban";
		break;
	}
	return rModel;
}

GetSpawnModel( )
{
	/* 
	0 = Arabian Models 
	1 = Arctic Models 
	2 = Airborne Models
	3 = Militia Models
	0 = TF141 Forest Models 
	1 = TF141 Desert Models 
	2 = TF141 Arctic Models
	3 = US Army Models
	4 = Seal Udt Models
	*/
	rModel = undefined;
	switch(level.zombieModel)
	{
		case 0:
		switch(randomInt(4))
		{
			case 0: rModel = "mp_body_opforce_arab_lmg_a";
			break;
			case 1: rModel = "mp_body_opforce_arab_shotgun_a";
			break;
			case 2: rModel = "mp_body_opforce_arab_smg_a";
			break;
			case 3: rModel = "mp_body_opforce_arab_assault_a";
			break;
		}
		break;
		case 1:
		switch(randomInt(12))
		{
			case 0: rModel = "mp_body_opforce_arctic_lmg_c";
			break;
			case 1: rModel = "mp_body_opforce_arctic_assault_b";
			break;
			case 2: rModel = "mp_body_opforce_arctic_assault_c";
			break;
			case 3: rModel = "mp_body_opforce_arctic_lmg";
			break;
			case 4: rModel = "mp_body_opforce_arctic_lmg_b";
			break;
			case 5: rModel = "mp_body_opforce_arctic_shotgun";
			break;
			case 6: rModel = "mp_body_opforce_arctic_shotgun_b";
			break;
			case 7: rModel = "mp_body_opforce_arctic_shotgun_c";
			break;
			case 8: rModel = "mp_body_opforce_arctic_smg";
			break;
			case 9: rModel = "mp_body_opforce_arctic_smg_b";
			break;
			case 10: rModel = "mp_body_opforce_arctic_smg_c";
			break;
			case 11: rModel = "mp_body_opforce_arctic_assault_a";
			break;
		}
		break;
		case 2:
		switch(randomInt(12))
		{
			case 0: rModel = "mp_body_airborne_assault_a";
			break;
			case 1: rModel = "mp_body_airborne_assault_b";
			break;
			case 2: rModel = "mp_body_airborne_assault_c";
			break;
			case 3: rModel = "mp_body_airborne_lmg";
			break;
			case 4: rModel = "mp_body_airborne_lmg_b";
			break;
			case 5: rModel = "mp_body_airborne_lmg_c";
			break;
			case 6: rModel = "mp_body_airborne_shotgun";
			break;
			case 7: rModel = "mp_body_airborne_shotgun_b";
			break;
			case 8: rModel = "mp_body_airborne_shotgun_c";
			break;
			case 9: rModel = "mp_body_airborne_smg";
			break;
			case 10: rModel = "mp_body_airborne_smg_b";
			break;
			case 11: rModel = "mp_body_airborne_smg_c";
			break;
		}
		break;
		case 3:
		switch(randomInt(11))
		{
			case 0: rModel = "mp_body_militia_assault_aa_blk";
			break;
			case 1: rModel = "mp_body_militia_assault_aa_wht";
			break;
			case 2: rModel = "mp_body_militia_assault_ab_blk";
			break;
			case 3: rModel = "mp_body_militia_assault_ac_blk";
			break;
			case 4: rModel = "mp_body_militia_lmg_aa_blk";
			break;
			case 5: rModel = "mp_body_militia_lmg_ab_blk";
			break;
			case 6: rModel = "mp_body_militia_lmg_ac_blk";
			break;
			case 7: rModel = "mp_body_militia_smg_aa_blk";
			break;
			case 8: rModel = "mp_body_militia_smg_aa_wht";
			break;
			case 9: rModel = "mp_body_militia_smg_ab_blk";
			break;
			case 10: rModel = "mp_body_militia_smg_ac_blk";
			break;
		}
		break;
	}
	return rModel;
}

FriendlyModels()
{
	/* 
	0 = Arabian Models 
	1 = Arctic Models 
	2 = Airborne Models
	3 = Militia Models
	0 = TF141 Forest Models 
	1 = TF141 Desert Models 
	2 = TF141 Arctic Models
	3 = US Army Models
	4 = Seal Udt Models
	*/
	fModel = undefined;
	switch(level.friendlyModel)
	{
		case 0:
		switch(randomInt(5))
		{
			case 0: fModel = "mp_body_forest_tf141_assault_a";
			break;
			case 1: fModel = "mp_body_forest_tf141_assault_b";
			break;
			case 2: fModel = "mp_body_forest_tf141_lmg";
			break;
			case 3: fModel = "mp_body_forest_tf141_smg";
			break;
			case 4: fModel = "mp_body_forest_tf141_shotgun";
			break;
		}
		break;
		case 1:
		switch(randomInt(5))
		{
			case 0: fModel = "mp_body_desert_tf141_assault_a";
			break;
			case 1: fModel = "mp_body_desert_tf141_lmg";
			break;
			case 2: fModel = "mp_body_desert_tf141_smg";
			break;
			case 3: fModel = "mp_body_desert_tf141_shotgun";
			break;
			case 4: fModel = "mp_body_desert_tf141_assault_b";
			break;
		}
		break;
		case 2:
		switch(randomInt(5))
		{
			case 0: fModel = "mp_body_tf141_assault_a";
			break;
			case 1: fModel = "mp_body_tf141_assault_b";
			break;
			case 2: fModel = "mp_body_tf141_lmg";
			break;
			case 3: fModel = "mp_body_tf141_smg";
			break;
			case 4: fModel = "mp_body_tf141_shotgun";
			break;
		}
		break;
		case 3:
		switch(randomInt(12))
		{
			case 0: fModel = "mp_body_us_army_lmg";
			break;
			case 1: fModel = "mp_body_us_army_lmg_b";
			break;
			case 2: fModel = "mp_body_us_army_lmg_c";
			break;
			case 3: fModel = "mp_body_us_army_assault_a";
			break;
			case 4: fModel = "mp_body_us_army_assault_b";
			break;
			case 5: fModel = "mp_body_us_army_assault_c";
			break;
			case 6: fModel = "mp_body_us_army_shotgun";
			break;
			case 7: fModel = "mp_body_us_army_shotgun_b";
			break;
			case 8: fModel = "mp_body_us_army_shotgun_c";
			break;
			case 9: fModel = "mp_body_us_army_smg";
			break;
			case 10: fModel = "mp_body_us_army_smg_b";
			break;
			case 11: fModel = "mp_body_us_army_smg_c";
			break;
		}
		break;
		case 4:
		switch(randomInt(4))
		{
			case 0: fModel = "mp_body_seal_udt_lmg";
			break;
			case 1: fModel = "mp_body_seal_udt_assault_a";
			break;
			case 2: fModel = "mp_body_seal_udt_assault_b";
			break;
			case 3: fModel = "mp_body_seal_udt_smg";
			break;
		}
		break;
	}
	return fModel;
}

GetHeadSpawnModel( )
{
	/* 
	0 = Arabian Models 
	1 = Arctic Models 
	2 = Airborne Models
	3 = Militia Models
	0 = TF141 Forest Models 
	1 = TF141 Desert Models 
	2 = TF141 Arctic Models
	3 = US Army Models
	4 = Seal Udt Models
	*/
	rModel = undefined;
	switch(level.friendlyModel)
	{
		case 0:
		switch(randomInt(4))
		{
			case 0: rModel = "head_tf141_forest_a";
			break;
			case 1: rModel = "head_tf141_forest_b";
			break;
			case 2: rModel = "head_tf141_forest_c";
			break;
			case 3: rModel = "head_tf141_forest_d";
			break;
		}
		break;
		case 1:
		switch(randomInt(4))
		{
			case 0: rModel = "head_tf141_desert_a";
			break;
			case 1: rModel = "head_tf141_desert_b";
			break;
			case 2: rModel = "head_tf141_desert_c";
			break;
			case 3: rModel = "head_tf141_desert_d";
			break;
		}
		break;
		case 2:
		switch(randomInt(4))
		{
			case 0: rModel = "head_tf141_arctic_a";
			break;
			case 1: rModel = "head_tf141_arctic_b";
			break;
			case 2: rModel = "head_tf141_arctic_c";
			break;
			case 3: rModel = "head_tf141_arctic_d";
			break;
		}
		break;
		case 3:
		switch(randomInt(5))
		{
			case 0: rModel = "head_us_army_a";
			break;
			case 1: rModel = "head_us_army_b";
			break;
			case 2: rModel = "head_us_army_c";
			break;
			case 3: rModel = "head_us_army_d";
			break;
			case 4: rModel = "head_us_army_f";
			break;
		}
		break;
		case 4:
		switch(randomInt(4))
		{
			case 0: rModel = "head_seal_udt_a";
			break;
			case 1: rModel = "head_seal_udt_c";
			break;
			case 2: rModel = "head_seal_udt_d";
			break;
			case 3: rModel = "head_seal_udt_e";
			break;
		}
		break;
	}
	return rModel;
}

SpawnWeapon(weapName, coords, angles)
{
	point = spawn("script_origin", coords);
	weap = SpawnWeap(weapName, point.origin);
	if(isDefined(angles))
	{
		weap.angles = angles;
	}
	weap linkto( point );
	return point;
}

SpawnWeap(weapName, coords)
{
	return spawn( "weapon_" + weapName, coords + (0,0,5) );
}