#include common_scripts\utility;
#include maps\mp\_utility1;
#include maps\mp\gametypes\_hud_util;
#include AImod\_OtherFunctions;
#include AImod\_Bot;
#include AImod\animation;
#include AImod\_weapon;

BonusDrops()
{
    self endon("disconnect");
	self endon("bonus_end");
	self endon("bot_is_dead");
	random = randomInt(45);
	randomequels = randomInt(45);
	randomequels2 = randomInt(45);
	self waittill("bot_death");
	if(level.Wave <= 5)
	{
		if(random == randomequels)
		{
			switch(randomInt(7))
			{
			    case 0:
				FreezerDrop(self.origin, self.angles);
				break;
			    case 1:
				NukeDrop(self.origin, self.angles);
				break;
				case 2:
				MoneyDrop(self.origin, self.angles);
				break;
				case 3:
				AdrenalineDrop(self.origin, self.angles);
				break;
				case 4:
				InfiniteAmmoDrop(self.origin, self.angles);
				break;
				case 5:
				DeathMachineDrop(self.origin, self.angles);
				break;
				case 6:
				AmmoDrop(self.origin, self.angles);
				break;
			}
		}
	}
	if(level.Wave >= 5)
	{
		if(random == randomequels == randomequels2)
		{
			switch(randomInt(7))
			{
			    case 0:
				FreezerDrop(self.origin, self.angles);
				break;
			    case 1:
				NukeDrop(self.origin, self.angles);
				break;
				case 2:
				MoneyDrop(self.origin, self.angles);
				break;
				case 3:
				AdrenalineDrop(self.origin, self.angles);
				break;
				case 4:
				InfiniteAmmoDrop(self.origin, self.angles);
				break;
				case 5:
				DeathMachineDrop(self.origin, self.angles);
				break;
				case 6:
				AmmoDrop(self.origin, self.angles);
				break;
			}
		}
	}
}

AmmoDrop(pos, angle)
{
	block = spawn("script_model", pos + (0, 0, 20) );
	block setModel("com_plasticcase_friendly");
	block.angles = angle;
	block notSolid();
	block CloneBrushmodelToScriptmodel( level.airDropCrateCollision );
	block.headIcon = newHudElem();
	block.headIcon.x = block.origin[0];
	block.headIcon.y = block.origin[1];
	block.headIcon.z = block.origin[2] + 50;
	block.headIcon.alpha = 0.85;
	block.headIcon setShader( "waypoint_ammo_friendly", 10,10 );
	block.headIcon setWaypoint( true, true, false );
	trigger = spawn( "trigger_radius", pos, 0, 75, 50 );
	trigger.angles = angle;
	trigger thread AmmoDropThink(pos);
	trigger thread AmmoDropDestroy();
	block thread AmmoDropDestroy();
	block thread BonusDropAmmoTimerDestroy();
	block thread rotateBonusDrop();
	wait 0.01;
}

rotateBonusDrop()
{
	for(;;)
	{
		self rotateyaw(-360,5);
		wait(5);
	}
}

BonusDropAmmoTimerDestroy()
{
	self endon("ammo_drop_take");
	{
		wait 20;
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		level notify("ammo_drop_take");
	}
}

AmmoDropDestroy()
{
    {
		level waittill("ammo_drop_take");
		self delete();
		self.headIcon destroy();
	}
}

AmmoDropThink(pos, angle)
{
	self endon("disconnect");
	while(1)
	{
		self waittill( "trigger", player );
		if(Distance(pos, Player.origin) <= 75)
		{
			player thread MaxAmmo();
			level notify("ammo_drop_take");
			level notify("random_drop_destroy");
			wait 0.1;
		}
		wait 0.01;
	}
}

NukeDrop(pos, angle)
{
	block = spawn("script_model", pos + (0, 0, 50) );
	block setModel("projectile_cbu97_clusterbomb");
	block.angles = angle-(90,0,0);
	block CloneBrushmodelToScriptmodel( level.airDropCrateCollision );
	block setContents(0);
	block.headIcon = newHudElem();
	block.headIcon.x = block.origin[0];
	block.headIcon.y = block.origin[1];
	block.headIcon.z = block.origin[2] + 70;
	block.headIcon.alpha = 0.85;
	block.headIcon setShader( "dpad_killstreak_nuke", 10,10 );
	block.headIcon setWaypoint( true, true, false );
	block.headIcon thread NukeIconDestroy();
	trigger = spawn( "trigger_radius", pos, 0, 75, 50 );
	trigger.angles = angle;
	trigger thread NukeDropThink(pos, angle, block);
	trigger thread NukeDropDestroy();
	block thread NukeDropDestroy();
	block thread BonusDropNukeTimerDestroy();
	block thread rotateBonusDrop();
	block thread MoveNukeIcon(block.headIcon);
	wait 0.01;
}

BonusDropNukeTimerDestroy()
{
	self endon("nuke_drop_take");
	{
		wait 20;
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		level notify("nuke_drop_take");
	}
}

NukeDropDestroy()
{
	level waittill("nuke_drop_take");
	self delete();
	self.headIcon destroy();
}

MoveNukeIcon(entity)
{
	self endon("nuke_icon_destroy");
	for(;;)
	{
		entity.x = self.origin[0];
		entity.y = self.origin[1];
		entity.z = self.origin[2] + 70;
		wait 0.05;
	}
}

NukeIconDestroy()
{
	level waittill("nuke_icon_destroy");
	self destroy();
}

NukeDropThink(pos, angle, block)
{
	self endon("disconnect");
	while(1)
	{
		self waittill( "trigger", player );
		if(Distance(pos, Player.origin) <= 75)
		{
		    block playSound( "veh_mig29_sonic_boom" );
		    block MoveTo(pos+(0,0,20000),6);
			wait 6;
			block hide();
			wait 3;
			level thread maps\mp\killstreaks\_nuke::nukeEffects();
			if(getDvarInt("z_dedicated") == 0)
				setDvar("timescale", 0.5);
			foreach(player in level.players)
			{
				player playlocalsound( "nuke_explosion" );
				player playlocalsound( "nuke_wave" );
			}
			level notify("nuke_drop_kill");
			level notify("nuke_drop_take");
			level notify("random_drop_destroy");
			level notify("nuke_icon_destroy");
			self thread NukeKill();
			foreach(player in level.players)
			{
				earthquake(1,1.5, player.origin + (0,0,40), 60);
			}
			wait 1.5;
			if(getDvarInt("z_dedicated") == 0)
				setDvar("timescale", 1);
			wait 3.5;
			level notify("nuke_drop_end");
			foreach(player in level.players)
			{
			    player.money += 400;
				player thread maps\mp\gametypes\_rank::giveRankXP("zombie_kill", 10);
				player.xpearned += 10;
				player thread AImod\_Mod::TextPopup("Nuke");
				player thread AImod\_text::BonusDropText("Nuke!", 0.85, (25.5,25.5,25.5),(0.9,0.9,0.1),0.60); 
				player thread AImod\_text::BonusDropIcon("dpad_killstreak_nuke");
				player notify("MONEY");
				player thread maps\mp\gametypes\_rank::scorePopup( 400, 0, (0,1,0), 1 );
			}
		}
		wait 0.1;
	}
}

NukeKill()
{
    level endon("nuke_drop_end");
    while(1)
	{
	    level notify("nuke_drop_kill");
		wait 0.1;
	}
}

FreezerDrop(pos, angle)
{
	block = spawn("script_model", pos + (0, 0, 50) );
	block setModel("projectile_cbu97_clusterbomb");
	block.angles = angle-(90,0,0);
	block setContents(0);
	block CloneBrushmodelToScriptmodel( level.airDropCrateCollision );
	block.headIcon = newHudElem();
	block.headIcon.x = block.origin[0];
	block.headIcon.y = block.origin[1];
	block.headIcon.z = block.origin[2] + 70;
	block.headIcon.alpha = 0.85;
	block.headIcon setShader( "dpad_killstreak_emp", 10,10 );
	block.headIcon setWaypoint( true, true, false );
	block.headIcon.color = (0.1,0.9,0.9);
	block.headIcon thread FreezerIconDestroy();
	trigger = spawn( "trigger_radius", pos, 0, 75, 50 );
	trigger.angles = angle;
	trigger thread FreezerDropThink(pos, angle, block, trigger);
	trigger thread FreezerDropDestroy();
	block thread MoveFreezerIcon(block.headIcon);
	block thread BonusDropFreezerTimerDestroy();
	block thread rotateFreezerBonusDrop();
	block thread FreezerDropDestroy();
	wait 0.01;
}

BonusDropFreezerTimerDestroy()
{
	level endon("freeze_drop_take");
	{
		wait 20;
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		level notify("freeze_drop_notake");
	}
}

rotateFreezerBonusDrop()
{
    level endon("freeze_drop_take");
	for(;;)
	{
		self rotateyaw(-360,5);
		wait(5);
	}
}

MoveFreezerIcon(entity)
{
	self endon("freeze_drop");
	for(;;)
	{
		entity.x = self.origin[0];
		entity.y = self.origin[1];
		entity.z = self.origin[2] + 70;
		wait 0.05;
	}
}

FreezerIconDestroy()
{
	level waittill("freeze_drop");
	self destroy();
}

FreezerDropDestroy()
{
	level waittill("freeze_drop_notake");
	self delete();
	self.headIcon destroy();
}

FreezerDropThink(pos, angle, block, trigger)
{
	self endon("disconnect");
	while(1)
	{
		self waittill( "trigger", player );
		if(Distance(pos, Player.origin) <= 75)
		{
			trigger delete();
		    block playSound( "veh_mig29_sonic_boom" );
		    block MoveTo(pos+(0,0,4000),6);
			level notify("freeze_drop_take");
			level notify("random_drop_destroy");
			foreach(player in level.players)
			{
				player thread AImod\_text::BonusDropText("Freezer!", 0.85, (25.5,25.5,25.5),(0.1,0.9,0.9),0.60); 
				player thread AImod\_text::BonusDropIcon("dpad_killstreak_emp", (0.1,0.9,0.9));
			}
			wait 6;
			level notify("freeze_drop");
			block playSound( "emp_activate" );
			playFx(level.empfx,block.origin);
			level notify("freeze_drop_notake");
			level thread FreezeZombies();
			wait 10;
			level notify("freeze_over");
			level notify("freeze_model_gone");
			foreach(player in level.players)
			{
			    player.money += 200;
				player thread AImod\_Mod::TextPopup("Freezer");
				player notify("MONEY");
				player thread maps\mp\gametypes\_rank::scorePopup( 200, 0, (0,1,0), 1 );
			}
		}
		wait 0.1;
	}
}

FreezeZombies()
{
	for(i = 0; i < 15; i += 1)
	{
		foreach(zombie in level.bots)
		{
			if(zombie.pers["isAlive"] == "false")
				continue;
			
			zombie.freezed = 1;
			zombie.speed = 1;
		}
		wait 1;
	}
	foreach(zombie in level.bots)
	{
		if(zombie.pers["isAlive"] == "false")
			continue;
			
		zombie.freezed = 0;
		zombie.speed = zombie.speed2;
	}
}

InfiniteAmmoDrop(pos, angle)
{
	block = spawn("script_model", pos + (0, 0, 20) );
	block setModel("com_plasticcase_friendly");
	block.angles = angle;
	block notSolid();
	block CloneBrushmodelToScriptmodel( level.airDropCrateCollision );
	block.headIcon = newHudElem();
	block.headIcon.x = block.origin[0];
	block.headIcon.y = block.origin[1];
	block.headIcon.z = block.origin[2] + 50;
	block.headIcon.alpha = 0.85;
	block.headIcon setShader( "dpad_killstreak_sentry_gun", 10,10 );
	block.headIcon setWaypoint( true, true, false );
	trigger = spawn( "trigger_radius", pos, 0, 75, 50 );
	trigger.angles = angle;
	trigger thread InfiniteAmmoDropThink(pos);
	trigger thread InfiniteAmmoDropDestroy();
	block thread InfiniteAmmoDropDestroy();
	block thread BonusDropInfiniteAmmoTimerDestroy();
	block thread rotateBonusDrop();
	wait 0.01;
}

BonusDropInfiniteAmmoTimerDestroy()
{
	self endon("infinite_ammo_drop_take");
	{
		wait 20;
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		level notify("infinite_ammo_drop_take");
	}
}

InfiniteAmmoDropDestroy()
{
    {
		level waittill("infinite_ammo_drop_take");
		self delete();
		self.headIcon destroy();
	}
}
	
InfiniteAmmoDropThink(pos, angle)
{
	self endon("disconnect");
	while(1)
	{
		self waittill( "trigger", player );
		if(Distance(pos, Player.origin) <= 75)
		{
			foreach(player in level.players)
			{
				player thread InfiniteAmmo();
			}
			level notify("infinite_ammo_drop_take");
			level notify("random_drop_destroy");
			wait 0.1;
		}
		wait 0.1;
	}
}

AdrenalineDrop(pos, angle)
{
	block = spawn("script_model", pos + (0, 0, 20) );
	block setModel("com_plasticcase_friendly");
	block.angles = angle;
	block notSolid();
	block CloneBrushmodelToScriptmodel( level.airDropCrateCollision );
	block.headIcon = newHudElem();
	block.headIcon.x = block.origin[0];
	block.headIcon.y = block.origin[1];
	block.headIcon.z = block.origin[2] + 50;
	block.headIcon.alpha = 0.85;
	block.headIcon setShader( "cardicon_doubletap", 10,10 );
	block.headIcon setWaypoint( true, true, false );
	trigger = spawn( "trigger_radius", pos, 0, 75, 50 );
	trigger.angles = angle;
	trigger thread AdrenalineDropThink(pos);
	trigger thread AdrenalineDropDestroy();
	block thread AdrenalineDropDestroy();
	block thread BonusDropAdrenalineTimerDestroy();
	block thread rotateBonusDrop();
	wait 0.01;
}

BonusDropAdrenalineTimerDestroy()
{
	self endon("adrenaline_drop_take");
	{
		wait 20;
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		level notify("adrenaline_drop_take");
	}
}

AdrenalineDropDestroy()
{
    {
		level waittill("adrenaline_drop_take");
		self delete();
		self.headIcon destroy();
	}
}

AdrenalineDropThink(pos, angle)
{
	self endon("disconnect");
	while(1)
	{
		self waittill( "trigger", player );
		if(Distance(pos, Player.origin) <= 75)
		{
			foreach(player in level.players)
			{
				player thread Adrenaline();
			}
			level notify("adrenaline_drop_take");
			level notify("random_drop_destroy");
			wait 0.1;
		}
		wait 0.1;
	}
}

DeathMachineDrop(pos, angle)
{
	block = spawn("script_model", pos + (0, 0, 20) );
	block setModel("com_plasticcase_friendly");
	block.angles = angle;
	block notSolid();
	block CloneBrushmodelToScriptmodel( level.airDropCrateCollision );
	block.headIcon = newHudElem();
	block.headIcon.x = block.origin[0];
	block.headIcon.y = block.origin[1];
	block.headIcon.z = block.origin[2] + 50;
	block.headIcon.alpha = 0.85;
	block.headIcon setShader( "cardicon_skull", 10,10 );
	block.headIcon setWaypoint( true, true, false );
	trigger = spawn( "trigger_radius", pos, 0, 75, 50 );
	trigger.angles = angle;
	trigger thread DeathMachineDropThink(pos);
	trigger thread DeathMachineDropDestroy();
	block thread DeathMachineDropDestroy();
	block thread BonusDropDeathMachineTimerDestroy();
	block thread rotateBonusDrop();
	wait 0.01;
}

BonusDropDeathMachineTimerDestroy()
{
	self endon("deathmachine_drop_take");
	{
		wait 20;
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		level notify("deathmachine_drop_take");
	}
}

DeathMachineDropDestroy()
{
    {
		level waittill("deathmachine_drop_take");
		self delete();
		self.headIcon destroy();
	}
}

DeathMachineDropThink(pos, angle)
{
	self endon("disconnect");
	while(1)
	{
		self waittill( "trigger", player );
		if(Distance(pos, Player.origin) <= 75)
		{
			player thread DeathMachineStart();
			level notify("deathmachine_drop_take");
			level notify("random_drop_destroy");
		}
		wait 0.1;
	}
}

MoneyDrop(pos, angle)
{
	block = spawn("script_model", pos + (0, 0, 20) );
	block setModel("com_plasticcase_friendly");
	block.angles = angle;
	block notSolid();
	block CloneBrushmodelToScriptmodel( level.airDropCrateCollision );
	block.headIcon = newHudElem();
	block.headIcon.x = block.origin[0];
	block.headIcon.y = block.origin[1];
	block.headIcon.z = block.origin[2] + 50;
	block.headIcon.alpha = 0.85;
	block.headIcon setShader( "cardicon_gold", 10,10 );
	block.headIcon setWaypoint( true, true, false );
    trigger = spawn( "trigger_radius", pos, 0, 75, 50 );
    trigger.angles = angle;
	trigger thread MoneyDropThink(pos);
	trigger thread MoneyDropDestroy();
	block thread MoneyDropDestroy();
	block thread BonusDropMoneyTimerDestroy();
	block thread rotateBonusDrop();
    wait 0.01;
}

BonusDropMoneyTimerDestroy()
{
	self endon("money_drop_take");
	{
		wait 20;
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		wait 0.5;
		self hide();
		wait 0.5;
		self show();
		level notify("money_drop_take");
	}
}

MoneyDropDestroy()
{
    {
		level waittill("money_drop_take");
		self delete();
		self.headIcon destroy();
	}
}

MoneyDropThink(pos, angle)
{
	self endon("disconnect");
	while(1)
	{
		self waittill( "trigger", player );
		if(Distance(pos, Player.origin) <= 75)
		{
			player thread ExtraMoney();
			level notify("money_drop_take");
			level notify("random_drop_destroy");
			wait 0.1;
		}
		wait 0.1;
	}
}

InfiniteAmmo()
{ 
    level endon("disconnect");
	self endon("take_infiniteammo");
	{
	    self thread AImod\_Mod::TextPopup( "Infinite Ammo!" );
	    self thread AImod\_text::BonusDropText("Infinite Ammo!", 0.85, (25.5,25.5,25.5),(0.3,0.3,0.9),0.60); 
		self thread AImod\_text::BonusDropIcon("dpad_killstreak_sentry_gun");
	    self thread InfiniteAmmoStart();
		wait 15;
		self thread AImod\_text::BonusDropText("^1No more Infinite Ammo!", 0.85, (25.5,25.5,25.5),(0.9,0.3,0.3),0.60); 
		self thread AImod\_text::BonusDropIcon("dpad_killstreak_sentry_gun");
		self notify("take_infiniteammo");
		self notify("bonus_end");
		level.nobonus = 0;
	}
	wait 0.1;
}

BonusDropHud( text, waitdestroy )
{
	if(self.bonusdrophud == 1)
	{
		self.bonusdrophud1 = NewClientHudElem( self );
		self.bonusdrophud1.alignX = "center";
		self.bonusdrophud1.alignY = "middle";
		self.bonusdrophud1.horzAlign = "center";
		self.bonusdrophud1.vertAlign = "middle";
		self.bonusdrophud1.x = -350;
		self.bonusdrophud1.y = 140;
		self.bonusdrophud1.foreground = true;
		self.bonusdrophud1.fontScale = 0.750;
		self.bonusdrophud1.font = "hudbig";
		self.bonusdrophud1.alpha = 1;
		self.bonusdrophud1.fontscale = 0.75;
		self.bonusdrophud1.alpha = 0.85;
		self.bonusdrophud1 setText(text);
		self.bonushudtimer += 1;
		self waittill(waitdestroy);
		self.bonusdrophud1 destroy();
	}
	else if(self.bonusdrophud == 2)
	{
		self.bonusdrophud2 = NewClientHudElem( self );
		self.bonusdrophud2.alignX = "center";
		self.bonusdrophud2.alignY = "middle";
		self.bonusdrophud2.horzAlign = "center";
		self.bonusdrophud2.vertAlign = "middle";
		self.bonusdrophud2.x = -350;
		self.bonusdrophud2.y = 110;
		self.bonusdrophud2.foreground = true;
		self.bonusdrophud2.fontScale = 0.750;
		self.bonusdrophud2.font = "hudbig";
		self.bonusdrophud2.alpha = 1;
		self.bonusdrophud2.fontscale = 0.75;
		self.bonusdrophud2.alpha = 0.85;
		self.bonusdrophud2 setText(text);
		self.bonushudtimer += 1;
		self waittill(waitdestroy);
		self.bonusdrophud2 destroy();
	}
	else if(self.bonusdrophud == 3)
	{
		self.bonusdrophud3 = NewClientHudElem( self );
		self.bonusdrophud3.alignX = "center";
		self.bonusdrophud3.alignY = "middle";
		self.bonusdrophud3.horzAlign = "center";
		self.bonusdrophud3.vertAlign = "middle";
		self.bonusdrophud3.x = -350;
		self.bonusdrophud3.y = 80;
		self.bonusdrophud3.foreground = true;
		self.bonusdrophud3.fontScale = 0.750;
		self.bonusdrophud3.font = "hudbig";
		self.bonusdrophud3.alpha = 1;
		self.bonusdrophud3.fontscale = 0.75;
		self.bonusdrophud3.alpha = 0.85;
		self.bonusdrophud3 setText(text);
		self.bonushudtimer += 1;
		self waittill(waitdestroy);
		self.bonusdrophud3 destroy();
	}
	else if(self.bonusdrophud == 4)
	{
		self.bonusdrophud4 = NewClientHudElem( self );
		self.bonusdrophud4.alignX = "center";
		self.bonusdrophud4.alignY = "middle";
		self.bonusdrophud4.horzAlign = "center";
		self.bonusdrophud4.vertAlign = "middle";
		self.bonusdrophud4.x = -350;
		self.bonusdrophud4.y = 50;
		self.bonusdrophud4.foreground = true;
		self.bonusdrophud4.fontScale = 0.750;
		self.bonusdrophud4.font = "hudbig";
		self.bonusdrophud4.alpha = 1;
		self.bonusdrophud4.fontscale = 0.75;
		self.bonusdrophud4.alpha = 0.85;
		self.bonusdrophud4 setText(text);
		self.bonushudtimer += 1;
		self waittill(waitdestroy);
		self.bonusdrophud4 destroy();
	}
}

InfiniteAmmoStart()
{
	self endon("disconnect");
	self endon("take_infiniteammo");
	while(1)
	{
		currentWeapon = self getCurrentWeapon();
		if ( currentWeapon != "none" && self getCurrentWeapon() != "ac130_105mm_mp")
		{
			self setWeaponAmmoClip( currentWeapon, 9999, "right" );
			self setWeaponAmmoClip( currentWeapon, 9999, "left" );
		}
		currentoffhand = self GetCurrentOffhand() && self getCurrentWeapon() != "ac130_105mm_mp";
		if ( currentoffhand != "none" )
		{
			self setWeaponAmmoClip( currentoffhand, 9999, "right" );
			self setWeaponAmmoClip( currentoffhand, 9999, "left" );
		}
		self waittill( "weapon_fired" );
	}
}

MaxAmmo()
{ 
    level endon("disconnect");
    foreach(player in level.players)
	{
	    player thread AImod\_Mod::TextPopup( "Max Ammo!" );
	    player thread AImod\_text::BonusDropText("Max Ammo!", 0.85, (25.5,25.5,25.5),(0.7,0.7,0.3),0.60); 
		player thread AImod\_text::BonusDropIcon("waypoint_ammo_friendly");
		player playLocalSound("mp_level_up");
	    weaponList = self GetWeaponsListAll();
	
		foreach ( weaponName in weaponList )
		{
			if(weaponName == "beretta_akimbo_xmags_mp")
				continue;
		
			self giveMaxAmmo( weaponName );
		}	
		self notify("bonus_end");
		level.nobonus = 0;
	}
	wait 0.1;
}

ExtraMoney()
{ 
    level endon("disconnect");
    foreach(player in level.players)
	{
	    player thread AImod\_Mod::TextPopup( "Extra Cash!" );
		player playLocalSound("mp_level_up");
		player thread AImod\_text::BonusDropText("Extra Cash!", 0.85, (25.5,25.5,25.5),(0.3,0.9,0.3),0.60); 
		player thread AImod\_text::BonusDropIcon("cardicon_gold");
	    player.money += 1000;
		player notify("MONEY");
		self notify("bonus_end");
		level.nobonus = 0;
	}
	wait 0.1;
}

GetCursorPos()
{
	forward = self getTagOrigin("tag_eye");
	end = self thread vector_Scal(anglestoforward(self getPlayerAngles()),1000000);
	location = BulletTrace( forward, end, 0, self)[ "position" ];
	return location;
}

vector_scal(vec, scale) 
{
    vec = (vec[0] * scale, vec[1] * scale, vec[2] * scale);
    return vec;
}

DeathMachineStart()
{ 
    level endon("disconnect");
	self endon("no_deathmachine");
	{
	    self thread AImod\_Mod::TextPopup( "Death Machine!" );
		self thread AImod\_text::BonusDropText("Death Machine!", 0.85, (25.5,25.5,25.5),(0.3,0.3,0.9),0.60); 
		self thread AImod\_text::BonusDropIcon("hud_icon_m240");
		self playLocalSound("mp_level_up");
		self thread DeathMachine();
		self thread DeathMachineNoSwitch();
	    self giveWeapon( "m240_xmags_mp", 6, false);
		self switchToWeapon("m240_xmags_mp");
		self GiveMaxAmmo("m240_xmags_mp");
		self.bonusdrophud += 1;
		self.notusebox = 1;
		wait 30;
		self.notusebox = 0;
		self.bonusdrophud -= 1;
		self takeWeapon("m240_xmags_mp");
		wait 0.1;
		self switchtoRandomWeapon();
		self thread AImod\_text::BonusDropText("No more Death Machine!", 0.85, (25.5,25.5,25.5),(0.3,0.3,0.9),0.60); 
		self thread AImod\_text::BonusDropIcon("hud_icon_m240");
		self playLocalSound("mp_level_up");
		level notify("bonus_end");
		level.nobonus = 0;
		self notify("no_deathmachine");
	}
	wait 0.1;
}

DeathMachineAirdropStart()
{ 
    level endon("disconnect");
	self endon("no_deathmachine");
	{
	    self thread AImod\_Mod::TextPopup( "Death Machine!" );
	    self thread AImod\_text::BonusDropText("Death Machine!", 0.85, (25.5,25.5,25.5),(0.3,0.3,0.9),0.60); 
		self thread AImod\_text::BonusDropIcon("hud_icon_m240");
		self playLocalSound("mp_level_up");
		self thread DeathMachine();
		self thread DeathMachineNoSwitch();
	    self giveWeapon( "m240_xmags_mp", 6, false);
		self switchToWeapon("m240_xmags_mp");
		self GiveMaxAmmo("m240_xmags_mp");
		self.notusebox = 1;
		wait 60;
		self.notusebox = 0;
		self takeWeapon("m240_xmags_mp");
		wait 0.1;
		self switchtoRandomWeapon();
		self thread AImod\_text::BonusDropText("No more Death Machine!", 0.85, (25.5,25.5,25.5),(0.9,0.3,0.3),0.60); 
		self thread AImod\_text::BonusDropIcon("hud_icon_m240");
		self playLocalSound("mp_level_up");
		level notify("bonus_end");
		level.nobonus = 0;
		self notify("no_deathmachine");
	}
	wait 0.1;
}

DeamMachineAirDropThink(pos, angle)
{
	self endon("disconnect");
	while(1)
	{
		self waittill( "trigger", player );
		if(Distance(pos, Player.origin) <= 75)
		{
			foreach(player in level.players)
			{
				player thread DeathMachineAirdropStart();
			}
			level notify("random_drop_destroy");
			wait 0.1;
		}
		wait .8;
	}
}

DeathMachineNoSwitch()
{
    self endon("no_deathmachine");
    while(1)
	{
	    self switchToWeapon("m240_xmags_mp");
		wait 0.1;
	}
}

DeathMachine()
{
    self endon("death");
	self endon("no_deathmachine");
    for( ;; )
    {
        self waittill( "weapon_fired" );
        if ( self getCurrentWeapon() == "m240_xmags_mp" )
        {
			self GiveMaxAmmo("m240_xmags_mp");
			self setWeaponAmmoClip( "m240_xmags_mp", 200 );
        }
    }
}

Adrenaline()
{
	level endon("disconnect");
	if(self.speedreload == 1)
	{
		self thread AImod\_Mod::TextPopup( "Adrenaline!" );
		self thread AImod\_text::BonusDropText("Adrenaline!", 0.85, (25.5,25.5,25.5),(0.9,0.3,0.3),0.60); 
		self thread AImod\_text::BonusDropIcon("cardicon_doubletap");
		self playLocalSound("mp_level_up");
		if ( self _hasPerk( "specialty_lightweight" ) )
		{
			self.moveSpeedScaler = 1.25;
			self maps\mp\gametypes\_weapons::updateMoveSpeedScale( "primary" );
		}
		else
		{
			self.moveSpeedScaler = 1.2;
			self maps\mp\gametypes\_weapons::updateMoveSpeedScale( "primary" );
		}
		self.bonusdrophud += 1;
		wait 15;
		if ( self _hasPerk( "specialty_lightweight" ) )
		{
			self.moveSpeedScaler = 1.1;
			self maps\mp\gametypes\_weapons::updateMoveSpeedScale( "primary" );
		}
		else
		{
			self.moveSpeedScaler = 1.0;
			self maps\mp\gametypes\_weapons::updateMoveSpeedScale( "primary" );
		}
		self.bonusdrophud -= 1;
		self thread AImod\_text::BonusDropText("Adrenaline has ran out!", 0.85, (25.5,25.5,25.5),(0.9,0.3,0.3),0.60); 
		self thread AImod\_text::BonusDropIcon("cardicon_doubletap");
		self notify("adrenaline_out");
		level notify("bonus_end");
		level.nobonus = 0;
	}
	else if(self.speedreload == 0)
	{
		self thread AImod\_Mod::TextPopup( "Adrenaline!" );
		self thread AImod\_text::BonusDropText("Adrenaline!", 0.85, (25.5,25.5,25.5),(0.9,0.3,0.3),0.60); 
		self thread AImod\_text::BonusDropIcon("cardicon_doubletap");
		self playLocalSound("mp_level_up");
		self _setPerk("specialty_fastreload");
		self _setPerk("specialty_quickdraw");
		if ( self _hasPerk( "specialty_lightweight" ) )
		{
			self.moveSpeedScaler = 1.25;
			self maps\mp\gametypes\_weapons::updateMoveSpeedScale( "primary" );
		}
		else
		{
			self.moveSpeedScaler = 1.2;
			self maps\mp\gametypes\_weapons::updateMoveSpeedScale( "primary" );
		}
		wait 15;
		if ( self _hasPerk( "specialty_lightweight" ) )
		{
			self.moveSpeedScaler = 1.1;
			self maps\mp\gametypes\_weapons::updateMoveSpeedScale( "primary" );
		}
		else
		{
			self.moveSpeedScaler = 1.0;
			self maps\mp\gametypes\_weapons::updateMoveSpeedScale( "primary" );
		}
		self _unsetPerk("specialty_fastreload");
		self _unsetPerk("specialty_quickdraw");
		self thread AImod\_text::BonusDropText("Adrenaline has ran out!", 0.85, (25.5,25.5,25.5),(0.9,0.3,0.3),0.60); 
		self thread AImod\_text::BonusDropIcon("cardicon_doubletap");
		self notify("adrenaline_out");
		self notify("bonus_end");
		level.nobonus = 0;
	}
	wait 0.1;
}