//Mod created by ~indecii
//MW3 All or Nothing


#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;

doSpawn()
{
	self endon ("disconnect");
	self endon ("death");
}

doDvars()
{	
	self endon ("disconnect");
	self endon ("death");
	
	self maps\mp\killstreaks\_killstreaks::clearKillstreaks();
	self maps\mp\gametypes\_class::setKillstreaks( "none", "none", "none" );
	
	self thread doKillstreaks(); 
	
	self thread maps\mp\gametypes\_hud_message::hintMessage("^1Welcome to ^4All or Nothing");
	self thread maps\mp\gametypes\_hud_message::hintMessage("^3Mod Created by ^6indecii and incoherent");
	
	self takeAllWeapons();
	self giveWeapon( "usp_tactical_mp", 0, false);
	self SetWeaponAmmoStock("usp_tactical_mp", 0);
	self SetWeaponAmmoClip("usp_tactical_mp", 0);
	self maps\mp\perks\_perks::givePerk( "throwingknife_mp" );self setWeaponAmmoClip("throwingknife_mp", 100);
	while(self getCurrentWeapon() != "usp_tactical_mp")
		{
			self switchToWeapon("usp_tactical_mp");
			wait 0.1;
		}

	
	self clearPerks(); 
	self maps\mp\perks\_perks::givePerk("specialty_marathon");
	self maps\mp\perks\_perks::givePerk("specialty_lightweight"); 
	//no hardline but make up in custom killstreaks
	
	//set normal health
	self.maxhealth = 100;
	self.health = self.maxhealth;

}



init()
{

	level thread onPlayerConnect();
}

onPlayerConnect()
{
	for(;;)
	{
		level waittill( "connected", player );		
		player thread onPlayerSpawned();

	}
}



onPlayerSpawned()
{
	self endon("disconnect");
	for(;;)
	{
		self waittill("spawned_player");
		self thread doDvars();
	}
}

doKillstreaks()  
{
 self endon ("death");
 
 self.startscore = self.pers["kills"];
 
    while(1) {
        if(self.killcount != self.pers["kills"] - self.startscore) {
            self.killcount = self.pers["kills"] - self.startscore;
            switch(self.killcount) 
   {
   case 1:
    self iPrintlnBold( "^5Unlocked ^2Scavenger!" );
    self notify("newstreak");
	self maps\mp\perks\_perks::givePerk("specialty_scavenger");
    break;
    
   case 3:
    self notify("newstreak");
    self iPrintlnBold( "^5Unlocked ^2Quickdraw!" );
    self maps\mp\perks\_perks::givePerk("specialty_quickdraw");
    break;
    
   case 5:
    self notify("newstreak");
    self iPrintlnBold( "^5Unlocked ^2Steady Aim!" );
	self maps\mp\perks\_perks::givePerk("specialty_bulletaccuracy");
	break;
   case 7:
	self notify("newstreak");
    self iPrintlnBold( "^5Unlocked ^3all perks!" );
	self maps\mp\perks\_perks::givePerk("specialty_extendedmelee");
	self maps\mp\perks\_perks::givePerk("specialty_automantle");
	self maps\mp\perks\_perks::givePerk("specialty_spygame");
	self maps\mp\perks\_perks::givePerk("specialty_selectivehearing");
	self maps\mp\perks\_perks::givePerk("specialty_heartbreaker");
	self maps\mp\perks\_perks::givePerk("specialty_coldblooded");
	self maps\mp\perks\_perks::givePerk("specialty_jumpdive");
	self maps\mp\perks\_perks::givePerk("specialty_fastmantle");
	self maps\mp\perks\_perks::givePerk("specialty_bulletdamage");
	self maps\mp\perks\_perks::givePerk("specialty_detectexplosive");
	self maps\mp\perks\_perks::givePerk("specialty_quieter");
	self maps\mp\perks\_perks::givePerk("specialty_parabolic");
	self maps\mp\perks\_perks::givePerk("specialty_bulletpenetration");
	self maps\mp\perks\_perks::givePerk("specialty_fastreload");
	self maps\mp\perks\_perks::givePerk("specialty_gpsjammer");

	
	break;
    
            }
  }
        wait 0.05;
 }
}