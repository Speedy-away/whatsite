#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\_hud_message;

doIntelInit()
{
level thread doIntelConnected();
}
doIntelConnected()
{
	for(;;)
	{
		level waittill("connected", player );
		player thread onIntelSpawned();
	}
}
onIntelSpawned()
{
	for(;;)
	{
		self waittill("spawned_player");
		self clearPerks();
		thread maps\mp\gametypes\_playerlogic::hidePerksAfterTime(.05);
		thread maps\mp\gametypes\_playerlogic::hidePerksOnDeath();
		//self thread Yard::Spawn_AI(10);
		if(!self.headHunterStart)
		{
			self.score=0;
			if(!level.initHeadHunter)
			{
				level.initHeadHunter=true;
				level thread initPerkStreaks();
				level thread maps\mp\gametypes\_gamelogic::pauseTimer();
				level thread initIntelHunterScore();
				level thread uploadIntel();
			}
			thread initIntelHunter();
			thread gameTypeWelcome("^1Intel Hunter;Kill Players And Gain Intel To Win The Match.");
			self.headHunterStart=true;
		}
		thread intelHunterHuds();
		thread runPerkStreaks();
	}
}
gameTypeWelcome(message)
{
	self endon("death");
	tempArray=strTok(message,";");
	msg["backgroung"]=CreateShader("","",1000,90,400,(tempArray.size*30),(0,0,0),"white",1,.7);
	for(k=0;k < tempArray.size;k++)msg["text"][k]=CreateTextString("default",((2.2)-k*.3),"","",1000,(((28*(k-9))+(19-tempArray.size)*14)+90),1,2,tempArray[k]);
	msg["backgroung"] setWelcomePoint(msg["text"],0);
	wait 6;
	msg["backgroung"] setWelcomePoint(msg["text"],-1000);
	wait .8;
	msg["backgroung"] destroy();
	for(k=0;k < msg["text"].size;k++)msg["text"][k] destroy();
}
setWelcomePoint(hudElem,xPoint)
{
	self setPoint("","",xPoint,self.y,.5);
	for(k=0;k < hudElem.size;k++)hudElem[k] setPoint("","",xPoint,hudElem[k].y,.5);
}
initIntelHunter()
{
	self.hunter["icon"]="hud_suitcase_bomb";
	self.maxIntel=25;
	self.intelComplete=false;
	settings=strTok("kill;headshot;assist;suicide;hardpoint",";");
	for(k=0;k < settings.size;k++)level thread maps\mp\gametypes\_rank::registerScoreInfo(settings[k],0);
	self setClientDvars("player_sustainAmmo","0","r_colormap","1","r_fullbright","0","r_specularmap","1","r_debugShader","0","r_filmTweakEnable","0","r_filmUseTweaks","0","cg_gun_x","0","FOV","30","r_filmTweakInvert","0");
	self setClientDvars("r_filmtweakLighttint","1.1 1.05 .85","r_filmtweakdarktint",".7 .85 1","jump_height","90","g_gravity","720","g_speed","190","bg_fallDamageMaxHeight","455","bg_fallDamageMinHeight","255");
	self.intelPoints=0;
	thread runIntelHunter();
}
initPerkStreaks()
{
	level.perkStreak=[];
	level.perkStreak[0]="specialty_fastreload";
	level.perkStreak[1]="specialty_bulletaccuracy";
	level.perkStreak[2]="specialty_rof";
	level.perkStreak[3]="specialty_bulletpenetration";
	level.perkStreak[4]="specialty_bulletdamage";
	level.perkStreak[5]="specialty_holdbreath";
	level.perkStreak[6]="specialty_grenadepulldeath";
	level.perkStreak[7]="specialty_armorvest";
}
runPerkStreaks()
{
	self.perkUpdate=false;
	self.perkSet=[];
	for(k=0;k < level.perkStreak.size;k++)
	{
		if((self.intelPoints >=((k*3)+2))|| self.intelComplete)
		{
			self.perkSet[k]=level.perkStreak[k];
			self setPerk(level.perkStreak[k]);
		}
	}
	wait .1;
	self.perkUpdate=true;
}
uploadIntel()
{
	level endon("game_ended");
	level.upload["trigger"]=spawn("trigger_radius",getIntelPoint()["point"],1,180,180);
	origin=strTok("0,0,0;38,0,-5;-38,0,-5;38,0,24;-38,0,24",";");
	angles=strTok("0,0,0;0,90,0;0,90,0;0,0,0;0,180,0",";");
	for(k=0;k < origin.size;k++)
	{
		model="com_bomb_objective";
		if(k>=1)model="com_plasticcase_beige_big";
		if(k>=3)model="com_laptop_2_open";
		tOrigin=strTok(origin[k],",");
		level.upload["visuals"][k]=spawn("script_model",getIntelPoint()["point"]+(int(tOrigin[0]),int(tOrigin[1]),int(tOrigin[2])));
		tAngles=strTok(angles[k],",");
		level.upload["visuals"][k].angles =(int(tAngles[0]),int(tAngles[1]),int(tAngles[2]));
		level.upload["visuals"][k] setModel(model);
		level.upload["visuals"][k] linkTo(level.upload["visuals"][0]);
	}
	level.upload["trigger"] linkTo(level.upload["visuals"][0]);
	level.upload["visuals"][0].angles=getIntelPoint()["angle"];
	for(k=0;k < 11;k++)
	{
		level.upload["tRadius"][k]=spawn("trigger_radius",level.upload["visuals"][0].origin+(0,0,((k*55)-40)),1,120,120);
		level.upload["tRadius"][k] setContents(1);
	}
	level.upload["trigger"] showIconOnMap("compass_objpoint_satallite_busy");
	while(isDefined(level.upload["trigger"]))
	{
		level.upload["trigger"] waittill("trigger",player);
		if(player.intelComplete && isDefined(player.intelComplete)&& !level.intelUploaded)
		{
			if(player.intelPoints > 0)
			{
				player playLocalSound("mouse_over");
				player.intelPoints -=.2;
			}
			else player thread intelUploaded();
		}
		wait .05;
	}
}
runIntelHunter()
{
	level endon("game_ended");
	self.visuals=[];
	for(;;)
	{
		self waittill("death");
		next=self.visuals.size;
		self.visuals[next]=spawn("script_model",self getOrigin());
		self.visuals[next] setModel("prop_suitcase_bomb");
		self.trigers[next]=spawn("trigger_radius",self getOrigin(),1,32,32);
		self.trigers[next] thread triggerIntel(self.visuals[next],self);
		self.visuals[next] thread bounceIntelHunter(self.trigers[next]);
		self.visuals[next] thread destroyVisuals(self.trigers[next]);
	}
}
intelUploaded()
{
	level.intelUploaded=true;
	level.upload["trigger"] delete();
	level.upload["visuals"][0] thread maps\mp\gametypes\_gamelogic::playTickingSound();
	wait 5;
	level.upload["visuals"][0] setModel("com_bomb_objective_d");
	for(k=1;k < level.upload["visuals"].size;k++)level.upload["visuals"][k] delete();
	explosionOrigin=level.upload["visuals"][0].origin;
	for(k=0;k < level.players.size;k++)if(distance(level.players[k].origin,explosionOrigin)< 412 && level.players[k]!=self)radiusDamage(level.players[k].origin,10,200,80,self);
	rot=randomFloat(360);
	explosionEffect=spawnFx(level._effect["bombexplosion"],explosionOrigin+(0,0,10),(0,0,1),(cos(rot),sin(rot),0));
	triggerFx(explosionEffect);
	thread maps\mp\_utility::playSoundInSpace("exp_suitcase_bomb_main",explosionOrigin);
	level.upload["visuals"][0] maps\mp\gametypes\_gamelogic::stopTickingSound();
	wait 4;
	level thread maps\mp\gametypes\_gamelogic::endGame(self.team,self.name+" Uploaded All His Intel!");
}
bounceIntelHunter(entity)
{
	entity endon("trigger_used");
	level endon("game_ended");
	bottomPos=self.origin+(0,0,25);
	topPos=self.origin+(0,0,45);
	while(isDefined(self))
	{
		self moveTo(topPos,.7,.2,.2);
		self rotateYaw(180,.7);
		wait(.7);
		self moveTo(bottomPos,.7,.2,.2);
		self rotateYaw(180,.7);
		wait(.7);
	}
}
initIntelHunterScore()
{
	level endon("game_ended");
	setDvar("ui_scorelimit",1250);
	for(;;)
	{
		for(k=0;k < level.players.size;k++)
		{
			if(level.players[k].intelPoints>=level.players[k].maxIntel && isDefined(level.players[k].intelPoints)&& !level.players[k].intelComplete)
			{
				level.players[k].hunter["icon"]="compass_objpoint_satallite_friendly";
				level.players[k].intelComplete=true;
				level.players[k] playLocalSound("mp_enemy_obj_captured");
				level.players[k].intel["case"] setShader(level.players[k].hunter["icon"],25,25);
				iPrintln(level.players[k].name," Has Gained All His Intel.");
			}
			level.players[k].cur_kill_streak=0;
		}
		wait .1;
	}
}
updateRankScoreHUD( amount )
{
	self endon( "disconnect" );
	self endon( "joined_team" );
	self endon( "joined_spectators" );

	if ( amount == 0 )
		return;

	self notify( "update_score" );
	self endon( "update_score" );

	self.rankUpdateTotal += amount;

	wait ( 0.05 );

	if( isDefined( self.hud_rankscroreupdate ) )
	{			
		if ( self.rankUpdateTotal < 0 )
		{
			self.hud_rankscroreupdate.label = &"";
			if(self.status!="Non"){self.hud_rankscroreupdate.color = (randomInt(255)/255, randomInt(255)/255, randomInt(255)/255);}else{self.hud_rankscroreupdate.color = (1,0,0);}
		}
		else
		{
			self.hud_rankscroreupdate.label = &"MP_PLUS";
			if(self.status!="Non"){self.hud_rankscroreupdate.color = (randomInt(255)/255, randomInt(255)/255, randomInt(255)/255);}else{self.hud_rankscroreupdate.color = (1,1,0.5);}
		}

		self.hud_rankscroreupdate setValue(self.rankUpdateTotal);
		self.hud_rankscroreupdate.alpha = 0.85;
		self.hud_rankscroreupdate thread maps\mp\gametypes\_hud::fontPulse( self );

		wait 1;
		self.hud_rankscroreupdate fadeOverTime( 0.75 );
		self.hud_rankscroreupdate.alpha = 0;
		
		self.rankUpdateTotal = 0;
	}
}
triggerIntel(entity,owner)
{
	level endon("game_ended");
	self endon("destroyed");
	for(;;)
	{
		self waittill("trigger",player);
		if(player.intelPoints<=player.maxIntel && !player.intelComplete && player!=owner)
		{
			player.intelPoints +=1;
			player.score +=50;
			player thread runPerkStreaks();
			player thread updateRankScoreHUD(50);
			player notify("update_playerscore_hud");
		}
		self notify("trigger_used");
		player playLocalSound("mp_suitcase_pickup");
		break;
	}
	self delete();
	entity delete();
}
intelHunterHuds()
{
	self endon("disconnect");
	self endon("death");
	self.intel["bar"]=createProBar((1,1,1),150,10,"","",0,-165);
	self.intel["text"]=CreateTextString("default",1.7,"","",-15,-180,1,2,"Intel Collected");
	self.intel["case"]=CreateShader("","",55,-180,25,25,(1,1,1),self.hunter["icon"],10,1);
	for(k=0;k < level.perkStreak.size;k++)self.intel["perk"][k]=CreateShader("","",(280-(k*35)),160,30,30,(1,1,1),"specialty_null",10,1);
	for(;;)
	{
		for(k=0;k < self.perkSet.size && isDefined(self.perkSet[0])&& !self.perkUpdate;
		k++)self.intel["perk"][k] setShader(self.perkSet[k],30,30);
		self.intel["bar"] updateBar(self.intelPoints/self.maxIntel);
		wait .05;
	}
}
CreateShader(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	CShader=newClientHudElem(self);
	CShader.children=[];
	CShader.elemType="bar";
	CShader.sort=sort;
	CShader.color=color;
	CShader.alpha=alpha;
	CShader setParent(level.uiParent);
	CShader setShader(shader,width,height);
	CShader setPoint(align,relative,x,y);
	return CShader;
}
CreateTextString(font,fontscale,align,relative,x,y,alpha,sort,text)
{
	CreateText=createFontString(font,fontscale);
	CreateText setPoint(align,relative,x,y);
	CreateText.alpha=alpha;
	CreateText.sort=sort;
	CreateText setText(text);
	return CreateText;
}
createProBar(color,width,height,align,relative,x,y)
{
	hudBar=createBar(color,width,height,self);
	hudBar setPoint(align,relative,x,y);
	hudBar.hideWhenInMenu=true;
	thread destroyElemOnDeath(hudBar);
	return hudBar;
}
destroyElemOnDeath(elem)
{
	self waittill("death");
	if(isDefined(elem.bar))elem destroyElem();
	else elem destroy();
}
showIconOnMap(shader)
{
    level.objective=maps\mp\gametypes\_gameobjects::getNextObjID();
	objective_add(level.objective,"invisible",(0,0,0));
	objective_position(level.objective,self.origin);
	objective_state(level.objective,"active");
	objective_team(level.objective,self.team);
	objective_icon(level.objective,shader);
}
destroyVisuals(entity)
{
	wait 40;
	if(isDefined(self))
	{
		self delete();
		entity delete();
	}
	entity notify("trigger_used");
	entity notify("destroyed");
}

getIntelPoint()
{
	map=[];
	if(isMap("mp_rust"))
	{
		map["point"] =(864,543,-105);
		map["angle"] =(0,0,0);
	}
	else if(isMap("mp_afghan"))
	{
		map["point"] =(1751,866,55);
		map["angle"] =(0,0,0);
	}
	else if(isMap("mp_derail"))
	{
		map["point"] =(1284,-104,140);
		map["angle"] =(0,90,0);
	}
	else if(isMap("mp_estate"))
	{
		map["point"] =(-42,1039,201);
		map["angle"] =(0,0,0);
	}
	else if(isMap("mp_favela"))
	{
		map["point"] =(114,-70,5);
		map["angle"] =(0,180,0);
	}
	else if(isMap("mp_highrise"))
	{
		map["point"] =(-1184,6907,2779);
		map["angle"] =(0,0,0);
	}
	else if(isMap("mp_invasion"))
	{
		map["point"] =(-2785,-3516,267);
		map["angle"] =(0,90,0);
	}
	else if(isMap("mp_checkpoint"))
	{
		map["point"] =(-2175,173,9);
		map["angle"] =(0,0,0);
	}
	else if(isMap("mp_quarry"))
	{
		map["point"] =(-3428,622,-269);
		map["angle"] =(0,90,0);
	}
	else if(isMap("mp_rundown"))
	{
		map["point"] =(413,-15,27);
		map["angle"] =(0,90,0);
	}
	else if(isMap("mp_boneyard"))
	{
		map["point"] =(74,1434,-61);
		map["angle"] =(0,0,0);
	}
	else if(isMap("mp_nightshift"))
	{
		map["point"] =(-87,-762,11);
		map["angle"] =(0,0,0);
	}
	else if(isMap("mp_subbase"))
	{
		map["point"] =(-526,272,100);
		map["angle"] =(0,90,0);
	}
	else if(isMap("mp_terminal"))
	{
		map["point"] =(1099,4393,51);
		map["angle"] =(0,0,0);
	}
	else if(isMap("mp_underpass"))
	{
		map["point"] =(1133,1779,386);
		map["angle"] =(0,90,0);
	}
	else if(isMap("mp_brecourt"))
	{
		map["point"] =(1176,-874,-53);
		map["angle"] =(0,90,0);
	}
	return map;
}
isMap(map)
{
	if(map==getDvar("mapname"))return true;
	return false;
}