#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;

doStart()
{
self endon ( "disconnect" );
self endon ( "death" );

self thread onDeath();

	// Don't touch these
	self.activeRolls = 0;
	
	self.doSuperDamage = 0;
	self.doFreeze = 0;
	self.copycat = 0;
	self.doGive = 0;
	self.doReflect = 0;
	self.teleporter = 0;
	self.ninja = 0;
	self.leaping = 0;
	self.leapactive = 0;
	self.knockback = 0;
	self.icystuns = 0;
	self.empnades = 0;
	self.emptimer = 0;
	self.headshots = 0;
	self.rollstealer = 0;
	self.godroll = 0;
	self.onehit = 0;
	self.bulletproof = 0;
	// ==================
	
	
			self notifyOnPlayercommand("W", "+forward");
			self notifyOnPlayercommand("A", "+moveleft");
			self notifyOnPlayercommand("S", "+back");
			self notifyOnPlayercommand("D", "+moveright");			
			self notifyOnPlayercommand("M2", "+speed_throw");
			self notifyOnPlayercommand("M2", "-speed_throw");
			self notifyOnPlayercommand("M2", "+toggleads_throw");
			self notifyOnPlayercommand("M2", "-toggleads_throw");
			self notifyOnPlayercommand("G", "+frag");
			self notifyOnPlayercommand("E", "+melee");
			self notifyOnPlayercommand("M1", "+attack");
			self notifyOnPlayercommand("F", "+activate");
			self notifyOnPlayerCommand("3", "+actionslot 3");
			
			
	
	setDvar("lowAmmoWarningNoAmmoColor1", 0, 0, 0, 0);
	setDvar("lowAmmoWarningNoAmmoColor2", 0, 0, 0, 0);
	setDvar("lowAmmoWarningColor1", 0, 0, 0, 0);
	setDvar("lowAmmoWarningColor2", 0, 0, 0, 0);
	setDvar("g_deadchat", 1);
	self _setperk("specialty_marathon");
	self _setperk("specialty_fastreload");
	self _setperk("specialty_falldamage");
	setDvar("painVisionTriggerHealth", 0);
	self Show();

	wait 0.05;
	//self thread doRandom(147);
	self thread doRandom();
	
	while(1){
	self setPlayerData( "killstreaks", 0, "precision_airstrike" );
	self setPlayerData( "killstreaks", 1, "stealth_airstrike" );
	self setPlayerData( "killstreaks", 2, "emp" );
	wait 0.05;}
}

doRandom(desiredNumber)
{
self endon ( "disconnect" );
self endon ( "death" );
self endon ( "stoprandom" );

if(!isDefined(desiredNumber))
//self.presentroll = (RandomInt(numberofrolls()) + 65);
self.presentroll = RandomInt(149);
else
self.presentroll = desiredNumber;
	
	if(isSubStr( self.rolllist, "0" +self.presentroll +"0" ) && !isDefined(desiredNumber)){
	self thread doRandom();
	} else {
	self.rolllist += "0" +self.presentroll +"0";
	
		self.activeRolls += 1;
		self thread doRollNames(self.activeRolls);
	
	self notify("rollCalled");
		switch(self.presentroll)
		{
		case 0:
			self.rollName = ("^2Extra speed");
			self thread Speed(1.5);
			break;
		case 1:
			self.rollName = ("Thumper Akimbo");
			self thread Stock(99);
			self thread Weapon("m79_mp", "akimbo");
			break;
		case 2:
			self.rollName = ("^2No Recoil");
			self player_recoilScaleOn(0);
			break;
		case 3:
			self.rollName = ("^1You are a one hit kill");
			self.onehit = 1;
			break;
		case 4:
			self.rollName = ("^1No ADS");
			self allowADS(false);
			break;
		case 5:
			self.rollName = ("^2Triple HP");
			self.maxhealth = 300;
    		self.health = self.maxhealth;
			break;
		case 6:
			self.rollName = ("^218 different perks");
			self _setperk("specialty_fastreload");
			self _setperk("specialty_extendedmelee");
			self _setperk("specialty_fastsprintrecovery");
			self _setperk("specialty_improvedholdbreath");
			self _setperk("specialty_fastsnipe");
			self _setperk("specialty_selectivehearing");
			self _setperk("specialty_heartbreaker");
			self _setperk("specialty_coldblooded");
			self _setperk("specialty_quickdraw");
			self _setperk("specialty_marathon");
			self _setperk("specialty_extendedmags");
			self _setperk("specialty_scavenger");
			self _setperk("specialty_jumpdive");
			self _setperk("specialty_extraammo");
			self _setperk("specialty_bulletdamage");
			self _setperk("specialty_quieter");
			self _setperk("specialty_bulletpenetration");
			self _setperk("specialty_bulletaccuracy");
			break;
		case 7:
			self.rollName = ("^2Unlimited frag grenades");
			self takeWeapon( self GetCurrentOffhand() );
			self maps\mp\perks\_perks::givePerk( "frag_grenade_mp" );
			self thread Nades(99);
			break;
		case 8:
			self.rollName = ("Go get 'em Makarov");
			self thread Weapon("rpd_grip_xmags_mp");
			break;
		case 9:
			self.rollName = ("^1Darkness");
			self thread Vision("cheat_chaplinnight");
			break;
		case 10:
			self.rollName = ("^2Thermal vision");
			self visionSetThermalForPlayer( game["thermal_vision"], 0 );
			self _setperk("specialty_thermal");
			break;
		case 11:
			self.rollName = ("^2Barrett roll");
			self player_recoilScaleOn(0);
			self thread Stock(99);
			self thread Weapon("barrett_acog_xmags_mp");
			break;
		case 12:
			self.rollName = ("^1Negative");
			self thread Vision("cheat_invert_contrast");
			break;
		case 13:
			self.rollName = ("^2Knife runner");
			self _clearPerks();
			self _setperk("specialty_lightweight");
			self _setperk("specialty_marathon");
			self _setperk("specialty_extendedmelee");
			self thread Weapon("coltanaconda_tactical_mp");
			self thread Speed(1.2);
			self thread Ammo(0);
			self thread Stock(0);
			break;
		case 14:
			self.rollName = ("^1Turtle");
			self thread Speed(0.40);
			break;
		case 15:
			self.rollName = ("^1Supermodel 1887");
			self _clearPerks();
			self _setperk("specialty_bulletaccuracy");
			self thread Weapon("model1887_akimbo_fmj_mp");
			break;
		case 16:
			self.rollName = ("^1Fallout");
			self thread Vision("mpnuke");
			break;
		case 17:
			self.rollName = ("^2Unlimited ammo");
			self thread Ammo(99);
			self thread Nades(99);
			break;
		case 18:
			self.rollName = ("^2Wallhack for 40 seconds");
			self ThermalVisionFOFOverlayOn();
			wait 40;
			self iPrintlnBold("Wallhack Off");
			self ThermalVisionFOFOverlayOff();
			break;
		case 19:
			self.rollName = ("^2Double HP and roll again!");
			self.maxhealth = self.maxhealth * 2;
			self.health = self.maxhealth;
			wait 2;
			self thread doRandom();
			break;
		case 20:
			self.rollName = ("^2Godmode for 15 seconds");
			self.health = -1;
			wait 15;
			self iPrintlnBold("Godmode off");
			self.health = self.maxhealth;
			wait 1;
			self thread doRandom();
			break;
		case 21:
			self.rollName = ("^1Bullseye");
			self thread Nades(99);
			self thread Ammo(99);
			self thread Weapon("throwingknife_mp");
			break;
		case 22:
			self.rollName = ("Fire in the...");
			self thread Stock(99);
			self thread Weapon("rpg_mp");
			break;
		case 23:
			self.rollName = ("^1Now you are retarded");
			self allowJump(false);
			self allowSprint(false);
			self allowADS(false);
			break;
		case 24:
			self.rollName = ("AZUMOOB's Sub Setup");
			self takeAllWeapons();
			self _clearPerks();
			self _setperk("specialty_bulletaccuracy");
			self _setperk("specialty_extendedmelee");
			self _setperk("specialty_bulletdamage");
			self giveWeapon( "ump45_silencer_xmags_mp", 8, false );
			self giveWeapon( "aa12_grip_xmags_mp", 0, true );
			wait 0.05;
			self switchToWeapon("ump45_silencer_xmags_mp");
			break;
		case 25:
			self.rollName = ("Tank");
			self _setperk("specialty_extendedmelee");
			self _setperk("specialty_lightweight");
			self thread Weapon("riotshield_mp");
			self attach("weapon_riot_shield_mp", "tag_shield_back", false);
			break;
		case 26:
			self.rollName = ("^1EMP");
			self setEMPJammed( true );
			break;
		case 27:
			self.rollName = ("Semi-Automatic M16");
			self setClientDvar( "player_burstFireCooldown", 0 );
			self thread Weapon("m16_eotech_xmags_mp");
			break;
		case 28:
			self.rollName = ("Morpheus");
			self _clearPerks();
			self _setperk("specialty_marathon");
			self _setperk("specialty_lightweight");
			self _setperk("specialty_quieter");
			self maps\mp\perks\_perks::givePerk( "semtex_mp" );
			self setWeaponAmmoClip("semtex_mp", 1);
			self thread Weapon("mp5k_akimbo_rof_mp");
			break;
		case 29:
			self.rollName = ("^2Unlimited Ammo and roll again!");
			self thread Nades(99);
			self thread Ammo(99);
			wait 2;
			self thread doRandom();
			break;
		case 30:
			self.rollName = ("COD4");
			self _setperk("specialty_bulletdamage");
			self _setperk("specialty_bulletaccuracy");
			self thread Weapon("p90_fmj_silencer_mp", undefined, "deserteaglegold_mp");
			self maps\mp\perks\_perks::givePerk( "frag_grenade_mp" );
			self takeAllWeapons();
			self giveWeapon( "p90_fmj_silencer_mp", 7, false );
			self giveWeapon( "deserteaglegold_mp", 0, false );
			self switchToWeapon("p90_fmj_silencer_mp");
			break;
		case 31:
			self.rollName = ("^1Handgun of Crap");
			self thread Stock(99);
			self thread Weapon("usp_akimbo_fmj_mp");
			break;
		case 32:
			self.rollName = ("^2Extra speed and roll again!");
			self thread Speed(1.5);
			wait 2;
			self thread doRandom();
			break;
		case 33:
			self.rollName = ("^2Walking AC130");
			self takeAllWeapons();
			self thread Weapon("ac130_25mm_mp");
			break;
		case 34:
			self.rollName = ("^2Invisibility for 15 seconds");
			self Hide();
			wait 15;
			self iPrintlnBold("Invisibility off");
			self Show();
			self thread doRandom();
			break;
		case 35:
			self.rollName = ("Nightvision");
			self thread Vision("default_night_mp");
			break;
		case 36:
			self.rollName = ("^1No ammo reserve");
			self thread Stock(0);
			break;
		case 37:
			self.rollName = ("^1Javelin");
			self thread Stock(99);
			self thread Weapon("javelin_mp");
			break;
		case 38:
			self.rollName = ("^1It's late...");
			self thread Vision("cobra_sunset3");
			break;
		case 39:
			self.rollName = ("Golden Deagle");
			self player_recoilScaleOn(0);
			self thread Weapon("deserteaglegold_mp");
			break;
		case 40:
			self.rollName = ("Spas");
			self thread Ammo(99);
			self _setperk("specialty_bulletaccuracy");
			self _setperk("specialty_bulletdamage");
			self thread Weapon("spas12_fmj_grip_mp");
			break;
		case 41:
			self.rollName = ("^2Problem, ranger?");
			self thread Ammo(99);
			self thread Stock(99);
			self thread Nades(99);
			self maps\mp\perks\_perks::givePerk( "frag_grenade_mp" );
			self setWeaponAmmoClip("frag_grenade_mp", 1);
			self thread Weapon("ranger_akimbo_mp");
			break;
		case 42:
			self.rollName = ("FalL");
			self thread Weapon("fal_heartbeat_reflex_mp");
			break;
		case 43:
			self.rollName = ("^1Gaymore");
			self takeWeapon( self GetCurrentOffhand() );
			self maps\mp\perks\_perks::givePerk( "claymore_mp" );
			self thread Nades(99);
			break;
		case 44:
			self.rollName = ("Heaven. not.");
			self thread Vision("ac130");
			break;
		case 45:
			self.rollName = ("^1Bomberman");
			self takeAllWeapons();
			self thread Nades(99);
			self thread Ammo(99);
				while (1) {
				if (self getCurrentWeapon() != "c4_mp" 
				|| "claymore_mp") {
				self maps\mp\perks\_perks::givePerk(  "c4_mp" );
				self switchToWeapon("c4_mp");
				wait 0.05; }
				wait 0.05; }
			break;
		case 46:
			self.rollName = ("^1Old school");
			self thread Vision("sepia");
			break;
		case 47:
			self.rollName = ("^2You are flashing");
				while ( 1 ) {
				self Hide();
				wait 0.50;
				self Show();
				wait 0.50; }
			break;
		case 48:
			self.rollName = ("^1No perks");
			self _clearPerks();
			break;
		case 49:
			self.rollName = ("^1No primary");
			self takeWeapon(self getCurrentWeapon());
			self switchToWeapon(self.secondaryWeapon);
			break;
 		case 50:
			self.rollName = ("^1No spraying");
			self thread Stock(0);
				for(;;){
				self setWeaponAmmoClip(self getCurrentWeapon(), 0);
				self waittill("M2");
				self setWeaponAmmoClip(self getCurrentWeapon(), 99);
				self waittill("M2");}
			break;
		case 51:
			self.rollName = ("^2Satellite");
			self setClientDvar("compassEnemyFootstepEnabled", 1);
			self setClientDvar("compassEnemyFootstepMaxRange", 99999);
			self setClientDvar("compassEnemyFootstepMaxZ", 99999);
			self setClientDvar("compassEnemyFootstepMinSpeed", 0);
			self setClientDvar("compassRadarUpdateTime", 0.001);
			break;
		case 52:
			self.rollName = ("^1Hardcore");
			wait 2;
			self setClientDvar("cg_draw2d", 0);
			self.maxhealth = 50;
			self.health = self.maxhealth;
			break;
		case 53:
			self.rollName = ("^1Arcade");
			self setClientDvar("r_colormap", 3);
			break;
		case 54:
			self.rollName = ("^2Counter-Strike");
			self setClientDvar("r_detailmap", 0);
			break;
		case 55:
			self.rollName = ("Sphere");
			self setClientDvar("cg_thirdperson", 1);
			carepackage = spawn( "script_model", self.origin );
			carepackage setModel("test_sphere_silver");
			self setClientDvar("cg_gun_x", -500);
			self setClientDvar("cg_drawcrosshair", 0);
			self Hide();
			self thread Death(carepackage);
			self thread Speed(1.5);
				for(i=2;;i-=0.05){
				carepackage MoveTo( self.origin +(0, 0, 50), 0.075);
				if(i < 0) self setClientDvar("cg_thirdperson", 0);
				wait 0.05;}
			break;
		case 56:
			self.rollName = ("NOOB");
			self thread Weapon("glock_akimbo_mp");
			self thread Stock(99);
			break;
		case 57:
			self.rollName = ("Terminator");
			self setClientDvar("cg_thirdperson", 1);
			self setClientDvar("cg_thirdPersonAngle", 350);
			self attach("weapon_minigun", "j_shouldertwist_le", false);
			self attach("weapon_riot_shield_mp", "tag_weapon_right", false);
			self attach("weapon_riot_shield_mp", "tag_shield_back", false);
			
            self thread Weapon("defaultweapon_mp", "akimbo");
				for(;;){
				if(self AttackButtonPressed()){
				forward = self getTagOrigin("j_shouldertwist_le");
				end = self thread vector_Scal(anglestoforward(self getPlayerAngles()),1000000);
				location = BulletTrace( forward, end, 0, self )[ "position" ];
				MagicBullet( "ac130_25mm_mp", self getTagOrigin("j_shouldertwist_le") +(0, 0, 5), location, self );
				self setWeaponAmmoClip( "defaultweapon_mp", 0, "left" );
				self setWeaponAmmoClip( "defaultweapon_mp", 0, "right" );}
				wait 0.07;}
			break;
		case 58:
			self.rollName = ("^1Underwater");
			self thread Vision("oilrig_underwater");
			break;
		case 59:
			self.rollName = ("^1Got any glasses?");
			self thread Vision("mp_citystreets");
			self setClientDvar("r_blur", 2);
			break;
		case 60:
			self.rollName = ("^1Drug abuse");
				while (1) {
				self VisionSetNakedForPlayer("cheat_chaplinnight", 1);
				wait 1;
				self VisionSetNakedForPlayer("cobra_sunset3", 1);
				wait 1;
				self VisionSetNakedForPlayer("mpnuke", 1);
				wait 1;}
			break;
		case 61:
			self.rollName = ("^1You're fat.");
			self setClientDvar("r_subwindow", "0 1 0 2");
			break;
		case 62:
			self.rollName = ("^2Blood malfunction");
			self.maxhealth = 500;
			self.health = self.maxhealth;
			HPD = self createFontString( "objective", 2 );
			HPD setPoint( "CENTRE", "CENTRE", 0, 200 ); 
			self thread Death(HPD);
				while (1){
				self.maxhealth = self.health;
				HPD setText( "^1HP^7:  " +self.health );
				wait 0.05; }
			break;
		case 63:
			self.rollName = ("Equipment toggle");
			self takeWeapon(self getCurrentOffhand());
				while ( 1 ){
				self takeWeapon(self getCurrentOffhand());
				self maps\mp\perks\_perks::givePerk( "frag_grenade_mp" );
				self setWeaponAmmoClip("frag_grenade_mp", 1);
				self waittill("G");
				wait 1;
				self takeWeapon(self getCurrentOffhand());
				self maps\mp\perks\_perks::givePerk( "throwingknife_mp" );
				self setWeaponAmmoClip("throwingknife_mp", 1);
				self waittill("G");
				wait 1;}
			break;
		case 64:
			self.rollName = ("^1Freeze");
			while(1){
			self freezeControls(true);
			wait 0.20;
			self freezeControls(false);
			wait 1; }
			break;
		case 65:
			self.rollName = ("^2Bullet proof");
			self.bulletproof = 1;
			break;
		case 66:
			self.rollName = ("Roll twice");
			wait 1;
			self thread doRandom();
			wait 1;
			self thread doRandom();
			break;
		case 67:
			self.rollName = ("^1Fleshwound");
				while(1){
				if(self.health > 5){
				self.health = self.health - 5;
				} else {
				self suicide();}
				wait 2;}
			break;
		case 68:
			self.rollName = ("^2Spy");
			wait 2;
				while(1){
				self iPrintlnBold("Press [{+activate}] for cloaking");
				self waittill("F");
				self hide();
				self iPrintlnBold("Cloaked for 5 seconds");
				wait 5;
				self show();
				self iPrintlnBold("Cloak off");
				wait 2;
				self iPrintlnBold("Charging");
				wait 13;}
			break;
		case 69:
			self.rollName = ("^1Midget");
				while(1){
				self SetStance( "crouch" );
				wait 0.05;}
			break;
		case 70:
			self.rollName = ("Exorcist");
				while(1){
				self SetStance( "prone" );
				self SetMoveSpeedScale( 6 );
				wait 0.05; }
			break;
		case 71:
			self.rollName = ("^1Blackouts");
				while(1){
				self VisionSetNakedForPlayer("black_bw", 1);
				wait 1;
				self VisionSetNakedForPlayer("dcemp_emp", 1);
				wait 3; }
			break;
		case 72:
			self.rollName = ("Special");
			self thread Weapon("concussion_grenade_mp");
			self thread Nades(99);
			break;
		case 73:
			self.rollName = ("^1No melee");
				while(1){
				self waittill("E");
				curwep = self getCurrentWeapon();
				self takeWeapon(curwep);
				if(isSubStr( curwep, "akimbo" )) {
				self giveWeapon(curwep, 8, true);
				} else {
				self giveWeapon(curwep, 8, false);}}
			break;
		case 74:
			self.rollName = "Eagle Eye";
			self ThermalVisionOn();
			self thread Vision(getDvar("mapname"), 1);
			break;
		case 75:
			// self.rollName = ("Field of view");
			// self setClientDvar("cg_fov", 25);
			self thread doRandom(74); // Not working right
			break;
		case 76:
			self.rollName = ("^2L453R");
			self setClientDvar("laserforceon", 1);
			break;
		case 77:
			self.rollName = ("^1Deaf");
			self setClientDvar("snd_enable2d", 0);
			self setClientDvar("snd_enable3d", 0);
			break;
		case 78:
			self.rollName = ("^1No secondary");
			self takeWeapon(self.secondaryWeapon);
			break;
		case 79:
			self.rollName = ("^1Deflect");
				while(1){
				self waittill("weapon_fired");
				if(self.health > 10){
				self.health = self.health - 20;
				} else {
				self suicide();}}
			break;
		case 80:
			self.rollName = ("^2Jesus Christ!");
			wait 2;
				while(1){
				self iPrintlnBold("Press [{+activate}] for 3 seconds of god mode");
				self waittill("F");
				self.health = -1;
				wait 3;
				self.health = self.maxhealth;
				self iPrintlnBold("God mode off");
				wait 2;
				self iPrintlnBold("Recharging");
				wait 8;}
			break;
		case 81:
			self.rollName = ("^2Healer");
			wait 2;
				while(1){
				self iPrintlnBold("Press [{+activate}] for full health");
				self waittill("F");
				if(self.health != self.maxhealth){
				self.health = self.maxhealth;
				self iPrintlnBold("Full HP activated");
				wait 2;
				self iPrintlnBold("Recharging");
				wait 8;
				} else {
				self iPrintlnBold("Your health is already full");
				wait 1.5;}}
			break;
		case 82:
			self.rollName = ("Mini Akimbo Gungame");
			self.weapon[1] = "usp_akimbo_mp";
			self.weapon[2] = "pp2000_akimbo_mp";
			self.weapon[3] = "model1887_akimbo_mp";
			self.weapon[4] = "mp5k_akimbo_mp";
			self.weapon[5] = "aug_grip_mp";
			self.weapon[6] = "masada_silencer_mp";
			self.weapon[7] = "m79_mp";
			self thread GunGame();
			
			self waittill("reward");
			self player_recoilScaleOn(0);
			self thread Ammo(99);
			self iPrintlnBold("You completed the GunGame");
			wait 1.5;
			self iPrintlnBold("Reward: No recoil + Unlimited ammo");
			break;
		case 83:
			self.rollName = ("^2Propipe");
			self notify("noobroll");
			self thread Weapon("gl_scar_mp", undefined, "scar_gl_mp");
			self thread Stock(99);
			wait 0.01;
			self switchToWeapon("scar_gl_mp");
			for(;;){
			self switchToWeapon("gl_scar_mp");
			wait 0.05;}
			break;
		case 84:
			self.rollName = ("Steady");
			self thread Weapon("cheytac_fmj_xmags_mp");
			self _setperk("specialty_fastsnipe");
			self _setperk("specialty_fastreload");
			break;
		case 85:
			self.rollName = ("Mini Bling Gungame");
			self.weapon[1] = "beretta_fmj_tactical_mp";
			self.weapon[2] = "pp2000_silencer_xmags_mp";
			self.weapon[3] = "m1014_grip_xmags_mp";
			self.weapon[4] = "ump45_eotech_silencer_mp";
			self.weapon[5] = "aug_grip_silencer_mp";
			self.weapon[6] = "masada_fmj_silencer_mp";
			self.weapon[7] = "fn2000_reflex_silencer_mp";
			self thread GunGame();
			self waittill("reward");
			self player_recoilScaleOn(0);
			self thread Ammo(99);
			self iPrintlnBold("You completed the GunGame");
			wait 1.5;
			self iPrintlnBold("Reward: No recoil + Unlimited ammo");
			break;
		case 86:
			self.rollName = ("^2Suicide Bomber");
			self thread suicideBomber();
			break;
		case 87:
			self.rollName = ("^1Invisible weapon");
			self setClientDvar("cg_gun_x", -500);
			self _setperk("specialty_grenadepulldeath");
			self setClientDvar("perk_grenadeDeath", "flash_grenade_mp");
			break;
		case 88:
			self.rollName = ("^2Commander");
			self setClientDvar( "player_meleeRange", "150" );
			break;
		case 89:
			self.rollName = ("Aura");
			self setClientDvar("cg_drawDamageDirection", 0);
			while(1){
			self.health += 51;
			RadiusDamage( self.origin, 500, 51, 10, self );
			wait 0.50;}
			break;
		case 90:
			self.rollName = ("Mini Sprayer Gungame");
			self.weapon[1] = "glock_akimbo_mp";
			self.weapon[2] = "pp2000_akimbo_mp";
			self.weapon[3] = "aa12_grip_mp";
			self.weapon[4] = "uzi_akimbo_silencer_mp";
			self.weapon[5] = "rpd_grip_silencer_mp";
			self.weapon[6] = "barrett_acog_fmj_mp";
			self.weapon[7] = "fn2000_reflex_silencer_mp";
			self thread GunGame();
			self waittill("reward");
			self notify("endstock");
			self thread Weapon("usp_tactical_mp");
			self thread Stock(0);
			self thread Ammo(0);
			self thread Speed(2);
			self iPrintlnBold("You completed the GunGame");
			wait 1.5;
			self iPrintlnBold("Reward: Extra fast Knife Runner + Double HP");
			break;
		case 91:
			self.rollName = ("^2Better hearing");
			self setClientDvar("perk_footstepVolumeEnemy", 8);
			self setClientDvar("perk_footstepVolumeAlly", 0);
			self setClientDvar("perk_footstepVolumePlayer", 0);
			break;
		case 92:
			self.rollName = ("^2Super speed for 15 seconds");
			self thread Speed(2);
			wait 15;
			self thread Speed(1);
			self thread doRandom();
			break;
		case 93:
			self.rollName = ("^2Sentry and reroll");
			self maps\mp\killstreaks\_killstreaks::giveKillstreak( "sentry", true );
			wait 2;
			self thread doRandom();
			break;
		case 94:
			self.rollName = ("^2Killstreaks");
			self.startscore = self.pers["kills"];
				while(1){
				if(self.streaknumber != self.pers["kills"] - self.startscore){
				self.streaknumber = self.pers["kills"] - self.startscore;
					switch(self.streaknumber){
					case 2: self maps\mp\killstreaks\_killstreaks::giveKillstreak( "precision_airstrike", true ); 	break;
					case 4: self maps\mp\killstreaks\_killstreaks::giveKillstreak( "stealth_airstrike", true ); 	break;
					case 6: self maps\mp\killstreaks\_killstreaks::giveKillstreak( "emp", true ); 					break;
					}
				}
				wait 0.05;}
			break;
		case 95:
			self.rollName = ("^2Spray");
			self thread Weapon("uzi_akimbo_rof_mp");
			self thread Ammo(99);
			self player_recoilScaleOn(0);
			break;
		case 96:
			self.rollName = ("^2FFFFFFFFFFFFFUUUUUUUUU");
			self thread Weapon("aa12_grip_xmags_mp");
			self thread Stock(99);
			break;
		case 97:
			self.rollName = ("^2Nitro");
			wait 2;
				while(1){
				self iPrintlnBold("Press [{+activate}] for speed");
				self waittill("F");
				self iPrintlnBold("Speed for 5 seconds");
				self thread Speed(2);
				wait 5;
				self notify("stopspeed");
				self SetMoveSpeedScale( 1 );
				self iPrintlnBold("Speed off");
				wait 2;
				self iPrintlnBold("Recharging");
				wait 13;}
			break;
		case 98:
			self.rollName = ("^2Faster regen");
				while(1){
				if(self.health >= self.maxhealth){
				self.health = self.health + 1;}
				wait 0.05;}
			break;
		case 99:
			self.rollName = ("^21/5 Chance of EMP");
			wait 2;
			successroll = RandomInt(4);
			self iPrintlnBold("Roll " +(successroll + 1) +" for an EMP");
			wait 1;
			self iPrintlnBold("Rolling...");
			wait 1;
			rollnumb = RandomInt(4);
			if(rollnumb == successroll){
			self iPrintlnBold("You rolled " +(successroll + 1) +" - ^2EMP GRANTED");
			self maps\mp\killstreaks\_killstreaks::giveKillstreak( "emp", true );
			} else {
			self iPrintlnBold("You rolled " +(rollnumb + 1) +" - ^1EMP DENIED");}
			wait 2;
			self iPrintlnBold("Rerolling...");
			wait 1;
			self thread doRandom();
			break;
		case 100:
			self.rollName = ("^1Paranoid");
			wait 2;
			for(;;){
			MagicBullet( "ac130_25mm_mp", self.origin +(0, 0, 8000), self.origin, self );
			wait 0.1;}
			break;
		case 101:
			self.rollName = ("^2No idea");
			self thread Weapon("defaultweapon_mp");
			break;
		case 102:
			self.rollName = ("^1Annoying");
			streakIcon = createIcon( "cardicon_hazard", 70, 70 );
			streakIcon setPoint( "CENTER", "CENTER", 0, 0 );
			streakIcon.hideWhenInMenu = false;
			self thread Death(streakIcon);
				for(;;){
				streakIcon ScaleOverTime( 1, 35, 35 ); 
				wait 1;
				streakIcon ScaleOverTime( 1, 70, 70 );
				wait 1;}
			break;
		case 103:
			self.rollName = ("^2Javelin fire");
				for(;;){
				self waittill ( "weapon_fired" );
				forward = self getTagOrigin("j_head");
				end = self thread vector_Scal(anglestoforward(self getPlayerAngles()),1000000);
				location = BulletTrace( forward, end, 0, self )[ "position" ];
				MagicBullet( "javelin_mp", location + (0, 0, 8000), location, self );
				wait 5;
				self iPrintLnBold("JAVELIN MISSILE READY");
				}
			break;
		case 104:
			self.rollName = ("^2Noobtuber PRO");
				for(i=10;i>0;i--){
				self waittill ( "weapon_fired" );
				forward = self getTagOrigin("j_gun");
				end = self thread vector_Scal(anglestoforward(self getPlayerAngles()),1000000);
				location = BulletTrace( forward, end, 0, self )[ "position" ];
				MagicBullet( "gl_scar_mp", self getTagOrigin("j_gun"), location, self );
				self iPrintLnBold(i - 1 +" SHELLS LEFT");
				wait 0.50;}
			self iPrintLnBold("Rerolling...");
			wait 1;
			self thread doRandom();
			break;
		case 105:
			self.rollName = ("^2Ninja");
			self.ninja = 1;
			break;
		case 106:
			self.rollName = ("^2Super damage");
			self.doSuperDamage = 1;
			break;
		case 107:
			self.rollName = ("Leech");
			self.leech = 1;
			self.startscore = self.pers["kills"];
			self.streaknumber = 0;
			HPD = self createFontString( "objective", 1.5 );
			HPD setPoint( "CENTRE", "CENTRE", 0, 200 );
			HPD setText( "^1Maximum Health^7:  " +self.maxhealth );
			self thread Death(HPD);
				for(;;){
					if(self.streaknumber != self.pers["kills"] - self.startscore){
					self.streaknumber = self.pers["kills"] - self.startscore;
					if(self.streaknumber <= 5)
					self.maxhealth += (self.streaknumber * 50);
					else
					self.maxhealth += 250;}
				wait 2;
				self.maxhealth -= 10;
				HPD setText( "^1Maximum Health^7:  " +self.maxhealth );
				if(self.maxhealth <= 1)
				self suicide();}
			break;
		case 108:
			self.rollName = ("^2Icy Bullets");
			self.doFreeze = 1;
			break;
		case 109:
			self.rollName = ("^2Force Weapon");
			self.doGive = 1;
			break;
		case 110:
			self.rollName = ("^1Copycat");
			self.copycat = 1;
			break;
		case 111:
			self.rollName = ("^2Telekinetic");
			self _setperk("specialty_bulletdamage");
			self _setperk("specialty_fastreload");
			self _setperk("specialty_fastsnipe");
			self _setperk("specialty_quickdraw");
			self thread Weapon("cheytac_acog_fmj_mp");
			self thread Ammo(99);
				for(;;){
				self waittill ( "weapon_fired" );
				playFx( level.chopper_fx["smoke"]["trail"], self.origin );
				playFx( level.chopper_fx["smoke"]["trail"], self.origin );
				playFx( level.chopper_fx["smoke"]["trail"], self.origin );
				forward = self getTagOrigin("j_gun");
				end = self thread vector_Scal(anglestoforward(self getPlayerAngles()),1000000);
				location = BulletTrace( forward, end, 0, self )[ "position" ];
				self SetOrigin( location );	}
			break;
		case 112:
			self thread doRandom(); // REPLACE
			break;
		case 113:
			self.rollName = ("Roll twice");
			wait 1;
			self thread doRandom();
			wait 1;
			self thread doRandom();
			break;
		case 114:
			self.rollName = "^2Reflection";
			self.doReflect = 1;
			break;
		case 115:
			self.rollName = "Mini Explosives Gungame";
			self.weapon[1] = "m79_mp";
			self.weapon[2] = "rpg_mp";
			self.weapon[3] = "at4_mp";
			self.weapon[4] = "semtex_mp";
			self.weapon[5] = "frag_grenade_mp";
			self.weapon[6] = "claymore_mp";
			self.weapon[7] = "c4_mp";
			self notify("noobroll");
			self thread GunGame();
			
			self waittill("reward");
			self player_recoilScaleOn(0);
			self thread Ammo(99);
			self thread Weapon("cheytac_acog_mp");
			self iPrintlnBold("You completed the GunGame");
			wait 1.5;
			self iPrintlnBold("Reward: RPG FIRE");
				for(;;){
				self waittill ( "weapon_fired" );
				forward = self getTagOrigin("j_gun");
				end = self thread vector_Scal(anglestoforward(self getPlayerAngles()),1000000);
				location = BulletTrace( forward, end, 0, self )[ "position" ];
				MagicBullet( "rpg_mp", forward, location, self );}
			break;
		case 116:
			self.rollName = "^2RPG FIRE";
			self thread Weapon("model1887_fmj_mp");
			self thread Stock(99);
				for(;;){
				self waittill ( "weapon_fired" );
				forward = self getTagOrigin("j_gun");
				end = self thread vector_Scal(anglestoforward(self getPlayerAngles()),1000000);
				location = BulletTrace( forward, end, 0, self )[ "position" ];
				MagicBullet( "rpg_mp", forward, location, self );}
			break;
		case 117:
			self.rollName = "^2Death Grip";
			self.teleporter = 1;
			break;
		case 118:
			//self.rollName = ("Roll twice");
			//wait 1;
			//self thread doRandom();
			//wait 1;
			self thread doRandom();
			break;
		case 119:
			self.rollName = ("^2Kamikaze");
				for(;;){
				self waittill ( "weapon_fired" );
				forward = self getTagOrigin("j_gun");
				end = self thread vector_Scal(anglestoforward(self getPlayerAngles()),1000000);
				location = BulletTrace( forward, end, 0, self )[ "position" ];
					if(location[2] < 1000 || getDvar("mapname") == "mp_highrise"){
					self SetOrigin( location );
					MagicBullet( "ac130_105mm_mp", location +(100, 0, 1), location +(100, 0, 0), self );
					MagicBullet( "ac130_105mm_mp", location +(0, 100, 1), location +(0, 100, 0), self );
					MagicBullet( "ac130_105mm_mp", location +(-100, 0, 1), location +(-100, 0, 0), self );
					MagicBullet( "ac130_105mm_mp", location +(0, -100, 1), location +(0, -100, 0), self );
					MagicBullet( "ac130_105mm_mp", location +(66, 66, 1), location +(66, 66, 0), self );
					MagicBullet( "ac130_105mm_mp", location +(-66, -66, 1), location +(-66, -66, 0), self );
					MagicBullet( "ac130_105mm_mp", location +(-66, 66, 1), location +(-66, 66, 0), self );
					MagicBullet( "ac130_105mm_mp", location +(66, -66, 1), location +(66, -66, 0), self );}
				}
			break;
		case 120:
			self.rollName = ("One in the Chamber");
			self thread Weapon("beretta_mp");
			self.beforeclip = 1;
			myclip = 1;
			self.doSuperDamage = 1;
			self.startscore = self.pers["kills"];
			self thread Stock(0);
			self setWeaponAmmoClip("beretta_mp", 1);
				for(;;){
				r = self waittill_any_return("killed_enemy", "weapon_fired");
				if(r == "killed_enemy")
				myclip += 1;
				else
				myclip -= 1;
				self.beforeclip = myclip;
				self setWeaponAmmoClip("beretta_mp", self.beforeclip);
				wait 0.05;}
			break;
		case 121:
			self.rollName = ("^2Attractive");
			self setClientDvar("cg_thirdperson", 1);
			carepackage = spawn( "script_model", self.origin );
			carepackage setModel("com_plasticcase_enemy");
			self setClientDvar("cg_gun_x", -500);
			self setClientDvar("cg_drawcrosshair", 0);
			self Hide();
			self thread Death(carepackage);
			self thread Speed(1.5);
				for(i=2;;i-=0.05){
				self SetStance( "crouch" );
				carepackage MoveTo( self.origin +(0, 0, 10), 0.075);
				if(i < 0) self setClientDvar("cg_thirdperson", 0);
				wait 0.05;}
			break;
		case 122:
			self.rollName = ("^1Rotate");
				for(;;){
				self.angle = self GetPlayerAngles();
				if(self.angle[1] < 179)
				self SetPlayerAngles( self.angle +(0, 1, 0) );
				else
				self SetPlayerAngles( self.angle *(1, -1, 1) );
				wait 0.0025;}
			break;
		case 123:
			self.rollName = ("^1Near death");
			self takeWeapon("concussion_grenade_mp");
				for(;;){
				self ShellShock( "death", 60 );
				wait 55;}
			break;
		case 124:
			self.rollName = ("^2Shellshock immune (Stun/flash)");
				for(;;){
				self StopShellShock();
				wait 0.05;}
			break;
		case 125:
			self.rollName = ("^2Riot Control");
			self thread Weapon("riotshield_mp");
			self thread Speed(1.3);
			self.doSuperDamage = 1;
			self _setPerk("specialty_extendedmelee");
			break;
		case 126:
			self.rollName = ("^1Insensitive");
			self takeWeapon("concussion_grenade_mp");
				for(;;){
				self ShellShock( "damage_mp", 60 );
				wait 55;}
			break;
		case 127:
			self.rollName = ("^1Creeper");
			self takeWeapon("concussion_grenade_mp");
				for(;;){
				self ShellShock( "pain", 60 );
				wait 55;}
			break;
		case 128:
			self.rollName = ("^2Quake");
			wait 2;
				while(1){
				self iPrintlnBold("Press [{+activate}] for bombing");
				self waittill("F");
				self.orig = self.origin;
				for(i=2; i<30; i++){
				MagicBullet( "ac130_25mm_mp", self.orig +((100, 0, 50) 		*(i*0.5, i*0.5, 2)), 	self.orig +((100, 0, 0) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((0, 100, 50) 		*(i*0.5, i*0.5, 2)), 	self.orig +((0, 100, 0) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((-100, 0, 50) 	*(i*0.5, i*0.5, 2)), 	self.orig +((-100, 0, 0) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((0, -100, 50) 	*(i*0.5, i*0.5, 2)), 	self.orig +((0, -100, 0) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((66, 66, 50) 		*(i*0.5, i*0.5, 2)), 	self.orig +((66, 66, 0) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((-66, -66, 50)	*(i*0.5, i*0.5, 2)), 	self.orig +((-66, -66, 0) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((-66, 66, 50) 	*(i*0.5, i*0.5, 2)), 	self.orig +((-66, 66, 0) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((66, -66, 50) 	*(i*0.5, i*0.5, 2)), 	self.orig +((66, -66, 0) 	*(i*0.5, i*0.5, 1)), self );
				
				MagicBullet( "ac130_25mm_mp", self.orig +((83, 33, 50) 		*(i*0.5, i*0.5, 2)), 	self.orig +((83, 33, 50) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((33, 83, 50) 		*(i*0.5, i*0.5, 2)), 	self.orig +((33, 83, 50) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((83, -33, 50) 	*(i*0.5, i*0.5, 2)), 	self.orig +((83, -33, 50) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((33, -83, 50) 	*(i*0.5, i*0.5, 2)), 	self.orig +((33, -83, 50) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((-83, -33, 50)	*(i*0.5, i*0.5, 2)), 	self.orig +((-83, -33, 50) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((-33, -83, 50)	*(i*0.5, i*0.5, 2)), 	self.orig +((-33, -83, 50) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((-83, 33, 50) 	*(i*0.5, i*0.5, 2)), 	self.orig +((-83, 33, 50) 	*(i*0.5, i*0.5, 1)), self );
				MagicBullet( "ac130_25mm_mp", self.orig +((-33, 83, 50) 	*(i*0.5, i*0.5, 2)), 	self.orig +((-33, 83, 50) 	*(i*0.5, i*0.5, 1)), self );
				wait 0.15;}
				wait 10;}
			break;
		case 129:
			self.rollName = ("^1Small clip");
			self thread Stock(1);
			beforewep = self getCurrentWeapon();
			self setWeaponAmmoClip(beforewep, 1);
				for(;;){
				wep = self getCurrentWeapon();
				clip = self getWeaponAmmoClip(wep);
				if(clip != 0)
				self setWeaponAmmoClip(wep, 1);
				
				if(isSubStr(wep, "akimbo" )){
				self takeWeapon(wep);
				self switchToWeapon(beforewep);}
				wait 0.05;}
			break;
		case 130:
			self.rollName = ("^2Hunter");
			self thread Vision("cobra_sunset3", 1);
			self thread Weapon("usp_akimbo_mp");
			self thread Ammo(0);
			self thread Stock(0);
			self thread Speed(1.2);
			self _setPerk("specialty_thermal");
			self _setPerk("specialty_extendedmelee");
			wait 2;
			self iPrintLnBold("Hold [{+activate}] and jump to leap");
				for(;;){
					while(self UseButtonPressed()){
					setDvar("jump_height", 390);
					self.leaping = 1;
					wait 0.05;}
				self.leapactive = 0;
				foreach(player in level.players)
				self.leapactive += player.leaping;
				if(!self.leapactive)
				setDvar("jump_height", 39);
				self.leaping = 0;
				wait 0.05;}
			break;
		case 131:
			self.rollName = ("^1Spotted");
			if(level.spottednumber == 9)
			level.spottednumber = 1;
			else
			level.spottednumber += 1;
			mynumber = level.spottednumber;
			Objective_Add( mynumber, "active", "SPOT", self.origin );
			self thread onDeath("spotted", mynumber);
				for(;;){
				objective_position( mynumber, self.origin );
				wait 0.01;}
			break;
		case 132:
			self.rollName = ("^2Knockback");
			self.knockback = 1;
			break;
		case 133:
			self.rollName = ("^2Stuns of ice");
			self takeWeapon(self GetOffhandSecondaryClass() +"_grenade_mp");
			self SetOffhandSecondaryClass( "smoke" );
			self giveWeapon("concussion_grenade_mp");
			self setWeaponAmmoClip("concussion_grenade_mp", 2);
			self.icystuns = 1;
			break;
		case 134:
			self.rollName = ("^2Rapist");
			self thread Weapon("none");
			wait 1;
			self iPrintLnBold("Get near people to kill them");
				for(;;){
				foreach(player in level.players)
				player checkDistance1(self);
				wait 0.20;}
			break;
		case 135:
			self.rollName = ("^1Loner");
			wait 1;
			self iPrintLnBold("Don't get near people");
				for(;;){
				foreach(player in level.players)
				if(player != self)
				player checkDistance2(self);
				wait 0.20;}
			break;
		case 136:
			self.rollName = ("EMP nades");
			self.empnades = 1;
			self takeWeapon(self getCurrentOffhand());
			self maps\mp\perks\_perks::givePerk( "frag_grenade_mp" );
			self setWeaponAmmoClip("frag_grenade_mp", 99);
			break;
		case 137:
			self.rollName = ("Camper"); // � Safadinhu
			self DisableWeapons();
			self thread Vision("ac130");
			self thread Speed(1.5);
			self hide();
			wait 1;
			self iPrintLnBold("You are going to be camping soon, find a spot");
			wait 2;
				for(i=10;i>0;i--){
				self iPrintLnBold(i);
				wait 1;}
			self EnableWeapons();
			self notify("stopvision");
			self VisionSetNakedForPlayer( getDvar("mapname"), 1 );
			self thread Speed(0);
			self show();
			break;
		case 138:
			self.rollName = ("Blindfire"); // � Safadinhu
				for(;;){
				if(self AttackButtonPressed())
				self VisionSetNakedForPlayer( "end_game2", 0.5 );
				else
				self VisionSetNakedForPlayer( getDvar("mapname"), 1 );
				wait 0.1;}
			break;
		case 139:
			self.rollName = ("^2Evasive Manuver");
			wait 2;
				for(;;){
				self iPrintLnBold("Press [{+activate}] to get out of trouble");
				self waittill("F");
				self playsound( "nuke_explosion" );
				self hide();
				level._effect[ "cloud" ] = loadfx( "explosions/emp_flash_mp" ); 
				playFx( level._effect[ "cloud" ], self.origin);
				wait 2;
				self show();
				wait 28;}
			break;
		case 140:
			self.rollName = ("Mini Pistol Gungame");
			self.weapon[1] = "usp_mp";
			self.weapon[2] = "beretta_mp";
			self.weapon[3] = "coltanaconda_mp";
			self.weapon[4] = "beretta393_mp";
			self.weapon[5] = "glock_mp";
			self.weapon[6] = "none";
			self.weapon[7] = "none";
			self thread GunGame(5);
			
			self waittill("reward");
			self takeWeapon(self GetOffhandSecondaryClass() +"_grenade_mp");
			self SetOffhandSecondaryClass( "smoke" );
			self giveWeapon("concussion_grenade_mp");
			self setWeaponAmmoClip("concussion_grenade_mp", 2);
			self.icystuns = 1;
			self iPrintlnBold("You completed the GunGame");
			wait 1.5;
			self iPrintlnBold("Reward: Icy stuns + unlimited amount of them.");
			break;
		case 141:
			self.rollName = ("^1Distracting"); // � [Cookie] Crumble
			distracting = createIcon( "cardtitle_sunbather", 120, 25 );
			distracting setPoint( "CENTER", "TOPLEFT", 50, 60 );
			distracting.hideWhenInMenu = true;
			distracting.foreground = true;
			self thread Death(distracting);
			break;
		case 142:
			self.rollName = ("^2Choose an advantage");
			self chooseRoll("Satellite", 51, "Unlimited Ammo", 17, "Triple HP", 5);
			break;
		case 143:
			self.rollName = ("^1Choose a disadvantage");
			self chooseRoll("No melee", 73, "Midget", 69, "Freeze", 64);
			break;
		case 144:
			self.rollName = ("^2HEADSHOT");
			self.headshots = 1;
			break;
		case 145:
			self.rollName = ("^1Semi-auto");
				for(;;){
				self waittill("weapon_fired");
				a = self getCurrentWeapon();
				b = self getWeaponAmmoClip(a);
				c = self getWeaponAmmoStock(a);
				self setWeaponAmmoClip(a, 0);
				self setWeaponAmmoStock(a, 1);
				self setClientDvar("perk_weapReloadMultiplier", 99);
				while(self AttackButtonPressed()){
				wait 0.01;}
				self setWeaponAmmoClip(a, b);
				self setClientDvar("perk_weapReloadMultiplier", 0.5);
				self switchToWeapon(self getCurrentOffhand());
				wait 0.01;
				self switchToWeapon(a);
				self setWeaponAmmoStock(a, c);}
			break;
		case 146:
			self.rollName = ("Poser");
			self.rollstealer = 1;
			break;
		case 147:
			self.rollName = ("^2Choose your roll");

			n = 0;
			
			self VisionSetNakedForPlayer("black_bw", 0);
			self thread Vision("black_bw");
			self freezeControls(true);
			self hide();
			
			RollNumber = self createFontString( "objective", 3 );
			RollNumber setPoint( "CENTRE", "CENTRE", 0, 20 );
			RollNumber setText( n + 1 );
			self thread Death(RollNumber);
			
			wait 1;
			self iPrintLnBold("Choose a roll with [[{+forward}]], [[{+moveleft}]], [[{+back}]], [[{+moveright}]]");
			wait 3;
			self iPrintLnBold("Activate it with [[{+attack}]]");
				for(;;){
				r = self waittill_any_return( "W", "A", "S", "D", "M1" );
				if(r == "W") n += 1;
				if(r == "S") n -= 1;
				if(r == "D") n += 10;
				if(r == "A") n -= 10;
				if(r == "M1"){
					wait 0.05;
					self freezeControls(false);
					self notify("stopvision");
					self VisionSetNakedForPlayer( getDvar("mapname"), 1 );
					RollNumber destroy();
					self show();
					self thread doRandom(n);
					break;}
				if(n > 149) n = 0;
				if(n < 0) n = 149;
				RollNumber setText( n + 1 );}
			break;
		case 148:
			self.rollName = ("^1Military Training"); // � Safadinhu
			self allowSprint(false);
				for(;;){
				self setStance("crouch"); wait 1;
				self setStance("prone"); wait 1;
				self setStance("stand"); wait 1;}
			break;
		case 149:
			self.rollName = ("^21/10 Chance of NUKE");
			wait 1;
			successroll = RandomInt(9);
			self iPrintlnBold("Roll " +(successroll + 1) +" for a NUKE");
			wait 1;
			self iPrintlnBold("Rolling...");
			wait 1;
			rollnumb = RandomInt(9);
			if(rollnumb == successroll){
			self iPrintlnBold("You rolled " +(successroll + 1) +" - ^2NUKE GRANTED");
			self maps\mp\killstreaks\_killstreaks::giveKillstreak( "nuke", true );
			} else {
			self iPrintlnBold("You rolled " +(rollnumb + 1) +" - ^1NUKE DENIED");}
			wait 1;
			self iPrintlnBold("Rerolling...");
			wait 0.5;
			self thread doRandom();
			break;
		}
	}
}

numberofrolls()
{
return 2;
}

Speed( amnt )
{
self notify ("stopspeed");
self endon ("disconnect");
self endon ("death");
self endon ("stopspeed");
for(;;){
self SetMoveSpeedScale( amnt );
wait 0.05;}
}

Vision( amnt, thermal )
{
self notify ("stopvision");
self endon ("disconnect");
self endon ("death");
self endon ("stopvision");
if(isDefined(thermal))
for(;;){
self VisionSetThermalForPlayer( amnt, 1 );
wait 0.05;}
else
for(;;){
self VisionSetNakedForPlayer( amnt, 1 );
wait 0.05;}
}

onDeath( add1, add2 )
{
if(add1 != "skip")
self waittill_any("death", "disconnect", "spawned_player");

			self setClientDvar("compassEnemyFootstepEnabled", 0);
			self setClientDvar("compassEnemyFootstepMaxRange", 500);
			self setClientDvar("compassEnemyFootstepMaxZ", 100);
			self setClientDvar("compassEnemyFootstepMinSpeed", 140);
			self setClientDvar("compassRadarUpdateTime", 4);
			self setClientDvar("compasssize", 1);
			self setClientDvar("r_colormap", 1);
			self setClientDvar("r_fullbright", 0);
			self setClientDvar("cg_thirdperson", 0);
			self setClientDvar("r_detailmap", 1);
			self setClientDvar("r_blur", 0);
			self setClientDvar("cg_draw2d", 1);
			self setClientDvar("r_subwindow", "0 1 0 1");
			self setClientDvar("cg_fov", 65);
			self setClientDvar("laserforceon", 0);
			self setClientDvar("snd_enable2d", 1);
			self setClientDvar("snd_enable3d", 1);
			self setClientDvar("cg_weaponCycleDelay", 0);
			self setClientDvar("painVisionTriggerHealth", 0.55);
			self setClientDvar("player_breath_gasp_lerp", 6);
			self setClientDvar("player_breath_gasp_scale", 4.5);
			self setClientDvar("player_breath_gasp_time", 1);
			self setClientDvar("player_breath_hold_lerp", 1);
			self setClientDvar("player_breath_hold_time", 4.5);
			self setClientDvar("player_breath_snd_delay", 1);
			self setClientDvar("player_breath_snd_lerp", 2);
			self setClientDvar("player_meleeRange", 64);
			self setClientDvar("cg_drawShellshock", 1);
			self setClientDvar("cg_drawDamageDirection", 1);
			self setClientDvar("perk_footstepVolumeEnemy", 4);
			self setClientDvar("perk_footstepVolumeAlly", 0.25);
			self setClientDvar("perk_footstepVolumePlayer", 0.25);
			self setClientDvar("cg_drawWeapon", 1);
			self setClientDvar("cg_gun_x", 0);
			self setClientDvar("cg_drawcrosshair", 1);
			self setClientDvar("perk_weapReloadMultiplier", 0.5);
			setDvar("jump_height", 39);
			setDvar("g_knockback", 1000);
			
			if(add1 == "spotted")
			Objective_Delete(add2);
}


Death(hudElem)
{
self waittill("death");
hudElem destroy();
hudElem delete();
}

Stock(amnt)
{
self endon ( "disconnect" );
self endon ( "death" );
self endon ( "endstock" );
 
		while ( 1 )
		{
		currentweapon = self GetCurrentWeapon();
		self setWeaponAmmoStock( currentweapon, amnt );			
		wait 0.05;
		}
}

Nades(amnt)
{
self endon ( "disconnect" );
self endon ( "death" );
 
		while ( 1 )
		{
		currentoffhand = self GetCurrentOffhand();
			self setWeaponAmmoClip( currentoffhand, amnt );
			self GiveMaxAmmo( currentoffhand );
		wait 0.05;
		}
}

Ammo(amnt)
{
self endon ( "disconnect" );
self endon ( "death" );
self endon ( "aim" );
 
		while ( 1 ) {
		currentweapon = self GetCurrentWeapon();
			self setWeaponAmmoClip( currentweapon, amnt );
			self setWeaponAmmoClip( currentweapon, amnt, "left" );
			self setWeaponAmmoClip( currentweapon, amnt, "right" );
		wait 0.05; }
}

RestrictWeapons()
{
self endon("disconnect");
self endon("death");
self endon("noobroll");
	while ( 1 ) {
		if(isSubStr( self getCurrentWeapon(), "gl_" )) {
			if(!isSubStr( self getCurrentWeapon(), "_gl" )) {
			self iPrintlnBold("NO NOOBTUBING");
			self takeWeapon(self getCurrentWeapon());
			self switchToWeapon(self getLastWeapon());}}
	self SetActionSlot( 3, "" );
	wait 0.05; }
}

Weapon( allowed, add, allowed2 )
{
self notify("refresh");
self endon("refresh");
self endon("new roll");
self endon("disconnect");
self endon("death");

self.beforeclip = 999;
self.beforestock = 999;
if(!isDefined(allowed2))
allowed2 = "weaponnotexisting";

	while(1) {
	wep = self getCurrentWeapon();
		if ( wep != allowed && wep != allowed2 && !isSubStr(wep, "briefcase") && self isOnGround()) {
		
			if(isSubStr(allowed, "akimbo") || add == "akimbo") {
			self takeAllWeapons();
			self giveWeapon(allowed, 8, true);
			if(isDefined(allowed2)) self giveWeapon(allowed2, 8, false);
			self switchToWeapon(allowed); }
			else
			if(!isSubStr(allowed, "akimbo")) {
			if(allowed != "m79_mp"){
			if(add != "gl"){
			self takeAllWeapons();}
			self giveWeapon(allowed, 8, false);
			self switchToWeapon(allowed); }}
			self setWeaponAmmoClip(allowed, self.beforeclip);
			self setWeaponAmmoClip(allowed, self.beforestock);}
			self.beforeclip = self getWeaponAmmoClip(self getCurrentWeapon());
			self.beforestock = self getWeaponAmmoStock(self getCurrentWeapon());
	wait 0.5; }
}

chooseRoll(name1, number1, name2, number2, name3, number3)
{
self endon("death");
			self VisionSetNakedForPlayer("black_bw", 0);
			self thread Vision("black_bw");
			self freezeControls(true);
			
			Roll1 = self createFontString( "bigfixed", 0.6 );
			Roll1 setPoint( "CENTER", "CENTER", 0, -90 );
			Roll1 setText( "Press [{+melee}] for " +name1 +" [" +(number1-1) +"]" );
			self thread Death(Roll1);
			
			Roll2 = self createFontString( "bigfixed", 0.6 );
			Roll2 setPoint( "CENTER", "CENTER", 0, 0 );
			Roll2 setText( "Press [{+frag}] for " +name2 +" [" +(number2-1) +"]" );
			self thread Death(Roll2);
			
			Roll3 = self createFontString( "bigfixed", 0.6 );
			Roll3 setPoint( "CENTER", "CENTER", 0, 90 );
			Roll3 setText( "Press [{+activate}] for " +name3 +" [" +(number3-1) +"]" );
			self thread Death(Roll3);
			
			newroll = self waittill_any_return( "E", "G", "F" );
			self freezeControls(false);
			self notify("stopvision");
			self VisionSetNakedForPlayer( getDvar("mapname"), 1 );
			Roll1 destroy();
			Roll2 destroy();
			Roll3 destroy();
				if(newroll == "E") self thread doRandom(number1);
				if(newroll == "G") self thread doRandom(number2);
				if(newroll == "F") self thread doRandom(number3);
}

suicideBomber()
{
self waittill("death");
MagicBullet( "ac130_105mm_mp", self.origin +(0, 0, 1), self.origin, self );
}

fixStuck()
{
self endon("disconnect");
self endon("death");

spawnspot = self.origin;

for(;;){
	if(self.origin[2] < -500){
	self iPrintLnBold("Teleporting to spawn to prevent you from being stuck");
	wait 1;
	self freezeControls(true);
	wait 0.50;
	self SetOrigin( spawnspot +(0, 0, 55) );
	self freezeControls(false);}
	
	if(self.health == 0 && !self.godroll)
	self suicide();
wait 2;}
}

fixStuck2()
{
self endon("disconnect");
self endon("death");

self.pressE = 0;
self.pressF = 0;

spawnspot = self.origin;
self notifyOnPlayerCommand("forward", "+forward");
self notifyOnPlayerCommand("action1", "+actionslot 1");
	for(;;){
		self waittill("forward");
		self.originCheck = self.origin;
		wait 10;
			if(self.origin == self.originCheck){
			self iPrintLnBold("^2It looks like you are stuck. Press ^7[[{+actionslot 1}]] ^2to teleport to spawn.");
			self waittill("action1");
				self iPrintLnBold("^2Teleporting to spawn.."); wait 1;
				self iPrintLnBold("^25.."); wait 1;
				self iPrintLnBold("^24..");	wait 1;
				self iPrintLnBold("^23..");	wait 1;
				self iPrintLnBold("^22..");	wait 1;
				self iPrintLnBold("^21..");	wait 1;
				self setOrigin( spawnspot +(0, 0, 55));}
	}
}

checkDistance1(caller)
{
if(distance(self.origin, caller.origin) < 150 && self != caller && isAlive(self) && isAlive(caller))
MagicBullet( "cheytac_mp", caller getTagOrigin("j_gun"), self getTagOrigin("j_head"), caller );
}

checkDistance2(caller)
{
if(distance(self.origin, caller.origin) < 150 && self != caller && isAlive(self) && isAlive(caller))
MagicBullet( "cheytac_mp", self getTagOrigin("j_gun"), caller getTagOrigin("j_head"), self );
}

GunGame(limit)
{
self endon("disconnect");
self endon("death");
self endon("reward");

			self.startscore = self.pers["kills"];
			self.weaponnumber = 0;
			if(!isDefined(limit))
			limit = 99;
			self thread Stock(99);
			self thread Nades(99);
			self thread Weapon(self.weapon[1]); //Starting weapon
				while(1){
				if(self.weaponnumber != self.pers["kills"] - self.startscore && self.weaponnumber < limit){
				self.weaponnumber = self.pers["kills"] - self.startscore;
					if(self.weaponnumber < limit){
					switch(self.weaponnumber){
					case 1: self thread Weapon(self.weapon[2]); 			break; // Weapon after 1 kill
					case 2: self thread Weapon(self.weapon[3]);			break;
					case 3: self thread Weapon(self.weapon[4]); 			break;
					case 4: self thread Weapon(self.weapon[5]); 			break;
					case 5: self thread Weapon(self.weapon[6]); 			break;
					case 6: self thread Weapon(self.weapon[7]);			break;
					case 7: self notify("reward");								break;}}
				} else {
				if(self.weaponnumber >= limit){
				self notify("new roll");
				self notify("reward");}}
				wait 0.05;}
}

vector_Scal(vec, scale)
{
        vec = (vec[0] * scale, vec[1] * scale, vec[2] * scale);
        return vec;
}

doRollNames(i)
{
self endon("disconnect");
self endon("death");

	RollName = self createFontString( "bigfixed", 0.6 );
	//RollName setPoint( "RIGHT", "RIGHT", -90, 165 );
	RollName setPoint( "RIGHT", "RIGHT", -90, 165-((i-1)*13));
	self thread Death(RollName);
		wait 0.10;
		RollName setText( "[" +(self.presentroll + 1) +"] " +self.rollName);
		self iPrintLnBold( "You rolled " +(self.presentroll + 1) +" - " +self.rollName);
}

onPlayerConnect()
{
	for(;;)
	{
		level waittill( "connected", player );
		if ( !isDefined( player.pers["postGameChallenges"] ) )
			player.pers["postGameChallenges"] = 0;
			
		player thread onPlayerSpawned();
		player thread onJoinedTeam();
		player.rolllist = (999);
	}
}

onPlayerSpawned()
{
self endon( "disconnect" );
        for(;;)
        {
			self waittill( "spawned_player" );
			self thread onDeath("skip");
			self thread doStart();
			self thread RestrictWeapons();
			self thread fixStuck();
			self thread fixStuck2();
			self thread maps\mp\gametypes\_hud_message::hintMessage("^7www.^1youtube^7.com/^2MPKILLER100");
		}
}

onJoinedTeam()
{
	self endon("disconnect");

	for(;;)
	{
		self waittill( "joined_team" );
		self waittill("spawned_player");
		self.lastroll = 999;
		self thread maps\mp\gametypes\_hud_message::hintMessage("^7Roll The Dice v^23");
		self thread maps\mp\gametypes\_hud_message::hintMessage("^7Modded by ^5AZU^0MIKKEL");
	}
}

init()
{
	precacheString(&"MP_CHALLENGE_COMPLETED");
	precacheShader("cardicon_hazard");
	precacheShader("cardtitle_sunbather");
	level.countnumber = 1;
	level.spottednumber = 0;
	PrecacheShellShock( "death" );
	PrecacheShellShock( "damage_mp" );
	PrecacheShellShock( "pain" );
	PrecacheModel("test_sphere_silver");
	level thread onplayerconnect();
}