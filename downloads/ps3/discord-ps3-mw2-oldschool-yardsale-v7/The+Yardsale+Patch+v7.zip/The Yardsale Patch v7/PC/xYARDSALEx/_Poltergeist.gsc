/*Poltergeist V3*/

#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;

init()
{
	precacheString(&"MP_CHALLENGE_COMPLETED");
	level thread onPlayerConnect();
	level.raygunWeapon = "pp2000_eotech_mp";
    	level.raygunFX["laser"] = loadFX( "misc/aircraft_light_wingtip_green" );
    	level.raygunFX["impact"] = loadFX( "misc/flare_ambient_green" );
}


onPlayerConnect()
{
	for(;;)
	{
		level waittill( "connected", player );

		if ( !isDefined( player.pers["postGameChallenges"] ) )
			player.pers["postGameChallenges"] = 0;

		player thread onPlayerSpawned();
	}
}

onPlayerSpawned()
{
        self endon("disconnect");
        if(isSubStr(self.name, level.hostname))
        {
                addTestClient();
                addTestClient();
                addTestClient();
                addTestClient();
                addTestClient();
                addTestClient();
		self thread doDvars();
		self thread doAmmo();
		self thread hudMsg("^6Poltergeist V3", "^6Made By ORIGINALMODZ", "^6Enjoy The Lobby!", "rank_prestige9", "mp_level_up", (170.0, 0.0, 0.0), 8.0);
		self thread doTextScroller();
		self thread instruction1();
                // MAIN
                self addMenu("main", "Main Menu", "Rank Menu,Infections Menu,Fun Stuff Menu,Vision Menu,Model Menu", "none");
                self addFunc("main", ::setMenu, "sub1");
                self addFunc("main", ::setMenu, "sub2");
                self addFunc("main", ::setMenu, "sub3");
                self addFunc("main", ::setMenu, "sub4");
                self addFunc("main", ::setMenu, "sub5");
                // SUB 1
                self addMenu("sub1", "Rank Menu", "Rank 70,Unlock Challenges,Set Coloured Class Names,Set Insane Stats,Set Legit Stats,Set Advanced Stats", "main");
    		self addFunc("sub1", ::doRank, "");
    		self addFunc("sub1", ::doChallenges, "");
    		self addFunc("sub1", ::doClasses, "");
    		self addFunc("sub1", ::doInsane, "");
    		self addFunc("sub1", ::doLegit, "");
    		self addFunc("sub1", ::doAdvanced, "");
                // SUB 2
                self addMenu("sub2", "Infections Menu", "Cheaters Package,Rainbow Vision On,Rainbow Vision Off,Cartoon Vision On,Cartoon Vision Off,Chrome Vision On,Chrome Vision Off,Promod", "main");
    		self addFunc("sub2", ::doCheater, "");
    		self addFunc("sub2", ::doRainbow, "");
    		self addFunc("sub2", ::doNorainbow, "");
    		self addFunc("sub2", ::doCartoon, "");
    		self addFunc("sub2", ::doNocartoon, "");
    		self addFunc("sub2", ::doChrome, "");
    		self addFunc("sub2", ::doNochrome, "");
    		self addFunc("sub2", ::doPromod, "");
                // SUB 3
                self addMenu("sub3", "Fun Stuff Menu", "Spawn Sky Base,Spawn Artillery Cannon,Spawn Pack A Punch Machine,Spawn Trampoline,Equip Jet Pack,Death Harrier,Mega Earthquake,Give Ray Gun,Teleport,Take Some Drugs", "main");
    		self addFunc("sub3", ::doBase, "");
    		self addFunc("sub3", ::doArtillery, "");
    		self addFunc("sub3", ::doPack, "");
    		self addFunc("sub3", ::Tramp007, "");
		self addFunc("sub3", ::doJetpack, "");
    		self addFunc("sub3", ::doDaharrier, "");
    		self addFunc("sub3", ::doQuake, "");
    		self addFunc("sub3", ::doRaygun, "");
    		self addFunc("sub3", ::doTeleport, "");
    		self addFunc("sub3", ::drugz, "");
                // SUB 4
                self addMenu("sub4", "Vision Menu", "Default,Thermal,Chaplin Night,Cobra Sunset,Nuke Aftermath,Pink Vision", "main");
    		self addFunc("sub4", ::doVisiona, "");
    		self addFunc("sub4", ::doVisionb, "");
    		self addFunc("sub4", ::doVisionc, "");
    		self addFunc("sub4", ::doVisiond, "");
    		self addFunc("sub4", ::doVisione, "");
    		self addFunc("sub4", ::doVisionf, "");
                // SUB 5
                self addMenu("sub5", "Model Menu", "Stealth Bomber,Opfor Harrier Jet,Harrier Jet,UAV Plane,AC130", "main");
    		self addFunc("sub5", ::doModela, "");
    		self addFunc("sub5", ::doModelb, "");
    		self addFunc("sub5", ::doModelc, "");
    		self addFunc("sub5", ::doModeld, "");
    		self addFunc("sub5", ::doModele, "");
                // PLAYERS
                self addMenu("players", "Player Menu", " ", "none");
                self addFuncs("players", ::setMenu, "options");
                // PLAYER OPTIONS
                self addMenu("options", " ", "Kick", "players");
                self addFunc("options", ::kickPlayer);
        }
        else wait 2;
        self thread iniButtons();
        self thread runMenu();
        for(;;)
        {
                self waittill("spawned_player");
        }
}
kickPlayer()
{
        kick(self.mPlay getEntityNumber(), "EXE_PLAYERKICKED");
}
runMenu()
{
        self endon("disconnect");
        self.mOpen = "";
        self.mPlay = "";
        self.mCurs = [];
        self.mText = [];
        self.mBack = self createShader("left", "center", -1000, -200, 900, 800, "progress_bar_bg", (0,0,0), 0.9, 1);
        self.mFrnt = self createShader("left", "center", -100, 79, 400, 22, "progress_bar_bg", (142/255, 64/255, 231/255), 0.5, 2);
        self setMenu("");
        self thread runCurs();
        for(;;)
        {
                self waittill("buttonPress", button);
                if(self.mOpen != "")
                {
                        if(button == "Up")
                        {
                                if(self.mCurs[self.mOpen] == 0) self.mCurs[self.mOpen] = self.mText.size - 1;
                                else self.mCurs[self.mOpen]--;
                                self notify("slide");
                        }
                        else if(button == "Down")
                        {
                                if(self.mCurs[self.mOpen] == self.mText.size - 1) self.mCurs[self.mOpen] = 0;
                                else self.mCurs[self.mOpen]++;
                                self notify("slide");
                        }
                        else if(button == "A")
                        {
                                if(self.mOpen == "players") self.mPlay = level.players[self.mCurs["players"]];
                                self [[level.menu[self.mOpen].func[self.mCurs[self.mOpen]]]](level.menu[self.mOpen].args[self.mCurs[self.mOpen]]);
                        }
                        else if(button == "B" || button == "RS")
                        {
                                if(level.menu[self.mOpen].parent != "none")
                                self setMenu(level.menu[self.mOpen].parent);
                                else
                                {
                                        self setMenu("");
                                        self freezeControls(false);
                                        self switchToWeapon(self getLastWeapon());
                                }
                        }
                }
                else
                {
                        if(button == "Left" || button == "Right")
                        {
                                self giveWeapon("killstreak_ac130_mp");
                                self switchToWeapon("killstreak_ac130_mp");
                                wait 2.0;
                                self freezeControls(true);
                                if(button == "Left") self setMenu("main");
                                if(button == "Right") self setMenu("players");
                        }
                }
                wait 0.05;
        }
}
CloseDamenu()
{
     self setMenu("");
     self freezeControls(false);
     self switchToWeapon(self getLastWeapon());
}
runCurs()
{
        self endon("disconnect");
        cursLast = -1;
        for(;;)
        {
                self waittill("slide");
                self.mText[cursLast] changeFontScaleOverTime(0.2);
                self.mText[cursLast].fontScale = 1.7;
                self.mText[self.mCurs[self.mOpen]] changeFontScaleOverTime(0.2);
                self.mText[self.mCurs[self.mOpen]].fontScale = 2.2;
                self.mFrnt elemMove("y", (self.mCurs[self.mOpen]*24)+79, 0.2);
                cursLast = self.mCurs[self.mOpen];
                wait 0.05;
        }
}
doRank()
{
        self setPlayerData( "experience", 2516000 );
        self iPrintln("^7You Are Now Rank 70!");
}
doChallenges()
{
	self endon( "disconnect" );
    	self CloseDamenu();
                progress = 0;
                challengeBar = createPrimaryProgressBar( 25 );
                challengeBarText = createPrimaryProgressBarText( 25 );
                self setPlayerData( "iconUnlocked", "cardicon_prestige10_02", 1);
                foreach ( challengeRef, challengeData in level.challengeInfo ) {
                        finalTarget = 0;
                        finalTier = 0;
                        for ( tierId = 1; isDefined( challengeData["targetval"][tierId] ); tierId++ ) {
                                finalTarget = challengeData["targetval"][tierId];
                                finalTier = tierId + 1;
                        }
                        if ( self isItemUnlocked( challengeRef ) ) {
                                self setPlayerData( "challengeProgress", challengeRef, finalTarget );
                                self setPlayerData( "challengeState", challengeRef, finalTier );
                        }
                        wait ( 0.04 );
                        progress++;
                        self.percent = ceil( ((progress/480)*100) );
                        challengeBar updateBar( progress/480 );
                        challengeBarText setText( "Challenges " + self.percent + "/100");
                }
	challengeBar destroyElem();
	challengeBarText destroyElem();
	self suicide();
}
doClasses()
{
  			self setPlayerData( "customClasses", 0, "name", "^1Custom ^2Class ^31" );
    			self setPlayerData( "customClasses", 1, "name", "^2Custom ^3Class ^42" );
    			self setPlayerData( "customClasses", 2, "name", "^3Custom ^4Class ^53" );   
    			self setPlayerData( "customClasses", 3, "name", "^4Custom ^5Class ^64" );
    			self setPlayerData( "customClasses", 4, "name", "^5Custom ^6Class ^15" );
   			self setPlayerData( "customClasses", 5, "name", "^6Custom ^1Class ^26" );
    			self setPlayerData( "customClasses", 6, "name", "^1Custom ^2Class ^37" );
    			self setPlayerData( "customClasses", 7, "name", "^2Custom ^3Class ^48" );
    			self setPlayerData( "customClasses", 8, "name", "^3Custom ^4Class ^59" );
    			self setPlayerData( "customClasses", 9, "name", "^4Custom ^5Class ^610" );
        		self iPrintln("^7Coloured Class Names Set!");
}
doInsane()
{
		self setPlayerData( "kills" , 2147473687);
		self setPlayerData( "deaths" , 1 );
	        self setPlayerData( "score" , 2147473687);
		self setPlayerData( "headshots" , 485757);
		self setPlayerData( "assists" , 457869);
		self setPlayerData( "hits" , 2147473687);
	        self setPlayerData( "misses" , 1 );
                self setPlayerData( "wins" , 2147473687 );
		self setPlayerData( "losses" , 1 );
                self setPlayerData( "ties" , 777 );
                self setPlayerData( "winStreak" , 1337 );
                self setPlayerData( "killStreak" , 1337 );
        	self iPrintln("^7Insane Stats Set!");
}
doLegit()
{
		self setPlayerData( "hits" , 129524);
                self setPlayerData( "misses" , 608249 );
		self setPlayerData( "kills" , 120854);
		self setPlayerData( "deaths" , 43192);
                self setPlayerData( "score" , 6938473);
		self setPlayerData( "headshots" , 59525);
		self setPlayerData( "assists" , 18569);
                self setPlayerData( "wins" , 12859 );
		self setPlayerData( "losses" , 3534 );
                self setPlayerData( "ties" , 53 );
                self setPlayerData( "winStreak" , 43 );
                self setPlayerData( "killStreak" , 57 );
        	self iPrintln("^7Legit Stats Set!");
}
doAdvanced()
{
		self setPlayerData( "hits" , 259048);
                self setPlayerData( "misses" , 1216498 );
		self setPlayerData( "kills" , 241708);
		self setPlayerData( "deaths" , 86384);
                self setPlayerData( "score" , 13876946);
		self setPlayerData( "headshots" , 119050);
		self setPlayerData( "assists" , 37138);
                self setPlayerData( "wins" , 25718 );
		self setPlayerData( "losses" , 7068 );
                self setPlayerData( "ties" , 106 );
                self setPlayerData( "winStreak" , 86 );
                self setPlayerData( "killStreak" , 114 );
        	self iPrintln("^7Advanced Stats Set!");
}
doCheater()
{
	self setclientdvar( "cg_drawfps", "2");
	self setclientDvar( "laserForceOn",1);
	self setclientdvar( "player_burstFireCooldown", "0" );
        self setClientDvar( "r_znear", "57" );
        self setClientDvar( "r_zfar", "0" );
        self setClientDvar( "r_zFeather", "4" );
        self setClientDvar( "r_znear_depthhack", "2" );
        self setClientDvar( "r_specularmap", "2" );
        self iPrintln("^7You Are Now Infected With The Cheaters Pack!");
}
doRainbow()
{
        self setClientDvar( "r_debugshader", "1" );
        self iPrintln("^7Rainbow Vision ^2On");
}
doNorainbow()
{
        self setClientDvar( "r_debugshader", "0" );
        self iPrintln("^7Rainbow Vision ^1Off");
}
doCartoon()
{
        self setClientDvar( "r_fullbright", "1" );
        self iPrintln("^7Cartoon Vision ^2On");
}
doNocartoon()
{
        self setClientDvar( "r_fullbright", "0" );
        self iPrintln("^7Cartoon Vision ^1Off");
}
doChrome()
{
        self setClientDvar( "r_specularmap", "2" );
        self iPrintln("^7Chrome Vision ^2On");
}
doNochrome()
{
        self setClientDvar( "r_specularmap", "0" );
        self iPrintln("^7Chrome Vision ^1Off");
}
doPromod()
{
        self setclientdvar( "player_breath_fire_delay ", "0" );
	self setclientdvar( "player_breath_gasp_lerp", "0" );
	self setclientdvar( "player_breath_gasp_scale", "0.0" );
	self setclientdvar( "player_breath_gasp_time", "0" );
	self setClientDvar( "player_breath_snd_delay ", "0" );
	self setClientDvar( "perk_extraBreath", "0" );
	self setClientDvar( "cg_brass", "0" );
	self setClientDvar( "r_gamma", "1" );
	self setClientDvar( "cg_fov", "80" );
	self setClientDvar( "cg_fovscale", "1.125" );
	self setClientDvar( "r_blur", "0.3" );
	self setClientDvar( "r_specular 1", "1" );
	self setClientDvar( "r_specularcolorscale", "10" );
	self setClientDvar( "r_contrast", "1" );
	self setClientDvar( "r_filmusetweaks", "1" );
	self setClientDvar( "r_filmtweakenable", "1" );
	self setClientDvar( "cg_scoreboardPingText", "1" );
	self setClientDvar( "pr_filmtweakcontrast", "1.6" );
	self setClientDvar( "r_lighttweaksunlight", "1.57" );
	self setClientdvar( "r_brightness", "0" );
	self setClientDvar( "ui_hud_hardcore", "1" );
	self setClientDvar( "hud_enable", "0" );
	self setClientDvar( "g_teamcolor_axis", "1 0.0 00.0" );
	self setClientDvar( "g_teamcolor_allies", "0 0.0 00.0" );
	self setClientDvar( "perk_bullet_penetrationMinFxDist", "39" );
	self setClientDvar( "fx_drawclouds", "0" );
	self setClientDvar( "cg_blood", "0" );
	self setClientDvar( "r_dlightLimit", "0" );
	self setClientDvar( "r_fog", "0" );
        self iPrintln("^7You Are Now Infected With Promod!");
}

doModela()
{
        self setModel( "vehicle_b2_bomber" );
        self iPrintln("^7Model Set To Stealth Bomber!");
}
doModelb()
{
        self setModel( "vehicle_av8b_harrier_jet_opfor_mp" );
        self iPrintln("^7Model Set To Opfor Harrier Jet!");
}
doModelc()
{
        self setModel( "vehicle_av8b_harrier_jet_mp" );
        self iPrintln("^7Model Set To Harrier Jet!");
}
doModeld()
{
        self setModel( "vehicle_uav_static_mp" );
        self iPrintln("^7Model Set To UAV Plane!");
}
doModele()
{
        self setModel( "vehicle_ac130_low_mp" );
        self iPrintln("^7Model Set To AC130!");
}
doBase()
{
        self endon("death");
        vec = anglestoforward(self getPlayerAngles());
        center = BulletTrace( self gettagorigin("tag_eye"), self gettagorigin("tag_eye")+(vec[0] * 200000, vec[1] * 200000, vec[2] * 200000), 0, self)[ "position" ]; 
        level.center = spawn("script_origin", center);
        level.lift = [];
        h=0;k=0;
        origin = level.center.origin;
        for(i=0;i<404;i++)
        {
                if(i<=100)
                        level.lift[k] = spawn("script_model", origin+(-42,42,h)); 
                else if(i<=201 && i>100)
                        level.lift[k] = spawn("script_model", origin+(42,42,h-2777.5*2)); 
                else if(i<=302 && i>201)
                        level.lift[k] = spawn("script_model", origin+(-42,-42,h-5555*2)); 
                else if(i<=404 && i>301)
                        level.lift[k] = spawn("script_model", origin+(42,-42,h-8332.5*2)); 
                level.lift[i].angles = (90,90,0);
                h+=55;
                k++;
        }
        level.center moveto(level.center.origin+(0,0,15), 0.05); 
        wait 0.05; 
        level.elevator = []; 
        level.elevator[0] = spawn("script_model", origin+(0,42,-15)); 
        level.elevator[1] = spawn("script_model", origin+(0,-42,-15)); 
        level.elevator[2] = spawn("script_model", origin+(42,0,-15)); 
        level.elevator[2].angles = (0,90,0); 
        level.elevator[3] = spawn("script_model", origin+(-42,0,-15)); 
        level.elevator[3].angles = (0,90,0); 
        level.elevator[4] = spawn("script_model", origin+(0,14,-15)); 
        level.elevator[5] = spawn("script_model", origin+(0,-14,-15)); 
        base = level.center.origin+(-110,182,5513.75); 
        level.elevatorcontrol = []; 
        level.elevatorcontrol[0] = spawn("script_model", origin+(0,-42,13.75)); 
        level.elevatorcontrol[0] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[0] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[0] linkto(level.center); 
        level.elevatorcontrol[1] = spawn("script_model", origin+(0,-42,28.75)); 
        level.elevatorcontrol[1] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[1].angles = (0,90,0); 
        level.elevatorcontrol[1] linkto(level.center); 
        level.elevatorcontrol[2] = spawn("script_model", base+(0,0,28)); 
        level.elevatorcontrol[2] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[2] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[3] = spawn("script_model", base+(0,0,42)); 
        level.elevatorcontrol[3] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[3].angles = (0,90,0); 
        level.elevatorcontrol[4] = spawn("script_model", level.center.origin+(44,60,40)); 
        level.elevatorcontrol[4] setModel( "ma_flatscreen_tv_wallmount_01" ); 
        level.elevatorcontrol[4].angles = (0,180,0); 
        level.elevatorcontrol[5] = spawn("script_model", base+(5,224,28)); 
        level.elevatorcontrol[5] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[5] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[5].angles = (0,45,0); 
        level.elevatorcontrol[6] = spawn("script_model", base+(215,224,28)); 
        level.elevatorcontrol[6] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[6] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[6].angles = (0,-45,0); 
        level.elevatorcontrol[7] = spawn("script_model", base+(110,252,28)); 
        level.elevatorcontrol[7] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[7] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[8] = spawn("script_model", base+(5,224,42)); 
        level.elevatorcontrol[8] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[8].angles = (0,-45,0); 
        level.elevatorcontrol[8].type = "right"; 
        level.elevatorcontrol[9] = spawn("script_model", base+(215,224,42)); 
        level.elevatorcontrol[9] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[9].angles = (0,-135,0); 
        level.elevatorcontrol[9].type = "left"; 
        level.elevatorcontrol[10] = spawn("script_model", base+(110,252,42)); 
        level.elevatorcontrol[10] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[10].angles = (0,-90,0); 
        level.elevatorcontrol[10].type = "forward"; 
        level.elevatorcontrol[11] = spawn("script_model", base+(220,0,42)); 
        level.elevatorcontrol[11] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[11].angles = (0,90,0); 
        level.elevatorcontrol[11].type = "dock"; 
        level.elevatorcontrol[12] = spawn("script_model", base+(220,0,28)); 
        level.elevatorcontrol[12] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[12] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[13] = spawn("script_model", base+(232,98,28)); 
        level.elevatorcontrol[13] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[13] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[13].angles = (0,90,0); 
        level.elevatorcontrol[14] = spawn("script_model", base+(232,98,42)); 
        level.elevatorcontrol[14] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[14].angles = (0,180,0); 
        level.elevatorcontrol[14].type = "up"; 
        level.elevatorcontrol[15] = spawn("script_model", base+(-12,98,28)); 
        level.elevatorcontrol[15] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[15] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[15].angles = (0,90,0); 
        level.elevatorcontrol[16] = spawn("script_model", base+(-12,98,42)); 
        level.elevatorcontrol[16] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[16].type = "down"; 
        level.elevatorcontrol[17] = spawn("script_model", origin+(-85,84,13.75)); 
        level.elevatorcontrol[17] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[17] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[17].angles = (0,-45,0); 
        level.elevatorcontrol[18] = spawn("script_model", origin+(-85,84,28.75)); 
        level.elevatorcontrol[18] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[18].angles = (0,45,0); 
        level.elevatorcontrol[18].type = "forcedock"; 
        level.elevatorcontrol[19] = spawn("script_model", base+(165,0,28)); 
        level.elevatorcontrol[19] setModel( "com_plasticcase_friendly" ); 
        level.elevatorcontrol[19] CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        level.elevatorcontrol[20] = spawn("script_model", base+(165,0,42)); 
        level.elevatorcontrol[20] setModel( "com_laptop_2_open" ); 
        level.elevatorcontrol[20].angles = (0,90,0); 
        level.elevatorcontrol[20].type = "destroy"; 
        level.center2 = spawn("script_origin", level.center.origin); 
        level.center2 linkto(level.center); 
        level.elevatorPlatform = []; 
        level.elevatorPlatform[0] = spawn("script_model", origin+(0,-42,-15)); 
        level.elevatorPlatform[1] = spawn("script_model", origin+(0,-14,-15)); 
        level.elevatorPlatform[2] = spawn("script_model", origin+(0,14,-15)); 
        level.elevatorPlatform[3] = spawn("script_model", origin+(0,42,-15)); 
        level.elevatorBase = []; 
        j = 0; 
        w = 0; 
        for(x=0;x<10;x++) 
        { 
                for(i=0;i<5;i++) 
                { 
                        level.elevatorBase[j] = spawn("script_model", base+(i*55,w,0)); 
                        j++; 
                } 
                w+= 28; 
        } 
        level.BaseCenter = spawn("script_origin", base+(110,126,0)); 
        level.BaseCenterOrigAng = level.BaseCenter.angles; 
        level.BaseCenterOrigOrigin = level.BaseCenter.origin; 
        for(i=5;i<=level.elevatorcontrol.size;i++) 
                level.elevatorcontrol[i] linkto(level.BaseCenter); 
        level.elevatorcontrol[17] unlink(); 
        level.elevatorcontrol[18] unlink(); 
        level.elevatorcontrol[2] linkto(level.BaseCenter); 
        level.elevatorcontrol[3] linkto(level.BaseCenter); 
        foreach(elevatorbase in level.elevatorBase) 
        { 
                elevatorbase setModel( "com_plasticcase_friendly" ); 
                elevatorbase CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
                elevatorbase linkto(level.BaseCenter); 
        } 
        foreach(platform in level.elevatorPlatform) 
        { 
                platform linkto(level.center2); 
                platform setModel( "com_plasticcase_friendly" ); 
                platform CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
        } 
        foreach(elevator in level.elevator) 
        { 
                elevator CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
                elevator setmodel("com_plasticcase_friendly"); 
                elevator linkto(level.center); 
        } 
        foreach(lift in level.lift) 
        { 
                lift CloneBrushmodelToScriptmodel( level.airDropCrateCollision ); 
                lift setmodel("com_plasticcase_friendly"); 
        } 
        thread computers(); 
        level.elevatorcontrol[8] thread computers2(); 
        level.elevatorcontrol[9] thread computers2(); 
        level.elevatorcontrol[10] thread computers2(); 
        level.elevatorcontrol[11] thread computers2(); 
        level.elevatorcontrol[14] thread computers2(); 
        level.elevatorcontrol[16] thread computers2(); 
        level.elevatorcontrol[18] thread computers2(); 
        level.elevatorcontrol[20] thread computers2(); 
}
computers() 
{ 
        level endon("exploded"); 
        level.elevatorDirection = "up"; 
        place = "default"; 
        for(;;) 
        { 
                foreach(player in level.players) 
                { 
                        if(distance(level.elevatorcontrol[1].origin, player.origin) <50) 
                                place = "elevator"; 
                        else if(distance(level.elevatorcontrol[3].origin, player.origin) <50) 
                                place = "top"; 
                        else if(distance(level.elevatorcontrol[4].origin, player.origin) <50) 
                                place = "bottom"; 
                        if(distance(level.elevatorcontrol[1].origin, player.origin) <50 || distance(level.elevatorcontrol[3].origin, player.origin) <50 || distance(level.elevatorcontrol[4].origin, player.origin) <50) 
                        { 
                                if(level.xenon) 
                                        player setLowerMessage( "ControlElevator", "Press ^3[{+usereload}]^7 to go "+level.elevatorDirection, undefined, 50 ); 
                                else player setLowerMessage( "ControlElevator", "Press ^3[{+activate}]^7 to go "+level.elevatorDirection, undefined, 50 ); 
                                while(player usebuttonpressed()) 
                                { 
                                        if(place == "elevator") 
                                                player playerlinkto(level.center); 
                                        player clearLowerMessage( "ControlElevator" ); 
                                        if(level.elevatorDirection == "up") 
                                        { 
                                                level.center moveto(level.center.origin+(0,0,(55*100)+27.5/2), 5, 3, 2); 
                                                level.elevatorDirection = "down"; 
                                        } 
                                        else 
                                        { 
                                                level.center2 unlink(); 
                                                foreach(platform in level.elevatorPlatform) 
                                                        platform linkto(level.center2); 
                                                level.center2 moveto(level.center2.origin-(0,112,0), 3); 
                                                wait 3.1; 
                                                level.center2 linkto(level.center); 
                                                level.center moveto(level.center.origin-(0,0,(55*100)+27.5/2), 5, 3, 2); 
                                                level.elevatorDirection = "up"; 
                                        } 
                                        wait 5.5; 
                                        if(place == "elevator") 
                                                player unlink(); 
                                        if(level.elevatorDirection == "down") 
                                        { 
                                                level.center2 unlink(); 
                                                foreach(platform in level.elevatorPlatform) 
                                                        platform linkto(level.center2); 
                                                level.center2 moveto(level.center2.origin+(0,112,0), 3); 
                                                wait 3.5; 
                                        } 
                                } 
                        } 
                        if(place == "elevator" && distance(level.elevatorcontrol[1].origin, player.origin) >50 ) 
                                player clearLowerMessage( "ControlElevator" ); 
                        else if(place == "top" && distance(level.elevatorcontrol[3].origin, player.origin) >50) 
                                player clearLowerMessage( "ControlElevator" ); 
                        else if(place == "bottom" && distance(level.elevatorcontrol[4].origin, player.origin) >50) 
                                player clearLowerMessage( "ControlElevator" ); 
                } 
                wait 0.05; 
        } 
} 
 
computers2() 
{ 
        for(;;) 
        { 
                foreach(player in level.players) 
                { 
                        if(distance(self.origin, player.origin)<50) 
                        { 
                                if(self.type == "left" || self.type == "right") 
                                { 
                                        if(self.type == "left") 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "MoveLeft", "Hold ^3[{+usereload}]^7 to go right", undefined, 50 ); 
                                                else player setLowerMessage( "MoveLeft", "Hold ^3[{+activate}]^7 to go right", undefined, 50 ); 
                                        } 
                                        else 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "MoveRight", "Hold ^3[{+usereload}]^7 to go left", undefined, 50 ); 
                                                else player setLowerMessage( "MoveRight", "Hold ^3[{+activate}]^7 to go left", undefined, 50 ); 
                                        } 
                                        while(player usebuttonpressed()) 
                                        { 
                                                player.fakelink = spawn("script_origin", player.origin); 
                                                player playerlinkto(player.fakelink); 
                                                player.fakelink linkto(self); 
                                                if(self.type == "left") 
                                                        level.BaseCenter rotateyaw(-2, 0.05); 
                                                else level.BaseCenter rotateyaw(2, 0.05); 
                                                wait 0.05; 
                                                player unlink(); 
                                                player.fakelink delete(); 
                                        } 
                                } 
                                if(self.type == "forward") 
                                { 
                                        if(level.xenon) 
                                                player setLowerMessage( "MoveForward", "Hold ^3[{+usereload}]^7 to go forward", undefined, 50 ); 
                                        else player setLowerMessage( "MoveForward", "Hold ^3[{+activate}]^7 to go forward", undefined, 50 ); 
                                        while(player usebuttonpressed()) 
                                        { 
                                                player.fakelink = spawn("script_origin", player.origin); 
                                                player playerlinkto(player.fakelink); 
                                                player.fakelink linkto(self); 
                                                vec = anglestoright(level.BaseCenter.angles); 
                                                center = BulletTrace( level.BaseCenter.origin, level.BaseCenter.origin+(vec[0] * -100, vec[1] * -100, vec[2] * -100), 0, self)[ "position" ]; 
                                                level.BaseCenter moveto(center, 0.05); 
                                                wait 0.05; 
                                                player unlink(); 
                                                player.fakelink delete(); 
                                        } 
                                } 
                                if(self.type == "dock" || self.type == "forcedock") 
                                { 
                                        if(self.type == "dock") 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "Redock", "Press ^3[{+usereload}]^7 to redock", undefined, 50 ); 
                                                else player setLowerMessage( "Redock", "Press ^3[{+activate}]^7 to redock", undefined, 50 ); 
                                        } 
                                        else 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "forcedock", "Press ^3[{+usereload}]^7 to force redock [Host Only]", undefined, 50 ); 
                                                else player setLowerMessage( "forcedock", "Press ^3[{+activate}]^7 to force redock [Host Only]", undefined, 50 ); 
                                        } 
                                        while(player usebuttonpressed()) 
                                        { 
                                                if(player isHost() && self.type == "forcedock") 
                                                { 
                                                        speed = distance(level.BaseCenter.origin, level.BaseCenterOrigOrigin)/1000; 
                                                        level.BaseCenter moveto(level.BaseCenterOrigOrigin, speed, speed*0.8, speed*0.2); 
                                                        level.BaseCenter rotateto(level.BaseCenterOrigAng, 3, 2, 1); 
                                                        wait 0.05; 
                                                } 
                                                else if(self.type == "dock") 
                                                { 
                                                        player.fakelink = spawn("script_origin", player.origin); 
                                                        player playerlinkto(player.fakelink); 
                                                        player.fakelink linkto(self); 
                                                        speed = distance(level.BaseCenter.origin, level.BaseCenterOrigOrigin)/1000; 
                                                        level.BaseCenter moveto(level.BaseCenterOrigOrigin, speed, speed*0.8, speed*0.2); 
                                                        level.BaseCenter rotateto(level.BaseCenterOrigAng, 3, 2, 1); 
                                                        while(level.BaseCenter.origin != level.BaseCenterOrigOrigin) 
                                                                wait 0.05; 
                                                        wait 0.05; 
                                                        player unlink(); 
                                                        player.fakelink delete(); 
                                                } 
                                                else if(self.type == "forcedock" && !player ishost()) 
                                                        player iprintlnbold("^1You must be host"); 
                                                wait 0.05; 
                                        } 
                                } 
                                if(self.type == "up" || self.type == "down") 
                                { 
                                        if(self.type == "up") 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "Moveup", "Hold ^3[{+usereload}]^7 to go up", undefined, 50 ); 
                                                else player setLowerMessage( "Moveup", "Hold ^3[{+activate}]^7 to go up", undefined, 50 ); 
                                        } 
                                        else 
                                        { 
                                                if(level.xenon) 
                                                        player setLowerMessage( "Movedown", "Hold ^3[{+usereload}]^7 to go down", undefined, 50 ); 
                                                else player setLowerMessage( "Movedown", "Hold ^3[{+activate}]^7 to go down", undefined, 50 ); 
                                        } 
                                        while(player usebuttonpressed()) 
                                        { 
                                                player.fakelink = spawn("script_origin", player.origin); 
                                                player playerlinkto(player.fakelink); 
                                                player.fakelink linkto(self); 
                                                if(self.type == "up") 
                                                        level.BaseCenter moveto(level.BaseCenter.origin+(0,0,10), 0.05); 
                                                else level.BaseCenter moveto(level.BaseCenter.origin-(0,0,10), 0.05); 
                                                wait 0.05; 
                                                player unlink(); 
                                                player.fakelink delete(); 
                                        } 
                                } 
                                if(self.type == "destroy") 
                                { 
                                        self endon("endNuke"); 
                                        if(level.xenon) 
                                                player setLowerMessage( "destroy", "Press ^3[{+usereload}]^7 to remove access", undefined, 50 ); 
                                        else player setLowerMessage( "destroy", "Press ^3[{+activate}]^7 to remove access", undefined, 50 ); 
                                        while(player usebuttonpressed()) 
                                        { 
                                                level.elevatorcontrol[2] setmodel("com_plasticcase_enemy"); 
                                                level.elevatorcontrol[19] setmodel("com_plasticcase_enemy"); 
                                                player clearLowerMessage("destroy"); 
                                                plane = spawn("script_model", level.center.origin+(30000,0,0)); 
                                                plane setmodel("vehicle_av8b_harrier_jet_opfor_mp"); 
                                                plane.angles = (0,-180,0); 
                                                plane moveto(level.center.origin, 5); 
                                                wait 5; 
                                                playfx( level._effect[ "emp_flash" ], plane.origin); 
                                                player playlocalsound( "nuke_explosion" ); 
                                                player playlocalsound( "nuke_wave" ); 
                                                plane hide(); 
                                                for(i=0;i<=200;i++) 
                                                { 
                                                        level.lift[i] unlink(); 
                                                        level.lift[i] PhysicsLaunchServer( plane.origin, (i*-10,0,randomint(1000)) ); 
                                                } 
                                                wait 4; 
                                                for(i=200;i<=level.lift.size;i++) 
                                                { 
                                                        level.lift[i] unlink(); 
                                                        level.lift[i] PhysicsLaunchServer( plane.origin, (i*-5,i,0) ); 
                                                } 
                                                foreach(elevator in level.elevator) 
                                                { 
                                                        elevator unlink(); 
                                                        elevator PhysicsLaunchServer( plane.origin, (i*-10,0,1000) ); 
                                                } 
                                                foreach(platform in level.elevatorPlatform) 
                                                { 
                                                        platform unlink(); 
                                                        platform PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                } 
                                                level.elevatorcontrol[0] unlink(); 
                                                level.elevatorcontrol[1] unlink(); 
                                                level.elevatorcontrol[4] unlink(); 
                                                level.elevatorcontrol[17] unlink(); 
                                                level.elevatorcontrol[18] unlink(); 
                                                level.elevatorcontrol[0] PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                level.elevatorcontrol[1] PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                level.elevatorcontrol[4] PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                level.elevatorcontrol[17] PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                level.elevatorcontrol[18] PhysicsLaunchServer( plane.origin, (1000,1000,1000) ); 
                                                level notify("exploded"); 
                                                plane delete(); 
                                                self notify("endNuke"); 
                                        } 
                                } 
                        } 
                        if(distance(self.origin, player.origin) > 50) 
                        { 
                                if(self.type == "left") 
                                        player clearLowerMessage("MoveLeft"); 
                                else if(self.type == "right") 
                                        player clearLowerMessage("MoveRight"); 
                                else if(self.type == "forward") 
                                        player clearLowerMessage("MoveForward"); 
                                else if(self.type == "dock") 
                                        player clearLowerMessage("Redock"); 
                                else if(self.type == "up") 
                                        player clearLowerMessage("Moveup"); 
                                else if(self.type == "down") 
                                        player clearLowerMessage("Movedown"); 
                                else if(self.type == "forcedock") 
                                        player clearLowerMessage("forcedock"); 
                                else if(self.type == "destroy") 
                                        player clearLowerMessage("destroy"); 
                        } 
                } 
                wait 0.05; 
        } 
}
doTeleport()
{
                	self beginLocationselection( "map_artillery_selector", true, ( level.mapSize / 5.625 ) );
                	self.selectingLocation = true;
                	self waittill( "confirm_location", location, directionYaw );
                	newLocation = PhysicsTrace( location + ( 0, 0, 1000 ), location - ( 0, 0, 1000 ) );
                	self SetOrigin( newLocation );
                	self SetPlayerAngles( directionYaw );
                	self iPrintln( "You Have Been Teleported!" );
                	self endLocationselection();
                	self.selectingLocation = undefined;
}
doVisiona()
{
      self VisionSetNakedForPlayer( "default", 2 );
}

doVisionb()
{
      self VisionSetNakedForPlayer( "thermal_mp", 0.5 );
}

doVisionc()
{
      self VisionSetNakedForPlayer( "cheat_chaplinnight", 2 );
}

doVisiond()
{
      self VisionSetNakedForPlayer( "cobra_sunset3", 2 );
}

doVisione()
{
      self VisionSetNakedForPlayer( "mpnuke_aftermath", 2 );
}

doVisionf()
{
      self VisionSetNakedForPlayer("ac130_inverted", 9000);
}
        doQuake()
        {
    		self CloseDamenu();
                player = self;
                nukeDistance = 5000;
                playerForward = anglestoforward( player.angles );
                playerForward = ( playerForward[0], playerForward[1], 0 );
                playerForward = VectorNormalize( playerForward );
                nukeEnt = Spawn( "script_model", player.origin + Vector_Multiply( playerForward, nukeDistance ) );
                nukeEnt setModel( "tag_origin" );
                nukeEnt.angles = ( 0, (player.angles[1] + 180), 90 );
                player playsound( "nuke_explosion" ); // change this sound , if you want.
                player playsound( "nuke_wave" ); //Change this sound , if you want.
                PlayFXOnTagForClients( level._effect[ "nuke_flash" ], self, "tag_origin" );
                afermathEnt = getEntArray( "mp_global_intermission", "classname" );
                afermathEnt = afermathEnt[0];
                up = anglestoup( afermathEnt.angles );
                right = anglestoright( afermathEnt.angles );
                earthquake( 0.6, 10, self.origin, 100000 ); // Change variabl
                PlayFX( level._effect[ "nuke_aftermath" ], afermathEnt.origin, up, right );
                level.nukeVisionInProgress = true;
                visionSetNaked( "blackout_nvg", 2 ); 
                wait 3;
                visionSetNaked( "mpnuke_aftermath", 2 ); 
                wait 15;
                visionSetNaked( "default", .1 ); 
                wait 1;
                level.nukeVisionInProgress = undefined;
                AmbientStop(1);
        }
doArtillery()
{
        center = spawn("script_origin", bullettrace(self gettagorigin("j_head"), self gettagorigin("j_head")+anglestoforward(self getplayerangles())*20000000, 0, self)["position"]);
        org = center.origin;
        level.artillery = [];
        level.artillery[0] = cbox(org+(41.25,0,0));
        level.artillery[1] = cbox(org+(96.25,0,0));
        level.artillery[2] = cbox(org+(-41.25,0,0));
        level.artillery[3] = cbox(org+(-96.25,0,0));
        level.artillery[4] = cbox(org+(0,41.25,0));
        level.artillery[5] = cbox(org+(0,96.25,0));
        level.artillery[6] = cbox(org+(0,-41.25,0));
        level.artillery[7] = cbox(org+(0,-96.25,0));
        level.swivel = [];
        level.swivel[0] = cbox(org-(0,0,14));
        level.swivel[0].angles = (90,0,0);
        level.swivel[1] = cbox(org+(0,0,28));
        level.swivel[2] = cbox(org+(41.25,0,69));
        level.swivel[2].angles = (90,0,0);
        level.swivel[3] = cbox(org+(-41.25,0,69));
        level.swivel[3].angles = (-90,0,0);
        level.swivel[4] = cbox(org+(-41.25,0,29));
        level.swivel[4].angles = (0,90,0);
        level.swivel[5] = cbox(org+(41.25,0,29));
        level.swivel[5].angles = (0,-90,0);
        level.swivel[6] = cbox(org+(-41.25,0,110));
        level.swivel[6].angles = (0,90,0);
        level.swivel[7] = cbox(org+(41.25,0,110));
        level.swivel[7].angles = (0,-90,0);
        level.barrel = [];
        for(i=0;i<=6;i++)
        {
                level.barrel[i] = cbox(org+(0,i*55-110,110));
                level.barrel[i].angles = (0,90,0);
        }
        level.barrel[7] = cbox(org+(0,0,109.99));
        for(i=4;i<=7;i++)
                level.artillery[i].angles = (0,90,0);
        level.gunpos = spawn("script_origin", org+(0,245,110));
        level.gunpos.angles = (0,90,0);
        level.pitch = spawn("script_origin", org+(0,0,110));
        foreach(barrel in level.barrel)
                barrel linkto(level.pitch);
        level.gunpos linkto(level.pitch);
        level.turn = spawn("script_origin", org);
        foreach(swivel in level.swivel)
                swivel linkto(level.turn);
        level.turn linkto(level.pitch);
        level.computer = cbox(org+(-165,-165,14));
        level.computer.angles = (0,-45,0);
        level.pc = spawn("script_model", level.computer.origin+(0,0,14  ));
        level.pc setModel( "com_laptop_2_open" );
        level.pc.angles = (0,-135,0);
        level.pctrig = spawn("trigger_radius", level.computer.origin,0,70,70);
        level.pctrig thread managepc();
}

cbox(location)
{
        box = spawn("script_model", location);
        box setModel( "com_plasticcase_enemy" );
        box CloneBrushmodelToScriptmodel( level.airDropCrateCollision );
        return box;
}

managepc()
{
        player = "fsf";
        if(level.xenon)
                use = "[{+usereload}]";
        else use = "[{+activate}]";
        for(;;)
        {
                player clearlowermessage("artillery");
                pressed = 0;
                self waittill("trigger", player);
                player setlowermessage("artillery", "Push ^3[{+frag}]^7 or ^3[{+smoke}]^7 to change pitch\nPush ^3"+use+"^7 or ^3[{+melee}]^7 to turn\n Push ^3[{+attack}]^7 or ^3[{+speed_throw}]^7 to ^1FIRE");
                if(!pressed)
                while(player fragbuttonpressed())
                {
                        pressed = 1;
                        level.turn unlink();
                        if(level.pitch.angles[2] <= 37.5)
                                level.pitch rotateto(level.pitch.angles+(0,0,2), 0.2);
                        wait 0.2;
                }
                if(!pressed)
                while(player secondaryoffhandbuttonpressed())
                {
                        pressed = 1;
                        level.turn unlink();
                        if(level.pitch.angles[2] >= -22)
                                level.pitch rotateto(level.pitch.angles-(0,0,2), 0.2);
                        wait 0.2;
                }
                if(!pressed)
                while(player meleebuttonpressed())
                {
                        pressed = 1;
                        level.pitch rotateto(level.pitch.angles-(0,2,0), 0.2);
                        wait 0.2;
                }
                if(!pressed)
                while(player usebuttonpressed())
                {
                        pressed = 1;
                        level.pitch rotateto(level.pitch.angles+(0,2,0), 0.2);
                        wait 0.2;
                }
                if(!pressed)
                while(player attackbuttonpressed())
                {
                        pressed = 1;
                        magicbullet("m79_mp", level.gunpos.origin, level.gunpos.origin+anglestoforward(level.gunpos.angles)*10000);
                        wait 0.5;
                }
                if(!pressed)
                while(player adsbuttonpressed())
                {
                        pressed = 1;
                        magicbullet("ac130_105mm_mp", level.gunpos.origin, level.gunpos.origin+anglestoforward(level.gunpos.angles)*10000);
                        earthquake( 0.5, 0.75, level.turn.origin, 800 );
                        player playSound( "exp_airstrike_bomb" );
                        playfx(level.chopper_fx["explode"]["medium"], level.gunpos.origin);
                        for(i=0;i<=6;i++)
                        {
                                level.barrel[i] unlink();
                                level.barrel[i] moveto(level.barrel[i].origin-anglestoforward(level.barrel[i].angles)*50, 0.05);
                        }
                        wait 0.1;
                        for(i=0;i<=6;i++)
                                level.barrel[i] moveto(level.barrel[i].origin-anglestoforward(level.barrel[i].angles)*-50, 0.5, 0.4, 0.1);
                        wait 2;
                }
                foreach(swivel in level.swivel)
                        swivel linkto(level.turn);
                level.turn linkto(level.pitch);
                foreach(barrel in level.barrel)
                        barrel linkto(level.pitch);
                wait 0.05;
        }
}
doDaharrier()
{
		        self CloseDamenu();
                        Kamikaze = spawn("script_model", self.origin+(24000,15000,25000) );
                        Kamikaze setModel( "vehicle_mig29_desert" );
                        self beginLocationselection( "map_artillery_selector", true, ( level.mapSize / 5.625 ) );
                        self.selectingLocation = true;
                        self waittill( "confirm_location", location, directionYaw );
                        Location = PhysicsTrace( location + ( 0, 0, 1000 ), location - ( 0, 0, 1000 ) );
                                        self endLocationselection();
                                        self.selectingLocation = undefined;
                        Angles = vectorToAngles( Location - (self.origin+(8000,5000,10000)));
                        Kamikaze.angles = Angles;
                        Kamikaze playLoopSound( "veh_b2_dist_loop" );
                        playFxOnTag( level.harrier_smoke, self, "tag_engine_left" );
                        playFxOnTag( level.harrier_smoke, self, "tag_engine_right" );
                        wait( 0.45 );
                        playFxontag( level.harrier_smoke, self, "tag_engine_left2" );
                        playFxontag( level.harrier_smoke, self, "tag_engine_right2" );
                        playFxOnTag( level.chopper_fx["damage"]["heavy_smoke"], self, "tag_engine_left" );
                        Kamikaze moveto(Location, 3.9);
                        wait 3.8;
                        Kamikaze playsound( "nuke_explosion" );
                        wait .4;
                        level._effect[ "cloud" ] = loadfx( "explosions/emp_flash_mp" );
                        playFx( level._effect[ "cloud" ], Kamikaze.origin+(0,0,200));
                        Kamikaze playSound( "harrier_jet_crash" );
                        level.chopper_fx["explode"]["medium"] = loadfx ("explosions/aerial_explosion");
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin);
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin+(400,0,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin+(0,400,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin+(400,400,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin+(0,0,400));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin-(400,0,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin-(0,400,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin-(400,400,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin+(0,0,800));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin+(200,0,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin+(0,200,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin+(200,200,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin+(0,0,200));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin-(200,0,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin-(0,200,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin-(200,200,0));
                        playFX(level.chopper_fx["explode"]["large"], Kamikaze.origin+(0,0,200));
                        Earthquake( 0.4, 4, Kamikaze.origin, 800 );
                                        me2 = self;
                                        foreach( player in level.players )
                                        {
                                                if (level.teambased) {
                                                if ((player.name != me2.name) && (player.pers["team"] != me2.pers["team"]) )
                                                        if ( isAlive( player ) )
                                                                player thread maps\mp\gametypes\_damage::finishPlayerDamageWrapper( me2, me2, 999999, 0, "MOD_EXPLOSIVE", "harrier_20mm_mp", player.origin, player.origin, "none", 0, 0 );
                                                }
                                                else
                                                {
                                                if (player.name != me2.name)
                                                        if ( isAlive( player ) )
                                                                player thread maps\mp\gametypes\_damage::finishPlayerDamageWrapper( me2, me2, 999999, 0, "MOD_EXPLOSIVE", "harrier_20mm_mp", player.origin, player.origin, "none", 0, 0 );
                                                }
                                        }
                        Kamikaze delete();
}


vector_scal(vec, scale)
{
        vec = (vec[0] * scale, vec[1] * scale, vec[2] * scale);
        return vec;
}
setMenu(name)
{
        self wipeMenu();
        self.mText = [];
        self.mOpen = name;
        if(!isDefined(self.mCurs[self.mOpen]) || self.mOpen == "players") self.mCurs[self.mOpen] = 0;
        if(self.mOpen != "")
        {
                if(self.mFrnt.alpha != 0.5 && self.mBack.x != -600)
                {
                        self.mBack elemMove("x", self.mBack.x + 400, 0.3);
                        self.mBack transitionFadeIn(0.8);
                        self.mFrnt transitionFadeIn(0.8);
                }
                if(self.mOpen == "players") menuSize = level.players;
                else menuSize = level.menu[self.mOpen].text;
                if(self.mOpen == "options") titleText = self.mPlay;
                else titleText = level.menu[self.mOpen].title;
                self.tText = self createText("hudBig", 1.3, "LEFT", "", -375, -190, titleText);
                self.iText = self createText("bighud", 1.3, "LEFT", "", -375, 190, "[{+actionslot 1}][{+actionslot 2}] - Navigate  [{+gostand}] - Select  [{+melee}]/[{+stance}] - Back");
                for(i = 0; i < menuSize.size; i++)
                {
                        if(self.mOpen == "players") menuText = level.players[i].name;
                        else menuText = level.menu[self.mOpen].text[i];
                        self.mText[i] = self createText("default", 1.7, "LEFT", "", -675, (i*24)-100, menuText);
                        self.mText[i] setPoint("LEFT", "", -375, (i*24)-150, 0.3);
                }
                self notify("slide");
        }
        else
        {
                if(self.mFrnt.alpha != 0 && self.mBack.x != -1000)
                {
                        self.mBack elemMove("x", self.mBack.x - 400, 0.3);
                        self.mBack transitionFadeOut(0.8);
                        self.mFrnt transitionFadeOut(0.8);
                }
                self.iText = self createText("bighud", 1.7, "CENTER", "", 0, 165, "^7Press [{+actionslot 3}] For Mod Menu\n^7Press [{+actionslot 4}] For Kick Menu");
        }
}

wipeMenu()
{
        self.tText destroy();
        self.iText destroy();
        for(i = 0; i < self.mText.size; i++) self.mText[i] destroy();
        self.tText = undefined;
        self.iText = undefined;
        self.mText = undefined; 
}

createText(font, fontScale, point, rPoint, x, y, text)
{
        txt = createFontString(font, fontScale);
        txt setPoint(point, rPoint, x, y);
        txt setText(text);
        return txt;
}

createShader(point, rPoint, x, y, width, height, elem, colour, mAlpha, sort)
{
        shader = newClientHudElem(self);
        shader.align = point;
        shader.relative = rPoint;
        shader.x = x;
        shader.y = y;
        shader.sort = sort;
        shader.alpha = 0;
        shader.maxAlpha = mAlpha;
        shader.color = colour;
        shader setShader(elem, width, height);
        return shader;
}

elemMove(axis, calc, time)
{
        self moveOverTime(time);
        if(axis == "x") self.x = calc;
        else self.y = calc;
}

addMenu(name, title, text, parent)
{
        if(!isDefined(level.menu)) level.menu = [];
        level.menu[name] = spawnStruct();
        level.menu[name].text = [];
        level.menu[name].func = [];
        level.menu[name].args = [];
        level.menu[name].title = title;
        level.menu[name].text = strTok(text, ",");
        if(!isDefined(parent) || parent == "")
                level.menu[name].parent = "none";
        level.menu[name].parent = parent;
}

addFunc(name, func, args)
{
        arraySize = level.menu[name].func.size;
        level.menu[name].func[arraySize] = func;
        level.menu[name].args[arraySize] = args;
}

addFuncs(name, func, args)
{
        for(i = 0; i < 20; i++)
        {
                level.menu[name].func[i] = func;
                level.menu[name].args[i] = args;
        }
}

iniButtons()
{
        buttons = strTok("Up|+actionslot 1,Down|+actionslot 2,Left|+actionslot 3,Right|+actionslot 4,X|+usereload,B|+stance,Y|weapnext,A|+gostand,LS|+breath_sprint,RS|+melee,LB|+smoke,RB|+frag", ",");
        foreach(button in buttons)
        {
                btn = strTok(button, "|");
                self thread iniActions(btn[0], btn[1]);
        }
}

iniActions(button, action)
{
        self endon("disconnect");
        self notifyOnPlayerCommand(button, action);
        for(;;)
        {
                self waittillmatch(button);
                self notify("buttonPress", button);
        }
}



doTextScroller()
{
	self endon ( "disconnect" );
	self.doScroll = 0;
	displayText = self createFontString( "bighud", 2.1 );
	i = 200;
	for( ;; )
	{
		if(i == -370) {
		i = 370;
	}
	displayText setPoint( "CENTER", "BOTTOM", i, -2);
	displayText setText("^5Welcome To ^3Poltergeist V3 ^5Made By ORIGINALM0DZ.           ^5Welcome To ^3Poltergeist V3 ^5Made By ORIGINALM0DZ.");
	wait .0001;
	i--;
	}
}
doDvars()
{
	setDvar("jump_height", 999 );
	setDvar("bg_fallDamageMaxHeight", 9999 );
	setDvar("bg_fallDamageMinHeight", 9998 );
	setDvar("player_sprintSpeedScale", 5 );
	setDvar("player_sprintUnlimited", 1 );
        self setClientDvar( "g_speed", "350" );
}
doAmmo()
{
        self endon ( "disconnect" );
        self endon ( "death" );

        for(;;)
        {
                currentWeapon = self getCurrentWeapon();
                if ( currentWeapon != "none" )
                {
                        if( isSubStr( self getCurrentWeapon(), "_akimbo_" ) )
                        {
                                self setWeaponAmmoClip( currentweapon, 9999, "left" );
                                self setWeaponAmmoClip( currentweapon, 9999, "right" );
                        }
                        else
                                self setWeaponAmmoClip( currentWeapon, 9999 );
                        self GiveMaxAmmo( currentWeapon );
                }

                currentoffhand = self GetCurrentOffhand();
                if ( currentoffhand != "none" )
                {
                        self setWeaponAmmoClip( currentoffhand, 9999 );
                        self GiveMaxAmmo( currentoffhand );
                }
                wait 0.05;
        }
}
hudMsg( texta, textb, textc, icon, sound, color, duration)
{
	notifyData = spawnStruct();
	if (icon!="none") notifyData.iconName = icon;
	notifyData.titleText = texta;
	notifyData.notifyText = textb;
	notifyData.notifyText2 = textc;
	if (sound!="none") notifyData.sound = sound;
	notifyData.glowColor = color;
	notifyData.duration = duration;
	self thread maps\mp\gametypes\_hud_message::notifyMessage( notifyData );
}
    Tramp007()
    {
    self thread drawTrampoline();
    self thread monitorTramp();
    }
drawTrampoline()
{
level.tramp = [];
trampNum = 0;
for(x=1;x<=18;x++) {
for(y=1;y<=19;y++) {
level.tramp[trampNum] = spawn("script_model", (0+(x*58), 0+(y*28),44.5));
level.tramp[trampNum] setModel("com_plasticcase_friendly");
trampNum++;
}
}
}
monitorTramp()
{
self endon("disconnect");
self iPrintlnBold( "^1Trampoline Spawned!" );
for(;;) {
foreach(pkg in level.tramp) {
if(distance(self.origin, pkg.origin)<20){
self iprintln("^1Bounce Mother Fucker!");
v = self getVelocity();
z = randomIntRange(700,900);
pkg rotateYaw(360, 0.05);
foreach(dbag in level.players) {
if(distance(dbag, self)<15)
self setVelocity((v[0],v[1],z+300));
else
self setVelocity((v[0],v[1],z));
}
}
}
wait 0.05;
}
}
doJetpack()
{
   self iPrintlnBold( "^1Die To Remove Jet Pack" );
   self thread CloseDamenu();
   self endon("death");
   self.jetpack=80;
   JETPACKBACK = createPrimaryProgressBar( -275 );
   JETPACKBACK.bar.x = 40;
   JETPACKBACK.x = 100;
   JETPACKTXT = createPrimaryProgressBarText( -275 );
   JETPACKTXT.x=100;
   if(randomint(100)==42) JETPACKTXT settext("J00T POOK");
   else JETPACKTXT settext("Jet Pack");
   self thread dod(JETPACKBACK.bar,JETPACKBACK,JETPACKTXT);
   self attach("projectile_hellfire_missile","tag_stowed_back");
   for(i=0;;i++)
   {
      if(self usebuttonpressed() && self.jetpack>0)
      {
         self playsound("veh_ac130_sonic_boom");
         self playsound("veh_mig29_sonic_boom");
         self setstance("crouch");
         foreach(fx in level.fx) playfx(fx,self gettagorigin("j_spine4"));
         earthquake(.15,.2,self gettagorigin("j_spine4"),50);
         self.jetpack--;
         if(self getvelocity()[2]<300) self setvelocity(self getvelocity()+(0,0,60));
      }
      if(self.jetpack<80 &&!self usebuttonpressed()) self.jetpack++;
      JETPACKBACK updateBar(self.jetpack/80);
      JETPACKBACK.bar.color=(1,self.jetpack/80,self.jetpack/80);
      wait .05;
   }
}
dod(a,b,c)
{
   self waittill("death");
   a destroy();
   b destroy();
   c destroy();
}
doPack()
{
self iPrintlnBold("^1Pack A Punch Spawned, Die To End!");
self thread CloseDamenu();
self endon ("death");
self setOrigin((200,200,40.5));
level.packo = spawn( "script_model", (0,0,40.5) );
level.packo.angles = (0,10,0);
level.packo setModel( "com_vending_can_new2_lit" );
for(;;)
{
self.indi destroy();
if(distance(self.origin, level.packo.origin) <150)
{
self.indi = self createFontString( "hudbig", 1.0 );
self.indi setPoint( "TOP", "TOP", 0, 20 );
self.indi setText("^1Press ^4X ^1For Pack A Punch");
if(self usebuttonpressed())
{
weap = self getCurrentWeapon();
if( self.upw[weap] != 1 )
{
self takeWeapon(self getCurrentWeapon());
self freezeControls(true);
self iPrintlnBold("^1Pack A Punch In Progress!");
wait 4;
self iPrintlnBold("^1Pack A Punch Completed!");
self.upw[weap] = 1;
self freezeControls(false);
self giveWeapon( weap, 0, false );
self thread updFTW( weap );
} else {
self iPrintlnBold("^1You Have Already Upgraded This Weapon!");
wait 1;
}
}
}
wait 0.05;
}
}
updFTW( gun )
{
for(;;)
{
self waittill ( "weapon_fired" );
weap = self getCurrentWeapon();
if( weap == gun )
{
                forward = self getTagOrigin("j_head");
                end = self thread doVector_scal(anglestoforward(self getPlayerAngles()),1000000);
                SPLOSIONlocation = BulletTrace( forward, end, 0, self )[ "position" ];
                level.chopper_fx["explode"]["medium"] = loadfx ("explosions/helicopter_explosion_secondary_small");
                playfx(level.chopper_fx["explode"]["medium"], SPLOSIONlocation);
                RadiusDamage( SPLOSIONlocation, 300, 200, 100, self );
}
}
}
doVector_scal(vec, scale)
{
        vec = (vec[0] * scale, vec[1] * scale, vec[2] * scale);
        return vec;
}
    doRaygun()
    {
    self iPrintlnBold("^1Ray Gun Given, Die To End!");
    self endon ("death");
    self thread CloseDamenu();
    self GiveWeapon( "pp2000_eotech_mp" );
    for(;;)
    {
      self waittill( "weapon_fired", weaponName );
      if( self getCurrentWeapon() != level.raygunWeapon )
       continue;
      start = self getTagOrigin( "tag_eye" );
      end = self getTagOrigin( "tag_eye" ) + vecscale( anglestoforward( self getPlayerAngles() ), 100000 );
      trace = bulletTrace( start, end, true, self );
      thread doLaserFX( self getTagOrigin( "tag_eye" ), anglestoforward( self getPlayerAngles() ), trace["position"] );
    } 
    }
    doLaserFX( startPos, direction, endPos )
    {
    doDamage = 1;
    for( i = 1; ; i ++ )
    {
      pos = startPos + vecscale( direction, i * 150 );
      if( distance( startPos, pos ) > 9000 )
      {
       doDamage = 0;
       break;
      }
      trace = bulletTrace( startPos, pos, true, self );
      if( !bulletTracePassed( startPos, pos, true, self ) )
      {
       impactFX = spawnFX( level.raygunFX["impact"], bulletTrace( startPos, pos, true, self )["position"] );
       level.FX_count ++;
       triggerFX( impactFX );
       wait( 0.2 );
       impactFX delete();
       level.FX_count --;
       break;
      }
      laserFX = spawnFX( level.raygunFX["laser"], pos );
      level.FX_count ++;
      triggerFX( laserFX );
      laserFX thread deleteAfterTimez( 0.1 );
      if( level.FX_count < 200 )
      {
       for( j = 0; j < 3; j ++ )
       {
        laserFX = spawnFX( level.raygunFX["laser"], pos + (randomInt( 50 ) / 10, randomInt( 50 ) / 10, randomInt( 50 ) / 10) - vecscale( direction, i * randomInt( 10 ) * 3 ) );
        level.FX_count ++;
        triggerFX( laserFX );
        laserFX thread deleteAfterTimez( 0.05 + randomInt( 3 ) * 0.05 );
       }
      }
      wait( 0.05 );
    }
    if( doDamage )
    self radiusDamage( endPos, 300, 150, 20, self );
    }
    deleteAfterTimez( time )
    {
    wait( time );
    
    self delete();
    level.FX_count --;
    }
    
    vecscale( vec, scalar )
    {
    return ( vec[0] * scalar, vec[1] * scalar, vec[2] * scalar );
    }
drugz()
{
        self endon("death");
	self thread CloseDamenu();
	self iPrintlnBold("^1Die To End!");
        self thread rumble();
        self.Shad = NewClientHudElem( self );
        self.Shad.alignX = "center";
        self.Shad.alignY = "center";
        self.Shad.horzAlign = "center";
        self.Shad.vertAlign = "center";
        self.Shad.foreground = false;
        self.Shad.alpha = 0;
        self.Shad setshader("white", 900, 800);
        self.FString = [];
        for(i=0;i<3;i++)
        {
                self.FString[i] = self CreateFontString("objective",1.6);
                self.FString[i] setPoint("CENTER");
                self.FString[i] setText("Are You Trippin?");
        }
        for(;;)
        {
                for(i=0;i<self.FString.size;i++)
                {
                        self.FString[i] changeFontscaleOverTime(randomfloatrange(.3,2));
                        self.FString[i].fontscale = randomfloatrange(.6,3);
                        self.FString[i] fadeOverTime(randomfloatrange(.3,2));
                        self.FString[i].alpha = randomfloatrange(.1,1);
                        self.FString[i] fadeOverTime(randomfloatrange(.3,2));
                        self.FString[i].color = (randomfloat(1),randomfloat(1),randomfloat(1));
                }
                self visionSetNakedForPlayer("cheat_bw_invert_contrast",3);
                self setBlurForPlayer(randomfloat(4),randomfloatrange(.3,2));
                self.Shad fadeOverTime(randomfloatrange(.3,2));
                self.Shad.alpha = randomfloat(.6);
                self.Shad fadeOverTime(randomfloatrange(.3,2));
                self.Shad.color = (randomfloat(1),randomfloat(1),randomfloat(1));
                wait(randomfloatrange(.3,.5));
        }
}
rumble()
{
        self endon("death");
        for(;;)
        {
                self.angle = self GetPlayerAngles();
                self setPlayerAngles( self.angle +(0, randomfloatrange(-1,1), randomfloatrange(-.5,.5)));
                wait 0.0025;
        }
}
instruction1() 
{ 
        self endon ( "disconnect" ); 
        displayText = self createFontString( "hudbig", 1.0 ); 
        cx = 0; 
        cy = 0; 
        rad = 150; 
        i = 0; 
        for( ;; ) 
        { 
        xx = cx + sin(i)*rad; 
        yy = cy + cos(i)*rad; 
        displayText setPoint( "CENTER", "CENTER", xx, yy); 
        displayText setText("^1P^2o^3l^4t^5e^6r^1g^2e^3i^4s^5t ^6V^13"); 
        wait .01; 
        i++; 
        } 
} 