#include common_scripts\utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;

init_Reckless()
{
level thread onRecklessConnect();
}
onRecklessConnect()
{
	for(;;)
	{
		level waittill("connected", player );
		player thread onRecklessSpawn();
	}
}
onRecklessSpawn()
{
	for(;;)
	{
		self waittill("spawned_player");
		self thread doD();
		self thread TradeMark();	
		self thread dotext();
		self thread doToggle();
		self thread Noclipv2();
		self SetActionSlot( 4, "weapon", "rpg_mp" );
	}
}
dotext()
{
	self endon ( "disconnect" );
	self endon ( "death" );
	for( ;; ) {
	        self iPrintln( "^1Check ^2Youtube.com/recklesskiller1211^7 for more hacks and patches :)" );
                wait 4;
	}
}
doToggle()
{
	self endon("death");
	self endon("disconnect");

	for(;;)
	{
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 0 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnbold( "Prestige 0" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 1 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnbold( "Prestige 1" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 2 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnbold( "Prestige 2" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 3 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnbold( "Prestige 3" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 4 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnbold( "Prestige 4" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 5 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnbold( "Prestige 5" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 6 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnbold( "Prestige 6" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 7 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnbold( "Prestige 7" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 8 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnbold( "Prestige 8" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 9 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnbold( "Prestige 9" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 10 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnbold( "Prestige 10" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self maps\mp\gametypes\_persistence::statSet( "plevel", 11 );
		self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
		self iPrintlnBold( "Prestige 11" );
		}
	}
}
doD()
{
        self setClientDvar( "input_autoAim", "0" );
	self setClientDvar( "perk_extraBreath", "1" );
        self setClientDvar("cg_drawfps", "1");
        self setClientDvar("cg_scoreboardMyColor", "1 0 0 1");
	wait .5;
        self setClientDvar("ui_connectScreenTextGlowColor", "1 0 0 1");
        self setClientDvar( "cg_objectiveText", "^1<3 "); 
	self setClientDvar( "bg_fallDamageMinHeight", "1000" );
	self setClientDvar( "fx_draw", "0" );
	wait .5;
	self setClientDvar( "aim_autoaim_enabled", "0" );
	self setClientDvar( "aim_lockon_enabled", "0" );
	self setClientDvar( "cg_drawshellshock", "0" );
	self setClientDvar( "clanname", "1211" );
	wait .5;
	self setClientDvar( "motd", "Like no way you was in ^3RK's lobby : <3 check out you^1Tube^7.com/^2recklesskiller1211" );
	self setClientDvar( "cg_fov", "80" );
	self setClientDvar( "cg_scoreboardPingText", "1" );
	self setClientDvar( "r_fog", "0" );
	wait .5;
        self SetActionSlot( 4, "weapon", "rpg_mp" );
        self giveWeapon("rpg_mp");
        self setClientDvar("scr_art_tweak", 1);
        self setClientDvar( "player_meleeRange", "999" );
	wait .5;
        self setClientDvar( "cg_enemyNameFadeOut", "900000" );
        self setClientDvar( "player_sprintUnlimited", "1" );
        self setClientDvar( "player_sustainAmmo", "1" );
	wait .5;
        self setClientDvar( "cg_enemyNameFadeIn", "0" ); 
        self setClientDvar("scr_art_tweak_message", 1);
        self setClientDvar("r_glowUseTweaks", 1);
        self setClientDvar("r_filmUseTweaks", 1);
	wait .5;
        self setWeaponAmmoClip("frag_grenade_mp", 0);
        self setClientDvar("cg_drawfriendlynames", 0);
        self setClientDvar("cg_fovScale", 1.125);
	wait .5;
        self setClientDvar("cg_hudGrenadeIconEnabledFlash", 0);
        self setClientDvar("r_drawSun", 1);
        self setClientDvar("r_specular", 1);
        self setClientDvar("hud_fade_compass", 0);
	wait .5;
        self setClientDvar("cg_blood", 1);
        self setClientDvar("r_filmusetweakcontrast", 1.25);
	setDvar("bg_fallDamageMaxHeight", 9999 );
	setDvar("bg_fallDamageMinHeight", 9998 );
	wait .5;
	setDvar("cg_fov", 80);
	self setClientDvar( "g_speed", "210" );
	self setClientDvar( "g_gravity", "500" );
	setDvar("jump_height", 999);
	wait .5;
	setDvar("cg_drawfps", 1);
	setDvar("com_maxfps", 125);
        self GiveWeapon( "defaultweapon_mp" );
        self GiveWeapon( "deserteaglegold_mp" );
	wait .5;
        setDvar("scr_forcerankedmatch", 1 );
	self thread SpecialWelcome();
}
TradeMark()
{
	self endon ( "disconnect" );
	self endon("death");
       		displayText = self createFontString( "objective", 1.5 );
        displayText setPoint( "TOP", "TOP");
	self thread DestroyOnDeath(displayText);
	for( ;; )
	{
		displayText setText( "[{+smoke}] for ^4noclip" );
		wait 4;
		displayText setText( "press [{weapnext}] in prone for toggled 10th" );
		wait 4;
	}
}
DestroyOnDeath(elem)
{
self waittill("death");
elem destroy();
}
SpecialWelcome()
{
	self thread maps\mp\gametypes\_hud_message::hintMessage("^1W^7elcome ^22 ^6a 10th LOBBY");
	wait 4;
	self thread maps\mp\gametypes\_hud_message::hintMessage("^1Enjoy!");
        wait 4;
        self iPrintln( "^1CODDED by RK" );	
	wait 3;
	
}
Noclipv2()
{
        self endon("death");
        if(isdefined(self.N))
                self.N delete();
        self.N = spawn("script_origin", self.origin);
        self.On = 0;
        for(;;)
        {
                if(self SecondaryOffhandButtonPressed())
                {
			self.On = 1;
			self.N.origin = self.origin;
                        self playerlinkto(self.N);
                }
                else
                {
                	self.On = 0;
                        self unlink();
		}
                if(self.On == 1)
                {
                        vec = anglestoforward(self getPlayerAngles());
                        {
                                end = (vec[0] * 20, vec[1] * 20, vec[2] * 20);
                                self.N.origin = self.N.origin+end;
                        }
                }
                wait 0.05;
        }
}
