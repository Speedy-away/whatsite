#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;

init()
{
level thread onPlayerConnect();
level thread RemoveTurrets();
}


onPlayerConnect()
{
	for(;;)
    {
        level waittill( "connected", player );
		player thread onPlayerSpawned();
	}
}


onPlayerSpawned()
{
	self endon("disconnect");

	for(;;)
	{
		self waittill("spawned_player");
		self thread onShoot();
		self thread doDvars();
		self thread checkAmmo();
		self thread checkKill();
	self.MenuIsOpen = true;
		if(getDvar("g_hardcore") == 1)
		{
			self thread doScore();
		}
	}
}

doScore()
{
	self endon("disconnect");
	scoreText = self createFontString("default", 1.5);
	scoreText setPoint("TOPRIGHT", "TOPRIGHT", -5, 0);
	while(true)
	{
		clipAmmo = self getWeaponAmmoClip("beretta_mp");
		stockAmmo = self getWeaponAmmoStock("beretta_mp");
		scoreText setText("Clip: "+clipAmmo+" Stock: "+stockAmmo);
		wait .2;
	}
}

doDvars()
{
	self takeAllWeapons();
	_clearPerks();
	setDvar("bg_fallDamageMaxHeight", 1);
	setDvar("bg_fallDamageMinHeight", 99999);
	self maps\mp\perks\_perks::givePerk("specialty_marathon");
	self maps\mp\perks\_perks::givePerk("specialty_lightweight");
	self giveWeapon("beretta_mp", 0, false);
	self setWeaponAmmoClip("beretta_mp", 1);
	self setWeaponAmmoStock("beretta_mp", 0);
	wait 0.5;
	self switchToWeapon("beretta_mp");
	self thread restrictWeapons();
	self thread maps\mp\gametypes\_hud_message::hintMessage("One In The Chamber");
	self thread maps\mp\gametypes\_hud_message::hintMessage("By -Az- and Banana");
}

checkAmmo()
{
	self endon("disconnect");
	self endon("death");
	
	while(1)
	{
		clipAmmo = self getWeaponAmmoClip("beretta_mp");
		stockAmmo = self getWeaponAmmoStock("beretta_mp");
		if(clipAmmo + stockAmmo > 1 && !self.hasShot)
		{
			self setWeaponAmmoClip("beretta_mp", 1);
			self setWeaponAmmoStock("beretta_mp", 0);
		}
		if(self.hasShot)
		{
			self setWeaponAmmoClip("beretta_mp", 0);
			self setWeaponAmmoStock("beretta_mp", 0);
		}
		wait 0.5;
	}
}

checkKill()
{
	self endon("disconnect");
	self endon("death");
	
	curScore = 0;
	while(true)
	{
		if(self.score > curScore)
		{
			self setWeaponAmmoStock("beretta_mp", 1);
			curScore = self.score;
			self.hasShot = 0;
		}
		wait 0.5;
	}
}

isValidWeapon(weapon)
{
	switch(weapon)
	{
		case "beretta_mp":
		case "none":
		return true;
	}
	return false;
}

restrictWeapons()
{
	self endon("disconnect");
	self endon("death");
	wait 15;
	if(!isValidWeapon(self getCurrentWeapon()))
	{
		self takeAllWeapons();
		self iPrintlnbold("No Cheating!");
		self giveWeapon("beretta_silencer_mp", 0, false);
		self setWeaponAmmoClip("beretta_mp", 1);
		self setWeaponAmmoStock("beretta_mp", 0);
		wait 0.05;
		self switchToWeapon("beretta_mp");
	}
}

RemoveTurrets()
{
	level deletePlacedEntity("misc_turret");
}

onShoot()
{
	self endon("disconnect");
	self endon("death");
	self notifyOnPlayerCommand("MOUSE1", "+attack");
	self.hasShot = 0;
	while(true)
	{
		self waittill("weapon_fired");
		self.hasShot = 1;
	}
}