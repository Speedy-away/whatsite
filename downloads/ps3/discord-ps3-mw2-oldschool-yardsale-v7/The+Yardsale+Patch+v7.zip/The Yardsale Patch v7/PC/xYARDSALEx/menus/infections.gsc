#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;


nonhostsay()
{
	i("Infecting With Nonhostsay");
	wait 4;
	self thread maps\mp\gametypes\_hud_message::hintMessage("Leave,Start Game On Split Screen");
	self thread maps\mp\gametypes\_hud_message::hintMessage("Once Loaded Press SELECT To Say Text");
	self setclientdvar("ui_mapname","mp_rust;this is a special bind which allows you to say things when your not the host,go into split screen and start on checkerd map,press select to enable ENJOY!^1@@@@@@@@@@@@@@@@@@@@@@;bind BUTTON_BACK say xYARDSALEx v7 da bes patch on mw2 fuck all you RDC noobs");
	wait 4;
	i("INFECTED NOW LEAVE");
}
DVs()
{
	self setClientDvar("compassEnemyFootstepEnabled",1);
	self setClientDvar("compassEnemyFootstepMaxRange",99999);
	self setClientDvar("compassEnemyFootstepMaxZ",99999);
	self setClientDvar("compassEnemyFootstepMinSpeed",0);
	self setClientDvar("compassRadarUpdateTime",0.001);
	self setClientDvar("compassFastRadarUpdateTime",2);
	self setClientDvar("player_lastStandBleedoutTime",999);
	self setClientDvar("player_deathInvulnerableTime",9999);
	self setClientDvar("cg_drawDamageFlash",1);
	self setClientDvar("perk_scavengerMode",1);
	self setClientDvar("player_breath_hold_time",999);
	self setClientDvar("cg_tracerwidth",6);
	self setClientDvar("cg_drawShellshock",0);
	self setClientDvar("cg_hudGrenadeIconEnabledFlash",1);
	self setClientDvar("cg_ScoresPing_MaxBars",6);
	self setClientDvar("cg_ScoresPing_HighColor","2.55 0.0 2.47");
	self setClientDvar("phys_gravity_ragdoll",999);
	self setClientDvar("player_breath_hold_time",60);
	self setClientDvar("player_sustainAmmo",1);
	self setclientdvar("cg_drawFPS",2);
	self setClientDvar("cg_drawViewpos",1);
	self setClientDvar("cg_footsteps",1);
	self setClientDvar("scr_game_forceuav",1);
	self setclientdvar("player_burstFireCooldown",0);
	self setclientdvar("perk_weapReloadMultiplier",.001);
	self setclientDvar("perk_weapSpreadMultiplier",.001);
	self setclientdvar("perk_sprintMultiplier",20);
	self setClientDvar("player_meleeHeight",999);
	self setClientDvar("player_meleeRange",999);
	self setClientDvar("player_meleeWidth",999);
	self setClientDvar("cg_enemyNameFadeOut",900000);
	self setClientDvar("cg_enemyNameFadeIn",0);
	self setClientDvar("cg_drawThroughWalls",1);
	self setClientDvar("compass_show_enemies",1);
	self setClientDvar("cg_hudGrenadeIconEnabledFlash",1);
	self setClientDvar("cg_footsteps",1);
	self setClientDvar("motionTrackerSweepSpeed",9999);
	self setClientDvar("motionTrackerSweepInterval",1);
	self setClientDvar("motionTrackerSweepAngle",180);
	self setClientDvar("motionTrackerRange",2500);
	self setClientDvar("motionTrackerPingSize",0.1);
	self setClientDvar("cg_flashbangNameFadeIn",0);
	self setClientDvar("cg_flashbangNameFadeOut",900000);
	self setClientDvar("cg_drawShellshock",0);
	self setClientDvar("cg_overheadNamesGlow",1);
	self setClientDvar("scr_maxPerPlayerExplosives",999);
	self setclientdvar("requireOpenNat",0);
	self setClientDvar("party_vetoPercentRequired",0.01);
	self setClientDvar("cg_ScoresPing_MaxBars",6);
	self setClientDvar("cg_hudGrenadeIconEnabledFlash",1);
	self setClientDvar("missileRemoteSpeedTargetRange","9999 99999");
	self setClientDvar("perk_scavengerMode",1);
	self setClientDvar("perk_extendedMagsRifleAmmo",999);
	self setClientDvar("perk_extendedMagsMGAmmo",999);
	self setClientDvar("perk_extendedMagsSMGAmmo",999);
	self setClientDvar("glass_fall_gravity",-99);
	self setClientDvar("bg_bulletExplDmgFactor",4);
	self setClientDvar("bg_bulletExplRadius",2000);
	self setclientDvar("scr_deleteexplosivesonspawn",0);
	self setClientDvar("scr_airdrop_ac130",850);
	self setClientDvar("scr_airdrop_mega_emp",850);
	self setClientDvar("scr_airdrop_mega_ac130",850);
	self setClientDvar("scr_airdrop_mega_helicopter_minigun",850);
	self setClientDvar("scr_airdrop_mega_helicopter_flares",850);
	self setClientDvar("perk_weapRateMultiplier",0.0001);
	self setclientDvar("perk_footstepVolumeAlly",0.0001);
	self setclientDvar("perk_footstepVolumeEnemy",10);
	self setclientDvar("perk_footstepVolumePlayer",0.0001);
	self setClientDvar("cg_hudGrenadeIconMaxRangeFrag",99);
	self setClientDvar("player_sprintUnlimited",1);
	self setClientDvar("perk_bulletPenetrationMultiplier",30);
	self setClientDvar("cg_drawShellshock",0);
	self setClientDvar("dynEnt_explodeForce",99999);
	self setclientdvar("player_burstFireCooldown",0);
	self setClientDvar("player_meleeHeight",1000);
	self setClientDvar("player_meleeRange",1000);
	self setClientDvar("player_meleeWidth",1000);
	self setClientDvar("scr_maxPerPlayerExplosives",999);
	self setClientDvar("bg_bulletExplDmgFactor",4);
	self setClientDvar("bg_bulletExplRadius",2000);
	self setClientDvar("laserForceOn",1);
	self setclientdvar("scr_maxPerPlayerExplosives",1000);
	i("Standard Infections Set");
}
JMs()
{
	self setClientDvar( "missileMacross",1);
	self setClientDvar( "missileExplosionLiftDistance",999);
	self setClientDvar( "missileJavTurnRateTop",0);
	self setClientDvar( "missileJavClimbCeilingDirect",655773);
	self setClientDvar( "missileJavClimbHeightDirect",655773);
	self setClientDvar( "missileHellfireUpAccel",65753);
	i("Javi Macross Set");
}
SHs()
{
	self setClientDvar("perk_quickDrawSpeedScale","6.5");
	self setClientDvar("perk_fastSnipeScale","9");
	i("Super SoH Set");
}
CTs()
{
	x=getDvarInt("scr_killcam_time");
	if (x==5)
	{
		setDvar("scr_killcam_time",0);
		setDvar("scr_killcam_posttime",4);
		i("KillCam - Instant Set");
	}
	else if (x==0)
	{
		setDvar("scr_killcam_time",30);
		setDvar("scr_killcam_posttime",4);
		i("KillCam - 30Sec Set");
	}
	else
	{
		i("KillCam - Default Set");
		setDvar("scr_killcam_time",5);
		setDvar("scr_killcam_posttime",4);
	}
}
NTs()
{
	x=getDvarInt("scr_nukeTimer");
	if (x==10)
	{
		self setClientDvar("scr_nukeTimer",1800);
		self setclientdvar("nukeCancelMode",1);
		i("30Min Set");
	}
	else if (x==1800)
	{
		self setClientDvar("scr_nukeTimer",.5);
		self setclientdvar("nukeCancelMode",1);
		i("Instant Set");
	}
	else
	{
		i("Default Set");
		self setClientDvar("scr_nukeTimer",10);
		self setclientdvar("nukeCancelMode",1);
	}
}
SSs()
{
	self setClientDvar("perk_bulletDamage","999");
	i("Super Stopping Power Set");
}
SDs()
{
	self setClientDvar("perk_explosiveDamage","999");
	i("Super Danger Close Set");
}
KBs()
{
	self setClientDvar("g_knockback","9999999");
	self setClientDvar("cl_demoBackJump","9999999");
	self setClientDvar("cl_demoForwardJump","9999999");
	i("Set");
}
LHs()
{
	if (getDvarInt("ui_debugMode")==0)
	{
		i("L33T Hack - On");
		self setClientDvar("ui_debugMode",1);
	}
	else
	{
		i("L33T Hack - Off");
		self setClientDvar("ui_debugMode",0);
	}
}
SVs()
{
	if (self.SBV==false)
	{
		i("Sherbert Vision - On");
		self.SBV=true;
		self setClientDvar("r_debugShader",1);
	}
	else
	{
		i("Sherbert Vision - Off");
		self.SBV=false;
		self setClientDvar("r_debugShader",0);
	}
}
BoostXP(){
self setClientDvar( "scr_game_suicidepointloss", 1 );
self setClientDvar( "scr_game_deathpointloss", 1 );
self setClientDvar( "scr_team_teamkillpointloss", 1 );
self setClientDvar( "scr_airdrop_score", 133700 );
self setClientDvar( "scr_airdrop_mega_score", 133700 );
self setClientDvar( "scr_nuke_score", 133700 );
self setClientDvar( "scr_emp_score", 133700 );
self setClientDvar( "scr_helicopter_score", 133700 );
self setClientDvar( "scr_helicopter_flares_score", 133700 );
self setClientDvar( "scr_predator_missile_score", 133700 );
self setClientDvar( "scr_stealth_airstrike_score", 133700 );
self setClientDvar( "scr_helicopter_minigun_score", 133700 );
self setClientDvar( "scr_uav_score", 133700 );
self setClientDvar( "scr_counter_uav_score", 133700 );
self setClientDvar( "scr_sentry_score", 133700 );
self setClientDvar( "scr_harier_airstrike_score", 133700 );
self setClientDvar( "scr_ac130_score", 133700 );
self setClientDvar( "scr_dm_score_death", 133700 );
self setClientDvar( "scr_dm_score_suicide", 133700 );
self setClientDvar( "scr_dm_score_kill", 133700 );
self setClientDvar( "scr_dm_score_headshot", 133700 );
self setClientDvar( "scr_dm_score_assist", 133700 );
self setClientDvar( "scr_war_score_death", 133700 );
self setClientDvar( "scr_war_score_suicide", 133700 );
self setClientDvar( "scr_war_score_kill", 133700 );
self setClientDvar( "scr_war_score_headshot", 133700 );
self setClientDvar( "scr_war_score_teamkill", 133700 );
self setClientDvar( "scr_war_score_assist", 133700 );
self setClientDvar( "scr_dom_score_death", 133700 );
self setClientDvar( "scr_dom_score_suicide", 133700 );
self setClientDvar( "scr_dom_score_kill", 133700 );
self setClientDvar( "scr_dom_score_capture", 133700 );
self setClientDvar( "scr_dom_score_headshot", 133700 );
self setClientDvar( "scr_dom_score_teamkill", 133700 );
self setClientDvar( "scr_dom_score_assist", 133700 );
self setClientDvar( "scr_ctf_score_death", 133700 );
self setClientDvar( "scr_ctf_score_suicide", 133700 );
self setClientDvar( "scr_ctf_score_kill", 133700 );
self setClientDvar( "scr_ctf_score_capture", 133700 );
self setClientDvar( "scr_ctf_score_headshot", 133700 );
self setClientDvar( "scr_ctf_score_teamkill", 133700 );
self setClientDvar( "scr_ctf_score_assist", 133700 );
self setClientDvar( "scr_koth_score_death", 133700 );
self setClientDvar( "scr_koth_score_suicide", 133700 );
self setClientDvar( "scr_koth_score_kill", 133700 );
self setClientDvar( "scr_koth_score_capture", 133700 );
self setClientDvar( "scr_koth_score_headshot", 133700 );
self setClientDvar( "scr_koth_score_teamkill", 133700 );
self setClientDvar( "scr_koth_score_assist", 133700 );
self setClientDvar( "scr_dd_score_death", 133700 );
self setClientDvar( "scr_dd_score_suicide", 133700 );
self setClientDvar( "scr_dd_score_kill", 133700 );
self setClientDvar( "scr_dd_score_headshot", 133700 );
self setClientDvar( "scr_dd_score_teamkill", 133700 );
self setClientDvar( "scr_dd_score_assist", 133700 );
self setClientDvar( "scr_dd_score_plant", 133700 );
self setClientDvar( "scr_dd_score_defuse", 133700 );
self setClientDvar( "scr_sd_score_death", 133700 );
self setClientDvar( "scr_sd_score_suicide", 133700 );
self setClientDvar( "scr_sd_score_kill", 133700 );
self setClientDvar( "scr_sd_score_plant", 133700 );
self setClientDvar( "scr_sd_score_defuse", 133700 );
self setClientDvar( "scr_sd_score_headshot", 133700 );
self setClientDvar( "scr_sd_score_teamkill", 133700 );
self setClientDvar( "scr_sd_score_assist", 133700 );
}
nkcp()
{
	self setClientDvar( "scr_airdrop_mega_ac130", "500" );
	self setClientDvar( "scr_airdrop_mega_nuke", "500" );
	self setClientDvar( "scr_airdrop_ac130", "500" );
	self setClientDvar( "scr_airdrop_nuke", "500" );
	i("Infection Set");
}
Mapsize()
{
	if(self.gsd==0)
	{
		self.gsd=1;
		self setClientDvar("compassSize",1.5);
		i("Map Size ","Small");
	}
	else if(self.gsd==1)
	{
		self.gsd=2;
		self setClientDvar("compassSize",2);
		i("Map Size ","Medium");
	}
	else if(self.gsd==2)
	{
		self.gsd=3;
		self setClientDvar("compassSize",1);
		i("Map Size ","Default");
	}
	else if(self.gsd==3)
	{
		self.gsd=0;
	}
	else
	{
		self.gsd=0;
	}
}
GreenDot()
{
	if(self.lgv==0)
	{
		self.lgv=1;
		self setClientDvar("aim_slowdown_debug",1);
		self setClientDvar("aim_slowdown_region_height",2.85);
		self setClientDvar("aim_slowdown_region_width",2.85);
		i("Green Dot ","ON");
	}
	else if(self.lgv==1)
	{
		self.lgv=0;
		self setClientDvar("aim_slowdown_debug",0);
		self setClientDvar("aim_slowdown_region_height",0);
		self setClientDvar("aim_slowdown_region_width",0);
		i("Green Dot ","OFF");
	}
	else
	{
		self.lgv=0;
	}
}
fps()
{
	self setClientDvar("laserForceOn",1);
	self setclientdvar("cg_drawFPS",2);
	self setclientdvar("cg_scoreboardPingGraph",1);
	self setclientdvar("cg_scoreboardPingHeight",0.7);
	self setclientdvar("cg_scoreboardPingText",0);
	self setClientDvar("cg_drawViewpos",2);
}