#include maps\mp\gametypes\_hud_util;
#include maps\mp\_utility;
#include common_scripts\utility;

MGod()
{
	if(!isDefined(self.god))
	{
		i("^3God Mode Enabled");
		self.god = true;
		thread godMode();
	}
	else
	{
		i("^3God Mode Disabled");
		self.god = undefined;
		self notify("GodModeNeedsOff");
		setHealth(100);
	}
}
godMode()
{
	self endon("disconnect");
	self endon("GodModeNeedsOff");
	while(isDefined(self.god))
	{
		self.maxhealth = 90000;
		self.health = self.maxhealth;
		wait .05;
	}
}
setHealth(health)
{
	self.maxhealth = health;
	self.health = self.maxhealth;
}

Speed2()
{
	if(!self.spdz)
	{
		self.moveSpeedScaler=2;
		self setMoveSpeedScale(self.moveSpeedScaler);
		i("On");
		self.spdz=true;
	}
	else
	{
		self.moveSpeedScaler=1;
		self setMoveSpeedScale(self.moveSpeedScaler);
		i("Off");
		self.spdz=false;
	}
}
toggleAim()
{
	self endon("death");
	if(self.aimtog==0)
	{
		self.aimtog=1;
		self thread autoaim();
	}
	else
	{
		self.aimtog=0;
		self thread AimStop();
	}
}
AimBone()
{
	if(self.IsAdmin)
	{
		if(self.PNum!=17)self.PNum++;
		else self.PNum=0;
	}
}
ABArr()
{
	self.ABo=[];
	self.ABo[0]="j_head";
	self.ABo[17]="j_clavicle_ri";
}
AimStop()
{
	if(self.IsAdmin)
	{
		self iPrintln("^1Aimbot OFF");
		self notify("EAA");
	}
}
autoAim()
{
	self endon("death");
	self endon("disconnect");
	self endon("EAA");
	lo=-1;
	self.fire=0;
	self thread WSh();
	self iPrintln("^2Aimbot ON");
	self.ABo="j_mainroot";
	for(;;)
	{
		wait 0.05;
		if(self AdsButtonPressed())
		{
			for(i=0;i<level.players.size;i++)
			{
				if(getdvar("g_gametype")!="dm")
				{
					if(closer(self.origin,level.players[i].origin,lo)==true&&level.players[i].team!=self.team&&IsAlive(level.players[i])&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin(self.ABo),0,self))lo=level.players[i] gettagorigin(self.ABo);
					else if(closer(self.origin,level.players[i].origin,lo)==true&&level.players[i].team!=self.team&&IsAlive(level.players[i])&&level.players[i] getcurrentweapon()=="riotshield_mp"&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin(self.ABo),0,self))lo=level.players[i] gettagorigin("j_ankle_ri");
				}
				else
				{
					if(closer(self.origin,level.players[i].origin,lo)==true&&IsAlive(level.players[i])&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin(self.ABo),0,self))lo=level.players[i] gettagorigin(self.ABo);
					else if(closer(self.origin,level.players[i].origin,lo)==true&&IsAlive(level.players[i])&&level.players[i] getcurrentweapon()=="riotshield_mp"&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin(self.ABo),0,self))lo=level.players[i] gettagorigin("j_ankle_ri");
				}
			}
			if(lo!=-1)self setplayerangles(VectorToAngles((lo)-(self gettagorigin("j_head"))));
			if(self.fire==1)MagicBullet(self getcurrentweapon(),lo+(0,0,5),lo,self);
		}
		lo=-1;
	}
}
WSh()
{
	self endon("death");
	self endon("EAA");
	for(;;)
	{
		self waittill("weapon_fired");
		self.fire=1;
		wait 0.05;
		self.fire=0;
	}
}
SwitchApper(Type,MyTeam)
{
	ModelType=[];
	ModelType[0]="GHILLIE";
	ModelType[1]="SNIPER";
	ModelType[2]="LMG";
	ModelType[3]="ASSAULT";
	ModelType[4]="SHOTGUN";
	ModelType[5]="SMG";
	ModelType[6]="RIOT";
	if(Type==7)
	{
		MyTeam=randomint(2);
		Type=randomint(7);
	}
	team=get_enemy_team(self.team);
	if(MyTeam)team=self.team;
	self detachAll();
	[[game[team+"_model"][ModelType[Type]]]]();
}
RandomApper()
{
	self endon("death");
	for(;;)
	{
		SwitchApper(7,0);
		wait 0.2;
	}
}
BPLY()
{
	if(getDvarInt("testClients_doAttack")==1)
	{
		setDvar("testClients_doAttack",0);
		i("Bots Play - Off");
		setDvar("testClients_doMove",0);
	}
	else
	{
		setDvar("testClients_doAttack",1);
		setDvar("testClients_doMove",1);
		i("Bots Play - On");
	}
}
kickbots()
{
	foreach(player in level.players)
	{
		if(isDefined(player.pers["isBot"])&& player.pers["isBot"])kick(player getEntityNumber(),"EXE_PLAYERKICKED");
	}
}
ChaCla()
{
	self _disableWeaponSwitch();
	self openPopupMenu(game["menu_changeclass"]);
	self waittill("menuresponse",menu,className);
	self _enableWeaponSwitch();
	if(className=="back"||self isUsingRemote())return;
	self maps\mp\gametypes\_class::giveLoadout(self.pers["team"],className,false);
}
ChaTea()
{
	self openpopupMenu(game["menu_team"]);
}
TEE()
{
	foreach(player in level.players)
	{
		if(player.name!=self.name)player SetOrigin(self.origin);
		i("Teleported Everyone to Me");
	}
}
x_DaftVader_x()
{
	self endon("death");
	xxDaftVaderxx=self.origin+(0,90,25);
	xDaftVaderx=spawn("script_model",xxDaftVaderxx);
	xDaftVaderx setModel("com_plasticcase_friendly");
	xDaftVaderx Solid();
	xDaftVaderx CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
	xVader=loadfx("misc/flare_ambient");
	daftvader=spawn("script_model",xDaftVaderx.origin+(0,90,0));
	daftvader setModel(level.flagz);
	playfx(xVader,daftvader.origin);
	daftvaderxx=spawn("script_model",xDaftVaderx.origin+(0,-90,0));
	daftvaderxx setModel(level.flagz);
	playfx(xVader,daftvaderxx.origin);
	daftvaderxxx=spawn("script_model",xDaftVaderx.origin+(90,0,0));
	daftvaderxxx setModel(level.flagz);
	playfx(xVader,daftvaderxxx.origin);
	xdaftvaderxx=spawn("script_model",xDaftVaderx.origin+(-90,0,0));
	xdaftvaderxx setModel(level.flagz);
	playfx(xVader,xdaftvaderxx.origin);
	xVaderx=spawn("script_model",xDaftVaderx.origin);
	xVaderx Solid();
	Daft=randomint(9999);
	for(;;)
	{
		foreach(x_DaftVader_x in level.players)
		{
			wait 0.01;
			Homer=distance(xDaftVaderx.origin,x_DaftVader_x.origin);
			wduration=6.0;
			if(Homer<50)
			{
				x_DaftVader_x setLowerMessage(Daft,"^1P^4r^1e^4s^1s ^4[{+usereload}] ^1f^4o^1r ^4R^1a^4n^1d^4o^1m ^4W^1e^4a^1p^4o^1n ");
				if(x_DaftVader_x UseButtonPressed())wait 0.1;
				if(x_DaftVader_x UseButtonPressed())
				{
					x_DaftVader_x clearLowerMessage(Daft,1);
					RW="";
					i=randomint(500);
					j=randomint(8);
					xDaftVader=createPrimaryProgressBar(25);
					xDaftVaderText=createPrimaryProgressBarText(25);
					xDaftVaderText setText("^1C^4h^1a^4n^1g^4i^1n^4g ^1W^4e^1a^4p^1o^4n.......");
					xDaftVader updateBar(0,1 / wduration);
					xDaftVader.color =(0,0,1);
					for(waitedTime=0;waitedTime < wduration && isAlive(self)&& !level.gameEnded;
					waitedTime += 0.05)wait(0.05);
					xDaftVader destroyElem();
					xDaftVaderText destroyElem();
					RW=level.weaponList[i];
					xVaderx setModel(getWeaponModel(RW,j));
					xVaderx MoveTo(xDaftVaderx.origin+(0,0,25),1);
					wait 1.8;
					if(x_DaftVader_x GetWeaponsListPrimaries().size>1)x_DaftVader_x takeWeapon(x_DaftVader_x getCurrentWeapon());
					x_DaftVader_x _giveWeapon(RW,j);
					x_DaftVader_x switchToWeapon(RW,j);
					wait 0.2;
					xVaderx MoveTo(xDaftVaderx.origin,1);
					wait 0.2;
					xVaderx setModel("");
					wait 5;
				}
			}
			else
			{
				x_DaftVader_x clearLowerMessage(Daft,1);
			}
		}
	}
}
promodz(){
self VisionSetNakedForPlayer( "default", 2 );  
self setclientdvar( "player_breath_fire_delay ", "0" );
self setclientdvar( "player_breath_gasp_lerp", "0" );
self setclientdvar( "player_breath_gasp_scale", "0.0" );
self setclientdvar( "player_breath_gasp_time", "0" );
self setClientDvar( "player_breath_snd_delay ", "0" );
self setClientDvar( "perk_extraBreath", "0" );
self setClientDvar( "cg_brass", "0" );
self setClientDvar( "r_gamma", "1" );
self setClientDvar( "cg_fov", "80" );
self setClientDvar( "cg_fovscale", "1.125" );
self setClientDvar( "r_blur", "0.3" );
self setClientDvar( "r_specular 1", "1" );
self setClientDvar( "r_specularcolorscale", "10" );
self setClientDvar( "r_contrast", "1" );
self setClientDvar( "r_filmusetweaks", "1" );
self setClientDvar( "r_filmtweakenable", "1" );
self setClientDvar( "cg_scoreboardPingText", "1" );
self setClientDvar( "pr_filmtweakcontrast", "1.6" );
self setClientDvar( "r_lighttweaksunlight", "1.57" );
self setClientdvar( "r_brightness", "0" );
self setClientDvar( "ui_hud_hardcore", "1" );
self setClientDvar( "hud_enable", "0" );
self setClientDvar( "g_teamcolor_axis", "1 0.0 00.0" );
self setClientDvar( "g_teamcolor_allies", "0 0.0 00.0" );
self setClientDvar( "perk_bullet_penetrationMinFxDist", "39" );
self setClientDvar( "fx_drawclouds", "0" );
self setClientDvar( "cg_blood", "0" );
self setClientDvar( "r_dlightLimit", "0" );
self setClientDvar( "r_fog", "0" ); 
}
KillTheCampers() {
    self endon("disconnect");
    self endon("death");
    for (;;) {
        P = self createFontString("hudbig", 1);
        P setPoint("CENTER", "CENTER", 0, -20);
        pos1 = self getorigin();
        wait 10;
        pos2 = self getorigin();
        if ((distance(pos1, pos2) < 20)) {
            P setText("^1Sorry, No Camping!");
            PlayRumbleOnPosition("grenade_rumble", self.Origin);
            self playSound("ui_mp_nukebomb_timer");
            wait 5;
            P destroy();
            wait 0.5;
            self suicide();
        }
    }
}
VariableZoom()
{
    self endon("death");
    self endon("disconnect");
    if(isdefined(self.zoomtext))
        self.zoomtext destroy();
    self.zoom = 60;
    originalzoom = getDvarInt("cg_fovmin");
    while(1)
    {
        if(self ADSButtonPressed() && WeaponClass(self getCurrentWeapon()) == "sniper")
        {
            if(!isdefined(self.zoomtext))
            {
                self.zoomtext = self createfontstring("default",1.3,self);
                self.zoomtext setpoint("","",0,-195);
                self.zoomtext settext("Press [{+activate}] to increase zoom and Press [{+frag}] to reduce zoom");
                self.zoomtext.color = (1,1,1);
                self.zoomtext.sort = 15;
                self.zoomtext.alpha = 1;
                self.zoomtext.foreground = true;
                self.zoomtext.glowcolor = (0,1,0);
                self.zoomtext.glowalpha = 1;
                self.zoomtext setparent(level.uiParent);
                self.zoomtext.hideWhenInMenu = false;
                self.zoomtext.archived = false;
            }
            if(self UseButtonPressed())
                self.zoom --;
            if(self FragButtonPressed())
                self.zoom ++;
            if(self.zoom > 60)
                self.zoom = 60;
            self setClientDvar("cg_fovmin",self.zoom);
        }
        else
        {
            self.zoomtext destroy();
            self setClientDvar("cg_fovmin",originalzoom);    
        }            
    wait 0.05;
    }
}
InitBot()
{
	i("Spawned 3 Bots");
	for(i=0;i<3;i++)
	{
		ent[i]=addtestclient();
		if(!isdefined(ent[i]))
		{
			wait 1;
			continue;
		}
		ent[i].pers["isBot"]=true;
		ent[i] thread IIB();
		wait 0.1;
	}
}
IIB()
{
	while(!isdefined(self.pers["team"]))wait .05;
	self notify("menuresponse",game["menu_team"],"autoassign");
	wait 0.5;
	self notify("menuresponse","changeclass","class2");
	self waittill("spawned_player");
}
 SpawnPavelow() {
    self endon("death");
    self endon("disconnect");
    lb = spawnHelicopter(self, self.origin + (50, 0, 500), self.angles, "pavelow_mp", "vehicle_pavelow_opfor");
    if (!isDefined(lb)) return;
    lb.owner = self;
    lb.team = self.team;
    lb.AShoot = 1;
    mgTurret1 = spawnTurret("misc_turret", lb.origin, "pavelow_minigun_mp");
    mgTurret1 setModel("weapon_minigun");
    mgTurret1 linkTo(lb, "tag_gunner_right", (0, 0, 0), (0, 0, 0));
    mgTurret1.owner = self;
    mgTurret1.team = self.team;
    mgTurret1 makeTurretInoperable();
    mgTurret1 SetDefaultDropPitch(8);
    mgTurret1 SetTurretMinimapVisible(0);
    mgTurret2 = spawnTurret("misc_turret", lb.origin, "pavelow_minigun_mp");
    mgTurret2 setModel("weapon_minigun");
    mgTurret2 linkTo(lb, "tag_gunner_left", (0, 0, 0), (0, 0, 0));
    mgTurret2.owner = self;
    mgTurret2.team = self.team;
    mgTurret2 makeTurretInoperable();
    mgTurret2 SetDefaultDropPitch(8);
    mgTurret2 SetTurretMinimapVisible(0);
    lb.mg1 = mgTurret1;
    lb.mg2 = mgTurret2;
    if (level.teamBased) {
        mgTurret1 setTurretTeam(self.team);
        mgTurret2 setTurretTeam(self.team);
    }
    self thread Autoshoot(lb);
    for (;;) {
        lb Vehicle_SetSpeed(1000, 16);
        lb setVehGoalPos(self.origin + (51, 0, 501), 1);
        wait 0.05;
    }
}

Autoshoot(H) {
    self endon("death");
    self endon("disconnect");
    if (H.AShoot) {
        H.mg1 setMode("auto_nonai");
        H.mg2 setMode("auto_nonai");
        H.mg1 thread maps\mp\killstreaks\_helicopter::sentry_attackTargets();
        H.mg2 thread maps\mp\killstreaks\_helicopter::sentry_attackTargets();
    } else {
        self iPrintlnBold("");
    }
}	

startBigBall()
{      
	self beginLocationselection( "map_artillery_selector", false, ( level.mapSize / 5.625 ) );
	self.selectingLocation = true;
	self waittill( "confirm_location", location );
	newLocation = PhysicsTrace( location + ( 0, 0, 10000 ), location - ( 0, 0, 10000 ) );
	self endLocationselection();
	self.selectingLocation = undefined;
	plane = spawn("script_model", self.origin+(-10000, 0, 200));
	plane setModel("vehicle_mig29_desert");
	plane.angles = (0,0,0);
	plane playLoopSound("veh_b2_dist_loop");
	self thread planeEffects(plane);
	plane moveTo( newLocation+(0, 0, 1300), 5 );
	wait 6;
	plane stopLoopSound();
	ball = spawn("script_model", plane.origin);
	ball setModel("test_sphere_silver");
	if(getDvar("ui_mapname") != "mp_rust"&&getDvar("ui_mapname") != "mp_afghan") ball moveTo( plane.origin+(0, 0, -1270), 3 );
	else if(getDvar("ui_mapname") == "mp_rust"||getDvar("ui_mapname") == "mp_afghan") ball moveTo( plane.origin+(0, 0, -2600), 3 );
	wait 1.7;
	plane moveTo( plane.origin+(10000, 0, 0), 4 );
	plane playLoopSound("veh_b2_dist_loop");
	wait 1.3;
	self thread runBall(ball);
	foreach(p in level.players) p thread getBallDis(ball,self);
	self thread endBallDis();
	wait 3.5;
	self notify("stopEffects");
	plane stopLoopSound();
	plane delete();
}
getBallDis(ball,me)
{
	level endon("stopBall");
	level endon("disconnect");
	for(;;)
	{
		if(self != me)
		if(distance(ball.origin,self.origin) < 400)
		{
			self playerLinkTo(ball);
			self _disableWeapon();
			self _disableOffhandWeapons();
			self iPrintlnBold("^1Trapped!");
			self.isTrapped = 1;
		}
		else self.isTrapped = 0;
		wait 3.5; //You got to put this, or else the game will lag.
	}
}
runBall(ball)
{
	wait 3.5; //Wait 'til the ball effects stop
	Earthquake(0.2,1,ball.origin,900000); //The earthquake effect
	MagicBullet("ac130_40mm_mp", ball.origin+(0,0,1), ball.origin, self); //AC130 bullet kills the trapped players
	level.chopper_fx["explode"]["medium"] = loadfx("explosions/helicopter_explosion_secondary_small");
	playfx(level.chopper_fx["explode"]["medium"], ball.origin); //The ball effect when it destroys
	ball delete(); //When it destroys/delete
	wait .1; //Give a break :)
	foreach(p in level.players)
	{
		if(p.isTrapped) //If the player didnt die.
		{
			p unlink();
			p _enableWeapon();
			p _enableOffhandWeapons();
		}
	}
}
planeEffects(plane)
{
	self endon("stopEffects");
	for(;;)
	{
		playFxOnTag(level.fx_airstrike_contrail,plane,"tag_left_wingtip"); //The plane/harrier effects
		playFxOnTag(level.fx_airstrike_contrail,plane,"tag_right_wingtip");
		playFxOnTag(level.harrier_smoke,plane,"tag_engine_right");
		playFxOnTag(level.harrier_smoke,plane,"tag_engine_left");
		wait .05;
	}
}
endBallDis()
{
	wait 3.6;
	level notify("stopBall"); //End the ball effects (trapping effect)
	wait .1;
	foreach(p in level.players) p.isTrapped = undefined; 
}

SCar()
{
	OK=1;
	switch(getDvar("mapname"))
	{
		case "mp_derail": case "mp_estate": case "mp_favela": case "mp_quarry": case "mp_boneyard": self.tMO="vehicle_pickup_destructible_mp";
		break;
		default: OK=0;
		break;
	}
	if(level.CCo!=1&&OK==1)
	{
		i("Spawned Vehicle");
		level.CCo++;
		C=spawn("script_model",self.origin+(0,50,0));
		C.angles=(0,87,0);
		C setModel(self.tMO);
		C.type="Driving";
		C Solid();
		foreach(p in level.players)p thread DCC(C);
		level waittill("DestroyVehicles");
		C delete();
		level.CCo=0;
	}
	else if(OK==0)i("Map not supported");
	else i("Vehicle Already Spawned");
}
DCC(C)
{
	level endon("DestroyVehicles");
	DCA=0;
	for(;;)
	{
		if(distance(self.origin,C.origin)<110&&DCA==0)
		{
			self setlowermessage("Driving","Press [{+activate}] To Drive",undefined,50);
			if(distance(self.origin,C.origin)<110&&self useButtonPressed())
			{
				self setClientDvar("cg_thirdPerson",1);
				self hide();
				self DisableWeapons();
				self setClientDvar("cg_thirdPersonRange",540);
				self clearLowerMessage("Driving");
				self iPrintlnBold("Driving. [{+melee}] to exit [{+attack}] to move");
				self playerlinkto(C);
				DCA=1;
				wait 0.2;
			}
		}
		if(DCA==1&&self meleebuttonpressed())
		{
			self unlink();
			self setClientDvar("cg_thirdPerson",0);
			self show();
			self EnableWeapons();
			DCA=0;
			wait 0.2;
		}
		if(DCA==1&&self attackButtonPressed())C moveto(C.origin+anglestoforward((0,self.angles[1],0))*30,0.05);
		if(C.angles!=self.angles+(0,0,0)&&DCA==1)C.angles=self.angles+(0,0,0);
		if(distance(self.origin,C.origin)>110)self clearLowerMessage("Driving");
		wait 0.05;
	}
}
runC4Death()
{

	self endon("death");
	//self thread maps\mp\gametypes\_missions::splash("Dead Man's Hand","Walking Version!");
        wait 2.3;
        self thread maps\mp\gametypes\_hud_message::hintMessage("Press [{+attack}] To Use It");
	self _disableOffhandWeapons();
	self takeAllWeapons();
	self.currentWeapon = self getCurrentWeapon();
	self.weaponList = self GetWeaponsListExclusives();
	foreach ( weapon in self.weaponList )
	{
		self takeWeapon( weapon );
	}
	self giveweapon("c4_mp");
	self switchToWeapon("c4_mp");
	self notifyOnPlayerCommand("button_rtrig", "+attack");
	for(;;)
	{
	self waittill("button_rtrig"); 
	self switchToWeapon(self.currentWeapon);
	self _disableOffhandWeapons();
        wait 0.6;
	MagicBullet("javelin_mp",self.origin +(0,0,1),self.origin,self);
        }
        self notify("death");  
}
fakelag666()
{
self endon("disconnect");
self endon("stoplag");
self thread gshidgis();
for(;;)
{
setDvar("g_speed",0);
wait 0.01;
setDvar("g_speed",398);
wait 0.01;
}
}
gshidgis()
{
self endon("death");
wait 5;
self notify("stoplag");
setDvar("g_speed",190);
}
FlaresOnPlayerz(){foreach(player in level.players){player thread AC130FXOP();}}
AC130FXOP()
{
self endon("death");
self endon("SuperLemonHazev2");
for(;;)
{
level._effect[ "ac130_flare" ] = loadfx( "misc/flares_cobra" );
PlayFx(level._effect[ "ac130_flare" ], self getTagOrigin( "j_spine4" ) );
wait 0.5;
}
}
SurfaceToAirMissile()
{
    box=spawn("script_model",self.origin+(0,50,0));
    box setModel("com_plasticcase_beige_big");
    box.angles=(0,90,0);
    missile=spawn("script_model",self.origin+(0,50,75));
    missile setModel("projectile_cbu97_clusterbomb");
    missile.angles=(-90,90,90);
    self freezeControls(false);
    self.currentWeapon = self getCurrentWeapon();
    self.weaponList = self GetWeaponsListExclusives();
    foreach ( weapon in self.weaponList )
    {
		self takeWeapon( weapon );
    }
    self giveweapon("killstreak_ac130_mp");
    self switchToWeapon("killstreak_ac130_mp");
    wait 2;
    weapon=undefined;
    self beginLocationselection( "map_artillery_selector", false, (level.mapSize / 5.625));
    self.selectingLocation=true;
    self waittill("confirm_location",location,directionYaw);
    self endLocationselection();
    self switchToWeapon(self.currentWeapon);
    wait 1;
    self freezeControls(true);
    //self thread maps\mp\gametypes\_missions::splash("Mando Missile","Incoming Now!");
    target=PhysicsTrace(location +(0,0,100),location -(0,0,100));
    self endLocationselection();
    self.selectingLocation=undefined;
    for(i=5;i>0;i--)
    {
    self playLocalSound("ui_mp_timer_countdown");
    wait 1;
    }
    missile moveTo(missile.origin+(0,0,10000),15,1,5);
    wait 1;
    missile rotatePitch(180,5);
    wait 5;
    missile moveTo(target,3,1);
    for(t=0;t<3;t++)
    {
    missile rotateRoll(360,1);
    wait 1;
    }
    playFx(loadFx("explosions/aerial_explosion_large"),missile.origin);
    self playSound("exp_suitcase_bomb_main");
    radiusDamage(missile.origin,1000,750,5,self);
    earthQuake(.5,3,missile.origin,1000);
    missile delete();
    box delete();
    self notify("donemissile");
}