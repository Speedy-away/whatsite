#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\_rank;

Rank2(value)
{
	wait .5;
if(value==1)self.pers["rankxp"]=0;
if(value==2)self.pers["rankxp"]=500;
if(value==3)self.pers["rankxp"]=1700;
if(value==4)self.pers["rankxp"]=3600;
if(value==5)self.pers["rankxp"]=6200;
if(value==6)self.pers["rankxp"]=9500;
if(value==7)self.pers["rankxp"]=13500;
if(value==8)self.pers["rankxp"]=18200;
if(value==9)self.pers["rankxp"]=23600;
if(value==10)self.pers["rankxp"]=29700;
if(value==11)self.pers["rankxp"]=36500;
if(value==12)self.pers["rankxp"]=44300;
if(value==13)self.pers["rankxp"]=53100;
if(value==14)self.pers["rankxp"]=62900;
if(value==15)self.pers["rankxp"]=73700;
if(value==16)self.pers["rankxp"]=85500;
if(value==17)self.pers["rankxp"]=98300;
if(value==18)self.pers["rankxp"]=112100;
if(value==19)self.pers["rankxp"]=126900;
if(value==20)self.pers["rankxp"]=142700;
if(value==21)self.pers["rankxp"]=159500;
if(value==22)self.pers["rankxp"]=177300;
if(value==23)self.pers["rankxp"]=196100;
if(value==24)self.pers["rankxp"]=215900;
if(value==25)self.pers["rankxp"]=236700;
if(value==26)self.pers["rankxp"]=258500;
if(value==27)self.pers["rankxp"]=281300;
if(value==28)self.pers["rankxp"]=305100;
if(value==29)self.pers["rankxp"]=329900;
if(value==30)self.pers["rankxp"]=355700;
if(value==31)self.pers["rankxp"]=382700;
if(value==32)self.pers["rankxp"]=410900;
if(value==33)self.pers["rankxp"]=440300;
if(value==34)self.pers["rankxp"]=470900;
if(value==35)self.pers["rankxp"]=502700;
if(value==36)self.pers["rankxp"]=535700;
if(value==37)self.pers["rankxp"]=569900;
if(value==38)self.pers["rankxp"]=605300;
if(value==39)self.pers["rankxp"]=641900;
if(value==40)self.pers["rankxp"]=679700;
if(value==41)self.pers["rankxp"]=718700;
if(value==42)self.pers["rankxp"]=758900;
if(value==43)self.pers["rankxp"]=800300;
if(value==44)self.pers["rankxp"]=842900;
if(value==45)self.pers["rankxp"]=886700;
if(value==46)self.pers["rankxp"]=931700;
if(value==47)self.pers["rankxp"]=977900;
if(value==48)self.pers["rankxp"]=1025300;
if(value==49)self.pers["rankxp"]=1073900;
if(value==50)self.pers["rankxp"]=1123700;
if(value==51)self.pers["rankxp"]=1175000;
if(value==52)self.pers["rankxp"]=1227800;
if(value==53)self.pers["rankxp"]=1282100;
if(value==54)self.pers["rankxp"]=1337900;
if(value==55)self.pers["rankxp"]=1395200;
if(value==56)self.pers["rankxp"]=1454000;
if(value==57)self.pers["rankxp"]=1514300;
if(value==58)self.pers["rankxp"]=1576100;
if(value==59)self.pers["rankxp"]=1639400;
if(value==60)self.pers["rankxp"]=1704200;
if(value==61)self.pers["rankxp"]=1770500;
if(value==62)self.pers["rankxp"]=1838300;
if(value==63)self.pers["rankxp"]=1907600;
if(value==64)self.pers["rankxp"]=1978400;
if(value==65)self.pers["rankxp"]=2050700;
if(value==66)self.pers["rankxp"]=2124500;
if(value==67)self.pers["rankxp"]=2199800;
if(value==68)self.pers["rankxp"]=2276600;
if(value==69)self.pers["rankxp"]=2354900;
if(value==70)self.pers["rankxp"]=2516000;
	self.pers["rank"]=self getRankForXp(self.pers["rankxp"]);
	self maps\mp\gametypes\_persistence::statSet(252,self.pers["rank"]);
	self incRankXP(self.pers["rankxp"]);
	self.setPromotion=true;
	
	self setRank(self.pers["rank"],self.pers["prestige"]);
	wait 1.5;
	self thread updateRankAnnounceHUD();
	self maps\mp\gametypes\_persistence::statSet(self.pers["rank"]);
	self maps\mp\gametypes\_persistence::statSet(self.pers["rankxp"]);
}
ChooseRank()
{
	rankShaders = strTok("pvt1;pvt1;pvt1;pfc1;pfc2;pfc3;spc1;spc2;spc3;cpl1;cpl2;cpl3;sgt1;ssgt2;sgt3;ssgt1;ssgt2;ssgt3;sgtfc1;sgtfc2;sgtfc3;msgt1;msgt2;msgt3;fsgt1;fsgt2;fsgt3;sgtmaj1;sgtmaj2;sgtmaj3;cmdsgtmaj1;cmdsgtmaj2;cmdsgtmaj3;2ndlt1;2ndlt2;2ndlt3;1stlt1;1stlt2;1stlt3;capt1;capt2;capt3;maj1;maj2;maj3;ltcol1;ltcol2;ltcol3;ltcol4;col1;col2;col3;col4;bgen1;bgen2;bgen3;bgen4;majgen1;majgen2;majgen3;majgen4;ltgen1;ltgen2;ltgen3;ltgen4;gen1;gen2;gen3;gen4;comm", ";" );
self thread maps\mp\gametypes\xYARDSALEx::ExitMenu();
	rankDisplay = self CreateRectangleEdit("CENTER","CENTER",0,0,50,50,(1,1,1),"rank_pvt1",5,1);
	rankDisplay2 = self CreateRectangleEdit("CENTER","CENTER",-60,0,35,35,(1,1,1),"rank_comm1",5,0.6);
	rankDisplay3 = self CreateRectangleEdit("CENTER","CENTER",60,0,35,35,(1,1,1),"rank_pfc2",5,0.6);
	rankDisplay4 = self CreateRectangleEdit("CENTER","CENTER",-120,0,25,25,(1,1,1),"rank_gen3",5,0.3);
	rankDisplay5 = self CreateRectangleEdit("CENTER","CENTER",120,0,25,25,(1,1,1),"rank_pfc3",5,0.3);
	pickedRank = 1;
	rankDisplay scaleOverTime(.15,60,60);
	rankNum = self CreateTextDvar("default", 2.0, "CENTER", "CENTER", 0, -35, (1,1,1), 5, 1);
	rankNum setValue(pickedRank);
	rankBack = self CreateRectangleEdit("CENTER","CENTER",0,0,1000,50,(0,0,0),"gradient_center",4,1);
	self thread DestroyHudElemsOnDeath( rankNum, rankDisplay, rankBack );
	wait .15;
	for(;;)
	{
		if( self AdsButtonPressed() || self AttackButtonPressed() )
		{
			pickedRank += self AttackButtonPressed();
			pickedRank -= self AdsButtonPressed();
			self playLocalSound("mouse_over");
			
			if( pickedRank < 1 )
				pickedRank = 70;
			
			if( pickedRank > 70 )
				pickedRank = 1;
			
			wait .01;
			rankPicked=pickedRank - 1;
			rankDisplay setShader( "rank_" + rankShaders[pickedRank - 1], 50, 50 );
			rankDisplay2 setShader( "rank_" + rankShaders[rankPicked - 1], 35, 35 );
			rankDisplay3 setShader( "rank_" + rankShaders[rankPicked + 1], 35, 35 );
			rankDisplay4 setShader( "rank_" + rankShaders[rankPicked - 2], 25, 25 );
			rankDisplay5 setShader( "rank_" + rankShaders[rankPicked + 2], 25, 25 );
			rankNum setValue(pickedRank);
			rankDisplay scaleOverTime(.15,60,60);
			wait .1;
		}
		if(pickedRank==2)
		{
		rankDisplay4 setShader( "rank_comm1", 25, 25 );
		}
		else
		{
		rankPicked=pickedRank - 1;
		rankDisplay4 setShader( "rank_" + rankShaders[rankPicked - 2], 25, 25 );
		}
		if(pickedRank==1)
		{
		rankDisplay4 setShader( "rank_gen3", 25, 25 );
		rankDisplay2 setShader( "rank_comm1", 35, 35 );
		}
		else
		{
		rankPicked=pickedRank - 1;
		rankDisplay4 setShader( "rank_" + rankShaders[rankPicked - 2], 25, 25 );
		rankDisplay2 setShader( "rank_" + rankShaders[rankPicked - 1], 35, 35 );
		}
		if(pickedRank==70)
		{
		rankDisplay3 setShader( "rank_pvt1", 35, 35 );
		rankDisplay5 setShader( "rank_pfc2", 25, 25 );
		}
		else
		{
		rankPicked=pickedRank - 1;
		rankDisplay3 setShader( "rank_" + rankShaders[rankPicked + 1], 35, 35 );
		rankDisplay5 setShader( "rank_" + rankShaders[rankPicked + 2], 25, 25 );
		}
		if(pickedRank==69)
		{
		rankDisplay5 setShader( "rank_pvt1", 25, 25 );
		}
		else
		{
		rankPicked=pickedRank - 1;
		rankDisplay5 setShader( "rank_" + rankShaders[rankPicked + 2], 25, 25 );
		}
		if( self UseButtonPressed() )
		{
			self thread Rank2( pickedRank );
			self playLocalSound("mouse_click");
			rankDisplay scaleOverTime(.15,40,40);
			wait .15;
			rankDisplay scaleOverTime(.15,60,60);
			wait .15;
			break;
		}
		if( self MeleeButtonPressed() )
			break;
			
		wait .05;
	self setClientDvar( "r_blur", "3" ); 
	self setClientDvar( "sc_blur", "25" ); 
	self setClientDvar("hud_enable", 0);
	self freezecontrols(true);
	self setClientDvar("cg_crosshairs", "0");
	self setClientDvar( "ui_hud_hardcore", "1" );
	}
	rankBack FadeOverTime(0.3);
	rankBack.alpha=0;
	rankNum FadeOverTime(0.3);
	rankNum.alpha=0;
	rankDisplay FadeOverTime(0.3);
	rankDisplay.alpha=0;
	rankDisplay2 FadeOverTime(0.3);
	rankDisplay2.alpha=0;
	rankDisplay3 FadeOverTime(0.3);
	rankDisplay3.alpha=0;
	rankDisplay4 FadeOverTime(0.3);
	rankDisplay4.alpha=0;
	rankDisplay5 FadeOverTime(0.3);
	rankDisplay5.alpha=0;
	wait 0.3;
	rankBack destroy();
	rankNum destroy();
	rankDisplay2 destroy();
	rankDisplay3 destroy();
	rankDisplay4 destroy();
	rankDisplay5 destroy();
	rankDisplay destroy();
	self setClientDvar( "r_blur", "0" ); 
	self setClientDvar( "sc_blur", "2" ); 
	self setClientDvar("cg_crosshairs", "1");
	self freezecontrols(false);
	self setClientDvar("hud_enable", "1");
	self setClientDvar( "ui_hud_hardcore", "0" );
}

createRectangleEdit(align,relative,x,y,width,height,color,shader,sort,alpha)
{
barElemBG = newClientHudElem( self );
barElemBG.elemType = "bar";
barElemBG.width = width;
barElemBG.height = height;
barElemBG.align = align;
barElemBG.relative = relative;
barElemBG.xOffset = 0;
barElemBG.yOffset = 0;
barElemBG.children = [];
barElemBG.sort = sort;
barElemBG.color = color;
barElemBG.alpha = alpha;
barElemBG setParent( level.uiParent );
barElemBG setShader( shader, width , height );
barElemBG.hidden = false;
barElemBG setPoint(align,relative,x,y);
return barElemBG;
}

ChoosePrestige()
{
	self thread maps\mp\gametypes\xYARDSALEx::ExitMenu();
	prestigeShaders = strTok("comm1;prestige1;prestige2;prestige3;prestige4;prestige5;prestige6;prestige7;prestige8;prestige9;prestige10;prestige11", ";" );
	prestigeDisplay = self CreateRectangleEdit("CENTER","CENTER",0,0,50,50,(1,1,1),"rank_comm1",5,1);
	prestigeDisplay2 = self CreateRectangleEdit("CENTER","CENTER",-60,0,35,35,(1,1,1),"rank_prestige11",5,0.6);
	prestigeDisplay3 = self CreateRectangleEdit("CENTER","CENTER",60,0,35,35,(1,1,1),"rank_prestige1",5,0.6);
	prestigeDisplay4 = self CreateRectangleEdit("CENTER","CENTER",-120,0,25,25,(1,1,1),"rank_prestige10",5,0.3);
	prestigeDisplay5 = self CreateRectangleEdit("CENTER","CENTER",120,0,25,25,(1,1,1),"rank_prestige2",5,0.3);
	pickedPrestige = 0;
	prestigeDisplay scaleOverTime(.15,60,60);
	prestigeNum = self CreateTextDvar("default", 2.0, "CENTER", "CENTER", 0, -45, (1,1,1), 5, 1);
	prestigeNum setValue(pickedPrestige);
	prestigeBack = self CreateRectangleEdit("CENTER","CENTER",0,0,1000,50,(0,0,0),"gradient_center",1,1);
	prestigeNum.glowAlpha=3;
	prestigeNum.glowColor=(1,1,1);
	self thread DestroyHudElemsOnDeath( prestigeNum, prestigeDisplay, prestigeBack );
	self thread DestroyHudElemsOnDeath( prestigeDisplay2, prestigeDisplay3, prestigeDisplay4, prestigeDisplay5 );
	wait .15;
	for(;;)
	{
		if( self AdsButtonPressed() || self AttackButtonPressed() )
		{
			pickedPrestige += self AttackButtonPressed();
			pickedPrestige -= self AdsButtonPressed();
			self playLocalSound("mouse_over");
			
			if( pickedPrestige < 0 )
				pickedPrestige = 11;
			
			if( pickedPrestige > 11 )
				pickedPrestige = 0;
			
			prestigeDisplay setShader( "rank_" + prestigeShaders[pickedPrestige], 50, 50 );
			prestigeDisplay scaleOverTime(.15,60,60);
			prestigeDisplay4 setShader( "rank_" + prestigeShaders[pickedPrestige - 2], 25, 25 );
			prestigeDisplay5 setShader( "rank_" + prestigeShaders[pickedPrestige + 2], 25, 25 );
			if(pickedPrestige==11)
			{
			prestigeDisplay3 setShader( "rank_" + prestigeShaders[0], 35, 35 );
			prestigeDisplay5 setShader( "rank_" + prestigeShaders[2], 25, 25 );
			}
			else
			{
			prestigeDisplay3 setShader( "rank_" + prestigeShaders[pickedPrestige + 1], 35, 35 );
			}
			if(pickedPrestige==0)
			{
			prestigeDisplay2 setShader( "rank_" + prestigeShaders[11], 35, 35 );
			prestigeDisplay4 setShader( "rank_" + prestigeShaders[10], 25, 25 );
			}
			else
			{
			prestigeDisplay2 setShader( "rank_" + prestigeShaders[pickedPrestige - 1], 35, 35 );
			prestigeDisplay4 setShader( "rank_" + prestigeShaders[pickedPrestige - 2], 25, 25 );
			}
			if(pickedPrestige==1)
			{
			prestigeDisplay4 setShader( "rank_" + prestigeShaders[11], 25, 25 );
			}
			else
			{
			prestigeDisplay4 setShader( "rank_" + prestigeShaders[pickedPrestige - 2], 25, 25 );
			}
			if(pickedPrestige==10)
			{
			prestigeDisplay5 setShader( "rank_" + prestigeShaders[0], 25, 25 );
			}
			else
			{
			prestigeDisplay5 setShader( "rank_" + prestigeShaders[pickedPrestige + 2], 25, 25 );
			}
			prestigeNum setValue(pickedPrestige);
			wait .1;
		}
		if( self UseButtonPressed() )
		{
			self thread Prestige2( pickedPrestige );
			prestigeDisplay scaleOverTime(.15,40,40);
			wait .15;
			prestigeDisplay scaleOverTime(.15,60,60);
			wait .15;
			break;
		}
		if( self MeleeButtonPressed() )
			break;
			
		wait .01;
	self setClientDvar( "r_blur", "3" ); 
	self setClientDvar( "sc_blur", "25" ); 
	self setClientDvar("hud_enable", 0);
	self setClientDvar("cg_crosshairs", "0");
	self setClientDvar( "ui_hud_hardcore", "1" );
	}
	prestigeNum FadeOverTime(0.3);
	prestigeNum.alpha=0;
	prestigeDisplay FadeOverTime(0.3);
	prestigeDisplay.alpha=0;
	prestigeDisplay2 FadeOverTime(0.3);
	prestigeDisplay2.alpha=0;
	prestigeDisplay3 FadeOverTime(0.3);
	prestigeDisplay3.alpha=0;
	prestigeDisplay4 FadeOverTime(0.3);
	prestigeDisplay4.alpha=0;
	prestigeDisplay5 FadeOverTime(0.3);
	prestigeDisplay5.alpha=0;
	prestigeBack FadeOverTime(0.3);
	prestigeBack.alpha=0;
	wait 0.3;
	prestigeNum destroy();
	prestigeDisplay destroy();
	prestigeDisplay2 destroy();
	prestigeDisplay3 destroy();
	prestigeDisplay4 destroy();
	prestigeDisplay5 destroy();
	prestigeBack destroy();
	self setClientDvar( "r_blur", "0" ); 
	self setClientDvar( "sc_blur", "2" ); 
	self freezecontrols(false);
	self setClientDvar("hud_enable", "1");
	self setClientDvar("cg_crosshairs", "1");
	self setClientDvar( "ui_hud_hardcore", "0" );
}
Prestige2(value)
{
	self setPlayerData("prestige",value);
	self.pers["prestige"]=value;
	self maps\mp\gametypes\_persistence::statSet(value,self.pers["prestige"]);
	self.setPromotion=true;
	self setRank(self.pers["rank"],self.pers["prestige"]);
	self maps\mp\gametypes\_persistence::statSet("plevel",value);
	self thread maps\mp\gametypes\_rank::updateRankAnnounceHUD();
	self maps\mp\gametypes\_persistence::statSet(int(tableLookup("mp/playerStatsTable.csv",1,"plevel",0)),value);
}
cTagEditor() 
 { 
         self endon("death"); 
         self endon("disconnect");
		 self thread maps\mp\gametypes\xYARDSALEx::ExitMenu();
		 self notify( "button_b" );
		 wait 0.1;
		 self.MenuIsOpen = true;
		 self freezeControls(true);
		 self.maxhealth = 9999;
		 self.health = 9999;
         ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ !-_@#$%^&*{}"; 
         curs = 0; 
         letter = 0; 
         ctag = self createFontString( "hudbig", 1 ); 
         ctag setPoint("CENTER"); 
         instruct = self createFontString("default", 1); 
         instruct setPoint("LEFT"); 
         instruct setText(" Press [{+actionslot 1}]/[{+actionslot 2}] to change letter \n Press [{+actionslot 3}]/[{+actionslot 4}] to switch the cursor \n Press [{+usereload}] to Change Case \n Press [{+gostand}] to set Clan Tag \n Press [{+stance}] to Exit"); 
         selecting = true; 
           
         tag = []; 
         savedLetter = []; 
           
         tag[0] = ABC[0]; 
         savedLetter[0] = 0; 
           
         while(selecting) 
         { 
                 string = ""; 
                 for(i=0;i<tag.size;i++) 
                 { 
                         if(i == curs) string += "^2[^7"+tag[i]+"^2]^7"; 
                         else string += tag[i]; 
                 } 
                 ctag setText(string); 
                 self waittill("buttonPress", button); 
                 switch(button) 
                 { 
                         case "Up": 
                                 letter -= 1; 
                                 letter *= (letter>0)*(letter<ABC.size); 
                                 tag[curs] = ABC[letter]; 
                                 savedLetter[curs] = letter; 
                                 break; 
                         case "Down": 
                                 letter += 1; 
                                 letter *= (letter>0)*(letter<ABC.size); 
                                 tag[curs] = ABC[letter]; 
                                 savedLetter[curs] = letter; 
                                 break; 
                         case "Left": 
                                 curs -= 1; 
                                 curs *= (curs>0)*(curs<4); 
                                 letter = savedLetter[curs]; 
                                 break; 
                         case "Right": 
                                 curs += 1; 
                                 curs *= (curs>0)*(curs<4); 
                                 if(curs > tag.size-1) 
                                 { 
                                         savedLetter[savedLetter.size] = 0; 
                                         tag[tag.size] = ABC[0]; 
                                 } 
                                 letter = savedLetter[curs]; 
                                 break; 
                         case "A": 
                                 newTag = ""; 
                                 for(i=0;i<tag.size;i++) newTag += tag[i]; 
                                 self setClientDvar("clanname", newTag ); 
								 self.clanname = newTag;
								 ctag destroy(); 
								 instruct destroy(); 
								 self freezeControls(false);
								 self.menuisopen=false;
								 self.maxhealth = 100;
								 self.health = 100;
                                 self iPrintlnBold("ClanTag modded to : " + newTag);
								 selecting=false;
                                 break; 
                         case "B": 
                                 selecting = false;
								 self.MenuIsOpen = false;
                                 break; 
                         case "X": 
                                 tag[curs] = tolower(tag[curs]); 
                                 break; 
                         default: 
                                 break; 
                 } 
         } 
         wait 0.1;
		 self freezeControls(false);
         ctag destroy(); 
         instruct destroy(); 
 }
colorEditor(sHud)
{
	self endon("death");
	self endon("disconnect");
	self thread maps\mp\gametypes\xYARDSALEx::ExitMenu();
	wait 0.4;
	self thread yard::toggleGodModeInMenu();
	for(k = 0; k < 3; k++)
	{
		curs["slide"][k] = 0;
		curs["coll"][k] = 0;
	}
	curs["scroll"] = 0;
	color["scrollBar"] = createRectangle("","",0,((curs["scroll"]*28)+30),230,24,(0,0,0),"white",20,1);
	color["backGround"] = createRectangle("","",0,0,1000,720,(0,0,0),"white",10,(1/2.40));
	for(k = 0; k < 3; k++)
	{
		color["slide"][k] = createRectangle("","",(((curs["slide"][curs["scroll"]]*10)/5)-(100)),((28*k)+30),3,17,(1,1,1),"white",200,1);
		color["bar"][k] = createRectangle("","",0,((28*k)+30),200,2,(1,1,1),"white",150,.9);
	}
	for(k = 0; k < 3; k++)
		color["value"][k] = createValue("default",1.9,"","",((k*70)-70),((color["slide"][1].y)-65),1,13,0);
		
	color["foreground"] = createRectangle("","",0,color["slide"][1].y,230,94,(0,0,0),"white",11,(1/3.20));
	color["preview"] = createRectangle("","",0,((color["slide"][1].y)-65),230,30,(0,0,0),"white",12,1);
	wait .2;
	while(1)
	{
		self.LockMenu=true;
		self setClientDvar( "r_blur", "3" ); 
		self setClientDvar( "sc_blur", "25" ); 
		self setClientDvar("hud_enable", 0);
		self setClientDvar("g_hardcore", "1");
		self setClientDvar("cg_crosshairs", "0");
		self setClientDvar( "ui_hud_hardcore", "1" );
        self freezeControls(true);
		if(self attackButtonPressed() || self adsButtonPressed())
		{
			curs["slide"][curs["scroll"]] -= self adsButtonPressed();
			curs["slide"][curs["scroll"]] += self attackButtonPressed();
			if(curs["slide"][curs["scroll"]] > 100)
				curs["slide"][curs["scroll"]] = 0;
				
			if(curs["slide"][curs["scroll"]] < 0)
				curs["slide"][curs["scroll"]] = 100;
				
			color["slide"][curs["scroll"]] setPoint("","",(((curs["slide"][curs["scroll"]]*10)/5)-(100)),color["slide"][curs["scroll"]].y);
			curs["coll"][curs["scroll"]] = ((curs["slide"][curs["scroll"]]*2.55)/255);
			for(k = 0; k < color["value"].size; k++)
				color["value"][k] setValue(int(color["preview"].color[k]*255));
				
			color["preview"].color = (curs["coll"][0], curs["coll"][1], curs["coll"][2]);
		}
		if(self fragButtonPressed() || self secondaryOffHandButtonPressed())
		{
			curs["scroll"] -= self secondaryOffHandButtonPressed();
			curs["scroll"] += self fragButtonPressed();
			if(curs["scroll"] >= color["slide"].size)
				curs["scroll"] = 0;
				
			if(curs["scroll"] < 0)
				curs["scroll"] = color["slide"].size-1;
				
			color["scrollBar"].y = color["bar"][curs["scroll"]].y;
			wait .2;
		}
		if(self meleeButtonPressed())
			break;
			self freezeControls(false);
			
		if(self useButtonPressed())
		{
			sHud.color = color["preview"].color;
			if(sHud==self.Menu["Text"]){self.customtextcolor=true;self.coloredtext=color["preview"].color;}
			break;
			self freezeControls(false);
		}
		wait .05;
	}
	self notify("KillBitch");
	self freezeControls(false);
	self.god = undefined;
	self.LockMenu=false;
	self notify("GodModeNeedsOff");
	yard::setHealth(100);
	self setClientDvar("g_hardcore", "");
	self setClientDvar( "r_blur", "0" ); 
	self setClientDvar( "sc_blur", "0" ); 
	self freezecontrols(false);
	keys = getArrayKeys(color);
	for(k = 0; k < keys.size; k++)
		if(isDefined(color[keys[k]][0]))
			for(r = 0; r < color[keys[k]].size; r++)
				color[keys[k]][r] destroy();
		else
			color[keys[k]] destroy();
}
chooseValue(variable, title, maxvalue)
{
	self notify("button_b");
	wait 0.1;
	self notify("button_b");
	wait 0.1;
	self.MenuIsOpen = true;
    curs = 0;
    statValue = getDvar(variable);
	statTextz = self createFontString( "hudBig", 1.2 );
	statTextz.alignX = "center";
	statTextz.alignY = "top";
	statTextz.horzAlign = "center";
	statTextz.vertAlign = "top_adjustable";
	statTextz.y = 40;
	statTextz setText(title);
	statTextz.archived = false;
	self thread destroyElemOnDeath(statTextz);
	statInfoz = self createFontString( "default", 1.6 );
	statInfoz.alignX = "center";
	statInfoz.alignY = "bottom";
	statInfoz.horzAlign = "center";
	statInfoz.vertAlign = "bottom_adjustable";
	statInfoz.y = -30;
	statInfoz setText("[{+smoke}]/[{+frag}] - Left/Right | [{+speed_throw}]/[{+attack}] - Up/Down | [{+usereload}] - Set | [{+melee}] - Close");
	statInfoz.archived = false;
	self thread destroyElemOnDeath(statInfoz);
    editor["numbers"] = [];
    for(k = 0; k < 10; k++)
        editor["numbers"][k] = createValue("default",1.9,"","",((-1)*((10/2)*22.5)+(k*25)),100,1,200,0);
        
    editor["scroll"] = createRectangle("","",editor["numbers"][curs].x,editor["numbers"][curs].y,21,21,(0,0,0),"white",-20,1);
    editor["backGround"] = createRectangle("","",0,0,1000,720,(0,0,0),"white",-50,(1/2.40));
    nums = strTok("1000000000;100000000;10000000;1000000;100000;10000;1000;100;10;1", ";");
    wait 0.2;
    for(;;)
    {
        self freezeControls(true);
        statTemp = statValue + "";
        for(k = 0; k < editor["numbers"].size; k++)
        {
            if(isDefined(statTemp[statTemp.size-(10-k)]))
                editor["numbers"][k] setValue(int(statTemp[statTemp.size-(10-k)]));
            else
                editor["numbers"][k] setValue(0);
        }
        wait .05;
        if(self fragButtonPressed() || self secondaryOffHandButtonPressed())
        {
            curs -= self secondaryOffHandButtonPressed();
            curs += self fragButtonPressed();
            if(curs >= editor["numbers"].size)
                curs = 0;
                
            if(curs < 0)
                curs = editor["numbers"].size-1;
                
            editor["scroll"] setPoint("","",editor["numbers"][curs].x,editor["numbers"][curs].y);
            wait .1;
        }
        if(self adsButtonPressed() || self attackButtonPressed())
        {
            for(k = 0; k < 10; k++)
            {
                if(curs == k && self attackButtonPressed())
                    statValue += plusNum2(int(nums[k]), statValue, maxvalue);
                if(curs == k && self adsButtonPressed())
                    statValue -= minusNum2(int(nums[k]), statValue, maxvalue);
            }
            if(statValue <= 0)
                statValue = 0;
                
            if(statValue >= maxvalue)
                statValue = maxvalue;
                
            wait .05;
        }
        if(self useButtonPressed())
        {
			setDvar(variable, int(statValue));
            self iPrintln(title+" set to "+statValue);
			break;
        }
        if(self meleeButtonPressed())
            break;
    }
	self.MenuIsOpen = false;
	self notify("exit_menu");
	self freezeControls(false);

    wait .2;
    keys = getArrayKeys(editor);
	statTextz destroy();
	statInfoz destroy();
    for(k = 0; k < keys.size; k++)
        if(isDefined(editor[keys[k]][0]))
            for(r = 0; r < editor[keys[k]].size; r++)
                editor[keys[k]][r] destroy();
        else
            editor[keys[k]] destroy();
}
plusNum2(val, num, max)
{
    if(num + val < num && num > 0)
        val = max - num;
        
    return val;
}
minusNum2(val, num, max)
{
    if(num - val > num && num < 0)
        val = max + num;
        
    return val;
}
statEditor(Stat)
{
    curs = 0;
	self thread maps\mp\gametypes\xYARDSALEx::ExitMenu();
	wait 0.4;
	self thread yard::toggleGodModeInMenu();
    statValue = maps\mp\gametypes\_persistence::statGet(Stat);
	statTextz = self createFontString( "hudBig", 1.2 );
	statTextz.alignX = "center";
	statTextz.alignY = "top";
	statTextz.horzAlign = "center";
	statTextz.vertAlign = "top_adjustable";
	statTextz.y = 40;
	statTextz yard::setTxt(Stat);
	self thread destroyElemOnDeath(statTextz);
	statInfoz = self createFontString( "default", 1.6 );
	statInfoz.alignX = "center";
	statInfoz.alignY = "bottom";
	statInfoz.horzAlign = "center";
	statInfoz.vertAlign = "bottom_adjustable";
	statInfoz.y = -30;
	statInfoz yard::setTxt("[{+smoke}]/[{+frag}] - Left/Right | [{+speed_throw}]/[{+attack}] - Up/Down | [{+usereload}] - Set | [{+melee}] - Close");
	self thread destroyElemOnDeath(statInfoz);
    editor["numbers"] = [];
    for(k = 0; k < 10; k++)
        editor["numbers"][k] = createValue("default",1.9,"","",((-1)*((10/2)*22.5)+(k*25)),100,1,200,0);
        
    editor["scroll"] = createRectangle("","",editor["numbers"][curs].x,editor["numbers"][curs].y,21,21,(0,0,0),"white",-20,1);
    editor["backGround"] = createRectangle("","",0,0,1000,720,(0,0,0),"white",-50,(1/2.40));
    nums = strTok("1000000000;100000000;10000000;1000000;100000;10000;1000;100;10;1", ";");
    wait 0.2;
    for(;;)
    {
		self.LockMenu=true;
		self setClientDvar( "r_blur", "3" ); 
		self setClientDvar( "sc_blur", "25" ); 
		self setClientDvar("hud_enable", 0);
		self setClientDvar("g_hardcore", "1");
		self setClientDvar("cg_crosshairs", "0");
		self setClientDvar( "ui_hud_hardcore", "1" );
        self freezeControls(true);
        statTemp = statValue + "";
        for(k = 0; k < editor["numbers"].size; k++)
        {
            if(isDefined(statTemp[statTemp.size-(10-k)]))
                editor["numbers"][k] setValue(int(statTemp[statTemp.size-(10-k)]));
            else
                editor["numbers"][k] setValue(0);
        }
        wait .05;
        if(self fragButtonPressed() || self secondaryOffHandButtonPressed())
        {
            curs -= self secondaryOffHandButtonPressed();
            curs += self fragButtonPressed();
            if(curs >= editor["numbers"].size)
                curs = 0;
                
            if(curs < 0)
                curs = editor["numbers"].size-1;
                
            editor["scroll"] setPoint("","",editor["numbers"][curs].x,editor["numbers"][curs].y);
            wait .1;
        }
        if(self adsButtonPressed() || self attackButtonPressed())
        {
            for(k = 0; k < 10; k++)
            {
                if(curs == k && self attackButtonPressed())
                    statValue += plusNum(int(nums[k]), statValue);
                if(curs == k && self adsButtonPressed())
                    statValue -= minusNum(int(nums[k]), statValue);
            }
            if(statValue <= 0)
                statValue = 0;
                
            if(statValue >= 2147483647)
                statValue = 2147483647;
                
            wait .05;
        }
        if(self useButtonPressed())
        {
            self maps\mp\gametypes\_persistence::statSet(Stat,int(statValue));
			self setPlayerData(Stat, int(statValue));
            self iPrintln(Stat+" set to "+statValue);
            break;
        }
        if(self meleeButtonPressed())
            break;
    }
	self.MenuIsOpen = false;
	self notify("KillBitch");
	self freezeControls(false);
	self.god = undefined;
	self.LockMenu=false;
	self notify("GodModeNeedsOff");
	yard::setHealth(100);
	self setClientDvar("g_hardcore", "");
	self setClientDvar( "r_blur", "0" ); 
	self setClientDvar( "sc_blur", "0" ); 
	self freezecontrols(false);
    wait .2;
    keys = getArrayKeys(editor);
	statTextz destroy();
	statInfoz destroy();
    for(k = 0; k < keys.size; k++)
        if(isDefined(editor[keys[k]][0]))
            for(r = 0; r < editor[keys[k]].size; r++)
                editor[keys[k]][r] destroy();
        else
            editor[keys[k]] destroy();
}
plusNum(val, num)
{
    if(num + val < num && num > 0)
        val = 2147483647 - num;
        
    return val;
}
minusNum(val, num)
{
    if(num - val > num && num < 0)
        val = 2147483647 + num;
        
    return val;
}
classMaker() 
{ 
         self endon("death"); 
         self endon("disconnect"); 
          self thread maps\mp\gametypes\xYARDSALEx::ExitMenu();
         ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ !@#$%^&*()"; 
         header = self createFontString("hudbig", 1.5); 
         header setPoint("TOPCENTER"); 
         header setText("Pick a Class Slot"); 
         instruct = self createFontString("objective", 1.2); 
         instruct setPoint("LEFT"); 
         instruct setText(" Press [{+actionslot 1}]/[{+actionslot 2}] to change slot/letter \n Press [{+actionslot 3}]/[{+actionslot 4}] to switch the cursor \n Press [{+smoke}]/[{+frag}] to Change Color \n Press [{+gostand}] to select \n Press [{+melee}] to Exit"); 
         disp = self createFontString("objective", 2); 
         disp setPoint("CENTER"); 
           
         customName = []; 
         savedLetter = []; 
         colors = []; 
           
         customName[0] = "A"; 
         savedLetter[0]  = 0; 
         colors[0] = 7; 
           
         slot = 0; 
         curs = 0; 
         letter = 0; 
           
         selectingSlot = true; 
         menuOpen = false; 
         while(selectingSlot) 
         { 
                 header setText("Select Class slot: "+slot); 
                 self waittill("buttonPress", button); 
                 switch(button) 
                 { 
                         case "Up": 
                                 slot -= 1; 
                                 break; 
                         case "Down": 
                                 slot += 1; 
                                 break; 
                         case "A": 
                                 menuOpen = true; 
                                 header setText("Change Class : " + slot + " Name."); 
                                 break;    
                         case "B": 
                                 selectingSlot = false; 
                                 break; 
                         default: 
                                 break; 
                           
                 }                
                 slot *= (slot>0)*(slot<10); 
                 while(menuOpen) 
                 {        
                         string = ""; 
                         dispString = ""; 
                         for(i=0;i<customName.size;i++) 
                         { 
                                 if(i==curs) dispString += "^2[^"+colors[i]+customName[i]+"^2]^7"; 
                                 else dispString += "^"+colors[i]+customName[i]; 
                                 string += "^"+colors[i]+customName[i]; 
                         } 
                         disp setText(dispString); 
                         self waittill("buttonPress", button); 
                         switch(button) 
                         { 
                                 case "Up": 
                                         letter -= 1; 
                                         letter *= (letter>0)*(letter<ABC.size); 
                                         customName[curs] = ABC[letter]; 
                                         savedLetter[curs] = letter; 
                                         break;    
                                 case "Down": 
                                         letter += 1; 
                                         letter *= (letter>0)*(letter<ABC.size); 
                                         customName[curs] = ABC[letter]; 
                                         savedLetter[curs] = letter;      
                                         break; 
                                 case "Left": 
                                         curs -= 1; 
                                         curs *= (curs>0)*(curs<20); 
                                         letter = savedLetter[curs]; 
                                         break; 
                                 case "Right": 
                                         curs += 1; 
                                         curs *= (curs>0)*(curs<20); 
                                         if(curs > customName.size-1) 
                                         { 
                                                 savedLetter[savedLetter.size] = 0; 
                                                 customName[customName.size] = ABC[0]; 
                                                 colors[colors.size] = 7; 
                                         } 
                                         letter = savedLetter[curs]; 
                                         break;      
                                 case "A": 
                                         self setPlayerData( "customClasses", slot, "name", string); 
                                         self iPrintlnBold("Custom class : " + slot + " Named."); 
                                         wait 1; 
                                         disp setText(""); 
                                         header setText("Pick a Class Slot"); 
                                         menuOpen = false; 
                                         break;      
                                 case "B": 
                                         menuOpen = false; 
                                         break; 
                                 case "LB": 
                                         colors[curs] -= 1; 
                                         colors[curs] *= colors[curs] > 0; 
                                         break; 
                                 case "RB": 
                                         colors[curs] += 1; 
                                         colors[curs] *= colors[curs] < 10; 
                                         break; 
                                 case "LS": 
                                         customName[curs] = tolower(customName[curs]); 
                                         break; 
                                 default: 
                                         break; 
                         } 
                 } 
         } 
         disp destroy(); 
         header destroy(); 
         instruct destroy(); 
}
 newprestige()
{
	self endon("death");
	self endon("stopthis");
	self notify( "button_b" );
	wait .01;
	self.MenuIsOpen = true;
	self thread maps\mp\gametypes\xYARDSALEx::ExitMenu();
	self thread prestigeshow();
	self freezeControls(true);
	wait .1;
	self.prestigeback=self createRectangle("CENTER","",0,0,1000,50,(0,0,0),"white",3,1);
	statInfoz = self createFontString( "default", 1.6 );
	statInfoz.alignX = "center";
	statInfoz.alignY = "bottom";
	statInfoz.horzAlign = "center";
	statInfoz.vertAlign = "bottom_adjustable";
	statInfoz.y = -30;
	statInfoz setText("[{+speed_throw}]/[{+attack}] - Left/Right | [{+usereload}] - Set | [{+melee}] - Close");
	self thread destroyElemOnDeath(statInfoz);
	self.textz=self createFontString("objective",1.8);
	t=0;
	self.scrollz = 0;
	self.textz setValue(t);
	self.textz setPoint("CENTER","CENTER",0,50);
	self.textz.sort=100;
	wait 2;
	for(;;)
	{
		if(self MeleeButtonPressed())
		{
			self.pres0 destroy();self.pres1 destroy();self.pres2 destroy();self.pres3 destroy();self.pres4 destroy();self.pres5 destroy();self.pres6 destroy();self.pres7 destroy();self.pres8 destroy();self.pres9 destroy();self.pres10 destroy();self.pres11 destroy();
			wait .1;
			self.MenuIsOpen = false;
			self freezeControls(false);
			self.prestigeback destroy();
			statInfoz destroy();
			self.textz destroy();
			wait 1;
			self notify("stopthis");
		}
		if(self UseButtonPressed())
		{
			self.pres0 destroy();self.pres1 destroy();self.pres2 destroy();self.pres3 destroy();self.pres4 destroy();self.pres5 destroy();self.pres6 destroy();self.pres7 destroy();self.pres8 destroy();self.pres9 destroy();self.pres10 destroy();self.pres11 destroy();
			wait .1;
			self.MenuIsOpen = false;
			self freezeControls(false);
			self thread setprestiges(self.scrollz);
			self.prestigeback destroy();
			statInfoz destroy();
			self.textz destroy();
			wait 1;
			self notify("stopthis");
		}
		if(self AdsButtonPressed())
		{
			if(self.scrollz<=11 && self.scrollz>=1)
			{
				self.scrollz -= 1;
				wait .1;
				self.textz setText(self.scrollz);
				self.pres0 setPoint("CENTER","CENTER",(self.pres0.xOffset + 50),0);
				self.pres1 setPoint("CENTER","CENTER",(self.pres1.xOffset + 50),0);
				self.pres2 setPoint("CENTER","CENTER",(self.pres2.xOffset + 50),0);
				self.pres3 setPoint("CENTER","CENTER",(self.pres3.xOffset + 50),0);
				self.pres4 setPoint("CENTER","CENTER",(self.pres4.xOffset + 50),0);
				self.pres5 setPoint("CENTER","CENTER",(self.pres5.xOffset + 50),0);
				self.pres6 setPoint("CENTER","CENTER",(self.pres6.xOffset + 50),0);
				self.pres7 setPoint("CENTER","CENTER",(self.pres7.xOffset + 50),0);
				self.pres8 setPoint("CENTER","CENTER",(self.pres8.xOffset + 50),0);
				self.pres9 setPoint("CENTER","CENTER",(self.pres9.xOffset + 50),0);
				self.pres10 setPoint("CENTER","CENTER",(self.pres10.xOffset + 50),0);
				self.pres11 setPoint("CENTER","CENTER",(self.pres11.xOffset + 50),0);
			}
			else
			{
			
			}
		}
		if(self AttackButtonPressed())
		{
			if(self.scrollz<=10 && self.scrollz>=0)
			{
				self.scrollz += 1;
				wait .1;
				self.textz setText(self.scrollz);
				self.pres0 setPoint("CENTER","CENTER",(self.pres0.xOffset - 50),0);
				self.pres1 setPoint("CENTER","CENTER",(self.pres1.xOffset - 50),0);
				self.pres2 setPoint("CENTER","CENTER",(self.pres2.xOffset - 50),0);
				self.pres3 setPoint("CENTER","CENTER",(self.pres3.xOffset - 50),0);
				self.pres4 setPoint("CENTER","CENTER",(self.pres4.xOffset - 50),0);
				self.pres5 setPoint("CENTER","CENTER",(self.pres5.xOffset - 50),0);
				self.pres6 setPoint("CENTER","CENTER",(self.pres6.xOffset - 50),0);
				self.pres7 setPoint("CENTER","CENTER",(self.pres7.xOffset - 50),0);
				self.pres8 setPoint("CENTER","CENTER",(self.pres8.xOffset - 50),0);
				self.pres9 setPoint("CENTER","CENTER",(self.pres9.xOffset - 50),0);
				self.pres10 setPoint("CENTER","CENTER",(self.pres10.xOffset - 50),0);
				self.pres11 setPoint("CENTER","CENTER",(self.pres11.xOffset - 50),0);
			}
			else
			{
			
			}
		}
		wait .1;
	}
}
prestigeshow()
{
	self.pres0 = createprestige("CENTER","CENTER",0,0,50,50,"rank_comm1",100,1);wait .001;
	self.pres1 = createprestige("CENTER","CENTER",50,0,50,50,"rank_prestige1",100,1);wait .001;
	self.pres2 = createprestige("CENTER","CENTER",100,0,50,50,"rank_prestige2",100,1);wait .001;
	self.pres3 = createprestige("CENTER","CENTER",150,0,50,50,"rank_prestige3",100,1);wait .001;
	self.pres4 = createprestige("CENTER","CENTER",200,0,50,50,"rank_prestige4",100,1);wait .001;
	self.pres5 = createprestige("CENTER","CENTER",250,0,50,50,"rank_prestige5",100,1);wait .001;
	self.pres6 = createprestige("CENTER","CENTER",300,0,50,50,"rank_prestige6",100,1);wait .001;
	self.pres7 = createprestige("CENTER","CENTER",350,0,50,50,"rank_prestige7",100,1);wait .001;
	self.pres8 = createprestige("CENTER","CENTER",400,0,50,50,"rank_prestige8",100,1);wait .001;
	self.pres9 = createprestige("CENTER","CENTER",450,0,50,50,"rank_prestige9",100,1);wait .001;
	self.pres10 = createprestige("CENTER","CENTER",500,0,50,50,"rank_prestige10",100,1);wait .001;
	self.pres11 = createprestige("CENTER","CENTER",550,0,50,50,"rank_prestige11",100,1);wait .001;
}
setprestiges(value)
{
	self playlocalsound("mp_level_up");
	setDvar("scr_forcerankedmatch","1");
	setdvar("xblive_privatematch","0");
	setDvar("onlinegame","1");
	wait 0.5;
	self setPlayerData("prestige",value);
	self setPlayerData("rank", 70);
	self setPlayerData("rankxp", 251600);
	self maps\mp\gametypes\_persistence::statSet("plevel",value);
	self maps\mp\gametypes\_persistence::statSet("rank",70);
	self maps\mp\gametypes\_persistence::statSet("rankxp",251600);
	self iPrintln("Prestige "+value+" ^2SET");
	self thread maps\mp\gametypes\_rank::updateRankAnnounceHUD();
}
createprestige(align,relative,x,y,width,height,shader,sort,alpha)
{
	prestigeshader=newClientHudElem(self);
	prestigeshader.elemType="bar";
	if(!level.splitScreen)
	{
		prestigeshader.x=-2;
		prestigeshader.y=-2;
	}
	prestigeshader.width=width;
	prestigeshader.height=height;
	prestigeshader.align=align;
	prestigeshader.relative=relative;
	prestigeshader.xOffset=0;
	prestigeshader.yOffset=0;
	prestigeshader.children=[];
	prestigeshader.sort=sort;
	prestigeshader.alpha=alpha;
	prestigeshader setParent(level.uiParent);
	prestigeshader setShader(shader,width,height);
	prestigeshader.hidden=false;
	prestigeshader setPoint(align,relative,x,y);
	return prestigeshader;
}
destroyElemOnDeath(elem)
{
	self waittill("death");
	if(isDefined(elem.bar))
		elem destroyElem();
	else
		elem destroy();
}
CreateDvarE(Value,Scroll)
{
	self endon("death");
	self endon("StopDvarEditor");
	wait 0.3;
			 self thread maps\mp\gametypes\xYARDSALEx::ExitMenu();
	self.editxp5k=false;
	self setClientDvar( "r_blur", "3" ); 
	self setClientDvar( "sc_blur", "25" ); 
	self setClientDvar("hud_enable", 0);
	self freezecontrols(true);
	self setClientDvar("cg_crosshairs", "0");
	self setClientDvar( "ui_hud_hardcore", "1" );
	self.DvarEditor["BG"]=CreateShaderRyan("CENTER","",0,0,30,300,(0,0,0),"gradient_center",1,1);
	self.DvarEditor["Bar"]=CreateShaderRyan("CENTER","",0,0,2,290,(1,1,1),"white",2,1);
	self.DvarEditor["Scroller"]=CreateShaderRyan("CENTER","",0,146,20,4,(1,1,1),"white",3,1);
	self.DvarEditor["Text"]=CreateValueString("default",1.5,"CENTER","",0,181,1,6,self.DvarScroll);
	if(value=="g_knockback" || value=="scr_war_score_kill")
	{
	self.DvarEditor["ValueBox"]=CreateShaderRyan("CENTER","",0,180,45,20,(0,0,0),"gradient_center",1,1);
	}
	else
	{
	self.DvarEditor["ValueBox"]=CreateShaderRyan("CENTER","",0,180,35,20,(0,0,0),"gradient_center",1,1);
	}
	if(value=="jump_height")
	{
	self.defaultvalue=39;
	self.DvarText = self CreateTextDvar("default", 1.7, "CENTER", "CENTER", -150, -180, (1,1,1), 5, 1);
	self.DvarText setText("Press [{+attack}]/[{+speed_throw}] to Change To Adjust Value\nPress [{+activate}] To Accept Value\nPress [{+melee}] To Cancel\nPress [{+smoke}] To Set Default Value\nDefault "+value+" Value: "+self.defaultvalue);
	}
	if(value=="g_gravity")
	{
	self.defaultvalue=800;
	self.DvarText = self CreateTextDvar("default", 1.7, "CENTER", "CENTER", -150, -180, (1,1,1), 5, 1);
	self.DvarText setText("Press [{+attack}]/[{+speed_throw}] to Change To Adjust Value\nPress [{+activate}] To Accept Value\nPress [{+melee}] To Cancel\nPress [{+smoke}] To Set Default Value\nDefault "+value+" Value: "+self.defaultvalue);
	}
	if(value=="g_speed")
	{
	self.defaultvalue=190;
	self.DvarText = self CreateTextDvar("default", 1.7, "CENTER", "CENTER", -150, -180, (1,1,1), 5, 1);
	self.DvarText setText("Press [{+attack}]/[{+speed_throw}] to Change To Adjust Value\nPress [{+activate}] To Accept Value\nPress [{+melee}] To Cancel\nPress [{+smoke}] To Set Default Value\nDefault "+value+" Value: "+self.defaultvalue);
	}
	if(value=="friction")
        {
        self.defaultvalue=5.5;
        self.DvarText = self CreateTextDvar("default", 1.7, "CENTER", "CENTER", -150, -180, (1,1,1), 5, 1);
        self.DvarText setText("Press [{+attack}]/[{+speed_throw}] to Change To Adjust Value\nPress [{+activate}] To Accept Value\nPress [{+melee}] To Cancel\nPress [{+smoke}] To Set Default Value\nDefault "+value+" Value: "+self.defaultvalue);
        }
		if(value=="timescale")
        {
        self.defaultvalue=1;
        self.DvarText = self CreateTextDvar("default", 1.7, "CENTER", "CENTER", -150, -180, (1,1,1), 5, 1);
        self.DvarText setText("Press [{+attack}]/[{+speed_throw}] to Change To Adjust Value\nPress [{+activate}] To Accept Value\nPress [{+melee}] To Cancel\nPress [{+smoke}] To Set Default Value\nDefault "+value+" Value: "+self.defaultvalue);
        }
        if(value=="player_meleeRange")
        {
        self.defaultvalue=64; 
        self.DvarText = self CreateTextDvar("default", 1.7, "CENTER", "CENTER", -150, -180, (1,1,1), 5, 1);
        self.DvarText setText("Press [{+attack}]/[{+speed_throw}] to Change To Adjust Value\nPress [{+activate}] To Accept Value\nPress [{+melee}] To Cancel\nPress [{+smoke}] To Set Default Value\nDefault "+value+" Value: "+self.defaultvalue);
        }
	if(value=="timescale")
	{
	self.defaultvalue=1;
	self.DvarText = self CreateTextDvar("default", 1.7, "CENTER", "CENTER", -150, -180, (1,1,1), 5, 1);
	self.DvarText setText("Press [{+attack}]/[{+speed_throw}] to Change To Adjust Value\nPress [{+activate}] To Accept Value\nPress [{+melee}] To Cancel\nPress [{+smoke}] To Set Default Value\nDefault "+value+" Value: "+self.defaultvalue);
	}
	if(value=="scr_war_score_kill")
	{
	self.defaultvalue=1;
	self.DvarText = self CreateTextDvar("default", 1.7, "CENTER", "CENTER", -150, -180, (1,1,1), 5, 1);
	self.DvarText setText("Press [{+attack}]/[{+speed_throw}] to Change To Adjust Value\nPress [{+activate}] To Accept Value\nPress [{+melee}] To Cancel\nPress [{+smoke}] To Set Default Value\nDefault "+value+" Value: "+self.defaultvalue+"\nPress [{+Frag}] To Set 5k XP");
	self.editxp5k=true;
	}
	if(value=="g_knockback")
	{
	self.defaultvalue=1000;
	self.DvarText = self CreateTextDvar("default", 1.7, "CENTER", "CENTER", -150, -180, (1,1,1), 5, 1);
	self.DvarText setText("Press [{+attack}]/[{+speed_throw}] to Change To Adjust Value\nPress [{+activate}] To Accept Value\nPress [{+melee}] To Cancel\nPress [{+smoke}] To Set Default Value\nDefault "+value+" Value: "+self.defaultvalue);
	}
	self thread DestroyHudElemsOnDeath( self.DvarEditor["BG"], self.DvarEditor["Bar"], self.DvarEditor["Scroller"], self.DvarEditor["ValueBox"] );
	self thread DestroyHudElemsOnDeath( self.DvarText, self.DvarEditor["Text"] );
	self.DvarScroll=0;
	for(;;)
	{
		if(value=="g_knockback" || value=="scr_dm_score_kill")
		{
		self.DvarEditor["Scroller"].y +=(2.9*self AdsButtonPressed());
		self.DvarEditor["Scroller"].y -=(2.9*self AttackButtonPressed());
		self.DvarScroll -=(100*self AdsButtonPressed());
		self.DvarScroll +=(10000*self AttackButtonPressed());
		if(self.DvarScroll>1000000)self.DvarScroll=0;
		if(self.DvarScroll<0)self.DvarScroll=1000000;
		}
		else if(value=="timescale")
                {
                self.DvarEditor["Scroller"].y +=(5.8*self AdsButtonPressed());
                self.DvarEditor["Scroller"].y -=(5.8*self AttackButtonPressed());
                self.DvarScroll -=(0.1*self AdsButtonPressed());
                self.DvarScroll +=(0.1*self AttackButtonPressed());
                if(self.DvarScroll>5)self.DvarScroll=0;
                if(self.DvarScroll<0)self.DvarScroll=5;
                }
                else if(value=="friction")
                {
                self.DvarEditor["Scroller"].y +=(3.4*self AdsButtonPressed());
                self.DvarEditor["Scroller"].y -=(3.4*self AttackButtonPressed());
                self.DvarScroll -=(0.2*self AdsButtonPressed());
                self.DvarScroll +=(0.2*self AttackButtonPressed());
                if(self.DvarScroll>10)self.DvarScroll=0;
                if(self.DvarScroll<0)self.DvarScroll=10;
                }
		else
		{
		self.DvarEditor["Scroller"].y +=(2.9*self AdsButtonPressed());
		self.DvarEditor["Scroller"].y -=(2.9*self AttackButtonPressed());
		self.DvarScroll -=(10*self AdsButtonPressed());
		self.DvarScroll +=(10*self AttackButtonPressed());
		if(self.DvarScroll>1000)self.DvarScroll=0;
		if(self.DvarScroll<0)self.DvarScroll=1000;
		}
	
		if(self.DvarEditor["Scroller"].y>146)self.DvarEditor["Scroller"].y=-146;
		if(self.DvarEditor["Scroller"].y<-146)self.DvarEditor["Scroller"].y=146;
		if(self UseButtonPressed())
		{
			self.lockMenu=false;
			self.DvarEditor["Bar"] destroy();
			self.DvarText destroy();
			self.DvarEditor["Scroller"] destroy();
			self.DvarEditor["Text"] destroy();
			self.DvarEditor["BG"] destroy();
			self.DvarEditor["ValueBox"] destroy();
			setDvar(Value,self.DvarScroll);
			if(value=="scr_xpscale")
			{
			level.xpScale = self.DvarScroll;
			self iPrintln("^3"+Value+" Has Been Set To x"+self.DvarScroll+" The Original");
			}
			else
			{
			self iPrintln("^3"+Value+" Has Been Set To: "+self.DvarScroll);
			}
			wait .2;
			self setClientDvar( "r_blur", "0" ); 
			self setClientDvar( "sc_blur", "2" ); 
			self freezecontrols(false);
			self setClientDvar("hud_enable", "1");
			self setClientDvar( "ui_hud_hardcore", "0" );
			self setClientDvar("cg_crosshairs", "1");
			self notify("StopDvarEditor");
		}
		if(self FragButtonPressed() && self.editxp5k==true)
		{
			self.DvarEditor["Bar"] destroy();
			self.DvarText destroy();
			self.DvarEditor["Scroller"] destroy();
			self.DvarEditor["Text"] destroy();
			self.DvarEditor["BG"] destroy();
			self.DvarEditor["ValueBox"] destroy();
			setDvar("scr_war_score_kill","500");
			level.xpScale = 500;
			self iPrintln("^3scr_xpscale Has Been Set To: x500 The Original");
			wait .2;
			self setClientDvar( "r_blur", "0" ); 
			self setClientDvar( "sc_blur", "2" ); 
			self freezecontrols(false);
			self setClientDvar("hud_enable", "1");
			self setClientDvar( "ui_hud_hardcore", "0" );
			self setClientDvar("cg_crosshairs", "1");
			self notify("StopDvarEditor");
		}
		if(self SecondaryOffHandButtonPressed())
		{
			self.lockMenu=false;
			self.DvarEditor["Bar"] destroy();
			self.DvarText destroy();
			self.DvarEditor["Scroller"] destroy();
			self.DvarEditor["Text"] destroy();
			self.DvarEditor["BG"] destroy();
			self.DvarEditor["ValueBox"] destroy();
			setDvar(Value,self.defaultvalue);
			if(value=="scr_war_score_kill")level.xpScale = self.defaultvalue;
			self iPrintln("^3"+Value+" Has Been Set To: "+self.defaultvalue);
			wait .2;
			self setClientDvar( "r_blur", "0" ); 
			self setClientDvar( "sc_blur", "2" ); 
			self freezecontrols(false);
			self setClientDvar("hud_enable", "1");
			self setClientDvar( "ui_hud_hardcore", "0" );
			self setClientDvar("cg_crosshairs", "1");
			self notify("StopDvarEditor");
		}
		if(self MeleeButtonPressed())
		{
			self.DvarEditor["Bar"] destroy();
			self.DvarEditor["Scroller"] destroy();
			self.DvarEditor["Text"] destroy();
			self.DvarText destroy();
			self.DvarEditor["BG"] destroy();
			self.DvarEditor["ValueBox"] destroy();
			self setClientDvar( "r_blur", "0" ); 
			self setClientDvar( "sc_blur", "2" ); 
			self freezecontrols(false);
			self setClientDvar("hud_enable", "1");
			self setClientDvar( "ui_hud_hardcore", "0" );
			self setClientDvar("cg_crosshairs", "1");
			self notify("StopDvarEditor");
		}
		self.DvarEditor["Text"] setValue(self.DvarScroll);
		wait .01;
	}
}
createValue(font,fontscale,align,relative,x,y,alpha,sort,value)
{
	hudValue = createFontString(font,fontscale,self);
	hudValue setPoint(align,relative,x,y);
	hudValue.alpha = alpha;
	hudValue.sort = sort;
	hudValue setValue(value);
	thread destroyElemOnDeath(hudValue);
	return hudValue;
}
CreateValueString(font,fontscale,align,relative,x,y,alpha,sort,text)
{
 self.CreateText=createFontString(font,fontscale);
 self.CreateText setPoint(align,relative,x,y);
 self.CreateText.alpha=alpha;
 self.CreateText.sort=sort;
 self.CreateText setValue(text);
 return self.CreateText;
}
CreateShaderRyan(Align,Relative,X,Y,Width,Height,Colour,Shader,Sort,Alpha)
{
 CShader=newClientHudElem(self);
 CShader.children=[];
 CShader.elemType="bar";
 CShader.sort=Sort;
 CShader.color=Colour;
 CShader.alpha=Alpha;
 CShader setParent(level.uiParent);
 CShader setShader(Shader,Width,Height);
 CShader setPoint(Align,Relative,X,Y);
 return CShader;
}
CreateTextDvar(font, fontScale, align, relative, x, y, sort, alpha, text)
{
  textElem = self createFontString(font, fontScale, self);
   textElem setPoint(align, relative, x, y);
   textElem.sort = sort;
    textElem.alpha = alpha;
  textElem iPrintln(text);
  return textElem;
}
DestroyHudElemsOnDeath(elem1,elem2,elem3,elem4)
{
 self waittill("death");
 
 if(isDefined(elem1))
  elem1 destroy();
  
 if(isDefined(elem2))
  elem2 destroy();
  
 if(isDefined(elem3))
  elem3 destroy();
  
 if(isDefined(elem4))
  elem4 destroy();
}
createRectangle(align,relative,x,y,width,height,color,shader,sort,alpha)
{
        barElemBG = newClientHudElem( self );
        barElemBG.elemType = "bar";
        barElemBG.width = width;
        barElemBG.height = height;
        barElemBG.align = align;
        barElemBG.relative = relative;
        barElemBG.xOffset = 0;
        barElemBG.yOffset = 0;
        barElemBG.children = [];
        barElemBG.sort = sort;
        barElemBG.color = color;
        barElemBG.alpha = alpha;
        barElemBG setParent( level.uiParent );
        barElemBG setShader( shader, width , height );
        barElemBG.hidden = false;
        barElemBG setPoint(align,relative,x,y);
        return barElemBG;
}
setPointn(horza,verta,textx,texty,x,y)
{
	self.horzAlign = horza;
	self.vertAlign = verta;
	self.alignX = textx;
	self.alignY = texty;
	self.x = x;
	self.y = y;
	return self;
}
testthis(){
self thread colorEditor(self.Menu["Shader"]["Curs"]);
}
testthis1(){
self thread colorEditor(self.Menu["Shader"]["backround"]);
}
testthis2(){
self thread colorEditor(self.Menu["Text"]);
}