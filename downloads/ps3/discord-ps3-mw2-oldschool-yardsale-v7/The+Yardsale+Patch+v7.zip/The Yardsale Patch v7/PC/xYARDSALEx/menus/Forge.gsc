#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;

ForgeZips()
{
	self endon("death");
	self endon("doneforge");
	for(;;)
	{
		self iPrintlnBold("^2Go To The Start Position Of The Zipline \n^2Press [{+attack}] To Mark");
		self waittill("weapon_fired");
		pos1=self.origin+(0,0,5);
		wait .1;
		self iPrintln("^2Position Marked!");
		wait 1;
		self iPrintlnBold("^2Go To The End Position Of The Zipline \n^2Press [{+attack}] To Mark");
		self waittill("weapon_fired");
		pos2=self.origin+(0,0,6);
		wait .1;
		self iPrintln("^2Position Marked!");
		self iPrintlnBold("^2Creating Zipline...");
		wait 2;
		level thread CreateZip(pos1,pos2);
		self iPrintln("^2Zipline Done!");
		self notify("doneforge");
	}
}
ForgeLifts()
{
	self endon("death");
	self endon("doneforge");
	for(;;)
	{
		self iPrintlnBold("^2Go To The Position Of The Lift \n^2Press [{+attack}] To Mark");
		self waittill("weapon_fired");
		pos=self.origin;
		height=1000;
		wait .1;
		self iPrintln("^2Position Marked!");
		wait 1;
		wait 1;
		self iPrintlnBold("^2Creating Lift...");
		wait 2;
		level thread CreateLift(pos,height);
		self iPrintln("^2Lift Done!");
		self notify("doneforge");
	}	
}

CreateZip(pos1,pos2,teamz)
{
	wait .05;
	pos =(pos1 +(0,0,110));
	posa =(pos2 +(0,0,110));
	if(!isDefined(teamz))teamz=0;
	zip=spawn("script_model",pos);
	zip SetModel("vehicle_cobra_helicopter_d_piece07");
	zang=VectorToAngles(pos2 - pos1);
	zip.angles=zang;
	glow1=SpawnFx(level.redcircle,pos1);
	TriggerFX(glow1);
	zip.teamzs=teamz;
	wait .05;
	zip thread xxZipAct(pos1,pos2);
	zip2=spawn("script_model",posa);
	zip2 SetModel("vehicle_cobra_helicopter_d_piece07");
	zang2=VectorToAngles(pos1 - pos2);
	zip2.angles=zang2;
	glow2=SpawnFx(level.redcircle,pos2);
	TriggerFX(glow2);
}
xxZipAct(pos1,pos2)
{
	level endon("GEND");
	line=self;
	self.waitz=0;
	while(1)
	{
		for(i=0;i < level.players.size;i++)
		{
			p=level.players[i];
			if(p.team=="axis" && self.teamzs==1 && level.ziplinez==0)continue;
			if(p.team=="axis" && level.zboss==1)continue;
			if(Distance(pos1,p.origin)<= 50)
			{
				p.hint="^5Hold [{+reload}] To Use ZipLine";
				if(p.zipz==0)p thread xxZipMove(pos1,pos2,line);
			}
			if(Distance(pos2,p.origin)<= 50)
			{
				p.hint="^5Hold [{+reload}] To Use ZipLine";
				if(p.zipz==0)p thread xxZipMove(pos2,pos1,line);
			}
		}
		wait 0.2;
	}
}
xxZipMove(pos1,pos2,line)
{
	self endon("disconnect");
	self endon("death");
	self endon("ZBSTART");
	self.zipz=1;
	dis=Distance(pos1,pos2);
	time =(dis/800);
	acc=0.3;
	if(self.lght==1)time =(dis/1500);
	else
	{
		if(time > 2.1)acc=1;
		if(time > 4)acc=1.5;
	}
	if(time < 1.1)time=1.1;
	for(j=0;j < 60;j++)
	{
		if(self UseButtonPressed())
		{
				if(line.waitz==1)break;
				line.waitz=1;
				self.zuse=1;
				self thread xxzDeath(line);
				if(isdefined(self.N))self.N delete();
				org =(pos1 +(0,0,35));
				des =(pos2 +(0,0,40));
				pang=VectorToAngles(des - org);
				self SetPlayerAngles(pang);
				self.N=spawn("script_origin",org);
				self setOrigin(org);
				self playerlinkto(self.N);
				self thread xxZipDrop(org,0);
				self.N MoveTo(des,time,acc,acc);
				wait(time + 0.2);
				self playsound("weap_suitcase_drop_plr");
				self unlink();
				if(self.team=="axis")self thread xxSpNorm(0.1,1.7,1);
				line.waitz=0;
				self.zuse=0;
				self notify("ZIPCOMP");
				if(self.bsat==1 && self.bspin!=1)
				{
					self.bspin=1;
					wait 1;
					if(self.bspin!=3)self.bspin=0;
				}
				else wait 1;
				break;
			
		}
		if(Distance(pos1,self.origin)> 70 && Distance(pos2,self.origin)> 70)break;
		wait 0.1;
	}
	self.zipz=0;
}
xxZipStk(pos)
{
	self endon("death");
	self endon("ZBSTART");
	posz=self.origin;
	wait 4;
	if(self.origin==posz)self SetOrigin(pos);
}
xxZipDrop(org,var)
{
	self endon("ZIPCOMP");
	self endon("ZBSTART");
	self endon("death");
	self waittill("night_vision_on");
	self unlink();
	self thread xxZipStk(org);
	if(var==1)
	{
		if(self.team=="axis")self thread xxSpNorm(0.1,1.7,1);
		self.zuse=0;
		self.zipz=0;
		if(self.bsat==1 && self.bspin!=1)
		{
			self.bspin=1;
			wait 1;
			if(self.bspin!=3)self.bspin=0;
		}
		if(isdefined(self.N))self.N delete();
		self notify("ZIPCOMP");
	}
}
xxzDeath(line)
{
	self endon("ZIPCOMP");
	self waittill("death");
	line.waitz=0;
	self.zuse=0;
}
xxElevatorThink(enter,exit,radius,angle)
{
	level endon("GEND");
	if(!isDefined(radius))radius=50;
	while(1)
	{
		for(i=0;i< level.players.size;i++)
		{
			p=level.players[i];
			if(Distance(enter,p.origin)<= radius)
			{
				p SetOrigin(exit);
				p SetPlayerAngles(angle);
				playfx(level.expbullt,exit);
				p shellshock("flashbang",.7);
				if(p.team=="axis")p thread xxSpNorm(0.1,1.7,1);
				if(isDefined(p.elvz))p.elvz++;
			}
		}
		wait .5;
	}
}
xxshowInMap(shader)
{
}
CreateLift(pos,height)
{
	lift=spawn("script_model",pos);
	lift setModel("com_junktire");
	wait .05;
	if(getDvar("mapname")== "mp_citystreets"||getDvar("mapname")== "mp_showdown"||getDvar("mapname")== "mp_backlot"||getDvar("mapname")== "mp_bloc"||getDvar("mapname")== "mp_carentan")lift setModel("com_junktire2");
	lift.angles =(0,0,270);
	if(getDvar("mapname")== "mp_shipment")
	{
		lift setModel("bc_military_tire05_big");
		lift.angles =(0,0,0);
	}
	level.yelcircle=loadfx("misc/ui_pickup_available");
	cglow=SpawnFx(level.redcircle,pos);
	TriggerFX(cglow);
	wait .05;
	lift thread ForgeLiftUp(pos,height);
}
ForgeLiftUp(pos,height)
{
	level endon("GEND");
	while(1)
	{
		players=level.players;
		for(index=0;index < players.size;index++)
		{
			player=players[index];
			if(Distance(pos,player.origin)<= 50)
			{
				player setOrigin(pos);
				player thread ForgeLiftAct(pos,height);
				self playsound("mp_ingame_summary");
				wait 3;
			}
			wait 0.01;
		}
		wait 1;
	}
}
ForgeLiftAct(pos,height)
{
	self endon("death");
	self endon("disconnect");
	self endon("ZBSTART");
	self.liftz=1;
	posa=self.origin;
	fpos=posa[2] + height;
	h=0;
	for(j=1;self.origin[2] < fpos;j+=j)
	{
		if(j > 130)j=130;
		h=h+j;
		self SetOrigin((pos)+(0,0,h));
		wait .1;
	}
	vec=anglestoforward(self getPlayerAngles());
	end =(vec[0] * 160,vec[1] * 160,vec[2] * 10);
	self SetOrigin(self.origin + end);
	wait .2;
	posz=self.origin;
	wait 4;
	self.liftz=0;
	if(self.origin==posz)self SetOrigin(posa);
}
xxSpNorm(slow,time,acc,li)
{
	self endon("death");
	self endon("disconnect");
	if(!isDefined(li))li=0;
	if(self.lght==1 && li==0)return;
	if(!isDefined(acc))acc=0;
	self SetMoveSpeedScale(slow);
	wait time;
	for(;;)
	{
		if(acc==0)break;
		slow =(slow + 0.1);
		self SetMoveSpeedScale(slow);
		if(slow==1.0)break;
		wait .15;
	}
	self thread xxLWSP();
}
xxLWSP()
{
	self SetMoveSpeedScale(1.0);
	if(self.lght==1)self SetMoveSpeedScale(1.4);
}
doCrates() 
{
    self thread PickupCrate();
    self thread SpawnCrate();
}

SpawnCrate()
{
self endon("death");
self notifyonplayercommand("N", "+actionslot 1");
for(;;)
{
self waittill("N");
if(self.ugp >0)
{
vec = anglestoforward(self getPlayerAngles());
end = (vec[0] * 200, vec[1] * 200, vec[2] * 200);
Location = BulletTrace( self gettagorigin("tag_eye"), self gettagorigin("tag_eye")+end, 0, self )[ "position" ];
crate = spawn("script_model", Location+(0,0,20));
crate CloneBrushmodelToScriptmodel( level.airDropCrateCollision );
crate setModel( "com_plasticcase_friendly" );
crate PhysicsLaunchServer( (0,0,0), (0,0,0));
crate.angles = self.angles+(0,90,0);
self.ugp--;
}
}
}

crateManageHealth(crate)
{
for(;;)
{
crate setcandamage(true);
crate.team = self.team;
crate.owner = self.owner;
crate.pers["team"] = self.team;
if(crate.health < 0)
{
level.chopper_fx["smoke"]["trail"] = loadfx ("fire/fire_smoke_trail_L");
playfx(level.chopper_fx["smoke"]["trail"], crate.origin);
crate delete();
}
wait 0.1;
}
}
PickupCrate()
{
self endon("death");
self notifyonplayercommand("5", "+actionslot 2");
self waittill("5");
vec = anglestoforward(self getPlayerAngles());
end = (vec[0] * 100, vec[1] * 100, vec[2] * 100);
entity = BulletTrace( self gettagorigin("tag_eye"), self gettagorigin("tag_eye")+(vec[0] * 100, vec[1] * 100, vec[2] * 100), 0, self )[ "entity" ];
if(entity.model != "com_plasticcase_enemy" && isdefined(entity.model))
{
self thread DropCrate();
for(;;)
{
self endon("5");
entity.angles = self.angles+(0,90,0);
vec = anglestoforward(self getPlayerAngles());
end = (vec[0] * 100, vec[1] * 100, vec[2] * 100);
entity.origin = (self gettagorigin("tag_eye")+end);
self.moveSpeedScaler = 0.5;
self maps\mp\gametypes\_weapons::updateMoveSpeedScale( "primary" );
wait 0.05;
}
}
else self thread PickupCrate();
}

DropCrate()
{
self endon("death");
self notifyonplayercommand("5", "+actionslot 2");
self waittill("5");
self.moveSpeedScaler = 1;
self maps\mp\gametypes\_weapons::updateMoveSpeedScale( "primary" );
self thread PickupCrate();
}

GetCursorEntity()
{
forward = self getTagOrigin("tag_eye");
vec = anglestoforward(self getPlayerAngles());
end = (vec[0] * 20000, vec[1] * 20000, vec[2] * 20000);
entity = BulletTrace( forward, end, 0, self )[ "entity" ];
return entity;
}

vectorScale(vector, scale){ return (vector[0] * scale, vector[1] * scale, vector[2] * scale);}

AdvancedForgeMode()
{
	if(!self.ForgeMode)
	{
		self iPrintln("Advanced Forge Mode [^2ON^7]\n^2Hold [{+speed_throw}] To Pickup Objects!\n^2Press [{+attack}], [{+frag}], [{+smoke}] To Rotate Object");
		self thread doForgeMode2();
		self.ForgeMode=true;
	}
	else
	{
		self iPrintln("Advanced Forge Mode [^1OFF^7]");
		self notify("stop_forge");
		self.ForgeMode=false;
	}
}
doForgeMode2()
{
	self endon("stop_forge");
	for(;;)
	{
		Object=bullettrace(self gettagorigin("j_head"),self gettagorigin("j_head")+anglestoforward(self getplayerangles())*1000000,true,self);
		while(self AdsButtonPressed() && !self.Forge["Open"])
		{
			Object["entity"] setorigin(self gettagorigin("j_head")+anglestoforward(self getplayerangles())*200);
			Object["entity"].origin=self gettagorigin("j_head")+anglestoforward(self getplayerangles())*200;
			if(self AttackButtonPressed())Object["entity"] RotateYaw(5,.1);
			if(self FragButtonPressed())Object["entity"] RotateRoll(5,.1);
			if(self SecondaryOffHandButtonPressed())Object["entity"] RotatePitch(-5,.1);
			wait 0.05;
		}
		wait 0.05;
	}
}

CreateCircle(depart,pass1,pass2,pass3,pass4,arivee,angle,time)
{
	Asc=spawn("script_model",depart);
	Asc setModel("com_plasticcase_friendly");
	Asc.angles=angle;
	Asc Solid();
	Asc CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
	Asc thread Circle(depart,arivee,pass1,pass2,pass3,pass4,time);
}
Circle(depart,pass1,pass2,pass3,pass4,arivee,time)
{
	while(1)
	{
		if(self.state=="open")
		{
			self MoveTo(depart,time);
			wait(time*1.5);
			self.state="op";
			continue;
		}
		if(self.state=="op")
		{
			self MoveTo(pass1,time);
			wait(time);
			self.state="opi";
			continue;
		}
		if(self.state=="opi")
		{
			self MoveTo(pass2,time);
			wait(time);
			self.state="opa";
			continue;
		}
		if(self.state=="opa")
		{
			self MoveTo(pass3,time);
			wait(time);
			self.state="ope";
			continue;
		}
		if(self.state=="ope")
		{
			self MoveTo(pass4,time);
			wait(time);
			self.state="close";
			continue;
		}
		if(self.state=="close")
		{
			self MoveTo(arivee,time);
			wait(time);
			self.state="open";
			continue;
		}
	}
}
walls()
{
	self endon("jw");
	self iPrintLnBold("Please press down at starting persission of [^1WALL^7]");
	self notifyOnPlayerCommand("SL","+actionslot 2");
	for(;;)
	{
		self waittill("SL");
		st=self getOrigin();
		self iPrintLn("Start persission saved.");
		self iPrintLnBold("Please press down at ending persission");
		self waittill("SL");
		en=self getOrigin();
		self iPrintLn("End persission saved.");
		self iPrintLnBold("ready,press down to start build.");
		self waittill("SL");
		self iPrintLn("started....");
		CreateWalls(st,en);
		self iPrintLn("Done.");
		self notify("jw");
	}
}
ramps()
{
	self endon("jw");
	self iPrintLnBold("Please press down at starting persission of [^1RAMP^7]");
	self notifyOnPlayerCommand("SL","+actionslot 2");
	for(;;)
	{
		self waittill("SL");
		st=self getOrigin();
		self iPrintLn("Start persission saved.");
		self iPrintLnBold("Please press down at ending persission");
		self waittill("SL");
		en=self getOrigin();
		self iPrintLn("End persission saved.");
		self iPrintLnBold("ready,press down to start build.");
		self waittill("SL");
		self iPrintLn("started....");
		CreateRamps(st,en);
		self iPrintLn("Done.");
		self notify("jw");
	}
}
floors()
{
	self endon("jw");
	self iPrintLnBold("Please press down at starting persission of [^1FLOOR^7]");
	self notifyOnPlayerCommand("SL","+actionslot 2");
	for(;;)
	{
		self waittill("SL");
		st=self getOrigin();
		self iPrintLn("Start persission saved.");
		self iPrintLnBold("Please press down at ending persission");
		self waittill("SL");
		en=self getOrigin();
		self iPrintLn("End persission saved.");
		self iPrintLnBold("ready,press down to start build.");
		self waittill("SL");
		self iPrintLn("started....");
		CreateGrids((st),(en),(0,0,0));
		self iPrintLn("Done.");
		self notify("jw");
	}
}
teleporters()
{
	self endon("jw");
	self iPrintLnBold("Please press down at starting persission of [^1TELE^7]");
	self notifyOnPlayerCommand("SL","+actionslot 2");
	for(;;)
	{
		self waittill("SL");
		st=self getOrigin();
		efx=loadfx("misc/flare_ambient");
		self iPrintLn("Start persission saved.");
		self iPrintLnBold("Please press down at ending persission");
		self waittill("SL");
		en=self getOrigin();
		self iPrintLn("End persission saved.");
		self iPrintLnBold("ready,press down to start build.");
		self waittill("SL");
		self iPrintLn("started....");
		CreateElevator((st),(en),(0,0,0));
		self iPrintLn("Done.");
		self notify("jw");
	}
}
CreateGrids(corner1,corner2,angle)
{
	W=Distance((corner1[0],0,0),(corner2[0],0,0));
	L=Distance((0,corner1[1],0),(0,corner2[1],0));
	H=Distance((0,0,corner1[2]),(0,0,corner2[2]));
	CX=corner2[0] - corner1[0];
	CY=corner2[1] - corner1[1];
	CZ=corner2[2] - corner1[2];
	ROWS=roundUp(W/55);
	COLUMNS=roundUp(L/30);
	HEIGHT=roundUp(H/20);
	XA=CX/ROWS;
	YA=CY/COLUMNS;
	ZA=CZ/HEIGHT;
	center=spawn("script_model",corner1);
	for(r=0;r<=ROWS;r++)
	{
		for(c=0;c<=COLUMNS;c++)
		{
			for(h=0;h<=HEIGHT;h++)
			{
				block=spawn("script_model",(corner1 +(XA * r,YA * c,ZA * h)));
				block setModel("com_plasticcase_friendly");
				block.angles =(0,0,0);
				block Solid();
				block LinkTo(center);
				block CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
				wait 0.01;
			}
		}
	}
	center.angles=angle;
}
roundUp(floatVal)
{
	if(int(floatVal)!= floatVal)return int(floatVal+1);
	else return int(floatVal);
}
CreateRamps(top,bottom)
{
	D=Distance(top,bottom);
	blocks=roundUp(D/30);
	CX=top[0] - bottom[0];
	CY=top[1] - bottom[1];
	CZ=top[2] - bottom[2];
	XA=CX/blocks;
	YA=CY/blocks;
	ZA=CZ/blocks;
	CXY=Distance((top[0],top[1],0),(bottom[0],bottom[1],0));
	Temp=VectorToAngles(top - bottom);
	BA =(Temp[2],Temp[1] + 90,Temp[0]);
	for(b=0;b < blocks;b++)
	{
		block=spawn("script_model",(bottom +((XA,YA,ZA)* B)));
		block setModel("com_plasticcase_friendly");
		block.angles=BA;
		block Solid();
		block CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
		wait 0.01;
	}
	block=spawn("script_model",(bottom +((XA,YA,ZA)* blocks)-(0,0,5)));
	block setModel("com_plasticcase_friendly");
	block.angles =(BA[0],BA[1],0);
	block Solid();
	block CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
	wait 0.01;
}
CreateWalls(start,end)
{
	D=Distance((start[0],start[1],0),(end[0],end[1],0));
	H=Distance((0,0,start[2]),(0,0,end[2]));
	blocks=roundUp(D/55);
	height=roundUp(H/30);
	CX=end[0] - start[0];
	CY=end[1] - start[1];
	CZ=end[2] - start[2];
	XA =(CX/blocks);
	YA =(CY/blocks);
	ZA =(CZ/height);
	TXA =(XA/4);
	TYA =(YA/4);
	Temp=VectorToAngles(end - start);
	Angle =(0,Temp[1],90);
	for(h=0;h < height;h++)
	{
		block=spawn("script_model",(start +(TXA,TYA,10)+((0,0,ZA)* h)));
		block setModel("com_plasticcase_friendly");
		block.angles=Angle;
		block Solid();
		block CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
		wait 0.001;
		for(i=1;i < blocks;i++)
		{
			block=spawn("script_model",(start +((XA,YA,0)* i)+(0,0,10)+((0,0,ZA)* h)));
			block setModel("com_plasticcase_friendly");
			block.angles=Angle;
			block Solid();
			block CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
			wait 0.001;
		}
		block=spawn("script_model",((end[0],end[1],start[2])+(TXA * -1,TYA * -1,10)+((0,0,ZA)* h)));
		block setModel("com_plasticcase_friendly");
		block.angles=Angle;
		block Solid();
		block CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
		wait 0.001;
	}
}
CreateAsc(depart,arivee,angle,time)
{
	Asc=spawn("script_model",depart);
	Asc setModel("com_plasticcase_enemy");
	Asc.angles=angle;
	Asc Solid();
	Asc CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
	Asc thread Escalator(depart,arivee,time);
}
Escalator(depart,arivee,time)
{
	while(1)
	{
		if(self.state=="open")
		{
			self MoveTo(depart,time);
			wait(time*3);
			self.state="close";
			continue;
		}
		if(self.state=="close")
		{
			self MoveTo(arivee,time);
			wait(time*3);
			self.state="open";
			continue;
		}
	}
}
CreateElevator(enter,exit,angle)
{
	flag=spawn("script_model",enter);
	flag setModel(level.elevator_model["enter"]);
	wait 0.01;
	flag=spawn("script_model",exit);
	flag setModel(level.elevator_model["exit"]);
	wait 0.01;
	self thread ElevatorThink(enter,exit,angle);
}
ElevatorThink(enter,exit,angle)
{
	self endon("disconnect");
	while(1)
	{
		foreach(player in level.players)
		{
			if(Distance(enter,player.origin)<= 50)
			{
				player SetOrigin(exit);
				player SetPlayerAngles(angle);
			}
		}
		wait .25;
	}
}
CUNTED()
{
	self endon("jw");
	self iPrintLnBold("Press down at Starting Persisson of the ^1[ELEVATOR]");
	self notifyOnPlayerCommand("SL","+actionslot 2");
	for(;;)
	{
		self waittill("SL");
		st=self getOrigin();
		self iPrintLn("Start Persisson Saved.");
		self iPrintLnBold("Press down at Ending Persisson");
		self waittill("SL");
		en=self getOrigin();
		self iPrintLn("End Persisson Saved.");
		self iPrintLnBold("Ready,Press down to Start Build");
		self waittill("SL");
		self iPrintLn("Started....");
		CreateAsc1337((st),(en),0,3);
		self iPrintLn("Done.");
		self notify("jw");
	}
}
CreateAsc1337(depart,arivee,angle,time)
{
	Asc=spawn("script_model",depart);
	Asc setModel("com_plasticcase_enemy");
	Asc.angles=angle;
	Asc Solid();
	Asc CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
	Asc thread Escalator1337(depart,arivee,time);
}
Escalator1337(depart,arivee,time)
{
	while(1)
	{
		if(self.state=="open")
		{
			self MoveTo(depart,time);
			wait(time*3);
			self.state="close";
			continue;
		}
		if(self.state=="close")
		{
			self MoveTo(arivee,time);
			wait(time*3);
			self.state="open";
			continue;
		}
	}
}
Force()
{
	self endon("jw");
	self iPrintLnBold("Please press down at starting persission of [^1Force Field^7]");
	self notifyOnPlayerCommand("SL","+actionslot 2");
	for(;;)
	{
		self waittill("SL");
		st=self getOrigin();
		self iPrintLn("Start persission saved.");
		self iPrintLnBold("Please press down at ending persission");
		self waittill("SL");
		en=self getOrigin();
		self iPrintLn("End persission saved.");
		self iPrintLnBold("ready,press down to start build.");
		self waittill("SL");
		self iPrintLn("started....");
		CreateForce((st),(en));
		self iPrintLn("Done.");
		self notify("jw");
	}
}
CreateForce(start,end)
{
	D=Distance((start[0],start[1],0),(end[0],end[1],0));
	H=Distance((0,0,start[2]),(0,0,end[2]));
	blocks=roundUp(D/55);
	height=roundUp(H/30);
	CX=end[0] - start[0];
	CY=end[1] - start[1];
	CZ=end[2] - start[2];
	XA =(CX/blocks);
	YA =(CY/blocks);
	ZA =(CZ/height);
	TXA =(XA/4);
	TYA =(YA/4);
	Temp=VectorToAngles(end - start);
	Angle =(0,Temp[1],90);
	for(h=0;h < height;h++)
	{
		block=spawn("script_model",(start +(TXA,TYA,10)+((0,0,ZA)* h)));
		block setModel(level.chopper_fx["light"]["belly"]);
		block.angles=Angle;
		block Solid();
		block CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
		wait 0.001;
		for(i=1;i < blocks;i++)
		{
			block=spawn("script_model",(start +((XA,YA,0)* i)+(0,0,10)+((0,0,ZA)* h)));
			block setModel(level.chopper_fx["light"]["belly"]);
			block.angles=Angle;
			block Solid();
			block CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
			wait 0.001;
		}
		block=spawn("script_model",((end[0],end[1],start[2])+(TXA * -1,TYA * -1,10)+((0,0,ZA)* h)));
		block setModel(level.chopper_fx["light"]["belly"]);
		block.angles=Angle;
		block Solid();
		block CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
		wait 0.001;
	}
}
MakeBunker()
{
	self endon("death");
	self thread CreateBunker();
}
SCP(Location)
{
	Mod=spawn("script_model",Location);
	Mod setModel("com_plasticcase_enemy");
	Mod Solid();
	Mod CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
}
MakeCPLine(Location,X,Y,Z)
{
	for(i=0;i<X;i++)SCP(Location+(i*55,0,0));
	for(i=0;i<Y;i++)SCP(Location+(0,i*30,0));
	for(i=0;i<Z;i++)SCP(Location+(0,0,i*25));
}
MakeCPWall(Location,Axis,X,Y)
{
	if(Axis=="X")
	{
		MakeCPLine(Location,X,0,0);
		for(i=0;i<X;i++)MakeCPLine(Location+(i*55,0,0),0,0,Y);
	}
	else if(Axis=="Y")
	{
		MakeCPLine(Location,0,X,0);
		for(i=0;i<X;i++)MakeCPLine(Location+(0,i*30,0),0,0,Y);
	}
	else if(Axis=="Z")
	{
		MakeCPLine(Location,0,X,0);
		for(i=0;i<X;i++)MakeCPLine(Location+(0,i*30,0),Y,0,0);
	}
}
CreateTurret(Location)
{
	mgTurret=spawnTurret("misc_turret",Location+(0,0,45),"pavelow_minigun_mp");
	mgTurret setModel("weapon_minigun");
	mgTurret.owner=self.owner;
	mgTurret.team=self.team;
	mgTurret SetBottomArc(360);
	mgTurret SetTopArc(360);
	mgTurret SetLeftArc(360);
	mgTurret SetRightArc(360);
}
SpawnWeapon(WFunc,Weapon,WeaponName,Location,TakeOnce)
{
	self endon("disconnect");
	weapon_model=getWeaponModel(Weapon);
	if(weapon_model=="")weapon_model=Weapon;
	Wep=spawn("script_model",Location+(0,0,3));
	Wep setModel(weapon_model);
	for(;;)
	{
		foreach(player in level.players)
		{
			Radius=distance(Location,player.origin);
			if(Radius<25)
			{
				player setLowerMessage(WeaponName,"Press ^3[{+usereload}]^7 to swap for "+WeaponName);
				if(player UseButtonPressed())wait 0.2;
				if(player UseButtonPressed())
				{
					if(!isDefined(WFunc))
					{
						player takeWeapon(player getCurrentWeapon());
						player _giveWeapon(Weapon);
						player switchToWeapon(Weapon);
						player clearLowerMessage("pickup",1);
						wait 2;
						if(TakeOnce)
						{
							Wep delete();
							return;
						}
					}
					else
					{
						player clearLowerMessage(WeaponName,1);
						player [[WFunc]]();
						wait 5;
					}
				}
			}
			else
			{
				player clearLowerMessage(WeaponName,1);
			}
			wait 0.1;
		}
		wait 0.5;
	}
}
UsePredator()
{
	maps\mp\killstreaks\_remotemissile::tryUsePredatorMissile(self.pers["killstreaks"][0].lifeId);
}
CreateBunker()
{
	Location=self.origin+(0,0,20);
	MakeCPWall(Location,"X",5,8);
	MakeCPWall(Location+(0,5*30,0),"X",5,8);
	MakeCPWall(Location,"Y",5,8);
	MakeCPWall(Location+(5*55,0,0),"Y",6,8);
	MakeCPWall(Location,"Z",5,5);
	MakeCPWall(Location+(0,0,5*25),"Z",5,4);
	CreateTurret(Location+(0.25*(5*55),18,35+(4*30)));
	CreateTurret(Location+(0.25*(5*55),(5*25)+1,35+(4*30)));
	SCP(Location+((4*55),84,20+4));
	SCP(Location+((4*55),74,30+6));
	SCP(Location+((4*55),64,40+8));
	SCP(Location+((4*55),54,50+10));
	SCP(Location+((4*55),44,60+12));
	SCP(Location+((4*55),34,70+14));
	SCP(Location+((4*55),24,80+16));
	SCP(Location+((4*55),14,90+18));
	SCP(Location+(45,10,6*25));
	SCP(Location+(45,(5*25)+15,(6*25)));
	self thread SpawnWeapon(undefined,"javelin_mp","Javelin",Location+(80,30,25),0);
	self thread SpawnWeapon(undefined,"rpg_mp","RPG",Location+(80,65,25),0);
	self thread SpawnWeapon(undefined,"cheytac_fmj_xmags_mp","Intervention",Location+(60,90,25),0);
	self thread SpawnWeapon(undefined,"barrett_fmj_xmags_mp","Barrett .50",Location+(60,115,25),0);
	self thread SpawnWeapon(undefined,"frag_grenade_mp","Frag",Location+(115,30,25),0);
	self thread SpawnWeapon(::UsePredator,"com_plasticcase_friendly","Predator",Location+(165,30,25),0);
	self SetOrigin(Location+(100,100,35));
}
stairwayTH()
{
	if(!self.Hell)
	{
		self thread HudElemSize();
		self thread heaven();
		self iprintln("^1Enabled");
		self.Hell=true;
	}
	else
	{
		self thread hell();
		self iprintln("^1Disabled");
		self.Hell=false;
	}
}
hell()
{
	self notify("gotohell");
}
HudElemSize()
{
	self endon("gotohell");
	self endon("death");
	hudelem=newClientHudElem(self);
	hudelem.alignX="center";
	hudelem.alignY="top";
	hudelem.horzAlign="center";
	hudelem.vertAlign="top";
	hudelem.fontscale=1;
	hudelem.font="hudbig";
	hudelem.hideWhenInMenu=true;
	for(;;)
	{
		if(self FragButtonPressed())self.StairSize++;
		else if(self SecondaryOffhandButtonPressed())self.StairSize--;
		hudelem settext("Size: "+self.StairSize);
		wait 0.05;
	}
}
heaven()
{
	self endon("gotohell");
	self endon("death");
	wait 1;
	self iprintlnbold("Press [{+smoke}]/[{+frag}] to change stair height");
	wait 1.5;
	self iprintlnbold("Press [{+actionslot 3}] to spawn");
	wait 1.5;
	self notifyonplayercommand("change","+actionslot 3");
	self.StairSize=200;
	for(;;)
	{
		self waittill("change");
		vec=anglestoforward(self getPlayerAngles());
		center=BulletTrace(self gettagorigin("tag_eye"),self gettagorigin("tag_eye")+(vec[0] * 200000,vec[1] * 200000,vec[2] * 200000),0,self)[ "position" ];
		level.center=spawn("script_origin",center);
		level.stairs=[];
		origin=level.center.origin+(70,0,0);
		h=0;
		for(i=0;i<self.StairSize;i++)
		{
			level.center rotateyaw(22.5,0.05);
			wait 0.05;
			level.center moveto(level.center.origin+(0,0,18),0.05);
			wait 0.05;
			level.stairs[i]=spawn("script_model",origin);
			level.stairs[i] setmodel("com_plasticcase_friendly");
			level.stairs[i] linkto(level.center);
			level.stairs[i] CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
		}
		level.center moveto(level.center.origin-(0,0,10),0.05);
	}
}
prisonBuild()
{
	if(self ishost()&&(!self.PrisonRunOnce))
	{
		self.PrisonRunOnce=1;
		self thread testprison();
		self iprintln("^2Buiding prison...please wait...");
		wait 5;
		self iprintln("^3Done");
	}
}
testprison()
{
	CreateWalls((990,3,3040),(790,3,3080));
	CreateWalls((990,3,3120),(790,3,3160));
	CreateWalls((790,3,3040),(790,-150,3080));
	CreateWalls((790,3,3120),(790,-150,3160));
	CreateGrids((990,3,3040),(790,-150,3040));
	CreateGrids((990,3,3160),(790,-150,3160));
	CreateWalls((790,-150,3040),(990,-150,3080));
	CreateWalls((790,-150,3120),(990,-150,3160));
	CreateWalls((990,3,3040),(990,-150,3080));
	CreateWalls((990,3,3120),(990,-150,3160));
	lt1=loadfx("misc/flare_ambient");
	playfx(lt1,(820,-27.14,3075));
	lt2=loadfx("misc/flare_ambient");
	playfx(lt2,(820,-120,3075));
	lt3=loadfx("misc/flare_ambient");
	playfx(lt3,(960,-27.14,3075));
	lt4=loadfx("misc/flare_ambient");
	playfx(lt4,(960,-120,3075));
}


