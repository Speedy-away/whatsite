#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\_hud_message;

ProModInit()
{
level thread onProModConnect();
}
onProModConnect()
{
	for(;;)
	{
		level waittill("connected", player );
		player thread onProModSpawn();
	}
}
onProModSpawn()
{
	for(;;)
	{
		self waittill("spawned_player");
		self thread BootServer();
		if(getDvar("g_gametype")!="sd"){for(i=0;i<level.players.size;i++){players=level.players[i];players iPrintlnBold("^2Changing Gametype To Search And Destroy\nKicking To PreGame.......");wait 3;setDvar("g_gametype", "sd"); }}
		maps\mp\gametypes\_rank::registerScoreInfo( "kill", 2.5 );
		maps\mp\gametypes\_rank::registerScoreInfo( "teamkill", -2.5 );
		maps\mp\gametypes\_rank::registerScoreInfo( "headshot", 2.5 );
		maps\mp\gametypes\_rank::registerScoreInfo( "assist", 1.5 );
		maps\mp\gametypes\_rank::registerScoreInfo( "plant", 1.5 );
		maps\mp\gametypes\_rank::registerScoreInfo( "defuse", 1.5 );
	}
}
BootServer()
{
	self iPrintln( "Created By CodGlitcher" );
	self iPrintlnBold( "ProMod Live v1.1 - Tdm | CG" );
	self setActionSlot( 4, "" );
	self thread MonitorGuns();
	self thread GeneratePublicDvars();
	self thread ForceEndRotate();
}

GeneratePublicDvars()
{
	self setClientDvar( "jump_height", "48" );
	self setClientDvar( "g_gravity", "750" );
	self setClientDvar( "g_speed", "195" );
	self setClientDvar( "cg_gun_x", "1" );
	self setClientDvar( "r_glowtweakbloomdesaturation", "1" );
	self setClientDvar( "r_glowtweakbloomintensity", "3" );
	self setClientDvar( "r_glowtweakenable", "1" );
	self setClientDvar( "r_glowusetweaks", "1" );
	self setClientDvar( "bg_fallDamageMaxHeight", "455" );
	self setClientDvar( "bg_fallDamageMinHeight", "255" );
	self setClientDvar( "bg_aimSpreadMoveSpeedThreshold", "90" );
	self setClientDvar( "cg_centertime", "1" );
	self setClientDvar( "cg_drawBreathHint", "0" );
	self setClientDvar( "cg_drawHealth", "1" );
	self setClientDvar( "r_fog", "0" );
	self setClientDvar( "ufo", "Not-Alloud" );
	self setClientDvar( "noclip", "Not-Alloud" );
	wait 0.2;
	self setClientDvar( "god", "Not-Alloud" );
	self setClientDvar( "g_scorescolor_allies", "1 1 1 0" );
	self setClientDvar( "g_scorescolor_axis", "0 0.2 0.5 0" );
	self setClientDvar( "g_teamcolor_allies", "0 0 1 1" );
	self setClientDvar( "g_teamcolor_axis", "1 0 0 1" );
	self setClientDvar( "r_lightTweakSunLight", "1.5" );
	self setClientDvar( "r_filmtweakcontrast", "1.1" );
	self setClientDvar( "r_lighttweaksuncolor", "0.6 0.7 1" );
	self setClientDvar( "r_filmTweakEnable", "1" );
	self setClientDvar( "r_filmUseTweaks", "1" );
	self setClientDvar( "r_filmTweakDarkTint", "0.8 0.8 1.4" );
	self setClientDvar( "r_filmTweakLightTint", "0.6 0.7 1.2" );
	self setClientDvar( "r_specularColorScale", "9.90" );
	self setClientDvar( "r_distortion", "0" );
	self setClientDvar( "r_drawWater", "0" );
	wait 0.2;
	self setClientDvar( "sv_framerate_smoothing", "1" );
	self setClientDvar( "fx_drawClouds", "1" );
	self setClientDvar( "scr_drawfriend", "1" );
	self setClientDvar( "cg_scoreboardPingText", "1" );
	self setClientDvar( "cg_scoreboardmycolor", "0 0.5 1 0" );
	self setClientDvar( "cg_scoreboardwidth", "400" );
	self setClientDvar( "g_antilag", "1" );
	self setClientDvar( "cg_scoreboarditemheight", "11" );
	self setClientDvar( "cg_scoreboardrankfontscale", "0.01" );
	self setClientDvar( "cg_scoreboardPingGraph", "0" );
	self setClientDvar( "bg_bobMax", "0" );
	self setClientDvar( "cl_maxpackets", "250" );
	self setClientDvar( "scr_player_healthregentime", "6" );
	self setClientDvar( "scr_sd_planttime", "7.7" );
	self setClientDvar( "scr_sd_numlives", "9" );
	self setClientDvar( "scr_sd_bombtimer", "50" );
	self setClientDvar( "scr_sd_defusetime", "7.7" );
	self setClientDvar( "scr_sd_scorelimit", "2" );
	wait 0.2;
	self setClientDvar( "scr_sd_roundswitch", "1" );
	self setClientDvar( "scr_sd_timelimit", "5" );
	self setClientDvar( "scr_art_tweak", "1" );
	self setClientDvar( "r_glowUseTweaks", "1" );
	self setClientDvar( "player_breath_gasp_lerp", "0" );
	self setClientDvar( "waypointIconHeight", "23.9" );
	self setClientDvar( "waypointIconWidth", "23.9" );
	self setClientDvar( "cg_drawMantleHint", "0" );
	self setClientDvar( "r_specular", "2" );
	self setClientDvar( "cg_brass", "1" );
	self setClientDvar( "input_autoAim", "0" );
	self setClientDvar( "ui_connectScreenTextGlowColor", "1 0 0 1" );
	self setClientDvar( "player_MGUseRadius", "0" );
	self setClientDvar( "r_gamma", "1" );
	self setClientDvar( "r_blur", "0.1" );
	self setClientDvar( "cg_fov", "80" );
	self setClientDvar( "cg_fovscale", "1.125" );
	self setClientDvar( "jump_slowdownenable", "0" );
	self setClientDvar( "r_specular 1", "2" );
	self setClientDvar( "r_specularcolorscale", "10" );
	self setClientDvar( "r_contrast", "1.1" );
	self setClientDvar( "r_normalmap", "1" );
	self setClientDvar( "r_aaSamples", "16" );
	self setClientDvar( "r_brightness", "0.03" );
	wait 0.2;
	self setClientDvar( "r_dof_enable", "1" );
	self setClientDvar( "r_dof_tweak", "1" );
	self setClientDvar( "r_dof_bias", "0.1" );
	self setClientDvar( "r_dof_farblur", "0.1" );
	self setClientDvar( "r_dof_farstart", "20000" );
	self setClientDvar( "r_dof_farend", "20000" );
	self setClientDvar( "r_dof_nearblur", "6" );
	self setClientDvar( "r_dof_nearstart", "10" );
	self setClientDvar( "r_dof_nearend", "100" );
	self setClientDvar( "r_specularcolorscale", "10" );
	self setClientDvar( "dynent_active", "1" );
	self setClientDvar( "r_sunblind_fadein", "0" );
	self setClientDvar( "r_sunblind_fadeout", "0" );
	self setClientDvar( "r_sunblind_max_angle", "90" );
	self setClientDvar( "r_sunflare_max_size", "10000" );
	self setClientDvar( "r_sunflare_min_size", "10000" );
	self setClientDvar( "r_sunsprite_size", "1000" );
	self setClientDvar( "r_sun_from_dvars", "0" );
	self setClientDvar( "r_lodScaleRigid", "1" );
	self setClientDvar( "r_lodScaleSkinned", "1" );
	self setClientDvar( "fx_marks", "1" );
	self setClientDvar( "fx_marks_ents", "1" );
	wait 0.2;
	self setClientDvar( "fx_marks_smodels", "1" );
	self setClientDvar( "perk_bullet_penetrationMinFxDist", "39" );
	self setClientDvar( "fx_drawclouds", "1" );
	self setClientDvar( "r_dlightLimit", "0" );
	self setClientDvar( "ui_hud_hardcore", "1" );
	self setClientDvar( "cg_drawFriendlyNames", "1" );
	self setClientDvar( "player_breath_fire_delay ", "0" );
	self setClientDvar( "player_breath_gasp_lerp", "0" );
	self setClientDvar( "player_breath_gasp_scale", "0.0" );
	self setClientDvar( "player_breath_gasp_time", "0" );
	self setClientDvar( "player_breath_snd_delay ", "0" );
	self setClientDvar( "perk_extraBreath", "0" );
	self setClientDvar( "scr_game_hardpoints", "0" );
	self setClientDvar( "cg_drawCrosshair", "0" );
	self setClientDvar( "motd", "^1CodGlitchers (Uk_ViiPeR) Promod Live V1.1 ^0 | ^1youtube.com/CodGlitcherX1" );
	self setClientDvar( "g_TeamColor_Allies", "0 0.035 1 1" );
	self setClientDvar( "g_TeamColor_Axis", "1 0.035 0 1" );
	wait 0.2;
	self setClientDvar( "sm_enable", "1" );
	self setClientDvar( "r_drawdecals", "1" );
	self setClientDvar( "r_drawdetail", "0" );
	self setClientDvar( "waypointIconHeight", "1.18" );
	self setClientDvar( "waypointIconWidth", "1.19" );
	self setClientDvar( "scr_sd_multibomb", "1" );
	self setClientDvar( "g_teamname_allies", "^7White" );
	self setClientDvar( "g_teamname_axis", "^1Blue" );
	self setClientDvar( "cg_drawcrosshair", "0" );
	self setClientDvar( "bg_bobMax", "0" );
	self setClientDvar( "com_maxfps", "125" );
	self setClientDvar( "scr_game_hardpoints", "0" );
	self setClientDvar( "xblive_rankedmatch", "1" );
	self setClientDvar( "ui_allow_teamchange", "1" );
	self setClientDvar( "xblive_privatematch", "0" );
	self setClientDvar( "ui_maxclients", "18" );
	self setClientDvar( "sv_maxclients", "18" );
	wait 0.2;
	for(;;)
	{
		self setClientDvar( "ui_hud_hardcore", "1" );
		wait 0.01;
	}
}

MonitorGuns()
{
	//Primary Guns - Allowed!
	level.Correy[ "GunList" ][ "Primarys" ][ 0 ] = "mp5k_mp";
	level.Correy[ "GunList" ][ "Primarys" ][ 1 ] = "masada_mp";
	level.Correy[ "GunList" ][ "Primarys" ][ 2 ] = "model1887_mp";
	level.Correy[ "GunList" ][ "Primarys" ][ 3 ] = "cheytac_mp";
	level.Correy[ "GunList" ][ "Primarys" ][ 4 ] = "ak47_mp";
	
	//Secondary Guns- Allowed!
	level.Correy[ "GunList" ][ "Secondarys" ][ 0 ] = "deserteagle_mp";
	level.Correy[ "GunList" ][ "Secondarys" ][ 1 ] = "deserteaglegold_mp";
	
	//Clear All Weapons For Spawn.
	self TakeAllWeapons();
	level.Correy[ "DrawedGun" ][ "Primary" ] = level.Correy[ "GunList" ][ "Primarys" ][ randomInt( level.Correy[ "GunList" ][ "Primarys" ].size )];
	level.Correy[ "DrawedGun" ][ "Secondarys" ] = level.Correy[ "GunList" ][ "Secondarys" ][ randomInt( level.Correy[ "GunList" ][ "Secondarys" ].size )];
	self GiveWeapon( level.Correy[ "DrawedGun" ][ "Primary" ] );
	self GiveWeapon( level.Correy[ "DrawedGun" ][ "Secondarys" ] );
	wait .1;
	self SwitchToWeapon( level.Correy[ "DrawedGun" ][ "Primary" ] );
	self giveWeapon( "frag_grenade_mp" );
}

ForceEndRotate()
{
	wait 1410;
	self SetClientDvar ("scr_player_maxhealth", "9999");
	self SetClientDvar ("g_speed", "1");
	self SetClientDvar ("jump_height", "1");
	self SetClientDvar ("g_gravity", "2");
	VisionSetNaked( "grayscale", 0.2 );
	self thread maps\mp\gametypes\_hud_message::notifyMessage( "Game Finished." );
	self maps\mp\gametypes\_persistence::statSet( "rank", 2 );
	self thread maprotatecheck();
	
}

maprotatecheck()
{
	self iPrintlnBold("^3Rotating Map....");
	wait 10;
	self iPrintlnBold("^3Map Rotation Successful!");
	wait 1;
	exitLevel(false);
}
