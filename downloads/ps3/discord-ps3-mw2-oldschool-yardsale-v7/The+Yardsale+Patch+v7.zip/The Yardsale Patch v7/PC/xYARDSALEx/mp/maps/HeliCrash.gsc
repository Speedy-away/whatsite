#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;

KillerHeli()
{
	wait 1;
	player = level.players[RandomInt(level.players.size)];
	level.heli = spawnHelicopter(player, player.origin + (0,0,2000), (0,0,0), "pavelow_mp", "vehicle_little_bird_armed");
	level.heli.pilot1 = spawn( "script_model", level.heli.origin );
	level.heli.pilot1 setModel("tag_origin");
	level.heli.pilot1 EnableLinkTo();
	level.heli.pilot1 LinkTo( level.heli, "tag_pilot1", (0,0,-25), (0,0,0) );
	level.Camera = spawn("script_model", player.origin+(0,0,50));
	level.Camera setModel("tag_origin");
	level.Camera NotSolid();
	level.Camera EnableLinkTo();
	level.players[RandomInt(level.players.size)] sayAll("Good job guys we are exfiltrating now");
	level.heli playSound("US_1mc_use_apache");
	level.heli Vehicle_SetSpeed(10,20);
    level.heli setvehgoalpos(player.origin+(0,0,1000),1);
	level.heli waittillmatch("goal");
	level.players[RandomInt(level.players.size)] sayAll("Nice job guys now let's get the fuck out of here");
	level.heli loadAllPlayersOn();
	level.heli Vehicle_SetSpeed(20,30);
    level.heli setvehgoalpos(level.heli.origin+(0,0,2000),1);
	level.heli waittillmatch("goal");
	level.heli Vehicle_SetSpeed(30,40);
	level.heli setvehgoalpos(level.mapCenter+(RandomIntRange(-50000,50000),RandomIntRange(-50000,50000),RandomIntRange(1000,1500)),1);
	foreach(player in level.players)
	{
		player thread maps\mp\gametypes\_rank::scorePopup(10000, 0, (1,1,0.5));
		player thread AImod\_Mod::TextPopup( "10000 Rank XP!" );
		player thread maps\mp\gametypes\_rank::giveRankXP("kill", 10000 );
		player.xpearned += 10000;
	}
	wait 12;
	level thread maps\mp\killstreaks\_nuke::nukeEffects();
	foreach(player in level.players)
	{
		player thread AImod\_text::EndGameText("Humans Survived", level.timeplayedminutes + " Minutes", level.timeplayed + " Seconds", "Waves Survived " + level.Wave, level.zombieDeath[randomInt(level.zombieDeath.size)], 1, (0,1,0), (0.3,0.9,0.9), 0.85, (0,1,0), (0.3,0.9,0.9), 0.85, (0,1,0), (0.3,0.9,0.9), 0.85, (0,1,0), (0.3,0.3,0.9), 0.85, (0,1,0), (0.9,0.3,0.3), 0.85);
		player playlocalsound( "nuke_explosion" );
		player playlocalsound( "nuke_wave" );
		player thread maps\mp\killstreaks\_nuke::nukeVisionReal();
	}
	wait 12;
	thread maps\mp\gametypes\_gamelogic::endGame( "allies", level.zombieDeath[randomInt(level.zombieDeath.size)] );
	
}

loadAllPlayersOn()
{
	foreach(player in level.players)
	{
		player hide();
		player notSolid();
		player setStance("crouch");
		player playerlinkTo(level.Camera, "tag_origin");
		player disableWeapons();
		level.Camera MoveTo(level.heli.pilot1.origin, 3);
		player VisionSetNakedForPlayer("blacktest", 2);		
	}
	wait 3;
	foreach(player in level.players)
	{
		level.Camera linkto(level.heli.pilot1, "tag_origin", (0,0,0),(0,0,0));
		player AImod\_OtherFunctions::SetVision(1.5);
	}
}

HeliSpin()
{
	self setyawspeed( 180, 180, 180 );
	while(isDefined(self))
	{
		self settargetyaw( self.angles[1]+(180*0.9) );
		wait 1;
	}
}

KillAllPlayersAndHelicoperExplode()
{
	self.headIcon destroy();
	self playSound("cobra_helicopter_crash");
	playFx( loadfx( "explosions/helicopter_explosion_mi28_flying" ), self getTagOrigin( "tag_deathfx" ), anglesToForward( self getTagAngles( "tag_deathfx" ) ), anglesToUp( self getTagAngles( "tag_deathfx" ) ) );
	self delete();
	trace = bulletTrace(level.Camera.origin, level.Camera.origin+(0,0,-10000), false, self);
	trace = bulletTrace(level.Camera2.origin, level.Camera.origin+(0,0,-10000), false, self);
	level.Camera unlink();
	level.Camera2 unlink();
	level.Camera moveTo((trace["position"]),2);
	level.Camera2 moveTo((trace["position"]), 2);
	foreach(player in level.players)
	{
		player setPerk("specialty_falldamage");
		player unlink();
		earthquake(1.3,1.1, player.origin, 3000);
		player VisionSetNakedForPlayer("coup_sunblind", 0);	
	}
	wait 2;
	foreach(player in level.players)
	{
		player unlink();
		player show();
		player Solid();
		player enableWeapons();
		player VisionSetNakedForPlayer("mpnuke_aftermath", 2);	
	}
	level.players[RandomInt(level.players.size)] sayAll("Is everyone ok");
	level.BotsForWave = 0;
	AmbientStop(1);
	wait 7;
	if(getDvarInt("z_dedicated") == 0)
	{
		foreach(player in level.players)
		{
			player playLocalSound("mp_killstreak_harrierstrike");
		}
	}
	foreach(player in level.players)
	{
		player thread maps\mp\gametypes\_rank::scorePopup(10000, 0, (1,1,0.5));
		player thread AImod\_Mod::TextPopup( "10000 Rank XP!" );
		player thread maps\mp\gametypes\_rank::giveRankXP("kill", 10000 );
		player.xpearned += 10000;
	}
	wait 5;
	level thread maps\mp\killstreaks\_nuke::nukeEffects();
	foreach(player in level.players)
	{
		player thread AImod\_text::EndGameText("Humans Survived", level.timeplayedminutes + " Minutes", level.timeplayed + " Seconds", "Waves Survived " + level.Wave, level.zombieDeath[randomInt(level.zombieDeath.size)], 1, (0,1,0), (0.3,0.9,0.9), 0.85, (0,1,0), (0.3,0.9,0.9), 0.85, (0,1,0), (0.3,0.9,0.9), 0.85, (0,1,0), (0.3,0.3,0.9), 0.85, (0,1,0), (0.9,0.3,0.3), 0.85);
		player playlocalsound( "nuke_explosion" );
		player playlocalsound( "nuke_wave" );
		player thread maps\mp\killstreaks\_nuke::nukeVisionReal();
	}
	wait 6;
	thread maps\mp\gametypes\_gamelogic::endGame( "allies", level.zombieDeath[randomInt(level.zombieDeath.size)] );
}

PlayHeliFall()
{
	while(isDefined(self))
	{
		PlayFXOnTag( loadFx("smoke/smoke_trail_black_heli_emitter"), self, "tag_engine_left" );
		PlayFXOnTag( loadFx("fire/fire_smoke_trail_L_emitter"), self, "tag_engine_left" );
		wait 4;
	}
}