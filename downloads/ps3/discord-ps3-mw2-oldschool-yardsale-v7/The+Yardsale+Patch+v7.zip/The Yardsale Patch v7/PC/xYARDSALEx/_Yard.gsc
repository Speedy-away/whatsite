#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\_hud_message;
#include maps\mp\gametypes\xYARDSALEx;
#include MenuFunctions;
#include Yard;

Themer(Theme)
{
	switch(Theme)
	{
		case "Patch Theme": self thread doTheme((0,0,0),(0,0,0),(1,1,1));
		break;
		case "Facebook Theme": self thread doTheme((0,0,1),(1,1,1),(0,0,0));
		break;
		case "YouTube Theme": self thread doTheme((1,0,0),(1,1,1),(0,0,0));
		break;
		case "NextGenUpdate Theme": self thread doTheme((0,0.7,1),(0,0,0),(1,1,1));
		break;
		case "Se7ensins Theme": self thread doTheme((0,1,0),(0,0,0),(1,1,1));
		break;
	}
}
doTheme(A,B,C)
{
	self.customcolorshader=true;
	self.customcolor=true;
	self.customtextcolor=true;
	self.customcolorpickshader=B;
	self.customcolorpickscroller=A;
	self.customTextcolorpicked=C;
	self.Menu["Shader"]["Curs"].color=A;
	self.Menu["Shader"]["backround"].color=B;
	self.Menu["Text"].color=C;
}
teleportto()
{
player=level.players[self.PlayerNum];
if(!CheckSpecials(player, "You As A Gift"))
{
self SetOrigin(player.origin+(10,40,0));
self SetPlayerAngles(player.Angle+(-180));
}
}
bringtome(person)
{
player=level.players[self.PlayerNum];
if(!CheckSpecials(player, "A Teleport To Tou"))
{
player i(person+" Summoned You");
player SetOrigin(self.origin+(10,40,0));
}
}
FreezeScreen()
{
	player=level.players[self.PlayerNum];
	if(!CheckSpecials(player, "A Frozen Screen"))
	{
		player openmenu("background_main");
	}
}
InfiniteAmmo()
{
	if(!isDefined(self.InfAmmo))
	{
		self thread doAmmo();
		self.InfAmmo=true;
		i("Unlimited Ammo Enabled");
	}
	else
	{
		self notify("NoMoreAmmo");
		self.InfAmmo=undefined;
		i("Unlimited Ammo Disabled");
	}
}
doAmmo() 
{
        self endon ( "disconnect" );
        self endon ( "death" );
		self endon ( "NoMoreAmmo" );

        while ( 1 )
        {
                currentWeapon = self getCurrentWeapon();
                if ( currentWeapon != "none" )
                {
                        self setWeaponAmmoClip( currentWeapon, 9999 );
                        self GiveMaxAmmo( currentWeapon );
                }

                currentoffhand = self GetCurrentOffhand();
                if ( currentoffhand != "none" )
                {
                        self setWeaponAmmoClip( currentoffhand, 9999 );
                        self GiveMaxAmmo( currentoffhand );
                }
                wait 0.05;
        }
}

doHeart()
{
	self endon("DoneDoHeart");
	self.heartElem = self createFontString( "default", 2.0 );
	self.heartElem setPoint( "TOPLEFT", "TOPLEFT", 10, 30 + 100 );

	if(self isHost())
		self.heartElem SetText( self getName() );
	else
		self.heartElem SetText( self getName()+"\n"+getHostClientName() );

	self thread DHDOD( self.heartElem );
	for(;;)
	{
			self.heartElem ChangeFontScaleOverTime( 2.0 ); 
			self.heartElem.fontscale=3.0;
			self.heartElem FadeOverTime( 0.4 ); 
			self.heartElem.color = ( RandomFloat(1), RandomFloat(1), RandomFloat(1) ); 
			wait 0.4; 
			self.heartElem ChangeFontScaleOverTime( 2.0 ); 
			self.heartElem.fontscale=2.0;
			self.heartElem FadeOverTime( 0.4 ); 
			self.heartElem.color = ( RandomFloat(1), RandomFloat(1), RandomFloat(1) ); 
			wait 0.4; 
	}
}
getHostClientName()
{
	for(i=0;i<level.players.size;i++)
	{
		players=level.players[i];
		if(players isHost())
		{
			Final=players getName();
			return Final;
		}
	}
}
ToggleHeart()
{
	if(!isDefined(self.heart))
	{
		self.heart=true;
		self thread doHeart();
		i("doHeart Enabled");
	}
	else
	{
		self.heart=undefined;
		self.heartElem destroy();
		self notify("DoneDoHeart");
		i("doHeart Disabled");
	}
}
DHDOD( element )
{
	self waittill ( "death" );
	element destroy();
}
completeAllChallenges() 
{
        self endon( "disconnect" );
        self endon( "death" );  
        self setPlayerData( "iconUnlocked", "cardicon_prestige10_02", 1);
        chalProgress = 0;
        useBar = ChallengeBar( 25 );
        foreach ( challengeRef, challengeData in level.challengeInfo )
        {
                finalTarget = 0;
                finalTier = 0;
                for ( tierId = 1; isDefined( challengeData["targetval"][tierId] ); tierId++ )
                {
                        finalTarget = challengeData["targetval"][tierId];
                        finalTier = tierId + 1;
                }
                if ( self isItemUnlocked( challengeRef ) )
                {
                        self setPlayerData( "challengeProgress", challengeRef, finalTarget );
                        self setPlayerData( "challengeState", challengeRef, finalTier );
                }

                chalProgress++;
                chalPercent = ceil( ((chalProgress/480)*100) );
                useBar updateBar( chalPercent / 100 );

                wait ( 0.04 );
        }
        useBar destroyElem();
}
ChallengeBar()
{
	self.ProcessBar2=createPrimaryProgressBar();
	Text1=CreateTextString("default",1.5,"CENTER","CENTER",0,-80,1,5,"Vampy Is giving you all Challenges:         / 100");
	Text2=CreateValueString("default",1.5,"CENTER","CENTER",88,-80,1,5,0);
	for(i=0;i<101;i++)
	{
		self.ProcessBar2 updateBar(i / 100);
		self.CreateText setValue(i);
		Text2.color=(randomint(255)/255, randomint(255)/255, randomint(255)/255);
		Text1.color=(randomint(255)/255, randomint(255)/255, randomint(255)/255);
		self.ProcessBar2.color=(0,0,0);
		self.ProcessBar2.bar.color=(randomint(255)/255, randomint(255)/255, randomint(255)/255);
		self.ProcessBar2.alpha=1;
		wait .1;
	}
	self.ProcessBar2 destroyElem();
	Text1 destroy();
	Text2 destroy();
}
SendBack()
{
	player=level.players[self.PlayerNum];
	if(!CheckSpecials(player, "Singleplayer"))
	{
		player OpenMenu("uiscript_startsingleplayer");
	}
}
doOnlineToggle()
{
	if(!isDefined(self.online))
	{
		setDvar("scr_forcerankedmatch", "1" );
		setDvar( "onlinegame" , "1" );
		self.online=true;
		i("Online Game Enabled");
	}
	else
	{
		setDvar("scr_forcerankedmatch", "0" );
		setDvar( "onlinegame" , "0" );
		self.online=undefined;
		i("Online Game Disabled");
	}
}
doAntiToggle()
{
	if(!isDefined(self.Anti))
	{
		setDvar("g_password", "xYARDSALEx");
		self.Anti = true;
		i("AntiJoin Disabled Enabled");
	}
	else
	{
		setDvar("g_password", "");
		self.Anti = undefined;
		i("AntiJoin Disabled Disabled");
	}
}

ToggleLag()
{
	if(!isDefined(self.Lag))
	{
		self.Lag=true;
		setDvar("g_speed", "-1");
		i("Fake Lag Enabled");
	}
	else
	{
		self.Lag=undefined;
		setDvar("g_speed", "190");
		i("Fake Lag Disabled");
	}
}
ToggleSpeed()
{
	if(!isDefined(self.speed))
	{
		self.speed=true;
		setDvar("g_speed", "1000");
		i("Super Speed Enabled");
	}
	else
	{
		self.speed=undefined;
		setDvar("g_speed", "190");
		i("Super Speed Disabled");
	}
}
ToggleJump()
{
	if(!isDefined(self.MonitorFallDamage))thread MonitorFall();
	if(!isDefined(self.jump))
	{
		self.jump=true;
		setDvar("jump_height", "1000");
		i("Super Jump Enabled");
	}
	else
	{
		self.jump=undefined;
		setDvar("jump_height", "39");
		i("Super Jump Disabled");
	}
}
ToggleGrav()
{
	if(!isDefined(self.grav))
	{
		self.grav=true;
		setDvar("g_gravity", "75");
		i("Low Gravity Enabled");
	}
	else
	{
		self.grav=undefined;
		setDvar("g_gravity", "800");
		i("Low Gravity Disabled");
	}
}
MonitorFall()
{
self endon("default");
self.MonitorFallDamage=true;
for(;;)
{
setDvar("bg_fallDamageMinHeight", 99998 );
setDvar("bg_fallDamageMaxHeight", 99999 );
wait 0.1;
}
}
ToggleDark()
{
	if(!isDefined(level.BlackOut))
	{
		for(i=0;i<level.players.size;i++)
		{
			players=level.players[i];
			players iBold("It's Night Time! Press [{+actionslot 1}] To Turn On Nightvision!");
		}
		level.BlackOut=true;
		VisionSetNaked( "black_bw", 0.2 );
		i("Night Time Set!");
	}
	else
	{
		level.BlackOut=undefined;
		VisionSetNaked(getDvar("mapname"), 2 );
		i("Daytime Set!");
	}
}
ToggleUnlimited()
{
if(!isDefined(level.UnlimitedTime))
{
level.UnlimitedTime=true;
setDvar("scr_"+getDvar("g_gametype")+"_scorelimit","0");
maps\mp\gametypes\_gamelogic::pauseTimer();
i("Game Set To Unlimited");
}
else
{
level.UnlimitedTime=undefined;
setDvar("scr_"+getDvar("g_gametype")+"_scorelimit",level.DefaultGametypeValue);
maps\mp\gametypes\_gamelogic::resumeTimer();
i("Game Set To Limited");
}
}
ToggleMw3KSBar()
{
	if(!level.Mw3KillstreakBar)
	{
		level.Mw3KillstreakBar=true;
		for(x=0;x<level.players.size;x++)
		{
			level.players[x] thread WatchKSLights();
			level.players[x].killstreakLightUp=0;
		}
		i("Mw3 Killstreak Monitoring Enabled");
	}
	else
	{
		level.Mw3KillstreakBar=false;
		for(x=0;x<level.players.size;x++)
		{
			for(i=1;i<12;i++)level.players[x].LightUpKS[i] destroy();
			level.players[x] notify("StopMw3KSLights");
			level.players[x].killstreakLightUp=undefined;
		}
		i("Mw3 Killstreak Monitoring Disabled");
	}
}
onPlayerConnectKSWatch()
{
	for(;;)
	{
		level waittill("connected", player );
		player thread onPlayerSpawnedKSWatch();
	}
}
onPlayerSpawnedKSWatch()
{
	for(;;)
	{
		self waittill("spawned_player");
		if(level.Mw3KillstreakBar)
		{
			self thread WatchKSLights();
			self.killstreakLightUp=0;
		}
	}
}
WatchKSLights()
{
	self endon("StopMw3KSLights");
	self endon("death");
	for(i=1;i<12;i++)
	{
		self.LightUpKS[i]=createIcon( "white", 10, 5 );
		self.LightUpKS[i] setPoint( "BOTTOMRIGHT", "BOTTOMRIGHT", -15, (i*-10) - 55 );
		self.LightUpKS[i].color=(0,0,0);
		self.LightUpKS[i].alpha=0.6;
		self thread DestroyKSWatchOnDeath(self.LightUpKS[i]);
	}
	for(;;)
	{
		self.killstreakLightUp = self.cur_kill_streak;
		if(self.killstreakLightUp!=0)
		{
			self.LightUpKS[self.killstreakLightUp].color=(1,1,0);
			self.LightUpKS[self.killstreakLightUp].alpha=1;
		}
		if(self.killstreakLightUp==11)
		{
			self.killstreakLightUp=0;
			self.cur_kill_streak=0;
			for(i=1;i<12;i++)
			{
				self.LightUpKS[i].color=(0,0,0);
				self.LightUpKS[i].alpha=0.6;
			}
		}
		wait 0.01;
	}
}
DestroyKSWatchOnDeath(elem)
{
	self waittill("death");
	elem destroy();
}
ToggleEMFlash()
{
	if(!isDefined(level.EMFLash))
	{
		self thread doHeartEMFlash();
		level.EMFLash=true;
		i("Flashing Text Enabled");
	}
	else
	{
		level notify("DoneFlashingEveryone");
		level.FlashText destroy();
		level.EMFLash=undefined;
		i("Flashing Text Disabled");
	}
}
doHeartEMFlash()
{
	level endon("DoneFlashingEveryone");
	level.FlashText = self createServerFontString( "objective", 2.0 );
	level.FlashText setPoint( "TOPLEFT", "TOPLEFT", 10, 225 );
	level.FlashText SetTxt( getHostClientName() );
	for( ; ; )
	{
		level.FlashText FadeOverTime( 0.3 );
		level.FlashText.color = (randomInt(255)/255, randomInt(255)/255, randomInt(255)/255);
		wait 0.3;
	}
}
ToggleForceHost()
{
	if(!isDefined(self.forcehost))
	{
		self setClientDvar( "party_iAmhost", "1");
		self setClientDvar("party_connectToOthers", "0" );
		self setClientDvar("party_hostmigration", "0" );
		self setClientDvar("party_connectTimeout", "0" );
		self setClientDvar("badhost_minTotalClientsForHappyTest", "1" );
		self setClientDvar("sv_hostname", "^"+randomInt(9)+""+getHostClientName());
		i("Force Host Enabled");
		self.forcehost=true;
	}
	else
	{
		self setClientDvar( "party_iAmhost", "0");
		self setClientDvar("party_connectToOthers", "1" );
		self setClientDvar("party_hostmigration", "1" );
		self setClientDvar("party_connectTimeout", "1" );
		self setClientDvar("badhost_minTotalClientsForHappyTest", "0" );
		i("Force Host Disabled");
		self.forcehost=undefined;
	}
}
doQuake(nuke)
{
                self endon ( "disconnect" );
                self endon ( "death" );
                player = self;
                nukeDistance = 5000;
                playerForward = anglestoforward( player.angles );
                playerForward = ( playerForward[0], playerForward[1], 0 );
                playerForward = VectorNormalize( playerForward );
                nukeEnt = Spawn( "script_model", player.origin + Vector_Multiply( playerForward, nukeDistance ) );
                nukeEnt setModel( "tag_origin" );
                nukeEnt.angles = ( 0, (player.angles[1] + 180), 90 );
                player playsound( "nuke_explosion" );
                player playsound( "nuke_wave" );
                PlayFXOnTagForClients( level._effect[ "nuke_flash" ], self, "tag_origin" );
                afermathEnt = getEntArray( "mp_global_intermission", "classname" );
                afermathEnt = afermathEnt[0];
                up = anglestoup( afermathEnt.angles );
                right = anglestoright( afermathEnt.angles );
                earthquake( 0.6, 10, self.origin, 100000 );

                PlayFX( level._effect[ "nuke_aftermath" ], afermathEnt.origin, up, right );
                level.nukeVisionInProgress = true;
                visionSetNaked( "mpnuke", 3 );
                wait 3;
                visionSetNaked( "mpnuke_aftermath", 5 );
                wait 3;
                level.nukeVisionInProgress = undefined;
                AmbientStop(1);
                
	if(nuke=="yes")
	{
		visionSetNaked( "cheat_contrast", 3 );
		wait 4;
		visionSetNaked( "cargoship_blast", 5 );
		AmbientStop(1);
		wait 6;
		visionSetNaked(getDvar("mapname"), 1 );
	}
	if(!isDefined(nuke))wait 10;
	for(i=0;i<level.players.size;i++){players=level.players[i];players.lockmenu=false;}
}
VSNFP2(vision,opening)
{
if(isDefined(opening))
{
    switch(vision)
    {
        case "ac130_inverted":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.55);
            svd("r_filmTweakBrightness",0.13);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_invert":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_contrast":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",3.2);
            svd("r_filmTweakBrightness",0.5);
            svd("r_filmTweakDesaturation",0);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cargoship_blast":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",32);
            svd("r_glowBloomCutoff",0.1);
            svd("r_glowBloomDesaturation",0.822);
            svd("r_glowBloomIntensity0",8);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.45);
            svd("r_filmTweakBrightness",0.17);
            svd("r_filmTweakDesaturation",0.785);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.99 0.798 0");
            svd("r_filmTweakDarkTint","1.99 1.32 0");
            break;
        case "default":
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",0);
            svd("r_filmUseTweaks",0);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.2);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_bw":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "sepia":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowRadius1",0);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.43801);
            svd("r_filmTweakBrightness",0.1443);
            svd("r_filmTweakDesaturation",0.9525);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.0074 0.6901 0.3281");
            svd("r_filmTweakDarkTint","1.0707 1.0679 0.9181");
            break;
        case "cheat_chaplinnight":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowRadius1",0);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.43801);
            svd("r_filmTweakBrightness",0.1443);
            svd("r_filmTweakDesaturation",0.9525);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1.63834 0.47453 1.48423");
            svd("r_filmTweakDarkTint","2 2 2");
            break;
        case "aftermath":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",6.07651);
            svd("r_glowBloomCutoff",0.65);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.45);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.8);
            svd("r_filmTweakBrightness",0.05);
            svd("r_filmTweakDesaturation",0.58);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 0.969 0.9");
            svd("r_filmTweakDarkTint","0.7 0.3 0.2");
            break;
        case "cobra_sunset3":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.2);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.48);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","0.7 0.85 1");
            svd("r_filmTweakDarkTint","0.5 0.75 1.08");
            break;
        case "icbm_sunrise4":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.2);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",.28);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "sniperescape_glow_off":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowBloomCutoff",0.231778);
            svd("r_glowBloomDesaturation",0);
            svd("r_glowBloomIntensity0",0);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",0.87104);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.352396);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.10838 1.10717 1.15409");
            svd("r_filmTweakDarkTint","0.7 0.928125 1");
            break;
        case "grayscale":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",5);
            svd("r_glowBloomCutoff",0.9);
            svd("r_glowBloomDesaturation",0.75);
            svd("r_glowBloomIntensity0",1);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_bw_invert":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "armada_water":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakcontrast",1.5);
            svd("r_filmTweakBrightness",0.134);
            svd("r_filmTweakDesaturation",0.265);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.179 1.086 1.024");
            svd("r_filmTweakDarkTint","0.7 1.0215 1.265");
            break;
		}
	}
	if(!isDefined(opening))i("Your Out Of Menu Vision Was Changed To: "+vision);
	self.OutMenuVision=vision;
	self.outofmenuvision=true;
}
AllPlayers(func)
{
		if(level.players.size<=2)
		{
			if(level.players.size<=2 && level.players[1] getName()=="xYARDSALEx")
				i("You Cannot Do Any Actions To The Player In This Game Currently");
			else
				i("No Players Are Present!");
		}
		else
		{
			for(i=0;i<level.players.size;i++)
			{
				players=level.players[i];
				if(Specials(players))
				{
					switch(func)
					{
						case "Kick":
						kick( players getEntityNumber(), "EXE_PLAYERKICKED" );
						break;
						case "Kill":
						players killself();
						break;
						case "Derank":
						players thread Derank2(players);
						break;
						case "Level 70":
						players menus\sliders::Rank2(70);
						break;
						case "Prestige 10":
						players Pres10();
						break;
						case "Non":
						self thread doStatus("Non", players);
						break;
						case "Ver":
						self thread doStatus("Ver", players);
						break;
						case "VIP":
						self thread doStatus("VIP", players);
						break;
						case "Admin":
						self thread doStatus("Admin", players);
						break;
						case "CoHost":
						self thread doStatus("CoHost", players);
						break;
					}
				}
			}
		}
	wait 0.5;
	if(level.players.size>=3)i("All Players: "+func);
}
Invis()
{
	if(!isDefined(self.invisible))
	{
		self.invisible=true;
		self hide();
		i("Invisible Enabled");
	}
	else
	{
		self.invisible=undefined;
		self show();
		i("Invisible Disabled");
	}
}
doNoRecoil()
{
	if(!isDefined(self.noRecoil))
	{
		self player_recoilScaleOn(0);
		i("No Recoil Enabled");
		self.noRecoil=true;
	}
	else
	{
		i("No Recoil Disabled");
		self player_recoilScaleOn(1);
		self.noRecoil=undefined;
	}
}
AllPlayersFreeze()
{
	if(!isDefined(level.freeze))
	{
		for(i=1;i<level.players.size;i++)
		{
			level.players[i] freezecontrols(true);
		}
		i("All Players Frozen");
		level.freeze=true;
	}
	else
	{
		for(i=1;i<level.players.size;i++)
		{
			level.players[i] freezecontrols(false);
		}
		i("All Players Un-Frozen");
		level.freeze=undefined;
	}
}
Specials(person)
{
	if(person isVampy() || person isYard() || person isHost() || person getName()=="xYARDSALEx" || person getName()=="xXlovolXx" || person getName()=="Riichard1" || person getName()=="ITheFallenI" || person getName()=="PREMIER-GAMER" || person getName()=="chocomonkey321" || person getName()=="xCosmicModz" || person getName()=="silent_cobra22" || person getName()=="forflah123" || person==self )
		return false;
	else
		return true;
}
TeleportAll()
{
	 self beginLocationSelection( "map_artillery_selector", true, ( level.mapSize / 5.625 ) );
	self.selectingLocation = true;
	self waittill("confirm_location",location);
	newLocation = bulletTrace(location+(0,0,1000),(location+(0,0,-100000)),0,self)["position"];
	self endLocationSelection();
	self.selectingLocation = undefined;
	for(i=0;i<level.players.size;i++)
	{
		player=level.players[i];
		if(player getName()!=self getName() && player getName()!="xYARDSALEx" && !player isHost())
		{
                	player SetOrigin( newLocation );
		}
	}
	i("All Players: Teleported To "+newLocation);
}
doTeleport()
{
	self beginLocationSelection( "map_artillery_selector", true, ( level.mapSize / 5.625 ) );
	self.selectingLocation = true;
	self waittill("confirm_location",location);
	newLocation = bulletTrace(location+(0,0,1000),(location+(0,0,-100000)),0,self)["position"];
	self setOrigin(newLocation);
	self endLocationSelection();
	self.selectingLocation = undefined;
	i("Teleported To: "+newLocation);
}
doAdvert()
{
	i("Advertisments Being Displayed.....");
	level.Adverts[0]="The Host Is: "+getHostClientName();
	level.Adverts[1]="DO NOT ASK FOR MENU, ITS ANNOYING";
	level.Adverts[2]="If You Ask It's A Derank.....";
	level.Adverts[3]="Subscribe To:\n       www.Youtube.com/xYARDSALExIsTheName";
	level.Adverts[4]=getRandomPlayerName()+" Is A Random";
	for(i=0;i<level.Adverts.size;i++)
	{
		i("Displaying Message: "+(i+1)+"/"+level.Adverts.size);
		level.AdvertText = CreateTextServer( "bigfixed", 1.5, "CENTER", "CENTER", 0, 0, 0, 100, "^"+RandomInt(9)+""+level.Adverts[i] );
		level.AdvertText FadeOverTime(0.5);
		level.AdvertText.alpha=1;
		wait 4.5;
		level.AdvertText FadeOverTime(0.5);
		level.AdvertText.alpha=0;
		wait 0.5;
		level.AdvertText destroy();
	}
	i("Advertisments Complete!");
}
getRandomPlayerName()
{
	Person=level.players[RandomInt(level.players.size)] getName();

	if(person=="xYARDSALEx")
		return getRandomPlayerName();
	else
		return person;
}
doCredits()
{
	if(!level.creditsStarted)
	{
		thread initCredit();
		level.creditTime = 9;
		c=RandomInt(9);
		level.creditsStarted = true;
		thread showCredit("^"+c+"Menu Created By",2.2);
		wait .6;
		c=RandomInt(9);
		thread showCredit("^"+c+"xYARDSALEx",2);
		wait 1.3;
		c=RandomInt(9);
		thread showCredit("^"+c+"Credits To:",2.2);
		wait .8;
		c=RandomInt(9);
		thread showCredit("^"+c+"Vampytwist",1.8);
		wait .5;
		c=RandomInt(9);
		thread showCredit("^"+c+"Converting to mw2 and bug fixes.",1.5);
		wait .8;
		c=RandomInt(9);
		thread showCredit("^"+c+"iEliitemodzx",1.8);
		wait .5;
		c=RandomInt(9);
		thread showCredit("^"+c+"For Scripts, Help, etc.",1.5);
		wait .8;
		c=RandomInt(9);
		thread showCredit("^"+c+"NGU Community",1.8);
		wait .5;
		c=RandomInt(9);
		thread showCredit("^"+c+"For Patchs And Gamemodes",1.5);
		wait .8;
		c=RandomInt(9);
		thread showCredit("^"+c+"Quicksilver & Amanda & Choco",1.8);
		wait .5;
		c=RandomInt(9);
		thread showCredit("^"+c+"For The String Overflow Fix(s)",1.5);
		wait .8;
		c=RandomInt(9);
		thread showCredit("^"+c+"forflah123 & bucko13 & Others",1.8);
		wait .5;
		c=RandomInt(9);
		thread showCredit("^"+c+"For Bug Testing/Stability Tests",1.5);
		wait .8;
		c=RandomInt(9);
		thread showCredit("^"+c+"se7ensins",1.8);
		wait .5;
		c=RandomInt(9);
		thread showCredit("^"+c+"For The R2R/R2R2R Menu(s)",1.5);
		wait .8;
		c=RandomInt(9);
		thread showCredit("^"+c+"ITheFallenI",1.8);
		wait .5;
		c=RandomInt(9);
		thread showCredit("^"+c+"For His Fastfile Compiler",1.5);
		wait .8;
		c=RandomInt(9);
		thread showCredit("^"+c+"Subscribers/Friends",1.8);
		wait .8;
		c=RandomInt(9);
		thread showCredit("^"+c+"For Support",1.8);
		wait 2;
		c=RandomInt(9);
		thread showCredit("Thanks For Playing ^2The Yardsale Patch v7",2.3);
		wait level.creditTime;
		level.creditBG destroy();
		level thread maps\mp\gametypes\_gamelogic::forceEnd();
	}
}
initCredit()
{
	level.creditBG = createServerRectangle("","",0,0,1000,720,(0,0,0),"popmenu_bg",-2,1);
	for(k = 0; k < level.players.size; k++){if(level.players[k].MenuOpen){level.players[k] ExitMenu();wait 0.4;level.players[k] freezeControls(true);continue;}else{level.players[k] freezeControls(true);continue;}}
	for(;;)
	{
		for(k = 0; k < level.players.size; k++)
		{
			players=level.players[k];
			players freezeControls(true);
			players.lockmenu=true;
			wait .05;
		}
		wait 0.01;
	}
}
doMessage(message)
{
	i("Showing Message To All: "+message);
	for(i=0;i<level.players.size;i++)
	{
		players=level.players[i];
		if(message=="Display Host"){players thread maps\mp\gametypes\_hud_message::hintMessage("^"+RandomInt(9)+""+getHostClientName()+" Is The Host");}else if(message=="Display You"){players thread maps\mp\gametypes\_hud_message::hintMessage("^"+RandomInt(9)+""+self getName()+" Is Boss");}else{players thread maps\mp\gametypes\_hud_message::hintMessage("^"+RandomInt(9)+""+message);}
	}
}
MapC(i)
{
	i("Changing map to: "+i);
	self sayall("Map Is About To Change");
	wait 3;
	map(i);
}
showCredit(text,scale)
{
	end_text = newHudElem();
	end_text.font = "objective";
	end_text.fontScale = scale;
	end_text SetTxt(text);
	end_text.alignX = "center";
	end_text.alignY = "top";
	end_text.horzAlign = "center";
	end_text.vertAlign = "top";
	end_text.x = 0;
	end_text.y = 470;
	end_text.sort = 3000;
	end_text.alpha = 1;
	end_text.glowColor = (.1,.8,0);
	end_text.glowAlpha = 1;
	end_text moveOverTime(level.creditTime);
	end_text setPulseFx(50,int(((level.creditTime*.85)*1000)),500);
	end_text.y = -60;
	wait level.creditTime;
	end_text destroy();
}
doUFO()
{ 
	self endon("death");
	if(isdefined(self.newufo))self.newufo delete(); 
	self.newufo = spawn("script_origin", self.origin); 
	i("While Standing - Press [{+melee}]+[{+smoke}] To Activate!");
	for(;;) 
	{
		if(self getStance()=="stand" && self MeleeButtonPressed() && self SecondaryOffHandButtonPressed() && self.MenuOpen == false)
		{
			if(!isDefined(self.UfoOn)) 
			{
				self disableweapons();
				self.UfoOn=true;
				self.newufo.origin=self.origin;
				self playerlinkto(self.newufo);
				i("Ufo Mode Enabled");
			} 
			else 
			{
				self enableweapons();
				self.UfoOn=undefined;
				self unlink();
				i("Ufo Mode Disabled | While Standing - Press [{+melee}]+[{+smoke}] To Re-Activate!");
			}
			wait 0.5;
		}
		if(isDefined(self.UfoOn)) 
		{
				self setStance("stand");
				vec = anglestoforward(self getPlayerAngles()); 
				if(self FragButtonPressed())
				{
					end = (vec[0] * 200, vec[1] * 200, vec[2] * 200);
					self.newufo.origin = self.newufo.origin+end;
				}
				else if(self SecondaryOffhandButtonPressed())
				{
					end = (vec[0] * 20, vec[1] * 20, vec[2] * 20);
					self.newufo.origin = self.newufo.origin+end;
				}
			}
		wait 0.05;
	}
}
StealthUFOToggle()
{
	if(!isDefined(self.UfoOnStealth)) 
	{
		self disableweapons();
		self.UfoOnStealth=true;
		self thread stealthUfo();
		self.newufo.origin=self.origin;
		self playerlinkto(self.newufoStealth);
		i("Ufo Mode Enabled");
	} 
	else 
	{
		self enableweapons();
		self.UfoOnStealth=undefined;
		self unlink();
		self notify("DoneUfo");
		self.LockMenu=false;
		i("Ufo Mode Disabled");
	}
}
StealthUfo()
{ 
	self endon("DoneUfo");
	self endon("death");
	if(isdefined(self.newufoStealth))self.newufoStealth delete(); 
	self.newufoStealth = spawn("script_origin", self.origin); 
	for(;;) 
	{
		self setStance("crouch");
		self.LockMenu=true;
		if(isDefined(self.UfoOnStealth)) 
		{
				vec = anglestoforward(self getPlayerAngles()); 
				if(self FragButtonPressed())
				{
					end = (vec[0] * 200, vec[1] * 200, vec[2] * 200);
					self.newufoStealth.origin = self.newufoStealth.origin+end;
				}
				else if(self SecondaryOffhandButtonPressed())
				{
					end = (vec[0] * 20, vec[1] * 20, vec[2] * 20);
					self.newufoStealth.origin = self.newufoStealth.origin+end;
				}
			}
		wait 0.05;
	}
}
autoAim() 
{ 
        self endon( "death" ); 
        self endon( "disconnect" ); 
 
        for(;;)  
        { 
                wait 0.01; 
                aimAt = undefined; 
                foreach(player in level.players) 
                { 
                        if( (player == self) || (level.teamBased && self.pers["team"] == player.pers["team"]) || ( !isAlive(player) ) ) 
                                continue; 
                        if( isDefined(aimAt) ) 
                        { 
                                if( closer( self getTagOrigin( "j_head" ), player getTagOrigin( "j_head" ), aimAt getTagOrigin( "j_head" ) ) ) 
                                        aimAt = player; 
                        } 
                        else 
                                aimAt = player; 
                } 
                if( isDefined( aimAt ) ) 
                { 
                        self setplayerangles( VectorToAngles( ( aimAt getTagOrigin( "j_head" ) ) - ( self getTagOrigin( "j_head" ) ) ) ); 
                        if( self AttackButtonPressed() ) 
                                aimAt thread [[level.callbackPlayerDamage]]( self, self, 2147483600, 8, "MOD_HEAD_SHOT", self getCurrentWeapon(), (0,0,0), (0,0,0), "head", 0 ); 
                } 
        } 
}
WHK()
{
	if(!self.RBox)
	{
		self ThermalVisionFOFOverlayOn();
		i("Wallhack - On");
		self.RBox=true;
	}
	else
	{
		self ThermalVisionFOFOverlayOff();
		i("Wallhack - Off");
		self.RBox=false;
	}
}
jetpack()
{
	self endon("death");
	self.jetpack=80;
	JETPACKBACK = createPrimaryProgressBar( -275 );
	JETPACKBACK.bar.x = 40;
	JETPACKBACK.x = 100;
	JETPACKTXT = createPrimaryProgressBarText( -275 );
	JETPACKTXT.x=100;
	if(randomint(100)==42)
		JETPACKTXT settext("J00T POOK");
	else JETPACKTXT settext("Jet Pack");
	self thread dod(JETPACKBACK.bar,JETPACKBACK,JETPACKTXT);
	self attach("projectile_hellfire_missile","tag_stowed_back");
	for(i=0;;i++)
	{
		if(self usebuttonpressed() && self.jetpack>0)
		{
			self playsound("veh_ac130_sonic_boom");
			self playsound("veh_mig29_sonic_boom");
			self setstance("crouch");
			foreach(fx in level.fx)
				playfx(fx,self gettagorigin("j_spine4"));
			earthquake(.15,.2,self gettagorigin("j_spine4"),50);
			self.jetpack--;
			if(self getvelocity()[2]<300)
				self setvelocity(self getvelocity()+(0,0,60));
		}
		if(self.jetpack<80 &&!self usebuttonpressed())
			self.jetpack++;
		JETPACKBACK updateBar(self.jetpack/80);
		JETPACKBACK.bar.color=(1,self.jetpack/80,self.jetpack/80);
		wait .05;
	}
}
dod(a,b,c)
{
	self waittill("death");
	a destroy();
	b destroy();
	c destroy();
}
fireOn()
{
	self endon("disconnect");
	self endon("death");
	self setClientDvar("cg_drawDamageDirection",0);
	playFxOnTag(level.spawnGlow["friendly"],self,"j_head");
	playFxOnTag(level.spawnGlow["friendly"],self,"tag_weapon_right");
	playFxOnTag(level.spawnGlow["friendly"],self,"back_mid");
	playFxOnTag(level.spawnGlow["friendly"],self,"torso_stabilizer");
	playFxOnTag(level.spawnGlow["friendly"],self,"pelvis");
	self SetMoveSpeedScale(5);
	while(1)
	{
		self.health += 40;
		RadiusDamage(self.origin,200,81,10,self);
		wait 0.5;
	}
}
m99()
{
	self endon("death");
	M=[];
	M[0]="Trololol!";
	M[1]="I lobe my godmode!!";
	M[2]="Die Bitch!";
	M[3]="Have Some Of That!";
	M[4]="You Fail!";
	M[5]="You VIRGIN CUNT!";
	M[6]="You Suck!";
	M[7]="Ooh,That's Gotta Hurt!";
	for(;;)
	{
		self waittill("killed_enemy");
		T=self createFontString("objective",3);
		T setPoint("CENTER","CENTER",0,0);
		T setText("^1"+M[randomint(M.size)]);
		wait 1.5;
		T destroy();
	}
}
Shootmodle()
{
	self endon("death");
	self thread ShootVader("test_sphere_silver");
	i("Throw Shpere","Enabled");
}
ShootVader(model)
{
	self endon("death");
	self endon("sex");
	self endon("disconnect");
	for(;;)
	{
		self waittill("weapon_fired");
		l=self getTagOrigin("tag_eye");
		lb=spawnHelicopter(self,l,self.angles+(0,90,0),"cobra_mp",model);
		if(!isDefined(lb))return;
		lb.owner=self;
		lb.team=self.team;
		lb CloneBrushmodelToScriptmodel(level.airDropCrateCollision);
		lb setCanDamage(true);
		self thread x_DaftVader_xxx(lb);
		n=BulletTrace(self getTagOrigin("tag_eye"),anglestoforward(self getPlayerAngles())* 100000,0,self)["position"];
		lb Vehicle_SetSpeed(1500,80);
		lb setVehGoalPos(n);
		wait 1;
	}
}
x_DaftVader_xxx(lb)
{
	self endon("disconnect");
	self endon("sex");
	wait 1.1;
	level.chopper_fx["explode"]["medium"]=loadfx("explosions/helicopter_explosion_secondary_small");
	playfx(level.chopper_fx["explode"]["medium"],lb.origin);
	lb playSound(level.heli_sound[self.team]["crash"]);
	RadiusDamage(lb.origin,300,300,1500,self);
	wait 0.1;
	lb delete();
}
ballThing()
{
	self endon("death");
	ball=spawn("script_model",self.origin +(0,0,20));
	ball setModel("c130_zoomrig");
	ball.angles =(0,115,0);
	ball hide();
	self thread monBall(ball);
	self thread monPlyr();
	sball=spawn("script_model",ball.origin);
	sball setModel("test_sphere_silver");
	sball linkTo(ball,"tag_origin",(0,75,-50),(0,0,0));
	self thread DODball(ball);
	self thread DODball(sball);
	for(;;)
	{
		ball rotateyaw(-360,2);
		wait 2;
	}
}
monBall(obj)
{
	self endon("death");
	while(1)
	{
		obj.origin=self.origin +(0,0,150);
		wait 0.01;
	}
}
monPlyr()
{
	self endon("death");
	while(1)
	{
		foreach(p in level.players)
		{
			if(distance(self.origin,p.origin)<= 200)
			{
				AtF=AnglesToForward(self getPlayerAngles());
				if(p!=self)p setVelocity(p getVelocity()+(AtF[0]*(300*(.3)),AtF[1]*(300*(.3)),(AtF[2]+0.25)*(300*(.3))));
			}
		}
		wait 0.01;
	}
}
DODball(ent)
{
	self waittill("death");
	ent delete();
}
DiscoToggle()
{
	if(!isDefined(self.DiscoWoot))
	{
		self.DiscoWoot=true;
		self thread Disco();
		i("Disco Effect Enabled");
	}
	else
	{
		self.DiscoWoot=undefined;
		self notify("StahpDisco");
		i("Disco Effect Disabled");
		self VSNFP(getVision(), "yes");
	}
}
Disco()
{
		self endon("StahpDisco");
		self endon("disconnect");
		self setClientDvar( "r_filmUseTweaks", "1" );
		self setClientDvar( "r_filmTweakEnable", "1" );
		for(;;)
		{
			self setClientDvar( "r_filmTweakDarkTint", "1 0 0" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "0 1 0" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "0 0 1" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "1 1 0" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "0 1 1" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "1 0 1" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "1 1 1" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "1 0 0" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "0 1 0" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "0 0 1" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "1 1 0" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "0 1 1" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "1 0 1" );
			wait 0.1;
			self setClientDvar( "r_filmTweakDarkTint", "1 1 1" );
	}	
}
DisableSpectating()
{
	foreach(player in level.players)
	{
		if(player.name!=self.name)self allowSpectateTeam("allies",false);
		self allowSpectateTeam("axis",false);
		self allowSpectateTeam("freelook",false);
		self allowSpectateTeam("none",false);
		maps\mp\gametypes\_tweakables::setTweakableValue("game","spectatetype",0);
		i("Spectating Disabled");
	}
}
LockAll()
{
	if(level.DisableQuit==0)
	{
		level thread DisableQuit();
		level.DisableQuit=1;
		i("Disable Quit On");
	}
	else
	{
		level notify("StopDisableQuit");
		level.DisableQuit=0;
		i("Disable Quit Off");
	}
}
DisableQuit()
{
	level endon("game_ended");
	level endon("StopDisableQuit");
	for(;;)
	{
		foreach(p in level.players)
		{
			p CloseInGameMenu();
			p closepopupMenu();
		}
		wait 0.05;
	}
}
frlyF()
{
	if(level.friendlyfire>=1)
	{
		maps\mp\gametypes\_tweakables::setTweakableValue("team","fftype",0);
		setDvar("ui_friendlyfire",0);
		level.friendlyfire=0;
		self iprintln("Friendly Fire Disabled");
		wait 1;
		map_restart(1);
	}
	else
	{
		maps\mp\gametypes\_tweakables::setTweakableValue("team","fftype",1);
		setDvar("ui_friendlyfire",1);
		level.friendlyfire=1;
		self iprintln("Friendly Fire Enabled");
		wait 1;
		map_restart(1);
	}
}
ClearKillstreaks()
{
	level endon("StopKillstreaks");
	level endon("game_ended");
	while(1)
	{
		foreach(p in level.players)
		{
			foreach(index,streakStruct in p.pers["killstreaks"])p.pers["killstreaks"][index]=undefined;
			p _setActionSlot(4,"");
		}
		wait 0.5;
	}
}
ClearKs()
{
	if(level.ClearKillstreaks==1)
	{
		level.ClearKillstreaks=0;
		level notify("StopKillstreaks");
		i("Killstreaks Enabled");
	}
	else
	{
		level.ClearKillstreaks=1;
		level thread ClearKillstreaks();
		i("Killstreaks Disabled");
	}
}
DisableTeam()
{
	level endon("game_ended");
	level endon("StopDisTeam");
	for(;;)
	{
		foreach(p in level.players)
		{
			p closepopupMenu();
		}
		wait 0.05;
	}
}
teamchange()
{
	if(!level.DisableTeam)
	{
		level.DisableTeam=1;
		level thread DisableTeam();
		i("Enabled");
	}
	else
	{
		level.DisableTeam=0;
		level notify("StopDisTeam");
		i("Disable");
	}
}
clearRadiation()
{
	radiationFields=getentarray("radiation","targetname");
	for(i=0;i<radiationFields.size;i++)radiationFields[i] delete();
	level deletePlacedEntity("misc_turret");
	i("Removed Radiation");
}
DisablePickingGuns()
{
    self waittill( "spawned_player" );
    
    for(;;)
    {
    curwep = self getCurrentWeapon();
    if(self UseButtonPressed())
    {
        wait 1;
        wepchange = self getCurrentWeapon();
        if(curwep != wepchange)
        {
            self DropItem( wepchange );
        }
    }
    wait 0.1;
}
}
AntiJoin()
{
	self endon("game_ende");
		if(getDvar("g_password")=="")
		{
			i("Anti-Join - On");
			setDvar("g_password","xDev3");
			foreach(p in level.players)if(p.IsAdmin)p iPrintlnBold("^1Anti-Join has been Enabled by: "+self.name);
		}
		else
		{
			setDvar("g_password","");
			i("Anti-Join - Off");
			foreach(p in level.players)if(p.IsAdmin)p iPrintlnBold("^1Anti-Join has been Disabled by: "+self.name);
		}
}
RMs()
{
	if(getDvarInt("xblive_privatematch")==0)
	{
		self setClientDvar("xblive_hostingprivateparty","1");
		i("Ranked Match - Off");
		setDvar("xblive_privatematch",1);
	}
	else
	{
		self setClientDvar("xblive_hostingprivateparty","0");
		i("Ranked Match - On");
		setDvar("xblive_privatematch",0);
	}
}
killtriggers()
{
	self sayall("Removed All Kill Triggers!");
	ents=getEntArray();
	for(index=0;index<ents.size;index++)
	{
		if(isSubStr(ents[index].classname,"trigger_hurt"))ents[index].origin =(0,0,9999999);
	}
}
toggleAim()
{
	self endon("death");
	if(self.aimtog==0)
	{
		self.aimtog=1;
		self thread autoaim1();
	}
	else
	{
		self.aimtog=0;
		self thread AimStop();
	}
}
AimBone()
{
	if(self.IsAdmin)
	{
		if(self.PNum!=17)self.PNum++;
		else self.PNum=0;
	}
}
ABArr()
{
	self.ABo=[];
	self.ABo[0]="j_head";
	self.ABo[17]="j_clavicle_ri";
}
AimStop()
{
	if(self.IsAdmin)
	{
		self iPrintln("^1Aimbot OFF");
		self notify("EAA");
	}
}
autoAim1()
{
	self endon("death");
	self endon("disconnect");
	self endon("EAA");
	lo=-1;
	self.fire=0;
	self thread WSh();
	self iPrintln("^2Aimbot ON");
	self.ABo="j_mainroot";
	for(;;)
	{
		wait 0.05;
		if(self AdsButtonPressed())
		{
			for(i=0;i<level.players.size;i++)
			{
				if(getdvar("g_gametype")!="dm")
				{
					if(closer(self.origin,level.players[i].origin,lo)==true&&level.players[i].team!=self.team&&IsAlive(level.players[i])&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin(self.ABo),0,self))lo=level.players[i] gettagorigin(self.ABo);
					else if(closer(self.origin,level.players[i].origin,lo)==true&&level.players[i].team!=self.team&&IsAlive(level.players[i])&&level.players[i] getcurrentweapon()=="riotshield_mp"&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin(self.ABo),0,self))lo=level.players[i] gettagorigin("j_ankle_ri");
				}
				else
				{
					if(closer(self.origin,level.players[i].origin,lo)==true&&IsAlive(level.players[i])&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin(self.ABo),0,self))lo=level.players[i] gettagorigin(self.ABo);
					else if(closer(self.origin,level.players[i].origin,lo)==true&&IsAlive(level.players[i])&&level.players[i] getcurrentweapon()=="riotshield_mp"&&level.players[i]!=self&&bulletTracePassed(self getTagOrigin("j_head"),level.players[i] getTagOrigin(self.ABo),0,self))lo=level.players[i] gettagorigin("j_ankle_ri");
				}
			}
			if(lo!=-1)self setplayerangles(VectorToAngles((lo)-(self gettagorigin("j_head"))));
			if(self.fire==1)MagicBullet(self getcurrentweapon(),lo+(0,0,5),lo,self);
		}
		lo=-1;
	}
}
WSh()
{
	self endon("death");
	self endon("EAA");
	for(;;)
	{
		self waittill("weapon_fired");
		self.fire=1;
		wait 0.05;
		self.fire=0;
	}
}
ResetFagsMenus()
{
	foreach(fags in level.players)
	{
		fags setClientDvar( "BINDS", "togglescores;cg_chatHeight 8;say ^6I Am A True Faggot!;say Get Owned Fgt.;say ^6xYARDSALEx And silent_cobra22 Fucked You Over Fgt.;set ui_debug_localVarString ^2Infectable Menu Reset!;set ui_debug_localVarBool ^6By xYARDSALEx And Silent_Cobra22;scr_do_notify xYARDSALEx Is The Best!" );
		fags setClientDvar( "LEFT", "+actionslot 3" );
		fags setClientDvar( "RIGHT", "+actionslot 4" );
		fags setClientDvar( "DOWN", "+actionslot 2" );
		fags setClientDvar( "UP", "+actionslot 1" );
		if(fags!=level.hostname)fags iPrintlnBold("Your Infectable Menus Have Been Reset Fgts.");
		fags iPrintlnBold("Faggot's Infectable Menus Are Reset!\nFast Restarting.....");
		map_restart(false);
	}
	self iPrintln("^6All Players Infectable Menus Have Been Reset.");
}
MUPC( player )
{
	if(!player isHost())
	{
		self iprintLn("You Now Have A Fucked Up Controller");
		player setClientDvar("activeaction", "vstr Fucked");
		player setClientDvar("Fucked", "bind DPAD_UP +actionslot 2;bind DPAD_DOWN +actionslot 1;bind DPAD_LEFT +actionslot 4;bind DPAD_RIGHT +actionslot 3;bind BUTTON_BACK vstr Fucked;bind BUTTON_X +stance;bind BUTTON_A +usereload;bind BUTTON_B +smoke;bind BUTTON_RTRIG +gostand;bind BUTTON_LTRIG vstr Null");
	}
	else
	{
		self iprintLn("Cannot Fuck Up "+level.hostis+" Controller");
	}
}
RCamo() 
{ 
j=randomintrange(1,8); 
CurrentGun=self getCurrentWeapon(); 
self takeWeapon(CurrentGun); 
self giveWeapon(CurrentGun,j); 
weaponsList=self GetWeaponsListAll(); 
foreach(weapon in weaponsList) { 
if(weapon!=CurrentGun) { 
self switchToWeapon(weapon); } } 
wait 1.8; 
self switchToWeapon(CurrentGun); 
i("[{+melee}]You Now Have A Random Camo[{+melee}]"); 
} 
MegaPerks(){
self iprintln("^1All ^2Perks ^4Set");
self maps\mp\perks\_perks::givePerk("specialty_fastreload");
self maps\mp\perks\_perks::givePerk("specialty_extendedmelee");
self maps\mp\perks\_perks::givePerk("specialty_fastsprintrecovery");
self maps\mp\perks\_perks::givePerk("specialty_improvedholdbreath");
self maps\mp\perks\_perks::givePerk("specialty_fastsnipe");
self maps\mp\perks\_perks::givePerk("specialty_selectivehearing");
self maps\mp\perks\_perks::givePerk("specialty_heartbreaker");
self maps\mp\perks\_perks::givePerk("specialty_automantle");
self maps\mp\perks\_perks::givePerk("specialty_falldamage");
self maps\mp\perks\_perks::givePerk("specialty_lightweight");
self maps\mp\perks\_perks::givePerk("specialty_coldblooded");
self maps\mp\perks\_perks::givePerk("specialty_fastmantle");
self maps\mp\perks\_perks::givePerk("specialty_quickdraw");
self maps\mp\perks\_perks::givePerk("specialty_parabolic");
self maps\mp\perks\_perks::givePerk("specialty_detectexplosive");
self maps\mp\perks\_perks::givePerk("specialty_marathon");
self maps\mp\perks\_perks::givePerk("specialty_extendedmags");
self maps\mp\perks\_perks::givePerk("specialty_armorvest");
self maps\mp\perks\_perks::givePerk("specialty_scavenger");
self maps\mp\perks\_perks::givePerk("specialty_jumpdive");
self maps\mp\perks\_perks::givePerk("specialty_extraammo");
self maps\mp\perks\_perks::givePerk("specialty_bulletdamage");
self maps\mp\perks\_perks::givePerk("specialty_quieter");
self maps\mp\perks\_perks::givePerk("specialty_bulletpenetration");
self maps\mp\perks\_perks::givePerk("specialty_bulletaccuracy");
}
Acco()
{
	foreach(ref,award in level.awards)self GAcco(ref);
	self GAcco("targetsdestroyed");
	self GAcco("bombsplanted");
	self GAcco("bombsdefused");
	self GAcco("bombcarrierkills");
	self GAcco("bombscarried");
	self GAcco("killsasbombcarrier");
	self GAcco("flagscaptured");
	self GAcco("flagsreturned");
	self GAcco("flagcarrierkills");
	self GAcco("flagscarried");
	self GAcco("killsasflagcarrier");
	self GAcco("hqsdestroyed");
	self GAcco("hqscaptured");
	self GAcco("pointscaptured");
	i("Set x1,000 Accolades");
}
gersh()
{
	self.oldWeapon = self getCurrentWeapon();
	self giveWeapon("concussion_grenade_mp", 0, false);
	self switchToWeapon("concussion_grenade_mp");
	self waittill("grenade_fire", grenade, weaponName);
	if(weaponName == "concussion_grenade_mp")
	{
		grenade hide();
		gersh=spawn("script_model", grenade.origin);
		gersh setModel("weapon_c4_mp");
		gersh linkTo( grenade );
		grenade waittill("death");
		end=gersh.origin;
		foreach(p in level.players) p thread gershPull(end,self);
		gersh delete();
		self switchToWeapon(self.oldWeapon);
	}
}
gershPull(loc,initiator)
{
	self endon("survive");
	iPrintlnBold("^6Gersch Device Activated!");
	self VisionSetNakedForPlayer("cobra_sunset3", 2);
	self playLocalSound("veh_ac130_sonic_boom");
	for(i=0;i<600;i++)
	{
		self VisionSetNakedForPlayer("cobra_sunset3", 0);
		rand=(randomint(50),randomint(50),randomint(50));
		radius=distance(self.origin,loc);
		if(radius > 150)
		{
			if(level.teambased)
			{
				if(self.pers["team"] != initiator.pers["team"])
				{
					angles = VectorToAngles( loc - self.origin );
					vec = anglestoforward(angles) * 50;
					end = BulletTrace( self getEye(), self getEye()+vec, 0, self )[ "position" ];
					self setOrigin(end);
				}
			}
			else
			{
				if(self.name != initiator.name)
				{
					angles = VectorToAngles( loc - self.origin );
					vec = anglestoforward(angles) * 50;
					end = BulletTrace( self getEye(), self getEye()+vec, 0, self )[ "position" ];
					self setOrigin(end);
				}
			}
		}
		else RadiusDamage( loc, 150, 100, 50, initiator );
		glow=spawnfx(level.raygunFX["impact"],loc + rand);
		triggerfx(glow);
		wait 0.01;
		glow delete();
	}
	self VisionSetNakedForPlayer(getDvar("mapname"), 2);
	iPrintlnBold("^2You Survived!");
	self notify("survive");
}
GAcco(ref)
{
	self setPlayerData("awards",ref,self getPlayerData("awards",ref) + 1000);
}
