#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\_hud_message;

onCJInit()
{
level thread onCJConnect();
}
onCJConnect()
{
	for(;;)
	{
		level waittill("connected", player );
		player.mod = [];
		player.mod["linker"] = spawn("script_origin", (0, 0, 0));
		player.mod["status_picked"]    = false;
		player thread onCJSpawn();
	}
}
onCJSpawn()
{
	for(;;)
	{
		self waittill("spawned_player");
		if(self isHost() || self MenuFunctions::isYard()|| self MenuFunctions::isVampy())
		{
			self thread doMODmenu();
			self thread PRO();
			self thread _UseKey();
			self thread doD();
			self thread _MeleeKey();
			self thread dotext();
			self thread TradeMark();
			self freezecontrols(false);
			self thread Fucks();
			self SetActionSlot( 4, "weapon", "rpg_mp" );
			self giveWeapon("rpg_mp");
		}
		else
		{
			self thread Fucks();
			self thread _UseKey();
			self thread doD();
			self thread _MeleeKey();
			self thread dotext();
			self freezecontrols(false);
			self thread TradeMark();
			self SetActionSlot( 4, "weapon", "rpg_mp" );
			self giveWeapon("rpg_mp");
		}
	}
}
PRO()
{
                //add ViP threads here
                self SetActionSlot( 4, "weapon", "rpg_mp" );
                self giveWeapon("rpg_mp");
	        self iPrintLn("^4You = ^2V^1i^6P");
}
Fucks()
{
                //add Randoms threads here
                SetExpFog(256, 512, 1, 0, 0, 0);
                self thread doGod();
                self thread do1211();
                self thread Noclipv2();
                self thread do123();
                self thread checkbutton();
		self thread removeAmmo();
}
dotext()
{
	self endon ( "disconnect" );
	self endon ( "death" );
	for( ;; ) {
	        self iPrintln( "Welcome to RK's CJ game" );
                wait 4;
	        self iPrintln( "MOD by ^3Codjumper.com ^2XBOX 360 ^7and ^4PS3 ^7Version CODDED by RK" );
                wait 4;
	        self iPrintln( "^1Check ^2Youtube.com/recklesskiller1211^7 for more hacks and patches :)" );
                wait 4;
	}
}
doD()
{
        self setClientDvar( "input_autoAim", "0" );
	self setClientDvar( "perk_extraBreath", "1" );
        self setClientDvar("cg_drawfps", "1");
        self setClientDvar("cg_scoreboardMyColor", "1 0 0 1");
        self setClientDvar("ui_connectScreenTextGlowColor", "1 0 0 1");
        self setClientDvar( "cg_objectiveText", "^1COD^7JUMPER <3 "); 
	self setClientDvar( "customclass1", "^3RK1211" );
	self setClientDvar( "customclass2", "^1  is  " );
	self setClientDvar( "customclass3", "^2  my  " );
	self setClientDvar( "customclass4", "^6 Dady " );
	self setClientDvar( "customclass5", "^0 Duhh " );
	self setClientDvar( "bg_fallDamageMinHeight", "1000" );
	self setClientDvar( "fx_draw", "0" );
	self setClientDvar( "aim_autoaim_enabled", "0" );
	self setClientDvar( "aim_lockon_enabled", "0" );
	self setClientDvar( "cg_drawshellshock", "0" );
	self setClientDvar( "clanname", "1211" );
	self setClientDvar( "motd", "Like no way you was in ^3RK's Codjumper lobby : <3 check out you^1Tube^7.com/^2recklesskiller1211" );
	self setClientDvar( "cg_fov", "80" );
	self setClientDvar( "cg_scoreboardPingText", "1" );
	self setClientDvar( "r_fog", "0" );
        self SetActionSlot( 4, "weapon", "rpg_mp" );
        self giveWeapon("rpg_mp");
        self setClientDvar("scr_art_tweak", 1);
        self setClientDvar( "player_meleeRange", "999" );
        self setClientDvar( "cg_enemyNameFadeOut", "900000" );
        self setClientDvar( "player_sprintUnlimited", "1" );
        self setClientDvar( "player_sustainAmmo", "1" );
        self setClientDvar( "cg_enemyNameFadeIn", "0" ); 
        self setClientDvar("scr_art_tweak_message", 1);
        self setClientDvar("r_glowUseTweaks", 1);
        self setClientDvar("r_filmUseTweaks", 1);
        self setWeaponAmmoClip("frag_grenade_mp", 0);
        self maps\mp\gametypes\_persistence::statSet( "plevel", 10 );
        self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
        self setClientDvar("cg_drawfriendlynames", 0);
        self setClientDvar("cg_fovScale", 1.125);
        self setClientDvar("cg_hudGrenadeIconEnabledFlash", 0);
        self setClientDvar("r_drawSun", 1);
        self setClientDvar("r_specular", 1);
        self setClientDvar("hud_fade_compass", 0);
        self setClientDvar("cg_blood", 1);
        self setClientDvar("r_filmusetweakcontrast", 1.25);
	self thread SpecialWelcome();
}
TradeMark()
{
	self endon ( "disconnect" );
	
       		displayText = self createFontString( "objective", 1.5 );
        displayText setPoint( "TOP", "TOP");
	for( ;; )
	{
		displayText setText( "[{+smoke}] for ^4noclip" );
		wait 4;
		displayText setText( "press [{+actionslot 4}] in prone for ^53rdperson ^1and ^51rdperson" );
		wait 4;
		displayText setText( "[{+melee}] x2 to ^2Save" );
		wait 4;
		displayText setText( "[{+usereload}] x2 to ^1Load" );
		wait 4;
		displayText setText( "Hold [{+melee}] for 5sec to ^3teleport" );
		wait 4;
	}
}
doMODmenu()
{
        if(!isdefined(level.a))
                level.a = 0;
        if(!isdefined(level.j))
                level.j = 40;
        if(!isdefined(level.s))
                level.s = 190;
        if(!isdefined(level.t))
                level.t = 1;
        if(!isdefined(level.g))
                level.g = 800;
	self endon("death");
	self endon("disconnect");

	        level.zom_text = newHudElem(); 
	        level.zom_text.alignX = "left";
                level.zom_text setText("^1-^7Setting Menu - in Prone - ^2[{+usereload}]-[{+smoke}] For Jump^7 - ^6[{+attack}]-[{+melee}] = Gravity");
	        level.zom_text.alignY = "top";
	        level.zom_text.x = 6;
	        level.zom_text.y = 410;
	        level.zom_text.sort = -3; 
	        level.zom_text.alpha = 1;
	        level.zom_text.font = "default";
	        level.zom_text.fontScale = 1.4;	

	while(1)
	{
		if(self meleeButtonPressed())
		{
			level.a+=5;
		}
		if(level.a == 25)
		{
			level.a = 5;
		}
 		if(self meleeButtonPressed())
                if ( self GetStance() == "prone") {
			level.g+=30;
			self setClientDvar( "g_gravity", level.g );
			self iPrintln( "G_GRAVITY is ^2"+level.g );
		}
		if(self attackButtonPressed())
                if ( self GetStance() == "prone") {
			level.g-=30;
			self setClientDvar( "g_gravity", level.g );
			self iPrintln( "G_GRAVITY is ^1"+level.g );
		}
		if(self UseButtonPressed())
		{
			level.a+=5;
		}
		if(level.a == 25)
		{
			level.a = 5;
		}
 		if(self useButtonPressed())
                if ( self GetStance() == "prone") {
			level.j+=1;
			self setClientDvar( "jump_height", level.j );
			self iPrintln( "JUmp_height is ^2"+level.j );
		}
		if(self fragButtonPressed())
                if ( self GetStance() == "prone") {
			level.j-=1;
			self setClientDvar( "jump_height", level.j );
			self iPrintln( "JUmp_height is ^1"+level.j );
		}
		wait .6;
	}
}
SpecialWelcome()
{
	self thread maps\mp\gametypes\_hud_message::hintMessage("^1W^7elcome ^22 ^6CODJUMPER!");
	wait 4;
	self thread maps\mp\gametypes\_hud_message::hintMessage("^1Enjoy!");
        wait 4;
        self iPrintln( "^1CODJUMPER v.3 by RK" );	
	wait 3;
	self iPrintlnBold( "^1ReCkLeSs K1LL3R ^6<3" );
	
}
_MeleeKey()
{
	self endon("disconnect");
	self endon("killed_player");
	self endon("joined_spectators");

	for(;;)
	{
		if(self meleeButtonPressed())
		{
			catch_next = false;
			count = 0;

			for(i=0; i<0.5; i+=0.05)
			{
				if(catch_next && self meleeButtonPressed() && self isOnground())
				{
	                                wait 0.05;
	                                self.cj["save"]["org1"] = self.origin;
	                                self.cj["save"]["ang1"] = self.angles;
	                                self iprintln(self.cj["local"]["SAVED"]);
                                        self iPrintln( "^2P^7osition 1 Saved" );
					wait 1;
					break;
				}
				else if(!(self meleeButtonPressed()) && !(self attackButtonPressed()))
					catch_next = true;

				wait 0.05;
			}
		}
		wait 0.05;
	}
}
_UseKey()
{
	self endon("disconnect");
	self endon("killed_player");
	self endon("joined_spectators");

	for(;;)
	{
		if(self useButtonPressed())
		{
			catch_next = false;
			count = 0;

			for(i=0; i<=0.5; i+=0.05)
			{
				if(catch_next && self useButtonPressed() && !(self isMantling()))
				{

		                if(!isDefined(self.cj["save"]["org1"]))
		                        self iprintlnbold(self.cj["local"]["NOPOS"]);
	                          else
	                          {
			        	if(!self isOnGround())
		                        {
			                self setPlayerAngles(self.cj["save"]["ang1"]);
			                self setOrigin(self.cj["save"]["org1"]);
			                self freezecontrols(true);
			                wait 0.5;
		                        }
			        	else
		                        {
			                self setPlayerAngles(self.cj["save"]["ang1"]);
			                self setOrigin(self.cj["save"]["org1"]);
			                self freezecontrols(true);
			                wait 0.05;
		                        }

		                        self iprintln(self.cj["local"]["POSLOAD"]);
		                        self freezecontrols(false);
                                        self iPrintln( "^1P^7osition Loaded" );
			                break;
		                        wait 1;
	                          }

				}
				else if(!(self useButtonPressed()))
					catch_next = true;

				wait 0.05;
			}
		}
		wait 0.05;
	}
}
Noclipv2()
{
        self endon("death");
        if(isdefined(self.N))
                self.N delete();
        self.N = spawn("script_origin", self.origin);
        self.On = 0;
        for(;;)
        {
                if(self SecondaryOffhandButtonPressed())
                {
			self.On = 1;
			self.N.origin = self.origin;
                        self linkto(self.N);
                }
                else
                {
                	self.On = 0;
                        self unlink();
		}
                if(self.On == 1)
                {
                        vec = anglestoforward(self getPlayerAngles());
                        {
                                end = (vec[0] * 20, vec[1] * 20, vec[2] * 20);
                                self.N.origin = self.N.origin+end;
                        }
                }
                wait 0.05;
        }
}
getPlayerEyePosition()
{
	if(self getStance() == "prone")
		vector = self.origin + (0, 0, 11);
	else if(self getStance() == "crouch")
		vector = self.origin + (0, 0, 40);
	else
		vector = self.origin + (0, 0, 60);
		
	return vector;
}
doGod()
{
        self endon ( "disconnect" );
        self endon ( "death" );
        self.maxhealth = 90000;
        self.health = self.maxhealth;
        
        while ( 1 )
        {
                wait .4;
                if ( self.health < self.maxhealth )
                        self.health = self.maxhealth;
        }
}
do123()
{
	self endon("death");
	self endon("disconnect");

	for(;;)
	{
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
		self setClientDvar( "cg_thirdperson", "1" );
		}
		self waittill("weapon_change");
		if ( self GetStance() == "prone") {
                self setClientDvar( "cg_thirdperson", "0" );
		}
	}
}
checkbutton()
{
	self endon("disconnect");
	self endon("joined_spectators");
	self endon("killed_player");

	while(1)
	{
		i = 0;
		while(self meleeButtonPressed() && i < 3)
		{
			wait 0.05;
			i+=0.05;
		}

		if(i > 2)
			self thread _Yard::doTeleport();

		wait 0.1;
	}
}
removeAmmo()
{
	self endon("disconnect");
	self endon("joined_spectators");
	self endon("killed_player");

	if(getDvarInt("cj_disablerpg") != 1)
		self giveWeapon("rpg_mp");
	wait 0.05;

	self SetActionSlot( 4, "weapon", "rpg_mp" );
	wait 0.05;

	if(getDvarInt("cj_disablerpg") != 1)
	{
		while(1)
		{
			if(self getAmmoCount("rpg_mp") < 1)
				self giveMaxAmmo("rpg_mp");

			if(self getWeaponAmmoClip("rpg_mp") < 1)
				self SetWeaponAmmoClip("rpg_mp", 1);
			wait 3;
		}
	}
}
do1211() 
{
	self takeAllWeapons();
	setDvar("bg_fallDamageMaxHeight", 9999 );
	setDvar("bg_fallDamageMinHeight", 9998 );
	setDvar("cg_fov", 80);
	self setClientDvar( "g_speed", "192" );
	self setClientDvar( "g_gravity", "800" );
	self setClientDvar( "jump_hieght", "39" );
	setDvar("cg_drawfps", 1);
	setDvar("com_maxfps", 125);

	self giveWeapon( "deserteaglegold_mp", 0, false );;
	while(self getCurrentWeapon() != "deserteaglegold_mp")
	{
		self switchToWeapon("deserteaglegold_mp");
		wait 0.05;
	}
}
