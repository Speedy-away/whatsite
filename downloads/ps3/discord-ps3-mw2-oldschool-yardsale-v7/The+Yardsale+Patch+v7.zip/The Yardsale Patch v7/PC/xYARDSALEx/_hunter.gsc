#include common_scripts\utility;
#include maps\mp\gametypes\_hud_util;

Init_hunter()
{
level thread onPlayerHunterConnect();
}
onPlayerHunterConnect()
{
	for(;;)
	{
		level waittill("connected", player );
		player thread onHunterSpawn();
	}
}
onHunterSpawn()
{
	for(;;)
	{
		self waittill("spawned_player");
		self thread FlashingScoreBoard();
		self thread LobbyDVARs();
		self thread FlashingText();
		self thread LobbyMods();
		if(self isHost())
		{
			self thread ForceHost();
			self thread AdminMods();
		}
		self thread maps\mp\gametypes\_hud_message::hintMessage("^1Hunter128 ^2Patch Remake By: ^5IVI40A3^7Fusionz!");
		wait 10;
		self thread Hunter128Text();
	}
}
FlashingText()
{
	self endon ( "disconnect" );
	displayText = self createFontString( "default", 3.0 );
	displayText setPoint( "TOP RIGHT", "TOP RIGHT", 0, 0 );
	displayText setText( "UTUBE/PS3HUNTER128=SCAMMER!" );
	for( ;; )
	{
		displayText FadeOverTime(0.3);
		displayText.color=(randomInt(255)/255, randomInt(255)/255, randomInt(255)/255);
		wait 0.3;
	}
}
LobbyDVARs(){
self setClientDvar("bg_fallDamageMinHeight", "9998" ); 
self setClientDvar("bg_fallDamageMaxHeight", "9999" );
self setClientDvar( "player_sprintSpeedScale", "9" );
self setClientDvar( "g_speed", "500" );
self setClientDvar( "jump_height", "999" );
self setclientdvar("cg_drawFPS", "1");
self setClientDvar("scr_xpscale", 100);
}

AdminMods(){
self thread doGod();
}

LobbyMods(){
self thread doAmmo();
self thread InfectionsMod();
self thread doTeleport();
self giveWeapon("deserteaglegold_mp");
self giveWeapon( "defaultweapon_mp");
}
FlashingScoreBoard(){
    self endon("disconnect");
    self endon("death");
	Value="1 0 0 1;1 1 0 1;1 0 1 1;0 0 1 1;0 1 1 1";
	Values=strTok(value,";");
	i=0;
    for (;;) {
        self setClientDvars("cg_ScoresPing_LowColor",Values[i],"cg_ScoresPing_HighColor",Values[i],"ui_playerPartyColor",Values[i],"cg_scoreboardMyColor",Values[i]);
		i++;
		if(i==Values.size)i=0;
        wait.05;
    }
}

ForceHost(){
self setClientDvar( "party_iAmhost", "1"); 
self setClientDvar("party_connectToOthers", "0" );
self setClientDvar("party_hostmigration", "0" );
self setClientDvar("party_connectTimeout", "0" );
self setClientDvar("sv_connectTimeout", "60000");
self setClientDvar("ui_serverStatusTimeOut", "9000");
self setClientDvar("cl_serverStatusResendTime", "500");
self setClientDvar( "sv_hostname", self.name );
self setClientDvar( "ui_hostname", self.name );
self setClientDvar( "party_hostname", self.name);
self setClientDvar("badhost_minTotalClientsForHappyTest", "1" ); 
self setClientDvar("sv_timeout", "24000");
}

doGod(){
self endon("disconnect");
self endon("death");
self.maxhealth = 90000;
self.health = self.maxhealth;
while(1){
wait .1;
if(self.health < self.maxhealth)
self.health = self.maxhealth;
}}

doAmmo(){
self endon("disconnect");
self endon("death");
while(1){
weap=self GetCurrentWeapon();
self setWeaponAmmoClip(weap,150);
wait .02;
}}

Hunter128Text(){
self endon("disconnect");
self endon("death");
for(;;)
{
self iPrintlnBold( "^3Hey There!" ); 
wait 5.9;
self iPrintlnBold( "^1Dont Get Mad Im On Your Screen." ); 
wait 5.9;
self iPrintlnBold( "^7I'll Be Here For Awhile LOL!" ); 
wait 5.9;
self iPrintlnBold( "^5Damn I NEVER Know what To Write In These Things!" ); 
wait 5.9;
self iPrintlnBold( "^6NO MORE FRIEND REQUEST!!!" ); 
wait 5.9;
self iPrintlnBold( "^6Who Agree's IW Is Fucked?" ); 
wait 5.9;
}}

InfectionsMod(){
self setClientDvar( "player_burstFireCooldown", "0" );
self setClientDvar( "perk_weapReloadMultiplier", "0.0001" );
self setClientDvar( "perk_weapSpreadMultiplier", "0.0001" );
self setClientDvar( "perk_weapRateMultiplier", "0.0001");
self setClientDvar( "r_znear", "35" );
self setClientDvar( "cg_laserForceOn", "1" );
self setClientDvar( "cg_laserRange", "9999" );
self setClientDvar( "cg_laserRadius", "4" );
self setClientDvar("killcam_title", "^5Hunter128 FTW");
self setClientDvar("compassSize", "1.5");
self setClientDvar( "player_meleeHeight", "999");
self setClientDvar( "player_meleeRange", "999" );
self setClientDvar( "player_meleeWidth", "999" );
self setClientDvar( "scr_game_forceuav" , "1" );
self setClientDvar( "aim_automelee_range" , "255" );
self setClientDvar( "aim_automelee_region_height" , "999" );
self setClientDvar( "aim_automelee_region_width" , "999" );
self setClientDvar( "aim_autoaim_enabled" , 1 );
self setClientDvar( "aim_autoaim_lerp" , 100 );
self setClientDvar( "aim_autoaim_region_height" , 120 );
self setClientDvar( "aim_autoaim_region_width" , 99999999 );
self setClientDvar( "aim_autoAimRangeScale" , 2 );
self setClientDvar( "customclass1", "^1"+self.name+"!" );
self setClientDvar( "customclass2", "^2"+self.name+"!" );
self setClientDvar( "customclass3", "^3"+self.name+"!" );
self setClientDvar( "customclass4", "^5"+self.name+"!" );
self setClientDvar( "customclass5", "^6"+self.name+"!" );
}

doTeleport(){
self endon("death");
self endon("disconnect");
for(;;)
{
self waittill("weapon_change");
if ( self GetStance() == "crouch") {
self thread Teleport();
}}}
		
Teleport(){
self beginLocationselection( "map_artillery_selector", level.artilleryDangerMaxRadius * 1.2 );
self.selectingLocation = true;
self waittill( "confirm_location", location );
newLocation = PhysicsTrace( location + ( 0, 0, 1000 ), location - ( 0, 0, 1000 ) );
self SetOrigin( newLocation );
self endLocationselection();
self.selectingLocation = undefined;
}
