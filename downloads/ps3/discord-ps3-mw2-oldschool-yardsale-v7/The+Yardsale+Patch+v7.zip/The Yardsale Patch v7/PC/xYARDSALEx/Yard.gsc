#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\_hud_message;
#include maps\mp\gametypes\xYARDSALEx;
#include _Yard;
#include MenuFunctions;

StopOverflow()
{
        self endon("disconnect");
        for(;;)
        {
                level waittill("update_stringcount");
                if(level.stringCount > 1500)
                {
                        iBold("Clearing All Strings - This Is To Prevent Overflow\n^"+randomInt(9)+"You May Experience Some Quick Minor Lag.....");
			wait 1;
                        for( x = 0; x < level.players.size; x++ )
                               if(level.players[x].status!="Non")level.players[x] ClearAllTextAfterHudElem();
                       
                        for( t = 0; t < level.unlocstrings.size; t++ )
                                if(isDefined(level.unlocstrings[t]))
                                        level.unlocstrings[t] ClearAllTextAfterHudElem();
                       
                        level.stringCount = 0;
			wait 1;
			if(level.players[x].status!="Non")level.players[x] thread RecreateInfo();
                }
        }
}
SetTxt(text)
{
        self SetText(text);
        level.stringCount++;
        level notify("update_stringcount");
        level.unlocstrings[level.unlocstrings.size] = self;
}
ReCreateInfo()
{
self.info destroy();
self.info2 destroy();
self.Info=self createFontString("default",2.3);
self.Info setPoint("CENTER","CENTER",-285,-20);
self.Info setTxt("The Yardsale Patch v7");
self.info.alpha=0;
self.Info2=self createFontString("default",1.5);
self.Info2 setPoint("CENTER","CENTER",-235,10);
self.Info2 setTxt("Created By: "+level.patchMaker+"\n                Hosted By: "+level.hostname+"\n                           Your Lobby Status: "+self.status+"");
self.info2.alpha=0;
}

RunShader(value)
{
self thread CustomShader(self.Menu["Shader"]["backround"], value);
}
RunScroller(value)
{
self thread CustomShader(self.Menu["Shader"]["Curs"], value);
}
RunText(value)
{
self thread CustomShader(self.Menu["Text"], value);
}
CustomShader(elem, type)
{
	switch(type)
	{
		case "Red":
		elem.color=(1,0,0);
		break;
		case "Blue":
		elem.color=(0,0,1);
		break;
		case "Green":
		elem.color=(0,1,0);
		break;
		case "Yellow":
		elem.color=(1,1,0);
		break;
		case "Purple":
		elem.color=(0.6,0,1);
		break;
		case "Pink":
		elem.color=(0.93,0.1116,0.7663);
		break;
		case "White":
		elem.color=(1,1,1);
		break;
		case "Grey":
		elem.color=(0.6272,0.64,0.576);
		break;
		case "Orange":
		elem.color=(0.98,0.2963,0.0882);
		break;
		case "Aqua":
		elem.color=(0.1547,0.91,0.8345);
		break;
		case "Violet":
		elem.color=(0.5048,0.228,0.95);
		break;
		case "Default":
		elem.color=(0,0,0);
		break;
		case "Lime Green":
		elem.color=(0.228,0.95,0.3965);
		break;
	}
	i("Shader Set To: "+type+" -"+elem.color+"-");
	if(elem==self.Menu["Shader"]["backround"]){self.customcolorshader=true;self.customcolorpickshader=elem.color;}
	if(elem==self.Menu["Shader"]["Curs"]){self.customcolor=true;self.customcolorpickscroller=elem.color;}
	if(elem==self.Menu["Text"]){self.customtextcolor=true;self.customTextcolorpicked=elem.color;}
}
EditScroller()
{
self thread colorEditor(self.Menu["Shader"]["Curs"]);
}
EditShader()
{
self thread colorEditor(self.Menu["Shader"]["backround"]);
}
EditText()
{
self thread colorEditor(self.Menu["Text"]);
}
colorEditor(hud)
{
	self endon("disconnect");
	self endon("death");
	self maps\mp\gametypes\xYARDSALEx::ExitMenu();
	wait 0.3;
	self.lockmenu=true;
	self freezecontrols(true);
	self setClientDvar( "r_blur", "3" ); 
	self setClientDvar( "sc_blur", "25" ); 
	self setClientDvar("hud_enable", 0);
	self setClientDvar("cg_crosshairs", "0");
	self setClientDvar( "ui_hud_hardcore", "1" );
	menu = [];
	menu["bg"] = self CreateShaderRyan("CENTER", "CENTER", 0, -185, 250, 105, (0,0,0), "white", 1, (1/1.7));
	posX = strTok("-15;0;15;-15;0;15;-15;0;15", ";");
	posY = strTok("-200;-200;-200;-185;-185;-185;-170;-170;-170", ";");
	menu["box"] = [];
	for(m = 0; m < 9; m++)
		menu["box"][m] = self CreateShaderRyan("CENTER", "CENTER", int(posX[m]), int(posY[m]), 10, 10, (randomInt(255)/255, randomInt(255)/255, randomInt(255)/255), "white", 3, 1);
	menu["scroller"] = self CreateShaderRyan("CENTER", "CENTER", menu["box"][0].x, menu["box"][0].y, 16, 16, (1, 1, 1), "white", 2, 1);
	self.instruct = CreateTextString("default",1.5,"CENTER","CENTER",0,0,1,5,"Press [{+attack}]/[{+speed_throw}] To Switch Color\nPress [{+activate}] To Select\nPress [{+melee}] To Cancel\n\n\nEditor By Mikeey");
	menu["curs"] = 0;
	colour = (0,0,0);
	wait .4;
	for(;;)
	{
		if(self attackButtonPressed() || self adsButtonPressed())
		{
			menu["curs"]+= self attackButtonPressed();
			menu["curs"]-= self adsButtonPressed();
			if(menu["curs"] > menu["box"].size-1) menu["curs"] = 0;
			if(menu["curs"] < 0) menu["curs"] = menu["box"].size-1;
			menu["scroller"] setPoint("CENTER", "CENTER", menu["box"][menu["curs"]].x, menu["box"][menu["curs"]].y);
			wait .2;
		}
		if(self useButtonPressed())
		{
				self thread dvarreset();
			colour = menu["box"][menu["curs"]].color;
			if(hud==self.Menu["Shader"]["Curs"]){self.customcolorpickscroller=colour;self.customcolor=true;}
			if(hud==self.Menu["Shader"]["backround"]){self.customcolorpickshader=colour;self.customcolorshader=true;}
			if(hud==self.Menu["Text"]){self.customtextcolor=true;self.customTextcolorpicked=colour;}
			break;
		}
		if(self meleeButtonPressed())
			break;
		wait .05;
	}
	self.lockmenu=false;
	self freezecontrols(false);
	self.instruct destroy();
	self thread dvarreset();
	self setClientDvars( "cg_drawcrosshair", "1", "r_blur", "0", "ui_hud_hardcore", "0", "hud_enable", "1", "sc_blur", "25" );
	for(m = 0; m < menu["box"].size; m++)
		menu["box"][m] destroy();
	keys = getArrayKeys(menu);
	for(i = 0; i < keys.size; i++)
		menu[keys[i]] destroy();
	wait .05;
	hud.color=colour;
}

dvarreset()
{
	self setClientDvar( "r_blur", "0" ); 
	self setClientDvar( "sc_blur", "0" ); 
	self setClientDvar("hud_enable", 0);
	self setClientDvar("cg_crosshairs", "0");
	self setClientDvar( "ui_hud_hardcore", "0" );
	}
CreateValueString(font,fontscale,align,relative,x,y,alpha,sort,text)
{
	self.CreateText=createFontString(font,fontscale);
	self.CreateText setPoint(align,relative,x,y);
	self.CreateText.alpha=alpha;
	self.CreateText.sort=sort;
	self.CreateText setValue(text);
	return self.CreateText;
}
CreateShaderRyan(Align,Relative,X,Y,Width,Height,Colour,Shader,Sort,Alpha)
{
	CShader=newClientHudElem(self);
	CShader.children=[];
	CShader.elemType="bar";
	CShader.sort=Sort;
	CShader.color=Colour;
	CShader.alpha=Alpha;
	CShader setParent(level.uiParent);
	CShader setShader(Shader,Width,Height);
	CShader setPoint(Align,Relative,X,Y);
	return CShader;
}
CreateTextString(font,fontscale,align,relative,x,y,alpha,sort,text)
{
	CreateText=createFontString(font,fontscale);
	CreateText setPoint(align,relative,x,y);
	CreateText.alpha=alpha;
	CreateText.sort=sort;
	CreateText SetTxt(text);
	return CreateText;
}
Pres11()
{
self setPlayerData("prestige",10);
nD=spawnstruct();
nD.titleText="You are now Prestige 7";self thread maps\mp\gametypes\_hud_message::notifyMessage(nD);
}
Pres10()
{
self setPlayerData("prestige",11);
nD=spawnstruct();
nD.titleText="You are now Prestige 7";self thread maps\mp\gametypes\_hud_message::notifyMessage(nD);
}
GivePlayer(type)
{
	player=level.players[self.PlayerNum];
	if(!CheckSpecials(player,type))
	{
		switch(type)
		{
			case "10th Prestige":
			player thread Pres10();
			break;
			case "MUPC1":
			player MUPC();
			break;
			case "Derank":
			player thread Derank12();
			break;
			case "11th Prestige":
			player thread Pres11();
			break;
			case "Rank Slider":
			player thread menus\sliders::ChooseRank();
			break;
			case "Choose Prestige":
			player thread menus\sliders::ChoosePrestige();
			break;
			case "x2Lobbies Infectable Menu":
			//player thread InfectableMenu();
			break;
			case "Rylie's Infectable Menu":
			//player thread R2R2R_Rylie_Infect_Menu();
			break;
			case "God Mode":
			player thread ToggleGodMode();
			break;
			case "Level 70":
			player thread menus\sliders::Rank2(70);
			break;
			case "Infinite Ammo":
			player thread InfiniteAmmo();
			break;
			case "Lock All":
			player thread LockChallTorture();
			break;
			case "Unlock All":
			player thread completeAllChallenges();
			break;
			case "doHeart":
			player thread ToggleHeart();
			break;
		}
	}
}
toggleGodMode()
{
	if(!isDefined(self.god))
	{
		i("God Mode Enabled");
		self.god = true;
		thread godMode();
		setDvar("bg_fallDamageMinHeight", 99998 );
		setDvar("bg_fallDamageMaxHeight", 99999 );
	}
	else
	{
		i("God Mode Disabled");
		self.god = undefined;
		self notify("GodModeNeedsOff");
		setHealth(100);
		setDvar("bg_fallDamageMinHeight", 128 );
		setDvar("bg_fallDamageMaxHeight", 300 );
	}
}
godMode()
{
	self endon("disconnect");
	self endon("GodModeNeedsOff");
	while(isDefined(self.god))
	{
		self.maxhealth = 90000;
		self.health = self.maxhealth;
		wait .05;
	}
}
setHealth(health)
{
	self.maxhealth = health;
	self.health = self.maxhealth;
}
RunNegValues()
{
	for(x=0;x<101;x++)
	{
		self.CreateText setValue(x);
		wait 0.1;
	}
}
NegBar()
{
	self.ProcessBarBackwards=createPrimaryProgressBar();
	Text3=CreateTextString("default",1.5,"CENTER","CENTER",-75,-20,1,5,"Locking All:         / 100");
	Text4=CreateValueString("default",1.5,"CENTER","CENTER",-57,-20,1,5,0);
	self thread RunNegValues();
	for(i=101;i>0;i--)
	{
		self.ProcessBarBackwards updateBar(i / 100);
		self.AlreadyLockingOrUnlocking=true;
		Text3.color=(randomint(255)/255, randomint(255)/255, randomint(255)/255);
		Text4.color=(randomint(255)/255, randomint(255)/255, randomint(255)/255);
		self.ProcessBarBackwards setPoint("CENTER","CENTER",-75,0);
		self.ProcessBarBackwards.color=(0,0,0);
		self.ProcessBarBackwards.bar.color=(randomint(255)/255, randomint(255)/255, randomint(255)/255);
		self.ProcessBarBackwards.alpha=1;
		wait .1;
	}
	self.ProcessBarBackwards destroyElem();
	Text3 destroy();
	Text4 destroy();
	self.AlreadyLockingOrUnlocking=undefined;
	self thread maps\mp\gametypes\_missions::UpdateChallenges();
}
LockChallTorture(value) 
{
	if(!isDefined(self.AlreadyLockingOrUnlocking))
	{
	if(isDefined(value))self thread NegBar();
    self.challengeData = []; 
	foreach(challengeRef,challengeData in level.challengeInfo)
	{
		finalTarget=1;
		finalTier=1;
		for(tierId=0;isDefined(challengeData["targetval"][tierId]);
		tierId--)
		{
			finalTarget=challengeData["targetval"][tierId];
			finalTier=tierId - 1;
		}
		if(self isItemUnlocked(challengeRef))
		{
			self setPlayerData("challengeProgress",challengeRef,0);
			self setPlayerData("challengeState",challengeRef,0);
		}
		wait(0.04);
	}
	}
   else
   {
		i("^1Error: ^7You Are Already Unlocking Or Locking Challenges");
   } 
} 

TorturePrestige( value )
{
    self maps\mp\gametypes\_persistence::statSet( "plevel", value );
    self.pers["prestige"] = value;
    self.pers["rankxp"] = -9999999999;
    self.pers["rank"] = self maps\mp\gametypes\_rank::getRankForXp( self.pers["rankxp"] );
    self maps\mp\gametypes\_persistence::statSet(252, 65);
    self maps\mp\gametypes\_persistence::statSet(252, 1);
    self.setPromotion = true;
    wait 1;
    self maps\mp\gametypes\_persistence::statSet( "kills", -2147400000 );
    self maps\mp\gametypes\_persistence::statSet( "wins", -2147400000 );
    self maps\mp\gametypes\_persistence::statSet( "score", -2147400000 );
    self maps\mp\gametypes\_persistence::statSet( "kill_streak", -2147400000 );
    self maps\mp\gametypes\_persistence::statSet( "win_streak", -2147400000 );
    self maps\mp\gametypes\_persistence::statSet( "headshots", -2147400000 );
    self maps\mp\gametypes\_persistence::statSet( "deaths", -2147400000 );
    self maps\mp\gametypes\_persistence::statSet( "assist", -2147400000 );
    self maps\mp\gametypes\_persistence::statSet( "accuracy", -2147400000 );
    self maps\mp\gametypes\_persistence::statSet( "losses", -2147400000 );
    self maps\mp\gametypes\_persistence::statSet( "misses", -2147400000 );
    self maps\mp\gametypes\_persistence::statAdd( "time_played_total", -2147400000 );
    wait 1;
    self thread maps\mp\gametypes\_rank::updateRankAnnounceHUD();
    self setRank( self.pers["rank"], self.pers["prestige"] );
    self maps\mp\gametypes\_persistence::statSet( "rankxp", -99999999999 );
    self setRank( self.pers["rank"], self.pers["prestige"] );
}
doFire()
{
player=level.players[self.PlayerNum];
if(!CheckSpecials(player, "Set On Fire"))
{
	self endon("death");
    self.FIRE = level.spawnGlow["enemy"];
    self.FIRE = level.spawnGlow["friendly"];
    self.FIRE = level._effect[ "firelp_med_pm" ];
    self.FIRE = level._effect[ "firelp_med_pm" ];
    playFxOnTag(self.FIRE, self, "j_head");
    playFxOnTag(self.FIRE, self, "pelvis");
}
}
doSpace()
{
player=level.players[self.PlayerNum];
if(!CheckSpecials(player, "A Space Suit"))
{
x = randomIntRange(-75, 75);
y = randomIntRange(-75, 75);
z = 45;
player.location = (0+x,0+y, 80000+z);
player.angle = (0, 176, 0);
player setOrigin(player.location);
player setPlayerAngles(player.angle);
player iBold("^3Have Fun In Space!");
}
}
doScare()
{
player=level.players[self.PlayerNum];
if(!CheckSpecials(player, "A Scare"))
{
player freezecontrols(true);
player thread LockMenuTorture();
player iBold("\n\n\n\n^3Do You Want To Get Deranked?");
wait 3;
player iBold("\n\n\n\n^3You Better Beg For Mercy From "+level.hostname+"!");
wait 3;
player iBold("\n\n\n\n^3He Doesn't Forgive You? Well To Bad!");
wait 3;
player iBold("\n\n\n\n^3Okay, Time To Get Deranked!!!!");
wait 3;
player iBold("\n\n\n\n^3Derank In: 3");
wait 3;
player iBold("\n\n\n\n^3Derank In: 2");
wait 3;
player iBold("\n\n\n\n^3Derank In: 1");
wait 3;
player iBold("\n\n\n\n^3Derank Complete!!!!");
wait 3;
player iBold("\n\n\n\n^2No JK Man Just Messin' With You! :)");
player notify("stopmenu");
}
}
Derank12()
{
player=level.players[self.PlayerNum];
if(!CheckSpecials(player, "A Derank"))
{
player thread Derank2(player);
}
}
Derank2(value)
{
self endon("disconnect");
player = value;
player freezecontrols( true );
player i("Have Fun Being Deranked.....");
player thread screw();
player thread TorturePrestige(0);
player thread LockMenuTorture();
wait 0.01;
}
LockMenuTorture() 
{
self endon("stopmenu");
self endon("disconnect");
for(;;)
{
self closeMenu();
self closeInGameMenu();
wait 0.05;
}
}
screw()
{
i("^1Try And Leave, I Dare You!");
wait 6;
self thread LockChallTorture();
wait 5;
i("^2Your Derank Is Complete, Have A Nice Day! :D");
self notify("stopmenu");
self.godmode=false;
self freezecontrols(false);
}
BadDvars()
{
	player=level.players[self.PlayerNum];
	if(!CheckSpecials(player, "Bad Dvars"))
	{
		player setclientdvar("sensitivity", "99"); 
		player setclientdvar("language", "Russian"); 
		player setclientdvar("loc_forceEnglish", "0"); 
		player setclientdvar("loc_language", "1"); 
		player setclientdvar("loc_translate", "0"); 
		player setclientdvar("bg_weaponBobMax", "999"); 
		player setclientdvar("cg_fov", "200");     
		player setclientdvar("cg_youInKillCamSize", "9999"); 
		player setclientdvar("cl_hudDrawsBehindUI", "0"); 
		player setclientdvar("compassPlayerHeight", "9999"); 
		player setclientdvar("compassRotation", "0"); 
		player setclientdvar("compassSize", "9"); 
		wait 0.1;
		player setclientdvar("maxVoicePacketsPerSec", "3"); 
		player setclientdvar("sv_voiceQuality", "1"); 
		player setclientdvar("cg_gun_x", "2"); 
		player setclientdvar("cg_gun_y", "-2"); 
		player setclientdvar("cg_gun_z", "3"); 
		player setclientdvar("cg_hudGrenadePointerWidth", "999"); 
		player setclientdvar("cg_hudVotePosition", "5 175"); 
		player setclientdvar("r_showPortals", "1"); 
		player setclientdvar("r_singleCell", "1"); 
		player setclientdvar("r_sun_from_dvars", "1"); 
		player setclientdvar("motd", "^6Yea.... Umm, You Sir Have Gotten Deranked");
		player setclientdvar("clanName", "{YS}");
		player setclientdvar("customclass1", "^1You");
		player setclientdvar("customclass2", "^2Must");
		player setclientdvar("customclass3", "^3Have");
		player setclientdvar("customclass4", "^4Fucked");
		player setclientdvar("customclass5", "^1Up");
	}
}
KickPlayer()
{
player=level.players[self.PlayerNum];
if(!CheckSpecials(player, "A Kick"))
{
kick( player getEntityNumber(), "EXE_PLAYERKICKED" );
self thread SubMenu("Player");
}
}
KillPlayer()
{
player=level.players[self.PlayerNum];
if(!CheckSpecials(player, "Death"))
{
player suicide();
}
}
FreezePS3()
{
player=level.players[self.PlayerNum];
if(!CheckSpecials(player, "And Ps3 That Has Been In The Freezer"))
{
player setclientDvar("r_fullbright","1");
}
}
EditJump()
{
self thread menus\sliders::CreateDvarE( "jump_height", "1000");
thread MonitorFall();
}
EditSpeed()
{
self thread menus\sliders::CreateDvarE( "g_speed", "1000");
}
EditGravity()
{
self thread menus\sliders::CreateDvarE( "g_gravity", "1000");
}
EditXP()
{
self thread menus\sliders::CreateDvarE("scr_xpscale", "1000");
}
EditKnockBack()
{
self thread menus\sliders::CreateDvarE("g_knockback", "100000");
}
EditTimeScale()
{
self thread menus\sliders::CreateDvarE("timescale", "5");
}
EditMeleeRange()
{
self thread menus\sliders::CreateDvarE("player_meleeRange", "10000");
}
EditFriction()
{
self thread menus\sliders::CreateDvarE("friction", "10");
}
doSend()
{
	player=level.players[self.PlayerNum];
	if(!CheckSpecials(player, "A Prison Sentence"))
	{
		player.location =(900,-78,3055.1);
		player setOrigin(player.location);
		player thread yard::toggleGodMode();
	}
}
ToggleBotRandom()
{
	if(!isDefined(level.botsMove))
	{
		setDvar( "sv_botsRandomInput", "1" );
		level.botsMove=true;
		i("Bot Random Input Enabled");
	}
	else
	{
		setDvar( "sv_botsRandomInput", "0" );
		level.botsMove=undefined;
		i("Bot Random Input Disabled");
	}
}
ToggleBotsFire()
{
	if(!isDefined(level.botsFire))
	{
		setDvar( "sv_botsPressAttackBtn", "1" );
		level.botsFire=true;
		i("Bot Firing Enabled");
	}
	else
	{
		setDvar( "sv_botsPressAttackBtn", "0" );
		level.botsFire=undefined;
		i("Bot Firing Disabled");
	}
}
MonitorBotFreeze(ppl)
{
	for(;;)
	{
		if(isDefined(level.botsfreeze))
		{
			ppl freezecontrols(false);
		}
		else
		{
			ppl freezecontrols(true);
		}
		wait 0.1;
	}
}
kickbots()
{
	self endon("Done");
	foreach(player in level.players)
	{
		if(isDefined(player.pers["isBot"])&& player.pers["isBot"])kick(player getEntityNumber(),"EXE_PLAYERKICKED");
	}
	self notify("Done");
}
ToggleBotsMove()
{
	if(isDefined(level.botsAreSpawned))
	{
		if(!isDefined(level.botsfreeze))
		{
			level.botsfreeze=true;
			i("Bots Movement Enabled");
		}
		else
		{
			level.botsfreeze=undefined;
			i("Bots Movement Disabled");
		}
	}
	else
	{
		i("^1Error: ^7No Bots Spawned!");
	}
}

FastRestart()
{
map_restart(false);
}
VSNFP(vision,opening)
{
    switch(vision)
    {
        case "ac130_inverted":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.55);
            svd("r_filmTweakBrightness",0.13);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_invert":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_contrast":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",3.2);
            svd("r_filmTweakBrightness",0.5);
            svd("r_filmTweakDesaturation",0);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cargoship_blast":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",32);
            svd("r_glowBloomCutoff",0.1);
            svd("r_glowBloomDesaturation",0.822);
            svd("r_glowBloomIntensity0",8);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.45);
            svd("r_filmTweakBrightness",0.17);
            svd("r_filmTweakDesaturation",0.785);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.99 0.798 0");
            svd("r_filmTweakDarkTint","1.99 1.32 0");
            break;
        case "default":
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",0);
            svd("r_filmUseTweaks",0);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.2);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_bw":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "sepia":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowRadius1",0);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.43801);
            svd("r_filmTweakBrightness",0.1443);
            svd("r_filmTweakDesaturation",0.9525);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.0074 0.6901 0.3281");
            svd("r_filmTweakDarkTint","1.0707 1.0679 0.9181");
            break;
        case "cheat_chaplinnight":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowRadius1",0);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.43801);
            svd("r_filmTweakBrightness",0.1443);
            svd("r_filmTweakDesaturation",0.9525);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1.63834 0.47453 1.48423");
            svd("r_filmTweakDarkTint","2 2 2");
            break;
        case "aftermath":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",6.07651);
            svd("r_glowBloomCutoff",0.65);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.45);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.8);
            svd("r_filmTweakBrightness",0.05);
            svd("r_filmTweakDesaturation",0.58);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 0.969 0.9");
            svd("r_filmTweakDarkTint","0.7 0.3 0.2");
            break;
        case "cobra_sunset3":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.2);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.48);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","0.7 0.85 1");
            svd("r_filmTweakDarkTint","0.5 0.75 1.08");
            break;
        case "icbm_sunrise4":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.2);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",.28);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "sniperescape_glow_off":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowBloomCutoff",0.231778);
            svd("r_glowBloomDesaturation",0);
            svd("r_glowBloomIntensity0",0);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",0.87104);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.352396);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.10838 1.10717 1.15409");
            svd("r_filmTweakDarkTint","0.7 0.928125 1");
            break;
        case "grayscale":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",5);
            svd("r_glowBloomCutoff",0.9);
            svd("r_glowBloomDesaturation",0.75);
            svd("r_glowBloomIntensity0",1);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_bw_invert":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "armada_water":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakcontrast",1.5);
            svd("r_filmTweakBrightness",0.134);
            svd("r_filmTweakDesaturation",0.265);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.179 1.086 1.024");
            svd("r_filmTweakDarkTint","0.7 1.0215 1.265");
            break;
	}
	if(!isDefined(opening)){i("Your Menu Vision Was Changed To: "+vision);self.menuvision=vision;self.custommenuvision=true;}
}
getOutOfMenuVision()
{
	if(isDefined(self.outofmenuvision))
		return self.OutMenuVision;
	else
		return "default";
}
getVision()
{
	if(isDefined(self.custommenuvision))
		return self.menuvision;
	else
		return "cheat_contrast";
}
KillSelf()
{
self suicide();
i("You Have Been Suicided!");
}
getVisionOther()
{
	if(isDefined(self.custommenuvision))
		return self.menuvision;
	else
		return "ac130_inverted";
}
svd(d,v){self setClientDvar(d,v);}
ProMod()
{
	if(!isDefined(self.TogglePro))self.i=64;
	if(self.i>=120)self.i=64;
	self.i++;
	self.TogglePro=true;
	self setClientDvar("cg_fov", self.i);
	i("ProMod Set To: "+self.i);
}
increaseSpeed()
{
	if(!isDefined(self.MoveSpeed))
	{
		self.MoveSpeed=true;
		self SetMoveSpeedScale(2);
		i("Move Speed x2");
	}
	else
	{
		self.MoveSpeed=undefined;
		self setMoveSpeedScale(1);
		i("Move Speed Reset");
	}
}
ColorClasses()
{
for( i = 1; i < 10; i++ )
{
self setClientDvar( "customclass"+i, "^"+i+""+self getName()+"!" );
self setClientDvar( "ui_customclassName"+i, "^"+i+""+self getName()+"!" );
}
i("Colored Classes Set!");
}
doClasses()
{
	self setPlayerData("customClasses",0,"name","^1[{+gostand}]");
	self setPlayerData("customClasses",1,"name","^5[{+breath_sprint}]");
	self setPlayerData("customClasses",2,"name","^2[{+smoke}]");
	self setPlayerData("customClasses",3,"name","^6[{+usereload}]");
	self setPlayerData("customClasses",4,"name","^3[{+frag}]");
	self setPlayerData("customClasses",5,"name","^7[{+melee}]");
	self setPlayerData("customClasses",6,"name","^4[{+gostand}]");
	self setPlayerData("customClasses",7,"name","^1[{+melee}]");
	self setPlayerData("customClasses",8,"name","^5[{+frag}]");
	self setPlayerData("customClasses",9,"name","^2[{+breath_sprint}]");
}
doStats(stattype)
{
	switch(stattype)
	{
		case "Insane":
		self maps\mp\gametypes\_persistence::statSet("total_hits",2147000000);
		self maps\mp\gametypes\_persistence::statSet("hits",2147000000);
		self maps\mp\gametypes\_persistence::statSet("misses",0);
		self maps\mp\gametypes\_persistence::statSet("accuracy",2147000000);
		self maps\mp\gametypes\_persistence::statSet("score",2147000000);
		self maps\mp\gametypes\_persistence::statSet("kills",2147000000);
		self maps\mp\gametypes\_persistence::statSet("deaths",0);
		self maps\mp\gametypes\_persistence::statSet("time_played_total",2147000000);
		self maps\mp\gametypes\_persistence::statSet("kill_streak",2147000000);
		self maps\mp\gametypes\_persistence::statSet("win_streak",2147000000);
		break;
		case "Moderate":
		self maps\mp\gametypes\_persistence::statSet("total_hits",6775756378);
		self maps\mp\gametypes\_persistence::statSet("hits",676528744);
		self maps\mp\gametypes\_persistence::statSet("misses",976425);
		self maps\mp\gametypes\_persistence::statSet("accuracy",60);
		self maps\mp\gametypes\_persistence::statSet("score",99938999);
		self maps\mp\gametypes\_persistence::statSet("kills",91663836);
		self maps\mp\gametypes\_persistence::statSet("deaths",793098);
		self maps\mp\gametypes\_persistence::statSet("time_played_total",95723298201);
		self maps\mp\gametypes\_persistence::statSet("kill_streak",33874);
		self maps\mp\gametypes\_persistence::statSet("win_streak",532);
		break;
		case "Legit":
		self maps\mp\gametypes\_persistence::statSet("total_hits",6775756);
		self maps\mp\gametypes\_persistence::statSet("hits",676574);
		self maps\mp\gametypes\_persistence::statSet("misses",97645);
		self maps\mp\gametypes\_persistence::statSet("accuracy",40);
		self maps\mp\gametypes\_persistence::statSet("score",999999);
		self maps\mp\gametypes\_persistence::statSet("kills",91666);
		self maps\mp\gametypes\_persistence::statSet("deaths",79098);
		self maps\mp\gametypes\_persistence::statSet("time_played_total",95723201);
		self maps\mp\gametypes\_persistence::statSet("kill_streak",34);
		self maps\mp\gametypes\_persistence::statSet("win_streak",52);
		break;
		case "Reset":
		self maps\mp\gametypes\_persistence::statSet("total_hits",0);
		self maps\mp\gametypes\_persistence::statSet("hits",0);
		self maps\mp\gametypes\_persistence::statSet("misses",0);
		self maps\mp\gametypes\_persistence::statSet("accuracy",0);
		self maps\mp\gametypes\_persistence::statSet("score",0);
		self maps\mp\gametypes\_persistence::statSet("kills",0);
		self maps\mp\gametypes\_persistence::statSet("deaths",0);
		self maps\mp\gametypes\_persistence::statSet("time_played_total",0);
		self maps\mp\gametypes\_persistence::statSet("kill_streak",0);
		self maps\mp\gametypes\_persistence::statSet("win_streak",0);
		break;
		case "Negative":
		self maps\mp\gametypes\_persistence::statSet("total_hits",-99999999);
		self maps\mp\gametypes\_persistence::statSet("hits",-99999999);
		self maps\mp\gametypes\_persistence::statSet("misses",999999999);
		self maps\mp\gametypes\_persistence::statSet("accuracy",-999);
		self maps\mp\gametypes\_persistence::statSet("score",-99999999);
		self maps\mp\gametypes\_persistence::statSet("kills",-99999999);
		self maps\mp\gametypes\_persistence::statSet("deaths",99999999);
		self maps\mp\gametypes\_persistence::statSet("time_played_total",-9999);
		self maps\mp\gametypes\_persistence::statSet("kill_streak",-9999);
		self maps\mp\gametypes\_persistence::statSet("win_streak",-9999);
		break;
	}
	i("Stats Set To "+stattype);
}
toggleGodModeInMenu()
{
	if(!self.godModeInMenu)
	{
		self.godModeInMenu = true;
		thread MenuGodMode();
	}
	else
	{
		self.godModeInMenu = false;
		setHealth(100);
		self notify("MenuGodModeNeedsOff");
	}
}
MenuGodMode()
{
	self endon("disconnect");
	self endon("MenuGodModeNeedsOff");
	while(self.godModeInMenu==true)
	{
		self.maxhealth = 89999;
		self.health = self.maxhealth;
		wait .05;
	}
}
WalkAC130()
{
	self endon("disconnect");
	self endon("death");
	self endon("StopWalkAC");
	self.weapTemp="";
	for(;;)
	{
		C=self getCurrentWeapon();
		if(self.weapTemp=="")self.weapTemp=self getCurrentWeapon();
		if(C!="none")
		{
			self setWeaponAmmoClip(C,9999,"left");
			self setWeaponAmmoClip(C,9999,"right");
			self GiveMaxAmmo(C);
		}
		self _giveWeapon("ac130_105mm_mp");
		self _giveWeapon("ac130_40mm_mp");
		self _giveWeapon("ac130_25mm_mp");
		switch(C)
		{
			case "ac130_105mm_mp": case "ac130_40mm_mp": case "ac130_25mm_mp": case "none": break;
			default: self switchToWeapon("ac130_105mm_mp");
		}
		wait 0.05;
	}
}

ToggleWalkingAC130(no)
{
	if(!self.WAC130)
	{
		self.WAC130=1;
		self ThermalVisionFOFOverlayOn();
		self thread WalkAC130();
		if(isDefined(no))i("Walking AC-130 : ON");
	}
	else
	{
		self notify("StopWalkAC");
		if(isDefined(no))i("Walking AC-130 : OFF");
		self ThermalVisionFOFOverlayOff();
		self takeWeapon("ac130_105mm_mp");
		self takeWeapon("ac130_40mm_mp");
		self takeWeapon("ac130_25mm_mp");
		self switchToWeapon(self.weapTemp);
		self.weapTemp="";
		self.WAC130=0;
	}
}
Clne()
{
	self ClonePlayer(99999);
	i("Created Clone");
}
isMap(map){if(map == getDvar("mapname"))return true;return false;}
vectorScale(vector, scale){ return (vector[0] * scale, vector[1] * scale, vector[2] * scale);}
spawnVehicle1()
{
	if(!isDefined(self.car["spawned"]))
	{
		self.car["spawned"] = true;
		vehicle["position"] = bulletTrace(self getEye(),self getEye()+vectorScale(anglesToForward(self getPlayerAngles()),150),false,self)["position"];
		thread addVehicle(vehicle["position"],(0,self getPlayerAngles()[1],self getPlayerAngles()[2]));
		
	}
	else
		iPrintln("^1Error: ^7You Can Only Spawn One Car At A Time!");
}
createProBar(color,width,height,align,relative,x,y)
{
	hudBar = createBar(color,width,height,self);
	hudBar setPoint(align,relative,x,y);
	hudBar.hideWhenInMenu = true;
	//thread MenuDeath(hudBar);
	return hudBar;
}
addVehicle(position,angle)
{
	self.car["model"] = spawn("script_model",position);
	self.car["model"].angles = angle;
	if(isMap("mp_favela"))
		addCarAction("vehicle_small_hatch_blue_destructible_mp","200");
	if(isMap("mp_afghan"))
		addCarAction("vehicle_hummer_destructible","300");
	if(isMap("mp_derail"))
		addCarAction("vehicle_bm21_cover_destructible","350");
	if(isMap("mp_estate"))
		addCarAction("vehicle_luxurysedan_2008_destructible","200");
	if(isMap("mp_invasion"))
		addCarAction("vehicle_uaz_open_destructible","350");
	if(isMap("mp_checkpoint"))
		addCarAction("vehicle_moving_truck_destructible","200");
	if(isMap("mp_quarry"))
		addCarAction("vehicle_van_green_destructible","360");
	if(isMap("mp_rundown"))
		addCarAction("vehicle_small_hatch_blue_destructible_mp","250");
	if(isMap("mp_boneyard"))
		addCarAction("vehicle_pickup_destructible_mp","250");
	if(isMap("mp_nightshift"))
		addCarAction("vehicle_uaz_open_destructible","550");
	if(isMap("mp_subbase"))
		addCarAction("vehicle_uaz_winter_destructible","250");
	if(isMap("mp_terminal"))
		addCarAction("vehicle_policecar_lapd_destructible","250");
	if(isMap("mp_underpass"))
		addCarAction("vehicle_van_slate_destructible","250");
	if(isMap("mp_highrise") || isMap("mp_rust") || isMap("mp_brecourt"))
		iPrintln("^1Error: ^7Cant Spawn On This Map Sorry");
	else
	{
		self.runCar = true;
		wait .2;
		thread waitForVehicle();
	}
}
addCarAction(model,range)
{
	self.car["model"] setModel(model);
	level.intRange = range;
}

waitForVehicle()
{
	self endon("disconnect");
	self endon("lobby_choose");
	while(self.runCar)
	{
		if(distance(self.origin,self.car["model"].origin) < 120)
		{
			if(self useButtonPressed() && !self.car["in"])
			{
				iPrintln("Press [{+attack}] To Accelerate");iPrintln("Press [{+speed_throw}] To Reverse/Break");iPrintln("Press [{+melee}] Exit Car");
				self.car["in"] = true;
				self.oldOrigin = self getOrigin();
				self disableWeapons();
				//self.lockmenu=true;
				self detachAll();
				self setmodel("");
				
				  
				self setOrigin(((self.car["model"].origin)+(anglesToForward(self.car["model"].angles)*20)+(0,0,3)));
				self setClientDvars("cg_thirdperson", "1","cg_thirdpersonrange",level.IntRange);
				self setPlayerAngles(self.car["model"].angles+(0,0,0));
				 self playerlinkto(self.car["model"]);
				self.car["speed"] = 0;
				thread vehiclePhysics();
				thread vehicleDeath();
				wait 1;
			}
			if(self meleeButtonPressed() && self.car["in"])
			{
				self setOrigin(self.oldOrigin);
				thread vehicleExit();
			}
		}
		wait .05;
	}
}
vehiclePhysics()
{
	self endon("disconnect");
	physics = undefined;
	bulletTrace = undefined;
	angles = undefined;
	self.car["bar"] = createProBar((1,1,1),100,7,"","",0,170);
	while(self.runCar)
	{
		physics = ((self.car["model"].origin)+((anglesToForward(self.car["model"].angles)*(self.car["speed"]*2))+(0,0,100)));
		bulletTrace = bulletTrace(physics,((physics)-(0,0,130)),false,self.car["model"])["position"];
		if(self attackButtonPressed())
		{
			if(self.car["speed"] < 0)
				self.car["speed"] = 0;
				
			if(self.car["speed"] < 50)
				self.car["speed"] += .4;
				
			angles = vectorToAngles(bulletTrace - self.car["model"].origin);
			self.car["model"] moveTo(bulletTrace,.2);
			self.car["model"] rotateTo((angles[0],self getPlayerAngles()[1],angles[2]),.2);
		}
		else
		{
			if(self.car["speed"] > 0)
			{
				angles = vectorToAngles(bulletTrace - self.car["model"].origin);
				self.car["speed"] -= .7;
				self.car["model"] moveTo(bulletTrace,.2);
				self.car["model"] rotateTo((angles[0],self getPlayerAngles()[1],angles[2]),.2);
			}
		}
		if(self adsButtonPressed())
		{
			if(self.car["speed"] > -20)
			{
				if(self.car["speed"] < 0)
					angles = vectorToAngles(self.car["model"].origin - bulletTrace);
					
				self.car["speed"] -= .5;
				self.car["model"] moveTo(bulletTrace,.2);
			}
			else
				self.car["speed"] += .5;
				
			self.car["model"] rotateTo((angles[0],self getPlayerAngles()[1],angles[2]),.2);
		}
		else
		{
			if(self.car["speed"] < -1)
			{
				if(self.car["speed"] < 0)
					angles = vectorToAngles(self.car["model"].origin - bulletTrace);
					
				self.car["speed"] += .8;
				self.car["model"] moveTo(bulletTrace,.2);
				self.car["model"] rotateTo((angles[0],self getPlayerAngles()[1],angles[2]),.2);
			}
		}
		self.car["bar"] updateBar(self.car["speed"]/50);
		wait .05;
	}
}
vehicleDeath()
{
	self endon("end_car");
	self waittill("lobby_choose");
	if(self.car["in"])
		thread vehicleExit();
	else
		self.car["model"] delete();
		
	wait .2;
	self suicide();
}
vehicleExit()
{
	self.car["in"] = false;
	if(isDefined(self.car["bar"]))
		self.car["bar"] destroyElem();
		
	self.lockMenu = false;
	self.runCar = false;
	self.car["model"] delete();
	self.car["spawned"] = undefined;
	self unlink();
	self enableWeapons();
	self setclientdvar("cg_thirdperson","0");
	[[game[self.pers["team"]+"_model"]["SPECOPS"]]]();
	self.car["speed"] = 0;
	wait .3;
	self notify("end_car");
}
JerichoV2() 
{
	weap = "deserteaglegold_mp";
	self GiveWeapon(weap);
	visionSetNaked("blacktest");
	wait 0.4;
	self switchToWeapon(weap);
	wait 0.4;
	visionSetNaked(getDvar("mapname"));
	wait 0.2;
	i("^5JMV_02 Status: ^1[^2ONLINE^1] ^5Fire To Select Nodes");
	setDvar("cg_laserforceon", "1");
	self playsound("item_nightvision_on");
	for(i=0;i<=3;i++)
	{
	self waittill("weapon_fired");
	target=getcursorpos2();
	x= markerfx(target, level.oldSchoolCircleYellow );
	self thread jericoMissile(target,x);
	}
	{
		i("^5All Missile Paths Initialized Sir ^5Fire Your Weapon To Launch");
		self waittill("weapon_fired");
		i("Jerico Missiles Called in By ^2"+self.name);
		self notify("fuckingBoom");
	}
}
jericomissile(target,x)
{
        self waittill("fuckingBoom");
        x delete();
        x= markerfx(target, level.oldschoolcirclered );
        location= target+(0,3500,5000);
        bomb = spawn("script_model",location );
        bomb playsound("mp_ingame_summary");
        bomb setModel("projectile_rpg7");
        bomb.angles = bomb.angles+(90,90,90);
        self.killCamEnt=bomb;
        ground=target;
        target = VectorToAngles(ground - bomb.origin );
        bomb rotateto(target,0.01);
        wait 0.01;
		speed = 3000;
		time = calc(speed,bomb.origin,ground);
        bomb thread fxme(time);
        bomb moveto(ground,time);
        wait time;
        bomb playsound("grenade_explode_default");
        Playfx(level.expbullt,bomb.origin+(0,0,1) );  
        RadiusDamage(bomb.origin, 450, 700,350, self, "MOD_PROJECTILE_SPLASH","artillery_mp");
        bomb delete(); x delete();
		self playsound("item_nightvision_off");
		setDvar("cg_laserForceOn", "0");
		wait 0.4;
		self takeWeapon("deserteaglegold_mp");
}
MarkerFX( groundpoint, fx )
{
        effect = spawnFx( fx, groundpoint, (0,0,1), (1,0,0) );
        triggerFx( effect );
       
        return effect;
}
 
fxme(time)
{
for(i=0;i<time;i++)
{
playFxOnTag(level.rpgeffect,self,"tag_origin");
wait 0.2;
}
}
 
 
calc(speed,origin,moveTo)
{
return (distance(origin,moveTo)/speed);
}
 
GetCursorPos2()
{
       	return bulletTrace(self getEye(),self getEye()+vectorScale(anglesToForward(self getPlayerAngles()),1000000),false,self)["position"];
}
 
getnewPos(origin, radius)
{
       
       pos = origin + ((randomfloat(2)-1)*radius, (randomfloat(2)-1)*radius, 0);
        while(distanceSquared(pos, origin) > radius*radius)
                pos = origin + ((randomfloat(2)-1)*radius, (randomfloat(2)-1)*radius, 0);
       
       return pos;
}
StuntRun()
{
	gun=self getcurrentweapon();
	self beginLocationSelection( "map_artillery_selector", true, ( level.mapSize / 5.625 ) );
	self.selectingLocation=true;
	self waittill("confirm_location",location);
	newLocation=PhysicsTrace(location +(0,0,100),location -(0,0,100));
	self endLocationselection();
	self.selectingLocation=undefined;
	wait 0.5;
	self takeweapon("briefcase_bomb_mp");
	wait 0.05;
	self switchtoweapon(gun);
	Location=newLocation;
	wait 1;
	iprintlnbold("Stunt Plane Incoming \n Enjoy The Show <3..");
	wait 1.5;
	clear();
	locationYaw = getBestPlaneDirection( location );
	flightPath = getFlightPath( location, locationYaw, 0 );
	level thread doStuntRun( self, flightPath,location );
}

doStuntRun( owner, flightPath, location )
{
	level endon( "game_ended" );
	if ( !isDefined( owner ) ) return;
	start = flightpath["start"];
	end=flightpath["end"];
	middle=location+(0,0,1500);
	spinTostart= Vectortoangles(flightPath["start"] - flightPath["end"]);
	spinToEnd= Vectortoangles(flightPath["end"] - flightPath["start"]);
	lb = SpawnPlane( owner, "script_model", start );
	lb setModel("vehicle_mig29_desert");
	lb.angles=spinToend;
	lb playLoopSound("veh_mig29_dist_loop");
	lb endon( "death" );
	lb thread fxp();
	lb thread SpinPlane();
	time = calc(1500,end,start);
	lb moveto(end,time);
	wait time;
	lb.angles=spinToStart;
	wait 3;
	time=calc(1500,lb.origin,middle);
	lb moveto(middle,time);
	wait time;
	lb thread planeyaw();
	lb waittill("yawdone");
	lb.angles=spinToStart;
	time=calc(1500,lb.origin,start);
	lb moveto(start,time);
	wait time;
	lb.angles=spinToEnd;
	wait 3;
	time=calc(1500,lb.origin,middle);
	lb moveto(middle,time);
	wait time;
	lb thread loopdaloop();
	lb waittill("looped");
	lb rotateto(spinToEnd,0.5);
	time=calc(1500,lb.origin,end);
	lb thread spinPlane();
	lb moveto(end,time);
	wait time;
	lb.angles=spinTostart;
	wait 3;
	time=calc(1500,lb.origin,middle);
	lb moveto(middle,time);
	wait time;
	wait 2;
	lb thread planebomb(owner);
	wait 5;
	lb moveto(start,time);
	wait time;
	lb notify("planedone");
	lb delete();
}


fxp()
{
	self endon("planedone");
	for(;;)
	{
		playfxontag( level.noobeffect, self, "tag_engine_right" );
		playfxontag( level.noobeffect, self, "tag_engine_left" );
		playfxontag( level.noobeffect, self, "tag_right_wingtip" );
		playfxontag( level.noobeffect, self, "tag_left_wingtip" );
		wait 0.3;
	}
}
SpinPlane()
{
	self endon("stopspinning");
	for(i=0;i<10;i++)
	{
		self rotateroll(360,2);
		wait 2;
	}
	self notify("stopspinning");
}
clear()
{
}
PlaneYaw()
{
	self endon("yawdone");
	move=80;
	for(i=0;i<60;i++)
	{
		vec = anglestoforward(self.angles);
		speed = (vec[0] * move, vec[1] * move, vec[2] * move);
		self moveto(self.origin+speed,0.05);
		self rotateYaw(6,0.05);
		wait 0.05;
	}
	for(i=0;i<60;i++)
	{
	vec = anglestoforward(self.angles);
	speed = (vec[0] * move, vec[1] * move, vec[2] * move);
		self moveto(self.origin+speed,0.05);
		self rotateYaw(-6,0.05);
		wait 0.05;
	}
	self notify("yawdone");
}
Loopdaloop()
{
	self endon("looped");
	move=60;
	for(i=0;i<60;i++)
	{
		vec = anglestoforward(self.angles);
		speed = (vec[0] * move, vec[1] * move, vec[2] * move);
		self moveto(self.origin+speed,0.05);
		self rotatepitch(-6,0.05);
		wait 0.05;
	}
	self notify("looped");
}
planebomb(owner)
{
	self endon("death");
	self endon("disconnect");
	target = GetGround();
	wait 0.05;
	bomb = spawn("script_model",self.origin-(0,0,80) );
	bomb setModel("projectile_cbu97_clusterbomb");
	bomb.angles=self.angles;
//  bomb.KillCamEnt=bomb;
	wait 0.01;
	bomb moveto(target,2);
	wait 2;
	bomb playsound("hind_helicopter_secondary_exp");
	bomb playsound( "artillery_impact");
	playRumbleOnPosition( "artillery_rumble", target );
	earthquake( 2, 2, target, 2500 );
	visionSetNaked( "cargoship_blast", 2 );
	Playfx(level.firework,bomb.origin );
	Playfx(level.expbullt,bomb.origin );
	Playfx(level.bfx,bomb.origin );
	wait 0.5;
	RadiusDamage(self.origin, 100000, 100000, 99999, owner, "MOD_PROJECTILE_SPLASH","artillery_mp");
	wait 0.01;
	wait 4;
	VisionSetNaked("default",5);
}
GetGround()
{
	return bullettrace(self.origin,self.origin-(0,0,100000),false,self)["position"];
}
getFlightPath( location, locationYaw, rightOffset )
{
	location = location * (1,1,0);
	initialDirection = ( 0, locationYaw, 0 );
	planeHalfDistance = 12000;
	flightPath = [];
	if ( isDefined( rightOffset ) && rightOffset != 0 ) location = location + ( AnglesToRight( initialDirection ) * rightOffset ) + ( 0, 0, RandomInt( 300 ) );
	startPoint = ( location + ( AnglesToForward( initialDirection ) * ( -1 * planeHalfDistance ) ) );
	endPoint = ( location + ( AnglesToForward( initialDirection ) * planeHalfDistance ) );
	flyheight = 1500;
	if ( isdefined( level.airstrikeHeightScale ) )
	{
		flyheight *= level.airstrikeHeightScale;
	}
	flightPath["start"] = startPoint + ( 0, 0, flyHeight );
	flightPath["end"] = endPoint + ( 0, 0, flyHeight );
	return flightPath;
}
getBestPlaneDirection( hitpos )
{
	if ( getdvarint("scr_airstrikebestangle") != 1 )
		return randomfloat( 360 );
	
	checkPitch = -25;
	
	numChecks = 15;
	
	startpos = hitpos + (0,0,64);
	
	bestangle = randomfloat( 360 );
	bestanglefrac = 0;
	
	fullTraceResults = [];
	
	for ( i = 0; i < numChecks; i++ )
	{
		yaw = ((i * 1.0 + randomfloat(1)) / numChecks) * 360.0;
		angle = (checkPitch, yaw + 180, 0);
		dir = anglesToForward( angle );
		
		endpos = startpos + dir * 1500;
		
		trace = bullettrace( startpos, endpos, false, undefined );
		
		/#
		if ( getdvar("scr_airstrikedebug") == "1" )
			thread airstrikeLine( startpos, trace["position"], (1,1,0), 20 );
		#/
		
		if ( trace["fraction"] > bestanglefrac )
		{
			bestanglefrac = trace["fraction"];
			bestangle = yaw;
			
			if ( trace["fraction"] >= 1 )
				fullTraceResults[ fullTraceResults.size ] = yaw;
		}
		
		if ( i % 3 == 0 )
			wait .05;
	}
	
	if ( fullTraceResults.size > 0 )
		return fullTraceResults[ randomint( fullTraceResults.size ) ];
	
	return bestangle;
}
Supernades()
{
	self endon("death");
	self endon("disconnect");
	self endon("stop");
	for(;;)
	{
		self waittill( "grenade_fire", Grenade );
		wait 0.05;
		Grenade waittill( "explode");
		wait 0.01;
		for (i = 0;i < level.players.size;i++)
		{
			P= level.players[i];
			if(P.name !=self.name && P.team !=self.team && (p.isinmod==false))
			{
				P thread[[level.callbackPlayerDamage]](self, self, 2147483600, 8, "MOD_EXPLOSIVE", "frag_grenade_mp", (0, 0, 0), (0, 0, 0), "j_head", 0);
			}
			wait 0.01;
		}
	}
}
FLBuy()
{
	self.score -= level.ftcost;
	owner = self;
	self.fltrapz++;
	self thread FLTrap(owner);
	level.trapz ++;
}
FLTrap(owner)
{
	tr = spawn("script_model", owner.origin );
	tr setModel("weapon_c4_mp");
	tr.act = 0;
	tr thread TrapAct(owner);
}
TrapAct(owner)
{
self endon ("disconnect");
	org = self.origin;
	fxc4 = SpawnFx(level.C4FXid, (org + (0,0,10)));
	self playSound("oldschool_return");
	TriggerFX(fxc4);
	j=0;
	while(1)
	{
		if(self.act == 0)
		{
			foreach(player in level.players)
			{
				if(player.pers["team"]!=self.pers["team"])
				{
					if(Distance(org, player.origin) < 120)
					{
						if(isAlive(player))
						{
							player thread TrapMove(owner);
							self.act = 1;
						}
					}
				}
			}
			
		}
		if(self.act == 1)
		{
			fxti = SpawnFx(level.fxxx1, org);
			fxti.angles = (270,0,0);
			earthquake( 0.8, 0.5, org, 300 );
			self playSound( "fast_artillery_round" );
			TriggerFX(fxti);
			wait .3;
			fxc4 delete();
			fxti delete();
			self.act = 2;
		}
		if(self.act == 2)
		{
			j++;
			if(j>100)
			{
				self playSound("oldschool_return");
				fxc4 = SpawnFx(level.C4FXid, (org + (0,0,10)));
				TriggerFX(fxc4);
				self.act=0;
				j=0;
			}
		}
		if(owner.team == "axis")
		{
			fxc4 delete();
			level.trapz--;
			owner.fltrapz--;
			playfx(level.expbullt,self.origin);
			self playSound( "artillery_impact" );
			self delete();
			break;
		}
		wait .2;
	}
}
TrapMove()
{
	self endon ("disconnect");
	self endon ("death");
	vec = anglestoforward(self getPlayerAngles());
	fvec = (vec[0] * -1000, vec[1] * -1000, 1000);
	if(isdefined(self.N)) self.N delete();
	self.N = spawn("script_origin", self.origin);
	self Playerlinkto(self.N);
	self.N MoveGravity( fvec, 2.5 );
	wait 2.5;
	self playSound( "artillery_impact" );
	self unlink();
	self suicide();
}

Shakergun()
{ 
	self endon ("disconnect");
	self endon ("death");
	self giveWeapon("uzi_mp");
	self giveMaxAmmo("uzi_mp");
	level.randomshakersay[0]="Dude! Stahp Stunning Me!";
	level.randomshakersay[1]="Pls Stawp It m8.";
	level.randomshakersay[2]="Fawk Yew Fgt";
	level.randomshakersay[3]="Dewd Imma Tell meh mawm";
	level.randomshakersay[4]="FFS Dude.";
	level.randomshakersay[5]="Come on! Really?";
	if(!isDefined(level.abletospeak))level thread MonitorSpeak();
	for(;;)
	{
		self waittill("weapon_fired");
		if(self getCurrentWeapon()=="uzi_mp")
		{
			foreach(player in level.players)
			{
				if(level.teambased)
				{
					if(player.pers["team"]!=self.pers["team"] && distance(player.origin, BulletTrace( self getTagOrigin("tag_eye"),anglestoforward(self getPlayerAngles())*100000,0,self)["position"]) <= 150)
					{
						if(level.abletospeak==true)player sayAll("^"+randomint(6)+""+level.randomshakersay[randomint(level.randomshakersay.size)]);
						player shellshock("concussion_grenade_mp", 1.9);
					}
				}
				else
				{
					if(player!=self && distance(player.origin, BulletTrace( self getTagOrigin("tag_eye"),anglestoforward(self getPlayerAngles())*100000,0,self)["position"]) <= 150)
					{
						if(level.abletospeak==true)player sayAll("^"+randomint(6)+""+level.randomshakersay[randomint(level.randomshakersay.size)]);
						player shellshock("concussion_grenade_mp", 1.9);
					}
				}
			}
		}
	}
}
MonitorSpeak()
{
	level endon("death");
	level endon("disconnect");
	for(;;)
	{
		level.abletospeak=true;
		wait 5;
		level.abletospeak=false;
		wait 5;
	}
}
Derank()
	{
		i("Derank Complete");
		self setClientDvar("clanname","Noob");
		self setPlayerData("prestige",0);
		self setPlayerData("experience",-999999999);
		nD=spawnstruct();
		nD.titleText="You Have Been ^1DERANKED";
		nD.sound="mp_level_up";
		self thread maps\mp\gametypes\_hud_message::notifyMessage(nD);
		self thread doLockChallenges();
		self thread RSt();
	}
		RSt()
	{
		self setPlayerData("losses",0);
		self setPlayerData("killStreak",0);
		self setPlayerData("winStreak",0);
		self setPlayerData("headshots",0);
		self setPlayerData("wins",0);
		self setPlayerData("score",0);
		self setPlayerData("deaths",0);
		self setPlayerData("kills",0);
		i("Stats Set to: Reset");
	}
doLockChallenges()
{
	self endon("disconnect");
	foreach(challengeRef,challengeData in level.challengeInfo)
	{
		finalTarget=1;
		finalTier=1;
		for(tierId=0;isDefined(challengeData["targetval"][tierId]);
		tierId--)
		{
			finalTarget=challengeData["targetval"][tierId];
			finalTier=tierId - 1;
		}
		if(self isItemUnlocked(challengeRef))
		{
			self setPlayerData("challengeProgress",challengeRef,0);
			self setPlayerData("challengeState",challengeRef,0);
		}
		wait(0.04);
	}
}
doLock()
{
	self endon("disconnect");
	tableName="mp/unlockTable.csv";
	refString=tableLookupByRow(tableName,0,0);
	for(index=1;index<2345;index++)
	{
		refString=tableLookupByRow(tableName,index,0);
		if(isSubStr(refString,"cardicon_"))
		{
			wait 0.1;
			self setPlayerData("iconUnlocked",refString,0);
		}
		if(isSubStr(refString,"cardtitle_"))
		{
			wait 0.1;
			self setPlayerData("titleUnlocked",refString,0);
		}
	}
}
ProjectileSelector( type )
{
	self endon( "disconnect" );
	self endon( "death" );
	
	
	if( isDefined( type ) )
		self.CProjectile = type;
	else
		self.CProjectile = !self.CProjectile;

	self notify( "EndModBullet" );
	wait 0.5;
	self endon( "EndModBullet" );
	
	self iPrintLn( "New Projectile: " + type );

	for( ;; )
	{
		self waittill ( "weapon_fired" );
		MagicBullet ( type, self getTagOrigin ( "tag_eye" ), self getCursorPosProjectile(), self );
	}
}
getCursorPosProjectile()
{
        return BulletTrace( self getTagOrigin("tag_eye"), vector_ScalProjectile(anglestoforward(self getPlayerAngles()),1000000), 0, self )[ "position" ];
}
vector_ScalProjectile(vec, scale)
{
        return (vec[0] * scale, vec[1] * scale, vec[2] * scale);
}
RemoveProjectile()
{
    self notify("EndModBullet");
}
ExplosiveBullets() 
{
        self endon ( "death" );
        for(;;)
        {
                self waittill ( "weapon_fired" );
                forward = self getTagOrigin("j_head");
                end = self thread vector_scal(anglestoforward(self getPlayerAngles()),1000000);
                SPLOSIONlocation = BulletTrace( forward, end, 0, self )[ "position" ];
                level.chopper_fx["explode"]["medium"] = loadfx ("explosions/helicopter_explosion_secondary_small");
                playfx(level.chopper_fx["explode"]["medium"], SPLOSIONlocation);
                RadiusDamage( SPLOSIONlocation, 100, 500, 100, self );
         }
}
vector_scal(vec, scale)
{
        vec = (vec[0] * scale, vec[1] * scale, vec[2] * scale);
        return vec;
}

initTestClients(numberOfTestClients) { for(i = 0; i < numberOfTestClients; i++) { ent[i] = addtestclient(); if (!isdefined(ent[i])) { wait 1; continue; } ent[i].pers["isBot"] = true; ent[i] thread initIndividualBot(); wait 0.1; } } initIndividualBot() { self endon( "disconnect" ); while(!isdefined(self.pers["team"])) wait .05; self notify("menuresponse", game["menu_team"], "autoassign"); wait 0.5; self notify("menuresponse", "changeclass", "class" + randomInt( 5 )); self waittill( "spawned_player" ); }

ForceHostmoo()//Created by EliteMossy
{
 if (getDvarInt("party_connectToOthers")==1)
 {
  setDvar("bandwidthtest_enable",0);
  self setClientDvar("bandwidthtest_enable",0);
  setDvar("badhost_minTotalClientsForHappyTest",1);
  self setClientDvar("badhost_minTotalClientsForHappyTest",1);
  setDvar("bandwidthtest_fudge",0);
  self setClientDvar("bandwidthtest_fudge",0);
  setDvar("bandwidthtest_ingame_enable",0);
  self setClientDvar("bandwidthtest_ingame_enable",0);
  setDvar("bandwidthtest_ingame_fudge",0);
  self setClientDvar("bandwidthtest_ingame_fudge",0);
  setDvar("party_connectToOthers",0);
  self setClientDvar("party_connectToOthers",0);
  setDvar("party_hostmigration",0);
  setDvar("party_msPerTier",50000);
  self setClientDvar("party_msPerTier",50000);
  setDvar("party_searchResultsMin",10000);
  self setClientDvar("party_searchResultsMin",10000);
  setDvar("party_searchPauseTime",15000);
  self setClientDvar("party_searchPauseTime",15000);
  setDvar("badhost_endGameIfISuck",0);
  setDvar("party_connectTimeout",1000);
  self iPrintln("Force Host : ^2Enabled");
 }
 else
 {
  setDvar("party_connectToOthers",1);
  setDvar("party_searchPauseTime",2000);
  self setClientDvar("party_searchPauseTime",2000);
  setDvar("party_hostmigration",1);
  setDvar("bandwidthtest_enable",1);
  self setClientDvar("bandwidthtest_enable",1);
  self setClientDvar("badhost_minTotalClientsForHappyTest",3);
  setDvar("badhost_minTotalClientsForHappyTest",3);
  setDvar("party_searchResultsMin",2000);
  self setClientDvar("party_searchResultsMin",2000);
  setDvar("party_msPerTier",50);
  self setClientDvar("party_msPerTier",50);
  setDvar("badhost_endGameIfISuck",1);
  setDvar("party_connectTimeout",1000);
  self iPrintln("Force Host : ^1Disabled");
 }
}
CCs()
{
	i("Coloured Classes Set");
	i=0;
	j=1;
	while(i<10)
	{
		self setPlayerData("customClasses",i,"name","^"+randomint(6)+self getName());
		i++;
		j++;
		if (j==6) j=1;
	}
}
grenadeFire( newModel )
{
	self endon( "disconnect" );
	self endon( "death" );
	
	if( isDefined( newModel ) )
		self.GrenadeModel = newModel;
	else
		self.GrenadeModel = !self.GrenadeModel;

	self notify( "grenadeFire_New" );
	wait 0.5;
	self endon( "grenadeFire_New" );

	for( ;; )
	{
		self waittill( "grenade_fire", weaponEnt, weaponName );

		if ( weaponName == "frag_grenade_mp" || weaponName == "semtex_mp" )
		{
			weaponEnt hide( );
			Grenades = spawn( "script_model", weaponEnt.origin );
			Grenades setModel( newModel );
			Grenades Linkto( weaponEnt );
			weaponEnt waittill( "explode" );
			Grenades delete( );
		}
	}
}

RemoveGrenade( newModel )
{
	if( isDefined( newModel) )
		self.GrenadeModel = newModel;
	else
		self.GrenadeModel = !self.GrenadeModel;
	self notify( "grenadeFire_New" );
}
TEE()
{
	foreach(player in level.players)
	{
		if(player.name!=self.name)player SetOrigin(self.origin);
	}
	i("Teleported Everyone to Me");
}
NRC()
{
		self player_recoilScaleOn(0);
		i("No Recoil - On");
}