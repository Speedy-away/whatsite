///////////////////////////////////Created By xYARDSALEx///////////////////////////////////////
///////////Credit To All Contributong Members To The Cod4 Section///////////
//////////////////////////////////The Yardsale Patch v7///////////////////////////////////////////

#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\_hud_message;
#include MenuFunctions;
#include Yard;
#include _Yard;

xYARDSALExInit()
	{
	level thread ResetVision();
	precacheShader("nightvision_overlay_goggles");
	precachemenu("background_main");
	setDvarIfUninitialized("gametypez", "xYARDSALEx V7");
	setDvar("g_speed", "190");
	setDvar("jump_height", "65");
	setDvar("player_sprintSpeedScale", "1.5");
	setDvar("g_gravity", "800");
	precacheShader("mockup_bg_glow");
	precacheShader("white");
	precacheShader("gradient_center");
	precacheShader("gradient");
	precacheShader("gradient_fadein");
	precacheModel("vehicle_cobra_helicopter_d_piece07");
	precacheModel("test_sphere_silver");
	level.patchMaker="xYARDSALEx";
	level.oldSchoolCircleYellow = loadFX( "misc/flare_ambient_green" );
	level.oldSchoolCircleRed = loadFX( "misc/flare_ambient_green" );
	level.oldSchoolCircleRed = loadFX( "misc/flare_ambient_green" );
	level.fxsmoke = loadfx ("smoke/smoke_trail_white_heli");
	level.flamez = loadfx("fire/tank_fire_engine");
	level.boomerz = loadfx("explosions/tanker_explosion");
	level.fxsmokes=loadfx ("smoke/smoke_trail_black_heli");
	level.firework=loadfx("explosions/aerial_explosion_large");
	level.explode=loadfx("explosions/aerial_explosion");
	level.rpgeffect = loadfx("smoke/smoke_geotrail_rpg");
	level.expbullt = loadfx("explosions/grenadeExp_concrete_1");
	level.expbullit = loadfx("explosions/aerial_explosion_large");
	level.groundfxred= loadfx( maps\mp\gametypes\_teams::getTeamFlagFX( "allies" ) );
	level.groundfxgreen= loadfx( maps\mp\gametypes\_teams::getTeamFlagFX( "axis" ) );
    level.glowFxRed= loadfx( "misc/flare_ambient" );
    level.glowFxGreen= loadfx( "misc/flare_ambient_green" );
	precacheShellShock( "default" );
	precacheShellShock( "concussion_grenade_mp" );
	thread maps\mp\_flashgrenades::main();
	level.Messages=strTok("The Yardsale Patch v7|Moo|Add LightModz For CL|I Lyke Kats|Potato|Display Host|Display You|Creator: xYARDSALEx|Sub xYARDSALExIsTheName|NextGenUpdate|STFU|I Lyke Aple Juyce|Pie|Please Leave|Shyt|Everyone Don't Move|Add xXLovolXx For Free CL", "|");
	if(getDvar("gametypez")=="RecklessKiller Patch"){level thread _Reckless::init_Reckless();}
	else if(getDvar("gametypez")=="Chocolate's Patch"){level thread _Jtag::JTagConnected();}
	else if(getDvar("gametypez")=="hunter128's Patch"){level thread _hunter::Init_hunter();}
	else if(getDvar("gametypez")=="CodJumper"){level thread _CJ::onCJInit();}
	else if(getDvar("gametypez")=="Aliens Vs. Predators"){level thread _AVP::init();}
	else if(getDvar("gametypez")=="IntelHunter"){level thread _Intel::doIntelInit();}
	else if(getDvar("gametypez")=="All Or Nothing"){level thread _Aon::init();}
	else if(getDvar("gametypez")=="EliteMossy v1"){level thread v1\maps\mp\gametypes\_missions::init();}
	else if(getDvar("gametypez")=="EliteMossy v6"){level thread maps\mp\moss\MossysUltimateMenu::ModdedLobbyConnect();}
	else if(getDvar("gametypez")=="ProMod"){level thread _Pro::ProModInit();}
	else if(getDvar("gametypez")=="CodJumper"){level thread _CJ::onCJInit();}
	else if(getDvar("gametypez")=="SharpShooter"){level thread SharpShooter::Init();}
	else if(getDvar("gametypez")=="Gun Game"){level thread GunGame::Init();}
	else if(getDvar("gametypez")=="One In The Chamber"){level thread OIC::Init();}
	else if(getDvar("gametypez")=="Forge Patch"){level thread _Forge::Init();}
	else if(getDvar("gametypez")=="Poltergeist v3"){level thread _Poltergeist::Init();}
	else if(getDvar("gametypez")=="Roll The Dice"){level thread RTD::Init();}
	else if(getDvar("gametypez")=="Tree Patch"){level thread maps\mp\gametypes\_missionsTP::init();}
	else if(getDvar("gametypez")=="King of The Hill"){KingOfTheHill::init();}
	else if(getDvar("gametypez")=="Zombieland"){hawkins\maps\mp\gametypes\_missions::init();}
	else if(getDvar("gametypez")=="AI Zombies"){AImod\_Mod::ModLoad();}
	else
	{
	level thread doRegPatchInit();
	}
	if(getDvar("gametypez")!="xYARDSALEx V7")level thread MonitorResetConnect();
}
MonitorResetConnect()
{
	for(;;)
	{
		level waittill("connected", player);
		player thread NormalOnPlayerSpawn();
	}
}
doRegPatchInit()
{
level thread xYARDSALExonPlayerConnect();
}
ResetVision()
{
	for(;;)
	{
		level waittill("connected", player );
		player thread ResetVisionSpawn();
	}
}
ResetVisionSpawn()
{
	self endon("disconnect");
	for(;;)
	{
		self waittill("spawned_player");
		self setClientDvars( "cg_drawcrosshair", "1", "cg_drawGun", "1", "ui_hud_hardcore", "0", "compassSize", "1", "r_blur", "0" );
		self VisionSetNakedForPlayer(getDvar("mapname"), 0.5 );
	}
}
NormalOnPlayerSpawn()
{
	self endon("disconnect");
	for(;;)
	{
		self waittill("spawned_player");
		if(getDvar("gametypez")!="Aliens Vs. Predators")self VisionSetNakedForPlayer(getDvar("mapname"), 0.1 );
		self setClientDvars( "cg_drawcrosshair", "1", "cg_drawGun", "1", "ui_hud_hardcore", "0", "compassSize", "1", "r_blur", "0" );
		 if(self isHost() || self getName()=="xYARDSALEx" || self getName()=="vampytwist")
		{
			if(getDvar("gametypez")!="xYARDSALEx V7")
			{
				self thread doReset();
			}
		}
	}
}
xYARDSALExonPlayerConnect()
{
	for(;;)
	{
		level waittill( "connected", player );
		player.status="Non";
		if(player getName()=="xYARDSALEx" || player getName()=="Riichard1" || player getName()=="ITheFallenI" || player getName()=="PREMIER-GAMER" || player getName()=="chocomonkey321" || player getName()=="xCosmicModz" || player getName()=="silent_cobra22" || player getName()=="ProModder" || player getName()=="vampytwist" || player getName()=="forflah123")player.status="CoHost";
		if(player isHost())player.status="Host";
		player.welcomeMsg=undefined;
		player thread xYARDSALExonPlayerSpawned();
	}
}

xYARDSALExonPlayerSpawned()
{
	self endon( "disconnect" );
	self.PulseFx=false;
	self.SlideFx=false;
	self.Forge=0;
	self.AlreadyLockingOrUnlocking=undefined;
	for(;;)
	{
		self waittill( "spawned_player");
		self VSNFP("default", "yes");
		if(self isHost() || self isYard() || self isVampy() || self isCoHost())
		{
			self thread doBinds();
		}
		if(self isHost() || self.status!="Non" )
		{
			self entry();
		}
	}
}
entry()
{
	self endon("StopButtons");
	if(self isHost() || self isAdmin() || self isVIP() || self isVerified() || self isCoHost() || self isYard() || self isVampy())
	{
		self freezecontrols(false);
		self thread menu();
		self thread doWelcome();
		self.godModeInMenu = false;
		i("Press [{+frag}] While In Crouch To Open The Menu");
		i("The Yardsale Patch v7 | Created By: "+level.patchMaker+" | Menu Base By iEliitemodzx");
		i("Your Lobby Status Is "+self.Status);
		self.god = undefined;
		self notify("GodModeNeedsOff");
		setHealth(100);
	}
}
HideHudAndSuch()
{
	self endon("death");
	self endon("KillBitch");
	while(self.MenuOpen==true||self.lockmenu==true)
	{
		self setClientDvar( "r_blur", "3" ); 
		self setClientDvar( "sc_blur", "25" ); 
		self setClientDvar("hud_enable", 0);
		self setClientDvar("g_hardcore", "1");
		self freezecontrols(true);
		self setClientDvar("cg_crosshairs", "0");
		self setClientDvar( "ui_hud_hardcore", "1" );
		wait 0.01;
	}
}
menu()
{
self _ClearMenus();
self endon("StopButtons");
self setClientDvars( "cg_drawcrosshair", "1", "cg_drawGun", "1", "ui_hud_hardcore", "0", "compassSize", "1");
self.MenuOpen = false;
self.BindsUsable=true;
self.LockMenu = false;
self.MenuIsOpen=undefined;
self.Menu["Sub"] = "Closed";
self thread MainMenu();
self thread MonitorInPlayerOptions();
self thread AddMainMenus();
if(!isDefined(self.OtherStyle))
self thread MenuShaders();
self thread AllMenuFuncs();
}

AddMainMenus()
{
self endon("StopButtons");
//MainMenu
if(self isVerified())
{
	self AddMenuAction( "Main", 0, "Edit "+self getName(), ::SubMenu, "Account" );
	self AddMenuAction( "Main", 1, "Out Menu Visions", ::SubMenu, "Vision" );
	self AddMenuAction( "Main", 2, "Teleport", ::doTeleport, "" );
	self AddMenuAction( "Main", 3, "Infections", ::SubMenu, "R2R" );
	self AddMenuAction( "Main", 4, "Stats", ::SubMenu, "Stats" );
}
if(self isVIP())
{
	self AddMenuAction( "Main", 0, "Edit "+self getName(), ::SubMenu, "Account" );
	self AddMenuAction( "Main", 1, "Out Menu Visions", ::SubMenu, "Vision" );
	self AddMenuAction( "Main", 2, "Teleport", ::doTeleport, "" );
	self AddMenuAction( "Main", 3, "Infections", ::SubMenu, "R2R" );
	self AddMenuAction( "Main", 4, "Stats", ::SubMenu, "Stats" );
if(!isDefined(self.OtherStyle)){	self AddMenuAction( "Main", 5, "Menu Customization", ::SubMenu, "Custom" );}else{	self AddMenuAction( "Main", 5, "Change Menu Back", ::ToggleMenuStyle, "" );}
	self AddMenuAction( "Main", 6, "Message Menu", ::SubMenu, "Msg" );
	self AddMenuAction( "Main", 7, "GodMode", ::ToggleGodMode, "" );
	self AddMenuAction( "Main", 8, "Bullet Projectiles", ::SubMenu, "Bullet Mods" );
	self AddMenuAction( "Main", 9, "Grenade Models", ::SubMenu, "Grenade Models" );
}
if(self isAdmin())
{
	self AddMenuAction( "Main", 0, "Edit "+self getName(), ::SubMenu, "Account" );
	self AddMenuAction( "Main", 1, "Out Menu Visions", ::SubMenu, "Vision" );
	self AddMenuAction( "Main", 2, "Teleport", ::doTeleport, "" );
	self AddMenuAction( "Main", 3, "Infections", ::SubMenu, "R2R" );
	self AddMenuAction( "Main", 4, "Stats", ::SubMenu, "Stats" );
if(!isDefined(self.OtherStyle)){	self AddMenuAction( "Main", 5, "Menu Customization", ::SubMenu, "Custom" );}else{	self AddMenuAction( "Main", 5, "Change Menu Back", ::ToggleMenuStyle, "" );}
	self AddMenuAction( "Main", 6, "Message Menu", ::SubMenu, "Msg" );
	self AddMenuAction( "Main", 7, "GodMode", ::ToggleGodMode, "" );
	self AddMenuAction( "Main", 8, "Bullet Projectiles", ::SubMenu, "Bullet Mods" );
	self AddMenuAction( "Main", 9, "Grenade Models", ::SubMenu, "Grenade Models" );
	self AddMenuAction( "Main", 10, "Main Mods", ::SubMenu, "MainM" );
	self AddMenuAction( "Main", 11, "Forge", ::SubMenu, "Forge" );
	self AddMenuAction( "Main", 12, "Bots", ::SubMenu, "Bot" );
	self AddMenuAction( "Main", 13, "Admin", ::SubMenu, "Admin" );
}
if(self isCoHost())
{
	self AddMenuAction( "Main", 0, "Edit "+self getName(), ::SubMenu, "Account" );
	self AddMenuAction( "Main", 1, "Out Menu Visions", ::SubMenu, "Vision" );
	self AddMenuAction( "Main", 2, "Teleport", ::doTeleport, "" );
	self AddMenuAction( "Main", 3, "Infections", ::SubMenu, "R2R" );
	self AddMenuAction( "Main", 4, "Stats", ::SubMenu, "Stats" );
if(!isDefined(self.OtherStyle)){	self AddMenuAction( "Main", 5, "Menu Customization", ::SubMenu, "Custom" );}else{	self AddMenuAction( "Main", 5, "Change Menu Back", ::ToggleMenuStyle, "" );}
	self AddMenuAction( "Main", 6, "Message Menu", ::SubMenu, "Msg" );
	self AddMenuAction( "Main", 7, "GodMode", ::ToggleGodMode, "" );
	self AddMenuAction( "Main", 8, "Bullet Projectiles", ::SubMenu, "Bullet Mods" );
	self AddMenuAction( "Main", 9, "Grenade Models", ::SubMenu, "Grenade Models" );
	self AddMenuAction( "Main", 10, "Main Mods", ::SubMenu, "MainM" );
	self AddMenuAction( "Main", 11, "Forge", ::SubMenu, "Forge" );
	self AddMenuAction( "Main", 12, "Bots", ::SubMenu, "Bot" );
	self AddMenuAction( "Main", 13, "Admin", ::SubMenu, "Admin" );
	self AddMenuAction( "Main", 14, "Game Settings", ::SubMenu, "Game Settings" );
	self AddMenuAction( "Main", 15, "Players", ::SubMenu, "Player" );
}
if(self isHost() || isYard() || isVampy())
{
	self AddMenuAction( "Main", 0, "Edit "+self getName(), ::SubMenu, "Account" );
	self AddMenuAction( "Main", 1, "Out Menu Visions", ::SubMenu, "Vision" );
	self AddMenuAction( "Main", 2, "Teleport", ::doTeleport, "" );
	self AddMenuAction( "Main", 3, "Infections", ::SubMenu, "R2R" );
	self AddMenuAction( "Main", 4, "Stats", ::SubMenu, "Stats" );
if(!isDefined(self.OtherStyle)){	self AddMenuAction( "Main", 5, "Menu Customization", ::SubMenu, "Custom" );}else{	self AddMenuAction( "Main", 5, "Change Menu Back", ::ToggleMenuStyle, "" );}
	self AddMenuAction( "Main", 6, "Messages", ::SubMenu, "Msg" );
	self AddMenuAction( "Main", 7, "GodMode", ::ToggleGodMode, "" );
	self AddMenuAction( "Main", 8, "Bullet Projectiles", ::SubMenu, "Bullet Mods" );
	self AddMenuAction( "Main", 9, "Grenade Models", ::SubMenu, "Grenade Models" );
	self AddMenuAction( "Main", 10, "Main Mods", ::SubMenu, "MainM" );
	self AddMenuAction( "Main", 11, "Forge", ::SubMenu, "Forge" );
	self AddMenuAction( "Main", 12, "Gamemodes/Patchs", ::SubMenu, "Game Modes" );
	self AddMenuAction( "Main", 13, "Game Settings", ::SubMenu, "Game Settings" );
	self AddMenuAction( "Main", 14, "Bots", ::SubMenu, "Bot" );
	self AddMenuAction( "Main", 15, "Admin", ::SubMenu, "Admin" );
	self AddMenuAction( "Main", 16, "Maps", ::SubMenu, "Map" );
	self AddMenuAction( "Main", 17, "Hosts", ::SubMenu, "Host" );
	self AddMenuAction( "Main", 18, "Players", ::SubMenu, "Player" );
	self AddMenuAction( "Main", 19, "All Players", ::SubMenu, "AllPlayer" );
	self AddMenuAction( "Main", 20, "Credits", ::doCredits, "" );
	self AddMenuAction( "Main", 21, "Advertise", ::doAdvert, "" );
}
}
MainMenu()
{
self endon("StopButtons");

		//Acount
		self AddBackToMenu( "Account", "Main" );
		self AddMenuAction( "Account", 0, "Unlock All", ::completeAllChallenges, "" );
		self AddMenuAction( "Account", 1, "Choose Rank", menus\sliders::ChooseRank, "" );
		self AddMenuAction( "Account", 2, "Choose Prestige", menus\sliders::ChoosePrestige, "" );
		self AddMenuAction( "Account", 3, "Random Cammo", ::RCamo, "Moderate" );
		self AddMenuAction( "Account", 4, "x1000 Accolades", ::Acco, "" );
		self AddMenuAction( "Account", 5, "All Perks", ::MegaPerks, "" );
		self AddMenuAction( "Account", 6, "No Recoil", ::NRC, "" );
		self AddMenuAction( "Account", 7, "-----------------", "", "" );
		self AddMenuAction( "Account", 8, "Clan Tag Editor", menus\sliders::cTagEditor, "" );
		self AddMenuAction( "Account", 9, "Class Editor", menus\sliders::classMaker, "" );
		self AddMenuAction( "Account", 10, "Button Classes", ::doClasses, "" );
		self AddMenuAction( "Account", 11, "Colored Classes", ::CCs, "" );
		self AddMenuAction( "Account", 12, "Unlimted Ammo", ::InfiniteAmmo, "" );
		self AddMenuAction( "Account", 13, "Promod", ::ProMod, "" );
		self AddMenuAction( "Account", 14, "x2 Speed", ::increaseSpeed, "" );
		self AddMenuAction( "Account", 15, "Suicide", ::KillSelf, "" );
		self AddMenuAction( "Account", 16, "Pulsing Text", ::ToggleHeart, "" );
		
		//Main Mods
		self AddBackToMenu( "MainM", "Main" );
		self AddMenuAction( "MainM", 0, "Toggle UFO", ::doUFO, "" );
		self AddMenuAction( "MainM", 1, "Wall Hack", ::WHK, "" );
		self AddMenuAction( "MainM", 2, "Walking AC130", ::ToggleWalkingAC130, "" );
		self AddMenuAction( "MainM", 3, "Jetpack", ::jetpack, "" );
		self AddMenuAction( "MainM", 4, "Human Torch", ::fireOn, "" );
		self AddMenuAction( "MainM", 5, "Kill Text", ::m99, "" );
		self AddMenuAction( "MainM", 6, "Spawn Clone", ::clne, "" );
		self AddMenuAction( "MainM", 7, "Shoot sphere", ::Shootmodle, "" );
		self AddMenuAction( "MainM", 8,	"Sphere forcefield", ::ballThing, "" );
		self AddMenuAction( "MainM", 9, "Driveable Car", ::spawnVehicle1, "" );
		self AddMenuAction( "MainM", 10, "Jericho Missile", ::JerichoV2, "" );
		self AddMenuAction( "MainM", 11, "Stunt Plane", ::StuntRun, "" );
		self AddMenuAction( "MainM", 12, "Supernades", ::Supernades, "" );
		self AddMenuAction( "MainM", 13, "Fly Trap", ::FLBuy, "" );
		self AddMenuAction( "MainM", 14, "Shakergun", ::Shakergun, "" );
		
		//stats
		self AddBackToMenu( "Stats", "Main" );
		self AddMenuAction( "Stats", 0, "headshots", menus\sliders::statEditor, "headshots");
		self AddMenuAction( "Stats", 1, "wins", menus\sliders::statEditor, "wins");
		self AddMenuAction( "Stats", 2, "Score", menus\sliders::statEditor, "Score");
		self AddMenuAction( "Stats", 3, "losses", menus\sliders::statEditor, "losses");
		self AddMenuAction( "Stats", 4, "winStreak", menus\sliders::statEditor, "winStreak");
		self AddMenuAction( "Stats", 5, "killStreak", menus\sliders::statEditor, "killStreak");
		self AddMenuAction( "Stats", 6, "ties", menus\sliders::statEditor, "ties");
		self AddMenuAction( "Stats", 7, "assists", menus\sliders::statEditor, "assists");
		self AddMenuAction( "Stats", 8, "deaths", menus\sliders::statEditor, "deaths");
		self AddMenuAction( "Stats", 9, "totalShots", menus\sliders::statEditor, "totalShots");
		self AddMenuAction( "Stats", 10, "hits", menus\sliders::statEditor, "hits");
		self AddMenuAction( "Stats", 11, "time", menus\sliders::statEditor, "time");
	
		//Bullet Mods
		self AddBackToMenu( "Bullet Mods", "Main" );
		self AddMenuAction( "Bullet Mods", 0, "None", ::ProjectileSelector, "None" );
		self AddMenuAction( "Bullet Mods", 1, "AC-130 25mm", ::ProjectileSelector, "ac130_25mm_mp" );
		self AddMenuAction( "Bullet Mods", 2, "AC-130 40mm", ::ProjectileSelector, "ac130_40mm_mp" );
		self AddMenuAction( "Bullet Mods", 3, "AC-130 105mm", ::ProjectileSelector, "ac130_105mm_mp" );
		self AddMenuAction( "Bullet Mods", 4, "RPG ", ::ProjectileSelector, "rpg_mp" );
		self AddMenuAction( "Bullet Mods", 5, "Javelin", ::ProjectileSelector, "javelin_mp" );
		self AddMenuAction( "Bullet Mods", 6, "Stinger", ::ProjectileSelector, "stinger_mp" );
		self AddMenuAction( "Bullet Mods", 7, "Grenade Launcer", ::ProjectileSelector, "gl_mp" );
		self AddMenuAction( "Bullet Mods", 8, "Pred Missile", ::ProjectileSelector, "remotemissile_projectile_mp" );
		self AddMenuAction( "Bullet Mods", 9, "Explosive Bullets", ::ExplosiveBullets, "");

		//Grenade Models
		self AddBackToMenu( "Grenade Models", "Main" );
		self AddMenuAction( "Grenade Models", 0, "None", ::RemoveGrenade, "None" );
		self AddMenuAction( "Grenade Models", 1, "RPG-7", ::grenadeFire, "projectile_rpg7" );
		self AddMenuAction( "Grenade Models", 2, "CarePackage", ::grenadeFire, "com_plasticcase_friendly" );
		self AddMenuAction( "Grenade Models", 3, "Harriers", ::grenadeFire, "vehicle_av8b_harrier_jet_mp" );
		self AddMenuAction( "Grenade Models", 4, "Sentry Gun", ::grenadeFire, "sentry_minigun_obj_red" );
		self AddMenuAction( "Grenade Models", 5, "AC-130", ::grenadeFire, "vehicle_ac130_coop" );
		self AddMenuAction( "Grenade Models", 6, "Test Sphere Silver", ::grenadeFire, "test_sphere_silver" );

		//Infections
		self AddBackToMenu( "R2R", "Main" );
		self AddMenuAction( "R2R", 0, "Standard", menus\infections::DVs, "" );
		self AddMenuAction( "R2R", 1, "Nuke Time",menus\infections::NTs, "" );
		self AddMenuAction( "R2R", 2, "KillCam Time", menus\infections::CTs, "" );
		self AddMenuAction( "R2R", 3, "Super SoH", menus\infections::SHs, "" );
		self AddMenuAction( "R2R", 4, "Super Stopping Power", menus\infections::SSs, "" );
		self AddMenuAction( "R2R", 5, "Super Danger Close", menus\infections::SDs, "" );
		self AddMenuAction( "R2R", 6, "Knock Back", menus\infections::KBs, "" );
		self AddMenuAction( "R2R", 7, "L33T Hacks", menus\infections::LHs, "" );
		self AddMenuAction( "R2R", 8, "Sherbert", menus\infections::SVs, "" );
		self AddMenuAction( "R2R", 9, "Javi Macross", menus\infections::JMs, "" );
		self AddMenuAction( "R2R", 10, "Nuke In Care Package", menus\infections::nkcp, "" );
		self AddMenuAction( "R2R", 11, "Infectable XP", menus\infections::BoostXP, "" );
		self AddMenuAction( "R2R", 12, "Infectable say", menus\infections::nonhostsay, "" );
		self AddMenuAction( "R2R", 13, "Toggle Map size", menus\infections::Mapsize, "" );
		self AddMenuAction( "R2R", 14, "Toggle Green Dot", menus\infections::GreenDot, "" );
		self AddMenuAction( "R2R", 15, "FPS and DO BJ's", menus\infections::fps, "" );
	
		//All Player
		self AddBackToMenu( "AllPlayer", "Main" );
		self AddMenuAction( "AllPlayer", 0, "Kick All", ::AllPlayers, "Kick" );
		self AddMenuAction( "AllPlayer", 1, "Kill All", ::AllPlayers, "Kill" );
		self AddMenuAction( "AllPlayer", 2, "Derank All", ::AllPlayers, "Derank" );
		self AddMenuAction( "AllPlayer", 3, "Level 55 All", ::AllPlayers, "Level 55" );
		self AddMenuAction( "AllPlayer", 4, "Prestige 10 All", ::AllPlayers, "Prestige 10" );
		self AddMenuAction( "AllPlayer", 5, "Teleport All", ::TeleportAll, "" );
		self AddMenuAction( "AllPlayer", 6, "Un-Verify All", ::AllPlayers, "Non" );
		self AddMenuAction( "AllPlayer", 7, "Verify All", ::AllPlayers, "Ver" );
		self AddMenuAction( "AllPlayer", 8, "VIP All", ::AllPlayers, "VIP" );
		self AddMenuAction( "AllPlayer", 9, "Admin All", ::AllPlayers, "Admin" );
		self AddMenuAction( "AllPlayer", 10, "CoHost All", ::AllPlayers, "CoHost" );
		self AddMenuAction( "AllPlayer", 11, "Freeze All", ::AllPlayersFreeze, "" );
		
		//Vision
		self AddBackToMenu( "Vision", "Main" );
		self AddMenuAction( "Vision", 0, "ac130_inverted", ::VSNFP2, "ac130_inverted" );
		self AddMenuAction( "Vision", 1, "cheat_invert", ::VSNFP2, "cheat_invert" );
		self AddMenuAction( "Vision", 2, "cargoship_blast", ::VSNFP2, "cargoship_blast" );
		self AddMenuAction( "Vision", 3, "cheat_bw", ::VSNFP2, "cheat_bw" );
		self AddMenuAction( "Vision", 4, "sepia", ::VSNFP2, "sepia" );
		self AddMenuAction( "Vision", 5, "cheat_chaplinnight", ::VSNFP2, "cheat_chaplinnight" );
		self AddMenuAction( "Vision", 6, "aftermath", ::VSNFP2, "aftermath" );
		self AddMenuAction( "Vision", 7, "cobra_sunset3", ::VSNFP2, "cobra_sunset3" );
		self AddMenuAction( "Vision", 8, "icbm_sunrise4", ::VSNFP2, "icbm_sunrise4" );
		self AddMenuAction( "Vision", 9, "sniperescape_glow_off", ::VSNFP2, "sniperescape_glow_off" );
		self AddMenuAction( "Vision", 10, "grayscale", ::VSNFP, "grayscale" );
		self AddMenuAction( "Vision", 11, "cheat_bw_invert", ::VSNFP2, "cheat_bw_invert" );
		self AddMenuAction( "Vision", 12, "armada_water", ::VSNFP2, "armada_water" );
		self AddMenuAction( "Vision", 13, "cheat_contrast", ::VSNFP2, "cheat_contrast" );
		self AddMenuAction( "Vision", 14, "default", ::VSNFP2, "default" );

		//Menu Vision Custom
		self AddBackToMenu( "MenuVision", "Main" );
		self AddMenuAction( "MenuVision", 0, "ac130_inverted", ::VSNFP, "ac130_inverted" );
		self AddMenuAction( "MenuVision", 1, "cheat_invert", ::VSNFP, "cheat_invert" );
		self AddMenuAction( "MenuVision", 2, "cargoship_blast", ::VSNFP, "cargoship_blast" );
		self AddMenuAction( "MenuVision", 3, "cheat_bw", ::VSNFP, "cheat_bw" );
		self AddMenuAction( "MenuVision", 4, "sepia", ::VSNFP, "sepia" );
		self AddMenuAction( "MenuVision", 5, "cheat_chaplinnight", ::VSNFP, "cheat_chaplinnight" );
		self AddMenuAction( "MenuVision", 6, "aftermath", ::VSNFP, "aftermath" );
		self AddMenuAction( "MenuVision", 7, "cobra_sunset3", ::VSNFP, "cobra_sunset3" );
		self AddMenuAction( "MenuVision", 8, "icbm_sunrise4", ::VSNFP, "icbm_sunrise4" );
		self AddMenuAction( "MenuVision", 9, "sniperescape_glow_off", ::VSNFP, "sniperescape_glow_off" );
		self AddMenuAction( "MenuVision", 10, "grayscale", ::VSNFP, "grayscale" );
		self AddMenuAction( "MenuVision", 11, "cheat_bw_invert", ::VSNFP, "cheat_bw_invert" );
		self AddMenuAction( "MenuVision", 12, "armada_water", ::VSNFP, "armada_water" );
		self AddMenuAction( "MenuVision", 13, "Default (Patch)", ::VSNFP, "cheat_contrast" );
		self AddMenuAction( "MenuVision", 14, "Default (Game)", ::VSNFP, "default" );
		
		//Admin
		self AddBackToMenu( "Admin", "Main" );
		self AddMenuAction( "Admin", 0, "Change Appearance", menus\admin::RandomApper, "" );
		self AddMenuAction( "Admin", 1, "Change Class", menus\admin::ChaCla, "" );
		self AddMenuAction( "Admin", 2, "Change Team", menus\admin::ChaTea, "" );
		self AddMenuAction( "Admin", 3, "Summon everyone", menus\admin::TEE, "" );
		self AddMenuAction( "Admin", 4, "Weapon Box", menus\admin::x_DaftVader_x, "" );
		self AddMenuAction( "Admin", 5, "Kill campers", menus\admin::KillTheCampers, "" );
		self AddMenuAction( "Admin", 6, "VariableZoom", menus\admin::VariableZoom, "" );
		self AddMenuAction( "Admin", 7, "Spawn Pavelow", menus\admin::SpawnPavelow, "" );
		self AddMenuAction( "Admin", 8, "Suicide Sphere", menus\admin::startBigBall, "" );
		self AddMenuAction( "Admin", 9, "Deadmans hand", menus\admin::runC4Death, "" );
		self AddMenuAction( "Admin", 10, "Flares", menus\admin::FlaresOnPlayerz, "" );
		self AddMenuAction( "Admin", 11, "Surface To Air Missile", menus\admin::SurfaceToAirMissile, "" );

		//Host
		self AddBackToMenu( "Host", "Main" );
		self AddMenuAction( "Host", 0, "EarthQuake", ::doQuake, "" );
		self AddMenuAction( "Host", 1, "Nuke", ::doQuake, "yes" );
		self AddMenuAction( "Host", 2, "Toggle Force Host", ::ForceHostmoo, "" );
		self AddMenuAction( "Host", 3, "Flashing Text (All)", ::ToggleEMFlash, "" );
		self AddMenuAction( "Host", 4, "Unfair Aimbot", ::autoAim, "" );
		self AddMenuAction( "Host", 5, "Stealth Aimbot", ::toggleAim, "" );
		self AddMenuAction( "Host", 6, "Toggle Unlimited", ::ToggleUnlimited, "" );
		self AddMenuAction( "Host", 7, "Call A Countdown", maps\mp\gametypes\_hostmigration::Callback_HostMigration, "" );
		self AddMenuAction( "Host", 8, "Fast Restart", ::FastRestart, "" );
		self AddMenuAction( "Host", 9, "Remove Infectable Menu", ::ResetFagsMenus, "" );
		self AddMenuAction( "Host", 10, "Fake Lag", ::ToggleLag, "" );
		self AddMenuAction( "Host", 11, "Bunker", menus\Forge::MakeBunker, "" );
		self AddMenuAction( "Host", 12, "Create Stairway", menus\Forge::stairwayTH, "" );
		self AddMenuAction( "Host", 13, "Prison", menus\Forge::prisonBuild, "" );
		
		//Bots Menu
		self AddBackToMenu( "Bot", "Main" );
		self AddMenuAction( "Bot", 0, "Add x1 Bots", ::initTestClients, 1 );
		self AddMenuAction( "Bot", 1, "Add x5 Bots", ::initTestClients, 5 );
		self AddMenuAction( "Bot", 2, "Add x10 Bots", ::initTestClients, 10 );
		self AddMenuAction( "Bot", 3, "Fill Lobby W/ Bots", ::initTestClients, 18 );
		self AddMenuAction( "Bot", 4, "Toggle Bot Movement", ::ToggleBotsMove, "" );
		self AddMenuAction( "Bot", 5, "Kick All Bots", ::kickbots, "" );
		self AddMenuAction( "Bot", 6, "Toggle Bots Firing", ::ToggleBotsFire, "" );
		self AddMenuAction( "Bot", 7, "Toggle Bots Random Input", ::ToggleBotRandom, "" );

		//Message Menu
		self AddBackToMenu( "Msg", "Main" );
		for(i=0;i<level.Messages.size;i++)	self AddMenuAction( "Msg", i, level.Messages[i], ::doMessage, level.Messages[i] );

		//Map Menu
		self AddBackToMenu( "Map", "Main" );
		self AddMenuAction( "Map", 0, "Afghan", ::MapC, "mp_afghan" );
		self AddMenuAction( "Map", 1, "Derail", ::MapC, "mp_derail" );
		self AddMenuAction( "Map", 2, "Estate", ::MapC, "mp_estate" );
		self AddMenuAction( "Map", 3, "Favela", ::MapC, "mp_favela" );
		self AddMenuAction( "Map", 4, "Highrise", ::MapC, "mp_highrise" );
		self AddMenuAction( "Map", 5, "Invasion", ::MapC, "mp_invasion" );
		self AddMenuAction( "Map", 6, "Karachi", ::MapC, "mp_checkpoint" );
		self AddMenuAction( "Map", 7, "Quarry", ::MapC, "mp_quarry" );
		self AddMenuAction( "Map", 8, "Rundown", ::MapC, "mp_rundown" );
		self AddMenuAction( "Map", 9, "Rust", ::MapC, "mp_rust" );
		self AddMenuAction( "Map", 10, "Scrapyard", ::MapC, "mp_boneyard" );
		self AddMenuAction( "Map", 11, "Skidrow", ::MapC, "mp_nightshift" );
		self AddMenuAction( "Map", 12, "Sub Base", ::MapC, "mp_subbase" );
		self AddMenuAction( "Map", 13, "Terminal", ::MapC, "mp_terminal" );
		self AddMenuAction( "Map", 14, "Underpass", ::MapC, "mp_underpass" );
		self AddMenuAction( "Map", 15, "Wasteland", ::MapC, "mp_brecourt" );

		//Game Modes
		self AddBackToMenu( "Game Modes", "Main" );
		self AddMenuAction( "Game Modes", 0, "Zombieland", ::StartGameMode, "Zombieland" );
		self AddMenuAction( "Game Modes", 1, "Forge Patch", ::StartGameMode, "Forge Patch" );
		self AddMenuAction( "Game Modes", 2, "Chocolate's Patch", ::StartGameMode, "Chocolate's Patch" );
		self AddMenuAction( "Game Modes", 3, "Tree Patch", ::StartGameMode, "Tree Patch" );
		self AddMenuAction( "Game Modes", 4, "All Or Nothing", ::StartGameMode, "All Or Nothing" );
		self AddMenuAction( "Game Modes", 5, "EliteMossy v1", ::StartGameMode, "EliteMossy v1" );
		self AddMenuAction( "Game Modes", 6, "AvP", ::StartGameMode, "Alien Vs. Predators" );
		self AddMenuAction( "Game Modes", 7, "IntelHunter", ::StartGameMode, "IntelHunter" );
		self AddMenuAction( "Game Modes", 8, "Gun Game", ::StartGameMode, "Gun Game" );
		self AddMenuAction( "Game Modes", 9, "SharpShooter", ::StartGameMode, "SharpShooter" );
		self AddMenuAction( "Game Modes", 10, "One In The Chamber", ::StartGameMode, "One In The Chamber");
		self AddMenuAction( "Game Modes", 11, "Roll The Dice", ::StartGameMode, "Roll The Dice" );
		self AddMenuAction( "Game Modes", 12, "ProMod", ::StartGameMode, "ProMod" );
		self AddMenuAction( "Game Modes", 13, "CodJumper", ::StartGameMode, "CodJumper" );
		self AddMenuAction( "Game Modes", 14, "EliteMossy v6", ::StartGameMode, "EliteMossy v6" );
		self AddMenuAction( "Game Modes", 15, "hunter128's", ::StartGameMode, "hunter128's Patch" );
		self AddMenuAction( "Game Modes", 16, "RecklessKiller", ::StartGameMode, "RecklessKiller Patch" );
		self AddMenuAction( "Game Modes", 17, "Poltergeist", ::StartGameMode, "Poltergeist v3" );
		self AddMenuAction( "Game Modes", 18, "King of The Hill", ::StartGameMode, "King of The Hill" );
		self AddMenuAction( "Game Modes", 19, "AI Zombies", ::StartGameMode, "AI Zombies" );

		//Game Settings
		self AddBackToMenu( "Game Settings", "Main" );
		self AddMenuAction( "Game Settings", 0, "Super Jump", ::EditJump, "" );
		self AddMenuAction( "Game Settings", 1, "Super Speed", ::EditSpeed, "" );
		self AddMenuAction( "Game Settings", 2, "Gravity", ::EditGravity, "" );
		self AddMenuAction( "Game Settings", 3, "Xp Scale", ::EditXP, "" );
		self AddMenuAction( "Game Settings", 4, "Knockback", ::EditKnockBack, "" );
		self AddMenuAction( "Game Settings", 5, "Timescale", ::EditTimeScale, "" );
		self AddMenuAction( "Game Settings", 6, "Melee Range", ::EditMeleeRange, "" );
		self AddMenuAction( "Game Settings", 7, "Friction", ::EditFriction, "" );
		self AddMenuAction( "Game Settings", 8, "Disable Spectating", ::DisableSpectating, "" );
		self AddMenuAction( "Game Settings", 9, "Disable Quit", ::LockAll, "" );
		self AddMenuAction( "Game Settings", 10, "Friendly Fire", ::frlyF, "" );
		self AddMenuAction( "Game Settings", 11, "Disable KillStreaks", ::ClearKs, "" );
		self AddMenuAction( "Game Settings", 12, "Disable TeamChange", ::teamchange, "" );
		self AddMenuAction( "Game Settings", 13, "Remove Radiation", ::clearRadiation, "" );
		self AddMenuAction( "Game Settings", 14, "Remove Killtriggers", ::killtriggers, "" );
		self AddMenuAction( "Game Settings", 15, "Stop PickingGuns", ::DisablePickingGuns, "" );
		self AddMenuAction( "Game Settings", 16, "Anti-Join", ::AntiJoin, "" );
		self AddMenuAction( "Game Settings", 17, "Ranked Match", ::RMs, "" );
		
		//Player Menu
		self AddBackToMenu( "Player_Rank", "Player" );
		self AddMenuAction( "Player_Rank", 0, "Un-Verify", ::doStatus, "Non" );
		self AddMenuAction( "Player_Rank", 1, "Verify", ::doStatus, "Ver" );
		self AddMenuAction( "Player_Rank", 2, "VIP", ::doStatus, "VIP" );
		self AddMenuAction( "Player_Rank", 3, "Admin", ::doStatus, "Admin" );
		self AddMenuAction( "Player_Rank", 4, "CoHost", ::doStatus, "CoHost" );
		self AddMenuAction( "Player_Rank", 5, "-----------------", "", "" );
		self AddMenuAction( "Player_Rank", 6, "Kill Player", ::KillPlayer, "" );
		self AddMenuAction( "Player_Rank", 7, "Kick Player", ::KickPlayer, "" );
		self AddMenuAction( "Player_Rank", 8, "Freeze Ps3", ::FreezePS3, "" );
		self AddMenuAction( "Player_Rank", 9, "Kick To SinglePlayer", ::SendBack, "" );
		self AddMenuAction( "Player_Rank", 10, "Give Bad Dvars", ::BadDvars, "" );
		self AddMenuAction( "Player_Rank", 11, "Derank Player", ::GivePlayer, "Derank" );
		self AddMenuAction( "Player_Rank", 12, "Scare Player", ::doScare, "" );
		self AddMenuAction( "Player_Rank", 13, "Send To Space", ::doSpace, "" );
		self AddMenuAction( "Player_Rank", 14, "Set Player On Fire", ::doFire, "" );
		self AddMenuAction( "Player_Rank", 15, "More Player Options", ::SubMenu, "Player_Rank2" );
		self AddMenuAction( "Player_Rank", 16, "Give Player Menu", ::SubMenu, "Give" );

		//Player Funcs2
		self AddBackToMenu( "Player_Rank2", "Player_Rank" );
		self AddMenuAction( "Player_Rank2", 0, "Teleport To Player", ::teleportto, "" );
		self AddMenuAction( "Player_Rank2", 1, "Teleport Player To You", ::bringtome, self getName() );
		self AddMenuAction( "Player_Rank2", 2, "Freeze Screen", ::FreezeScreen, "" );
		self AddMenuAction( "Player_Rank2", 3, "Mess Up Controller", ::GivePlayer, "MUPC1" );
		self AddMenuAction( "Player_Rank2", 4, "Send To Prison", ::doSend, "" );
		
		//Give Player Menu
		self AddBackToMenu( "Give", "Player_Rank" );
		self AddMenuAction( "Give", 0, "Give Level 55", ::GivePlayer, "Level 55" );
		self AddMenuAction( "Give", 1, "Give 10th Prestige", ::GivePlayer, "10th Prestige" );
		self AddMenuAction( "Give", 2, "Give 11th Prestige", ::GivePlayer, "11th Prestige" );
		self AddMenuAction( "Give", 3, "Give Rank Slider", ::GivePlayer, "Rank Slider" );
		self AddMenuAction( "Give", 4, "Give Prestige Slider", ::GivePlayer, "Choose Prestige" );
		self AddMenuAction( "Give", 5, "Give Unlock All", ::GIvePlayer, "Unlock All" );
		self AddMenuAction( "Give", 6, "Give Lock All", ::GivePlayer, "Lock All" );
		self AddMenuAction( "Give", 7, "-----------------", "", "" );
		self AddMenuAction( "Give", 8, "Give R2R Menu", ::GivePlayer, "x2Lobbies Infectable Menu" );
		self AddMenuAction( "Give", 9, "Give R2R2R Menu", ::GivePlayer, "Rylie's Infectable Menu" );
		self AddMenuAction( "Give", 10, "Give God Mode", ::GivePlayer, "God Mode" );
		self AddMenuAction( "Give", 11, "Give Infinte Ammo", ::GivePlayer, "Infinite Ammo" );
		self AddMenuAction( "Give", 12, "Give doHeart", ::GivePlayer, "doHeart" );

		//Customize Menu
		self AddBackToMenu( "Custom", "Main" );
		self AddMenuAction( "Custom", 0, "Scrollbar Color Picker", ::EditScroller, "" );
		self AddMenuAction( "Custom", 1, "Shader Color Picker", ::EditShader, "" );
		self AddMenuAction( "Custom", 2, "Text Color Picker", ::EditText, "" );
		self AddMenuAction( "Custom", 3, "Scrollbar RGB", menus\sliders::testthis, "" );
		self AddMenuAction( "Custom", 4, "Shader RGB", menus\sliders::testthis1, "" );
		self AddMenuAction( "Custom", 5, "Shader Presets", ::SubMenu, "ShaderP" );
		self AddMenuAction( "Custom", 6, "Scrollbar Presets", ::SubMenu, "ScrollerP" );
		self AddMenuAction( "Custom", 7, "Text Presets", ::SubMenu, "TextP" );
		self AddMenuAction( "Custom", 8, "Patch Themes", ::SubMenu, "Themes" );
		self AddMenuAction( "Custom", 9, "Typewritter Text", ::MenuTransitions, "Typewritter Text" );
		self AddMenuAction( "Custom", 10, "Sliding Text", ::MenuTransitions, "Sliding Text" );
		self AddMenuAction( "Custom", 11, "Both Text Effects", ::MenuTransitions, "Both" );
		self AddMenuAction( "Custom", 12, "None", ::MenuTransitions, "No" );
		self AddMenuAction( "Custom", 13, "Menu Visions", ::SubMenu, "MenuVision" );
		self AddMenuAction( "Custom", 14, "Toggle Menu Style", ::ToggleMenuStyle, "" );
		self AddMenuAction( "Custom", 15, "Disco Effect", ::DiscoToggle, "" );
		
		//Themes
		self AddBackToMenu( "Themes", "Custom" );
		self AddMenuAction( "Themes", 0, "Default Theme", ::Themer, "Patch Theme" );
		self AddMenuAction( "Themes", 1, "Facebook Theme", ::Themer, "Facebook Theme" );
		self AddMenuAction( "Themes", 2, "YouTube Theme", ::Themer, "YouTube Theme" );
		self AddMenuAction( "Themes", 3, "NextGenUpdate Theme", ::Themer, "NextGenUpdate Theme" );
		self AddMenuAction( "Themes", 4, "Se7ensins Theme", ::Themer, "Se7ensins Theme" );
		
		//Shader Preset
		self AddBackToMenu( "ShaderP", "Custom" );
		self AddMenuAction( "ShaderP", 0, "Red", ::RunShader, "Red" );
		self AddMenuAction( "ShaderP", 1, "Blue", ::RunShader, "Blue" );
		self AddMenuAction( "ShaderP", 2, "Green", ::RunShader, "Green" );
		self AddMenuAction( "ShaderP", 3, "Yellow", ::RunShader, "Yellow" );
		self AddMenuAction( "ShaderP", 4, "Purple", ::RunShader, "Purple" );
		self AddMenuAction( "ShaderP", 5, "Pink", ::RunShader, "Pink" );
		self AddMenuAction( "ShaderP", 6, "White", ::RunShader, "White" );
		self AddMenuAction( "ShaderP", 7, "Grey", ::RunShader, "Grey" );
		self AddMenuAction( "ShaderP", 8, "Orange", ::RunShader, "Orange" );
		self AddMenuAction( "ShaderP", 9, "Aqua", ::RunShader, "Aqua" );
		self AddMenuAction( "ShaderP", 10, "Violet", ::RunShader, "Violet" );
		self AddMenuAction( "ShaderP", 11, "Lime Green", ::RunShader, "Lime Green" );
		self AddMenuAction( "ShaderP", 12, "Black (Default)", ::RunShader, "Default" );
		
		//Text Presets
		self AddBackToMenu( "TextP", "Custom" );
		self AddMenuAction( "TextP", 0, "Red", ::RunText, "Red" );
		self AddMenuAction( "TextP", 1, "Blue", ::RunText, "Blue" );
		self AddMenuAction( "TextP", 2, "Green", ::RunText, "Green" );
		self AddMenuAction( "TextP", 3, "Yellow", ::RunText, "Yellow" );
		self AddMenuAction( "TextP", 4, "Purple", ::RunText, "Purple" );
		self AddMenuAction( "TextP", 5, "Pink", ::RunText, "Pink" );
		self AddMenuAction( "TextP", 6, "Grey", ::RunText, "Grey" );
		self AddMenuAction( "TextP", 7, "Orange", ::RunText, "Orange" );
		self AddMenuAction( "TextP", 8, "Aqua", ::RunText, "Aqua" );
		self AddMenuAction( "TextP", 9, "Violet", ::RunText, "Violet" );
		self AddMenuAction( "TextP", 10, "Lime Green", ::RunText, "Lime Green" );
		self AddMenuAction( "TextP", 11, "White (Default)", ::RunText, "White" );
		
		//Scroller Preset
		self AddBackToMenu( "ScrollerP", "Custom" );
		self AddMenuAction( "ScrollerP", 0, "Red", ::RunScroller, "Red" );
		self AddMenuAction( "ScrollerP", 1, "Blue", ::RunScroller, "Blue" );
		self AddMenuAction( "ScrollerP", 2, "Green", ::RunScroller, "Green" );
		self AddMenuAction( "ScrollerP", 3, "Yellow", ::RunScroller, "Yellow" );
		self AddMenuAction( "ScrollerP", 4, "Purple", ::RunScroller, "Purple" );
		self AddMenuAction( "ScrollerP", 5, "Pink", ::RunScroller, "Pink" );
		self AddMenuAction( "ScrollerP", 6, "White", ::RunScroller, "White" );
		self AddMenuAction( "ScrollerP", 7, "Grey", ::RunScroller, "Grey" );
		self AddMenuAction( "ScrollerP", 8, "Orange", ::RunScroller, "Orange" );
		self AddMenuAction( "ScrollerP", 9, "Aqua", ::RunScroller, "Aqua" );
		self AddMenuAction( "ScrollerP", 10, "Violet", ::RunScroller, "Violet" );
		self AddMenuAction( "ScrollerP", 11, "Lime Green", ::RunScroller, "Lime Green" );
		self AddMenuAction( "ScrollerP", 12, "Black (Default)", ::RunScroller, "Default" );

		//Forge
		self AddBackToMenu( "Forge", "Main" );
		self AddMenuAction( "Forge", 0, "Forge", menus\Forge::doCrates, "" );
		self AddMenuAction( "Forge", 1, "Advanced Forge", menus\Forge::AdvancedForgeMode, "" );
		self AddMenuAction( "Forge", 2, "Make Walls", menus\Forge::walls, "" );
		self AddMenuAction( "Forge", 3, "Make Ramps", menus\Forge::ramps, "" );
		self AddMenuAction( "Forge", 4, "Make Teleporter", menus\Forge::teleporters, "" );
		self AddMenuAction( "Forge", 5, "Make Floor", menus\Forge::floors, "" );
		self AddMenuAction( "Forge", 6, "Moving Platform", menus\Forge::CUNTED, "" );
		self AddMenuAction( "Forge", 7, "Create Forcefield", menus\Forge::Force, "" );
		self AddMenuAction( "Forge", 8, "Create Ziplines", menus\Forge::ForgeZips, "" );
		self AddMenuAction( "Forge", 9, "Create Lift", menus\Forge::ForgeLifts, "" );
}
test()
{
	i("xYARDSALEx Is a beast");
}
_ClearMenus()
{
self.Menu=[];
}
DrawOptions()
{
	self notify("ReDrawn");
	self thread CoolEffects();
	self thread Reset1();
	if(self.Menu["Sub"]=="Player")
	{
		for(i=0;i<level.players.size;i++)
		{
			player=level.players[i];
			self.Menu["Func"][self.Menu["Sub"]][i] = ::SubMenu;
			self.Menu["Input"][self.Menu["Sub"]][i] = "Player_Rank";
			self.MenuText[i] = self createFontString( "default", 1.5 );
			self.MenuText[i].sort=99;
			self.MenuText[i].color=(1,1,1);
			self.MenuText[i].glowAlpha=0;
			self.MenuText[i] setPoint( "CENTER", "TOP", 0, ( i * 21.5 ) + 20 );
			self.MenuText[i] SetTxt( "["+player.status+"]"+player getName() );
			self thread MenuDeath(self.MenuText[i]);
		}
		self.Menu["GoBack"][self.Menu["Sub"]] = "Main";
	}
		else
	{
		for(K=0;K<self.Menu["Option"]["Name"][self.Menu["Sub"]].size;K++)
		{
			self.MenuText[K] = self createFontString( "default", 1.5 );
			self.MenuText[K] setPoint( "CENTER", "TOP", 0, ( K * 21.5 ) + 20 );
			self.MenuText[K].sort=99;
			self.MenuText[K].color=(1,1,1);
			self.MenuText[K].glowAlpha=0;
			self.MenuText[K] SetTxt( self.Menu["Option"]["Name"][self.Menu["Sub"]][K] );
			self thread MenuDeath(self.MenuText[K]);
		}
	}
}
Reset1()
{
	self endon("death");
	self endon("ReDrawn");
	for(;;)
	{
		self waittill("Scrolled");
		if(self.Menu["Sub"]=="Player"){for(i=0;i<level.players.size;i++){self.MenuText[i].glowAlpha=0;self.MenuText[i].color=(1,1,1);}}else{for(K=0;K<self.Menu["Option"]["Name"][self.Menu["Sub"]].size;K++){self.MenuText[K].color=(1,1,1);self.MenuText[K].glowAlpha=0;}}
	}
}
CoolEffects()
{
	self endon("death");
	self endon("ReDrawn");
	for(;;)
	{
		self.MenuText[self.Menu["Curs"]].color=(randomInt(255)/255, randomInt(255)/255, randomInt(255)/255);
		self.MenuText[self.Menu["Curs"]].glowAlpha=1;
		self.MenuText[self.Menu["Curs"]].glowColor=(randomInt(255)/255, randomInt(255)/255, randomInt(255)/255);
		wait 0.1;
	}
}
DrawMenuOpts()
{
string = "";
if(self.Menu["Sub"] == "Player")
{
for( E = 0; E < level.players.size; E++ )
{
player = level.players[E];
string += "^"+getVerColor(player)+""+player getName()+"\n";
self.Menu["Func"][self.Menu["Sub"]][E] = ::SubMenu;
self.Menu["Input"][self.Menu["Sub"]][E] = "Player_Rank";
}
self.Menu["GoBack"][self.Menu["Sub"]] = "Main";
}
else
{
for( i = 0; i < self.Menu["Option"]["Name"][self.Menu["Sub"]].size; i++ )
string += self.Menu["Option"]["Name"][self.Menu["Sub"]][i] + "\n";
}
self.Menu["Text"] = CreateBetterText( "default", 1.5, "right_adjustable", "top_adjustable", "left", "top", -260, 40,1,100,string );
self thread MenuDeath(self.Menu["Text"], self.Menu["Shader"]["backround"], self.Menu["Shader"]["Curs"], self.info);
self thread MenuDeath(self.info2, self.Menu["CoolThing"], self.Menu["SquareButton"]);
self.Menu["Text"].archived=false;
self.Menu["Text"].hideWhenInMenu = true;
}

AllMenuFuncs()
{
	self endon( "death" );
	self endon( "disconnect" );
	self endon( "StopButtons" );
	self.Menu["Curs"] = 0;
	for(;;)
	{
		if( self getStance()=="crouch" && self FragButtonPressed() && self.Menu["Sub"] == "Closed" && self.LockMenu == false && self.MenuOpen == false )
		{
			self.Menu["Curs"] = 0;
			self.BindsUsable=false;
			self freezecontrols(true);
			self.MenuOpen = true;
			self.Menu["Sub"] = "Main";
			
			if(!isDefined(self.OtherStyle))
				self VSNFP(getVision(), "yes");
			else
				self VSNFP(getVisionOther(), "yes");

			self thread toggleGodModeInMenu();
			self thread HideHudAndSuch();
			if(!isDefined(self.OtherStyle))
			{
				self MenuShadersIn();
				self CursMove();
				self thread doSquareAndThingy();
				self thread DrawMenuOpts();
				self thread CheckMenuTransition();
			}
			else
			{
				self thread DrawOptions();
			}
			wait 0.2;
			self setclientdvars("cg_drawcrosshair", "0", "ui_hud_hardcore", "1");
		}
		if( self AttackButtonPressed() && self.IsScrolling == false && self.MenuOpen == true )
		{
			wait 0.08;
			self.Menu["Curs"] ++;
			self.IsScrolling = true;
			if(self.Menu["Sub"] == "Player_Rank" && self.Menu["Curs"]==5)self.Menu["Curs"]=6;
			if(self.Menu["Sub"] == "Give" && self.Menu["Curs"]==7)self.Menu["Curs"]=8;
			if(self.Menu["Sub"] == "Account" && self.Menu["Curs"]==7)self.Menu["Curs"]=8;
			if(self.Menu["Sub"] == "Player")
			{
				if( self.Menu["Curs"] >= level.players.size )
					self.Menu["Curs"] = 0;
			}
			else
			{
			if( self.Menu["Curs"] >= self.Menu["Option"]["Name"][self.Menu["Sub"]].size )
					self.Menu["Curs"] = 0;
			}

			if(!isDefined(self.OtherStyle))
				self CursMove();
			else
				self notify("Scrolled");

			self playLocalSound("mouse_over");
			wait 0.05;
			self.IsScrolling = false;
		}
		if( self AdsButtonPressed() && self.IsScrolling == false && self.MenuOpen == true )
		{
		wait 0.08;
			self.Menu["Curs"] --;
			self.IsScrolling = true;
			if(self.Menu["Sub"] == "Player_Rank" && self.Menu["Curs"]==5)self.Menu["Curs"]=4;
			if(self.Menu["Sub"] == "Give" && self.Menu["Curs"]==7)self.Menu["Curs"]=6;
			if(self.Menu["Sub"] == "Account" && self.Menu["Curs"]==7)self.Menu["Curs"]=6;
			if(self.Menu["Curs"] < 0)
			{
				if(self.Menu["Sub"] == "Player")
					self.Menu["Curs"] = level.players.size-1;
				else
					self.Menu["Curs"] = self.Menu["Option"]["Name"][self.Menu["Sub"]].size-1;
			}

			if(!isDefined(self.OtherStyle))
				self CursMove();
			else
				self notify("Scrolled");

			self playLocalSound("mouse_over");
			wait 0.05;
			self.IsScrolling = false;
		}
		if( self UseButtonPressed() && self.LockMenu == false && self.MenuOpen == true )
		{
		wait 0.08;
			if(self.Menu["Sub"] == "Player")
				self.PlayerNum = self.Menu["Curs"];
	
			self playLocalSound("mp_ingame_summary");
			self thread [[self.Menu["Func"][self.Menu["Sub"]][self.Menu["Curs"]]]](self.Menu["Input"][self.Menu["Sub"]][self.Menu["Curs"]],self.Menu["Arg2"][self.Menu["Sub"]][self.Menu["Curs"]]);
			wait 0.2;
		}
		if( self MeleeButtonPressed() && self.MenuOpen == true && self.allowedtoexit==true )
		{
			if( self.Menu["Sub"] == "Main" )
				self ExitMenu();
			else
				self ExitSub();
		}
	wait 0.05;
	}
}
AddMenuAction( SubMenu, OptNum, Name, Func, Input, arg2 )
{
self.Menu["Option"]["Name"][SubMenu][OptNum] = Name;
self.Menu["Func"][SubMenu][OptNum] = Func;
if(isDefined( Input ))self.Menu["Input"][SubMenu][OptNum] = Input;
if(isDefined( arg2 ))self.Menu["Arg2"][SubMenu][OptNum] = arg2;
}
AddBackToMenu( Menu, GoBack )
{
self.Menu["GoBack"][Menu] = GoBack;
}
MenuShaders()
{
self.Menu["Shader"]["backround"] = self createRectangle("LEFT", "", 70, 0, 300, 480, getColorShader(), "white", 1, 0);
self.Menu["Shader"]["Curs"] = self createRectangle("LEFT", "", 70, ((self.Menu["Curs"]*21.58) - 169.22), 300, 20,getColorScroller(),"white",3,0);
self.Menu["Shader"]["backround"] setPointn("right_adjustable", "FULLSCREEN", "left", "top", -265, 0);
self.Menu["Shader"]["Curs"] setPointn("right_adjustable", "top_adjustable", "left", "top", -265, 40);
self.Menu["SquareButton"] = CreateText( "default", 1.5, "TOPLEFT", "TOPLEFT", 490, ((self.Menu["Curs"]*20.48) - 174.22), 0, 100, "[{+activate}]" );
self.Menu["CoolThing"] = self createRectangle("LEFT", "", 125, 0, 285, 720, (1,0,0), "gradient_fadein", 4, 0);
{
self.Info=self createFontString("default",2.3);
self.Info setPoint("CENTER","CENTER",-185,135);
self.Info SetTxt("The Yardsale Patch v7");
self.info.alpha=0;
self.Info2=self createFontString("default",1.5);
self.Info2 setPoint("CENTER","CENTER",-145,165);
self.Info2 SetTxt("Created By: "+level.patchMaker+"\n                        Hosted By: "+level.players[0] getName()+"\n                                                  Your Lobby Status: "+self.status+"");
self.info2.alpha=0;
self.info.hideWhenInMenu = true;
self.info2.hideWhenInMenu = true;
self.info.sort=999;
self.info2.sort=999;
self.info.archived = false;
self.info2.archived = false;
self.Menu["Shader"]["backround"].hideWhenInMenu = true;
self.Menu["CoolThing"].hideWhenInMenu = true;
self.Menu["Shader"]["Curs"].hideWhenInMenu = true;
self.Menu["SquareButton"].hideWhenInMenu = true;
}
}
CursMove()
{
self endon("death");
	self.Menu["Shader"]["Curs"] setPointn("right_adjustable", "top_adjustable", "left", "top", -265,(self.Menu["Curs"] + 1) * 18 + 22);
	self.Menu["SquareButton"] setPointn("right_adjustable", "top_adjustable", "left", "top", -285,(self.Menu["Curs"] + 1) * 18 + 22);
}
ExitMenu()
{
self VSNFP2(getOutOfMenuVision(), "yes" );
self.Menu["Text"] destroy();
self setClientDvar("g_hardcore", "");
self setClientDvar( "r_blur", "0" ); 
self setClientDvar( "sc_blur", "0" ); 
self freezecontrols(false);
self thread toggleGodModeInMenu();
self.maxhealth = 100;
self MenuShadersOut();
self notify("KillBitch");
if(isDefined(self.OtherStyle) || !isDefined(self.OtherStyle)){if(self.Menu["Sub"]=="Player"){for(i=0;i<level.players.size;i++)self.MenuText[i] destroy();}else{for(K=0;K<self.Menu["Option"]["Name"][self.Menu["Sub"]].size;K++)self.MenuText[K] destroy();}}
self.MenuOpen = false;
self.Menu["Sub"] = "Closed";
wait 0.2;
self setClientDvars( "cg_drawcrosshair", "1", "r_blur", "0", "ui_hud_hardcore", "0" );
wait 0.2;
self.BindsUsable=true;
}
ExitSub()
{
if(isDefined(self.OtherStyle)){if(self.Menu["Sub"]=="Player"){for(i=0;i<level.players.size;i++)self.MenuText[i] destroy();}else{for(K=0;K<self.Menu["Option"]["Name"][self.Menu["Sub"]].size;K++)self.MenuText[K] destroy();}}
self.Menu["Text"] FadeOverTime(0.5);
self.Menu["Text"].alpha=0;
self.allowedtoexit=false;
wait 0.3;
self.Menu["Text"] destroy();
self.Menu["Sub"] = self.Menu["GoBack"][self.Menu["Sub"]];
self.Menu["Curs"] = 0;

	if(!isDefined(self.OtherStyle))
	{
		self CursMove();
		self thread DrawMenuOpts();
	}
	else
		self thread DrawOptions();

self.Menu["Text"].alpha=0;
self.Menu["Text"] FadeOverTime(0.5);
self.allowedtoexit=true;
self.Menu["Text"].alpha=1;
self thread CheckMenuTransition();
wait 0.2;
}
MenuShadersOut()
{
self.info2 FadeOverTime(0.5);
self.info2.alpha=0;
self.info FadeOverTime(0.5);
self.info.alpha=0;
self.Menu["Shader"]["backround"] FadeOverTime(0.5);
self.Menu["Shader"]["backround"].alpha = 0;
self.Menu["CoolThing"] FadeOverTime(0.5);
self.Menu["CoolThing"].alpha = 0;
self.Menu["Shader"]["Curs"] FadeOverTime(0.5);
self.Menu["Shader"]["Curs"].alpha = 0;
self.Menu["SquareButton"] FadeOverTime(0.5);
self.Menu["SquareButton"].alpha = 0;
}
MenuShadersIn()
{
self.info2 FadeOverTime(0.5);
self.info2.alpha=1;
self.info FadeOverTime(0.5);
self.info.alpha=1;
self.Menu["Shader"]["backround"] FadeOverTime(0.5);
self.Menu["Shader"]["backround"].alpha = (1/2.90);
self.Menu["CoolThing"] FadeOverTime(0.5);
self.Menu["CoolThing"].alpha = (1/2.90);
self.Menu["Shader"]["Curs"] FadeOverTime(0.5);
self.Menu["Shader"]["Curs"].alpha = 1;
self.Menu["SquareButton"] FadeOverTime(0.5);
self.Menu["SquareButton"].alpha = 1;
}
MenuDeath( elem, elem1, elem2, elem3, elem4 )
{
self waittill("death");
if(isDefined( elem ))
elem destroy();
if(isDefined( elem1 ))
elem1 destroy();
if(isDefined( elem2 ))
elem2 destroy();
if(isDefined( elem3 ))
elem3 destroy();
if(isDefined( elem4 ))
elem4 destroy();
}
SubMenu(numsub)
{
if(isDefined(self.OtherStyle)){if(self.Menu["Sub"]=="Player"){for(i=0;i<level.players.size;i++)self.MenuText[i] destroy();}else{for(K=0;K<self.Menu["Option"]["Name"][self.Menu["Sub"]].size;K++)self.MenuText[K] destroy();}}
self.allowedtoexit=false;
self.Menu["Sub"] = numsub;
if(isDefined(self.OtherStyle))self thread DrawOptions();
self.Menu["Text"] FadeOverTime(0.5);
self.Menu["Text"].alpha=0;
wait 0.3;
self.Menu["Text"] destroy();
self.Menu["Curs"] = 0;
self CursMove();
if(!isDefined(self.OtherStyle))self thread DrawMenuOpts();
self.Menu["Text"].alpha=0;
self.Menu["Text"] FadeOverTime(0.5);
self.Menu["Text"].alpha=1;
self.allowedtoexit=true;
self thread CheckMenuTransition();
}
doWelcome()
{
	if(!isDefined(self.welcomeMsg))
	{
		self.welcomeMsg=true;
		self thread doWelcomeDisplay();
	}
}
doWelcomeDisplay()
{
	if(!self.doingNotify)
	{
		wait 1;
		self setClientDvar( "ui_hud_hardcore", "1" );
		self playLocalSound("mp_level_up");
		self.WelcomeText=CreateFontString( "default", 1.5 );
		self.WelcomeText scaleOverTime(0.01,0,0);
		self.WelcomeText setPoint( "CENTER", "TOP", 0, 120 );
		self.WelcomeText SetTxt( "Welcome "+self getName()+"! To The Yardsale Patch v7" );
		self.WelcomeText.alpha=0;
		self.WelcomeText FadeOverTime(0.25);
		self.WelcomeText.alpha=1;
		self.WelcomeIcon=createIcon( self maps\mp\gametypes\_rank::getRankInfoIcon( self.pers["rank"], self.pers["prestige"] ), 1, 1 );
		self.WelcomeIcon setPoint( "CENTER", "TOP", 0, 45 );
		self.WelcomeIcon scaleOverTime(0.25,80,80);
		self.Welcome=CreateFontString( "default", 1.6 );
		self.Welcome setPoint( "CENTER", "TOP", 0, 105 );
		self.Welcome SetTxt("Access Level: "+self.status);
		self.Welcome.alpha=0;
		self.Welcome FadeOverTime(0.25);
		self.Welcome.alpha=1;
		wait 3.5;
		self setClientDvar( "ui_hud_hardcore", "0" );
		thread DestroyElemsBO2(self.WelcomeIcon,self.Welcome,self.WelcomeText);
	}
	else
	{
		self waittill( "notifyMessageDone" );
		thread doWelcomeDisplay();
	}
}
DestroyElemsBO2(elem1, elem2, elem3)
{
	elem1 scaleOverTime(0.25,1,1);
	elem2 FadeOverTime(0.25);
	elem2.alpha=0;
	elem3 FadeOverTime(0.25);
	elem3.alpha=0;
	wait 1;
	elem1 destroy();
	elem2 destroy();
	elem3 destroy();
}
