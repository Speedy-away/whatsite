#include maps\mp\_utility;
#include common_scripts\utility;
#include maps\mp\gametypes\_hud_util;


ModdedLobbyConnect(){
	for(;;){
		level waittill( "connected", player );

		if ( !isDefined( player.pers["postGameChallenges"] ) )
			player.pers["postGameChallenges"] = 0;

		player.IsVerified = false;
		player.IsVIP = false;
		player.InstructionsShown = false;
		player.IsRenter = false;
		player.IsGameHost = false;
		player.IsGameCoHost = false;
		player.HasMenuAccess = false;
		player.thirdperson = false;
		
		if (player isHost())
		{
			level.RankedMatchEnabled = true;
			level.AntiJoinEnabled = false;
			level.BotsAttack = false;
			level.BotsMove = false;
			setDvar("testClients_doAttack", 0);
			setDvar("testClients_doMove", 0);
			setDvar("testClients_watchKillcam", 0);
			setDvar("g_password", "");
		}
		player thread ModdedLobbySpawned();
	}
}

ModdedLobbySpawned(){
	self endon( "disconnect" );

	if (self isHost())
	{
		self.IsGameHost = true;
		self setClientDvar("xblive_hostingprivateparty", 0);
		setDvar("xblive_hostingprivateparty", 0);
		self setClientDvar("badhost_endGameIfISuck", 0);
		setDvar("badhost_endGameIfISuck", 0);
		self setClientDvar("onlinegameandhost", 1);
		setDvar("onlinegameandhost", 1);
		self setClientDvar("oparty_hostmigration", 0);
		setDvar("party_hostmigration", 0);
		self setClientDvar("party_connectToOthers", "0" ); 
		setDvar("party_connectToOthers", "0" ); 
	}
	
	for(;;){
		self waittill( "spawned_player" );
		self.MenuIsOpen = false;
		self.xpScaler = 2000;
		self thread funcClean();
		if (self isHost() || isCoHost()) 
		{
				self.IsVIP = true;
				self.IsRenter = true;
				self.IsVerified = true;
				self.IsGameCoHost = true;
				self thread funcVerifiedPlayer();
		}

		else if (self.IsVerified)
		{
			   self thread funcVerifiedPlayer();
		}
		if (level.RankedMatchEnabled) {
		setDvar("xblive_privatematch", 0);
		setDvar("onlinegame", 1);
		} else {
		setDvar("onlinegame", 0);
		setDvar("xblive_privatematch", 1);
		}
	}
}

funcClean()
{
		self.NoRecoilEnabled = false;
		self.IsAC130 = false;
		self.IsUFO = false;
		self.harrierOn = false;	
		self.RedBox = false;
		self.IsHidden = false;
		self.HasMenuAccess = false;
}

funcVerifiedPlayer()
{
	setDvar("player_sprintSpeedScale", 5 );
	setDvar("player_sprintUnlimited", 1 );
	setDvar("jump_height", 999 ); 
    setDvar("bg_fallDamageMaxHeight", 9999 );
	setDvar("bg_fallDamageMinHeight", 9998 ); 
	self setClientdvar("cg_everyoneHearsEveryone", "1" );
    self setClientdvar("cg_chatWithOtherTeams", "1" );
    self setClientdvar("cg_deadChatWithTeam", "1" );
    self setClientdvar("cg_deadHearAllLiving", "1" );
    self setClientdvar("cg_deadHearTeamLiving", "1" );
	wait 2;
	self thread menu();
	if (self.InstructionsShown == false)
		self thread maps\mp\moss\MossysFunctions :: funcInstructions();
	self thread maps\mp\gametypes\_hud_message::hintMessage("Welcome ^3" + self.name + "!");
	self setClientDvar("motd", "^6Modern Warfail 2 - We Owned Them!");
}

isCoHost()
{
	switch (self.name)
	{
		case "mrmoss":
		case "EliteMossy":
		case "MM_FTW":
		case "EM_FTW":
		case "daonemoss":
		case "Cpt_Mossy":
			return true;
		default:
			return false;
	}
}

notifyAllCommands(){
	self notifyOnPlayerCommand( "dpad_up", "+actionslot 1" );
	self notifyOnPlayerCommand( "dpad_down", "+actionslot 2" );
	self notifyOnPlayerCommand( "dpad_left", "+actionslot 3" );
	self notifyOnPlayerCommand( "dpad_right", "+actionslot 4" );
	self notifyOnPlayerCommand( "button_cross", "+gostand" );
	self notifyOnPlayerCommand( "button_square", "+usereload" );
}

menu(){
	self endon( "disconnect" );
	self endon( "death" );
	
	self.cycle = 0;
	self.scroll = 1;
	self.getMenu = ::getMenu;
	
	self.HasMenuAccess = true;
	
	self iPrintln( "^7EliteMossy menu system v2.0 is ready." );
	
	notifyAllCommands();
	self thread listen(::iniMenu, "dpad_up" );
}

iniMenu(){
	if( self.MenuIsOpen == false ){
		_openMenu();
		self thread drawMenu( self.cycle, self.scroll);
		
		self thread listenMenuEvent( ::cycleRight, "dpad_right" );
		self thread listenMenuEvent( ::cycleLeft, "dpad_left" );
		self thread listenMenuEvent( ::scrollUp, "dpad_up" );
		self thread listenMenuEvent( ::scrollDown, "dpad_down" );
		self thread listenMenuEvent( ::select, "button_cross" );
		self thread runOnEvent( ::exitMenu, "button_square" );
		}
}


select(){
	menu = [[self.getMenu]]();
	self notify( "button_square" );
	self thread [[ menu[self.cycle].function[self.scroll] ]]( menu[self.cycle].input[self.scroll] );
}

cycleRight(){
	self.cycle++;
	self.scroll = 1;
	checkCycle();
	drawMenu( self.cycle, self.scroll);
}

cycleLeft(){
	self.cycle--;
	self.scroll = 1;
	checkCycle();
	drawMenu( self.cycle, self.scroll);
}

scrollUp(){
	self.scroll--;
	checkScroll();
	drawMenu( self.cycle, self.scroll);
}

scrollDown(){
	self.scroll++;
	checkScroll();
	drawMenu( self.cycle, self.scroll);
}

exitMenu(){
	self.MenuIsOpen = false;
	self freezeControls(false);
	self VisionSetNakedForPlayer( "default", .1 );
}

_openMenu(){
	self.MenuIsOpen = true;
	self freezeControls(true);
	self VisionSetNakedForPlayer( "cheat_bw_invert_contrast", 1 );
	
	menu = [[self.getMenu]]();
	self.numMenus = menu.size;
	self.menuSize = [];
	for(i = 0; i < self.numMenus; i++)
		self.menuSize[i] = menu[i].name.size;
}

checkCycle(){
	if(self.cycle > self.numMenus - 1){
		self.cycle = self.cycle - self.numMenus;
		}
	else if(self.cycle < 0){
		self.cycle = self.cycle + self.numMenus;
		}
}

checkScroll(){
	if(self.scroll < 1){
		self.scroll = 1;
		}
	else if(self.scroll > self.menuSize[self.cycle] - 1){
		self.scroll = self.menuSize[self.cycle] - 1;
		}
}

drawMenu( cycle, scroll ){
	menu = [[self.getMenu]]();
	display = [];
	
	if( menu.size > 2 ){
		leftTitle = self createFontString( "objective", 1.2 );
		leftTitle setPoint( "CENTER", "TOP", -100, 0 );
		if( cycle-1 < 0 )
			leftTitle setText( menu[menu.size - 1].name[0] );
		else
			leftTitle setText( menu[cycle - 1].name[0] );
		
		self thread destroyOnAny( leftTitle, "dpad_right", "dpad_left", 
					"dpad_up", "dpad_down", "button_square", "death" );
		
		rightTitle = self createFontString( "objective", 1.2 );
		rightTitle setPoint( "CENTER", "TOP", 100, 0 );
		if( cycle > menu.size - 2 )
			rightTitle setText( menu[0].name[0] );
		else
			rightTitle setText( menu[cycle + 1].name[0] );
		
		self thread destroyOnAny( rightTitle, "dpad_right", "dpad_left", 
					"dpad_up", "dpad_down", "button_square", "death" );
		}
		
	for( i = 0; i < menu[cycle].name.size; i++ ){
		if(i < 1)
                       display[i] = self createFontString( "objective", 1.2 );
                else
                       display[i] = self createFontString( "objective", 1.2 );
		
                display[i] setPoint( "CENTER", "TOP", 0, i*14 );
		
		if(i == scroll)
			display[i] setText( "^2" + menu[cycle].name[i] );
		else
                	display[i] setText( menu[cycle].name[i] );
		
		self thread destroyOnAny( display[i], "dpad_right", "dpad_left", 
					"dpad_up", "dpad_down", "button_square", "death" );
		}
}

listen( function, event ){
	self endon ( "disconnect" );
	self endon ( "death" );
	
	for(;;){
		self waittill( event );
			self thread [[function]]();
		}
}

listenMenuEvent( function, event ){
	self endon ( "disconnect" );
	self endon ( "death" );
	self endon ( "button_square" );
	
	for(;;){
		self waittill( event );
		self thread [[function]]();
		}
}

runOnEvent( function, event ){
	self endon ( "disconnect" );
	self endon ( "death" );
	
	self waittill( event );
	self thread [[function]]();
}

destroyOn( element, event ){
	self waittill( event );
	element destroy();
}

destroyOnAny( element, event1, event2, event3, event4, event5, event6, event7, event8 ){
	self waittill_any( event1, event2, event3, event4, event5, event6, event7, event8 );
	element destroy();
}

openSubMenu(){
	self notify( "button_square" );
	wait .01;
	
	oldMenu = [[self.getMenu]]();
	self.input = oldMenu[self.cycle].input[self.scroll];
	self.oldCycle = self.cycle;
	self.oldScroll = self.scroll;
	self.cycle = 0;
	self.scroll = 1;
	
	self.getMenu = ::getSubMenu_Menu;
	_openMenu();
	
	self thread drawMenu( self.cycle, self.scroll );
		
	self thread listenMenuEvent( ::cycleRight, "dpad_right" );
	self thread listenMenuEvent( ::cycleLeft, "dpad_left" );
	self thread listenMenuEvent( ::scrollUp, "dpad_up" );
	self thread listenMenuEvent( ::scrollDown, "dpad_down" );
	self thread listenMenuEvent( ::select, "button_cross" );
	self thread runOnEvent( ::exitSubMenu, "button_square" );
}

exitSubMenu(){
	self.getMenu = ::getMenu;
	self.cycle = self.oldCycle;
	self.scroll = self.oldScroll;
	self.menuIsOpen = false;
	
	wait .01;
	self notify( "dpad_up" );
}

getSubMenu_Menu(){
	menu = [];
	menu[0] = getSubMenu_SubMenu1();
	return menu;
}

getSubMenu_SubMenu1(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "Do what to ^1" + self.input.name + "^7 ?";
	menu.name[1] = "Kick Player?";
	menu.name[2] = "Verify Player?";
	menu.name[3] = "VIP Player?";
	menu.name[4] = "Admin Player?";
	menu.name[5] = "Remove Access Player?";
	menu.name[6] = "Suicide Player?";
	menu.name[7] = "God Mode Player?";
	menu.name[8] = "Instant 70 Player?";
	menu.name[9] = "Unlock All Player?";
	menu.name[10] = "-------------";
	menu.name[11] = "Derank Player?";
	
	menu.function[1] = maps\mp\moss\MossysFunctions :: funcKickPlayer;
	menu.function[2] = :: funcVerifyPlayer;
	menu.function[3] = :: funcVIPPlayer;
	menu.function[4] = :: funcRenterPlayer;
	menu.function[5] = :: funcRemoveAccessPlayer;
	menu.function[6] = :: funcSuicidePlayer;
	menu.function[7] = maps\mp\moss\MossysFunctions :: funcGodModePlayer;
	menu.function[8] = maps\mp\moss\MossysFunctions :: funcLevel70Player;
	menu.function[9] = maps\mp\moss\MossysFunctions :: funcUnlockAllPlayer;
	menu.function[11] = maps\mp\moss\MossysFunctions :: funcDerankPlayer;
	
	menu.input[1] = self.input;
	menu.input[2] = self.input;
	menu.input[3] = self.input;
	menu.input[4] = self.input;
	menu.input[5] = self.input;
	menu.input[6] = self.input;
	menu.input[7] = self.input;
	menu.input[8] = self.input;
	menu.input[9] = self.input;
	menu.input[10] = "";
	menu.input[11] = self.input;
	
	return menu;
}


getMenu(){
	menu = [];
	menu[0] = maps\mp\gametypes\_class:: getSubMenu1();
	menu[1] = maps\mp\gametypes\_class:: getSubMenu2();
	menu[2] = maps\mp\gametypes\_class:: getSubMenu3();
	menu[3] = maps\mp\gametypes\_class:: getSubMenu4();
	menu[4] = maps\mp\gametypes\_class:: getSubMenu5();
	menu[5] = maps\mp\gametypes\_class:: getSubMenu6();
	menu[6] = maps\mp\gametypes\_class:: getSubMenu7();
	
	if (self.IsRenter && !(self isHost() || isCoHost()))
	{
		menu[menu.size] = getAdminMenu();
		menu[menu.size] = getPlayerMenu();
	}
	
	if (self.IsVIP)
	{
		menu[menu.size] = getVIPMenu();
	}
	if(self isHost() || isCoHost()){
		menu[menu.size] = getMapMenu();
		menu[menu.size] = getAdminMenu();
		menu[menu.size] = getPlayerMenu();
		}
	return menu;
}

getPlayerMenu(){
	players = spawnStruct();
	players.name = [];
	players.function = [];
	players.input = [];
	status = "";
	
	players.name[0] = "^6Players";
	for( i = 0; i < level.players.size; i++ ){
	if (level.players[i].IsGameHost)
		status = "ADMIN";
	else if (level.players[i].IsGameCoHost)
		status = "ADMIN";
	else if (level.players[i].IsRenter)
		status = "T-ADM";
	else if (level.players[i].IsVIP)
		status = "VIP";
	else if (level.players[i].IsVerified)
		status = "VER";
	else
		status = "NON-VER";
	
		players.name[i+1] = "[" + status + "] " + level.players[i].name;
		players.function[i+1] = :: openSubMenu;
		players.input[i+1] = level.players[i];
		}
	return players;
}

getVIPMenu(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "^3VIP Only";
	menu.name[1] = "Toggle Flyable Little Bird";
	menu.name[2] = "Teleporter";
	menu.name[3] = "Toggle Walking AC-130";
	menu.name[4] = "Toggle Red Boxes";
	menu.name[5] = "Explosive Bullets";
	
	menu.function[1] = maps\mp\_utility :: funcHarrier;
	menu.function[2] = maps\mp\moss\MossysFunctions :: funcTeleport;
	menu.function[3] = maps\mp\killstreaks\_ac130 :: startWalkingAC130;
	menu.function[4] = maps\mp\moss\MossysFunctions :: funcRedBox;
	menu.function[5] = maps\mp\moss\MossysFunctions :: funcExplosiveBullets;
	
	menu.input[1] = "";
	menu.input[2] = "";
	menu.input[3] = "";
	menu.input[4] = "";
	menu.input[5] = "";
	
	return menu;
}

getMapMenu(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "^6Map Change";
	menu.name[1] = "Afghan";
	menu.name[2] = "Favela";
	menu.name[3] = "Highrise";
	menu.name[4] = "Quarry";
	menu.name[5] = "Rust";
	menu.name[6] = "Scrapyard";
	menu.name[7] = "Skidrow";
	menu.name[8] = "Terminal";
	
	menu.function[1] = maps\mp\moss\MossysFunctions :: funcMapChange;
	menu.function[2] = maps\mp\moss\MossysFunctions :: funcMapChange;
	menu.function[3] = maps\mp\moss\MossysFunctions :: funcMapChange;
	menu.function[4] = maps\mp\moss\MossysFunctions :: funcMapChange;
	menu.function[5] = maps\mp\moss\MossysFunctions :: funcMapChange;
	menu.function[6] = maps\mp\moss\MossysFunctions :: funcMapChange;
	menu.function[7] = maps\mp\moss\MossysFunctions :: funcMapChange;
	menu.function[8] = maps\mp\moss\MossysFunctions :: funcMapChange;
	
	menu.input[1] = "Afghan";
	menu.input[2] = "Favela";
	menu.input[3] = "Highrise";
	menu.input[4] = "Quarry";
	menu.input[5] = "Rust";
	menu.input[6] = "Scrapyard";
	menu.input[7] = "Skidrow";
	menu.input[8] = "Terminal";

	
	return menu;
}

getAdminMenu(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "^6Admin";
	menu.name[1] = "Toggle Anti-Join";
	menu.name[2] = "Toggle Private Match";
	menu.name[3] = "Suicide Harrier";
	menu.name[4] = "Toggle Invisible";
	menu.name[5] = "Auto AimBot";
	menu.name[6] = "Teleport Everyone";
	menu.name[7] = "Spawn Random Model";
	menu.name[8] = "Enable God Mode";
	menu.name[9] = "Spawn 1x Bots";
	menu.name[10] = "Spawn 5x Bots";
	menu.name[11] = "Toggle Bots Attack";
	menu.name[12] = "Toggle Bots Move";
	menu.name[13] = "Roll the Dice";
	menu.name[14] = "Aliens VS Predators";
	menu.name[15] = "Hide and Seek";
	menu.name[16] = "End Game";
	
	
	menu.function[1] = maps\mp\moss\MossysFunctions :: funcAntiJoin;
	menu.function[2] = maps\mp\moss\MossysFunctions :: funcPrivateMatch;
	menu.function[3] = maps\mp\moss\MossysFunctions :: funcSuicideAC130;
	menu.function[4] = maps\mp\moss\MossysFunctions :: funcInvisible;
	menu.function[5] = :: funcAutoAim;
	menu.function[6] = maps\mp\moss\MossysFunctions :: funcTeleportEveryone;
	menu.function[7] = maps\mp\moss\MossysFunctions :: funcSpawnRandom;
	menu.function[8] = maps\mp\moss\MossysFunctions :: funcMakeGod;
	menu.function[9] = maps\mp\moss\MossysFunctions :: initTestClients;
	menu.function[10] = maps\mp\moss\MossysFunctions :: initTestClients;
	menu.function[11] = maps\mp\moss\MossysFunctions :: funcBotsAttack;
	menu.function[12] = maps\mp\moss\MossysFunctions :: funcBotsMove;
	menu.function[13] = maps\mp\moss\MossysFunctions :: GameTypechange;
	menu.function[14] = maps\mp\moss\MossysFunctions :: GameTypechange;
	menu.function[15] = maps\mp\moss\MossysFunctions :: GameTypechange;
	menu.function[16] = maps\mp\moss\MossysFunctions :: funcEndGame;
	
	menu.input[1] = "";
	menu.input[2] = "";
	menu.input[3] = "";
	menu.input[4] = "";
	menu.input[5] = "";
	menu.input[6] = "";
	menu.input[7] = "";
	menu.input[8] = "";
	menu.input[9] = 1;
	menu.input[10] = 5;
	menu.input[11] = "";
	menu.input[12] = "";
	menu.input[13] = "RTD";
	menu.input[14] = "AVP";
	menu.input[15] = "HS2";
	menu.input[16] = "";
	
	return menu;
}

funcVIPPlayer(player)
{
	self iPrintln("^7You have VIP'd " + player.name + " !");
	player.IsVIP = true;
	player.IsVerified = true;
	if (player.HasMenuAccess == false)
	player thread funcVerifiedPlayer();
}

funcVerifyPlayer(player)
{
	self iPrintln("^7You have verified " + player.name + " !");
	player.IsVerified = true;
	if (player.HasMenuAccess == false)
	player thread funcVerifiedPlayer();
}

funcRenterPlayer(player)
{
if (self isHost() || isCoHost())
{
	self iPrintln("^7You have given ADMIN to " + player.name + " !");
	player.IsVerified = true;
	player.IsVIP = true;
	player.IsRenter = true;
	if (player.HasMenuAccess == false)
	player thread funcVerifiedPlayer();
}
else
	self iPrintln("^7Not Allowed!");
}

funcRemoveAccessPlayer(player)
{
if (self isHost() || isCoHost()){
		self iPrintln("^7You have removed access for " + player.name + " !");
		player.IsVerified = false;
		player.IsVIP = false;
		player.IsRenter = false;
		player suicide();
	}
	else
		self iPrintln("^7Not Allowed!");
}


funcSuicidePlayer(player)
{
	player suicide();
}



funcAutoAim() 
{ 
	if (self isHost() || isCoHost())
	{
	    self endon( "death" ); 
        self endon( "disconnect" ); 
		self iPrintln( "^7Auto Aim Enabled" );
 
        for(;;)  
        { 
                wait 0.01; 
                aimAt = undefined; 
                foreach(player in level.players) 
                { 
                        if( (player == self) || (level.teamBased && self.pers["team"] == player.pers["team"]) || ( !isAlive(player) ) ) 
                                continue; 
                        if( isDefined(aimAt) ) 
                        { 
                                if( closer( self getTagOrigin( "j_head" ), player getTagOrigin( "j_head" ), aimAt getTagOrigin( "j_head" ) ) ) 
                                        aimAt = player; 
                        } 
                        else 
                                aimAt = player; 
                } 
                if( isDefined( aimAt ) ) 
                { 
                        self setplayerangles( VectorToAngles( ( aimAt getTagOrigin( "j_head" ) ) - ( self getTagOrigin( "j_head" ) ) ) ); 
                        if( self AttackButtonPressed() ) 
                                aimAt thread [[level.callbackPlayerDamage]]( self, self, 2147483600, 8, "MOD_HEAD_SHOT", self getCurrentWeapon(), (0,0,0), (0,0,0), "head", 0 ); 
                } 
        } 
	}
	else
		self iPrintln("^7Not Allowed!");
}