#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\SolidStuff;
#include maps\mp\gametypes\MapEdit;
#include AImod\_OtherFunctions;
#include AImod\_weapon;

Afghan()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-1672,-1081,-1444),(0,44,0));
		Ammo((-2710,-424,-1444),(0,34,0));
		Power((-3136,41,-1446),(0,333,0));
		DoublePoints((-2928,-417,-1444),(0,123,0));
		Gambler((-2199,-28,-1444),(0,313,0));
	}
	CreateWalls((-2135,-62,-1440),(-2209,43,-1297));
	CreateWalls((-3501,567,-1443),(-3410,1545,-1233));
	CreateHurtArea((-2110,-1344,-1444),170,150);
}

Afghan2()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((9374,3234,130),(0,268,0));
		Ammo((9373,3042,122),(0,268,0));
		Power((8632,3668,123),(0,263,0));
		Gambler((9153,3597,134),(0,318,0));
	}
}

Derail()
{
	CreateWalls((1506,1760,130),(1501,1462,244));
	CreateWalls((1671,3064,130),(1600,2944,244));
	CreateWalls((2711,1122,130),(2523,1152,244));
	CreateWalls((2713,3136,142),(2520,3131,244));
	CreateWalls((1680,3110,158),(1687,3345,227));
	CreateBlocks((2346,3447,294),(0,0,0));
	CreateBlocks((2346,3447,250),(0,0,0));
	CreateBlocks((2346,3447,350),(0,0,0));
	CreateBlocks((1884,3190,456),(0,90,0));
	CreateBlocks((1884,3190,500),(0,90,0));
	CreateBlocks((1884,3190,550),(0,90,0));
	CreateBlocks((1884,3254,450),(0,90,0));
	CreateBlocks((1884,3254,500),(0,90,0));
	CreateBlocks((1884,3254,550),(0,90,0));
	CreateBlocks((2602,2809,158),(0,0,0));
	CreateBlocks((2602,2809,200),(0,0,0));
	CreateBlocks((2602,2809,250),(0,0,0));
	CreateBlocks((1820,2127,320),(0,90,0));
	CreateBlocks((1820,2127,370),(0,90,0));
	CreateBlocks((1820,2198,320),(0,90,0));
	CreateBlocks((1820,2198,370),(0,90,0));
	CreateBlocks((1683,3186,344),(0,90,0));
	CreateBlocks((1684,3269,344),(0,90,0));
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((1790,3371,294),(0,0,0));
		Ammo((1888,2672,158),(0,90,0));
		Power3((1959,2233,294),(0,90,0));
		DoublePoints((1738,3371,158),(0,0,0));
		Gambler((1810,3084,158),(0,0,0));
	}
}

Derail2()
{
	thread CreateVisableWalls((784,-5567,120),(919,-5570,170));
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((863,-6096,131),(0,0,0));
		Ammo((759,-5842,131),(0,90,0));
		Power3((944,-5846,131),(0,90,0));
		Gambler((944,-5998,131),(0,90,0));
	}
}

Estate()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-3191,-1275,-527),(0,156,0));
		Upgrade((-3591,-749,-527),(0,24,0));
		Ammo((-3473,-814,-575),(0,116,0));
		DoublePoints((-2042,-525,-341),(0,113,0));
		Gambler((-2321,-45,-286),(0,0,0));
		KillstreakBox((-2067,-901,-333),(0,237,0));
	}
	CreateHurtArea((-2276,-1298,-434),55,150);
	CreateHurtArea((-2168,-1125,-369),55,150);
}

Favela()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((1873,2458,296),(0,207,0));
		Ammo((1717,2640,296),(0,25,0));
		Power3((2189,2635,296),(0,207,0));
		DoublePoints((2034,2829,296),(0,25,0));
		Gambler((2292,2692,296),(0,207,0));
	}
	CreateWalls((2740,2858,250),(3047,3047,469));
	CreateWalls((1340,2442,408),(1719,2657,448));
	CreateWalls((987,2440,408),(1366,2446,470));
}

Favela2()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-2395,2354,-765),(0,283,0));
		Ammo((-2375,2850,-779),(0,252,0));
		Power3((-4701,2173,-922),(0,92,0));
		Gambler((-3188,2046,-813),(0,70,0));
	}
	CreateHurtArea((-3538,5014,-935),1000,500);
	CreateHurtArea((-2121,4154,-796),800,500);
}

Favela3()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-3782,-9312,-791),(0,160,0));
		Ammo((-3206,-9600,-816),(0,162,0));
		Power3((-3010,-9853,-817),(0,167,0));
		Gambler((-3414,-10075,-688),(0,160,0));
	}
}

HighRise()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-1608,9688,2179),(0,90,0));
		Ammo((-551,11091,2179),(0,90,0));
		Power3((-2824,11461,2179),(0,90,0));
		DoublePoints((-2297,9593,2275),(0,0,0));
		Gambler((-2754,9895,2275),(0,90,0));
	}
	CreateRamps((-2368,10168,2256),(-2368,11271,2256));
	CreateRamps((-2368,11271,2256),(-2655,11271,2256));
	CreateRamps((-2655,11271,2256),(-2655,10168,2256));
	CreateRamps((-2655,10168,2256),(-2368,10168,2256));
	CreateRamps((-2525,10916,2192),(-2521,11271,2256));
	CreateRamps((-2503,10469,2192),(-2507,10168,2256));
}

HighRise2()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((2308,10069,4075),(0,0,0));
		Ammo((5046,2666,2355),(0,180,0));
		Ammo((1384,10768,3371),(0,180,0));
		Ammo((1896,10863,4075),(0,90,0));
		Power3((1451,10172,4075),(0,0,0));
		DoublePoints((2242,11440,4075),(0,90,0));
		Gambler((1383,10895,3371),(0,180,0));
	}
	CreateProgressArea((2208,10676,3371),1500,150,1,0);
	CreateProgressArea((2230,10895,4075),1500,150,1,1);
	CreateProgressArea((5074,2460,2355),2500,150,1,2);
}

Invasion()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((2335,12023,11),(0,90,0));
		Power3((2403,12760,11),(0,0,0));
		DoublePoints((2471,11593,11),(0,90,0));
		Ammo((2335,11223,11),(0,90,0));
		Gambler((2472,10874,11),(0,90,0));
	}
}

Karachi()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((2740,2738,8),(0,90,0));
		Power3((2597,2610,3),(0,0,0));
		DoublePoints((2361,2807,11),(0,90,0));
		Ammo((2582,2892,8),(0,0,0));
		Gambler((2701,2889,3),(0,0,0));
	}
}

Quarry()
{
	CreateWalls((-335,1062,907),(-335,735,1000));
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-335,1178,907),(0,270,0));
		Ammo((-517,1079,907),(0,180,0));
		DoublePoints((-592,1079,907),(0,180,0));
		Gambler((-597,1268,907),(0,0,0));
		Upgrade((-1324,1166,923),(0,90,0));
	}
}

Rundown()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((1407,2651,77),(0,0,0));
		Power3((497,3358,59),(0,0,0));
		DoublePoints((1496,3056,77),(0,90,0));
		Ammo((830,2953,75),(0,90,0));
		Gambler((1215,2988,77),(0,0,0));
	}
	CreateWalls((1536,2303,50),(1472,2300,200));
	CreateWalls((695,2131,100),(495,2174,200));
	CreateWalls((304,2327,140),(163,2936,250));
}

Rust()
{
	thread CreateWalls((-579.5,-9976.5,-290.5),(-1192,-9332.6,0));
	thread CreateWalls((3281.4,-10772.8,-271.1),(3136.1,-9614.3,-73.2));
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((2749,-9489,-271),(0,-25,0));
		Power3((1477,-10211,-162),(0,162,0));
		Ammo((1777,-10392,-201),(0,155,0));
		Gambler((2630,-9443,-276),(0,340,0));
	}
}

Rust2()
{
	thread CreateGrids((1302,-6124,-286),(936,-6674,-281),(0,0,0));
	thread CreateGrids((1338,-5722,-286),(929,-5392,-281),(0,0,0));
	thread CreateRamps((1184,-6110,-286),(1174,-5741,-286));
	thread CreateRamps((1370,-5368,-270),(1597,-5147,-255));
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((1138,-5393,-255),(0,0,0));
		Ammo((1092,-6437,-255),(0,0,0));
		Gambler((924,-6453,-255),(0,90,0));
		Power3((1783,-4733,-163),(0,90,0));
	}
}

Rust3()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-955,-1523,-247),(0,253,0));
		Ammo((-1733,-960,-213),(0,211,0));
		Gambler((-1353,-1378,-170),(0,337,0));
		Power3((-1843,-2350,-190),(0,170,0));
	}
}

Scrapyard()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((167,-1775,-124),(0,105,0));
		Ammo((-56,-1799,-120),(0,100,0));
		Power3((88,-2355,-119),(0,120,0));
		DoublePoints((314,-2309,-124),(0,131,0));
		Gambler((960,-1661,-51),(0,90,0));
	}
}

Skidrow()
{
	CreateWalls((-760.1, -918.8, 12.1), (-760.1, -918.8, 100.9));
	CreateWalls((-856.2, 343.4, 152.1), (-856.8, 235.9, 235.9));
	CreateWalls((-152.7, 719.5, 101.2), (55.9, 722.2, 236.8));
	CreateWalls((-266.6, -720.1, 16.1), (-266.6, -767.9, 100.0));
	CreateWalls((-2.1, -1840.1, 16.1), (-5.5, -1935.7, 111.8));
	CreateWalls((-647.9, -1676.0, 152.1), (-536.1, -1676.3, 253.9));
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-2000.1,-366.9,144.1),(0,90,0));
		Power3((-923.7,217.4,152.1),(0,0,0));
		DoublePoints((-2082.8,-1556.8,-39.9),(0,0,0));
		Ammo((-2281.3,267.9,32.1),(0,0,0));
		Gambler((-2496.9,-433.0,139.1),(0,90,0));
	}
}

Skidrow2()
{
	CreateWalls((-760,-918,12),(-760, -918, 100));
	CreateWalls((-856,343,152),(-856, 235, 235));
	CreateWalls((-152,719,101),(55, 722, 236));
	CreateWalls((-266,-720,16),(-266, -767, 100.0));
	CreateWalls((-685,-1840,16),(-684,-1935,111));
	CreateWalls((-647,-1676,152),(-536, -1676, 253));
	CreateWalls((-197,-275,200),(-200,-448,263));
	CreateBlocks((-126,-458,214),(0, 0, 0));
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((1965,-500,16),(0,90,0));
		Power3((-185,96,16),(0,90,0));
		DoublePoints((-2082,-1556,-39),(0,0,0));
		Ammo((1772,-284,16),(0,0,0));
		Gambler((1818,-185,227),(0,0,0));
	}
}

Skidrow3()
{
	CreateWalls((2057,-3601,0),(1576,-3623,200));
	CreateBlocks((2032,-833,16),(0,180,0));
	CreateBlocks((2032,-833,50),(0,180,0));
	CreateBlocks((2032,-833,100),(0,180,0));
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((2040,-1266,16),(0,90,0));
		Power3((1584,-1842,16),(0,90,0));
		DoublePoints((1825,-1967,8),(0,0,0));
		Ammo((1608,-1247,8),(0,90,0));
		Gambler((1792,-1580,8),(0,90,0));
	}
}

SubBase()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-208,-4142,27),(0,90,0));
		Ammo((-495,-4193,17),(0,90,0));
		LastStandPro((-215,-4328,22),(0,90,0));
		Gambler((-488,-4360,25),(0,90,0));
		KillstreakBox((-488,-4677,20),(0,105,0));
		Upgrade((-339,-6440,11),(0,0,0));
	}
}

Terminal()
{
	CreateWalls((2295, 4425, 210), (2695, 4435, 400.2));
	CreateBlocks((2209,4257,315),(0,180,0));
	CreateBlocks((1453,4440,315),(0,0,0));
	CreateBlocks((1505,4439,315),(0,0,0));
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((1840,4339,179),(0,90,0));
		Power3((1658,2948,195),(0,190,0));
		DoublePoints((2038,3294,136),(0,316,0));
		Ammo((715,2893,56),(0,0,0));
		Gambler((610,4202,218),(0,180,0));
	}
	CreateWalls((1802,4782, 216),(605, 4781, 267));
	CreateWalls((407,4646, 207),(304, 4648, 293));
	CreateWalls((1858,4435, 324),(1858, 4046, 419));
	CreateWalls((1858,3935, 326),(1858, 3554, 418));
	CreateWalls((1913,3429, 200),(2151, 3191, 295));
}

Underpass()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((3975,2304,400),(0,90,0));
		Power3((3655,1726,400),(0,0,0));
		DoublePoints((3514,2015,400),(0,132,0));
		Ammo((3545,1552,400),(0,90,0));
		Gambler((3691,2508,400),(0,90,0));
	}
	CreateWalls((4113,3144,432),(4129,3448,500));
	CreateWalls((4129,3448,432),(4008,3468,500));
	CreateWalls((3669,2446,400),(3426,2553,500));
	CreateWalls((3414,2536,400),(3659,2529,500));
	CreateWalls((3426,2553,400),(3414,2536,500));
	CreateWalls((3669,2446,400),(3659,2529,500));
}

Bailout()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((2500,-907,407),(0,90,0));
		Power3((469,-852,407),(0,0,0));
		DoublePoints((1236,-1348,407),(0,0,0));
		Ammo((1695,-543,395),(0,90,0));
		Gambler((2147,-1132,407),(0,0,0));
	}
}

Carnival()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-2779,2928,3),(0,54,0));
		Power3((-2339,2609,3),(0,50,0));
		DoublePoints((-2319,1661,3),(0,140,0));
		Ammo((-2307,3170,3),(0,234,0));
		Gambler((-1759,2968,3),(0,138,0));
	}
}

Wasteland()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((10113,7044,358),(0,90,0));
		Power3((10113,7198,358),(0,90,0));
		DoublePoints((10113,7327,358),(0,90,0));
		Ammo((9480,6527,358),(0,90,0));
		Ammo((10901,7439,1481),(0,0,0));
		Gambler((10113,8312,358),(0,90,0));
	}
	CreateWalls((10694,6956,1545),(10693,7477,1600));
}
	
Overgrown()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-1700,-5439,-148),(0,353,0));
		DoublePoints((-895,-5439,-157),(0,0,0));
		Ammo((-1836,-5554,-148),(0,90,0));
		Gambler((-1287,-5965,-153),(0,223,0));
		KillstreakBox((-756,-5439,-159),(0,0,0));
		Health((-1959,-6334,-156),(0,0,0));
		Upgrade((-2788,-6076,-148),(0,90,0));
	}
	CreateHurtArea((-1155,-5490,-150),45,150);
	CreateHurtArea((-1480,-5470,-156),45,150);
}

Trailerpark()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((271.1,-2360.1,11.1),(0,90,0));
		Ammo((2732,-2642,13),(0,90,0));
		Power3((-105,-1470,4),(0,0,0));
		DoublePoints((773.1,-2683.9,20.1),(0,0,0));
		Gambler((858,-2676,15),(0,0,0));
	}
	CreateWalls((246,-2267,96),(252,-2599,171));
	CreateWalls((-754,-2247,17),(-1424,-2261,120));
}

Vacant()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((445,1526,-96),(0,0,0));
		Ammo((-241,692,-31),(0,0,0));
		Power3((-1659,208,-91),(0,90,0));
		DoublePoints((-539,86,-36),(0,90,0));
		Gambler((-828,-261,-37),(0,90,0));
	}
	CreateWalls((-846,-503,-8),(-849,-384,50));
	CreateWalls((-520,16,-31),(-518,-96,50));
	CreateWalls((-848,640,-8),(-846,520,50));
	CreateWalls((-4,677,-32),(-52,675,50));
	CreateWalls((72,959,-32),(73,848,46));
	CreateWalls((343,-880,-32),(346,-928,50));
}

Storm()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((3465,-975,-52),(0,0,0));
		Ammo((4207,-1009,-52),(0,90,0));
		Power3((4646,-975,-52),(0,0,0));
		DoublePoints((5040,-1235,-52),(0,90,0));
		Gambler((4826,-1328,-52),(0,0,0));
	}
	CreateWalls((4700,-62,8),(4737,-59,100));
	CreateWalls((2163,-843,8),(2120,-842,100));
	CreateWalls((5088,-1360,8),(5004,-1347,100));
}

Salvage()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((2250.3,3311.6,63.7),(0,0,0));
		Ammo((1644.0,3350.7,87.4),(0,0,0));
		Power3((1608.1,2025.3,152.1),(0,90,0));
		DoublePoints((2103.8,2230.2,16.1),(0,90,0));
		Gambler((1801.2,2000.1,16.1),(0,0,0));
	}
	CreateBlocks((3505.8,2665.8,11.1),(0,0,0));
	CreateBlocks((3505.8,2665.8,51.1),(0,0,0));
	CreateBlocks((3505.8,2665.8,91.1),(0,0,0));
	CreateBlocks((2044.4,1984.2,42.1),(0,0,0));
	CreateBlocks((1998.0,1986.2,42.1),(0,0,0));
	CreateBlocks((1846.3,1989.2,178.1),(0,0,0));
	CreateBlocks((1787.8,1982.3,178.1),(0,0,0));
	CreateBlocks((1595.5,2060.3,45.1),(0,90,0));
	CreateWalls((1936.1,2335.9,300.9),(2487.9,2339.0,0.8));
	CreateWalls((984.1,2623.8,96.1),(1095.9,2614.9,202.4));
}

Strike()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-2199,1240,31),(0,0,0));
		Ammo((-2185,1615,24),(0,0,0));
		Power3((-3116,1240,20),(0,0,0));
		DoublePoints((-3959,1380,16),(0,90,0));
		Gambler((-2577,1615,24),(0,0,0));
	}
	CreateWalls((-3538,1216,32),(-3959,1211,128));
	CreateWalls((-3530,1627,16),(-3959,1621,128));
}

Fuel()
{
	thread CreateWalls((-5649,2185,-250),(-5762,1365,-50));
	thread CreateWalls((-6307,2417,-250),(-6439,1725,-50));
	CreateHurtArea((-5930,2640,-236),750,300);
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-5996,1435,-125),(0,158,0));
		DoublePoints((-6371,1642,-125),(0,133,0));
		Ammo((-6251,1552,-125),(0,147,0));
		Gambler((-5811,1384,-125),(0,158,0));
		Upgrade((-6118,1479,-125),(0,154,0));
	}
}

Crash()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-746,-2175,155),(0,0,0));
		DoublePoints((-1169,-2146,118),(0,57,0));
		Ammo((-1045,-2365,106),(0,0,0));
		Gambler((-873,-3073,81),(0,273,0));
		KillstreakBox((-1280,-3015,81),(0,90,0));
		Health((-1191,-3578,68),(0,97,0));
		Upgrade((-993,-3925,59),(0,180,0));
	}
	CreateWalls((-716,-2169,160),(-753,-3861,254));
	CreateWalls((-684,-2152,235),(-430,-2152,310));
}

Safehouse()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-166,63,179),(0,168,0));
		Ammo((125,48,179),(0,74,0));
		Power3((281,271,27),(0,167,0));
		DoublePoints((138,41,27),(0,74,0));
		Gambler((83,884,179),(0,345,0));
		Ammo((65,232,27),(0,77,0));
	}
	CreateWalls((832,166,184),(839,203,254));
	CreateWalls((458,591,184),(408,602,247));
	CreateWalls((356,-174,38),(282,-164,113));
	CreateWalls((779,380,32),(741,385,102));
	CreateWalls((-278,490,223),(-345,411,309));
	CreateWalls((-370,306,223),(-348,211,325));
}

Arcadia()
{
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((4256,-7531,2380),(0,330,0));
		Ammo((4160,-7697,2380),(0,330,0));
		DoublePoints((3763,-7468,2380),(0,330,0));
		Gambler((4474,-7657,2380),(0,330,0));
		Upgrade((3861,-7303,2380),(0,330,0));
		LastStandPro((4438,-7857,2380),(0,330,0));
		Health((3942,-7571,2380),(0,330,0));
	}
	CreateHurtArea((2987,-6930,2383),650,200);
	CreateHurtArea((5317,-8274,2382),750,200);
}

Oilrig()
{
	thread CreateRamps((1184,-6110,-286),(1174,-5741,-286));
	if(getDvarInt("z_doa") < 1)
	{
		RandomWeapon((-56,1022,-1388),(0,90,0));
		DoublePoints((-56,1158,-1388),(0,90,0));
		Ammo((-45,413,-1388),(0,90,0));
		Gambler((259,1086,-1388),(0,90,0));
		Power3((109,280,-163),(0,180,0));
	}
}

PowerSpawner()
{
	level endon("disconnect");
	wait 1;
	Announcement("^2Power Activated!");
	wait 3.0;
	if(getDvar("mapname") == "mp_rust" && level.edit == 0)
	{
		CreateRamps((2314,-9299,-287),(2654,-8577,-287));
		Upgrade((2649,-8583,-261),(0,329,0));
		wait 3.0;
		SpeedReload((1637.8,-9032.8,-274.2),(0,341.8,0));
		SteadyAim((2176.6,-9246.8,-274.8),(0,335.1,0));
		StoppingPower((3161.6,-10811.7,-176.2),(0,206.2,0));
		Speedy((756.5,-10078.5,-89.8),(0,180,0));
		Health((-161.8,-10090.0,-155.0),(0,177.6,0));
		AmmOMatic((1885,-10492,-216),(0,138,0));
		LastStandPro((1673,-10304,-187),(0,140,0));
		KillstreakBox((1402,-9884,-177),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_rust" && level.edit == 1)
	{
		Upgrade((1580,-4481,-147),(0,0,0));
		wait 3.0;
		SpeedReload((914,-5550,-255),(0,90,0));
		Health((1353,-5549,-255),(0,90,0));
		LastStandPro((1317,-6359,-255),(0,90,0));
		KillstreakBox((1769,-4752,-167),(0,268,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_rust" && level.edit == 2)
	{
		Upgrade((-1166,-1375,-219),(0,250,0));
		wait 3.0;
		SpeedReload((-1135,-833,-206),(0,-206,0));
		Health((-1928,-1420,-243),(0,-243,0));
		LastStandPro((-2505,-1666,-116),(0,90,0));
		KillstreakBox((13,-1947,-231),(0,317,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_afghan" && level.edit == 0)
	{
		Upgrade((-2841,-394,-1332),(0,120,0));
		wait 3.0;
		SpeedReload((-2502,-13,-1444),(0,7,0));
		Speedy((-3499,920,-1448),(0,282,0));
		Health((-3822,1390,-1448),(0,185,0));
		LastStandPro((-3541,-511,-1448),(0,343,0));
		KillstreakBox((-2692,-1314,-1301),(0,168,0));
		wait 3.0;
	}
	else if(getDvar("mapname") == "mp_afghan" && level.edit == 1)
	{
		Upgrade((8632,3668,123),(0,263,0));
		wait 3.0;
		Health((8977,3748,131),(0,317,0));
		KillstreakBox((8632,3797,124),(0,270,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_highrise" && level.edit == 0)
	{
		Upgrade((-1471,10415,2179),(0,0,0));
		wait 3.0;
		SpeedReload((-1096,10414,2179),(0,90,0));
		SteadyAim((-1096,10962,2179),(0,90,0));
		StoppingPower((-1458,11087,2179),(0,0,0));
		Speedy((-1642,11089,2179),(0,0,0));
		Health((-850,11023,2179),(0,0,0));
		AmmOMatic((-1224,10757,2179),(0,90,0));
		LastStandPro((-2184,10012,2275),(0,90,0));
		KillstreakBox((-1210,10063,2179),(0,0,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_highrise" && level.edit == 1)
	{
		Upgrade((1707,10096,3371),(0,0,0));
		wait 3.0;
		SpeedReload((2943,11008,3371),(0,90,0));
		Speedy((4981,3698,2355),(0,0,0));
		Health((1394,11458,4075),(0,0,0));
		LastStandPro((1936,10035,3371),(0,0,0));
		KillstreakBox((3513,3144,2355),(0,0,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_invasion")
	{
		Upgrade((2403,12760,11),(0,0,0));
		wait 3.0;
		SpeedReload((2335,12127,11),(0,90,0));
		SteadyAim((2335,11544,11),(0,90,0));
		StoppingPower((2476,11173,11),(0,90,0));
		Speedy((2335,10865,11),(0,90,0));
		Health((2472,10567,11),(0,90,0));
		AmmOMatic((2335,10182,11),(0,90,0));
		LastStandPro((2474,10170,11),(0,90,0));
		KillstreakBox((2335,11788,11),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_favela" && level.edit == 0)
	{
		Upgrade((2043,2561,291),(0,207,0));
		wait 3.0;
		SpeedReload((1468,2492,291),(0,25,0));
		Speedy((1756,2400,291),(0,207,0));
		Health((2695,3160,291),(0,352,0));
		LastStandPro((1049,2424,292),(0,90,0));
		KillstreakBox((1266,2254,327),(0,105,0));
	}
	if(getDvar("mapname") == "mp_favela" && level.edit == 1)
	{
		Upgrade((-2362,2007,-759),(0,270,0));
		wait 3.0;
		SpeedReload((-3568,2091,-840),(0,86,0));
		Speedy((-3320,3703,-872),(0,236,0));
		Health((-3513,3293,-874),(0,102,0));
		LastStandPro((-3088,1453,-779),(0,236,0));
		KillstreakBox((-2434,1632,-753),(0,240,0));
	}
	if(getDvar("mapname") == "mp_favela" && level.edit == 2)
	{
		Upgrade((-3248,-9972,-763),(0,165,0));
		wait 3.0;
		SpeedReload((-3497,-9583,-779),(0,260,0));
		Speedy((-3782,-9148,-808),(0,174,0));
		Health((-3238,-9723,-802),(0,167,0));
		LastStandPro((-3436,-9789,-751),(0,170,0));
		KillstreakBox((-3054,-10211,-765),(0,168,0));
	}
	if(getDvar("mapname") == "mp_checkpoint")
	{
		Upgrade((2588,2714,3),(0,90,0));
		wait 3.0;
		Health((2490,2216,12),(0,90,0));
		LastStandPro((2364,2267,11),(0,90,0));
		KillstreakBox((2377,3162,11),(0,90,0));
	}
	if(getDvar("mapname") == "mp_quarry")
	{
		Upgrade((-1839.9,768.7,169.5),(0,90,0),(-1792,768,169));
		wait 3.0;
		CreateRamps((-1634.4,1019.0,20.1),(-1623.5,823.6,176.1));
		SpeedReload((-1660.2,727.1,35.1),(0,0,0));
		SteadyAim((-2395.3,1288.9,31.1),(0,0,0));
		StoppingPower((-1815.1,2789.7,84.9),(0,90,0));
		Speedy((-2020.9,1687.1,35.1),(0,0,0));
		Health((-1424.1,778.7,171.5),(0,90,0));
		AmmOMatic((-2658,2767,84),(0,0,0));
		LastStandPro((-1565,727,169),(0,0,0));
		KillstreakBox((-1678,2152,171),(0,0,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_subbase")
	{
		RandomWeapon((-412,-6440,0),(0,0,0));
	}
	if(getDvar("mapname") == "mp_nightshift" && level.edit == 0)
	{
		Upgrade((-2016.4,-50.8,8.1),(0,90,0),(-1972,-48,3));
		wait 3.0;
		SpeedReload((-1576.1,-2213.3,27.1),(0,90,0));
		SteadyAim((-1328.1,-1864.5,8.1),(0,90,0));
		StoppingPower((-318.6,-2023.9,16.1),(0,0,0));
		Speedy((-496.1,-1728.4,152.1),(0,90,0));
		Health((-752.6,-883.2,12.2),(0,0,0));
		AmmOMatic((-1757,304,3),(0,0,0));
		LastStandPro((-1968,-292,3),(0,90,0));
		KillstreakBox((-1087,155,8),(0,0,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_nightshift" && level.edit == 1)
	{
		Upgrade((1947,309,119),(0,360,0),(1947,257,119));
		wait 3.0;
		SpeedReload((31,-991,11),(0,0,0));
		SteadyAim((827,-1799,43),(0,0,0));
		StoppingPower((504,-912,11),(0,90,0));
		Speedy((615,-112,19),(0,180,0));
		Health((1867,186,224),(0,245,0));
		AmmOMatic((-309,-2016,11),(0,0,0));
		LastStandPro((1104,-2112,43),(0,90,0));
		KillstreakBox((543,-696,11),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_nightshift" && level.edit == 2)
	{
		Upgrade((1834,-2794,8),(0,0,0),(1830,-2744,3));
		wait 3.0;
		SpeedReload((2023,-1613,16),(0,90,0));
		SteadyAim((2022,-1792,16),(0,90,0));
		StoppingPower((2023,-1990,16),(0,90,0));
		Speedy((1576,-2521,16),(0,90,0));
		Health((1576,-2863,16),(0,90,0));
		AmmOMatic((1828,-2283,134),(0,0,0));
		LastStandPro((1787,-1748,3),(0,90,0));
		KillstreakBox((1591,-2068,11),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_strike")
	{
		Upgrade((-2385,1608,19),(0,0,0));
		wait 3.0;
		SpeedReload((-2378,1248,22),(0,0,0));
		SteadyAim((-2627,1247,17),(0,0,0));
		StoppingPower((-2777,1247,16),(0,0,0));
		Speedy((-2950,1247,15),(0,0,0));
		Health((-3302,1247,12),(0,0,0));
		AmmOMatic((-2742,1608,19),(0,0,0));
		LastStandPro((-3065,1608,19),(0,0,0));
		KillstreakBox((-2905,1608,19),(0,0,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_vacant")
	{
		Upgrade((-1625,972,-83),(0,0,0));
		wait 3.0;
		SpeedReload((-1404,152,-98),(0,0,0));
		SteadyAim((-1760,-62,-100),(0,0,0));
		StoppingPower((-659,78,-100),(0,90,0));
		Speedy((-867,409,-98),(0,90,0));
		Health((196,1600,-101),(0,90,0));
		AmmOMatic((764,1663,-100),(0,90,0));
		LastStandPro((53,1093,-36),(0,90,0));
		KillstreakBox((-1783,512,-91),(0,180,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_underpass")
	{
		Upgrade((3732,2105,395),(0,48,0));
		wait 3.0;
		SpeedReload((3778,1731,395),(0,0,0));
		SteadyAim((4094,1039,427),(0,0,0));
		StoppingPower((3542,1426,395),(0,90,0));
		Speedy((3660,1968,395),(0,46,0));
		Health((3015,3354,395),(0,90,0));
		AmmOMatic((3495,2273,395),(0,238,0));
		LastStandPro((4164,1904,427),(0,0,0));
		KillstreakBox((3651,2240,395),(0,325,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_rundown")
	{
		Upgrade((1236,2644,82),(0,0,0),(1235,2704,77));
		wait 3.0;
		SpeedReload((1426,3187,82),(0,0,0));
		SteadyAim((1343,3187,82),(0,0,0));
		StoppingPower((1366,3028,82),(0,0,0));
		Speedy((1279,3028,82),(0,0,0));
		Health((1708,3040,73),(0,90,0));
		AmmOMatic((391,2320,134),(0,0,0));
		LastStandPro((963,2919,80),(0,90,0));
		KillstreakBox((1535,2699,75),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_fuel2")
	{
		Upgrade((18041,27175,6994),(0,0,0));
		wait 3.0;
		SpeedReload((17962,27608,6994),(0,0,0));
		Health((18051,27345,6994),(0,0,0));
		LastStandPro((18571,27608,6994),(0,0,0));
		KillstreakBox((17790,27364,6994),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_storm")
	{
		Upgrade((3843,-1903,8),(0,0,0));
		wait 3.0;
		SpeedReload((3913,-1519,16),(0,0,0));
		SteadyAim((3144,-968,-48),(0,0,0));
		StoppingPower((3668,-1335,-48),(0,0,0));
		Speedy((2120,-902,8),(0,90,0));
		Health((3412,-844,8),(0,90,0));
		AmmOMatic((5056,-1806,8),(0,90,0));
		LastStandPro((5097,-1360,8),(0,0,0));
		KillstreakBox((3424,-2051,3),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_derail" && level.edit == 0)
	{
		Upgrade((2495,3319,294),(0,90,0));
		wait 3.0;
		SpeedReload((1896,2060,158),(0,0,0));
		Speedy((1824,2450,158),(0,90,0));
		Health((2154,2606,282),(0,0,0));
		LastStandPro((2299,2788,153),(0,0,0));
		KillstreakBox((2488,2400,153),(0,105,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_derail" && level.edit == 1)
	{
		Upgrade((944,-5846,131),(0,90,0));
		wait 3.0;
		SpeedReload((944,-5684,131),(0,90,0));
		Health((759,-5697,131),(0,90,0));
		KillstreakBox((759,-6005,131),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_estate")
	{
		RandomWeapon((1362,3719,65),(0,0,0));
	}
	if(getDvar("mapname") == "mp_boneyard")
	{
		Upgrade((-537,-2008,-88),(0,90,0));
		wait 3.0;
		SpeedReload((-370,-756,-65),(0,0,0));
		SteadyAim((-553,-756,-76),(0,0,0));
		StoppingPower((-875,-1093,-84),(0,163,0));
		Speedy((-122,-875,-108),(0,90,0));
		Health((1301,-2258,-51),(0,0,0));
		AmmOMatic((-261,-3077,-68),(0,31,0));
		LastStandPro((-565,-2420,0),(0,70,0));
		KillstreakBox((248,-3140,-77),(0,293,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_terminal")
	{
		Upgrade((609,2763,213),(0,180,0),(607,2808,213));
		wait 3.0;
		SpeedReload((550,3062,213),(0,90,0));
		SteadyAim((673,3059,213),(0,90,0));
		StoppingPower((550,3527,213),(0,90,0));
		Speedy((1392,4730,55),(0,90,0));
		Health((1761,4215,448),(0,90,0));
		AmmOMatic((354,4595,201),(0,0,0));
		LastStandPro((674,4020,213),(0,90,0));
		KillstreakBox((983,4142,51),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_brecourt")
	{
		Upgrade((10727,7210,1486),(0,90,0));
		wait 3.0;
		SpeedReload((9983,6227,358),(0,0,0));
		SteadyAim((10116,6224,358),(0,0,0));
		StoppingPower((10241,6224,358),(0,0,0));
		Speedy((10374,-6224,358),(0,0,0));
		Health((10528,6222,358),(0,0,0));
		AmmOMatic((11909,7442,1486),(0,0,0));
		LastStandPro((11911,6989,1486),(0,0,0));
		KillstreakBox((10360,6935,353),(0,0,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_overgrown")
	{
		RandomWeapon((1284,2651,-157),(0,90,0));
	}
	if(getDvar("mapname") == "mp_compact")
	{
		Upgrade((2807.9,2835.5,70.1),(0,90,0),(2756,2840,70));
		wait 3.0;
		CreateRamps((1957.5,2666.8,0.1),(2027.9,2406.3,130));
		SpeedReload((2060.0,3351.9,77.5),(0,0,0));
		SteadyAim((2103.9,2078.5,16.1),(0,90,0));
		StoppingPower((1608.1,2261.2,16.1),(0,90,0));
		Speedy((2491.9,2472.4,29.0),(0,-90,0));
		Health((1937.4,2392.1,16.1),(0,0,0));
		AmmOMatic((1753,2360,11),(0,0,0));
		LastStandPro((1718,2399,11),(0,0,0));
		KillstreakBox((1607,3129,71),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_crash")
	{
		RandomWeapon((-1239,-2646,86),(0,90,0));
	}
	if(getDvar("mapname") == "mp_abandon")
	{
		Upgrade((-1553,2798,3),(0,141,0));
		wait 3.0;
		SpeedReload((-2119,3865,3),(0,20,0));
		SteadyAim((-2898,3629,3),(0,38,0));
		StoppingPower((-3878,2865,3),(0,140,0));
		Speedy((-3281,2486,3),(0,318,0));
		Health((-2248,1351,3),(0,323,0));
		AmmOMatic((-2552,1984,3),(0,140,0));
		LastStandPro((-1901,1150,3),(0,189,0));
		KillstreakBox((-2691,900,-2),(0,50,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_complex")
	{
		Upgrade((844,-47,430),(0,0,0));
		wait 3.0;
		SpeedReload((559,-23,395),(0,90,0));
		SteadyAim((224,-48,395),(0,90,0));
		StoppingPower((-108,-852,407),(0,90,0));
		Speedy((-243,-1062,407),(0,0,0));
		Health((-780,-1294,395),(0,90,0));
		AmmOMatic((-1581,-655,395),(0,0,0));
		LastStandPro((-597,-69,395),(0,326,0));
		KillstreakBox((1120,-541,395),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "mp_trailerpark")
	{
		Upgrade((1958.9,-1706.1,15.4),(0,0,0),(1963,-1752,15));
		wait 3.0;
		CreateRamps((1739.2, -2213.0, 0), (1741.3, -2479, 190.1));
		SpeedReload((1613.4,-2907.3,190.1),(0,73.6,0));
		Speedy((2165.5,-2986.4,190.1),(0,-90,0));
		Health((1672.3,-2478.2,190.1),(0,90,0));
		LastStandPro((649,-2676,15),(0,180,0));
		KillstreakBox((2403,-2568,18),(0,90,0));
		wait 3.0;
	}
	if(getDvar("mapname") == "estate")
	{
		Upgrade((267,251,307),(0,345,0));
		wait 3.0;
		SpeedReload((222,776,179),(0,118,0));
		Speedy((587,112,179),(0,256,0));
		Health((851,36,307),(0,254,0));
		LastStandPro((803,257,27),(0,253,0));
		KillstreakBox((557,344,27),(0,345,0));
		wait 3.0;
	}
}