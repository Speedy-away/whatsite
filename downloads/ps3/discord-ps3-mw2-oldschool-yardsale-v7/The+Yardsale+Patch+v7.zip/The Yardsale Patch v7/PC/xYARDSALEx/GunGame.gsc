#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;

initGuns()
{
    self.inverse = false; //Inverted gungame?
    self.upgscore = 50; //Score necessary for upgrade. Leave at 100 for 2 kill upgrade. Do 50 for 1 kill, 150 for 3 kill.
    self.finalkills = 5; //Kills to win after getting final weapon
    self.gunList = [];
    // Gun Name, Laser Sight, Akimbo
    self.gunList[0] = createGun("throwingknife_mp", 9, false, false);
    self.gunList[1] = createGun("usp_fmj_mp", 9, false, false);
    self.gunList[2] = createGun("beretta_fmj_mp", 9, false, false);
    self.gunList[3] = createGun("coltanaconda_fmj_mp", 9, false, false);
    self.gunList[4] = createGun("deserteaglegold_mp", 9, false, false);
    self.gunList[5] = createGun("pp2000_mp", 9, true, false);
    self.gunList[6] = createGun("tmp_mp", 9, true, false);
    self.gunList[7] = createGun("beretta393_akimbo_mp", 9, true, true);
    self.gunList[8] = createGun("glock_mp", 9, true, false);
    self.gunList[9] = createGun("ranger_akimbo_mp", 9, true, true);
    self.gunList[10] = createGun("model1887_akimbo_mp", 9, true, true);
    self.gunList[11] = createGun("m1014_grip_reflex_mp", 9, true, false);
    self.gunList[12] = createGun("striker_grip_reflex_mp", 9, true, false);
    self.gunList[13] = createGun("aa12_eotech_grip_mp", 9, true, false);
    self.gunList[14] = createGun("spas12_grip_mp", 9, true, false);
    self.gunList[15] = createGun("uzi_reflex_rof_mp", 9, true, false);
    self.gunList[16] = createGun("mp5k_reflex_rof_mp", 9, true, false);
    self.gunList[17] = createGun("ump45_reflex_rof_mp", 9, true, false);
    self.gunList[18] = createGun("p90_eotech_rof_mp", 9, true, false);
    self.gunList[19] = createGun("fal_acog_mp", 9, true, false);
    self.gunList[20] = createGun("scar_reflex_mp", 9, true, false);
    self.gunList[21] = createGun("m16_reflex_mp", 9, true, false);
    self.gunList[22] = createGun("aug_grip_mp", 9, true, false);
    self.gunList[23] = createGun("masada_reflex_mp", 9, true, false);
    self.gunList[24] = createGun("rpd_grip_mp", 9, true, false);
    self.gunList[25] = createGun("mg4_grip_mp", 9, true, false);
    self.gunList[26] = createGun("m240_grip_mp", 9, true, false);
    self.gunList[27] = createGun("wa2000_fmj_mp", 9, false, false);
    self.gunList[28] = createGun("m21_fmj_mp", 9, false, false);
    self.gunList[29] = createGun("barrett_fmj_mp", 9, false, false);
    self.gunList[30] = createGun("cheytac_fmj_mp", 9, false, false);
    self.gunList[31] = createGun("m79_mp", 9, false, false);
    self.gunList[32] = createGun("at4_mp", 9, true, false);
    self.gunList[33] = createGun("rpg_mp", 9, false, false);
    self.gunList[34] = createGun("javelin_mp", 9, true, false);
}

createGun(gunName, camo, laserSight, akimbo)
{
    gun = spawnstruct();
    gun.name = gunName;
    gun.camo = camo;
    gun.laser = laserSight;
    gun.akimbo = akimbo;
    return gun;
}

doBinds() //Put persistent threads that are started once here
{
    self.firstRun = true;
    self thread initGuns();
    self.nv = false;
    self thread killCrosshairs();
    self thread doScore();
    self thread doGun();
    setDvar("scr_dm_scorelimit", ((self.gunList.size - 1) * self.upgscore) + (self.finalkills * 50));
    setDvar("scr_dm_timelimit", 0);
    setDvar("ui_gametype", "ffa");
    setDvar("scr_game_hardpoints", 0);
}

doDvars() //Put threads that are called with every respawn
{
    setDvar("g_speed", 220);
    setDvar("bg_fallDamageMaxHeight", 1);
    setDvar("bg_fallDamageMinHeight", 99999);
    self setClientDvar("player_meleerange", 0);
    self _clearPerks();
    self maps\mp\perks\_perks::givePerk("specialty_bulletaccuracy");
    self maps\mp\perks\_perks::givePerk("specialty_bulletdamage");
    self maps\mp\perks\_perks::givePerk("specialty_bulletpenetration");
    self maps\mp\perks\_perks::givePerk("specialty_exposeenemy");
    self maps\mp\perks\_perks::givePerk("specialty_extendedmags");
    self maps\mp\perks\_perks::givePerk("specialty_fastreload");
    self maps\mp\perks\_perks::givePerk("specialty_fastsnipe");
    self maps\mp\perks\_perks::givePerk("specialty_marathon");
    self maps\mp\perks\_perks::givePerk("specialty_quieter");
    if(self.nv) self VisionSetNakedForPlayer("default_night_mp", 1);
    else self VisionSetNakedForPlayer(getDvar("mapname"), 2);
    self thread doNV();
    if(self.firstRun){
        if(self.inverse){
            self thread maps\mp\gametypes\_hud_message::hintMessage("^2Inverse Gun Game");
            self thread maps\mp\gametypes\_hud_message::hintMessage("^2Kill Enemies to Downgrade Your Gun");
        }else{
            self thread maps\mp\gametypes\_hud_message::hintMessage("^2Gun Game");
            self thread maps\mp\gametypes\_hud_message::hintMessage("^2Kill Enemies to Upgrade Your Gun");
        }
        self thread maps\mp\gametypes\_hud_message::hintMessage("^2Press [{+actionslot 1}] to Toggle Night Vision");
        //DO NOT REMOVE THE FOLLOWING LINE
        self thread maps\mp\gametypes\_hud_message::hintMessage("^2CRATED BY GHOST [DS]:");
        self thread maps\mp\gametypes\_hud_message::hintMessage("^2Donate at skixtech.com/donate!");
        //DO NOT REMOVE THAT ^
        self.firstRun = false;
    }
}

doGun()
{
    self endon("disconnect");
    if(self.inverse) self.curgun = self.gunList.size - 1;
    else self.curgun = 0;
    curscore = 0;
    done = false;
    while(true){
        if(self.inverse && self.curgun <= 0) done = true;
        if(!self.inverse && self.curgun >= (self.gunList.size - 1)) done = true;
        if(!done){
            if(self.inverse && (self.score - curscore >= self.upgscore)){
                self.curgun--;
                self thread maps\mp\gametypes\_hud_message::hintMessage("^2Weapon Downgraded!");
                curscore = self.score;
            }else if((self.score - curscore >= self.upgscore)){
                self.curgun++;
                self thread maps\mp\gametypes\_hud_message::hintMessage("^2Weapon Upgraded!");
                curscore = self.score;
            }
        }
        while(self getCurrentWeapon() != self.gunList[self.curgun].name){
            if(self.gunList[self.curgun].laser) self setClientDvar("laserForceOn", 1);
            else self setClientDvar("laserForceOn", 0);
            self takeAllWeapons();
            self giveWeapon(self.gunList[self.curgun].name, self.gunList[self.curgun].camo, self.gunList[self.curgun].akimbo);
            self switchToWeapon(self.gunList[self.curgun].name);
            wait .2;
        }
        self giveMaxAmmo(self.gunList[self.curgun].name);
        wait .2;
    }
}

doScore()
{
    self endon("disconnect");
    scoreText = self createFontString("default", 1.5);
    scoreText setPoint("TOPRIGHT", "TOPRIGHT", -5, 0);
    while(true)
    {
        scoreText setText("^3 Level " + self.curgun);
        wait .2;
    }
}

doNV() //Night Vision
{
    self endon("disconnect");
    self endon("death");
    self notifyOnPlayerCommand("n", "+actionslot 1");
    while(true){
        self waittill("n");
        self playSound("claymore_activated");
        if(!self.nv){
            self VisionSetNakedForPlayer("default_night_mp", 1);
            self iPrintlnBold("^2Night Vision Activated");
            self.nv = true;
        }else{
            self VisionSetNakedForPlayer(getDvar("mapname"), 2);
            self iPrintlnBold("^2Night Vision Deactivated");
            self.nv = false;
        }
    }
}

killCrosshairs() //Get rid of those fucking useless hax
{
    self endon("disconnect");

    while(true){
        setDvar("cg_drawcrosshair", 0);
        self setClientDvar("cg_scoreboardPingText", 1);
        self setClientDvar("com_maxfps", 0);
        self setClientDvar("cg_drawFPS", 1);
        wait 1;
    }
}

init()
{
    level thread onPlayerConnect();
}


onPlayerConnect()
{
    for(;;)
    {
        level waittill( "connected", player );

        player.hud_scorePopup = newClientHudElem( player );
        player.hud_scorePopup.horzAlign = "center";
        player.hud_scorePopup.vertAlign = "middle";
        player.hud_scorePopup.alignX = "center";
        player.hud_scorePopup.alignY = "middle";
         player.hud_scorePopup.x = 0;
         if ( level.splitScreen )
            player.hud_scorePopup.y = -40;
        else
            player.hud_scorePopup.y = -60;
        player.hud_scorePopup.font = "hudbig";
        player.hud_scorePopup.fontscale = 0.75;
        player.hud_scorePopup.archived = false;
        player.hud_scorePopup.color = (0.5,0.5,0.5);
        player.hud_scorePopup.sort = 10000;
        player.hud_scorePopup maps\mp\gametypes\_hud::fontPulseInit( 3.0 );
        
               player thread doBinds();
        player thread onPlayerSpawned();
    }
}

onPlayerSpawned()
{
    self endon("disconnect");
    for(;;)
    {
        self waittill( "spawned_player" );
            self thread doDvars();
	self.MenuIsOpen = true;
    }
}