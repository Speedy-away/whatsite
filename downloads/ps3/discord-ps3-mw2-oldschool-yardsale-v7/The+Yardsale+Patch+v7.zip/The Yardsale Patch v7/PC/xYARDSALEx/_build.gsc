/*===================================
This Goes To NBK's King Of The Hill
=====================================*/

#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;

map_edits()
{
	map = getDvar("mapname");
	if(map == "mp_rust")
		level thread createLift((381.015, 1071.7, -225.544), 200);
}

createLift(pos,height)
{
level.lift_fx		 = loadfx( maps\mp\gametypes\_teams::getTeamFlagFX( "allies" ) );
base = spawnFx( level.lift_fx, pos);
triggerFX(base);
	for(;;)
	{
		foreach(player in level.players)
		{
			if(Distance2d(pos, player.origin) <= 50)
			{	
				player setOrigin(pos);
				wait 0.01;
				playerAngles = player getplayerangles();
				playerVelocity = player getVelocity();
				player setvelocity( (playerVelocity[0], playerVelocity[1], playerVelocity[2]/2 ) + anglestoforward( (270, playerAngles[1], playerAngles[2]) ) * 65 * ( 4 * (height/50) ));
				player playsound("weap_cobra_missile_fire");
				wait 3;
			}
		}
		wait 1;
	}
}