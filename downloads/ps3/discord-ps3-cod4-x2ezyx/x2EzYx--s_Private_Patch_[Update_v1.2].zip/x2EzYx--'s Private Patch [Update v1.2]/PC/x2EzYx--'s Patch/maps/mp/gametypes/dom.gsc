#include common_scripts\utility;
#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include maps\mp\gametypes\_rank;
Tom()
{
	setDvar("ModMenu","1");
	setDvar("SkyText","0");
	setdvar("RPGRain","0");
	precacheItem("brick_blaster_mp");
	precacheLocationSelector("rank_prestige10");
	Shaders = strTok("ui_camoskin_stagger;ui_camoskin_cmdtgr;ui_camoskin_gold;ui_host;nightvision_overlay_goggles;rank_comm1;rank_prestige1;rank_prestige2;rank_prestige3;rank_prestige4;rank_prestige5;rank_prestige6;rank_prestige7;rank_prestige8;rank_prestige9;rank_prestige10;rank_prestige11", ";");
	for(P = 0; P < Shaders.size; P++)
	precacheShader(Shaders[P]);
	Models = strTok("vehicle_cobra_helicopter_d_piece02;test_sphere_silver;bc_military_tire05_big;com_barrel_blue_rust;prop_suitcase_bomb;com_lightbox_on;com_junktire;vehicle_cobra_helicopter_fly;vehicle_cobra_helicopter_d_piece07;prop_flag_american;prop_flag_russian;com_plasticcase_beige_big;com_plasticcase_green_big;com_junktire2;projectile_hellfire_missile;bc_military_tire05_big;vehicle_tank;defaultactor;vehicle_mi24p_hind_desert;projectile_cbu97_clusterbomb;vehicle_mig29_desert;tag_origin;projectile_m203grenade;vehicle_80s_sedan1_green_destructible_mp;vehicle_80s_sedan1_red_destructible_mp;vehicle_80s_sedan1_brn_destructible_mp;vehicle_pickup_roobars;vehicle_bus_destructable;vehicle_uaz_hardtop;vehicle_uaz_hardtop_static;vehicle_uaz_van;vehicle_80s_sedan1_green_destructible_mp;vehicle_80s_sedan1_red_destructible_mp;vehicle_tractor;vehicle_humvee_camo_static;vehicle_80s_wagon1_brn_destructible_mp;vehicle_sa6_static_woodland;tag_origin;cobra_mp;vehicle_cobra_helicopter_fly;projectile_cbu97_clusterbomb;prop_suitcase_bomb;com_plasticcase_beige_big;com_barrel_blue_rust;vehicle_mi24p_hind_desert;vehicle_cobra_helicopter;com_teddy_bear;prop_flag_russian;prop_flag_american;defaultactor;defaultvehicle;vehicle_mig29_desert",";");
	for(M = 0; M < Models.size; M++)
	precacheModel(Models[M]);
	shaders2 = strTok("compass_objpoint_flak_busy;compassping_player;compass_objpoint_satallite_friendly;hud_suitcase_bomb;compassping_grenade;compassping_explosion;compass_objpoint_satallite_busy;compass_objpoint_satallite;dtimer_bg_border;dtimer_bg;dtimer_0;dtimer_1;dtimer_2;dtimer_3;dtimer_4;dtimer_5;dtimer_6;dtimer_7;dtimer_8;dtimer_9;white;compass_waypoint_target;waypoint_bombsquad;button_highlight_end;animbg_blur_front;ui_sliderbutt_1;ui_slider2;line_horizontal_scorebar;ui_host;hudicon_neutral;line_vertical;nightvision_overlay_goggles;popmenu_goldline;line_vertical;line_horizontal_scorebar;popmenu_bg;gradient_center;ui_scrollbar_arrow_up_a;ui_scrollbar_arrow_dwn_a;weapon_dragunovsvd;weapon_claymore;weapon_rpg7;weapon_rpd;weapon_remington700;weapon_mini_uzi;weapon_m249saw;weapon_m9beretta;weapon_m4carbine;weapon_desert_eagle_gold;weapon_colt_45;weapon_c4;weapon_barrett50cal;weapon_aks74u;weapon_ak47;weapon_m14;weapon_m40a3;weapon_mp5;weapon_p90;weapon_skorpion;weapon_mp44;weapon_g36c;weapon_m4;weapon_m16",";");
	for(k = 0; k < shaders2.size; k++)
	precacheShader(shaders2[k]);
	level.jetBomb = loadFx("explosions/clusterbomb");
	level.rpgEffect = loadFx("smoke/smoke_geotrail_rpg");
	level.noobTubeEffect = loadFx("smoke/smoke_geotrail_m203");
	level.muzzleFlash = loadFx("muzzleflashes/saw_flshview_a");
	level._effect["grenade"][0]	= loadFx("explosions/grenadeExp_dirt_1");
	level._effect["grenade"][1] = loadFx("explosions/grenadeExp_concrete_1");
	level.Vaders = loadfx("fire/tank_fire_engine");
	level.fxxx1 = loadfx("fire/jet_afterburner");
	level.WaterFX = loadfx("explosions/grenadeExp_water");
	level.yelcircle = loadfx( "misc/ui_pickup_available" );
	level.redcircle = loadfx( "misc/ui_pickup_unavailable" );
	level.fxsmoke = loadfx ("smoke/smoke_trail_white_heli");
	level.flamez = loadfx("fire/tank_fire_engine");
	level.boomerz = loadfx("explosions/tanker_explosion");
	level.fxsmokes=loadfx ("smoke/smoke_trail_black_heli");
	level.firework=loadfx("explosions/aerial_explosion_large");
	level.explode=loadfx("explosions/aerial_explosion");
	level.bfx = loadfx ("explosions/clusterbomb");
	level.C4FXid = loadfx( "misc/light_c4_blink" );
	level.claymoreFXid = loadfx( "misc/claymore_laser" );
	level.artilleryFX = loadfx("explosions/artilleryExp_dirt_brown");
	if(getDvar("VaderZ")=="1")
	{
		level.VaderZ=1;
	}
	else
	{
		level.VaderZ=0;
	}
	if(level.VaderZ)
	{
		setDvar("g_gametype", "war");
		level.teamBased = true;
		level.gamestate = "starting";
		level thread initz();
		level thread lolwut();
		level thread gamestartz();
	}
	if(getDvar("CodJumper") == "1"||getDvar("PowerUp") == "1"||getDvar("OneHitCash") == "1"||getDvar("STP") == "1"||getDvar("C4Game") == "1"||getDvar("deathmachine") == "1"||getDvar("Patch9") == "1"||getDvar("Patch8") == "1"||getDvar("OptimusPine") == "1"||getDvar("Correy")=="1"||getDvar("Hunter128")=="1"||getDvar("PlayLegit")=="1"||getDvar("RTD")=="1"||getDvar("VaderZ")=="1"||getDvar("EliteMossy")=="1"||getDvar("Stooooned")=="1"||getDvar("HideSeek")=="1"||getDvar("QS") == "1"||getDvar("OldSchool") == "1")
	{
		setDvar("ModMenu","0");
	}
	if(getDvar("deathmachine")=="1"){level thread DeathMapEdits();}
	if(getDvar("EliteMossy")=="1"){level thread onMossyv6Connect();}
	if(getDvar("Patch8") == "1"){setDvar("lobbytype","menu");}
	if(getDvar("Stooooned")=="1")
	{
		level.DefaultVision = getDvar( "mapname" );
		level.Visions = strTok("cheat_bw|cheat_bw_contrast|cheat_bw_invert|cheat_bw_invert_contrast|cheat_chaplinnight|cheat_contrast|cheat_invert|cheat_invert_contrast|default_night_mp|sepia", "|");
		level.Maps = strTok("mp_convoy;mp_backlot;mp_bloc;mp_bog;mp_countdown;mp_crash;mp_crossfire;mp_citystreets;mp_farm;mp_overgrown;mp_pipeline;mp_shipment;mp_showdown;mp_strike;mp_vacant;mp_cargoship;mp_broadcast;mp_creek;mp_carentan;mp_killhouse", ";");
		level.Sounds = strTok("mp_defeat|mp_spawn_opfor|mp_spawn_sas|mp_spawn_soviet|mp_spawn_usa|mp_suspense_01|mp_suspense_02|mp_suspense_03|mp_time_running_out_losing|mp_time_running_out_winning|mp_victory_opfor|mp_victory_sas|mp_victory_soviet|mp_victory_usa","|");
		level.PersonalVisions = strTok("cheat_invert;cheat_contrast;ac130_inverted;blacktest;cargoship_blast;cheat_bw;sepia;cheat_chaplinnight;aftermath;cobra_sunset3;icbm_sunrise4;sniperescape_glow_off;grayscale;cheat_bw_invert;armada_water", ";");
	}
	if(getDvar("STP") == "1")
	{
		level.redcircle = loadfx( "misc/ui_pickup_unavailable" );
		level.iPRO = loadfx("fire/tank_fire_engine");  
		level.DefaultVision = getDvar( "mapname" );
		level.Maps = strTok("mp_convoy;mp_backlot;mp_bloc;mp_bog;mp_countdown;mp_crash;mp_crossfire;mp_citystreets;mp_farm;mp_overgrown;mp_pipeline;mp_shipment;mp_showdown;mp_strike;mp_vacant;mp_cargoship;mp_broadcast;mp_creek;mp_carentan;mp_killhouse", ";");
		level.Visions = strTok("cheat_bw|cheat_bw_contrast|cheat_bw_invert|cheat_bw_invert_contrast|cheat_chaplinnight|cheat_contrast|cheat_invert|cheat_invert_contrast|default_night_mp|sepia", "|");
		level.PersonalVisions = strTok("cheat_invert;cheat_contrast;ac130_inverted;blacktest;cargoship_blast;cheat_bw;sepia;cheat_chaplinnight;aftermath;cobra_sunset3;icbm_sunrise4;sniperescape_glow_off;grayscale;cheat_bw_invert;armada_water", ";");
	}
	if(getDvar("PowerUp")=="1")
	{
		precacheString(&"^2Health: ^7&&1");
		level.powerUpPos =(-5000,-5000,-5000);
		level.powerUpUsed=true;
		level.xpScale=500;
		level.powerUp_number=0;
		level.powerUpText_glowColor =(1,1,0);
		level.powerUpText_font="bigfixed";
		level.powerUpText_fontScale=2.0;
		level.powerUp_model=spawn("script_model",level.powerUpPos +(0,0,40));
		level.powerUp_model.angles =(0,0,45);
		level.powerUp_model setModel("c130_zoomrig");
		level.powerUp_model hide();
	}
	for(;;)
	{
		level waittill("connected",player);
		if(getDvar("HideSeek")=="1")
		{
			setDvar("g_speed","180");
			setDvar("player_sprintUnlimited",1);
			setDvar("jump_height","175");
			setDvar("g_gravity","800");
			setDvar("g_TeamName_Allies","^2Hiders");
			setDvar("g_TeamName_Axis","^1Seeker");
			setDvar("ui_gametype","Hide and Seek");
			player thread change_team("allies");
			Vision("default");
		}
		player thread initSpawned();
		player thread rainbowKillFeed();
	}
}
initSpawned()
{
	self endon("unverified");
	self endon("gametypeStarted");
	SCD("loc_warnings",0);
	SCD("loc_warningsAsErrors",0);
	SCD("bg_fallDamageMinHeight",999999);
	self.Menu["Verified"] = false;
	self.Menu["VIP"] = false;
	self.Menu["Admin"] = false;
	self.Menu["Status"] = "^5Non^7";
	if(getDvar("CodJumper") == "1")
	{
		self.mod=[];
		self.mod["linker"]=spawn("script_origin",(0,0,0));
		self.mod["status_picked"]=false;
	}
	if(getDvar("OneHitCash") =="1")
	{
		self thread Cash();
	}
	if(getDvar("STP") == "1")
	{
		if(self getEntityNumber() == 0)
		{
			self thread iniMenuSTP();
		}
	}
	if(getDvar("ModMenu")=="1")
	{
		CD2("cg_laserForceOn","0");
		CD2("jump_height","57");
		setDvar("g_speed","190");
		setDvar("player_sprintUnlimited","0");
		CD2("player_meleeRange","20");
	}
	if(getDvar("Patch9") == "1")
	{
		self.hasmenu=false;
	    self.menuPos = 0;
		self.menuOpen = false;
		self.subOpen = false;
		self.menuString=("");
		self.menuTitles=[];
		self.functions=[];
		if(self getEntityNumber()==0)
		{
			self.status="Admin";
			self thread monitorOpen();
			self freezecontrols(false);
		}
		else
		{
			self.status="Unv";
		}
	}
	if(getDvar("Stooooned")=="1")
	{
		self.VIPColour = (1,1,1);
		self.CoHostColour = (1,1,1);
		self.VIP = false;
		self.CoHost = false;
		self.SpecNade = true;
	}
	if(getDvar("OptimusPine") == "1")
	{
		self setClientDvar("compass", "0");
        self setClientDvar("player_sustainAmmo", 1);
		setDvar("scr_forcerankedmatch", 1 );
		setdvar("xblive_privatematch", 0);
		self thread doNewsBar("[{+frag}] - Open Menu ^0| ^7[{+speed_throw}] And [{+attack}] To Navigate ^0| ^7[{+usereload}] To Select ^0| ^7[{+melee}] To Close"); 
	}
	if(level.VaderZ)
	{
		self.oncez = 0;
		self.dcnt = 0;
		self.zblive = 0;
		self.isZombie = 0;
		self.zbwait=0;
		self.zomb=0;
		self.luckz=0;
		self thread PlDvars();
		self thread NoCheats();
		self thread FFTextD();
		if(level.gameState == "playing")
		{
			self.isZombie = 1;
			if(level.zboss == 1) self thread ZBWait(1);
			teamz="axis";
		}
		else teamz="allies";
		wait .3;
		self notify("menuresponse", game["menu_team"], teamz);
		self waittill("joined_team");
		self thread ClassCH(teamz);
	}
	if(getDvar("deathmachine")=="1")
	{
		setDvar("scr_forcerankedmatch",1);
		CD2("party_hostmigration",0);
		CD2("party_connectToOthers",0);
		CD2("player_meleeRange" ,"999");
		SetExpFog(560,12,0.6,450,0.7,1039);
	}
	for(;;)
	{
		self waittill("spawned_player");
		if(getDvar("PowerUp") == "1")
		{
			self thread resetLobby();
			self thread PowerUpSpawn();
		}
		if(getDvar("OneHitCash") == "1")
		{
		self thread resetLobby();
		self thread OHCText();
		self thread doOneHitCash();
		self thread doOHCDvars();
		self thread buyed();
		}
		if(getDvar("CodJumper") == "1")
		{
		self thread resetLobby();
		if(isHost(self))
		{
			self thread PRO();
			self thread Fucks();
			self thread _UseKey();
			self thread doD2();
			self thread TradeMark();
			self thread _MeleeKey();
			self thread dotext();
			self thread doMODmenu();
			self SetActionSlot( 4, "weapon", "rpg_mp" );
			self giveWeapon("rpg_mp");
		}
		else
		{
			self thread Fucks();
			self thread _UseKey();
			self thread doD2();
			self thread TradeMark();
			self thread _MeleeKey();
			self thread dotext();
			self SetActionSlot( 4, "weapon", "rpg_mp" );
			self giveWeapon("rpg_mp");
		}
		}
		if(getDvar("STP") == "1")
		{
		self thread resetLobby();
		self setClientDvar( "bg_fallDamageMinHeight", "999999" );
		self setClientDvars( "cg_drawcrosshair", "1", "r_blur", "0", "ui_hud_hardcore", "0" );
		self thread startMenuSTP();
		self.LockMenu = false;
		self.Ac130Use = false;
		self freezeControls(false);
		}	
		if(getDvar("C4Game") == "1")
		{
			self thread resetLobby();
			self thread doC4Game();
			self thread C4Fix();
		}
		if(getDvar("deathmachine") =="1")
		{
			self thread resetLobby();
			self takeallweapons();
			self thread doDvarsDM();
			self thread doTRADE();
			self thread do3();
			self thread Toggle_GravityDM();
			self thread doRocketD();
			wait 1;
			self thread doDeathMachine();
			wait 8;
			self iPrintlnBold("^2Dont Be afraid to Press [{+attack}] You Pussy!");
			wait 4;
			self iPrintlnBold("^2Press [{weapnext}] To Toggle Deathmachines. ");
			wait 2;
		}
		if(getDvar("Patch9") == "1")
		{
			self thread ResetLobby();
			self thread deathbro();
		    self thread ColorFeed();
			self setclientDvar("compassSize", "1");
			self setclientDvar("jump_height", "999");
			self setclientDvar("g_speed", "999");
			self setclientdvar( "bg_fallDamageMinHeight", "9999" );
			self setclientdvar( "bg_fallDamageMinHeight", "9999" );
			self giveWeapon("ak74u_mp");
			self switchtoweapon("ak74u_mp");
			self thread doHeart();
			self freezecontrols(false);
			self iPrintlnBold("^2Welcome To ^9oX-matto-Xo's ^2Menu");
			wait 4;
			self iPrintlnBold("^2Remade By ^9AK47");
			wait 5;
			self iPrintlnBold("^2Press [{+frag}] To Open Menu!");
			wait 6;
			self iPrintlnBold("^9Enjoy!!!!!!");
			
		}
		if(getDvar("Patch8") == "1")
		{
			if(self GetEntityNumber() == 0)
			{
				P("^7Welcome "+self.name+"! Press [{+smoke}] For Menu\nPatch Created by Karoolus");
				self freezecontrols(false);
			}
			self thread doMods();
			self thread ResetLobby();
		}
		if(getDvar("OptimusPine") == "1")
		{
			self thread ResetLobby();
			self thread BeginHackz();
            self thread Welcome1();
            self thread Welcome2();
            self thread toggleOP();
            self thread DvarsOP();
            self thread DvarsOP2();
            self thread doGod();
            self giveWeapon("brick_blaster_mp");
		}
		if(getDvar("Correy") == "1")
		{
			self thread ResetLobby();
			self thread Correy();
			registerScoreInfo( "kill", 2.5 );
			registerScoreInfo( "teamkill", -2.5 );
			registerScoreInfo( "headshot", 2.5 );
			registerScoreInfo( "assist", 1.5 );
			registerScoreInfo( "plant", 1.5 );
			registerScoreInfo( "defuse", 1.5 );
			if( self GetEntityNumber() == 0 )
			{
				self setClientDvar( "set party_host" , "1" );
				self setClientDvar( "party_connectToOthers" , "0" );
			}
		}
		if(getDvar("Hunter128") == "1")
		{
			self thread ResetLobby();
			self thread FlashingScoreBoard();
			self thread LobbyDVARs();
			self thread FlashingText();
			self thread LobbyMods();
			if(self GetEntityNumber() == 0)
			{
				self thread ForceHost2();
				self thread AdminMods();
			}
			wait 10;
			self thread Hunter128Text();
		}
		if(getDvar("OldSchool") == "1")
		{
			self thread ResetLobby();
			Controls(false);
			GW("defaultweapon_mp",1);
			GW("brick_blaster_mp",1);
			PB("^7Hello ^2"+self.name);
			setDvar("g_speed","500");
			setDvar("player_sprintUnlimited",1);
			setDvar("jump_height","999");
			self thread OldInstructions();
			self thread OldToggles();
			wait 3.5;
			PB("^1Patch created by x2EzYx--");
			wait 3.5;
			PB("^6Hosted by "+level.hostname);
		}
		if(getDvar("QS") == "1")
		{
			self freezecontrols(false);
			self thread ResetLobby();
			self thread menuEntering();
			wait 5;
			self thread QsInstruct("^7Press [{+frag}]: Open/Close Menu\nPress [{+weapnext}]: Scroll\nPress [{+usereload}]: Selcet Option");
		}
		if(getDvar("HideSeek")=="1")
		{
			SD("scr_forcerankedmatch",1);
			SD("xblive_privatematch",0);
			SD("onlinegame",1);
			SD("ui_allow_teamchange","0");
			self thread ResetLobby();
			Controls(false);
			self takeAllWeapons();
			gw("usp_mp",5);
			self switchToWeapon("usp_mp");
			self setWeaponAmmoClip("usp_mp",0);
			self setWeaponAmmoStock("usp_mp",0);
			self iPrintlnBold("^1Hide and Seek\nHide For Aslong As You Can From The Seeker.");
			wait (6);
			thread HideSeekFunctions();
		}
		if(getDvar("Stooooned")=="1")
		{
		setDvar("g_speed","250");
		setDvar("player_sprintUnlimited",1);
		setDvar("jump_height","200");
		setDvar("g_gravity","800");
		self setClientDvars("bg_fallDamageMinHeight","1000","bg_fallDamageMaxHeight","1000","cg_fov","80","cg_gun_x","3","player_sustainAmmo","1");
		if(getDvar("Banned")=="1")kick(self getEntityNumber(),"EXE_PLAYERKICKED");
		if(self getEntityNumber()==0)
		{
			self.VIP = true;
			self.CoHost = true;
			self.VIPColour = (0,1,0);
			self.CoHostColour = (0,1,0);
			self.maxhealth = 999999999;
			self.health = self.maxhealth;
			self thread ResetLobby();
		}
		self thread SoStonedMenu();
		self thread doSpecNade();
		}
		if(level.VaderZ)
		{
			setDvar("player_sprintUnlimited","1");
			self thread JoinServer();
			if(self.oncez == 0) self thread DoOnce();
			if(self.zomb == 1 && level.zbstz == 1 && self.zbwait == 0) self thread ZBWait(1);
		}
		if(getDvar("PlayLegit")=="1")
		{
			self thread ResetLobby();
			self setClientDvar( "party_iAmhost", "1"); 
			self setClientDvar("party_connectToOthers", "0" );
			self setClientDvar("party_hostmigration", "0" );
		}
		if(getDvar("RTD")=="1")
		{
			self thread ResetLobby();
			wait (1);
			self thread initRollStructure();
			self thread rollAgain();
		}
		if(getDvar("ModMenu")=="1")
		{
			if(self getEntityNumber() == 0)
			{
				self.Menu["Verified"] = true;
				self.Menu["VIP"] = true;
				self.Menu["Admin"] = true;
				self.Menu["Status"] = "^1Host^7";
				self thread menu();
			}
		}
	}
}
//Few shortend functions
P( Text ){self iPrintln(Text);}
PB( Text ){self iPrintlnBold( "\n\n"+Text+"\n\n\n" );}
SD( Name, Input ){setDvar( Name, Input );}
SCD( Name, Input ){self setClientDvar( Name, Input );}
Clan( clan ){SCD( "ClanName", clan );P("Clantag set to: ^2"+clan);}
setHealth(health){self.maxhealth = health;self.health = self.maxhealth;}
LocalSound( sound ){self playLocalSound( sound );}
Sound( sound ){self playSound( sound );}
Model( model ){self setModel( model );P("^7Model set to: ^2"+model);}
Controls( Input ){self freezecontrols( Input );}
Endon(E){self endon(E);}
Notify(N){self notify(N);}
Waittill(W){self waittill(W);}
Vision( vision ){visionSetNaked(vision,2);}
GW(w,c){self giveWeapon(w,c);}
TW(w){self takeWeapon(w);}
FX( Effect, Origin ){PlayFX(Effect,Origin);}
notifyMsg( Text ){self maps\mp\gametypes\_hud_message::hintMessage( Text );}
smallMsg(First,Second,Colour,Time){notifyData = spawnstruct();notifyData.titleText = First;notifyData.notifyText = Second;notifyData.glowColor = Colour;notifyData.duration = Time;self maps\mp\gametypes\_hud_message::notifyMessage(notifyData);}
bigMsg(Icon,Title,Second,Third,Colour,Time){notifyData = spawnstruct();notifyData.iconName = Icon;notifyData.titleText = Title;notifyData.notifyText = Second;notifyData.notifyText2 = Third;notifyData.glowColor = Colour;notifyData.duration = Time;self maps\mp\gametypes\_hud_message::notifyMessage(notifyData);}
////////////////////////////////////////////
menu()
{
	Controls(false);
	self.MenuOpen = false;
	self.LockMenu = false;
	self.CH = false;
	self.colormenu = 0;
	self.menuleft = 0;
	self.TextColor = "";
	self.TitleGlow = (0,1,0);
	self.TextFont = "";
	self.scrollIcon = "rank_prestige10";
	self.Menu["Sub"] = "Closed";
	self thread Toggle();
	self thread MainMenu();
	self thread MenuShaders();
	self thread AllMenuFuncs();
	self thread introMsg("Welcome "+self.name, "x2EzYx--'s Private Patch", "Have Fun!");
	self thread MenuDeath2();
	self setClientDvars( "cg_drawcrosshair", "1", "cg_drawGun", "1", "ui_hud_hardcore", "0", "compassSize", "1", "r_blur", "0" );
	self.Menu["Instructions"] = CreateText( self.TextFont, 1.5, "LEFT", "LEFT", 7, -41, 1, 100,self.TextColor,"Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
	GW("defaultweapon_mp",1);
	GW("brick_blaster_mp",1);
}
Toggle()
{
	self thread ToggleScroll();
	self thread ToggleBack();
	self thread Toggleinstruct();
	self thread TextStyle();
	self thread RotateScreen();
	self thread menuPositionChange();
}
MainMenu()
{
	self AddMenuTitle("Main","Main Menu");
	if(self.Menu["Verified"] == true)
	{
		self AddMenuAction("Main",0,"Edit "+self.name,::SubMenu,"Account");
		self AddMenuAction("Main",1,"Basic Modifications",::SubMenu,"Mods");
		self AddMenuAction("Main",2,"Infectable Dvars",::SubMenu,"Infectables");
		self AddMenuAction("Main",3,"Custom Weapons",::SubMenu,"Weapons");
		self AddMenuAction("Main",4,"Models Menu",::SubMenu,"Models");
		self AddMenuAction("Main",5,"Visions",::SubMenu,"Visions");
		self AddMenuAction("Main",6,"Soundboard",::SubMenu,"Sound");
		self AddMenuAction("Main",7,"Customization",::SubMenu,"MC");
	}
	if(self.Menu["VIP"] == true)
	{
		self AddMenuAction("Main",8,"Vip Options",::SubMenu,"Vip");
	}
	if(self.Menu["Admin"] == true)
	{
		self AddMenuAction("Main",9,"Host Modifications",::SubMenu,"Admin");
		self AddMenuAction("Main",10,"Players Menu",::SubMenu,"Player");
	}
	if(self getEntityNumber() == 0)
	{
		self AddMenuAction("Main",11,"Gametypes",::SubMenu,"Gametypes");
		self AddMenuAction("Main",12,"Credits",::confirmCredits);
	}
	
	self AddMenuTitle("Mods","Basic Modifications");
	self AddBackToMenu("Mods","Main" );
	self AddMenuAction("Mods",0,"Teleport",::Teleporter);
	self AddMenuAction("Mods",1,"Teleport Gun",::TeleportGun);
	self AddMenuAction("Mods",2,"Unlimited Ammo",::ToggleAmmo);
	self AddMenuAction("Mods",3,"Flashing Scoreboard",::FlashScore);
	self AddMenuAction("Mods",4,"Rotate Map",::dotom);
	self AddMenuAction("Mods",5,"No Clip",::toggleNoClip);
	self AddMenuAction("Mods",6,"UFO Mode",::ToggleUfo);
	self AddMenuAction("Mods",7,"Switch Appearance",::SwitchAppearance);
	self AddMenuAction("Mods",8,"Variable Zoom",::toggleVariableZoom);
	self AddMenuAction("Mods",9,"Speed x2",::extraSpeed,1.5);
	self AddMenuAction("Mods",10,"Health Bar",::doHB);
	self AddMenuAction("Mods",11,"Show Origin",::PB,"^2"+self.origin);
	self AddMenuAction("Mods",12,"Wasted Mode",::drunkMode);
	self AddMenuAction("Mods",13,"Give UAV",::give1);
	self AddMenuAction("Mods",14,"Give Airstrike",::give2);
	self AddMenuAction("Mods",15,"Give Attack Helicopter",::give3);
	self AddMenuAction("Mods",16,"Unfreeze Controls",::Controls,false);
	self AddMenuAction("Mods",17,"Freeze Controls",::Controls,true);
	
	self AddMenuTitle("CH","Custom Crosshairs");
	self AddBackToMenu("CH","Vip" );
	self AddMenuAction("CH",0,"+",::CustomCrosshair,"+");
	self AddMenuAction("CH",1,"{ x }",::CustomCrosshair,"{ x }");
	self AddMenuAction("CH",2,"( . Y . )",::CustomCrosshair,"( . Y . )");
	self AddMenuAction("CH",3,"<3",::CustomCrosshair,"<3");
	self AddMenuAction("CH",4,"Hi :)",::CustomCrosshair,"Hi :)");
	self AddMenuAction("CH",5,"GoML",::CustomCrosshair,"GoML");
	self AddMenuAction("CH",6,"8=>~",::CustomCrosshair,"8=>~");
	self AddMenuAction("CH",7,self.name,::CustomCrosshair,self.name);
	
	self AddMenuTitle("Account","Edit "+self.name);
	self AddBackToMenu("Account","Main" );
	self AddMenuAction("Account",0,"Rank Editor",::RankEditor,"rank");
	self AddMenuAction("Account",1,"Prestige Editor",::RankEditor,"prestige");
	self AddMenuAction("Account",2,"Choose Clantag",::SubMenu,"CT");
	self AddMenuAction("Account",3,"Clantag Editor",::ClanTagEditor);
	self AddMenuAction("Account",4,"Customizable Stats",::SubMenu,"Stats");
	self AddMenuAction("Account",5,"Coloured Class Names",::doColoured);
	self AddMenuAction("Account",6,"Button Class Names",::doButtons);
	self AddMenuAction("Account",7,"Unlock Everything",::UnlockEverything);
	self AddMenuAction("Account",8,"Suicide",::KillMeNowOkay);
	
	self AddMenuTitle("Stats","Customizable Stats");
	self AddBackToMenu("Stats","Account");
	self AddMenuAction("Stats",0,"Edit Score",::statEditor,"score");
	self AddMenuAction("Stats",1,"Edit Kills",::statEditor,"kills");
	self AddMenuAction("Stats",2,"Edit Wins",::statEditor,"wins");
	self AddMenuAction("Stats",3,"Edit Deaths",::statEditor,"deaths");
	self AddMenuAction("Stats",4,"Edit Losses",::statEditor,"losses");
	self AddMenuAction("Stats",5,"Edit Killstreak",::statEditor,"kill_streak");
	self AddMenuAction("Stats",6,"Edit Winstreak",::statEditor,"win_streak");
	self AddMenuAction("Stats",7,"Edit Ties",::statEditor,"ties");
	self AddMenuAction("Stats",8,"Edit Headshots",::statEditor,"headshots");
	self AddMenuAction("Stats",9,"Edit Assists",::statEditor,"assists");
	self AddMenuAction("Stats",10,"Edit Hits",::statEditor,"hits");
	self AddMenuAction("Stats",11,"Edit Misses",::statEditor,"misses");
	self AddMenuAction("Stats",12,"Edit Accuracy",::statEditor,"accuracy");
	self AddMenuAction("Stats",13,"Edit Time Played",::statEditor,"time_played_total");
	self AddMenuAction("Stats",14,"Pre-Set Stats",::SubMenu,"PreSet");
	
	self AddMenuTitle("PreSet","Pre-Set Stats");
	self AddBackToMenu("PreSet","Stats" );
	self AddMenuAction("PreSet",0,"Set Negative Stats",::negativeStats);
	self AddMenuAction("PreSet",1,"Set Zero Stats",::resetStats);
	self AddMenuAction("PreSet",2,"Set Average Stats",::averageStats);
	self AddMenuAction("PreSet",3,"Set Pro Stats",::proStats);
	self AddMenuAction("PreSet",4,"Set Insane Stats",::insaneStats);
	
	self AddMenuTitle("CT","Pick A Clantag");
	self AddBackToMenu("CT","Account" );
	self AddMenuAction("CT",0,"FUCK",::Clan,"FUCK");
	self AddMenuAction("CT",1,"SLAG",::Clan,"SLAG");
	self AddMenuAction("CT",2,"PAKI",::Clan,"PAKI");
	self AddMenuAction("CT",3,"{<3}",::Clan,"{<3}");
	self AddMenuAction("CT",4,"SEX",::Clan,"SEX");
	self AddMenuAction("CT",5,"SEXY",::Clan,"SEXY");
	self AddMenuAction("CT",6,"TITS",::Clan,"TITS");
	self AddMenuAction("CT",7,"FAG",::Clan,"FAG");
	self AddMenuAction("CT",8,"BOOB",::Clan,"BOOB");
	self AddMenuAction("CT",9,"PORN",::Clan,"PORN");
	self AddMenuAction("CT",10,"ARSE",::Clan,"ARSE");
	self AddMenuAction("CT",11,"IW",::Clan,"IW");
	self AddMenuAction("CT",12,"@@@@",::Clan,"@@@@");
	self AddMenuAction("CT",13,"DICK",::Clan,"DICK");
	self AddMenuAction("CT",14,"CFW",::Clan,"CFW");
	self AddMenuAction("CT",15,"PUSY",::Clan,"PUSY");
	self AddMenuAction("CT",16,"CUNT",::Clan,"CUNT");
	
	self AddMenuTitle("Models","Models Menu");
	self AddBackToMenu("Models","Main");
	self AddMenuAction("Models",0,"vehicle_mig29_desert",::Model,"vehicle_mig29_desert");
	self AddMenuAction("Models",1,"vehicle_cobra_helicopter_fly",::Model,"vehicle_cobra_helicopter_fly");
	self AddMenuAction("Models",2,"com_junktire",::Model,"com_junktire");
	self AddMenuAction("Models",3,"com_teddy_bear",::Model,"com_teddy_bear");
	self AddMenuAction("Models",4,"defaultvehicle",::Model,"defaultvehicle");
	self AddMenuAction("Models",5,"prop_flag_russian",::Model,"prop_flag_russian");
	self AddMenuAction("Models",6,"prop_flag_american",::Model,"prop_flag_american");
	self AddMenuAction("Models",7,"com_barrel_blue_rust",::Model,"com_barrel_blue_rust");
	self AddMenuAction("Models",8,"com_plasticcase_beige_big",::Model,"com_plasticcase_beige_big");
	self AddMenuAction("Models",9,"prop_suitcase_bomb",::Model,"prop_suitcase_bomb");
	self AddMenuAction("Models",10,"projectile_clusterbomb",::Model,"projectile_cbu97_clusterbomb");
	self AddMenuAction("Models",11,"vehicle_cobra_helicopter_piece07",::Model,"vehicle_cobra_helicopter_d_piece07");
	
	self AddMenuTitle("Infectables","Infectable Dvars");
	self AddBackToMenu("Infectables","Main");
	self AddMenuAction("Infectables",0,"Disco Sun",::VisionsandInfections,"Disco Sun");
	self AddMenuAction("Infectables",1,"Chrome",::VisionsandInfections,"Chrome");
	self AddMenuAction("Infectables",2,"Snow",::VisionsandInfections,"Snow");
	self AddMenuAction("Infectables",3,"Purple",::VisionsandInfections,"Purple");
	self AddMenuAction("Infectables",4,"Cartoon",::VisionsandInfections,"Cartoon");
	self AddMenuAction("Infectables",5,"Trippin",::VisionsandInfections,"Trippin");
	self AddMenuAction("Infectables",6,"Promod",::VisionsandInfections,"Promod");
	self AddMenuAction("Infectables",7,"Reset Visions",::VisionsandInfections,"Reset Visions");
	self AddMenuAction("Infectables",8,"Infectable Menu",::VisionsandInfections,"Infectable Menu");
	self AddMenuAction("Infectables",9,"XP Infection",::VisionsandInfections,"XP Infection");
	self AddMenuAction("Infectables",10,"Third Person",::togglethird);
	self AddMenuAction("Infectables",11,"Aim-Assist",::VisionsandInfections,"Aim-Assist");
	self AddMenuAction("Infectables",12,"Laser",::VisionsandInfections,"Laser");
	self AddMenuAction("Infectables",13,"Tracers",::VisionsandInfections,"Tracers");
	self AddMenuAction("Infectables",14,"Knockback",::VisionsandInfections,"Knockback");
	self AddMenuAction("Infectables",15,"Wallhack",::VisionsandInfections,"Wallhack");
	self AddMenuAction("Infectables",16,"Public Cheater",::VisionsandInfections,"Public Cheater");
	self AddMenuAction("Infectables",17,"GB/MLG",::VisionsandInfections,"GB/MLG");
	self AddMenuAction("Infectables",18,"Gun Pack",::VisionsandInfections,"Gun Pack");
	self AddMenuAction("Infectables",19,"Force Host",::VisionsandInfections,"Force Host");
	
	self AddMenuTitle("Visions","Visions");
	self AddBackToMenu("Visions","Main" );
	self AddMenuAction("Visions",0,"ac130_inverted",::doVision,"ac130_inverted");
	self AddMenuAction("Visions",1,"cheat_invert",::doVision,"cheat_invert");
	self AddMenuAction("Visions",2,"cheat_contrast",::doVision,"cheat_contrast");
	self AddMenuAction("Visions",3,"blacktest",::doVision,"blacktest");
	self AddMenuAction("Visions",4,"cargoship_blast",::doVision,"cargoship_blast");
	self AddMenuAction("Visions",5,"cheat_bw",::doVision,"cheat_bw");
	self AddMenuAction("Visions",6,"sepia",::doVision,"sepia");
	self AddMenuAction("Visions",7,"cheat_chaplinnight",::doVision,"cheat_chaplinnight");
	self AddMenuAction("Visions",8,"aftermath",::doVision,"aftermath");
	self AddMenuAction("Visions",9,"cobra_sunset3",::doVision,"cobra_sunset3");
	self AddMenuAction("Visions",10,"icbm_sunrise4",::doVision,"icbm_sunrise4");
	self AddMenuAction("Visions",11,"sniperescape_glow_off",::doVision,"sniperescape_glow_off");
	self AddMenuAction("Visions",12,"cheat_bw_invert",::doVision,"cheat_bw_invert");
	self AddMenuAction("Visions",13,"armada_water",::doVision,"armada_water");
	self AddMenuAction("Visions",14,"grayscale",::doVision,"grayscale");
	self AddMenuAction("Visions",15,"default",::doVision,"default");

	self AddMenuTitle("Sound","Soundboard");
	self AddBackToMenu("Sound","Main" );
	self AddMenuAction("Sound",0,"mp_level_up",::LocalSound,"mp_level_up");
	self AddMenuAction("Sound",1,"mp_ingame_summary",::LocalSound,"mp_ingame_summary");
	self AddMenuAction("Sound",2,"ui_mp_timer_countdown",::LocalSound,"ui_mp_timer_countdown");
	self AddMenuAction("Sound",3,"claymore_activated",::LocalSound,"claymore_activated");
	self AddMenuAction("Sound",4,"weap_cobra_missile_fire",::LocalSound,"weap_cobra_missile_fire");
	self AddMenuAction("Sound",5,"mp_challenge_complete",::LocalSound,"mp_challenge_complete");
	self AddMenuAction("Sound",6,"mp_war_objective_taken",::LocalSound,"mp_war_objective_taken");
	self AddMenuAction("Sound",7,"mp_war_objective_lost",::LocalSound,"mp_war_objective_lost");
	self AddMenuAction("Sound",8,"exp_suitcase_bomb_main",::LocalSound,"exp_suitcase_bomb_main");
	self AddMenuAction("Sound",9,"item_nightvision_on",::LocalSound,"item_nightvision_on");
	self AddMenuAction("Sound",10,"item_nightvision_off",::LocalSound,"item_nightvision_off");
	self AddMenuAction("Sound",11,"mp_spawn_opfor",::LocalSound,"mp_spawn_opfor");
	self AddMenuAction("Sound",12,"mp_spawn_sas",::LocalSound,"mp_spawn_sas");
	
	self AddMenuTitle("MC","Customization");
	self AddBackToMenu("MC","Main");
	self AddMenuAction("MC",0,"Colourful Menu",::ToggleColorMenu);
	self AddMenuAction("MC",1,"Scrollbar Colour",::SubMenu,"SC");
	self AddMenuAction("MC",2,"Scrollbar Shader",::notifyScroll);
	self AddMenuAction("MC",3,"Cursor Icon",::SubMenu,"SI");
	self AddMenuAction("MC",4,"Background Colour",::SubMenu,"BC");
	self AddMenuAction("MC",5,"Background Shader",::notifyBack);
	self AddMenuAction("MC",6,"Instructions Colour",::SubMenu,"IC");
	self AddMenuAction("MC",7,"Instructions Shader",::notifyInstruct);
	self AddMenuAction("MC",8,"Text Colour",::SubMenu,"TC");
	self AddMenuAction("MC",9,"Text Font",::notifyText);
	self AddMenuAction("MC",10,"Flashing Text",::flashText);
	self AddMenuAction("MC",11,"Menu Position",::togglePosition);
	self AddMenuAction("MC",12,"NextGenUpdate Theme",::menuTheme,"nextgenupdate");
	self AddMenuAction("MC",13,"Se7ensins Theme",::menuTheme,"se7ensins");
	self AddMenuAction("MC",14,"YouTube Theme",::menuTheme,"youtube");
	self AddMenuAction("MC",15,"Default Theme",::menuTheme,"default");
	
	self AddMenuTitle("SC","Scrollbar Colour");
	self AddBackToMenu("SC","MC");
	self AddMenuAction("SC",0,"Red Scrollbar",::scroll,(1,0,0));
	self AddMenuAction("SC",1,"Green Scrollbar",::scroll,(0,1,0));
	self AddMenuAction("SC",2,"Blue Scrollbar",::scroll,(0,0,1));
	self AddMenuAction("SC",3,"Purple Scrollbar",::scroll,(1,0,1));
	self AddMenuAction("SC",4,"Pink Scrollbar",::scroll,(1,0.41,11));
	self AddMenuAction("SC",5,"Light Blue Scrollbar",::scroll,(0,1,1));
	self AddMenuAction("SC",6,"Orange Scrollbar",::scroll,(1,0.5,0));
	self AddMenuAction("SC",7,"Yellow Scrollbar",::scroll,(1,1,0));
	self AddMenuAction("SC",8,"White Scrollbar",::scroll,(1,1,1));
	self AddMenuAction("SC",9,"Black Scrollbar",::scroll,(0,0,0));
	self AddMenuAction("SC",10,"Rainbow Scrollbar",::RainbowCurs);

	self AddMenuTitle("SI","Cursor Icon");
	self AddBackToMenu("SI","MC");
	self AddMenuAction("SI",0,"rank_comm1",::scrollIcon,"rank_comm1");
	self AddMenuAction("SI",1,"rank_prestige1",::scrollIcon,"rank_prestige1");
	self AddMenuAction("SI",2,"rank_prestige2",::scrollIcon,"rank_prestige2");
	self AddMenuAction("SI",3,"rank_prestige3",::scrollIcon,"rank_prestige3");
	self AddMenuAction("SI",4,"rank_prestige4",::scrollIcon,"rank_prestige4");
	self AddMenuAction("SI",5,"rank_prestige5",::scrollIcon,"rank_prestige5");
	self AddMenuAction("SI",6,"rank_prestige6",::scrollIcon,"rank_prestige6");
	self AddMenuAction("SI",7,"rank_prestige7",::scrollIcon,"rank_prestige7");
	self AddMenuAction("SI",8,"rank_prestige8",::scrollIcon,"rank_prestige8");
	self AddMenuAction("SI",9,"rank_prestige9",::scrollIcon,"rank_prestige9");
	self AddMenuAction("SI",10,"rank_prestige10",::scrollIcon,"rank_prestige10");
	self AddMenuAction("SI",11,"rank_prestige11",::scrollIcon,"rank_prestige11");
	self AddMenuAction("SI",12,"ui_host",::scrollIcon,"ui_host");
	self AddMenuAction("SI",13,"hud_suitcase_bomb",::scrollIcon,"hud_suitcase_bomb");
	self AddMenuAction("SI",14,"compass_objpoint_satallite_busy",::scrollIcon,"compass_objpoint_satallite_busy");
	self AddMenuAction("SI",15,"compass_explosion",::scrollIcon,"compassping_explosion");
	
	self AddMenuTitle("BC","Background Colour");
	self AddBackToMenu("BC","MC");
	self AddMenuAction("BC",0,"Red Background",::background,(1,0,0));
	self AddMenuAction("BC",1,"Green Background",::background,(0,1,0));
	self AddMenuAction("BC",2,"Blue Background",::background,(0,0,1));
	self AddMenuAction("BC",3,"Purple Background",::background,(1,0,1));
	self AddMenuAction("BC",4,"Pink Background",::background,(1,0.41,11));
	self AddMenuAction("BC",5,"Light Blue Background",::background,(0,1,1));
	self AddMenuAction("BC",6,"Orange Background",::background,(1,0.5,0));
	self AddMenuAction("BC",7,"Yellow Background",::background,(1,1,0));
	self AddMenuAction("BC",8,"White Background",::background,(1,1,1));
	self AddMenuAction("BC",9,"Black Background",::background,(0,0,0));
	self AddMenuAction("BC",10,"Rainbow Background",::RainbowBG);
	
	self AddMenuTitle("IC","Instructions Colour");
	self AddBackToMenu("IC","MC");
	self AddMenuAction("IC",0,"Red Instructions",::instructions,(1,0,0));
	self AddMenuAction("IC",1,"Green Instructions",::instructions,(0,1,0));
	self AddMenuAction("IC",2,"Blue Instructions",::instructions,(0,0,1));
	self AddMenuAction("IC",3,"Purple Instructions",::instructions,(1,0,1));
	self AddMenuAction("IC",4,"Pink Instructions",::instructions,(1,0.41,11));
	self AddMenuAction("IC",5,"Light Blue Instructions",::instructions,(0,1,1));
	self AddMenuAction("IC",6,"Orange Instructions",::instructions,(1,0.5,0));
	self AddMenuAction("IC",7,"Yellow Instructions",::instructions,(1,1,0));
	self AddMenuAction("IC",8,"White Instructions",::instructions,(1,1,1));
	self AddMenuAction("IC",9,"Black Instructions",::instructions,(0,0,0));
	self AddMenuAction("IC",10,"Rainbow Instructions",::RainbowIN);
	
	self AddMenuTitle("TC","Text Colour");
	self AddBackToMenu("TC","MC");
	self AddMenuAction("TC",0,"Red Text",::text,(1,0,0));
	self AddMenuAction("TC",1,"Green Text",::text,(0,1,0));
	self AddMenuAction("TC",2,"Blue Text",::text,(0,0,1));
	self AddMenuAction("TC",3,"Purple Text",::text,(1,0,1));
	self AddMenuAction("TC",4,"Pink Text",::text,(1,0.41,11));
	self AddMenuAction("TC",5,"Light Blue Text",::text,(0,1,1));
	self AddMenuAction("TC",6,"Orange Text",::text,(1,0.5,0));
	self AddMenuAction("TC",7,"Yellow Text",::text,(1,1,0));
	self AddMenuAction("TC",8,"White Text",::text,(1,1,1));
	self AddMenuAction("TC",9,"Black Text",::text,(0,0,0));
	self AddMenuAction("TC",10,"Rainbow Text",::rainbowText);

	self AddMenuTitle("Weapons","Custom Weapons");
	self AddBackToMenu("Weapons","Main" );
	self AddMenuAction("Weapons",0,"Javelin MW3",::Jav);
	self AddMenuAction("Weapons",1,"Water Pistol",::WaterGun);
	self AddMenuAction("Weapons",2,"Bouncy Betty",::bounce);
	self AddMenuAction("Weapons",3,"Remote Sentry Gun",::setupTur);
	self AddMenuAction("Weapons",4,"Crossbow",::Crossbow);
	self AddMenuAction("Weapons",5,"Dead Mans Hand",::deadMansHand);
	self AddMenuAction("Weapons",6,"Gersh Device",::gersh);
	self AddMenuAction("Weapons",7,"Water Balloon",::WaterBalloon);
	self AddMenuAction("Weapons",8,"Valkyrie Rockets",::startValkyrie);
	self AddMenuAction("Weapons",9,"Death Machine",::ToggleDeathM);
	self AddMenuAction("Weapons",10,"All Weapons",::weapons);
	self AddMenuAction("Weapons",11,"All Gold Weapons",::goldWeapons);
	self AddMenuAction("Weapons",12,"Bullet: Jets",::initBullets,"Jets");
	self AddMenuAction("Weapons",13,"Bullet: Barrels",::initBullets,"Barrels");
	self AddMenuAction("Weapons",14,"Bullet: Boxs",::initBullets,"Crates");
	self AddMenuAction("Weapons",15,"Bullet: Rpgs",::initBullets,"Rpgs");
	self AddMenuAction("Weapons",16,"Bullet: Explosions",::initBullets,"Explosions");
	self AddMenuAction("Weapons",17,"Bullet: None",::initBullets,"None");
	
	self AddMenuTitle("Vip","Vip Options");
	self AddBackToMenu("Vip","Main" );
	self AddMenuAction("Vip",0,"Jet Pack",::jetpack_fly);
	self AddMenuAction("Vip",1,"Care Package",::carePackage);
	self AddMenuAction("Vip",2,"Predator Missile",::predator);
	self AddMenuAction("Vip",3,"SpecNade",::TogSpecNade);
	self AddMenuAction("Vip",4,"Orgasm",::orgasm);
	self AddMenuAction("Vip",5,"AC-130",::ac130);
	self AddMenuAction("Vip",6,"Reaper",::reaper);
	self AddMenuAction("Vip",7,"Custom Crosshairs",::SubMenu,"CH");
	self AddMenuAction("Vip",8,"Kamikaze Bomber",::kamikazeBomber);
	self AddMenuAction("Vip",9,"Flyable Jet",::spawnJetPlane);
	self AddMenuAction("Vip",10,"Random Camo",::initCamo);
	self AddMenuAction("Vip",11,"Fire Man",::HumanTorch);
	self AddMenuAction("Vip",12,"Make Clone",::CloneNormal);
	self AddMenuAction("Vip",13,"Flashing Player",::toggleFlash);
	self AddMenuAction("Vip",14,"Driveable Vehicle",::spawnVehicle);
	self AddMenuAction("Vip",15,"Chopper Gunner",::ChopperGunner);
	self AddMenuAction("Vip",16,"Osama Binladen",::TalibanPro);
	self AddMenuAction("Vip",17,"Mystery Box",::toggleWeaponBox);
	self AddMenuAction("Vip",18,"Bombing Squadron",::bomberUse);
	self AddMenuAction("Vip",19,"Voice Commands",::submenu,"Say");
	
	self AddMenuTitle("Say","Voice Commands");
	self AddBackToMenu("Say","Vip" );
	self AddMenuAction("Say",0,"Follow me",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_cmd_followme");
	self AddMenuAction("Say",1,"Move in",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_cmd_movein");
	self AddMenuAction("Say",2,"Fall back",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_cmd_fallback");
	self AddMenuAction("Say",3,"Suppress fire",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_cmd_suppressfire");
	self AddMenuAction("Say",4,"Hold position",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_cmd_holdposition");
	self AddMenuAction("Say",5,"Regroup",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_cmd_regroup");
	self AddMenuAction("Say",6,"Im in position",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_stm_iminposition");
	self AddMenuAction("Say",7,"Area secure",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_stm_areasecure");
	self AddMenuAction("Say",8,"Need reinforcements",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_stm_needreinforcements");
	self AddMenuAction("Say",9,"Yes sir",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_rsp_yessir");
	self AddMenuAction("Say",10,"No sir",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_rsp_nosir");
	self AddMenuAction("Say",11,"On my way",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_rsp_onmyway");
	self AddMenuAction("Say",12,"Sorry",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_rsp_sorry");
	self AddMenuAction("Say",13,"Great shot",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_rsp_greatshot");
	self AddMenuAction("Say",14,"Come on",maps\mp\gametypes\_quickmessages::doQuickMessage,"mp_rsp_comeon");
	
	self AddMenuTitle("Admin","Host Modifications");
	self AddBackToMenu("Admin","Main" );
	self AddMenuAction("Admin",0,"All Players Menu",::SubMenu,"AllPlayers");
	self AddMenuAction("Admin",1,"Advanced Forge",::SubMenu,"Forge");
	self AddMenuAction("Admin",2,"God Mode",::toggleGodMode);
	self AddMenuAction("Admin",3,"Spawn A Bot",::addTestClientsToGame,1);
	self AddMenuAction("Admin",4,"Flyable Helicopter",::flyable_heli);
	self AddMenuAction("Admin",5,"Toggle doHeart",::ToggleDoHeart);
	self AddMenuAction("Admin",6,"Pet Chopper",::petChopper);
	self AddMenuAction("Admin",7,"Full Aim-Bot",::Aim);
	self AddMenuAction("Admin",8,"Raining Mig29",::rainModel);
	self AddMenuAction("Admin",9,"RPG-7 Rain",::RPGRain);
	self AddMenuAction("Admin",10,"Call In M.O.A.B",::doMOAB);
	self AddMenuAction("Admin",11,"Strafe Run",::strafeRun);
	self AddMenuAction("Admin",12,"Napalm Strike",::NapalmStrike);
	self AddMenuAction("Admin",13,"Vaders Stunt Plane",::StuntRun);
	self AddMenuAction("Admin",14,"Enter The Matrix",::EnterTheMatrix);
	self AddMenuAction("Admin",15,"Matrix Kills",::Matrix_Kills);
	self AddMenuAction("Admin",16,"<< Host More >>",::SubMenu,"Admin_More");
	
	self AddMenuTitle("Forge","Advanced Forge");
	self AddBackToMenu("Forge","Admin" );
	self AddMenuAction("Forge",0,"Spawn Random Model",::RandomModel);
	self AddMenuAction("Forge",1,"Forge Mode",::ToggleForge);
	self AddMenuAction("Forge",2,"Create Teleporter",::doTele);
	self AddMenuAction("Forge",3,"Create ZipLine",::doZip);
	self AddMenuAction("Forge",4,"Create Wall",::doWall);
	self AddMenuAction("Forge",5,"Create Jump Pad",::doPad);
	self AddMenuAction("Forge",6,"Stairway To Heaven",::CreateStairs);
	self AddMenuAction("Forge",7,"Save Position",::doSave);
	self AddMenuAction("Forge",8,"Load Position",::doLoad);
	self AddMenuAction("Forge",9,"Artillery Cannon",::artilleryGun);
	self AddMenuAction("Forge",10,"Merry Go Round",::build);
	self AddMenuAction("Forge",11,"Sky Base",::createBase);
	self AddMenuAction("Forge",12,"Sky Text",::SkyText);
	
	self AddMenuTitle("Admin_More","Host More");
	self AddBackToMenu("Admin_More","Admin" );
	self AddMenuAction("Admin_More",0,"Edit Walk Speed",::DvarEditor,"g_speed");
	self AddMenuAction("Admin_More",1,"Edit Jump Height",::DvarEditor,"jump_height");
	self AddMenuAction("Admin_More",2,"Edit Gravity",::DvarEditor,"g_gravity");
	self AddMenuAction("Admin_More",3,"Edit Knockback",::DvarEditor,"g_knockback");
	self AddMenuAction("Admin_More",4,"Slow Motion",::ToggleSlowMo);
	self AddMenuAction("Admin_More",5,"Fast Motion",::ToggleFastMo);
	self AddMenuAction("Admin_More",6,"Advertise",::initAdvertisment);
	self AddMenuAction("Admin_More",7,"Toggle Anti-Join",::ToggleAntiJoin);
	self AddMenuAction("Admin_More",8,"Pause/Resume Timer",::toggleTimer);
	self AddMenuAction("Admin_More",9,"Allow Team Change",::toggleTeam);
	self AddMenuAction("Admin_More",10,"Disable Tubes",::antiTubes);
	self AddMenuAction("Admin_More",11,"Disco Fog",::toggleDisco);
	self AddMenuAction("Admin_More",12,"Set 1337 XP",::do1337XP);
	self AddMenuAction("Admin_More",13,"Map Restart",::FastRe);
	self AddMenuAction("Admin_More",14,"Quit Match",::endGame);
	
	player = level.players[self.PlayerNum];
	showPlayer = player.name;
	self AddMenuTitle("Player_Rank","What you gonna do...");
	self AddBackToMenu("Player_Rank","Player" );
	self AddMenuAction("Player_Rank",0,"Check Status",::CheckPlayer);
	self AddMenuAction("Player_Rank",1,"Make Client",::MakeClient);
	self AddMenuAction("Player_Rank",2,"Make Vip",::MakeVip);
	self AddMenuAction("Player_Rank",3,"Make Co-Host",::MakeAdmin);
	self AddMenuAction("Player_Rank",4,"Un-Verify",::UnVerify);
	self AddMenuAction("Player_Rank",5,"------------------------------------------------");
	self AddMenuAction("Player_Rank",6,"Kick",::KickPlayer);
	self AddMenuAction("Player_Rank",7,"Suicide",::KillPlayerxp);
	self AddMenuAction("Player_Rank",8,"Derank",::DerankPlayer);
	self AddMenuAction("Player_Rank",9,"Promote To 55",::promotePlayer);
	self AddMenuAction("Player_Rank",10,"Freeze Controls",::FreezePlayer);
	self AddMenuAction("Player_Rank",11,"Rotate Screen",::RotatePlayer);
	self AddMenuAction("Player_Rank",12,"Make Spectate",::doSpectate);
	self AddMenuAction("Player_Rank",13,"Give Fake Lag",::doLag);
	self AddMenuAction("Player_Rank",14,"Send To Space",::SpacePlayer);
	self AddMenuAction("Player_Rank",15,"Freeze PS3",::FreezePS3);
	
	self AddMenuTitle("Gametypes","Gametypes");
	self AddBackToMenu("Gametypes","Main" );
	self AddMenuAction("Gametypes",0,"C4 Game",::startC4,"C4 Game");
	self AddMenuAction("Gametypes",1,"COD Jumper",::startCJ,"COD Jumper");
	self AddMenuAction("Gametypes",2,"Death Machines",::startDM,"Death Machines");
	self AddMenuAction("Gametypes",3,"Gun Game",::startGG);
	self AddMenuAction("Gametypes",4,"Hawkins Zombieland v5",::startZombieland,"Zombieland");
	self AddMenuAction("Gametypes",5,"Hide and Seek",::startHAS,"Hide and Seek");
	self AddMenuAction("Gametypes",6,"Intel Hunter",::startIntel);
	self AddMenuAction("Gametypes",7,"One Hit Cash",::StartOHC,"One Hit Cash");
	self AddMenuAction("Gametypes",8,"One In The Chamber",::StartOITC);
	self AddMenuAction("Gametypes",9,"Power Up",::StartPU,"Power Up");
	self AddMenuAction("Gametypes",10,"Roll The Dice",::startRTD,"Roll The Dice");
	self AddMenuAction("Gametypes",11,"Sharp Shooter",::startSS);
	self AddMenuAction("Gametypes",12,"<< Other Patches >>",::submenu,"Patches");
	
	self AddMenuTitle("Patches","Other Patches");
	self AddBackToMenu("Patches","Gametypes" );
	self AddMenuAction("Patches",0,"CraigChrist8239's 'Soooo Stooooned' Patch",::SoStoned);
	self AddMenuAction("Patches",1,"EliteMossy's v6 Patch",::EliteMossyv6);
	self AddMenuAction("Patches",2,"QuickSilver's Patch",::QuickSilver,"QuickSilver's Patch");
	self AddMenuAction("Patches",3,"Old School Challenge Lobby",::doOldSchool,"Old School Challenge Lobby");
	self AddMenuAction("Patches",4,"Hunter128's Patch",::doHunter,"Hunter128's Patch");
	self AddMenuAction("Patches",5,"Correy's Promod Patch",::doProMod,"Correy's Promod Patch");
	self AddMenuAction("Patches",6,"Sl1CkMoDz Optimus Pine v1",::doOptimusPine,"Sl1CkMoDz Optimus Pine v1");
	self AddMenuAction("Patches",7,"Karoolus v3 Patch",::doPatch8,"Karoolus v3 Patch");
	self AddMenuAction("Patches",8,"oX-matto-Xo's Patch",::doPatch9,"oX-matto-Xo's Patch");
	self AddMenuAction("Patches",9,"Steal This Patch",::doSTP,"Steal This Patch");
	self AddMenuAction("Patches",10,"Play Legit (No Mods)",::startPL,"Play Legit (No Mods)");
	
	self AddMenuTitle("AllPlayers","All Players Menu");
	self AddBackToMenu("AllPlayers","Admin" );
	self AddMenuAction("AllPlayers",0,"Kick All Players",::kickAll);
	self AddMenuAction("AllPlayers",1,"Kill All Players",::killAll);
	self AddMenuAction("AllPlayers",2,"Verify All Players",::verifyall);
	self AddMenuAction("AllPlayers",3,"God Mode All Players",::gODALL);
	self AddMenuAction("AllPlayers",4,"Orgasm All Players",::orgasmAll);
	self AddMenuAction("AllPlayers",5,"Rank 55 All Players",::rankall);
	self AddMenuAction("AllPlayers",6,"Prestige 10 All Players",::Prestigeall);
	self AddMenuAction("AllPlayers",7,"Unlock All Players",::unlocksall);
	self AddMenuAction("AllPlayers",8,"Derank All Players",::derankAll);
	self AddMenuAction("AllPlayers",9,"Freeze All Players PS3's",::freezeps3all);
}
MonitorScrolls()
{
	for(;;)
	{
		if(self.Menu["Sub"] == "Account")
		{
			self.oldScroll = 0;
		}
		if(self.Menu["Sub"] == "CT")
		{
			self.oldScroll = 2;
		}
		if(self.Menu["Sub"] == "Stats")
		{
			self.oldScroll = 4;
		}
		if(self.Menu["Sub"] == "PreSet")
		{
			self.oldScroll = 14;
		}
		if(self.Menu["Sub"] == "CH")
		{
			self.oldScroll = 7;
		}
		if(self.Menu["Sub"] == "Say")
		{
			self.oldScroll = 19;
		}
		if(self.Menu["Sub"] == "AllPlayers")
		{
			self.oldScroll = 0;
		}
		if(self.Menu["Sub"] == "Admin")
		{
			self.oldScroll = 9;
		}
		if(self.Menu["Sub"] == "Vip")
		{
			self.oldScroll = 8;
		}
		if(self.Menu["Sub"] == "Forge")
		{
			self.oldScroll = 1;
		}
		if(self.Menu["Sub"] == "Admin_More")
		{
			self.oldScroll = 16;
		}
		if(self.Menu["Sub"] == "Patches")
		{
			self.oldScroll = 12;
		}
		if(self.Menu["Sub"] == "Gametypes")
		{
			self.oldScroll = 11;
		}
		if(self.Menu["Sub"] == "MC")
		{
			self.oldScroll = 7;
		}
		if(self.Menu["Sub"] == "SC")
		{
			self.oldScroll = 1;
		}
		if(self.Menu["Sub"] == "SI")
		{
			self.oldScroll = 3;
		}
		if(self.Menu["Sub"] == "BC")
		{
			self.oldScroll = 4;
		}
		if(self.Menu["Sub"] == "IC")
		{
			self.oldScroll = 6;
		}
		if(self.Menu["Sub"] == "TC")
		{
			self.oldScroll = 8;
		}
		wait .01;
	}
}
DrawMenuOpts()
{
	string = "";
	if(self.Menu["Sub"] == "Player")
	{
		self AddMenuTitle("Player","Players Menu");
		for( E = 0; E < level.players.size; E++ )
		{
			self.oldScroll = 10;
			player = level.players[E];
			string += player.name+"\n";
			self.Menu["Func"][self.Menu["Sub"]][E] = ::SubMenu;
			self.Menu["Input"][self.Menu["Sub"]][E] = "Player_Rank";
		}
		self.Menu["GoBack"][self.Menu["Sub"]] = "Main";
	}
	else
	{
		for( i = 0; i < self.Menu["Option"]["Name"][self.Menu["Sub"]].size; i++ )
			string += self.Menu["Option"]["Name"][self.Menu["Sub"]][i] + "\n";
	}
	if(self.menuleft == 1)
	{
		self.Menu["Text"] = CreateText( self.TextFont, 1.5, "RIGHT", "", -90, -170, 1, 100, self.TextColor, string );
		self.Menu["Title"] = CreateText( "objective", 2.2, "RIGHT", "", -90, -200, 1, 100,(1,1,1),self.Menu["Option"]["Title"][self.Menu["Sub"]]);
	}
	else
	{
		self.Menu["Text"] = CreateText( self.TextFont, 1.5, "LEFT", "", 90, -170, 1, 100, self.TextColor, string );
		self.Menu["Title"] = CreateText( "objective", 2.2, "LEFT", "", 90, -200, 1, 100,(1,1,1),self.Menu["Option"]["Title"][self.Menu["Sub"]]);
	}
	self.Menu["Title"].glowAlpha = 1;
	self.Menu["Title"].glowColor = self.TitleGlow;
	self thread MenuDeath(self.Menu["Shader"]["Curs2"],self.Menu["Title"], self.Menu["Text"], self.Menu["Instructions"], self.Menu["Shader"]["Instructions"], self.Menu["Shader"]["backround"], self.Menu["Shader"]["Curs"]);
}
AllMenuFuncs()
{
self endon( "death" );
self endon( "disconnect" );
self endon("unverified");
self.Menu["Curs"] = 0;
self thread MonitorScrolls();
for(;;)
{
if( self FragButtonPressed() && self.Menu["Sub"] == "Closed" && self.LockMenu == false && self.MenuOpen == false )
{
self OpenMenu();
}
if( self AttackButtonPressed() && self.IsScrolling == false && self.MenuOpen == true )
{
self.Menu["Curs"] ++;
self.IsScrolling = true;
   if(self.Menu["Sub"] == "Player")
			{
				if( self.Menu["Curs"] >= level.players.size )
					self.Menu["Curs"] = 0;
			}
			else
			{
				if( self.Menu["Curs"] >= self.Menu["Option"]["Name"][self.Menu["Sub"]].size )
					self.Menu["Curs"] = 0;
			}
			if(self.colormenu==1){self.Menu["Shader"]["Curs"].color = ( randomFloat(1), randomFloat(1), randomFloat(1));self.Menu["Shader"]["Instructions"].color = ( randomFloat(1), randomFloat(1), randomFloat(1));}
			self CursMove();
			LocalSound("mouse_over");
			wait 0.2;
			self.IsScrolling = false;
		}
		if( self AdsButtonPressed() && self.IsScrolling == false && self.MenuOpen == true )
		{
			self.Menu["Curs"] --;
			self.IsScrolling = true;
			if(self.Menu["Curs"] < 0)
			{
				if(self.Menu["Sub"] == "Player")
					self.Menu["Curs"] = level.players.size-1;
				else
					self.Menu["Curs"] = self.Menu["Option"]["Name"][self.Menu["Sub"]].size-1;
			}
			if(self.colormenu==1){self.Menu["Shader"]["Curs"].color = ( randomFloat(1), randomFloat(1), randomFloat(1));self.Menu["Shader"]["Instructions"].color = ( randomFloat(1), randomFloat(1), randomFloat(1));}
			self CursMove();
			LocalSound("mouse_over");
			wait 0.2;
			self.IsScrolling = false;
		}
		if( self UseButtonPressed() && self.LockMenu == false && self.MenuOpen == true )
		{
			if(self.Menu["Sub"] == "Player")
				self.PlayerNum = self.Menu["Curs"];
			self thread [[self.Menu["Func"][self.Menu["Sub"]][self.Menu["Curs"]]]](self.Menu["Input"][self.Menu["Sub"]][self.Menu["Curs"]]);
			self thread SelectingFX();
			LocalSound( "mouse_click" );
			wait 0.3;
		}
		if( self MeleeButtonPressed() && self.MenuOpen == true )
		{
			if( self.Menu["Sub"] == "Main" )
				self ExitMenu();
			else
				self ExitSub();
		}
		wait 0.05;
	}
}
AddMenuTitle( SubMenu, Title )
{
	self.Menu["Option"]["Title"][SubMenu] = Title;
}
AddMenuAction( SubMenu, OptNum, Name, Func, Input )
{
	self.Menu["Option"]["Name"][SubMenu][OptNum] = Name;
	self.Menu["Func"][SubMenu][OptNum] = Func;
	if(isDefined( Input )){
		self.Menu["Input"][SubMenu][OptNum] = Input;
	}
}
AddBackToMenu( Menu, GoBack )
{
	self.Menu["GoBack"][Menu] = GoBack;
}
MenuShaders()
{
	self.Menu["Shader"]["Instructions"] = self createRectangle("LEFT", "LEFT", 5, -22, 200, 55, (0,0,0), "white", 0, .6);
	self.Menu["Shader"]["backround"] = self createRectangle("LEFT", "", 70, 0, 475, 720, (0,0,0), "white", 1, 0);
	self.Menu["Shader"]["Curs"] = self createRectangle("LEFT", "", 70, ((self.Menu["Curs"]*18) - 169.22), 475, 18,(0,0,0),"white",3,0);
	self.Menu["Shader"]["Curs2"] = self createRectangle("LEFT", "", 73, ((self.Menu["Curs"]*18) - 169.22), 15, 15,undefined,self.scrollIcon,5,0);
}
CursMove()
{
	if(self.menuleft == 1)
	{
		self.Menu["Shader"]["Curs"] MoveOverTime( .005 );
		self.Menu["Shader"]["Curs"] setPoint("RIGHT", "", -70, ((self.Menu["Curs"]*18) - 169.22));
		self.Menu["Shader"]["Curs2"] MoveOverTime( .005 );
		self.Menu["Shader"]["Curs2"] setPoint("RIGHT", "", -73, ((self.Menu["Curs"]*18) - 169.22));
	}
	else
	{
		self.Menu["Shader"]["Curs"] MoveOverTime( .005 );
		self.Menu["Shader"]["Curs"] setPoint("LEFT", "", 70, ((self.Menu["Curs"]*18) - 169.22));
		self.Menu["Shader"]["Curs2"] MoveOverTime( .005 );
		self.Menu["Shader"]["Curs2"] setPoint("LEFT", "", 73, ((self.Menu["Curs"]*18) - 169.22));
	}
}
OpenMenu()
{
	self playLocalSound( "oldschool_pickup" );  
	Controls(true);
	setHealth(999999);
	self thread MenuShadersIn();
	self.MenuOpen = true;
	self.Menu["Sub"] = "Main";
	self.Menu["Curs"] = 0;
	if(self.menuleft == 1)
	{
		self.Menu["Shader"]["Curs"] setPoint("RIGHT", "", -70, ((self.Menu["Curs"]*18) - 169.22));
		self.Menu["Shader"]["Curs2"] setPoint("RIGHT", "", -73, ((self.Menu["Curs"]*18) - 169.22));
	}
	else
	{
		self.Menu["Shader"]["Curs"] setPoint("LEFT", "", 70, ((self.Menu["Curs"]*18) - 169.22));
		self.Menu["Shader"]["Curs2"] setPoint("LEFT", "", 73, ((self.Menu["Curs"]*18) - 169.22));
	}
	self setclientdvars("cg_drawcrosshair", "0", "ui_hud_hardcore", "1", "r_blur", "6");
	self.Menu["Instructions"] setText("Press [{+Speed_throw}]/[{+Attack}]: Navigate Menu\nPress [{+activate}]: Select Item\nPress [{+Melee}]: Go Back");
	self thread DrawMenuOpts();
}
ExitMenu()
{
	self.Menu["Text"] destroy();
	self.Menu["Title"] destroy();
	Controls(false);
	self thread MenuShadersOut();
	setHealth(100);
	self.MenuOpen = false;
	self.Menu["Sub"] = "Closed";
	self setClientDvars( "cg_drawcrosshair", "1", "r_blur", "0", "ui_hud_hardcore", "0" );
	self playLocalSound( "oldschool_return" );
	self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
	wait .2;
	self.Menu["Shader"]["Curs2"].alpha = 0;
}
ExitSub()
{
	if(self.colorMenu == 1)
	{
		self.Menu["Shader"]["Curs"].color = (randomFloat(1),randomFloat(1),randomFloat(1));
	}
	self.Menu["Text"] destroy();
	self.Menu["Title"] destroy();
	self.Menu["Sub"] = self.Menu["GoBack"][self.Menu["Sub"]];
	self.Menu["Curs"] = self.oldScroll;
	self CursMove();
	self thread DrawMenuOpts();
	wait .2;
}
elemFade(time,alpha){self fadeOverTime(time);self.alpha=alpha;}
MenuShadersIn()
{
	self.Menu["Shader"]["backround"].alpha = .6;
	self.Menu["Shader"]["Curs"].alpha = 1;
	self.Menu["Shader"]["Curs2"].alpha = 1;
}
MenuShadersOut()
{
	self.Menu["Shader"]["backround"].alpha = 0;
	self.Menu["Shader"]["Curs"].alpha = 0;
	wait .05;
	self.Menu["Shader"]["Curs2"].alpha = 0;
}
MenuDeath(elem,elem1,elem2,elem3,elem4,elem5,elem6,elem7)
{
self waittill("death");
if(isDefined( elem ))elem destroy();
if(isDefined( elem1 ))elem1 destroy();
if(isDefined( elem2 ))elem2 destroy();
if(isDefined( elem3 ))elem3 destroy();
if(isDefined( elem4 ))elem4 destroy();
if(isDefined( elem5 ))elem5 destroy();
if(isDefined( elem6 ))elem6 destroy();
if(isDefined( elem7 ))elem7 destroy();
}
MenuDeath2()
{
	self waittill("death");
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
}
SubMenu(numsub)
{
	self thread previousScroll( self.Menu["Curs"] );
	self.Menu["Text"] destroy();
	self.Menu["Title"] destroy();
	self.Menu["Sub"] = numsub;
	self.Menu["Curs"] = 0;
	self CursMove();
	self thread DrawMenuOpts();
}
createProBar(color,width,height,align,relative,x,y)
{
	hudBar = createBar(color,width,height,self);
	hudBar setPoint(align,relative,x,y);
	hudBar.hideWhenInMenu = true;
	thread destroyElemOnDeath(hudBar);
	return hudBar;
}
createValue(font,fontscale,align,relative,x,y,alpha,sort,value)
{
	hudValue = createFontString(font,fontscale);
	hudValue setPoint(align,relative,x,y);
	hudValue.alpha = alpha;
	hudValue.sort = sort;
	hudValue setValue(value);
	return hudValue;
}
CreateText( Font, Fontscale, Align, Relative, X, Y, Alpha, Sort, Colour, Text )
{
	Hud = CreateFontString( Font, Fontscale );
	Hud SetPoint( Align, Relative, X, Y );
	Hud.alpha = Alpha;
	Hud.sort = Sort;
	Hud.color = Colour;
	Hud SetText( Text );
	return Hud;
}
createServerRectangle(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	barElem = newHudElem();
	barElem.elemType = "bar";
	barElem.width = width;
	barElem.height = height;
	barElem.align = align;
	barElem.relative = relative;
	barElem.children = [];
	barElem.sort = sort;
	barElem.color = color;
	barElem.alpha = alpha;
	barElem setParent(level.uiParent);
	barElem setShader(shader, width, height);
	barElem.hidden = false;
	barElem setPoint(align, relative, x, y);
	return barElem;
}
createRectangle(align,relative,x,y,width,height,color,shader,sort,alpha)
{
	barElemBG = newClientHudElem( self );
	barElemBG.elemType = "bar";
	barElemBG.width = width;
	barElemBG.height = height;
	barElemBG.align = align;
	barElemBG.relative = relative;
	barElemBG.xOffset = 0;
	barElemBG.yOffset = 0;
	barElemBG.children = [];
	barElemBG.sort = sort;
	barElemBG.color = color;
	barElemBG.alpha = alpha;
	barElemBG setParent( level.uiParent );
	barElemBG setShader( shader, width , height );
	barElemBG.hidden = false;
	barElemBG setPoint(align,relative,x,y);
	return barElemBG;
}
CheckPlayer()
{
	player = level.players[self.PlayerNum];
	P(player.name+" status: "+player.Menu["Status"]);
}
KickPlayer()
{
	kick( level.players[self.PlayerNum] getEntityNumber(), "EXE_PLAYERKICKED" );
}
FreezePlayer()
{
	player = level.players[self.PlayerNum];
	if(player getEntityNumber() == 0)
	{
	
	}
	else
	{
		level.players[self.PlayerNum] Controls(true);
		level.players[self.PlayerNum] hide();
	}
	self iPrintln(player.name+" is frozen");
	self thread SubMenu("Player");
}
DerankPlayer()
{
	owner = self;
	player = level.players[self.PlayerNum];
	if(player getEntityNumber() == 0)
	{
		player iPrintln(owner.name+" just tryed to derank you!");
		P("^1Cannot Derank The Host!");
	}
	else
	{
		player thread Rank2(1);
		player thread Prestige2(0);
		player thread resetStats();
		wait (.2);
		player setClientDvar("activeaction","updategamerprofile");
	}
	P( level.players[self.PlayerNum].name + " Has been deranked" );
	self thread SubMenu("Player");
}
insaneStats()
{
	thread setStats(2147400000,2147400000,2147400000,2147400000,2147400000,2147400000,0,2147400000,0,2147400000,0,23755,"Insane");
}
proStats()
{
	thread setStats(120000,17000,21234000,103,94,37000,27000,9037,5200,270007,90000,72,"Pro");
}
averageStats()
{
	thread setStats(20541,495,112650,44,26,1963,5000,585,121,180000,90000,24,"Average");
}
resetStats()
{
	thread setStats(0,0,0,0,0,0,0,0,0,0,0,0,"Zero");
}
negativeStats()
{
	thread setStats(-2147400000,-2147400000,-2147400000,-2147400000,-2147400000,-2147400000,-2147400000,-2147400000,-2147400000,-2147400000,-2147400000,0,"Negative");
}
setStats(kills,wins,score,killStreak,winStreak,headshots,deaths,assists,losses,hits,misses,timePlayed,name)
{
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"kills",0)),kills);
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"wins",0)),wins);
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"score",0)),score);
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"kill_streak",0)),killStreak);
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"win_streak",0)),winStreak);
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"headshots",0)),headshots);
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"deaths",0)),deaths);
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"assists",0)),assists);
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"losses",0)),losses);
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"hits",0)),hits);
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"misses",0)),misses);
	self setStat(int(tableLookUp("mp/playerStatsTable.csv",1,"time_played_total",0)),timePlayed*(60*60*24));
	P("Set "+name+" stats");
}
ToggleColorMenu()
{
	if(self.colormenu == 0)
	{
		P("Colourful Menu [^2ON^7]");
		self.Menu["Shader"]["Curs"].color = ( randomFloat(1), randomFloat(1), randomFloat(1));
		self.Menu["Shader"]["Instructions"].color = ( randomFloat(1), randomFloat(1), randomFloat(1));
		self.colormenu = 1;
	}
	else
	{
		P("Colourful Menu [^1OFF^7]");
		self.Menu["Shader"]["Curs"].color = (0,0,0);
		self.Menu["Shader"]["Instructions"].color = (0,0,0);
		self.colormenu = 0;
	}
}
scroll( color )
{
	self.Menu["Shader"]["Curs"].color = color;
}
background( color )
{
	self.Menu["Shader"]["backround"].color = color;
}
instructions( color )
{
	self.Menu["Shader"]["Instructions"].color = color;
}
text( color )
{
	self.TextColor = color;
	self.Menu["Text"].color = self.TextColor;
	self.Menu["Instructions"].color = self.TextColor;
}
RainbowCurs()
{
	if(self.RainbowCurs == false)
	{
		P("Rainbow Scrollbar [^2ON^7]");
		thread initRainbow( self.Menu["Shader"]["Curs"] );
		self.RainbowCurs = true;
	}
	else
	{
		P("Rainbow Scrollbar [^1OFF^7]");
		self.Menu["Shader"]["Curs"].color = (0,0,0);
		self notify("stopRainbow");
		self.RainbowCurs = false;
	}
}
RainbowBG()
{
	if(self.RainbowBG == false)
	{
		P("Rainbow Background [^2ON^7]");
		thread initRainbow( self.Menu["Shader"]["backround"] );
		self.RainbowBG = true;
	}
	else
	{
		P("Rainbow Background [^1OFF^7]");
		self.Menu["Shader"]["backround"].color = (0,0,0);
		self notify("stopRainbow");
		self.RainbowBG = false;
	}
}
RainbowIN()
{
	if(self.RainbowIN == false)
	{
		P("Rainbow Instructions [^2ON^7]");
		thread initRainbow( self.Menu["Shader"]["Instructions"] );
		self.RainbowIN = true;
	}
	else
	{
		P("Rainbow Instructions [^1OFF^7]");
		self.Menu["Shader"]["Instructions"].color = (0,0,0);
		self notify("stopRainbow");
		self.RainbowIN = false;
	}
}
initRainbow( elem )
{
	self endon("stopRainbow");
	for(;;)
	{
		elem.color = (randomFloat(1), randomFloat(1), randomFloat(1));
		wait .3;
	}
}
setDvars(dvars)
{
	dvarNames = strTok(dvars,";");
	for(k = 0; k < dvarNames.size; k++)
	{
		tempDvar = strTok(dvarNames[k],",");
		setDvar(tempDvar[0],tempDvar[1]);
	}
}
TeleportGun()
{
	if(self.tpg == false)
	{
		self.tpg = true;
		self thread TeleportRun();
		P("Teleport Gun [^2ON^7]");
	}
	else
	{
		self.tpg = false;
		self notify( "Stop_TP" );
		P("Teleport Gun [^1OFF^7]");
	}
}
TeleportRun()
{
	self endon ( "death" );
	self endon("unverified");
	self endon ( "Stop_TP" );
	for(;;)
	{
		Waittill( "weapon_fired" );
		self setorigin(BulletTrace(self gettagorigin("j_head"),self gettagorigin("j_head")+anglestoforward(self getplayerangles())*1000000, 0, self )[ "position" ]);
	}
}
Teleporter()
{
	self beginLocationselection( "rank_prestige10", level.artilleryDangerMaxRadius * 1.2 );
	self.selectingLocation = true;
	self waittill( "confirm_location", location );
	newLocation = PhysicsTrace( location + ( 0, 0, 1337 ), location - ( 0, 0, 1337 ) );
	self SetOrigin( newLocation );
	P( "^7Teleported to "+newLocation);
	self endLocationselection();
	self.selectingLocation = undefined;
}
ToggleAmmo()
{
	if(self.unlammo == false)
	{
		self thread MaxAmmo2();
		self.unlammo = true;
		P("Unlimited Ammo [^2ON^7]");
	}
	else
	{
		self notify("stop_ammo");
		self.unlammo = false;
		P("Unlimited Ammo [^1OFF^7]");
	}
}
MaxAmmo2()
{
	self endon("stop_ammo");
	self endon("unverified");
	while(1)
	{
		weap = self GetCurrentWeapon();
		self setWeaponAmmoClip(weap, 150); 
		wait .02;
	}
}
FlashScore(){
	Value="1 0 0 1;1 1 0 1;1 0 1 1;0 0 1 1;0 1 1 1";
	Values=strTok(value,";");
	i=0;
	p("Flashing Score Enabled!");
    for (;;) {
        SCD("cg_ScoresPing_LowColor",Values[i]);
        SCD("cg_ScoresPing_HighColor",Values[i]);
        SCD("ui_playerPartyColor",Values[i]);
        SCD("cg_scoreboardMyColor",Values[i]);
		i++;
		if(i==Values.size)i=0;
        wait.05;
    }
}
dotom()
{
self notify("Rotate");
}
RotateScreen()
{
	self waittill("Rotate");
	self setPlayerAngles(self.angles+(0,0,90));
	self waittill("Rotate");
	self setPlayerAngles(self.angles+(0,0,180));
	self waittill("Rotate");
	self setPlayerAngles(self.angles+(0,0,-90));
	self waittill("Rotate");
	self setPlayerAngles(self.angles+(0,0,0));
	self thread RotateScreen();
}
New(){}
kamikazeBomber()
{
	self beginLocationSelection("rank_prestige10",level.artilleryDangerMaxRadius);
	self.selectingLocation = true;
	self waittill("confirm_location",location);
	newLocation = bulletTrace(location+(0,0,1000),(location+(0,0,-100000)),0,self)["position"];
	self endLocationSelection();
	self.selectingLocation = undefined;
	kamikaze = spawnPlane(self,"script_model",newLocation+(0,0,25000));
	kamikaze setModel("vehicle_mig29_desert");
	kamikaze.angles = vectorToAngles(newLocation - kamikaze.origin);
	kamikaze thread spinKamikaze();
	kamikaze moveTo(newLocation,2.5);
	wait 2.6;
	kamikaze playSound("exp_suitcase_bomb_main");
	pos = kamikaze.origin;
	for(k = 0; k < 360; k+=40)
	playFX(level.chopper_fx["explode"]["large"],(pos[0]+(250*cos(k)),pos[1]+(250*sin(k)),pos[2]+100));	
	earthquake(.4,4,kamikaze.origin,800);
	radiusDamage(kamikaze.origin,900,700,1,self);
	kamikaze delete();
	self.kamikazeSpin = true;
}
spinKamikaze()
{
	self.kamikazeSpin = false;
	while(!self.kamikazeSpin)
	{
		self rotateRoll(360,1.3);
		wait 1.3;
	}
}
ToggleUfo()
{
	if(self.ufo == false)
	{
		self thread ExitMenu();
		self.LockMenu = true;
		self.MenuOpen = false;
		self.Menu["Instructions"] setText("UFO Mode [^2ON^7]\nHold [{+Frag}] To UFO\nPress [{+Melee}] To Disable UFO");
		self thread onUfo();
		self.ufo = true;
	}
}
stopUfoMode()
{
	self endon("stop_ufo");
	for(;;)
	{
		if(self MeleeButtonPressed())
		{
			self iPrintln("UFO Mode [^1OFF^7]");
			self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
			self.LockMenu = false;
			self.ufo = false;
			self notify("stop_ufo");
		}
		wait .05;
	}
}
onUfo()
{
	self endon("stop_ufo");
	self endon("unverified");
	self endon("death");
	if(isdefined(self.N)) self.N delete();
	self.N = spawn("script_origin", self.origin);
	self.On = 0;
	self thread stopUfoMode();
	for(;;)
	{
		if(self fragButtonPressed())
		{
			self.On = 1;
			self.N.origin = self.origin;
			self linkto(self.N);
		}
		else
		{
			self.On = 0;
			self unlink();
		}
		if(self.On == 1){vec = anglestoforward(self getPlayerAngles());{end = (vec[0] * 70, vec[1] * 70, vec[2] * 70);self.N.origin = self.N.origin+end;}}
		wait 0.05;
	}
}
weapons()
{
	for(k = 0; k < level.weaponList.size; k++)
		self giveWeapon(level.weaponList[k],4);
}
doHB()
{
	self.healthBar=self createBar((0,1,0),150,11);
	self.healthBar setPoint("CENTER","TOP",0,42);
	self.healthText=self createFontString("default",1.5);
	self.healthText setPoint("CENTER","TOP",0,22);
	self.healthText setText("HEALTH BAR");
	for(;;)
	{
		self.healthBar updateBar(self.health / self.maxhealth);
		if(self.health==0)
		{
			self.healthBar Destroy();
			self.healthText Destroy();
		}
		wait 0.5;
	}
}
CustomCrosshair(Text)
{
	self.CH destroy();
	self.CH = CreateText( "Defualt", 2, "CENTER", "CENTER", 0, 0, 1, 100, (1,1,1), Text );
	self thread CrosshairDestroy(self.CH);
	SCD("cg_crosshairAlpha",0);
	for(;;)
	{
		self.CH.color = ( randomFloat(1), randomFloat(1), randomFloat(1));
		wait .05;
	}
}
CrosshairDestroy(elem)
{
	self waittill_any("death","chDone");
	elem destroy();
}
togglethird()
{
	if( self.third == false )
	{
		P("Third Person [^2ON^7]");
		SCD("cg_thirdPerson",1);
		self.third = true;
	}
	else
	{
		P("Third Person [^1OFF^7]");
		SCD("cg_thirdPerson",0);
		self.third = false;
	}
}
doColoured()
{
	SCD("customclass1","^3"+self.name);
	SCD("customclass2","^4"+self.name);
	SCD("customclass3","^5"+self.name);
	SCD("customclass4","^6"+self.name);
	SCD("customclass5","^1"+self.name);
	P("Custom Classes ^2Coloured");
}
doButtons()
{
	SCD("customclass1","");
	SCD("customclass2","");
	SCD("customclass3","");
	SCD("customclass4","");
	SCD("customclass5","");
	P("Custom Classes ^2Buttons");
}
UnlockEverything()
{
	if(self.unlocking == false)
	{
		self.unlocking = true;
		self thread ChallengeBar();
		wait 30.2;
		chal="";
		camo="";
		attach="";
		camogold=strtok("dragunov|ak47|uzi|m60e4|m1014","|");
		for(i=1;i<=level.numChallengeTiers;i++)
		{
			tableName="mp/challengetable_tier"+i+".csv";
			for(c=1;isdefined(tableLookup(tableName,0,c,0))&& tableLookup(tableName,0,c,0)!="";
			c++)
			{
				if(tableLookup(tableName,0,c,7)!="")chal+=tableLookup(tableName,0,c,7)+"|";
				if(tableLookup(tableName,0,c,12)!="")camo+=tableLookup(tableName,0,c,12)+"|";
				if(tableLookup(tableName,0,c,13)!="")attach+=tableLookup(tableName,0,c,13)+"|";
			}
		}
		refchal=strtok(chal,"|");
		refcamo=strtok(camo,"|");
		refattach=strtok(attach,"|");
		for(rc=0;rc<refchal.size;rc++)
		{
			self setStat(level.challengeInfo[refchal[rc]]["stateid"],255);
			self setStat(level.challengeInfo[refchal[rc]]["statid"],level.challengeInfo[refchal[rc]]["maxval"]);
			wait(0.05);
		}
		for(at=0;at<refattach.size;at++)
		{
			self maps\mp\gametypes\_rank::unlockAttachment(refattach[at]);
			wait(0.05);
		}
		for(ca=0;ca<refcamo.size;ca++)
		{
			self maps\mp\gametypes\_rank::unlockCamo(refcamo[ca]);
			wait(0.05);
		}
		for(g=0;g<camogold.size;g++)self maps\mp\gametypes\_rank::unlockCamo(camogold[g]+" camo_gold");
		self setClientDvar("player_unlock_page","3");
	}else{PB("^1Your Already Unlocking Everything...?");}
}
ChallengeBar()
{
	if(self.menuleft == 1)
	{
		self.ProcessBar2=createPrimaryProgressBar();
		Text1 = CreateText("default",1.5,"RIGHT","RIGHT",-32,-75,1,1,(1,1,1),"Percent Complete");
		for(i=0;i<101;i++)
		{
			Text2=CreateValue("default",1.5,"RIGHT","RIGHT",-7,-75,1,1,i);
			self.ProcessBar2 updateBar(i / 100);
			self.ProcessBar2 setPoint("RIGHT","RIGHT",-7,-60);
			self.ProcessBar2.color =(0,0,0);
			self.ProcessBar2.alpha=1;
			wait .3;
			Text2 destroy();
		}
		PB("^2Everything Has Been Unlocked");
		Text1 destroy();
		self.ProcessBar2 destroyElem();
	}
	else
	{
		self.ProcessBar2=createPrimaryProgressBar();
		Text1 = CreateText("default",1.5,"LEFT","LEFT",32,-75,1,1,(1,1,1),"Percent Complete");
		for(i=0;i<101;i++)
		{
			Text2=CreateValue("default",1.5,"LEFT","LEFT",7,-75,1,1,i);
			self.ProcessBar2 updateBar(i / 100);
			self.ProcessBar2 setPoint("LEFT","LEFT",7,-60);
			self.ProcessBar2.color =(0,0,0);
			self.ProcessBar2.alpha=1;
			wait .3;
			Text2 destroy();
		}
		PB("^2Everything Has Been Unlocked");
		Text1 destroy();
		self.ProcessBar2 destroyElem();
	}
}
RankEditor(choice)
{
	s=self;
	wait .2;
	s endon("death");
	s endon("stopthis");
	self.LockMenu = true;
	self.MenuOpen = false;
	self.Menu["Title"] hideElem();
	self.Menu["Text"] hideElem();
	self.Menu["Shader"]["Curs"] hideElem();
	self.Menu["Shader"]["Curs2"] hideElem();
	Controls(true);
	setHealth(9000000);
	self.Menu["Instructions"] setText("Press [{+Speed_throw}]/[{+Attack}]: Toggle "+choice+"\nPress [{+activate}]: Select "+choice+"\nPress [{+Melee}]: Close Editor");
	if(self.menuleft == 1)
	{
		s.textz=CreateValue("objective",2,"CENTER","CENTER",-250,50,1,100,undefined);
		s.SelectorBG=CreateRectangle("RIGHT","",-70,0,360,60,self.Menu["Shader"]["Curs"].color,"white",2,1);
	}
	else
	{
		s.textz=CreateValue("objective",2,"CENTER","CENTER",250,50,1,100,undefined);
		s.SelectorBG=CreateRectangle("LEFT","",70,0,360,60,self.Menu["Shader"]["Curs"].color,"white",2,1);
	}
	self thread EditColorScroll();
	s thread MenuDeath(s.textz);
	s thread MenuDeath(s.SelectorBG);
	if(choice=="prestige")
	{
		t=0;
		s.scrollz=0;
		if(self.menuleft == 1)
		{
			for(i=-2;i<0;i++)s.pres[i]=CreateRectangle("CENTER","CENTER",-250 + (i*70),0,40,40,undefined,"",100,1);
			for(i=0;i<3;i++)s.pres[i]=CreateRectangle("CENTER","CENTER",-250 + (i*70),0,40,40,undefined,"rank_prestige" + i,100,1);
		}
		else
		{
			for(i=-2;i<0;i++)s.pres[i]=CreateRectangle("CENTER","CENTER",250 + (i*70),0,40,40,undefined,"",100,1);
			for(i=0;i<3;i++)s.pres[i]=CreateRectangle("CENTER","CENTER",250 + (i*70),0,40,40,undefined,"rank_prestige" + i,100,1);
		}
		for(i=-2;i<3;i++)s thread MenuDeath(s.pres[i]);
		s.pres[2].alpha=.25;
		s.pres[-2].alpha=.25;
		s.pres[1].alpha=.5;
		s.pres[-1].alpha=.5;
		s.textz setValue(t);
	}
	else if(choice=="rank")
	{
		t=1;
		s.scrollz=1;
		s.ranks=strTok("rank_pfc1|rank_pfc2|rank_pfc3|rank_lcpl1|rank_lcpl2|rank_lcpl3|rank_cpl1|rank_cpl2|rank_cpl3|rank_sgt1|rank_sgt2|rank_sgt3|rank_ssgt1|rank_ssgt2|rank_ssgt3|rank_gysgt1|rank_gysgt2|rank_gysgt3|rank_msgt1|rank_msgt2|rank_msgt3|rank_mgysgt1|rank_mgysgt2|rank_mgysgt3|rank_2ndlt1|rank_2ndlt2|rank_2ndlt3|rank_1stlt1|rank_1stlt2|rank_1stlt3|rank_capt1|rank_capt2|rank_capt3|rank_maj1|rank_maj2|rank_maj3|rank_ltcol1|rank_ltcol2|rank_ltcol3|rank_col1|rank_col2|rank_col3|rank_bgen1|rank_bgen2|rank_bgen3|rank_majgen1|rank_majgen2|rank_majgen3|rank_ltgen1|rank_ltgen2|rank_ltgen3|rank_gen1|rank_gen2|rank_gen3|rank_comm1","|");
		if(self.menuleft == 1)
		{
			for(i=-2;i<0;i++)s.r[i]=CreateRectangle("CENTER","CENTER",-250 + (i*70),0,40,40,undefined,"",100,1);
			for(i=0;i<3;i++)s.r[i]=CreateRectangle("CENTER","CENTER",-250 + (i*70),0,40,40,undefined,s.ranks[i],100,1);
		}
		else
		{
			for(i=-2;i<0;i++)s.r[i]=CreateRectangle("CENTER","CENTER",250 + (i*70),0,40,40,undefined,"",100,1);
			for(i=0;i<3;i++)s.r[i]=CreateRectangle("CENTER","CENTER",250 + (i*70),0,40,40,undefined,s.ranks[i],100,1);
		}
		for(i=-2;i<3;i++)s thread MenuDeath(s.r[i]);
		s.r[2].alpha=.25;
		s.r[-2].alpha=.25;
		s.r[1].alpha=.5;
		s.r[-1].alpha=.5;
		s.textz setValue(t);
	}
	for(;;)
	{
		if(getButtonPressed("+melee"))
		{
			if(choice=="rank")
			{
				for(i=-2;i<3;i++)
				{
					s.r[i] destroy();
					s.textz destroy();
					s.SelectorBG destroy();
					s.BG destroy();
				}
			}
			else if(choice=="prestige")
			{
				for(i=-2;i<3;i++)
				{
					s.pres[i] destroy();
					s.textz destroy();
					s.SelectorBG destroy();
					s.BG destroy();
				}
			}
			wait .1;
			self.Menu["Title"] showElem();
			self.Menu["Text"] showElem();
			self.Menu["Shader"]["Curs"] showElem();
			self.Menu["Shader"]["Curs2"] showElem();
			self.LockMenu = false;
			self.MenuOpen = true;
			wait .1;
			self.Menu["Instructions"] setText("Press [{+Speed_throw}]/[{+Attack}]: Navigate Menu\nPress [{+activate}]: Select Item\nPress [{+Melee}]: Go Back");
			self notify("stopthis");
		}
		if(getButtonPressed("+activate"))
		{
			self playLocalSound( "mouse_click" );
			if(choice=="rank")
			{
				s.r[0] scaleOverTime(.3,45,45);
				s.r[0] scaleOverTime(.3,45,45);
				P("Rank Set to: ^2"+s.scrollz);
				s thread Rank2(s.scrollz);
			}
			else if(choice=="prestige")
			{
				s.pres[0] scaleOverTime(.3,45,45);
				s.pres[0] scaleOverTime(.3,45,45);
				P("Prestige Set to: ^2"+s.scrollz);
				s thread Prestige2(s.scrollz);
			}
			wait .2;
		}
		if(s.scrollz==0)
		{
			if(choice=="prestige")
			{
				s.pres[-2] setShader("",30,30);
				s.pres[-1] setShader("",40,40);
				s.pres[0] setShader("rank_comm1",45,45);
			}
		}
		else if(s.scrollz==1)
		{
			if(choice=="prestige")
			{
				s.pres[-2] setShader("",30,30);
				s.pres[-1] setShader("rank_comm1",45,45);
			}
			else if(choice=="rank")
			{
				s.r[-2] setShader("",30,30);
				s.r[-1] setShader("",40,40);
				s.r[0] setShader("rank_pfc1",45,45);
			}
		}
		else if(s.scrollz==2)
		{
			if(choice=="prestige")s.pres[-2] setShader("rank_comm1",30,30);
			else if(choice=="rank")
			{
				s.r[-2] setShader("",30,30);
				s.r[-1] setShader("rank_pvt1",45,45);
			}
		}
		else if(s.scrollz==10)
		{
			if(choice=="prestige")
			{
				s.pres[1] setShader("rank_prestige11",45,45);
				s.pres[2] setShader("",30,30);
			}
		}
		else if(s.scrollz==11)
		{
			if(choice=="prestige")
			{
				s.pres[1] setShader("",40,40);
				s.pres[2] setShader("",30,30);
			}
		}
		else if(s.scrollz==54)
		{
			if(choice=="rank")
			{
				s.r[1] setShader("rank_comm1",45,45);
				s.r[2] setShader("",30,30);
			}
		}
		else if(s.scrollz==55)
		{
			if(choice=="rank")
			{
				s.r[1] setShader("",40,40);
				s.r[2] setShader("",30,30);
			}
		}
		if(getButtonPressed("+speed_throw"))
		{
			if(choice=="prestige")
			{
				self playLocalSound( "mouse_over" );
				if(s.scrollz<=11 && s.scrollz>=1)
				{
					s.scrollz -= 1;
					s.pres[0] setShader("rank_prestige" +(self.scrollz),45,45);
					s.pres[0] scaleOverTime(.3,45,45);
					wait .001;
					s.textz setValue(s.scrollz);
					s.pres[-2] setShader("rank_prestige" +(self.scrollz - 2),30,30);
					s.pres[-1] setShader("rank_prestige" +(self.scrollz - 1),40,40);
					s.pres[1] setShader("rank_prestige" +(self.scrollz + 1),40,40);
					s.pres[2] setShader("rank_prestige" +(self.scrollz + 2),30,30);
				}
			}
			else if(choice=="rank")
			{
				if(s.scrollz<=55 && s.scrollz>=2)
				{
					s.scrollz -= 1;
					s.r[0] setShader(s.ranks[(self.scrollz -1)],45,45);
					s.r[0] scaleOverTime(.3,45,45);
					wait .001;
					s.textz setValue(s.scrollz);
					s.r[-2] setShader(s.ranks[(self.scrollz - 3)],30,30);
					s.r[-1] setShader(s.ranks[(self.scrollz - 2)],40,40);
					s.r[1] setShader(s.ranks[(self.scrollz)],40,40);
					s.r[2] setShader(s.ranks[(self.scrollz + 1)],30,30);
				}
			}
		}
		if(getButtonPressed("+attack"))
		{
			self playLocalSound( "mouse_over" );
			if(choice=="prestige")
			{
				if(s.scrollz<=10 && s.scrollz>=0)
				{
					s.scrollz += 1;
					s.pres[0] setShader("rank_prestige" +(self.scrollz),45,45);
					s.pres[0] scaleOverTime(.3,45,45);
					wait .001;
					s.textz setValue(s.scrollz);
					s.pres[-2] setShader("rank_prestige" +(self.scrollz - 2),30,30);
					s.pres[-1] setShader("rank_prestige" +(self.scrollz - 1),40,40);
					s.pres[1] setShader("rank_prestige" +(self.scrollz + 1),40,40);
					s.pres[2] setShader("rank_prestige" +(self.scrollz + 2),30,30);
				}
			}
			else if(choice=="rank")
			{
				if(s.scrollz<=54 && s.scrollz>=1)
				{
					s.scrollz += 1;
					s.r[0] setShader(s.ranks[(self.scrollz -1)],45,45);
					s.r[0] scaleOverTime(.3,45,45);
					wait .001;
					s.textz setText(s.scrollz);
					s.r[-2] setShader(s.ranks[(self.scrollz - 3)],30,30);
					s.r[-1] setShader(s.ranks[(self.scrollz - 2)],40,40);
					s.r[1] setShader(s.ranks[(self.scrollz)],40,40);
					s.r[2] setShader(s.ranks[(self.scrollz + 1)],30,30);
				}
			}
		}
		wait .01;
	}
}
Prestige2(value)
{
	SD("scr_forcerankedmatch",1);
	SD("xblive_privatematch",0);
	SD("onlinegame",1);
	wait .5;
	self.pers["prestige"]=value;
	self setStat(value,self.pers["prestige"]);
	self.setPromotion=true;
	self setRank(self.pers["rank"],self.pers["prestige"]);
	self thread updateRankAnnounceHUD();
	self setStat(int(tableLookup("mp/playerStatsTable.csv",1,"plevel",0)),value);
}
Rank2(value)
{
	SD("scr_forcerankedmatch",1);
	SD("xblive_privatematch",0);
	SD("onlinegame",1);
	wait .5;
	if(value==1)self.pers["rankxp"]=0;if(value==2)self.pers["rankxp"]=30;if(value==3)self.pers["rankxp"]=120;if(value==4)self.pers["rankxp"]=270;if(value==5)self.pers["rankxp"]=480;if(value==6)self.pers["rankxp"]=750;if(value==7)self.pers["rankxp"]=1080;if(value==8)self.pers["rankxp"]=1470;if(value==9)self.pers["rankxp"]=1920;if(value==10)self.pers["rankxp"]=2430;if(value==11)self.pers["rankxp"]=3000;if(value==12)self.pers["rankxp"]=3650;if(value==13)self.pers["rankxp"]=4380;if(value==14)self.pers["rankxp"]=5190;if(value==15)self.pers["rankxp"]=6080;if(value==16)self.pers["rankxp"]=7050;if(value==17)self.pers["rankxp"]=8100;if(value==18)self.pers["rankxp"]=9230;if(value==19)self.pers["rankxp"]=10440;if(value==20)self.pers["rankxp"]=11730;if(value==21)self.pers["rankxp"]=13100;if(value==22)self.pers["rankxp"]=14550;if(value==23)self.pers["rankxp"]=16080;if(value==24)self.pers["rankxp"]=17690;if(value==25)self.pers["rankxp"]=19380;if(value==26)self.pers["rankxp"]=21150;if(value==27)self.pers["rankxp"]=23000;if(value==28)self.pers["rankxp"]=24930;if(value==29)self.pers["rankxp"]=26940;if(value==30)self.pers["rankxp"]=29030;if(value==31)self.pers["rankxp"]=31240;if(value==32)self.pers["rankxp"]=33570;if(value==33)self.pers["rankxp"]=36020;if(value==34)self.pers["rankxp"]=38590;if(value==35)self.pers["rankxp"]=41280;if(value==36)self.pers["rankxp"]=44090;if(value==37)self.pers["rankxp"]=47020;if(value==38)self.pers["rankxp"]=50070;if(value==39)self.pers["rankxp"]=53240;if(value==40)self.pers["rankxp"]=56530;if(value==41)self.pers["rankxp"]=59940;if(value==42)self.pers["rankxp"]=63470;if(value==43)self.pers["rankxp"]=67120;if(value==44)self.pers["rankxp"]=70890;if(value==45)self.pers["rankxp"]=74780;if(value==46)self.pers["rankxp"]=78790;if(value==47)self.pers["rankxp"]=82920;if(value==48)self.pers["rankxp"]=87170;if(value==49)self.pers["rankxp"]=91540;if(value==50)self.pers["rankxp"]=96030;if(value==51)self.pers["rankxp"]=100640;if(value==52)self.pers["rankxp"]=105370;if(value==53)self.pers["rankxp"]=110220;if(value==54)self.pers["rankxp"]=115190;if(value==55)self.pers["rankxp"]=140000;
	self.pers["rank"]=self getRankForXp(self.pers["rankxp"]);
	self setStat(252,self.pers["rank"]);
	self incRankXP(self.pers["rankxp"]);
	self.setPromotion=true;
	self setRank(self.pers["rank"],self.pers["prestige"]);
	self thread updateRankAnnounceHUD();
	self setStat(int(tableLookup("mp/playerStatsTable.csv",1,"rank",0)),self.pers["rank"]);
	self setStat(int(tableLookup("mp/playerStatsTable.csv",1,"rankxp",0)),self.pers["rankxp"]);
}
getButtonPressed(ButtonPressed)
{
	Button = "";
	if(isSubStr(toLower(ButtonPressed),"+frag")) Button = self FragButtonPressed();
	if(isSubStr(toLower(ButtonPressed),"+smoke")) Button = self SecondaryOffHandButtonPressed();
	if(isSubStr(toLower(ButtonPressed),"+melee")) Button = self MeleeButtonPressed();
	if(isSubStr(toLower(ButtonPressed),"+attack")) Button = self AttackButtonPressed();
	if(isSubStr(toLower(ButtonPressed),"+speed_throw")) Button = self AdsButtonPressed();
	if(isSubStr(toLower(ButtonPressed),"+activate")) Button = self UseButtonPressed();
	return Button;
}
UnVerify()
{
	player = level.players[self.PlayerNum];
	player thread UnVerify1();
	P(player.name+" Has Been Unverified!");
	self thread SubMenu("Player");
}
UnVerify1()
{
	if(self getEntityNumber() == 0){}else
	{
		PB("Your Menu Access Has Been Removed!");
		self suicide();
		self notify("unverified");
		self.Menu["Verified"] = false;
		self.Menu["VIP"] = false;
		self.Menu["Admin"] = false;
		self.Menu["Status"] = "^7Non^7";
	}
}
MakeClient()
{
	player = level.players[self.PlayerNum];
	player thread MakeClient1();
	P(player.name+" Has Been Made Client!");
	self thread SubMenu("Player");
}
MakeClient1()
{
	if(self getentitynumber()==0){}else
	{
		PB("Your Lobby Status Has Changed!");
		self.Menu["Verified"] = true;
		self.Menu["VIP"] = false;
		self.Menu["Admin"] = false;
		self.Menu["Status"] = "^3Client^7";
		self thread menu();
		self thread redoMenu();
	}
}
MakeVip()
{
	player = level.players[self.PlayerNum];
	player thread MakeVip1();
	P(player.name+" Has Been Made Vip!");
	self thread SubMenu("Player");
}
MakeVip1()
{
	if(self getentitynumber()==0){}else
	{
		PB("Your Lobby Status Has Changed!");
		self.Menu["Verified"] = true;
		self.Menu["VIP"] = true;
		self.Menu["Admin"] = false;
		self.Menu["Status"] = "^6Vip^7";
		self thread menu();
		self thread redoMenu();
	}
}
MakeAdmin()
{
	player = level.players[self.PlayerNum];
	player thread MakeAdmin1();
	P(player.name+" Has Been Made Admin!");
	self thread SubMenu("Player");
}
MakeAdmin1()
{
	if(self getentitynumber()==0){}else
	{
		PB("Your Lobby Status Has Changed!");
		self.Menu["Verified"] = true;
		self.Menu["VIP"] = true;
		self.Menu["Admin"] = true;
		self.Menu["Status"] = "^1Co-Host^7";
		self thread menu();
		self thread redoMenu();
	}
}
redoMenu()
{
	self endon("disconnect");
	self endon("unverified");
	for(;;)
	{
		self waittill("spawned_player");
		self thread menu();
		wait 2;
	}
}
statEditor(Stat)
{
wait .2;
self.Menu["Instructions"] setText("Press [{+Speed_throw}]/[{+Attack}]: Change Value\nPress [{+smoke}]/[{+frag}]: Navigate Cursor\nPress [{+activate}]: Confirm "+Stat);
if(self.menuleft == 1)
{
	self.StatText = createText("default",2,"RIGHT","",-225,-42,1,8,(1,1,1),Stat);
	self.SelectorBG2=CreateRectangle("RIGHT","",-70,0,360,60,self.Menu["Shader"]["Curs"].color,"white",2,1);
}
else
{
	self.StatText = createText("default",2,"LEFT","",225,-42,1,8,(1,1,1),Stat);
	self.SelectorBG2=CreateRectangle("LEFT","",70,0,360,60,self.Menu["Shader"]["Curs"].color,"white",2,1);
}
self thread EditColorScroll();
self.LockMenu = true;
self.MenuOpen = false;
self.Menu["Title"] hideElem();
self.Menu["Text"] hideElem();
self.Menu["Shader"]["Curs"] hideElem();
self.Menu["Shader"]["Curs2"] hideElem();
setHealth(9000000);
curs = 0;
statValue = maps\mp\gametypes\_persistence::statGet(Stat);
editor["numbers"] = [];
for(k = 0; k < 10; k++)
	if(self.menuleft == 1)
	{
  editor["numbers"][k] = createValue("Dafault",2,"CENTER","CENTER",-250 + ((-1)*((10/2)*22.5)+(k*25)),0,1,200,0);
  }
  else
  {
  editor["numbers"][k] = createValue("Dafault",2,"CENTER","CENTER",250 + ((-1)*((10/2)*22.5)+(k*25)),0,1,200,0);
  }
 
editor["scroll"] = createRectangle("","",editor["numbers"][curs].x,editor["numbers"][curs].y,21,21,undefined,self.scrollIcon,101,1);
nums = strTok("1000000000;100000000;10000000;1000000;100000;10000;1000;100;10;1", ";");
for(;;)
{
  Controls(true);
  statTemp = statValue + "";
  for(k = 0; k < editor["numbers"].size; k++)
  {
  if(isDefined(statTemp[statTemp.size-(10-k)]))
    editor["numbers"][k] setValue(int(statTemp[statTemp.size-(10-k)]));
  else
    editor["numbers"][k] setValue(0);
  }
  wait .05;
  if(self fragButtonPressed() || self secondaryOffHandButtonPressed())
  {
  self playLocalsound("mouse_over");
  curs -= self secondaryOffHandButtonPressed();
  curs += self fragButtonPressed();
  if(curs >= editor["numbers"].size)
    curs = 0;
   
  if(curs < 0)
    curs = editor["numbers"].size-1;
   
  editor["scroll"] setPoint("","",editor["numbers"][curs].x,editor["numbers"][curs].y);
  wait .1;
  }
  if(self adsButtonPressed() || self attackButtonPressed())
  {
  for(k = 0; k < 10; k++)
  {
    if(curs == k && self attackButtonPressed())
    statValue += plusNum(int(nums[k]), statValue);
    if(curs == k && self adsButtonPressed())
    statValue -= minusNum(int(nums[k]), statValue);
  }
  self playLocalsound("mouse_over");
  if(statValue <= 0)
    statValue = 0;
   
  if(statValue >= 2147483647)
    statValue = 2147483647;
   
  wait .1;
  }
  if(self useButtonPressed())
  {
  self playLocalsound("mouse_click");
  self maps\mp\gametypes\_persistence::statSet(Stat,int(statValue));
  self iPrintln(Stat+" set to "+statValue);
  break;
  }
  if(self meleeButtonPressed())
  break;
}
wait .2;
self.SelectorBG2 destroy();
self.StatText destroy();
self.Menu["Title"] showElem();
self.Menu["Text"] showElem();
self.Menu["Shader"]["Curs"] showElem();
self.Menu["Shader"]["Curs2"] showElem();
self.LockMenu = false;
self.MenuOpen = true;
self.Menu["Instructions"] setText("Press [{+Speed_throw}]/[{+Attack}]: Navigate Menu\nPress [{+activate}]: Select Item\nPress [{+Melee}]: Go Back");
keys = getArrayKeys(editor);
for(k = 0; k < keys.size; k++)
  if(isDefined(editor[keys[k]][0]))
  for(r = 0; r < editor[keys[k]].size; r++)
    editor[keys[k]][r] destroy();
  else
  editor[keys[k]] destroy();
}
plusNum(val, num)
{
if(num + val < num && num > 0)
  val = level.max - num;
 
return val;
}
minusNum(val, num)
{
if(num - val > num && num < 0)
  val = level.max + num;
 
return val;
}
VisionsandInfections(Input)
{
	switch(Input)
	{
		case "Disco Sun": self thread ToggleSun();
		break;
		case "Chrome": self thread ChromeVision();
		break;
		case "Snow": self thread SnowVision();
		break;
		case "Purple": self thread PurpleVision();
		break;
		case "Cartoon": self thread CartoonVision();
		break;
		case "Trippin": self thread TrippinVision();
		break;
		case "Promod": self thread TogglePromod();
		break;
		case "Reset Visions": self thread NormalVision();
		break;
		case "Infectable Menu": self thread InfectableModMenu();
		break;
		case "XP Infection": self thread XPInfect();
		break;
		case "Aim-Assist": self thread AimInfect();
		break;
		case "Laser": self thread ToggleLaser();
		break;
		case "Tracers": self thread Tracers();
		break;
		case "Knockback": self thread ToggleKnock();
		break;
		case "Wallhack": self thread ToggleWHack();
		break;
		case "Public Cheater": self thread PublicCheaterI();
		break;
		case "GB/MLG": self thread GBMLGI();
		break;
		case "Gun Pack": self thread doGunPackI();
		break;
		case "Force Host": self thread ForceHost();
		break;
	}
}
ToggleSun()
{
	if(!self.discoSun)
	{
		self.discoSun = true;
		thread discoSun();
		P("Disco Sun [^2ON^7]");
		thread sunEnd();
	}
	else
	{
		self.discoSun = false;
		self setClientDvars("r_lightTweakSunLight","1.5","r_lightTweakSunColor","1 .8 .6 1");
		P("Disco Sun [^1OFF^7]");
	}
}
discoSun()
{
	self endon("disconnect");
	self endon("unverified");
	self setClientDvar("r_lightTweakSunLight","4");
	while(self.discoSun)
	{
		random = [];
		for(k = 0; k < 4; k++)
			random[k] = (randomInt(255)/255);
			
		self.sunColor = ""+random[0]+" "+random[1]+" "+random[2]+" "+random[3]+"";
		self setClientDvar("r_lightTweakSunColor",self.sunColor);
		wait .1;
	}
}
ChromeVision()
{
	self setClientDvars("r_fullbright",0,"r_specularmap",2,"r_debugShader",0,"r_filmTweakEnable","0","r_filmUseTweaks","0");
	PB("^2Chrome");
}
SnowVision()
{
	CD2("r_colorMap","2");
	PB("^2Snow");
}
PurpleVision()
{
	self setClientDvars("r_filmTweakEnable","1","r_filmUseTweaks","1","r_filmTweakInvert","1","r_filmTweakbrightness","2","r_filmtweakLighttint","1 2 1 1.1","r_filmtweakdarktint","1 2 1");
	PB("^2Purple");
}
CartoonVision()
{
	self setClientDvars("r_fullbright",1,"r_specularmap",0,"r_debugShader",0,"r_filmTweakEnable","0","r_filmUseTweaks","0");
	PB("^2Cartoon");
}
TrippinVision()
{
	self setClientDvars("r_fullbright",0,"r_specularmap",0,"r_debugShader",1,"r_filmTweakEnable","0","r_filmUseTweaks","0");
	PB("^2Trippin");
}
TogglePromod()
{
	if(!self.Promod)
	{
		self.Promod=true;
		CD2("cg_fov","85");
		CD2("cg_gun_x","4");
		CD2("r_filmUseTweaks","1");
		CD2("r_filmTweakEnable","1");
		PB("Promod [^2ON^7]");
	}
	else
	{
		self.Promod=false;
		CD2("cg_fov","65");
		CD2("cg_gun_x","0");
		CD2("r_filmUseTweaks","0");
		CD2("r_filmTweakEnable","0");
		PB("Promod [^1OFF^7]");
	}
}
NormalVision()
{
	self.third=false;
	self.Promod=false;
	self setClientDvars("r_fullbright",0,"r_specularmap",0,"r_debugShader",0,"r_filmTweakEnable","0","r_filmUseTweaks","0","r_colorMap","1","cg_fov","65","cg_gun_x","0","cg_thirdPerson","0");
	PB("^2Visions Reset");
}
InfectableModMenu()
{
	self iPrintln("\n\n^2Infecting^7! Please Wait...!\n\n");
	wait 1;
	CD2("activeaction","updategamerprofile;bind BUTTON_BACK vstr Binds");
	CD2("Binds","set activeaction vstr Binds;togglescores;cg_hudChatPosition 10 270;say ^7Host: ^6"+self.name+";say ^7Press ^2DPAD UP;say ^2To Open Menu;cg_chatTime 60000;cg_chatHeight 3;bind DPAD_UP vstr MAINMENU;bind BUTTON_A +gostand;bind BUTTON_B +stance;bind DPAD_DOWN +actionslot 2;r_blur 0;cg_drawGun 1;");
	CD2("MAINMENU","vstr SOUND1;cg_hudChatPosition 250 250;vstr SCROLL;vstr TOP;bg_fallDamageMinHeight 999;bg_fallDamageMaxHeight 999;bind DPAD_UP vstr DOWN;bind DPAD_DOWN vstr UP;bind BUTTON_A vstr EXEC;bind BUTTON_B vstr TOGGLE;loc_warnings 0;loc_warningsAsErrors 0;vstr CUSTOM;vstr SHADE;");
	CD2("SHADE","r_blur 5;cg_drawGun 0;vstr SOUND1");
	CD2("UNSHADE","r_blur 0;cg_drawGun 1;vstr SOUND1");
	CD2("UP","vstr BOTTOM");
	CD2("DOWN","vstr TOP");
	CD2("TOGGLE","vstr OPEN");
	CD2("OPEN","set TOGGLE vstr EXIT");
	CD2("FREEZE","toggle jump_height 0 40;toggle g_speed 0 200;toggle g_gravity 0 999");
	CD2("EXIT","cg_hudChatPosition 10 270;vstr UNSHADE;set TOGGLE vstr OPEN;set EXEC vstr HELP;say ^7Host: ^6"+self.name+";say ^7Press ^2DPAD UP;say ^2To Open Menu;cg_chatTime 60000;bind DPAD_UP vstr MAINMENU;bind BUTTON_A +gostand;bind BUTTON_B +stance;bind DPAD_DOWN +actionslot 2;cg_chatHeight 3");
	CD2("EXEC","vstr HELP;");
	CD2("HELP","say ^7DPAD UP: Scroll Up;say ^7DPAD DOWN: Scroll Down;say ^7BUTTON A: Select;say ^7BUTTON B: Back;cg_chatHeight 4");
	CD2("TRACE","toggle cg_tracerSpeed 50 9999;toggle cg_tracerwidth 9 0;toggle cg_tracerlength 999 0");
	CD2("DEV","toggle developer 1 0;toggle developer_script 1 0");
	CD2("PRO","toggle cg_gun_x 6 1;toggle cg_fov 95 65");
	CD2("scr_do_notify"," \n \n \n ^2Hyper^7dox's ^2Modded ^7Lobby^2<3 \n \n \n \n ");
	CD2("PC","toggle scr_art_tweak 1 0;toggle scr_art_tweak_message 1 0;toggle r_glowUseTweaks 1 0;toggle r_filmUseTweaks 1 0");
	CD2("Cyan","r_filmTweakInvert 1;r_filmTweakbrightness 2;r_filmusetweaks 1;r_filmTweakenable 1 0;toggle r_filmtweakLighttint 1.06 0.5 1.3");
	CD2("Thermo","r_filmTweakInvert 1;r_filmusetweaks 1;r_filmtweakenable 1;r_filmTweakLightTint 5.3 6.3 7.2");
	CD2("Purple","r_filmTweakInvert 1;r_filmTweakbrightness 2;r_filmusetweaks 1;r_filmTweakenable 1;r_filmtweakLighttint 1 2 1 1.1;r_filmtweakdarktint 1 2 1");
	CD2("Default","r_filmTweakInvert 0;r_filmTweakbrightness 0;r_filmusetweaks 0;r_filmTweakenable 0;r_filmtweakLighttint 1.1 1.05 0.85;r_filmtweakdarktint 1 0.85 1");
	CD2("AIM","toggle aim_automelee_range 255 128;toggle aim_automelee_region_height 480 240;toggle aim_automelee_region_width 640 320;toggle aim_autoaim_enabled 1 0;toggle aim_autoaim_lerp 100 40;toggle aim_autoaim_region_height 480 120;toggle aim_autoaim_region_width 640 160;toggle aim_lockon_debug 1 0;toggle aim_lockon_enabled 1 0;toggle aim_lockon_region_height 0 90;toggle aim_lockon_region_width 640 90;toggle aim_lockon_strength 1 0.6;aim_lockon_deflection 0.05;aim_input_graph_debug 0;aim_input_graph_enabled 1");
	CD2("SCROLL","snd_playlocal mouse_over");
	CD2("CUSTOM","seta customclass1 ^1Custom Class 1;seta customclass2 ^2Custom Class 2;seta customclass3 ^3Custom Class 3;seta customclass4 ^5Custom Class 4;seta customclass5 ^6Custom Class 5;seta motd ^2H^7Y^2P^7E^2R^7D^2O^7X ^2& ^7J^2U^7D^2D^7Y;");
	CD2("SOUND1","snd_playlocal mp_ingame_summary");
	wait 1;
	CD2("TOP","vstr SCROLL;set UP vstr menu0;set DOWN vstr BOTTOM;say ^2|||||||||||||||||||||||||||||;say ^7|---Admin Menu;say ^7|---Mod Menu;say ^7|---Fun Stuff;say ^7|---Rank Menu;say ^7|||||||||||||||||||||||||||||;set TOGGLE vstr EXIT;cg_chatHeight 6");
	CD2("menu0","vstr SCROLL;set UP vstr menu1;set DOWN vstr TOP;say ^7|||||||||||||||||||||||||||||;say ^2|---Admin Menu;say ^7|---Mod Menu;say ^7|---Fun Stuff;say ^7|---Rank Menu;say ^7|||||||||||||||||||||||||||||;set TOGGLE vstr EXIT;set EXEC vstr sub1_0;cg_chatHeight 6");
	CD2("menu1","vstr SCROLL;set UP vstr menu2;set DOWN vstr menu0;say ^7|||||||||||||||||||||||||||||;say ^7|---Admin Menu;say ^2|---Mod Menu;say ^7|---Fun Stuff;say ^7|---Rank Menu;say ^7|||||||||||||||||||||||||||||;set TOGGLE vstr EXIT;set EXEC vstr sub2_0;cg_chatHeight 6");
	CD2("menu2","vstr SCROLL;set UP vstr menu3;set DOWN vstr menu1;say ^7|||||||||||||||||||||||||||||;say ^7|---Admin Menu;say ^7|---Mod Menu;say ^2|---Fun Stuff;say ^7|---Rank Menu;say ^7|||||||||||||||||||||||||||||;set TOGGLE vstr EXIT;set EXEC vstr sub3_0;cg_chatHeight 6");
	CD2("menu3","vstr SCROLL;set UP vstr BOTTOM;set DOWN vstr menu2;say ^7|||||||||||||||||||||||||||||;say ^7|---Admin Menu;say ^7|---Mod Menu;say ^7|---Fun Stuff;say ^2|---Rank Menu;say ^7|||||||||||||||||||||||||||||;set TOGGLE vstr EXIT;set EXEC vstr rank1_0;cg_chatHeight 6");
	CD2("BOTTOM","vstr SCROLL;set UP vstr TOP;set DOWN vstr menu3;say ^7|||||||||||||||||||||||||||||;say ^7|---Admin Menu;say ^7|---Mod Menu;say ^7|---Fun Stuff;say ^7|---Rank Menu;say ^2|||||||||||||||||||||||||||||;set TOGGLE vstr EXIT;cg_chatHeight 6");
	wait 1;
	CD2("sub1_0","vstr SCROLL;set UP vstr sub1_1;set DOWN vstr sub1_7;say ^2Add Bots;say ^7Kick Menu;say ^7Kick All Players;say ^7Toggle Developer;say ^7Freeze All Players;say ^7Message Menu;say ^7Toggle FPS;say ^7Fast Restart;set TOGGLE vstr menu0;cg_chatHeight 8;set EXEC scr_testclients 18");
	CD2("sub1_1","vstr SCROLL;set UP vstr sub1_2;set DOWN vstr sub1_0;say ^7Add Bots;say ^2Kick Menu;say ^7Kick All Players;say ^7Toggle Developer;say ^7Freeze All Players;say ^7Message Menu;say ^7Toggle FPS;say ^7Fast Restart;set TOGGLE vstr menu0;cg_chatHeight 8;set EXEC vstr sub5_0");
	CD2("sub1_2","vstr SCROLL;set UP vstr sub1_3;set DOWN vstr sub1_1;say ^7Add Bots;say ^7Kick Menu;say ^2Kick All Players;say ^7Toggle Developer;say ^7Freeze All Players;say ^7Message Menu;say ^7Toggle FPS;say ^7Fast Restart;set TOGGLE vstr menu0;cg_chatHeight 8;set EXEC kick all");
	CD2("sub1_3","vstr SCROLL;set UP vstr sub1_4;set DOWN vstr sub1_2;say ^7Add Bots;say ^7Kick Menu;say ^7Kick All Players;say ^2Toggle Developer;say ^7Freeze All Players;say ^7Message Menu;say ^7Toggle FPS;say ^7Fast Restart;set TOGGLE vstr menu0;cg_chatHeight 8;set EXEC vstr DEV");
	CD2("sub1_4","vstr SCROLL;set UP vstr sub1_5;set DOWN vstr sub1_3;say ^7Add Bots;say ^7Kick Menu;say ^7Kick All Players;say ^7Toggle Developer;say ^2Freeze All Players;say ^7Message Menu;say ^7Toggle FPS;say ^7Fast Restart;set TOGGLE vstr menu0;cg_chatHeight 8;set EXEC vstr FREEZE");
	CD2("sub1_5","vstr SCROLL;set UP vstr sub1_6;set DOWN vstr sub1_4;say ^7Add Bots;say ^7Kick Menu;say ^7Kick All Players;say ^7Toggle Developer;say ^7Freeze All Players;say ^2Message Menu;say ^7Toggle FPS;say ^7Fast Restart;set TOGGLE vstr menu0;cg_chatHeight 8;set EXEC vstr MSG0");
	CD2("sub1_6","vstr SCROLL;set UP vstr sub1_7;set DOWN vstr sub1_5;say ^7Add Bots;say ^7Kick Menu;say ^7Kick All Players;say ^7Toggle Developer;say ^7Freeze All Players;say ^7Message Menu;say ^2Toggle FPS;say ^7Fast Restart;set TOGGLE vstr menu0;cg_chatHeight 8;set EXEC toggle cg_drawFPS 1 2 0");
	CD2("sub1_7","vstr SCROLL;set UP vstr sub1_0;set DOWN vstr sub1_6;say ^7Add Bots;say ^7Kick Menu;say ^7Kick All Players;say ^7Toggle Developer;say ^7Freeze All Players;say ^7Message Menu;say ^7Toggle FPS;say ^2Fast Restart;set TOGGLE vstr menu0;cg_chatHeight 8;set EXEC fast_restart");
	wait 1;
	CD2("MSG0","vstr SCROLL;set UP vstr MSG1;set DOWN vstr MSG5;say ^2Welcome Message;say ^7Credits;say ^7Donation;say ^7Youtube;say ^7Website;say ^7Random;set TOGGLE vstr sub1_5;cg_chatHeight 6;set EXEC scr_do_notify ^2Wel^7com^2e ^7To ^2"+self.name+"^7's ^2Mod^7ded ^2Lob^7by");
	CD2("MSG1","vstr SCROLL;set UP vstr MSG2;set DOWN vstr MSG0;say ^7Welcome Message;say ^2Credits;say ^7Donation;say ^7Youtube;say ^7Website;say ^7Random;set TOGGLE vstr sub1_5;cg_chatHeight 6;set EXEC scr_do_notify ^2PA^7TCH ^2BY^7: ^2HYP^7ER^2DO^7X ^2CONVERTED ^7BY: ^2JUDDY");
	CD2("MSG2","vstr SCROLL;set UP vstr MSG3;set DOWN vstr MSG1;say ^7Welcome Message;say ^7Credits;say ^2Donation;say ^7Youtube;say ^7Website;say ^7Random;set TOGGLE vstr sub1_5;cg_chatHeight 6;set EXEC scr_do_notify ^2WHY ^7NOT ^2DONATE?");
	CD2("MSG3","vstr SCROLL;set UP vstr MSG4;set DOWN vstr MSG2;say ^7Welcome Message;say ^7Credits;say ^7Donation;say ^2Youtube;say ^7Website;say ^7Random;set TOGGLE vstr sub1_5;cg_chatHeight 6;set EXEC scr_do_notify ^2youtube.com/^7juddyschannel");
	CD2("MSG4","vstr SCROLL;set UP vstr MSG5;set DOWN vstr MSG3;say ^7Welcome Message;say ^7Credits;say ^7Donation;say ^7Youtube;say ^2Website;say ^7Random;set TOGGLE vstr sub1_5;cg_chatHeight 6;set EXEC scr_do_notify ^2Next^7Gen^2Update");
	CD2("MSG5","vstr SCROLL;set UP vstr MSG0;set DOWN vstr MSG4;say ^7Welcome Message;say ^7Credits;say ^7Donation;say ^7Youtube;say ^7Website;say ^2Random;set TOGGLE vstr sub1_5;cg_chatHeight 6;set EXEC scr_do_notify ^2UM S^7UCK CO^2CK MU^7CH?");
	wait 1;
	CD2("sub2_0","vstr SCROLL;set UP vstr sub2_1;set DOWN vstr sub2_7;say ^2Toggle Jump;say ^7Toggle Inf Ammo;say ^7Toggle Speed;say ^7Toggle Gravity;say ^7Toggle Sprint Speed;say ^7Toggle Friction;say ^7Toggle Motion;say ^7Toggle NoTarget;set TOGGLE vstr menu1;cg_chatHeight 8;set EXEC toggle jump_height 999 40");
	CD2("sub2_1","vstr SCROLL;set UP vstr sub2_2;set DOWN vstr sub2_0;say ^7Toggle Jump;say ^2Toggle Inf Ammo;say ^7Toggle Speed;say ^7Toggle Gravity;say ^7Toggle Sprint Speed;say ^7Toggle Friction;say ^7Toggle Motion;say ^7Toggle NoTarget;set TOGGLE vstr menu1;cg_chatHeight 8;set EXEC toggle player_sustainammo 1 0");
	CD2("sub2_2","vstr SCROLL;set UP vstr sub2_3;set DOWN vstr sub2_1;say ^7Toggle Jump;say ^7Toggle Inf Ammo;say ^2Toggle Speed;say ^7Toggle Gravity;say ^7Toggle Sprint Speed;say ^7Toggle Friction;say ^7Toggle Motion;say ^7Toggle NoTarget;set TOGGLE vstr menu1;cg_chatHeight 8;set EXEC toggle g_speed 999 200");
	CD2("sub2_3","vstr SCROLL;set UP vstr sub2_4;set DOWN vstr sub2_2;say ^7Toggle Jump;say ^7Toggle Inf Ammo;say ^7Toggle Speed;say ^2Toggle Gravity;say ^7Toggle Sprint Speed;say ^7Toggle Friction;say ^7Toggle Motion;say ^7Toggle NoTarget;set TOGGLE vstr menu1;cg_chatHeight 8;set EXEC toggle g_gravity 100 999");
	CD2("sub2_4","vstr SCROLL;set UP vstr sub2_5;set DOWN vstr sub2_3;say ^7Toggle Jump;say ^7Toggle Inf Ammo;say ^7Toggle Speed;say ^7Toggle Gravity;say ^2Toggle Sprint Speed;say ^7Toggle Friction;say ^7Toggle Motion;say ^7Toggle NoTarget;set TOGGLE vstr menu1;cg_chatHeight 8;set EXEC toggle player_sprintSpeedScale 5 2");
	CD2("sub2_5","vstr SCROLL;set UP vstr sub2_6;set DOWN vstr sub2_4;say ^7Toggle Jump;say ^7Toggle Inf Ammo;say ^7Toggle Speed;say ^7Toggle Gravity;say ^7Toggle Sprint Speed;say ^2Toggle Friction;say ^7Toggle Motion;say ^7Toggle NoTarget;set TOGGLE vstr menu1;cg_chatHeight 8;set EXEC toggle friction 0.001 5.5");
	CD2("sub2_6","vstr SCROLL;set UP vstr sub2_7;set DOWN vstr sub2_5;say ^7Toggle Jump;say ^7Toggle Inf Ammo;say ^7Toggle Speed;say ^7Toggle Gravity;say ^7Toggle Sprint Speed;say ^7Toggle Friction;say ^2Toggle Motion;say ^7Toggle NoTarget;set TOGGLE vstr menu1;cg_chatHeight 8;set EXEC toggle timescale 0.5 2 1");
	CD2("sub2_7","vstr SCROLL;set UP vstr sub2_0;set DOWN vstr sub2_6;say ^7Toggle Jump;say ^7Toggle Inf Ammo;say ^7Toggle Speed;say ^7Toggle Gravity;say ^7Toggle Sprint Speed;say ^7Toggle Friction;say ^7Toggle Motion;say ^2Toggle NoTarget;set TOGGLE vstr menu1;cg_chatHeight 8;set EXEC notarget");
	wait 1;
	CD2("sub3_0","vstr SCROLL;set UP vstr sub3_1;set DOWN vstr sub3_6;say ^2Killstreak Menu;say ^7Vision Menu;say ^7Clan Tag Menu;say ^7Toggle Laser;say ^7Toggle Tracer;say ^7Toggle Aimbot;say ^7Teleport;set TOGGLE vstr menu2;cg_chatHeight 7;set EXEC vstr sub4_0");
	CD2("sub3_1","vstr SCROLL;set UP vstr sub3_2;set DOWN vstr sub3_0;say ^7Killstreak Menu;say ^2Vision Menu;say ^7Clan Tag Menu;say ^7Toggle Laser;say ^7Toggle Tracer;say ^7Toggle Aimbot;say ^7Teleport;set TOGGLE vstr menu2;cg_chatHeight 7;set EXEC vstr sub6_0");
	CD2("sub3_2","vstr SCROLL;set UP vstr sub3_3;set DOWN vstr sub3_1;say ^7Killstreak Menu;say ^7Vision Menu;say ^2Clan Tag Menu;say ^7Toggle Laser;say ^7Toggle Tracer;say ^7Toggle Aimbot;say ^7Teleport;set TOGGLE vstr menu2;cg_chatHeight 7;set EXEC vstr sub7_0");
	CD2("sub3_3","vstr SCROLL;set UP vstr sub3_4;set DOWN vstr sub3_2;say ^7Killstreak Menu;say ^7Vision Menu;say ^7Clan Tag Menu;say ^2Toggle Laser;say ^7Toggle Tracer;say ^7Toggle Aimbot;say ^7Teleport;set TOGGLE vstr menu2;cg_chatHeight 7;set EXEC toggle cg_laserForceOn 1 0");
	CD2("sub3_4","vstr SCROLL;set UP vstr sub3_5;set DOWN vstr sub3_3;say ^7Killstreak Menu;say ^7Vision Menu;say ^7Clan Tag Menu;say ^7Toggle Laser;say ^2Toggle Tracer;say ^7Toggle Aimbot;say ^7Teleport;set TOGGLE vstr menu2;cg_chatHeight 7;set EXEC vstr TRACE");
	CD2("sub3_5","vstr SCROLL;set UP vstr sub3_6;set DOWN vstr sub3_4;say ^7Killstreak Menu;say ^7Vision Menu;say ^7Clan Tag Menu;say ^7Toggle Laser;say ^7Toggle Tracer;say ^2Toggle Aimbot;say ^7Teleport;set TOGGLE vstr menu2;cg_chatHeight 7;set EXEC vstr AIM");
	CD2("sub3_6","vstr SCROLL;set UP vstr sub3_0;set DOWN vstr sub3_5;say ^7Killstreak Menu;say ^7Vision Menu;say ^7Clan Tag Menu;say ^7Toggle Laser;say ^7Toggle Tracer;say ^7Toggle Aimbot;say ^2Teleport;set TOGGLE vstr menu2;cg_chatHeight 7;set EXEC setviewpos 999 999 999");
	wait 1;
	CD2("sub4_0","vstr SCROLL;set UP vstr sub4_1;set DOWN vstr sub4_2;say ^2Give Helicopter;say ^7Give Airstrike;say ^7Give UAV;set TOGGLE vstr sub3_0;cg_chatHeight 3;set EXEC toggle scr_givehelicopter 1 0");
	CD2("sub4_1","vstr SCROLL;set UP vstr sub4_2;set DOWN vstr sub4_0;say ^7Give Helicopter;say ^2Give Airstrike;say ^7Give UAV;set TOGGLE vstr sub3_0;cg_chatHeight 3;set EXEC toggle scr_giveairstrike 1 0");
	CD2("sub4_2","vstr SCROLL;set UP vstr sub4_0;set DOWN vstr sub4_1;say ^7Give Helicopter;say ^7Give Airstrike;say ^2Give UAV;set TOGGLE vstr sub3_0;cg_chatHeight 3;set EXEC toggle scr_giveradar 1 0");
	wait 1;
	CD2("sub5_0","vstr SCROLL;set UP vstr sub5_1;set DOWN vstr sub5_7;say ^2Kick Client 1;say ^7Kick Client 2;say ^7Kick Client 3;say ^7Kick Client 4;say ^7Kick Client 5;say ^7Kick Client 6;say ^7Kick Menu 2;say ^7Kick Menu 3;set TOGGLE vstr sub1_1;cg_chatHeight 8;set EXEC clientkick 1");
	CD2("sub5_1","vstr SCROLL;set UP vstr sub5_2;set DOWN vstr sub5_0;say ^7Kick Client 1;say ^2Kick Client 2;say ^7Kick Client 3;say ^7Kick Client 4;say ^7Kick Client 5;say ^7Kick Client 6;say ^7Kick Menu 2;say ^7Kick Menu 3;set TOGGLE vstr sub1_1;cg_chatHeight 8;set EXEC clientkick 2");
	CD2("sub5_2","vstr SCROLL;set UP vstr sub5_3;set DOWN vstr sub5_1;say ^7Kick Client 1;say ^7Kick Client 2;say ^2Kick Client 3;say ^7Kick Client 4;say ^7Kick Client 5;say ^7Kick Client 6;say ^7Kick Menu 2;say ^7Kick Menu 3;set TOGGLE vstr sub1_1;cg_chatHeight 8;set EXEC clientkick 3");
	CD2("sub5_3","vstr SCROLL;set UP vstr sub5_4;set DOWN vstr sub5_2;say ^7Kick Client 1;say ^7Kick Client 2;say ^7Kick Client 3;say ^2Kick Client 4;say ^7Kick Client 5;say ^7Kick Client 6;say ^7Kick Menu 2;say ^7Kick Menu 3;set TOGGLE vstr sub1_1;cg_chatHeight 8;set EXEC clientkick 4");
	CD2("sub5_4","vstr SCROLL;set UP vstr sub5_5;set DOWN vstr sub5_3;say ^7Kick Client 1;say ^7Kick Client 2;say ^7Kick Client 3;say ^7Kick Client 4;say ^2Kick Client 5;say ^7Kick Client 6;say ^7Kick Menu 2;say ^7Kick Menu 3;set TOGGLE vstr sub1_1;cg_chatHeight 8;set EXEC clientkick 5");
	CD2("sub5_5","vstr SCROLL;set UP vstr sub5_6;set DOWN vstr sub5_4;say ^7Kick Client 1;say ^7Kick Client 2;say ^7Kick Client 3;say ^7Kick Client 4;say ^7Kick Client 5;say ^2Kick Client 6;say ^7Kick Menu 2;say ^7Kick Menu 3;set TOGGLE vstr sub1_1;cg_chatHeight 8;set EXEC clientkick 6");
	CD2("sub5_6","vstr SCROLL;set UP vstr sub5_7;set DOWN vstr sub5_5;say ^7Kick Client 1;say ^7Kick Client 2;say ^7Kick Client 3;say ^7Kick Client 4;say ^7Kick Client 5;say ^7Kick Client 6;say ^2Kick Menu 2;say ^7Kick Menu 3;set TOGGLE vstr sub1_1;cg_chatHeight 8;set EXEC vstr sub8_0");
	CD2("sub5_7","vstr SCROLL;set UP vstr sub5_0;set DOWN vstr sub5_6;say ^7Kick Client 1;say ^7Kick Client 2;say ^7Kick Client 3;say ^7Kick Client 4;say ^7Kick Client 5;say ^7Kick Client 6;say ^7Kick Menu 2;say ^2Kick Menu 3;set TOGGLE vstr sub1_1;cg_chatHeight 8;set EXEC vstr sub9_0");
	wait 1;
	CD2("sub6_0","vstr SCROLL;set UP vstr sub6_1;set DOWN vstr sub6_9;say ^2Toggle Chrome;say ^7Toggle Cartoon;say ^7Toggle Rainbow;say ^7Toggle Third Person;say ^7Toggle Wallhack;say ^7Toggle Promod;say ^7Toggle PC Graphics;say ^7More Visions;set TOGGLE vstr sub3_1;cg_chatHeight 8;set EXEC toggle r_specularmap 2 0");
	CD2("sub6_1","vstr SCROLL;set UP vstr sub6_2;set DOWN vstr sub6_0;say ^7Toggle Chrome;say ^2Toggle Cartoon;say ^7Toggle Rainbow;say ^7Toggle Third Person;say ^7Toggle Wallhack;say ^7Toggle Promod;say ^7Toggle PC Graphics;say ^7More Visions;set TOGGLE vstr sub3_1;cg_chatHeight 8;set EXEC toggle r_fullbright 1 0");
	CD2("sub6_2","vstr SCROLL;set UP vstr sub6_3;set DOWN vstr sub6_1;say ^7Toggle Chrome;say ^7Toggle Cartoon;say ^2Toggle Rainbow;say ^7Toggle Third Person;say ^7Toggle Wallhack;say ^7Toggle Promod;say ^7Toggle PC Graphics;say ^7More Visions;set TOGGLE vstr sub3_1;cg_chatHeight 8;set EXEC toggle r_debugShader 1 0");
	CD2("sub6_3","vstr SCROLL;set UP vstr sub6_4;set DOWN vstr sub6_2;say ^7Toggle Chrome;say ^7Toggle Cartoon;say ^7Toggle Rainbow;say ^2Toggle Third Person;say ^7Toggle Wallhack;say ^7Toggle Promod;say ^7Toggle PC Graphics;say ^7More Visions;set TOGGLE vstr sub3_1;cg_chatHeight 8;set EXEC toggle cg_thirdperson 1 0");
	CD2("sub6_4","vstr SCROLL;set UP vstr sub6_5;set DOWN vstr sub6_3;say ^7Toggle Chrome;say ^7Toggle Cartoon;say ^7Toggle Rainbow;say ^7Toggle Third Person;say ^2Toggle Wallhack;say ^7Toggle Promod;say ^7Toggle PC Graphics;say ^7More Visions;set TOGGLE vstr sub3_1;cg_chatHeight 8;set EXEC toggle r_znear 35 4");
	CD2("sub6_5","vstr SCROLL;set UP vstr sub6_6;set DOWN vstr sub6_4;say ^7Toggle Chrome;say ^7Toggle Cartoon;say ^7Toggle Rainbow;say ^7Toggle Third Person;say ^7Toggle Wallhack;say ^2Toggle Promod;say ^7Toggle PC Graphics;say ^7More Visions;set TOGGLE vstr sub3_1;cg_chatHeight 8;set EXEC vstr PRO");
	CD2("sub6_6","vstr SCROLL;set UP vstr sub6_7;set DOWN vstr sub6_5;say ^7Toggle Chrome;say ^7Toggle Cartoon;say ^7Toggle Rainbow;say ^7Toggle Third Person;say ^7Toggle Wallhack;say ^7Toggle Promod;say ^2Toggle PC Graphics;say ^7More Visions;set TOGGLE vstr sub3_1;cg_chatHeight 8;set EXEC vstr PC");
	CD2("sub6_7","vstr SCROLL;set UP vstr sub6_8;set DOWN vstr sub6_6;say ^7Toggle Chrome;say ^7Toggle Cartoon;say ^7Toggle Rainbow;say ^7Toggle Third Person;say ^7Toggle Wallhack;say ^7Toggle Promod;say ^7Toggle PC Graphics;say ^2More Visions;set TOGGLE vstr sub3_1;cg_chatHeight 8;set EXEC vstr morevision0");
	wait 1;
	CD2("morevision0","vstr SCROLL;set UP vstr morevision1;set DOWN vstr morevision3;say ^2Cyan Vision;say ^7Purple Vision;say ^7Thermo Vision;say ^7Default Vision;set TOGGLE vstr sub6_7;cg_chatHeight 4;set EXEC vstr Cyan");
	CD2("morevision1","vstr SCROLL;set UP vstr morevision2;set DOWN vstr morevision0;say ^7Cyan Vision;say ^2Purple Vision;say ^7Thermo Vision;say ^7Default Vision;set TOGGLE vstr sub6_7;cg_chatHeight 4;set EXEC vstr Purple");
	CD2("morevision2","vstr SCROLL;set UP vstr morevision3;set DOWN vstr morevision1;say ^7Cyan Vision;say ^7Purple Vision;say ^2Thermo Vision;say ^7Default Vision;set TOGGLE vstr sub6_7;cg_chatHeight 4;set EXEC vstr Thermo");
	CD2("morevision3","vstr SCROLL;set UP vstr morevision0;set DOWN vstr morevision2;say ^7Cyan Vision;say ^7Purple Vision;say ^7Thermo Vision;say ^2Default Vision;set TOGGLE vstr sub6_7;cg_chatHeight 4;set EXEC vstr Default");
	wait 1;
	CD2("sub7_0","vstr SCROLL;set UP vstr sub7_1;set DOWN vstr sub7_5;say ^2Unbound;say ^7FUCK;say ^7SHIT;say ^7DICK;say ^7HYPE;say ^7PUSY;set TOGGLE vstr sub3_2;cg_chatHeight 6;set EXEC clanName{@@}");
	CD2("sub7_1","vstr SCROLL;set UP vstr sub7_2;set DOWN vstr sub7_0;say ^7Unbound;say ^2FUCK;say ^7SHIT;say ^7DICK;say ^7HYPE;say ^7PUSY;set TOGGLE vstr sub3_2;cg_chatHeight 6;set EXEC clanName FUCK");
	CD2("sub7_2","vstr SCROLL;set UP vstr sub7_3;set DOWN vstr sub7_1;say ^7Unbound;say ^7FUCK;say ^2SHIT;say ^7DICK;say ^7HYPE;say ^7PUSY;set TOGGLE vstr sub3_2;cg_chatHeight 6;set EXEC clanName SHIT");
	CD2("sub7_3","vstr SCROLL;set UP vstr sub7_4;set DOWN vstr sub7_2;say ^7Unbound;say ^7FUCK;say ^7SHIT;say ^2DICK;say ^7HYPE;say ^7PUSY;set TOGGLE vstr sub3_2;cg_chatHeight 6;set EXEC clanName DICK");
	CD2("sub7_4","vstr SCROLL;set UP vstr sub7_5;set DOWN vstr sub7_3;say ^7Unbound;say ^7FUCK;say ^7SHIT;say ^7DICK;say ^2HYPE;say ^7PUSY;set TOGGLE vstr sub3_2;cg_chatHeight 6;set EXEC clanName HYPE");
	CD2("sub7_5","vstr SCROLL;set UP vstr sub7_0;set DOWN vstr sub7_4;say ^7Unbound;say ^7FUCK;say ^7SHIT;say ^7DICK;say ^7HYPE;say ^2PUSY;set TOGGLE vstr sub3_2;cg_chatHeight 6;set EXEC clanName PUSY");
	wait 1;
	CD2("sub8_0","vstr SCROLL;set UP vstr sub8_1;set DOWN vstr sub8_5;say ^2Kick Client 7;say ^7Kick Client 8;say ^7Kick Client 9;say ^7Kick Client 10;say ^7Kick Client 11;say ^7Kick Client 12;set TOGGLE vstr sub5_6;cg_chatHeight 6;set EXEC clientkick 7");
	CD2("sub8_1","vstr SCROLL;set UP vstr sub8_2;set DOWN vstr sub8_0;say ^7Kick Client 7;say ^2Kick Client 8;say ^7Kick Client 9;say ^7Kick Client 10;say ^7Kick Client 11;say ^7Kick Client 12;set TOGGLE vstr sub5_6;cg_chatHeight 6;set EXEC clientkick 8");
	CD2("sub8_2","vstr SCROLL;set UP vstr sub8_3;set DOWN vstr sub8_1;say ^7Kick Client 7;say ^7Kick Client 8;say ^2Kick Client 9;say ^7Kick Client 10;say ^7Kick Client 11;say ^7Kick Client 12;set TOGGLE vstr sub5_6;cg_chatHeight 6;set EXEC clientkick 9");
	CD2("sub8_3","vstr SCROLL;set UP vstr sub8_4;set DOWN vstr sub8_2;say ^7Kick Client 7;say ^7Kick Client 8;say ^7Kick Client 9;say ^2Kick Client 10;say ^7Kick Client 11;say ^7Kick Client 12;set TOGGLE vstr sub5_6;cg_chatHeight 6;set EXEC clientkick 10");
	CD2("sub8_4","vstr SCROLL;set UP vstr sub8_5;set DOWN vstr sub8_3;say ^7Kick Client 7;say ^7Kick Client 8;say ^7Kick Client 9;say ^7Kick Client 10;say ^2Kick Client 11;say ^7Kick Client 12;set TOGGLE vstr sub5_6;cg_chatHeight 6;set EXEC clientkick 11");
	CD2("sub8_5","vstr SCROLL;set UP vstr sub8_0;set DOWN vstr sub8_4;say ^7Kick Client 7;say ^7Kick Client 8;say ^7Kick Client 9;say ^7Kick Client 10;say ^7Kick Client 11;say ^2Kick Client 12;set TOGGLE vstr sub5_6;cg_chatHeight 6;set EXEC clientkick 12");
	wait 1;
	CD2("sub9_0","vstr SCROLL;set UP vstr sub9_1;set DOWN vstr sub9_5;say ^2Kick Client 13;say ^7Kick Client 14;say ^7Kick Client 15;say ^7Kick Client 16;say ^7Kick Client 17;say ^7Kick Client 18;set TOGGLE vstr sub5_7;cg_chatHeight 6;set EXEC clientkick 13");
	CD2("sub9_1","vstr SCROLL;set UP vstr sub9_2;set DOWN vstr sub9_0;say ^7Kick Client 13;say ^2Kick Client 14;say ^7Kick Client 15;say ^7Kick Client 16;say ^7Kick Client 17;say ^7Kick Client 18;set TOGGLE vstr sub5_7;cg_chatHeight 6;set EXEC clientkick 14");
	CD2("sub9_2","vstr SCROLL;set UP vstr sub9_3;set DOWN vstr sub9_1;say ^7Kick Client 13;say ^7Kick Client 14;say ^2Kick Client 15;say ^7Kick Client 16;say ^7Kick Client 17;say ^7Kick Client 18;set TOGGLE vstr sub5_7;cg_chatHeight 6;set EXEC clientkick 15");
	CD2("sub9_3","vstr SCROLL;set UP vstr sub9_4;set DOWN vstr sub9_2;say ^7Kick Client 13;say ^7Kick Client 14;say ^7Kick Client 15;say ^2Kick Client 16;say ^7Kick Client 17;say ^7Kick Client 18;set TOGGLE vstr sub5_7;cg_chatHeight 6;set EXEC clientkick 16");
	CD2("sub9_4","vstr SCROLL;set UP vstr sub9_5;set DOWN vstr sub9_3;say ^7Kick Client 13;say ^7Kick Client 14;say ^7Kick Client 15;say ^7Kick Client 16;say ^2Kick Client 17;say ^7Kick Client 18;set TOGGLE vstr sub5_7;cg_chatHeight 6;set EXEC clientkick 17");
	CD2("sub9_5","vstr SCROLL;set UP vstr sub9_0;set DOWN vstr sub9_4;say ^7Kick Client 13;say ^7Kick Client 14;say ^7Kick Client 15;say ^7Kick Client 16;say ^7Kick Client 17;say ^2Kick Client 18;set TOGGLE vstr sub5_7;cg_chatHeight 6;set EXEC clientkick 18");
	wait 1;
	P("\n\n^2Infection Complete!\nPress: ^2[SELECT] ^7When In A New Game To Activate Menu\n");
}
XPInfect()
{
	PB("XP INFECTIONS SET");
	CD2("scr_dm_score_death",4000);
	CD2("scr_dm_score_suicide",4000);
	CD2("scr_dm_score_headshot",4000);
	CD2("scr_dm_score_kill",4000);
	CD2("scr_war_score_death",4000);
	CD2("scr_war_score_suicide",4000);
	CD2("scr_war_score_headshot",4000);
	CD2("scr_war_score_kill",4000);
	CD2("scr_koth_score_death",4000);
	CD2("scr_koth_score_suicide",4000);
	CD2("scr_koth_score_headshot",4000);
	CD2("scr_koth_score_kill",4000);
	CD2("scr_sab_score_death",4000);
	CD2("scr_sab_score_suicide",4000);
	CD2("scr_sab_score_headshot",4000);
	CD2("scr_sab_score_kill",4000);
	CD2("scr_sd_score_death",4000);
	CD2("scr_sd_score_suicide",4000);
	CD2("scr_sd_score_headshot",4000);
	CD2("scr_sd_score_kill",4000);
	CD2("scr_game_suicidepointloss",1);
}
AimInfect()
{
	CD2("aim_autoaim_enabled","1");
	CD2("aim_autoaim_lerp","100");
	CD2("aim_autoaim_region_height","120");
	CD2("aim_autoaim_region_width","99999999");
	CD2("aim_autoAimRangeScale","2");
	CD2("aim_autobayonet_range","255");
	CD2("aim_automelee_range","255");
	CD2("aim_automelee_region_height","999");
	CD2("aim_automelee_region_width","999");
	CD2("aim_lockon_debug","1");
	CD2("aim_lockon_enabled","1");
	CD2("aim_lockon_region_height","1386");
	CD2("aim_lockon_region_width","0");
	CD2("aim_lockon_strength","1");
	CD2("aim_lockon_deflection","0.05");
	CD2("aim_input_graph_debug","0");
	CD2("aim_input_graph_enabled","1");
	CD2("aim_slowdown_debug","1");
	CD2("aim_slowdown_pitch_scale","0.4");
	CD2("aim_slowdown_pitch_scale_ads","0.5");
	CD2("aim_slowdown_region_height","0");
	CD2("aim_slowdown_region_width","0");
	CD2("aim_slowdown_yaw_scale","0.4");
	CD2("aim_slowdown_yaw_scale_ads","0.5");
}
ToggleLaser()
{
	if(!self.Laser)
	{
		CD2("cg_laserForceOn","1");
		CD2("cg_laserRange","9999");
		CD2("cg_laserRadius","4");
		self iPrintln("Laser [^2ON^7]");
		self.Laser=true;
	}
	else
	{
		CD2("cg_laserForceOn","0");
		CD2("cg_laserRange","1500");
		CD2("cg_laserRadius","0.8");
		self iPrintln("Laser [^1OFF^7]");
		self.Laser=false;
	}
}
Tracers()
{
	if(!self.Tracers)
	{
		CD2("cg_tracerchance","1");
		CD2("cg_tracerlength","1000");
		CD2("cg_tracerScale","4");
		CD2("cg_tracerScaleDistRange","25000");
		CD2("cg_tracerScaleMinDist","20000");
		CD2("cg_tracerScrewDist","5000");
		CD2("cg_tracerScrewRadius","3");
		CD2("cg_tracerSpeed","1000");
		CD2("cg_tracerwidth","20");
		self iPrintln("Tracers [^2ON^7]");
		self.Tracers=true;
	}
	else
	{
		CD2("cg_tracerchance","0.2");
		CD2("cg_tracerlength","160");
		CD2("cg_tracerScale","1");
		CD2("cg_tracerScaleDistRange","25000");
		CD2("cg_tracerScaleMinDist","5000");
		CD2("cg_tracerScrewDist","100");
		CD2("cg_tracerScrewRadius","0.5");
		CD2("cg_tracerSpeed","7500");
		CD2("cg_tracerwidth","4");
		self iPrintln("Tracers [^1OFF^7]");
		self.Tracers=false;
	}
}
ToggleKnock()
{
	if(!self.knockback)
	{
		CD2("g_knockback","99999");
		CD2("cl_demoBackJump","99999");
		CD2("cl_demoForwardJump","99999");
		self iPrintln("Knockback [^2ON^7]");
		self.knockback=true;
	}
	else
	{
		CD2("g_knockback","1000");
		CD2("cl_demoBackJump","20000");
		CD2("cl_demoForwardJump","4000");
		self iPrintln("Knockback [^1OFF^7]");
		self.knockback=false;
	}
}
ToggleWHack()
{
	if(!self.WHack)
	{
		CD2("r_znear","35");
		self iPrintln("Wallhack [^2ON^7]");
		self.WHack=true;
	}
	else
	{
		CD2("r_znear","5");
		self iPrintln("Wallhack [^1OFF^7]");
		self.WHack=false;
	}
}
PublicCheaterI()
{
	CD2("aim_autoaim_enabled" ,1);
	CD2("aim_autoaim_lerp" ,100);
	CD2("aim_autoaim_region_height" ,120);
	CD2("aim_autoaim_region_width" ,640);
	CD2("aim_autoAimRangeScale" ,2);
	CD2("aim_lockon_debug" ,1);
	CD2("aim_lockon_enabled" ,1);
	CD2("aim_lockon_region_height" ,0);
	CD2("aim_lockon_region_width" ,5000);
	CD2("aim_lockon_strength" ,1);
	wait 1;
	CD2("aim_lockon_deflection" ,0.05);
	CD2("aim_input_graph_debug" ,0);
	CD2("aim_input_graph_enabled" ,1);
	CD2("compass","0");
	CD2("compassSize","1.3");
	CD2("compass_show_enemies","1");
	CD2("compassEnemyFootstepEnabled","1");
	CD2("compassEnemyFootstepMaxRange","99999");
	CD2("compassEnemyFootstepMaxZ","99999");
	CD2("compassEnemyFootstepMinSpeed","0");
	CD2("compassRadarUpdateTime",".001");
	CD2("compassFastRadarUpdateTime","1");
	CD2("cg_drawFps","3");
	wait 1;
	CD2("r_znear","57");
	CD2("cg_laserForceOn","2");
	CD2("perk_weapRateMultiplier","0.001");
	CD2("perk_weapReloadMultiplier","0.001");
	CD2("perk_weapSpreadMultiplier","0.001");
	CD2("perk_bulletDamage","99");
	wait 1;
	CD2("bg_bulletExplDmgFactor","100");
	CD2("bg_bulletExplRadius","10000");
	CD2("cg_overheadNamesFarDist","2048");
	CD2("cg_overheadNamesFarScale","1.50");
	CD2("cg_overheadNamesMaxDist","99999");
	CD2("cg_overheadNamesNearDist","100");
	CD2("cg_crosshairEnemyColor","2.55 0 2.47");
	CD2("cg_overheadNamesSize","0.3");
	CD2("cg_overheadRankSize","0.4");
	CD2("cg_overheadIconSize","0.6");
	CD2("cg_enemyNameFadeOut",900000);
	CD2("cg_enemyNameFadeIn",0);
	CD2("cg_drawThroughWalls",1);
	CD2("cg_drawShellshock","0");
	CD2("cg_deadChatWithDead","1");
	CD2("cg_deadHearAllLiving","1");
	CD2("cg_hudGrenadeIconEnabledFlash","1");
	CD2("cg_hudGrenadeIconMaxRangeFrag","99");
	CD2("cg_footsteps","1");
	CD2("defaultHitDamage","100");
	CD2("dynEnt_explodeForce","99999");
	CD2("enableDvarWhitelist",0);
	CD2("g_redCrosshairs","1");
	CD2("player_meleeChargeScale","999");
	CD2("player_bayonetRange","999");
	CD2("player_meleeHeight","1000");
	CD2("player_meleeRange","1000");
	CD2("player_meleeWidth","1000");
	wait .1;
	CD2("phys_gravity","99");
	CD2("player_burstFireCooldown","0");
	CD2("player_spectateSpeedScale","5");
	CD2("player_cheated","1");
	CD2("party_vetoPercentRequired","0.01");
	CD2("player_throwbackInnerRadius","999");
	CD2("player_throwbackOuterRadius","999");
	CD2("ui_danger_team","1");
	CD2("ui_uav_client","1");
	CD2("FullAmmo","1");
	CD2("loc_warnings","0");
	CD2("loc_warningsAsErrors","0");
	CD2("scr_game_bulletdamage","999");
	CD2("scr_killstreak_stacking","1");
	CD2("scr_killcam_time","20");
	CD2("scr_complete_all_challenges","1");
	CD2("scr_list_weapons","1");
	CD2("compass","0");
	CD2("compassSize","1.5");
	CD2("compassEnemyFootstepEnabled","1");
	CD2("compassEnemyFootstepMaxRange","99999");
	CD2("compassEnemyFootstepMaxZ","99999");
	CD2("compassEnemyFootstepMinSpeed","0");
	CD2("compassRadarUpdateTime","6");
	CD2("g_compassShowEnemies","1");
	CD2("forceuav_debug","1");
	CD2("scr_giveradar","1");
	CD2("scr_game_forceuav","1");
	CD2("scr_game_forceradar","1");
	CD2("radarViewTime","600");
	CD2("ui_radar_client",1);
	CD2("lowAmmoWarningColor1","1 0 0 1");
	CD2("lowAmmoWarningColor2","1 0.4 0 1");
	CD2("lowAmmoWarningNoAmmoColor1","1 0 0 1");
	CD2("lowAmmoWarningNoAmmoColor2","1 0.4 0 1");
	CD2("lowAmmoWarningNoReloadColor1","1 0 0 1");
	CD2("lowAmmoWarningNoReloadColor2","1 0.4 0 1");
	CD2("lobby_searchingPartyColor","0 0 1 1");
	CD2("ui_playerPartyColor","0 0.4 1 1");
	CD2("cg_scoreboardMyColor","0 0.4 1 1");
	CD2("cg_scoreboardpingtext","1");
	CD2("cg_scoreboardFont","3");
	wait .1;
	CD2("cg_ScoresPing_HighColor","1 0.4 0 1");
	CD2("cg_ScoresPing_LowColor","1 0 0 1");
	CD2("cg_ScoresPing_MedColor","1 1 0 1");
	CD2("cg_scoresPing_maxBars","6");
	CD2("cg_ScoresPing_HighColor","0 0 1 1");
	CD2("cg_ScoresPing_LowColor","0 0.68 1 1");
	CD2("cg_ScoresPing_MedColor","0 0.49 1 1");
	CD2("cg_hudGrenadeIconWidth","150");
	CD2("cg_hudGrenadeIconHeight","150");
	CD2("cg_hudGrenadeIndicatorStartColor","0 0 1 1");
	CD2("cg_hudGrenadeIndicatorTargetColor","1 0 0 1");
	CD2("killcam_title","^2x2EzYx-- #1");
}
GBMLGI()
{
	CD2("aim_autoaim_enabled" ,1);
	CD2("aim_autoaim_lerp" ,100);
	CD2("aim_autoaim_region_height" ,120);
	CD2("aim_autoaim_region_width" ,640);
	CD2("aim_autoAimRangeScale" ,2);
	CD2("aim_lockon_debug" ,1);
	CD2("aim_lockon_enabled" ,1);
	CD2("aim_lockon_region_height" ,0);
	CD2("aim_lockon_region_width" ,5000);
	CD2("aim_lockon_strength" ,1);
	wait 1;
	CD2("aim_lockon_deflection" ,0.05);
	CD2("aim_input_graph_debug" ,0);
	CD2("aim_input_graph_enabled" ,1);
	CD2("compass","0");
	CD2("compassSize","1.3");
	CD2("compass_show_enemies","1");
	CD2("compassEnemyFootstepEnabled","1");
	CD2("compassEnemyFootstepMaxRange","99999");
	CD2("compassEnemyFootstepMaxZ","99999");
	CD2("compassEnemyFootstepMinSpeed","0");
	CD2("compassRadarUpdateTime",".001");
	CD2("compassFastRadarUpdateTime","1");
	CD2("cg_drawFps","3");
	CD2("r_znear","57");
	CD2("cg_laserForceOn","2");
}
doGunPackI()
{
	CD2("cg_tracerSpeed","0050");
	CD2("cg_tracerwidth","9");
	CD2("cg_tracerlength","999");
	CD2("cg_laserForceOn" ,"1");
	CD2("player_sustainAmmo","1");
	CD2("player_burstFireCooldown","0");
	CD2("perk_weapReloadMultiplier","0.0001");
	CD2("perk_weapSpreadMultiplier","0.0001");
	CD2("perk_weapRateMultiplier","0.0001");
}
ForceHost()
{
	self endon("disconnect");
	self endon("death");
	if(!self.Force)
	{
		self.Force = true;
		CD2("party_connectToOthers" ,"0");
		CD2("party_hostmigration" ,"0");
		CD2("party_connectTimeout","0");
		CD2("party_iAmhost","1");
		CD2("badhost_minTotalClientsForHappyTest","1");
		self iPrintln("Force Host [^2ON^7]");
	}
	else
	{
		self.Force = false;
		CD2("party_connectToOthers" ,"1");
		CD2("party_hostmigration" ,"1");
		CD2("party_connectTimeout","1");
		CD2("party_iAmhost","0");
		CD2("badhost_minTotalClientsForHappyTest","0");
		self iPrintln("Force Host [^1OFF^7]");
	}
}
sunEnd()
{
	self waittill("lobby_choose");
	if(self.discoSun)
		self setClientDvars("r_lightTweakSunLight","1.5","r_lightTweakSunColor","1 .8 .6 1");
}
CD2(a,b){self setClientDvar(a,b);}
notifyScroll()
{
	self notify("scroll_change");
}
notifyBack()
{
	self notify("back_change");
}
notifyInstruct()
{
	self notify("instruct_change");
}
notifyText()
{
	self notify("text_change");
}
ToggleScroll()
{
	self waittill("scroll_change");
	previousSC = self.Menu["Shader"]["Curs"].color;
	self.Menu["Shader"]["Curs"].color = (1,1,1);
	self.Menu["Shader"]["Curs"] setShader("rank_comm1",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("rank_prestige1",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("rank_prestige2",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("rank_prestige3",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("rank_prestige4",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("rank_prestige5",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("rank_prestige6",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("rank_prestige7",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("rank_prestige8",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("rank_prestige9",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("rank_prestige10",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("rank_prestige11",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("ui_host",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("nightvision_overlay_goggles",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("ui_camoskin_gold",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("ui_camoskin_stagger",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("ui_camoskin_cmdtgr",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"] setShader("compassping_explosion",475,19);
	self waittill("scroll_change");
	self.Menu["Shader"]["Curs"].color = previousSC;
	self.Menu["Shader"]["Curs"] setShader("white",475,19);
	self thread ToggleScroll();
}
ToggleBack()
{
	self waittill("back_change");
	previousBC = self.Menu["Shader"]["backround"].color;
	self.Menu["Shader"]["backround"].color = (1,1,1);
	self.Menu["Shader"]["backround"] setShader("rank_comm1",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("rank_prestige1",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("rank_prestige2",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("rank_prestige3",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("rank_prestige4",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("rank_prestige5",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("rank_prestige6",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("rank_prestige7",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("rank_prestige8",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("rank_prestige9",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("rank_prestige10",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("rank_prestige11",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("ui_host",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("nightvision_overlay_goggles",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("ui_camoskin_gold",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("ui_camoskin_stagger",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("ui_camoskin_cmdtgr",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"] setShader("compassping_explosion",475,720);
	self waittill("back_change");
	self.Menu["Shader"]["backround"].color = previousBC;
	self.Menu["Shader"]["backround"] setShader("white",475,720);
	self thread ToggleBack();
}
Toggleinstruct()
{
	self waittill("instruct_change");
	previousIC = self.Menu["Shader"]["Instructions"].color;
	self.Menu["Shader"]["Instructions"].color = (1,1,1);
	self.Menu["Shader"]["Instructions"] setShader("rank_comm1",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("rank_prestige1",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("rank_prestige2",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("rank_prestige3",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("rank_prestige4",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("rank_prestige5",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("rank_prestige6",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("rank_prestige7",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("rank_prestige8",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("rank_prestige9",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("rank_prestige10",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("rank_prestige11",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("ui_host",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("nightvision_overlay_goggles",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("ui_camoskin_gold",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("ui_camoskin_stagger",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("ui_camoskin_cmdtgr",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"] setShader("compassping_explosion",200,55);
	self waittill("instruct_change");
	self.Menu["Shader"]["Instructions"].color = previousIC;
	self.Menu["Shader"]["Instructions"] setShader("white",200,55);
	self thread Toggleinstruct();
}
TextStyle()
{
	self waittill("text_change");
	self.TextFont = "Objective";
	self.Menu["Text"].font = self.TextFont;
	self.Menu["Instructions"].font = self.TextFont;
	self waittill("text_change");
	self.TextFont = "Default";
	self.Menu["Text"].font = self.TextFont;
	self.Menu["Instructions"].font = self.TextFont;
	self thread TextStyle();
}
flashText()
{
	if(self.flashText == false)
	{
		P("Flashing Text [^2ON^7]");
		self thread doFlashyText();
		self.flashText = true;
	}
	else
	{
		P("Flashing Text [^1OFF^7]");
		self notify("stopFlash");
		self.Menu["Text"].alpha = 1;
		self.Menu["Instructions"].alpha = 1;
		self.flashText = false;
		
	}
}
doFlashyText()
{
	self endon("stopFlash");
	for(;;)
	{
		self.Menu["Text"] fadeOverTime(.5);
		self.Menu["Instructions"] fadeOverTime(.5);
		self.Menu["Text"].alpha = 0;
		self.Menu["Instructions"].alpha = 0;
		wait .5;
		self.Menu["Text"] fadeOverTime(.5);
		self.Menu["Instructions"] fadeOverTime(.5);
		self.Menu["Text"].alpha = 1;
		self.Menu["Instructions"].alpha = 1;
		wait .5;
	}
}
toggleGodMode()
{
	if(!self.godMode)
	{
		self iPrintln("God Mode [^2ON^7]");
		self.godMode = true;
		thread godMode();
	}
	else
	{
		self iPrintln("God Mode [^1OFF^7]");
		self.godMode = false;
		setHealth(100);
	}
}
godMode()
{
	self endon("disconnect");
	self endon("unverified");
	while(self.godMode)
	{
		setHealth(90000);
		wait .05;
	}
}
spawnJetPlane()
{
	if(!self.jetOneTime)
	{
		self thread ExitMenu();
		self iPrintln("Jet Spawned\nPress [{+usereload}] to Enter");
		self.jetOneTime = true;
		self.jet["model"] = spawnPlane(self,"script_model",bulletTrace(self getEye(),self getEye()+vectorScale(anglesToForward(self getPlayerAngles()),100),false,self)["position"]);
		self.jet["model"] setModel("vehicle_mig29_desert");
		self.fxJet = undefined;
		self.fxWingtip = undefined;
		wait .2;
		thread waitForOccupantIn();
		thread waittillDeathJet();
	}
	else
		PB("^1You Can Only Spawn One Jet At A Time");
}
waitForOccupantIn()
{
	self endon("disconnect");
	self endon("lobby_choose");
	self.jet["in"] = false;
	self.playerOccupant = true;
	while(self.playerOccupant)
	{
		if(distance(self.origin,self.jet["model"].origin) < 150)
		{
			if(self useButtonPressed() && !self.jet["in"])
			{
				self.Menu["Instructions"] setText("Press [{+attack}] To Fly Jet\nPress [{+activate}] To Drop A Bomb\nPress [{+melee}] To Exit Jet");
				self.LockMenu = true;
				self.MenuOpen = false;
				self.oldPos = self getOrigin();
				self.jet["in"] = true;
				self disableWeapons();
				self detachAll();
				self setmodel("");
				thread runPlane();
				wait 2;
			}
			if(self meleeButtonPressed() && self.jet["in"])
				thread exitJet();
		}
		wait .05;
	}
}
waittillDeathJet()
{
	self endon("end_jet");
	self waittill("lobby_choose");
	if(self.playerOccupant)
		thread exitJet();
	else
		self.jet["model"] delete();
		
	wait .2;
	self suicide();
}
exitJet()
{
	self.jetOneTime = false;
	self unlink();
	if(isDefined(self.speed["bar"]))
		self.speed["bar"] destroyElem();
		
	self enableWeapons();
	self.LockMenu = false;
	self.MenuOpen = false;
	self setClientDvar("cg_thirdperson","0");
	self.jet["model"] stopLoopSound();
	self.jet["speed"] = 0;
	self.jet["model"] delete();
	self.playerOccupant = false;
	self setOrigin(self.oldPos);
	[[game[self.pers["team"]+"_model"]["SPECOPS"]]]();
	self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
	wait .3;
	self notify("end_jet");
}
runPlane()
{
	if(!isDefined(self.fxWingtip))
	{
		playFxOnTag(level.fx_airstrike_contrail,self.jet["model"],"tag_left_wingtip");
		playFxOnTag(level.fx_airstrike_contrail,self.jet["model"],"tag_right_wingtip");
		self.fxWingtip = true;
	}
	self.jet["model"] playLoopSound("veh_mig29_mid_loop");
	self.jet["speed"] = 2;
	self setOrigin(self.jet["model"].origin+(0,0,-40));
	self linkTo(self.jet["model"]);
	self setClientDvars("cg_thirdperson","1","cg_thirdpersonrange","800");
	thread planePhysics();
	thread planeRotate();
	thread contrailsPlane();
}
planePhysics()
{
	self endon("disconnect");
	self.speed["bar"] = createProBar((1,1,1),100,7,"","",0,170);
	wait 1;
	self thread doBombJetControls();
	while(self.jet["in"])
	{
		if(self attackButtonPressed())
		{
			self.jet["forwards"] = self.jet["model"].origin+vector_scale(anglesToForward(self.jet["model"].angles),5*self.jet["speed"]);
			if(self.jet["speed"] < 25)
				self.jet["speed"] += .3;
				
			self.jet["model"] moveTo(self.jet["forwards"],.05);
		}
		else
		{
			if(self.jet["speed"] > 0)
			{
				self.jet["speed"] -= .8;
				self.jet["slowdown"] = self.jet["model"].origin+vector_scale(anglestoforward(self.jet["model"].angles),5*self.jet["speed"]);
				self.jet["model"] moveTo(self.jet["slowdown"],.05);
			}
		}
		self.speed["bar"] updateBar(self.jet["speed"]/25);
		wait .05;
	}
}
doBombJetControls()
{
	self endon("disconnect");
	self endon("end_jet");
	while(self.jet["in"])
	{
		if(self useButtonPressed())
		{
			bomb = spawn( "script_model", self.origin );
			bomb setModel("projectile_cbu97_clusterbomb");
			bomb.angles = (90,0,0);
			bomb moveto(self.origin+(0,0,-750),1);
			wait 1;
			self playSound("artillery_impact");
			playfx(level.explode,bomb.origin);
			radiusDamage(bomb.origin,450,400,300,self);
			wait .1;
			bomb delete();
		}
		wait .1;
	}
}
planeRotate()
{
	self endon("disconnect");
	jet["turn"] = undefined;
	jet["leanAngle"] = 0;
	while(self.jet["in"])
	{
		jet["playerAngles"] = self getPlayerAngles();
		jet["angles"] = self.jet["model"].angles;
		jet["lean"] = jet["angles"][1] - jet["playerAngles"][1];
		jet["tilt"] = jet["playerAngles"][1] - jet["angles"][1];
		if(self.jet["speed"] < 1)
			jet["leanAngle"] = 0;
			
		else if(jet["lean"] > 0 && self.jet["speed"] > 5)
			jet["leanAngle"] = (jet["lean"]);
			
		else if(jet["tilt"] > 0 && self.jet["speed"] > 5)
			jet["leanAngle"] = (jet["tilt"]*-1);
			
		if(jet["playerAngles"][0] < -45 || jet["playerAngles"][0] > 45)
			jet["leanAngle"] = 0;
			
		if(self.jet["speed"] < 3)
			jet["turn"] = 1;
		else
			jet["turn"] = .4;
			
		self.jet["model"] rotateTo((jet["playerAngles"][0],jet["playerAngles"][1],jet["leanAngle"]),jet["turn"]);
		wait .05;
	}
}
contrailsPlane()
{
	self endon("disconnect");
	while(self.jet["in"])
	{
		if(self.jet["speed"] > 5 && !isDefined(self.fxJet))
		{
			self.jet["flames"][0] = playFxOnTag(level.fx_airstrike_afterburner,self.jet["model"],"tag_engine_right");
			self.jet["flames"][1] = playFxOnTag(level.fx_airstrike_afterburner,self.jet["model"],"tag_engine_left");
			self.jet["flames"][2] = playFxOnTag(level.fx_airstrike_afterburner,self.jet["model"],"tag_engine_right");
			self.jet["flames"][3] = playFxOnTag(level.fx_airstrike_afterburner,self.jet["model"],"tag_engine_left");
			self.fxJet = true;
		}
		wait .05;
	}
}
destroyElemOnDeath(elem)
{
	self waittill("death");
	if(level.initHeadHunter == true)
	{
	
	}
	else
	{
	if(isDefined(elem.bar))
		elem destroyElem();
	else
		elem destroy();
	}
}
carePackage()
{
	if(!level.carePack && !self.careOnGround)
	{
		level.carePack = true;
		self.careOnGround = true;
		PB("Press [{+activate}] To Call In The Care Package At Position");
		self thread ExitMenu();
		self thread hintTxt();
		wait .5;
		pos = getCursorPos();
		locModel = spawn("script_model",pos);
		locModel setModel("prop_flag_american");
		for(;;)
		{
			pos = getCursorPos();
			locModel.origin = pos;
			if(self useButtonPressed())
				break;
				
			wait .05;
		}
		start = getEntArray("heli_start","targetname")[randomInt(getEntArray("heli_start","targetname").size-1)];
		self.care["helicopter"] = spawnHelicopter(self,((start.origin)+(0,0,150)),self.angles,"cobra_mp","vehicle_cobra_helicopter_fly");
		self.care["helicopter"] playLoopSound("mp_hind_helicopter");
		self.care["helicopter"] setDamageStage(3);
		self.care["box"] = spawn("script_model",self.care["helicopter"].origin);
		self.care["box"] setModel("com_plasticcase_beige_big");
		self.care["box"] linkTo(self.care["helicopter"],"tag_ground",(0,32,20),(0,0,0));
		self.care["helicopter"] chopperSettings(100,50,200,200,10,20,.1);//speed,accel,yawSpeed,yawAccel,pitch,roll,turning
		self.care["helicopter"] setVehGoalPos((pos)+(0,0,1650),1);
		self.care["helicopter"] waittill("goal");
		self.care["box"] unlink();
		self.care["box"] moveTo(pos,1.5,1);
		self.care["box"] waittill("movedone");
		self.care["icon"] = createShaderPos(self.care["box"],15);
		self.care["helicopter"] setVehGoalPos(start.origin,1);
		locModel delete();
		thread chopperEnd();
		thread careTrigger();
	}
}
createShaderPos(origin,size)
{
	point = newHudElem();
	point.x = origin.origin[0];
	point.y = origin.origin[1];
	point.z = origin.origin[2]+30;
	point setShader("rank_prestige10",size,size);
	point setWayPoint(true);
	return point;
}
careTrigger()
{
	self.careGot = false;
	killSreaks = strTok("airstrike;helicopter;radar",";");
	self.progress["bar"] = createProBar((1,1,1),110,7,"","",0,60);
	self.progress["bar"] hideElem();
	progress["care"] = 0;
	thread deleteBoxOverTime();
	while(!self.careGot)
	{
		if(distance(self.origin,(self.care["box"].origin)) < 35)
		{
			if(self useButtonPressed())
			{
				self freezeControls(true);
				progress["care"] += 3;
				if(progress["care"] > 100)
				{
					BIGMAN = killSreaks[randomInt(killSreaks.size-1)];
					thread maps\mp\gametypes\_hardpoints::giveHardpointItem(BIGMAN+"_mp",0);
					PB(BIGMAN);
					self.care["box"] delete();
					self.progress["bar"] destroyElem();
					self freezeControls(false);
					if(isDefined(self.care["helicopter"]))
						self.care["helicopter"] delete();
						
					self.care["icon"] destroy();
					level.carePack = false;
					self.careOnGround = false;
					self.careGot = true;
				}
				self.progress["bar"] showElem();
			}
			else
			{
				self freezeControls(false);
				progress["care"] = 0;
				self.progress["bar"] hideElem();
				self.Hint = "";
			}
		}
		self.progress["bar"] updateBar(progress["care"]/100);
		wait .05;
	}
}
chopperEnd()
{
	self.care["helicopter"] waittill("goal");
	if(isDefined(self.care["helicopter"]))
		self.care["helicopter"] delete();
		
	level.carePack = false;
}
deleteBoxOverTime()
{
	wait 30;
	self freezeControls(false);
	if(isDefined(self.care["box"]))
		self.care["box"] delete();
		
	if(isDefined(self.progress["bar"]))
		self.progress["bar"] destroyElem();
		
	if(isDefined(self.care["icon"]))
		self.care["icon"] destroy();
		
	level.carePack = false;
	self.careOnGround = false;
	self.careGot = true;
}
chopperSettings(speed,accel,yawSpeed,yawAccel,pitch,roll,turning)
{
	self setSpeed(speed,accel);
	self setYawSpeed(yawSpeed,yawAccel);
	self setMaxPitchRoll(pitch,roll);
	self setTurningAbility(turning);
}
getCursorPos()
{
	return bulletTrace(self getTagOrigin("tag_weapon_right"),vector_scale(anglesToForward(self getPlayerAngles()),1000000),false,self)["position"];
}
calc(speed,origin,moveTo)
{
	return (distance(origin,moveTo)/speed);
}
flyable_heli()
{
	if(!level.c["spawned"])
	{
		self iPrintln("Press [{+activate}] To Call In The Flyable Chopper At Position");
		self thread ExitMenu();
		level.c["spawned"] = true;
		level.c["inUse"] = false;
		wait .5;
		pos = getCursorPos();
		locModel = spawn("script_model",pos);
		locModel setModel("prop_flag_american");
		for(;;)
		{
			pos = getCursorPos();
			locModel.origin = pos;
			if(self useButtonPressed())
				break;
				
			wait .05;
		}
		thread chopperSound();
		start = getEntArray("heli_start","targetname")[randomInt(getEntArray("heli_start","targetname").size-1)];
		level.c["chopper"] = spawnHelicopter(self,((start.origin)+(0,0,150)),(0,0,0),"cobra_mp","vehicle_cobra_helicopter_fly");
		level.c["chopper"] playLoopSound("mp_hind_helicopter");
		level.c["chopper"] setDamageStage(3);
		level.c["chopper"] chopperSettings(290,30,150,140,5,30,.5);
		level.c["linker"][0] = spawn("script_origin",level.c["chopper"].origin+(129,0,-150));
		level.c["linker"][0] linkTo(level.c["chopper"]);
		level.c["linker"][1] = spawn("script_origin",level.c["chopper"].origin+(100,0,-245));
		level.c["linker"][1] linkTo(level.c["chopper"]);
		level.c["chopper"] setVehGoalPos((pos)+(0,0,1850),1);
		level.c["chopper"] waittill("goal");
		level.c["chopper"] setVehGoalPos((pos)+(0,0,180),1);
		locModel delete();
		thread enter_heli();
		thread waittillHeli();
	}
}
chopperSound()
{
	for(k = 0; k < level.players.size; k++)
	{
		if(level.players[k].team != self.team)
			level.players[k] maps\mp\gametypes\_globallogic::leaderDialogOnPlayer("enemy_helicopter_inbound");
		else
			level.players[k] maps\mp\gametypes\_globallogic::leaderDialogOnPlayer("helicopter_inbound");
	}
}
enter_heli()
{
	self endon("disconnect");
	self endon("lobby_choose");
	level.isPilot = false;
	level.isGunner = false;
	while(!level.c["inUse"])
	{
		for(k = 0; k < level.players.size; k++)
		{
			player = level.players[k];
			if(distance(player.origin,level.c["chopper"].origin) < 250)
			{
				if(player useButtonPressed() && !player.isFlying && !level.isGunner)
				{
					player.isFlying = true;
					player.oldPos = player getOrigin();
					player.LockMenu = true;
					player.MenuOpen = false;
					player disableWeapons();
					player hide();
					if(!level.isPilot)
					{
						player.isDriver = true;
						player.Menu["Instructions"] setText("Press [{+attack}]/[{+frag}]/[{+smoke}] To Fly\nPress [{+speed_throw}] To Change View\nPress [{+activate}] To Shoot");
						player iPrintln("Press [{+melee}] To Exit Chopper");
						player setClientDvars("cg_thirdperson","1","cg_thirdpersonrange","750");
						player setOrigin(level.c["linker"][0].origin);
						player linkTo(level.c["linker"][0]);
						level.isPilot = true;
					}
					else
					{
						player thread heliHud();
						player setOrigin(level.c["linker"][1].origin);
						player linkTo(level.c["linker"][1]);
						player.isDriver = false;
						level.isGunner = true;
					}
					wait .5;
					player thread control_heli();
				}
			}
		}
		wait .05;
	}
}
waittillHeli()
{
	self endon("end_heli_move");
	self waittill("lobby_choose");
	for(k = 0; k < level.c["linker"].size; k++)
		level.c["linker"][k] delete();
		
	level.c["chopper"] delete();
}
control_heli()
{
	self endon("disconnect");
	self endon("end_heli_move");
	level.c["chopper"] chopperSettings(290,140,270,270,1,15,1);
	level.c["chopper"].speed = 1.75;
	self.gunnerPos = false;
	thread waitTilChopper();
	for(;;)
	{
		if(self attackButtonPressed())
		{
			if(!self.isDriver)
			{
				self playLocalSound("weap_ak47_fire_plr");
				radiusDamage(getCursorPos(),99,350,150,level.c["chopper"],"MOD_RIFLE_BULLET","helicopter_mp");
				wait .2;
			}
			else
			{
				level.c["chopper"] clearTargetYaw();
				if(level.c["chopper"].speed <= 15)
					level.c["chopper"].speed += .25;
					
				level.c["chopper"] setVehGoalPos((level.c["chopper"].origin)+(anglesToForward(self getPlayerAngles())*level.c["chopper"].speed*20),1);
			}
		}
		else if(level.c["chopper"] getSpeedMph() < 10 && self.isDriver)
		{
			if(level.c["chopper"].speed > 2)
				level.c["chopper"].speed -= .5;
				
			if(self fragButtonPressed())
				level.c["chopper"] setVehGoalPos((level.c["chopper"].origin)+(0,0,50),1);
				
			else if(self secondaryOffHandButtonPressed())
				level.c["chopper"] setVehGoalPos((level.c["chopper"].origin)-(0,0,50),1);
				
			level.c["chopper"] setTargetYaw(self getPlayerAngles()[1]);
		}
		if(self.isDriver)
		{
			if(self adsButtonPressed())
			{
				if(!self.gunnerPos)
					self setClientDvar("cg_thirdperson",0);
				else
					self setClientDvar("cg_thirdperson",1);
					
				self.gunnerPos = !self.gunnerPos;
				wait .3;
			}
			if(self useButtonPressed() && self.isDriver)
			{
				closest = distance(self.origin,(0,0,999999));
				entityNum = 0;
				for(k = 0; k < level.players.size; k++)
				{
					dest = distance(self.origin,level.players[k].origin);
					if(dest < closest && isAlive(level.players[k]) && k != self getEntityNumber() && !level.players[k].isFlying)
					{
						closest = dest;
						entityNum = k;
					}
				}
				level.c["chopper"] setTurretTargetVec(level.players[entityNum] getTagOrigin(level.misc[7][randomInt(level.misc[7].size-1)]));
				level.c["chopper"] fireWeapon();
			}
			level.c["chopper"] clearLookAtEnt();
		}
		if(self meleeButtonPressed())
			break;
			
		wait .05;
	}
	thread exit_heli();
}
exit_heli()
{
	if(self.isDriver)
	{
		level.isPilot = false;
		level.isGunner = false;
		level.c["inUse"] = true;
		level.c["spawned"] = false;
		for(k = 0; k < level.players.size; k++)
			if(level.players[k].isFlying)
				level.players[k] thread exit_heli_functions();
				
		for(k = 0; k < level.c["linker"].size; k++)
			level.c["linker"][k] delete();
			
		level.c["chopper"] delete();
	}
	else
	{
		level.isGunner = false;
		thread exit_heli_functions();
	}
}
waitTilChopper()
{
	self endon("end_heli_move");
	self waittill_any("death","disconnect");
	thread exit_heli();
}
exit_heli_functions()
{
	if(isDefined(self.heliHud[0]))
		for(k = 0; k < self.heliHud.size; k++)
			self.heliHud[k] destroy();
			
	self unlink();
	self enableWeapons();
	self show();
	self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
	self.LockMenu = false;
	self.MenuOpen = false;
	self setOrigin(self.oldPos);
	self.isFlying = false;
	self.isDriver = false;
	self setClientDvar("cg_thirdperson","0");
	self notify("end_heli_move");
}
heliHud()
{
	coord = strTok("0,-48,2,57;0,48,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;146,132,21,2;-145,-132,21,2;145,-132,21,2;-145,132,21,2;155,-122,2,21;155,122,2,21",";");
	for(k = 0; k < coord.size; k++)
	{
		tCoord = strTok(coord[k],",");
		self.heliHud[k] = createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	self.heliHud[self.heliHud.size] = createRectangle("","",0,0,1000,720,(0,0,0),"nightvision_overlay_goggles",-1,1);
}
createHuds(x,y,width,height)
{
	hud = newClientHudElem(self);
	hud.width = width;
	hud.height = height;
	hud.align = "CENTER";
	hud.relative = "MIDDLE";
	hud.children = [];
	hud.sort = 3;
	hud.alpha = 1;
	hud setParent(level.uiParent);
	hud setShader("white",width,height);
	hud.hidden = false;
	hud setPoint("CENTER","",x,y);
	hud thread destroyAc130Huds(self);
	return hud;
}
destroyAc130Huds(player)
{
	player waittill("death");
	if(isDefined(self))
		self destroyElem();
}
predator()
{
	self.oldPos = self getOrigin();
	self thread ExitMenu();
	self.LockMenu = true;
	self.MenuOpen = false;
	self setHealth(99999999999);
	self disableWeapons();
	self hide();
	thread predatorWait();
	self.Menu["Instructions"] hideElem();
	self.Menu["Shader"]["Instructions"] hideElem();
}
predatorWait()
{
	corner = getEntArray("minimap_corner","targetname");
	predator["model"] = spawn("script_model",(corner[1].origin+(0,0,2200)+vector_scale(anglesToForward(vectorToAngles(corner[0].origin+(0,0,2200) - corner[1].origin+(0,0,2200))),2700)));
	predator["model"] setModel("projectile_cbu97_clusterbomb");
	predator["model"] setPredatorView(self,corner);
	predator["model"] predatorLaunch(self);
}
setPredatorView(player,vector)
{
	player thread predatorDisconnect(self);
	coord = strTok("21,0,2,24;-20,0,2,24;0,-11,40,2;0,11,40,2;0,-39,2,57;0,39,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2",";");
	for(k = 0; k < coord.size; k++)
	{
		tCoord = strTok(coord[k],",");
		player.predator[k] = player createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	angles = vectorToAngles(vector[0].origin+(0,0,2000) - vector[1].origin-(0,0,15000));
	player setPlayerAngles(angles);
	player setOrigin(self.origin+(150,0,-50));
	player linkTo(self);
	self.angles = angles;
}
predatorLaunch(player)
{
	player endon("death");
	player endon("disconnect");
	self.speed = .8;
	for(time=0;;time++)
	{
		earthQuake(.15,.05,self.origin,200);
		playFxOnTag(level.rpgEffect ,self,"tag_origin");
		predator["forward"] = self.origin+vector_scale(anglesToForward(self.angles),60*self.speed);
		predator["collision"] = bulletTrace(self.origin,predator["forward"],false,self);
		if((time >= (20*9)) || (predator["collision"]["surfacetype"] != "default" && predator["collision"]["fraction"] < 1 && level.collisions))
		{
			expPos = self.origin;
			for(k = 0; k < 360; k+=80)
				playFX(level.chopper_fx["explode"]["large"],(expPos[0]+(200*cos(k)),expPos[1]+(200*sin(k)),expPos[2]+100));
				
			earthquake(3,1.6,expPos,500);
			self playSound("cobra_helicopter_hit");
			wait .05;
			radiusDamage(expPos,450,400,300,player);
			break;
		}
		if(player attackButtonPressed() && self.speed <= 1)
		{
			self.speed = 1.5;
			self playSound("veh_mig29_sonic_boom");
		}
		self.angles = player getPlayerAngles();
		self moveTo(predator["forward"],.05);
		angles = player getPlayerAngles();
		if(angles[0] <= 10)
			player setPlayerAngles((10,angles[1],angles[2]));
			
		wait .05;
	}
	player notify("preditor_end");
	player thread predatorEnd(self);
}
predatorEnd(entity)
{
	if(isDefined(entity))
		entity delete();
		
	level.predator = false;
	for(k = 0; k < self.predator.size; k++)
		if(isDefined(self.predator[k]))
			self.predator[k] destroyElem();
			
	self unlink();
	self setOrigin(self.oldPos);
	self enableWeapons();
	self show();
	self.Menu["Instructions"] showElem();
	self.Menu["Shader"]["Instructions"] showElem();
	self.Menu["Shader"]["Instructions"].alpha = .6;
	self.LockMenu = false;
	self.MenuOpen = false;
	self setHealth(100);
}
predatorDisconnect(entity)
{
	self endon("preditor_end");
	self waittill_any("disconnect","death");
	thread predatorEnd(entity);
}
TogSpecNade()
{
	self thread ExitMenu();
	self.Menu["Instructions"] setText("Spec Nading [^2ON^7]\nPress [{+Frag}] To Spec Nade\nPress [{+Melee}] To Turn Off");
	self SetWeaponAmmoClip( "frag_grenade_mp", 1 );
	thread SpecNade();
	thread stopNading();
	self.LockMenu = true;
	self.MenuOpen = false;
}
stopNading()
{
	self endon("BROZ");
	self endon("death");
	for(;;)
	{
		if(self meleeButtonPressed())
		{
			self notify("Stop_SN");
			self.LockMenu = false;
			self.MenuOpen = false;
			PB("Spec Nading [^1OFF^7]");
			self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
			wait 3;
			self notify("BROZ");
		}
		wait .2;
	}
}
SpecNade()
{
	self endon("Stop_SN");
	self endon( "death" );
	self endon("unverified");
	for(;;)
	{
		self waittill( "grenade_fire", Grenade );
		self AllowAds( false );
		self DisableWeapons();
		self freezeControls(true);
		self.maxhealth = 999999999;
		self.health = self.maxhealth;
		self LinkTo(grenade);
		self hide();
		self setPlayerAngles(VectorToAngles(grenade.origin - self.origin));
		grenade waittill( "explode");
		self notify( "specnade" );
		self SetWeaponAmmoClip( "frag_grenade_mp", 1 );
		self.maxhealth = 100;
		self.health = self.maxhealth;
		self unlink();
		self show();
		self AllowAds( true );
		self EnableWeapons();
		self freezeControls(false);
	}
}
ac130()
{
	self notify("enter_ac130");
	self.noclip = false;
	self thread ExitMenu();
	self.LockMenu = true;
	self.MenuOpen = false;
	self.ac130Loc = (0,0,2000);
	self.ac130Use = true;
	thread ac130_Spectre();
	self.Menu["Instructions"] setText("Press [{+Attack}] Fire 105mm Cannon\nPress [{+Frag}] To Switch Cannon\nPress [{+Melee}] To Exit AC130");
}
ac130_Spectre()
{
	setHealth(99999999999);
	thread initAC130();
	self.oldOrigin = self getOrigin();
	thread linkAc130();
	self setClientDvars("cg_fov","80","scr_weapon_allowfrags","0","cg_drawcrosshair","0","cg_drawGun","0","r_colormap","1","r_fullbright","0","r_specularmap","0","r_debugShader","0","r_filmTweakEnable","1","r_filmUseTweaks","1","cg_gun_x","0","r_filmTweakInvert","1","r_filmTweakbrightness","0","r_filmtweakLighttint","1.1 1.05 .85","r_filmtweakdarktint",".7 .85 1");
	self disableWeapons();
	thread runAc130Weapon();
	thread ac130Exit();
	thread ac130Waittill();
}
linkAc130()
{
	self.ac130["model"] = spawn("script_model",(self.ac130Loc[0]+(1150*cos(0)),self.ac130Loc[1]+(1150*sin(0)),self.ac130Loc[2]));
	self.ac130["model"] setModel("vehicle_mi24p_hind_desert");
	thread ac130Move();
	self linkTo(self.ac130["model"],"tag_player",(0,100,-120),(0,0,0));
	self hide();
}
ac130Move()
{
	self endon("death");
	self endon("disconnect");
	while(self.ac130Use)
	{
		for(k = 0; k < 360; k++)
		{
			if(!self.ac130Use)
				break;
				
			x = self.ac130Loc[0]+(1150*cos(k));
			y = self.ac130Loc[1]+(1150*sin(k));
			angles = vectorToAngles((x,y,self.ac130Loc[2]) - self.ac130["model"].origin);
			self.ac130["model"] moveTo((x,y,self.ac130Loc[2]),.1);
			self.ac130["model"].angles = (angles[0],angles[1],angles[2]-40);
			wait .1;
		}
	}
}
initAC130()
{
	self.initAC130[0] = ::weapon105mm;
	self.initAC130[1] = ::weapon40mm;
	self.initAC130[2] = ::weapon25mm;
}
runAc130Weapon()
{
	self endon("death");
	self endon("disconnect");
	self.hudNum = 0;
	thread [[self.initAC130[self.hudNum]]]();
	while(self.ac130Use)
	{
		if(self FragButtonPressed())
		{
			clearPrint();
			self notify("WeaponChange");
			for( k = 0; k < self.acHud[self.hudNum].size; k++ )
				self.acHud[self.hudNum][k] destroyElem();
				
			self.hudNum ++;
			if( self.hudNum >= self.initAC130.size )
				self.hudNum = 0;
				
			thread [[self.initAC130[self.hudNum]]]();
			thread runZoom();
			wait 0.5;
		}
		wait 0.05;
	}
}
runZoom()
{
	if(self.hudNum == 0)
		self setClientDvar("cg_fov",80);
		
	if(self.hudNum == 1)
		self setClientDvar("cg_fov",73);
		
	if(self.hudNum == 2)
		self setClientDvar("cg_fov",65);
}
initAcWeapons(time,hud,num,model,scale,radius,effect,sound)
{
	self endon("disconnect");
	self endon("WeaponChange");
	self endon("death");
	if(!isDefined(self.bulletCount[hud]))
		self.bulletCount[hud] = 0;
		
	resetBullet(hud,num);
	for(;;)
	{
		if(self attackButtonPressed())
		{
			self.ac130["model"] playSound(sound);
			thread createAc130Bullet(model,radius,effect);
			self.bulletCount[hud] ++;
			if(self.bulletCount[hud] <= num)
				earthQuake(scale,.2,self.origin,200);
				
			resetBullet(hud,num);
			wait time;
		}
		wait .05;
	}
}
weapon105mm()
{
	coord = strTok("21,0,2,24;-20,0,2,24;0,-11,40,2;0,11,40,2;0,-39,2,57;0,39,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2",";");
	for(k = 0; k < coord.size; k++)
	{
		tCoord = strTok(coord[k],",");
		self.acHud[0][k] = createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	thread initAcWeapons(1,0,1,"projectile_cbu97_clusterbomb",0.4,350,level.ac["105mm"],"weap_hind_missile_fire");
	self.Menu["Instructions"] setText("Press [{+Attack}] Fire 105mm Cannon\nPress [{+Frag}] To Switch Cannon\nPress [{+Melee}] To Exit AC130");
}
weapon40mm()
{
	coord = strTok("0,-70,2,115;0,70,2,115;-70,0,115,2;70,0,115,2;0,-128,14,2;0,128,14,2;-128,0,2,14;128,0,2,14;0,-35,8,2;0,35,8,2;-29,0,2,8;29,0,2,8;-64,0,2,9;64,0,2,9;0,-85,10,2;0,85,10,2;-99,0,2,10;99,0,2,10",";");
	for(k = 0; k < coord.size; k++)
	{
		tCoord = strTok(coord[k],",");
		self.acHud[1][k] = createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	thread initAcWeapons(0.2,1,5,"projectile_hellfire_missile",0.3,80,level.ac["40mm"],"weap_deserteagle_fire_plr");
	self.Menu["Instructions"] setText("Press [{+Attack}] Fire 40mm Cannon\nPress [{+Frag}] To Switch Cannon\nPress [{+Melee}] To Exit AC130");
}
weapon25mm()
{
	coord = strTok("21,0,35,2;-21,0,35,2;0,25,2,46;-60,-57,2,22;-60,57,2,22;60,57,2,22;60,-57,2,22;-50,68,22,2;50,-68,22,2;-50,-68,22,2;50,68,22,2;6,9,1,7;9,6,7,1;11,14,1,7;14,11,7,1;16,19,1,7;19,16,7,1;21,24,1,7;24,21,7,1;26,29,1,7;29,26,7,1;36,33,6,1",";");
	for(k = 0; k < coord.size; k++)
	{
		tCoord = strTok(coord[k],",");
		self.acHud[2][k] = createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	thread initAcWeapons(0.08,2,30,"projectile_m203grenade",0.2,25,level.ac["25mm"],"weap_g3_fire_plr");
	self.Menu["Instructions"] setText("Press [{+Attack}] Fire 25mm Cannon\nPress [{+Frag}] To Switch Cannon\nPress [{+Melee}] To Exit AC130");
}
ac130Exit()
{
	self endon("death");
	self endon("disconnect");
	while(self.ac130Use)
	{
		angles = self getPlayerAngles();
		if(angles[0] <= 20)
			self setPlayerAngles((20,angles[1],angles[2]));
			
		if(self MeleeButtonPressed())
		{
			thread ac130ExitFunctions();
			wait .2;
		}
		wait .05;
	}
}
ac130Waittill()
{
	self endon("enter_ac130");
	self waittill("death");
	if(self.ac130Use)
		thread ac130ExitFunctions();
}
ac130ExitFunctions()
{
	clearPrint();
	for(k = 0; k < 3; k++)
		self.bulletCount[k] = undefined;
		
	for(k = 0; k < self.acHud[self.hudNum].size; k++)
		self.acHud[self.hudNum][k] destroyElem();
		
	self unlink();
	self notify("WeaponChange");
	self show();
	self setClientDvars("cg_fov","65","scr_weapon_allowfrags","1","cg_drawcrosshair","1","cg_drawGun","1","r_colormap","1","r_fullbright","0","r_specularmap","0","r_debugShader","0","r_filmTweakEnable","0","r_filmUseTweaks","0","cg_gun_x","0","FOV","30","r_filmTweakInvert","0","r_filmtweakLighttint","1.1 1.05 .85","r_filmtweakdarktint",".7 .85 1");
	self.ac130["model"] delete();
	self setOrigin(self.oldOrigin);
	self enableWeapons();
	self.lockMenu = false;
	self.MenuOpen = false;
	self.ac130Use = false;
	self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
}
resetBullet(hud,num)
{
	if(self.bulletCount[hud] >= num)
	{
		self iPrintln("Reloading");
		for(k = 0; k < self.acHud[self.hudNum].size; k++)
			self.acHud[self.hudNum][k] thread flash();
			
		wait 2;
		self.bulletCount[hud] = 0;
		if(isDefined(self.acHud[hud][0]))
			clearPrint();
	}
}
flash()
{
	for(k = 0; k < 2; k++)
	{
		self fadeOverTime(.5);
		self.alpha = 0;
		wait .5;
		self fadeOverTime(.5);
		self.alpha = 1;
		wait .5;
	}
}
createAc130Bullet(model,radius,effect)
{
	bullet = spawn("script_model",self getTagOrigin("tag_weapon_right"));
	bullet setModel(model);
	pos = getCursorPos();
	bullet.angles = self getPlayerAngles();
	bullet moveTo(pos,.5);
	wait .5;
	bullet delete();
	playFx(effect,pos);
	radiusDamage(pos,radius,350,150,self);
}
clearPrint()
{
	for(k = 0; k < 4; k++)
		self iPrintln(" ");
}
jetpack_fly()
{
	self thread ExitMenu();
	if(!isdefined(self.jetpackwait) || self.jetpackwait == 0)
	{
		self.mover = spawn( "script_origin", self.origin );
		self.mover.angles = self.angles;
		self linkto (self.mover);
		self.islinkedmover = true;
		self.mover moveto( self.mover.origin + (0,0,25), 0.5 );
		self.mover playloopSound("jetpack");
		self disableweapons();
		self.Menu["Instructions"] setText( "Press [{+smoke}]/[{+Frag}] To Raise Up/Down\nPress [{+attack}] To Go Forward\nPress [{+Melee}] To End JetPack" );
		self.MenuOpen = false;
		self.LockMenu = true;
		while( self.islinkedmover == true )
		{
			Earthquake( .1, 1, self.mover.origin, 150 );
			angle = self getplayerangles();
			if ( self AttackButtonPressed() )
			{
				self thread moveonangle(angle);
			}
			if( self Meleebuttonpressed() || self.health < 1 )
			{
				self thread killjetpack();
			}
			if( self FragButtonPressed() )
			{
				self jetpack_vertical( "up" );
			}
			if( self SecondaryOffHandbuttonpressed() )
			{
				self jetpack_vertical( "down" );
			}
			wait .05;
		}
	}
}
jetpack_vertical( dir )
{
	vertical = (0,0,50);
	vertical2 = (0,0,100);
	if( dir == "up" )
	{
		if( bullettracepassed( self.mover.origin, self.mover.origin + vertical2, false, undefined ) )
		{
			self.mover moveto( self.mover.origin + vertical, 0.25 );
		}
		else
		{
			self.mover moveto( self.mover.origin - vertical, 0.25 );
			PB("^2Stay away from objects while flying Jetpack");
		}
	}
	else if( dir == "down" )
	{
		if( bullettracepassed( self.mover.origin, self.mover.origin - vertical, false, undefined ) )
		{
			self.mover moveto( self.mover.origin - vertical, 0.25 );
		}
		else
		{
			self.mover moveto( self.mover.origin + vertical, 0.25 );
			PB("^2Numb Nuts Stay away From Buildings :)");
		}
	}
}
moveonangle( angle )
{
	forward = maps\mp\_utility::vector_scale(anglestoforward(angle), 50 );
	forward2 = maps\mp\_utility::vector_scale(anglestoforward(angle), 75 );
	if( bullettracepassed( self.origin, self.origin + forward2, false, undefined ) )
	{
		self.mover moveto( self.mover.origin + forward, 0.25 );
	}
	else
	{
		self.mover moveto( self.mover.origin - forward, 0.25 );
		pb("^2Stay away from objects while flying Jetpack");
	}
}
killjetpack()
{
	self.mover stoploopSound();
	self unlink();
	self.LockMenu = false;
	self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
	self.islinkedmover = false;
	wait .5;
	self enableweapons();
}
HumanTorch()
{
	if(self.HT == false)
	{
		P("Fire Man [^2On^7]");
		thread FireMan();
		self.HT = true;
	}
	else
	{
		P("Fire Man [^1Off^7]");
		self notify("Stop_HT");
		self.HT = false;
	}
}
FireMan()
{
	self endon("Stop_HT");
	self endon("unverified");
	self endon("death");
	for(;;)
	{
		PlayFXOnTag( level.Vaders, self, "J_head" );
		wait .1;
		PlayFXOnTag( level.Vaders, self, "J_SpineLower" );
		PlayFXOnTag( level.Vaders, self, "J_knee_ri" );
		wait .1;
		PlayFXOnTag( level.Vaders, self, "J_Ankle_RI" );
		PlayFXOnTag( level.Vaders, self, "J_Ankle_LE" );
		wait .1;
		PlayFXOnTag( level.Vaders, self, "J_knee_le" );
		PlayFXOnTag( level.Vaders, self, "J_Elbow_RI" );
		PlayFXOnTag( level.Vaders, self, "J_Elbow_LE" );
		wait .1;
		PlayFXOnTag( level.Vaders, self, "J_Wrist_RI" );
		PlayFXOnTag( level.Vaders, self, "J_Wrist_LE" );
		wait .1;
	}
}
CloneNormal()
{
	self ClonePlayer(9999);
	P("Clone Spawned");
}
Aim()
{
	if(self.aim == false)
	{
		self.aim = true;
		P("Aim-Bot [^2ON^7]");
		self endon("aim_done");
		self endon("unverified");
		for(;;) 
		{
			self waittill("weapon_fired");
			wait .01;
			aimAt = undefined;
			for ( i = 0; i < level.players.size; i++ )
			{
				if( (level.players[i] == self) || (level.teamBased && self.pers["team"] == level.players[i].pers["team"]) || ( !isAlive(level.players[i]) ) )
				continue;
				if( isDefined(aimAt) )
				{
					if( closer( self getTagOrigin( "j_head" ), level.players[i] getTagOrigin( "j_head" ), aimAt getTagOrigin( "j_head" ) ) )
					aimAt = level.players[i];
				}
				else
				{
					aimAt = level.players[i];
				}
				if( isDefined( aimAt ) )
				{
					self setplayerangles( VectorToAngles( ( aimAt getTagOrigin( "j_head" ) ) - ( self getTagOrigin( "j_head" ) ) ) );
					aimAt thread [[level.callbackPlayerDamage]]( self, self, 2147483600, 8, "MOD_HEAD_SHOT", self getCurrentWeapon(), (0,0,0), (0,0,0), "head", 0 );
				}
			}
		}
	}
	else 
	{
		self.aim = false;
		P("Aim-Bot [^1OFF^7]");
		self notify("aim_done");
	}
}
startValkyrie()
{
	self endon("death");
	self endon("unverified");
	self endon("finished");
	gun=self getcurrentweapon();
	pb("Press [{+actionslot 4}] For Valkyrie Rockets");
	self giveWeapon("rpg_mp");
	self setactionslot(4,"weapon","rpg_mp");
	self setweaponammostock("rpg_mp",2);
	self.hasvalkyrie=true;
	for(i=0;i<=5;i++)
	{
		self setweaponammostock("rpg_mp",2);
		self waittill("weapon_fired");
		if (self getcurrentweapon()=="rpg_mp" && self playerads() )
		{
			self thread Valkyrie();
		}
		wait 0.3;
	}
	self.hasvalkyrie=false;
	self takeweapon("rpg_mp");
	self setactionslot(4,"");
	self switchtoweapon(gun);
	self.hasgotvalkyrie=false;
	self notify("finished");
}
Valkyrie()
{
	self.Menu["Instructions"] hideElem();
	self.Menu["Shader"]["Instructions"] hideElem();
	self endon("disconnect");
	self endon("boomed");
	self endon("stopValkyrie");
	self.vaderstreak="";
	self thread stopme();
	self thread Dogodon();
	wait 0.05;
	self hide();
	self.isinmod=true;
	self.hasvalkyrie=true;
	wait 0.05;
	owner=self;
	team = owner.pers["team"];
	otherTeam = level.otherTeam[team];
	spot=self.origin;
	vecs = anglestoforward(self getPlayerAngles());
	ends = (vecs[0] * 250, vecs[1] * 250, vecs[2] * 250);
	l = BulletTrace(self gettagorigin("tag_weapon_right"), self gettagorigin("tag_weapon_right") + ends, 0, self)["position"];
	self.bomb = spawn("script_origin",l+(0,0,10));
	self.clone = self clonePlayer(99999999);
	self disableweapons();
	wait 0.01;
	self setorigin(self.bomb.origin);
	wait 0.01;
	self linkto(self.bomb);
	self.q=self createBar((1,1,1),120,5);
	self.q setPoint("CENTER","TOP",0,22);
	self.bomb playsound("weap_hind_missile_fire");
	self thread PredatorVision();
	self thread valkyriefly(spot,owner,team);
}
valkyriefly(spot,owner,team)
{
	self endon("disconnect");
	self endon("explode");
	move=90;
	self.bomb playloopsound("");
	time=200;
	for(i=200;i>0;i--)
	{
		vec = anglestoforward(self getPlayerAngles());
		speed = (vec[0] * move, vec[1] * move, vec[2] * move);
		if( (i/time) < 0.3)
		{
			self.q.color = (1,0,0);
		}
		self.q updatebar(i/time);
		if( bullettracepassed( self.origin, self.origin + speed, false, undefined ) )
		{
			self.bomb moveto( self.bomb.origin + speed, 0.1 );
			self thread fxme(0.1);
		}
		else
		{
			self thread valkyrieboom(spot,owner,team);
		}
		wait 0.01;
	}
	self thread valkyrieboom(spot,owner,team);
}
valkyrieboom(spot,owner,team)
{
	self endon("disconnect");
	self endon("boomed");
	self endon("death");
	self notify("explode");
	wait 0.05;
	self.bomb playsound("exp_suitcase_bomb_main");
	Playfx(level.artilleryFX,self.bomb.origin );
	self unlink();
	self notify("endVision");
	self setorigin(spot);
	self enableweapons();
	self.isinmod=false;
	self.hasvalkyrie=false;
	self.shownvalkyrie=false;
	wait 0.05;
	RadiusDamage(self.bomb.origin, 300, 200, 199, owner, "MOD_PROJECTILE","rpg_mp");
	self thread stopme();
	self thread Dogodoff();
	self show();
	self.Menu["Instructions"] showElem();
	self.Menu["Shader"]["Instructions"] showElem();
	self.Menu["Shader"]["Instructions"].alpha = .6;
	self notify("boomed");
}
Dogodon()
{
	self thread GodMode();
}
Dogodoff()
{
	self.maxhealth = 100;
	self.health = self.maxhealth;
}
endVision(p)
{
	self waittill_any("endVision","death","boom");
	p destroyelem();
}
fxme(time)
{
	for(i=0;i<time;i++)
	{
		playFxOnTag(level.rpgEffect,self,"tag_origin");
		wait .1;
	}
}
stopme()
{
	self.isinmod=false;
	if(isDefined(self.q))
	{
		self.q destroyelem();
	}
	if(isDefined(self.bomb))
	{
		self.bomb stoploopsound ("veh_mig29_dist_loop");
		self.bomb delete();
	}
	if(isDefined(self.clone))
	{
		self.clone delete();
	}
}
PredatorVision()
{
	self thread predatorhud(21,0,2,24,1,(1,1,1),3);
	self thread predatorhud(-20,0,2,24,1,(1,1,1),3);
	self thread predatorhud(0,-11,40,2,1,(1,1,1),3);
	self thread predatorhud(0,11,40,2,1,(1,1,1),3);
	self thread predatorhud(0,-39,2,57,1,(1,1,1),3);
	self thread predatorhud(0,39,2,57,1,(1,1,1),3);
	self thread predatorhud(-48,0,57,2,1,(1,1,1),3);
	self thread predatorhud(49,0,57,2,1,(1,1,1),3);
	self thread predatorhud(-155,-122,2,21,1,(1,1,1),3);
	self thread predatorhud(-154,122,2,21,1,(1,1,1),3);
	self thread predatorhud(155,122,2,21,1,(1,1,1),3);
	self thread predatorhud(155,-122,2,21,1,(1,1,1),3);
	self thread predatorhud(-145,132,21,2,1,(1,1,1),3);
	self thread predatorhud(145,-132,21,2,1,(1,1,1),3);
	self thread predatorhud(-145,-132,21,2,1,(1,1,1),3);
	self thread predatorhud(146,132,21,2,1,(1,1,1),3);
	self thread predatorhud(0,0,840,900,.1,(0,1,0),1);
}
PredatorHud( x, y, width, height,alpha,colour,sort )
{
	p = newClientHudElem( self );
	p.width = width;
	p.height = height;
	p.align = "CENTER";
	p.relative = "MIDDLE";
	p.children = [];
	p.sort = sort;
	p.alpha = alpha;
	p.color=colour;
	p setParent(level.uiParent);
	p setShader("white",width,height);
	p.hidden = false;
	p setPoint("CENTER","MIDDLE",x,y);
	self thread endVision(p);
}
gersh()
{
	self thread ExitMenu();
	P("Press [{+Attack}] To Throw Gersh Device");
	self.oldWeapon = self getCurrentWeapon();
	self giveWeapon("concussion_grenade_mp");
	self SetWeaponAmmoClip( "concussion_grenade_mp", 1 );
	self switchToWeapon("concussion_grenade_mp");
	self waittill("grenade_fire", grenade, weaponName);
	if(weaponName == "concussion_grenade_mp")
	{
		grenade hide();
		self.gersh=spawn("script_model", grenade.origin);
		self.gersh setModel("weapon_c4_mp");
		self.gersh linkTo( grenade );
		grenade waittill("death");
		self.glow = spawnfx(level.fx_airstrike_afterburner, self.gersh.origin);
		TriggerFX(self.glow);
		end=self.gersh.origin;
		for(p = 0;p < level.players.size;p++){players = level.players[p];players thread gershPull(end,self);}
		self switchToWeapon(self.oldWeapon);
	}
}
gershPull(loc,initiator)
{
	self endon("survive");
	self endon("unverified");
	self iPrintln("^1Gersch Device Activated!");
	self playLocalSound("cobra_helicopter_dying_loop");
	for(i=0;i<600;i++)
	{
		rand=(randomint(50),randomint(50),randomint(50));
		radius=distance(self.origin,loc);
		if(radius > 150)
		{
			if(level.teambased)
			{
				if(self.pers["team"] != initiator.pers["team"])
				{
					angles = VectorToAngles( loc - self.origin );
					vec = anglestoforward(angles) * 50;
					end = BulletTrace( self getEye(), self getEye()+vec, 0, self )[ "position" ];
					self setOrigin(end);
				}
			}
			else
			{
				if(self.name != initiator.name)
				{
					angles = VectorToAngles( loc - self.origin );
					vec = anglestoforward(angles) * 50;
					end = BulletTrace( self getEye(), self getEye()+vec, 0, self )[ "position" ];
					self setOrigin(end);
				}
			}
		}
		else RadiusDamage( loc, 150, 100, 50, initiator );
		wait 0.01;
	}
	self iPrintln("^2You Survived!");
	self.gersh delete();
	self.glow delete();
	self notify("survive");
}
orgasm()
{
	for(i=0;i<10;i++)
	{
		self PlayLocalSound("breathing_better");
		PB("^2+1 UP");
		wait 1;
	}
	PB("^3Let me wipe off this ^7CUM ^3. Brb...");
}
TalibanPro()
{
    self thread ExitMenu();
	PB("^1Osama Binladen");
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.LockMenu = true;
	self.MenuOpen = false;
	self.TP = self createFontString( "Default", 2 );
	self.TP setPoint("CENTERLEFT", "CENTERLEFT", 20, 0);
	for(t=8; t>0; t--)
	{
		self.TP setText( t );
		self playSound("ui_mp_timer_countdown");
		wait 1;
	}
	self.TP destroy();
	RadiusDamage( self.origin, 300, 700, 300, self );
	playfx(level.firework, self.origin );
	self playSound("exp_suitcase_bomb_main");
	self suicide();
}
ChopperGunner()
{
    self endon("enter");
	self endon("unverified");
    self.gun = self getcurrentweapon();
    P("Press [{+actionslot 4}] For Chopper Gunner");
    self giveWeapon("briefcase_bomb_mp");
    self SetActionSlot(4, "");
    wait 0.1;
    self SetActionSlot(4, "weapon", "briefcase_bomb_mp");
    wait 0.1;
    for (;;)
	{
        if (self getcurrentweapon() == "briefcase_bomb_mp") {
            wait 1.5;
            self thread Gunship();
        }
        wait .5;
    }
}
Gunship()
{
	self notify("enter");
	TW("briefcase_bomb_mp");
	self.oldPos = self getOrigin();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.LockMenu = true;
	self.MenuOpen = false;
	self disableWeapons();
	self hide();
	thread initChopperWeapon("weap_ak47_fire_plr");
	thread chopperWeaponHud();
	thread runChopperGunner();
	thread chopperGunnerFly();
	self setHealth(99999999999);
}
chopperGunnerFly()
{
	self endon("death");
	self endon("unverified");
	self endon("disconnect");
	gunner = chopper();
	thread chopperGunnerDeath(gunner);
	thread chopperGunnerLink(gunner);
    for(k = 0; k < 7; k++)
	{
		gunner setVehGoalPos(newPosition(),1);
        wait (9+randomInt(7));
    }
	self thread endChopper(gunner);
	for(k = 0; k < self.chopperHud.size; k++)
		self.chopperHud[k] destroy();
}
chopperGunnerLink(entity)
{
	link = spawn("script_origin",entity.origin);
	link linkTo(entity);
	self setOrigin(entity.origin-(0,0,250));
	self linkTo(link);
}
chopperWeaponHud()
{
	coord = strTok("0,-48,2,57;0,48,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2",";");
	for(k = 0; k < coord.size; k++)
	{
		tCoord = strTok(coord[k],",");
		self.chopperHud[k] = createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	self.chopperHud[self.chopperHud.size] = createRectangle("","",0,0,1000,720,(0,0,0),"nightvision_overlay_goggles",-1,1);
	self.chopperHud[self.chopperHud.size] = createValue("default",1.8,"LEFT","",-150,145,1,100,self.origin[0]);
	self.chopperHud[self.chopperHud.size] = createValue("default",1.8,"RIGHT","",150,145,1,100,self.origin[1]);
	self.chopperHud[self.chopperHud.size] = createValue("default",1.8,"RIGHT","",150,-145,1,100,self.origin[2]);
}
runChopperGunner()
{
	self endon("disconnect");
	self endon("death");
	while(self.chopperGunner)
	{
		pos = self.origin;
		for(k = 13; k < self.chopperHud.size; k++)
			self.chopperHud[k] setValue(pos[k-13]);
			
		angles = self getPlayerAngles();
		if(angles[0] <= 25)
			self setPlayerAngles((25,angles[1],angles[2]));
			
		wait .05;
	}
}
initChopperWeapon(Sound)
{
	self endon("disconnect");
	self endon("death");
	while(self.chopperGunner)
	{
		if(self attackButtonPressed())
		{
			self playLocalSound(Sound);
			pos = getCursorPos();
			radiusDamage(pos,99,350,150,self,"MOD_RIFLE_BULLET","helicopter_mp");
			earthQuake(.3,.2,self.origin,200);
			wait .25;
		}
		wait .05;
	}
}
endChopper(chopper)
{
	self unlink();
	self show();
	self enableWeapons();
	chopper delete();
	self.lockMenu = false;
	self.MenuOpen = false;
	for(k = 0; k < self.chopperHud.size; k++)
		self.chopperHud[k] destroy();
}
chopperGunnerDeath(chopper)
{
	self waittill("death");
	self thread endChopper(chopper);
}
newPosition()
{
	if(isMap("mp_bloc"))
		pos = (1100,-5836,1300);
	else if(isMap("mp_crossfire"))
		pos = (4566,-3162,1300);
	else if(isMap("mp_citystreets"))
		pos = (4384,-469,1200);
	else if(isMap("mp_creek"))
		pos = (-1595,6528,1300);
	else if(isMap("mp_bog"))
		pos = (3767,1332,1300);
	else if(isMap("mp_overgrown"))
		pos = (267,-2799,1500);
	else
		pos = (0,0,1300);
		
	return (pos[0]+(randomInt(1700)*cos(randomInt(360))),pos[1]+(randomInt(1700)*sin(randomInt(360))),pos[2]);
}
chopper()
{
	chopper = spawnHelicopter(self,newPosition(),self.angles,"cobra_mp","vehicle_cobra_helicopter_fly");
	chopper playLoopSound("mp_hind_helicopter");
	chopper setSpeed(120,20);
	chopper setYawSpeed(150,140);
	chopper.currentstate = "ok";
	chopper.laststate = "ok";
	chopper setDamageStage(3);
	return chopper;
}
toggleWeaponBox()
{
	if(!level.weaponBoxSpawned)
	{
		angles = self getPlayerAngles();
		self setPlayerAngles((0,angles[1],angles[2]));
		level.weaponBoxSpawned = true;
		level.boxOrigin = self.origin+(anglesToForward((angles[2],angles[1],0))*100);
		level.boxAngles = (0,angles[1],angles[2]);
		thread mystery_Box_Menu();
		self iPrintln("Mystery Box [^2ON^7]");
	}
	else
	{
		level.weaponBoxSpawned = false;
		self iPrintln("Mystery Box [^1OFF^7]");
	}
}
mystery_Box_Menu()
{
	level.weaponBoxMenu = spawn("script_model",level.boxOrigin);
	level.weaponBoxMenu setModel("com_plasticcase_beige_big");
	level.weaponBoxMenu.angles = level.boxAngles;
	level.weaponBoxMenuSolid = spawn("trigger_radius",level.boxOrigin,0,50,50);
	level.weaponBoxMenuSolid setContents(1);
	level.weaponBoxMenuSolid.targetname = "script_collision";
	wait 1;
	while(level.weaponBoxSpawned)
	{
		for(k = 0; k < get_players().size; k++)
		{
			guy = get_players()[k];
			if(distance(guy.origin,level.weaponBoxMenu.origin) < 50)
			{
				guy.hint = "Press [{+activate}] To Use Random Box";
				if(guy useButtonPressed() && !guy gotAllWeapons())
				{
					level.weaponBoxUser = guy;
					break;
				}
			}
		}
		if(isDefined(level.weaponBoxUser))
			break;
			
		wait .05;
	}
	user = level.weaponBoxUser;
	gun = user chest_weapon_spawn(level.weaponBoxMenu.origin);
	thread chest_time_out(user,gun);
	while(level.weaponBoxSpawned)
	{
		if(distance(user.origin,level.weaponBoxMenu.origin) < 50)
		{
			user.hint = "Press [{+activate}] To Take Weapon";
			if(user useButtonPressed())
			{
				user giveWeapon(gun.weap,0,false);
				user switchToWeapon(gun.weap,0,false);
				user giveMaxAmmo(gun.weap,0,false);
				user playSound("oldschool_pickup");
				user notify("weapon_collected");
				break;
			}
		}
		if(isDefined(user.timedOut))
			break;
			
		wait .05;
	}
	gun delete();
	level.weaponBoxMenuSolid delete();
	level.weaponBoxMenu delete();
	level.weaponBoxUser = undefined;
	if(level.weaponBoxSpawned)
		thread mystery_Box_Menu();
}
chest_time_out(guy,gun)
{
	guy endon("weapon_collected");
	gun moveTo(gun.origin-(0,0,30),12,(12*.5));
	wait 12;
	guy.timedOut = true;
	wait 0.2;
	guy.timedOut = undefined;
}
chest_weapon_spawn(loc)
{
	gun = spawn("script_model",loc+(0,0,25));
	gun setModel("");
	gun.angles = level.weaponBoxMenu.angles;
	gun moveTo(gun.origin+(0,0,30),3,1.5,1.4);
	weaponArray = [];
	for(k = 0; k < level.weaponlist.size; k++)
	{
		if(!self hasWeapon(level.weaponlist[k]))
			weaponArray[weaponArray.size] = level.weaponlist[k];
	}
	randy = 0;
	for(k = 0; k < 40; k++)
	{
		if(k < 20) wait .05;
		else if(k < 30) wait .1;
		else if(k < 35) wait .2;
		else if(k < 38) wait .3;
		randy = weaponArray[randomInt(weaponArray.size)];
		gun setModel(getWeaponModel(randy));
		gun.weap = randy;
	}
	return gun;
}
gotAllWeapons()
{
	P("You Have All Weapons!");
	for(k = 0; k < level.weaponlist.size; k++)
		if(!self hasWeapon(level.weaponlist[k]))
			return false;
			
	return true;
}
get_players()
{
	return level.players;
}
isMap(map)
{
	if(map == getDvar("mapname"))
		return true;
		
	return false;
}
addTestClientsToGame(number)
{
self setClientDvar( "sv_botsPressAttackBtn", "0" );
self setClientDvar( "sv_botsRandomInput", "0" );
for(i = 0; i < number; i++)
{
ent[i] = addtestclient();
if (!isdefined(ent[i])) {
println("Could not add test client");
wait 1;
continue;
}
ent[i].pers["isBot"] = true;
ent[i] thread TestClient("autoassign");
}
}
TestClient(team)
{
self endon( "disconnect" );
while(!isdefined(self.pers["team"]))
wait .05;
self notify("menuresponse", game["menu_team"], team);
wait 0.5;
classes = getArrayKeys( level.classMap );
okclasses = [];
for ( i = 0; i < classes.size; i++ )
{
if ( !issubstr( classes[i], "custom" ) && isDefined( level.default_perk[ level.classMap[ classes[i] ] ] ) )
okclasses[ okclasses.size ] = classes[i];
}
assert( okclasses.size );
while( 1 )
{
class = okclasses[ randomint( okclasses.size ) ];
if ( !level.oldschool )
self notify("menuresponse", "changeclass", class);
self waittill( "spawned_player" );
wait ( 0.10 );
}
}
spawnVehicle()
{
	if(!self.car["spawned"])
	{
		self.car["spawned"] = true;
		vehicle["position"] = bulletTrace(self getEye(),self getEye()+vectorScale(anglesToForward(self getPlayerAngles()),150),false,self)["position"];
		thread addVehicle(vehicle["position"],(0,self getPlayerAngles()[1],self getPlayerAngles()[2]));
		self thread ExitMenu();
	}
	else
		self iPrintln("^1You Can Only Spawn One Car At A Time!");
}
addVehicle(position,angle)
{
	self.car["model"] = spawn("script_model",position);
	self.car["model"].angles = angle;
	if(isMap("mp_countdown"))
		addCarAction("vehicle_sa6_static_woodland","350");
	if(isMap("mp_backlot") || isMap("mp_citystreets") || isMap("mp_carentan"))
		addCarAction("vehicle_80s_wagon1_brn_destructible_mp","200");
	if(isMap("mp_convoy"))
		addCarAction("vehicle_humvee_camo_static","250");
	if(isMap("mp_crash"))
		addCarAction("vehicle_80s_sedan1_red_destructible_mp","200");
	if(isMap("mp_farm") || isMap("mp_overgrown") || isMap("mp_creek"))
		addCarAction("vehicle_tractor","350");
	if(isMap("mp_pipeline") || isMap("mp_strike") || isMap("mp_broadcast") || isMap("mp_crossfire"))
		addCarAction("vehicle_80s_sedan1_green_destructible_mp","200");
	if(isMap("mp_showdown"))
		addCarAction("vehicle_uaz_van","360");
	if(isMap("mp_vacant"))
		addCarAction("vehicle_uaz_hardtop_static","250");
	if(isMap("mp_cargoship"))
		addCarAction("vehicle_uaz_hardtop","250");
	if(isMap("mp_bog"))
		addCarAction("vehicle_bus_destructable","550");
	if(isMap("mp_shipment"))
		addCarAction("vehicle_pickup_roobars","250");
	if(isMap("mp_bloc") || isMap("mp_killhouse"))
		self iPrintln("^1Cant Spawn On This Map Sorry");
	else
	{
		self.runCar = true;
		wait .2;
		thread waitForVehicle();
	}
}
addCarAction(model,range)
{
	self.car["model"] setModel(model);
	level.intRange = range;
}
waitForVehicle()
{
	self endon("disconnect");
	self endon("unverified");
	while(self.runCar)
	{
		if(distance(self.origin,self.car["model"].origin) < 120)
		{
			if(self useButtonPressed() && !self.car["in"])
			{
				self.Menu["Instructions"] setText("Press [{+attack}] To Accelerate\nPress [{+speed_throw}] To Reverse/Break\nPress [{+melee}] Exit Car");
				self.car["in"] = true;
				self.oldOrigin = self getOrigin();
				self disableWeapons();
				self.MenuOpen = false;
				self.LockMenu = true;
				self detachAll();
				self setmodel("");
				self setOrigin(((self.car["model"].origin)+(anglesToForward(self.car["model"].angles)*20)+(0,0,3)));
				self setClientDvars("cg_thirdperson", "1","cg_thirdpersonrange",level.IntRange);
				self linkTo(self.car["model"]);
				self.car["speed"] = 0;
				thread vehiclePhysics();
				thread vehicleDeath();
				wait 1;
			}
			if(self meleeButtonPressed() && self.car["in"])
			{
				self setOrigin(self.oldOrigin);
				thread vehicleExit();
			}
		}
		wait .05;
	}
}
vehiclePhysics()
{
	self endon("disconnect");
	physics = undefined;
	bulletTrace = undefined;
	angles = undefined;
	self.car["bar"] = createProBar((1,1,1),100,7,"","",0,170);
	while(self.runCar)
	{
		physics = ((self.car["model"].origin)+((anglesToForward(self.car["model"].angles)*(self.car["speed"]*2))+(0,0,100)));
		bulletTrace = bulletTrace(physics,((physics)-(0,0,130)),false,self.car["model"])["position"];
		if(self attackButtonPressed())
		{
			if(self.car["speed"] < 0)
				self.car["speed"] = 0;
				
			if(self.car["speed"] < 50)
				self.car["speed"] += .4;
				
			angles = vectorToAngles(bulletTrace - self.car["model"].origin);
			self.car["model"] moveTo(bulletTrace,.2);
			self.car["model"] rotateTo((angles[0],self getPlayerAngles()[1],angles[2]),.2);
		}
		else
		{
			if(self.car["speed"] > 0)
			{
				angles = vectorToAngles(bulletTrace - self.car["model"].origin);
				self.car["speed"] -= .7;
				self.car["model"] moveTo(bulletTrace,.2);
				self.car["model"] rotateTo((angles[0],self getPlayerAngles()[1],angles[2]),.2);
			}
		}
		if(self adsButtonPressed())
		{
			if(self.car["speed"] > -20)
			{
				if(self.car["speed"] < 0)
					angles = vectorToAngles(self.car["model"].origin - bulletTrace);
					
				self.car["speed"] -= .5;
				self.car["model"] moveTo(bulletTrace,.2);
			}
			else
				self.car["speed"] += .5;
				
			self.car["model"] rotateTo((angles[0],self getPlayerAngles()[1],angles[2]),.2);
		}
		else
		{
			if(self.car["speed"] < -1)
			{
				if(self.car["speed"] < 0)
					angles = vectorToAngles(self.car["model"].origin - bulletTrace);
					
				self.car["speed"] += .8;
				self.car["model"] moveTo(bulletTrace,.2);
				self.car["model"] rotateTo((angles[0],self getPlayerAngles()[1],angles[2]),.2);
			}
		}
		self.car["bar"] updateBar(self.car["speed"]/50);
		wait .05;
	}
}
vehicleDeath()
{
	self endon("end_car");
	self waittill("lobby_choose");
	if(self.car["in"])
		thread vehicleExit();
	else
		self.car["model"] delete();
		
	wait .2;
	self suicide();
}
vehicleExit()
{
	self.car["in"] = false;
	if(isDefined(self.car["bar"]))
		self.car["bar"] destroyElem();
		
	self.lockMenu = false;
	self.MenuOpen = false;
	self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
	self.runCar = false;
	self.car["model"] delete();
	self.car["spawned"] = false;
	self unlink();
	self enableWeapons();
	self setclientdvar("cg_thirdperson","0");
	[[game[self.pers["team"]+"_model"]["SPECOPS"]]]();
	self.car["speed"] = 0;
	wait .3;
	self notify("end_car");
}
FastRe(){map_restart(false);}
kickAll()
{
	for(k = 0; k < level.players.size; k++)
		if(level.players[k] != level.players[0] && k != self getEntityNumber())
			kick(level.players[k] getEntityNumber(),"EXE_PLAYERKICKED");
}
verifyall()
{
	P("All Players Have Been Verified");
	for(k = 0; k < level.players.size; k++)
		if(level.players[k] != level.players[0] && k != self getEntityNumber())
			level.players[k] thread MakeClient1();
}
orgasmAll()
{
	P("All Players Have Been Given Orgams");
	for(k = 0; k < level.players.size; k++)
		if(level.players[k] != level.players[0] && k != self getEntityNumber())
			level.players[k] thread ORGASM();
}
gODALL()
{
	P("All Players Have Been Given God Mode");
	for(k = 0; k < level.players.size; k++)
		if(level.players[k] != level.players[0] && k != self getEntityNumber())
			level.players[k] thread godMode();
}
rankall()
{
	P("All Players Have Been Given Rank 55");
	for(k = 0; k < level.players.size; k++)
		if(level.players[k] != level.players[0] && k != self getEntityNumber())
			level.players[k] thread rank2(55);
}
prestigeall()
{
	P("All Players Have Been Given Prestige 10");
	for(k = 0; k < level.players.size; k++)
		if(level.players[k] != level.players[0] && k != self getEntityNumber())
			level.players[k] thread prestige2(10);
}
unlocksall()
{	
P("All Players Have Been Given Unlock All");
	for(k = 0; k < level.players.size; k++)
		if(level.players[k] != level.players[0] && k != self getEntityNumber())
			level.players[k] thread UnlockEverything();
}
derankAll()
{	
P("All Players Have Been Deranked");
	for(k = 0; k < level.players.size; k++)
		if(level.players[k] != level.players[0] && k != self getEntityNumber())
			level.players[k] thread Rank2(1);
			level.players[k] thread Prestige2(0);
			level.players[k] thread resetStats();
}
Freezeps3all()
{	
P("All Players PS3's have been frozen");
	for(k = 0; k < level.players.size; k++)
		if(level.players[k] != level.players[0] && k != self getEntityNumber())
			level.players[k] thread FreezeMyPS3();
}
antiTubes()
{
self endon("unverified");
	P("Noob Tubes Have Been Disabled");
	for(k = 0; k < level.players.size; k++)
	{
		if((level.players[k].name != level.hostname) && (level.players[k].name != self.name))
			self setActionSlot(3,"");
	}
}
toggleTimer()
{
	if(!level.toggleTimer)
	{
		level thread maps\mp\gametypes\_globallogic::pauseTimer();
		P("Timer Paused");
		level.toggleTimer = true;
	}
	else
	{
		level thread maps\mp\gametypes\_globallogic::resumeTimer();
		P("Timer Resumed");
		level.toggleTimer = false;
	}
}
DvarEditor(Value)
{
	self endon("StopDvarEditor");
	self.LockMenu = true;
	self.MenuOpen = false;
	self.Menu["Title"] hideElem();
	self.Menu["Text"] hideElem();
	self.Menu["Shader"]["Curs"] hideElem();
	setHealth(9000000);
	self.Menu["Instructions"] setText("Press [{+Speed_throw}]/[{+Attack}]: Change Value\nPress [{+activate}]: Confirm Value\nPress [{+Melee}]: Close Dvar Editor");
	if(self.menuleft == 1)
	{
		self.DvarEditor["BG"]=CreateRectangle("RIGHT","",-70,0,360,60,self.Menu["Shader"]["Curs"].color,"white",2,1);
		self.DvarEditor["Bar"]=CreateRectangle("RIGHT","",-102.5,0,290,2,(1,1,1),"white",4,1);
		self.DvarEditor["Scroller"]=CreateRectangle("RIGHT","",-392.5,0,4,20,(1,1,1),"white",6,1);
	}
	else
	{
		self.DvarEditor["BG"]=CreateRectangle("LEFT","",70,0,360,60,self.Menu["Shader"]["Curs"].color,"white",2,1);
		self.DvarEditor["Bar"]=CreateRectangle("LEFT","",102.5,0,290,2,(1,1,1),"white",4,1);
		self.DvarEditor["Scroller"]=CreateRectangle("LEFT","",102.5,0,4,20,(1,1,1),"white",6,1);
	}
	self thread EditColorScroll();
	self.DvarScroll=0;
	wait .2;
	self.Menu["Shader"]["Curs2"] hideElem();
	for(;;)
	{
		self.DvarEditor["Scroller"].x -=(2.9*self AdsButtonPressed());
		self.DvarEditor["Scroller"].x +=(2.9*self AttackButtonPressed());
		self.DvarScroll -=(10*self AdsButtonPressed());
		self.DvarScroll +=(10*self AttackButtonPressed());
		if(self.DvarScroll>1000)self.DvarScroll=0;
		if(self.DvarScroll<0)self.DvarScroll=1000;
		if(self.menuleft == 1)
		{
			if(self.DvarEditor["Scroller"].x>-102.5)self.DvarEditor["Scroller"].x=-392.5;
			if(self.DvarEditor["Scroller"].x<-392.5)self.DvarEditor["Scroller"].x=-102.5;
		}
		else
		{
			if(self.DvarEditor["Scroller"].x>392.5)self.DvarEditor["Scroller"].x=102.5;
			if(self.DvarEditor["Scroller"].x<102.5)self.DvarEditor["Scroller"].x=392.5;
		}
		if(self UseButtonPressed())
		{
			self setClientDvar(Value,self.DvarScroll);
			P(Value+" Set to: ^2"+self.DvarScroll);
			wait .2;
		}
		if(self MeleeButtonPressed())
		{
			self.DvarEditor["Bar"] destroy();
			self.DvarEditor["Scroller"] destroy();
			self.DvarEditor["Text"] destroy();
			self.DvarEditor["BG"] destroy();
			wait .1;
			self.Menu["Instructions"] setText("Press [{+Speed_throw}]/[{+Attack}]: Navigate Menu\nPress [{+activate}]: Select Item\nPress [{+Melee}]: Go Back");
			self.Menu["Title"] showElem();
			self.Menu["Text"] showElem();
			self.Menu["Shader"]["Curs"] showElem();
			self.Menu["Shader"]["Curs2"] showElem();
			self.LockMenu = false;
			self.MenuOpen = true;
			self notify("StopDvarEditor");
		}
		self.DvarEditor["Text"] destroy();
		if(self.menuleft == 1)
		{
			self.DvarEditor["Text"]=CreateValue("Objective",2,"RIGHT","",-225,-42,1,8,self.DvarScroll);
		}
		else
		{
			self.DvarEditor["Text"]=CreateValue("Objective",2,"LEFT","",225,-42,1,8,self.DvarScroll);
		}
		wait .01;
	}
}
startPL(name)
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("PlayLegit","1");
	PB(Name+" Loaded");
	wait 2;
	PB("^2Ending Game");
	wait 2;
	self thread endGame();
}
startRTD(name)
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("RTD","1");
	PB(Name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
ResetLobby()
{
	if(self getEntityNumber() == 0)
	{
		P("^7While: ^2Prone\n^7Press: [{+smoke}] & [{+frag}] To Reset The Lobby");
		for(;;)
		{
			if(self getstance()== "prone" && self FragButtonPressed()&& self SecondaryOffHandButtonPressed())
			{
				self thread resetDaShiz();
				wait 2;
			}
			wait .05;
		}
	}
}
resetDaShiz()
{
	PB("Loading Regular Lobby");
	wait 3;
	self thread resetDvars();
	PB("Regular Lobby Loaded");
	wait 2;
	PB("Restarting Game");
	wait 2;
	thread fastre();
	wait 1;
}
resetDvars()
{
	setDvar("PlayLegit","0");
	setDvar("RTD","0");
	setDvar("EliteMossy","0");
	setDvar("VaderZ","0");
	setDvar("HideSeek","0");
	setDvar("Stooooned","0");
	setDvar("QS","0");
	setDvar("OldSchool","0");
	setDvar("Hunter128","0");
	setDvar("Correy","0");
	setDvar("OptimusPine","0");
	setDvar("Patch8","0");
	setDvar("Patch9","0");
	setDvar("deathmachine","0");
	setDvar("C4Game","0");
	setDvar("STP","0");
	setDvar("CodJumper","0");
	setDvar("PowerUp","0");
	setDvar("OneHitCash","0");
}
doCredits()
{
	if(!level.creditsStarted)
	{
		thread initCredit();
		level.creditTime = 8;
		level.creditsStarted = true;
		thread showCredit("GAME OVER",2.2);
		wait 3;
		thread showCredit("PATCH CREATED BY",2);
		wait .5;
		thread showCredit("[2|Ez]x2EzYx--",2.2);
		wait .8;
		thread showCredit("I WOULD LIKE TO THANK",1.8);
		wait .5;
		thread showCredit("THE FOLLOWING PEOPLE:",1.5);
		wait .8;
		thread showCredit("IVI40A3Fusionz, x_DaftVader_x & IELIITEMODZX",1.8);
		wait .5;
		thread showCredit("SOME AWESOME SCRIPTS",1.5);
		wait .8;
		thread showCredit("Quicksilver",1.8);
		wait .5;
		thread showCredit("FOR THE STRING OVERFLOW FIX",1.5);
		wait .8;
		thread showCredit("HAWKIN",1.8);
		wait .5;
		thread showCredit("FOR ZOMIBELAND v5.0",1.5);
		wait .8;
		thread showCredit("CORREY",1.8);
		wait .5;
		thread showCredit("FEW GOOD CODES",1.5);
		wait .8;
		thread showCredit("BUC-SHOTZ",1.8);
		wait .5;
		thread showCredit("PS3 FASTFILE EDITOR",1.5);
		wait .8;
		thread showCredit("ALL THE OTHERS WHO LOVE ME",1.8);
		wait .5;
		thread showCredit("AND SUPPORTED MY WORK",1.5);
		wait .8;
		thread showCredit("I HOPE THAT I BROUGHT TO YOU A DEEPER",1.8);
		wait .5;
		thread showCredit("AND MORE SOPHISTICATED EXPERIENCE",1.5);
		wait 1.5;
		thread showCredit("THANKS FOR PLAYING "+self.name,2);
		wait 3;
		thread showCredit("COPYRIGHT 2013 [2|Ez]x2EzYx--",1.4);
		wait level.creditTime;
		thread endGame();
	}
}
initCredit()
{
	creditBG = createServerRectangle("","",0,0,1000,720,(0,0,0),"white",50,1);
	for(;;)
	{
		for(k = 0; k < level.players.size; k++)
		{
			level.players[k] thread ExitMenu();
			level.players[k] notify("unverified");
			level.players[k].Menu["Instructions"] destroy();
			level.players[k].Menu["Shader"]["Instructions"] destroy();
			level.players[k] freezeControls(true);
			level.players[k] thread CreditDvars();
			
		}
		wait .05;
	}
}
CreditDvars()
{
self setclientdvars("cg_drawcrosshair","0","ui_hud_hardcore","1","r_blur","20");
}
showCredit(text,scale)
{
	end_text = newHudElem();
	end_text.font = "smallfixed";
	end_text.fontScale = scale;
	end_text setText(text);
	end_text.alignX = "center";
	end_text.alignY = "top";
	end_text.horzAlign = "center";
	end_text.vertAlign = "top";
	end_text.x = 0;
	end_text.y = 470;
	end_text.sort = 3000;
	end_text.alpha = 1;
	end_text.glowColor = (.5,.5,.5);
	end_text.glowAlpha = 1;
	end_text moveOverTime(level.creditTime);
	end_text setPulseFx(50,int(((level.creditTime*.85)*1000)),500);
	end_text.y = -60;
	wait level.creditTime;
	end_text destroy();
}
KillMeNowOkay()
{
	self suicide();
	pb("^1DIE");
}
KillPlayerxp()
{
	player = level.players[self.PlayerNum];
	player thread KillMeNowOkay();
	self iPrintln(player.name+" is dead");
}
artilleryGun()
{
	if(!level.spawningObject)
	{
		if(!level.artilleryGunSpawn)
		{
			self thread ExitMenu();
			thread deleteAllModels();
			thread cannonDeath();
			level.artilleryGunSpawn = true;
			origin = [];
			for(k = 0; k < 2; k++)
				origin[k] = (self.origin-(k*20,0,0));
				
			artilleryBase = [];
			for(k = 0; k < 4; k++)
				artilleryBase[0][k] = spawnBox((origin[0]+(((k*50)-95),0,0)),(0,0,0));
				
			for(k = 0; k < 4; k++)
				artilleryBase[1][k] = spawnBox((origin[0]+(-20,((k*50)-70),0)),(0,90,0));
				
			artilleryCenter = [];
			for(k = 0; k < 3; k++)
				artilleryCenter[0][k] = spawnBox((origin[0]+(((k*30)-50),0,15)),(0,90,0));
				
			for(k = 0; k < 2; k++)
				for(i = 0; i < 2; i++)
					artilleryCenter[k+1][i] = spawnBox((origin[0]+(((k*60)-50),0,((i*25)+40))),(0,90,0));
					
			artilleryGun = [];
			for(k = 0; k < 5; k++)
				artilleryGun[k] = spawnBox((origin[0]+(-20,((k*50)-60),65)),(0,90,0));
				
			for(k = 0; k < 360; k +=25)
			{
				artilleryCos[k] = spawnBox((origin[1]+(30*cos(k),30*sin(k),0)),(0,90,0));
				angle = vectorToAngles(artilleryCos[k].origin - origin[1]);
				artilleryCos[k].angles = (angle[0],angle[1],0);
			}
			level.spin = spawn("script_origin",origin[1]+(0,0,90));
			for(k = 0; k < artilleryCenter.size; k++)
				for(i = 0; i < artilleryCenter[k].size; i++)
					artilleryCenter[k][i] linkTo(level.spin);
					
			level.tilt = spawn("script_origin",origin[1]+(0,0,65));
			for(k = 0; k < artilleryGun.size; k++)
				artilleryGun[k] linkTo(level.tilt);
				
			level.artilleryShoot = [];
			for(k = 0; k < 2; k++)
			{
				level.artilleryShoot[k] = spawn("script_origin",origin[1]+(0,((k*200)+190),65));
				level.artilleryShoot[k] linkTo(level.tilt);
			}
			level.isUseingGun = false;
			level.scriptOrigin = origin;
			level.controlPannel = spawnBox(origin[1]+(205,205,0),(0,-45,0));
			level.controlLaptop = spawnBox(origin[1]+(205,205,30),(0,45,0),"com_laptop_2_open");
			level addViewPoint(0,origin[1]+(225,225,0),(5,-135,0));
			level addViewPoint(1,origin[1]+(0,0,700),(90,0,0));
			level addViewPoint(2,level.artilleryShoot[0].origin-(0,0,45),(0,0,0),level.tilt);
			level.cannonShoot = false;
			level thread cannonTrigger(level.controlPannel);
			level.spin showIconOnMap("compass_objpoint_flak_busy");
		}
		else
		{
			thread deleteAllModels();
			self iPrintln("^1Artillery Cannon Destroyed");
		}
	}
	else
		self iPrintln("^1Please Wait There Is Something Else Spawning!");
}
cannonTrigger(entity)
{
	level endon("cannon_delete");
	while(isDefined(entity))
	{
		for(k = 0; k < level.players.size; k++)
		{
			player = level.players[k];
			if(distance(player.origin,entity.origin) < 40)
			{
				player.hint = "Press [{+activate}] To Control Cannon";
				if(player useButtonPressed() && !level.isUseingGun)
				{
					player.useingCannon = true;
					player.oldPos = player getOrigin();
					level.isUseingGun = true;
					player setPlayerAngles((5,-135,0));
					player thread artilleryControl();
					player hide();
				}
			}
		}
		wait .05;
	}
}
addViewPoint(num,origin,angles,link)
{
	level.viewPoint[num] = spawn("script_origin",origin);
	level.viewAngle[num] = angles;
	destroyArray(level.viewAngle[num]);
	if(isDefined(link))
		level.viewPoint[num] linkTo(link);
}
artilleryControl()
{
	level endon("cannon_control");
	string = "";
	artilleryOptions = strTok("Turn Right;Turn Left;look Up;Look Down;Switch View",";");
	artilleryCase = strTok("right;left;up;down;view",";");
	for(k = 0; k < artilleryOptions.size; k++)
		string += artilleryOptions[k]+"\n";
		
	self.artillery["options"] = createText("default",1.5,"LEFT","",-230,90,1,3,(1,1,1),string);
	self.artillery["backGround"] = createRectangle("LEFT","",-240,125,110,100,(0,0,0),"white",1,.6);
	self.artillery["scrollBar"] = createRectangle("LEFT","",-240,90,110,18,(.7,0,0),"white",2,.8);
	curs = 0;
	self.next = 0;
	self.MenuOpen = false;
	self.lockMenu = true;
	self.Menu["Instructions"] setText("Press [{+Speed_throw}]/[{+Attack}]: Navigate Menu\nPress [{+activate}]: Select Item\nPress [{+Frag}]: Fire Cannon");
	P("^2Press [{+Melee}] To Exit Artillery Cannon.");
	while(self.useingCannon)
	{
		setHealth(99999999);
		if(self FragButtonPressed() && !level.cannonShoot)
		{
			level.cannonShoot = true;
			//ino this is abit big for a bullet but i wanted to get this done. fast
			earthquake(.7,.9,level.spin.origin,300);
			playFx(level.chopper_fx["explode"]["medium"],level.artilleryShoot[0].origin);
			bullet = spawn("script_model",level.artilleryShoot[0].origin);
			bullet setModel("projectile_cbu97_clusterbomb");
			bullet.angles = vectorToAngles(level.artilleryShoot[1].origin - level.artilleryShoot[0].origin);
			trace = bulletTrace(level.artilleryShoot[0].origin,vector_scale(anglesToForward(bullet.angles),1000000),false,self)["position"];
			time = (distance(level.artilleryShoot[0].origin,trace)/3000);
			bullet moveTo(trace,time);
			bullet thread destroyBullet(time,self);
		}
		if(self UseButtonPressed())
		{
			thread cannonActions(artilleryCase[curs]);
			if(artilleryCase[curs] == "view")
				wait .2;
		}
		if(isButtonPressed("+attack") || isButtonPressed("+speed_throw"))
		{
			curs += isButtonPressed("+attack");
			curs -= isButtonPressed("+speed_throw");
			if(curs >= artilleryOptions.size)
				curs = 0;
				
			if(curs < 0)
				curs = artilleryOptions.size-1;
				
			self.artillery["scrollBar"].y = ((curs*18)+90);
			wait .2;
		}
		if(isButtonPressed("+melee"))
		{
			thread exitCannonFunctions(self.artillery);
			break;
		}
		self disableWeapons();
		self freezeControls(true);
		wait .05;
	}
}
exitCannonFunctions(hudElem)
{
	self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
	self notify("switch_cannon");
	level notify("cannon_control");
	self show();
	self setOrigin(self.oldPos);
	level.cannonShoot = false;
	self unlink();
	self enableWeapons();
	self freezeControls(false);
	level.isUseingGun = false;
	self.MenuOpen = false;
	self.lockMenu = false;
	self.useingCannon = false;
	setHealth(100);
	if(isDefined(self.cannonHud[0]))
		for(k = 0; k < self.cannonHud.size; k++)
			self.cannonHud[k] destroy();
			
	keys = getArrayKeys(hudElem);
	for(k = 0; k < keys.size && isDefined(hudElem[keys[k]]); k++)
		hudElem[keys[k]] destroy();
}
cannonActions(caseType)
{
	switch(caseType)
	{
		case "right":
			level.tilt linkTo(level.spin);
			level.spin rotateTo(level.spin.angles-(0,2,0),.05);
		break;
		case "left":
			level.tilt linkTo(level.spin);
			level.spin rotateTo(level.spin.angles+(0,2,0),.05);
		break;
		case "up":
			level.tilt unlink();
			if(level.tilt.angles[2] <= 25)
				level.tilt rotateTo(level.tilt.angles+(0,0,1),.05);
		break;
		case "down":
			level.tilt unlink();
			if(level.tilt.angles[2] >= -15)
				level.tilt rotateTo(level.tilt.angles-(0,0,1),.05);
		break;
		case "view":
			if(isDefined(self.cannonHud[0]))
				for(k = 0; k < self.cannonHud.size; k++)
					self.cannonHud[k] destroy();
					
			self notify("switch_cannon");
			self.next ++;
			if(self.next >= level.viewPoint.size)
				self.next = 0;
				
			self unlink();
			self setOrigin(level.viewPoint[self.next].origin);
			self linkTo(level.viewPoint[self.next]);
			self setPlayerAngles(level.viewAngle[self.next]);
			if(self.next == 2)
				thread runCannonAngles();
				
			wait .2;
		break;
	}
}
runCannonAngles()
{
	self endon("switch_cannon");
	coord = strTok("21,0,2,24;-20,0,2,24;0,-11,40,2;0,11,40,2;0,-39,2,57;0,39,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2",";");
	for(k = 0; k < coord.size; k++)
	{
		tCoord = strTok(coord[k],",");
		self.cannonHud[k] = createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	for(;;)
	{
		self setPlayerAngles(vectorToAngles(level.artilleryShoot[1].origin - level.artilleryShoot[0].origin));
		wait .05;
	}
}
destroyBullet(time,owner)
{
	wait time;
	playFx(level.chopper_fx["explode"]["large"],self.origin);
	self playSound("exp_suitcase_bomb_main");
	radiusDamage(self.origin,250,200,90,owner);
	self delete();
	wait 1;
	level.cannonShoot = false;
}
spawnBox(pos,angle,model)
{
	box = spawn("script_model",pos);
	if(!isDefined(model))
		box setModel("com_plasticcase_beige_big");
	else
		box setModel(model);
		
	box.angles = angle;
	destroyArray(box);
	return box;
}
cannonDeath()
{
	level endon("cannon_delete");
	self waittill("death");
	if(self.useingCannon)
		thread exitCannonFunctions(self.artillery);
}
isButtonPressed(required)
{
	button = "";
	if(isSubStr(toLower(required),"+attack"))
		button = self attackButtonPressed();
		
	if(isSubStr(toLower(required),"+activate"))
		button = self useButtonPressed();
		
	if(isSubStr(toLower(required),"+speed_throw"))
		button = self adsButtonPressed();
		
	if(isSubStr(toLower(required),"+melee"))
		button = self meleeButtonPressed();
		
	if(isSubStr(toLower(required),"+frag"))
		button = self fragButtonPressed();
		
	if(isSubStr(toLower(required),"+smoke"))
		button = self secondaryOffHandButtonPressed();
		
	return button;
}
destroyArray(ent)
{
	if(!isDefined(level.modelEnt))
		level.modelEnt = [];
		
	level.modelEnt[level.modelEnt.size] = ent;
}
showIconOnMap(shader)
{
	level.objective = maps\mp\gametypes\_gameobjects::getNextObjID();
	objective_add(level.objective,"invisible",(0,0,0));
	objective_position(level.objective,self.origin);
	objective_state(level.objective,"active");
	objective_team(level.objective,self.team);
	objective_icon(level.objective,shader);
}
deleteAllModels()
{
	objective_Delete(level.objective);
	if(isDefined(level.modelEnt))
		for(k = 0; k < level.modelEnt.size; k++)
			level.modelEnt[k] delete();
			
	if(level.merryGoRound)
	{
		for(k = 0; k < level.players.size; k++)
		{
			level.players[k] unlink();
			level.players[k].Occ = false;
		}
		level.merryGoRound = false;
	}
	if(level.skyBaseSpawn)
	{
		for(k = 0; k < level.players.size; k++)
		{
			level.players[k] allowJump(true);
			level.players[k].randumWeapon = false;
		}
		level.sbOpen = false;
		level.skyBaseSpawn = false;
	}
	if(level.artilleryGunSpawn)
	{
		level notify("cannon_delete");
		level.controlPannel delete();
		level.spin delete();
		level.tilt delete();
		for(k = 0; k < 2; k++)
			level.artilleryShoot[k] delete();
			
		level.isUseingGun = false;
		level.artilleryGunSpawn = false;
		for(k = 0; k < level.players.size; k++)
			if(level.players[k].useingCannon)
				level.players[k] thread exitCannonFunctions(level.players[k].artillery);
	}
}
createBase()
{
	self thread ExitMenu();
	if(!level.spawningObject)
	{
		if(!level.skyBaseSpawn)
		{
			thread deleteAllModels();
			level.spawningObject = true;
			level.skyBaseSpawn = true;
			if(isMap("mp_countdown"))
			{
				level.skyBase["origin"] = (1765,860,520);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_slieghtofhand";
				thread skyBaseLights();
				thread telePort((2331,514,-12),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(2331,514,-7),false);
			}
			if(isMap("mp_vacant"))
			{
				level.skyBase["origin"] = (174,604,180);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_juggernaut";
				thread telePort((-1803,1738,-104),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(-1803,1738,-104),false);
			}
			if(isMap("mp_convoy"))
			{
				level.skyBase["origin"] = (2561,56,600);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_slieghtofhand";
				thread skyBaseBars();
				thread telePort((1138,1289,-55),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(1138,1289,-55),false);
			}
			if(isMap("mp_crossfire"))
			{
				level.skyBase["origin"] = (5439,-901,535);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_martyrdom";
				thread skyBaseLights();
				thread telePort((4164, -1894, 23),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(4164,-1894,23),false);
			}
			if(isMap("mp_citystreets"))
			{
				level.skyBase["origin"] = (5340,-175,1285);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_martyrdom";
				thread skyBaseLights();
				thread telePort((2373,-874,-95),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(2373,-874,-95),false);
			}
			if(isMap("mp_crash"))
			{
				level.skyBase["origin"] = (1868,-1443,791);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_stoppingpower";
				thread telePort((1411,-1701,226),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(1411,-1701,226),false);
			}
			if(isMap("mp_overgrown"))
			{
				level.skyBase["origin"] = (2662,-2839,967);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_slieghtofhand";
				thread telePort((-1007,-3696,-107),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(-1007,-3696,-107),false);
			}
			if(isMap("mp_farm"))
			{
				level.skyBase["origin"] = (1663,3262,806);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_stoppingpower";
				thread telePort((317,1036,217),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(317,1036,217),false);
			}
			if(isMap("mp_shipment"))
			{
				level.skyBase["origin"] = (-4890,4813,168);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "";
				thread telePort((680,13,201),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(680,13,201),false);
			}
			if(isMap("mp_showdown"))
			{
				level.skyBase["origin"] = (1219,631,367);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_last_stand";
				thread telePort((859,511,16),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(859,511,16),false);
			}
			if(isMap("mp_strike"))
			{
				level.skyBase["origin"] = (959,-173,447);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_stoppingpower";
				thread skyBaseLights();
				thread telePort((343,412,16),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(343,412,16),false);
			}
			if(isMap("mp_broadcast"))
			{
				level.skyBase["origin"] = (512,2,662);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_slieghtofhand";
				thread skyBaseBars();
				thread telePort((-2233,3275,-64),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(-2233,3275,-64),false);
			}
			if(isMap("mp_backlot"))
			{
				level.skyBase["origin"] = (1493,-589,325);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_slieghtofhand";
				thread skyBaseBars();
				thread telePort((1437,288,240),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(1437,288,240),false);
			}
			if(isMap("mp_bog"))
			{
				level.skyBase["origin"] = (5895,2904,312);
				pos = level.skyBase["origin"];
				level.box["top_Icon"] = "perc_doubletap";
				thread skyBaseLights();
				thread telePort((4385,102,9),((pos[0]+186),(pos[1]-21),(pos[2]+30)),true);
				thread telePort(((pos[0]+186),(pos[1]-21),(pos[2]+19)),(4385,102,9),false);
			}
			if(isMap("mp_pipeline") || isMap("mp_creek") || isMap("mp_carentan") || isMap("mp_killhouse") || isMap("mp_cargoship") || isMap("mp_bloc"))
				self iPrintln("^1Sorry You Cant Spawn It On This Map");//these maps are not used alot, plus i got bored making this. :D
				
			else
			{
				s = [];
				s[0] = ::window;
				s[1] = ::constructBase;
				s[2] = ::mystery_box;
				for(k = 0; k < s.size; k++)
					thread [[s[k]]]();
					
				P("skyBase Spawned");
				level.spawningObject = false;
			}
		}
		else
		{
			self iPrintln("skyBase Deleted");
			for(k = 0; k < level.modelEnt.size; k++)
				level.modelEnt[k] delete();
				
			for(k = 0; k < level.players.size; k++)
			{
				level.players[k] allowJump(true);
				level.players[k].randumWeapon = false;
			}
			level.sbOpen = false;
			level.skyBaseSpawn = false;
			objective_Delete(level.objective);
		}
	}
	else
		self iPrintln("^1Please Wait There Is Something Else Spawning!");
}
constructBase()
{
	for(z = 0; z < 2; z++)
		for(x = 0; x < 8; x++)
			for(y = 0; y < 8; y++)
				skyBase = spawnModel(level.skyBase["origin"],"com_plasticcase_beige_big",(x*30),(y*-50),(z*125),(0,90,0),false);
				
	for(k = 0; k < 5; k++)
		for(r = 0; r < 5; r++)
			skyBase = spawnModel(level.skyBase["origin"],"com_plasticcase_beige_big",(r*50),(28),((k*26)+10),(0,0,0),true,55);
			
	wait .05;
	for(k = 0; k < 5; k++)
		for(r = 0; r < 5; r++)
			skyBase = spawnModel(level.skyBase["origin"],"com_plasticcase_beige_big",(r*50),(-377),((k*26)+10),(0,0,0),true,55);
			
	for(k = 0; k < 5; k++)
		for(r = 0; r < 8; r++)
			skyBase = spawnModel(level.skyBase["origin"],"com_plasticcase_beige_big",(235),((r*-50)-5),((k*26)+10),(0,90,0),true,55);
			
	wait .05;
	for(k = 0; k < 2; k++)
		for(r = 0; r < 8; r++)
			skyBase = spawnModel(level.skyBase["origin"],"com_plasticcase_beige_big",(-29),((r*-50)-10),((k*26)+10),(0,90,0),true,55);
			
	for(k = 0; k < 8; k++)
		skyBase = spawnModel(level.skyBase["origin"],"com_plasticcase_beige_big",(-29),((k*-50)+10),(110),(0,90,0),true,55);
}
skyBaseBars()
{
	for(k = 0; k < 9; k++)
		skyBase = spawnModel(level.skyBase["origin"],"me_window_bars_05",(-29),((k*-43)-4),(35),(0,0,0),false);
}
skyBaseLights()
{
	for(k = 0; k < 4; k++)
		skyBase = spawnModel(level.skyBase["origin"],"com_lightbox_on",((k*63)+11),(15),(110),(0,0,0),false);
		
	wait .05;
	for(k = 0; k < 6; k++)
		skyBase = spawnModel(level.skyBase["origin"],"com_lightbox_on",(225),((k*63)-336),(110),(0,-90,0),false);
		
	wait .05;
	for(k = 0; k < 4; k++)
		skyBase = spawnModel(level.skyBase["origin"],"com_lightbox_on",((k*63)+11),(-365),(110),(0,180,0),false);
}
window()
{
	window = [];
	for(k = 0; k < 2; k++)
		for(r = 0; r < 9; r++)
			window[window.size] = spawnModel(level.skyBase["origin"],"com_plasticcase_beige_big",(-29),((r*-45)+10),((k*25)+11),(0,90,0),false);
			
	thread windowTrigger(window);
}
spawnModel(origin,model,xPos,yPos,zPos,angle,argument,solid)
{
	ent = spawn("script_model",(origin[0]+xPos,origin[1]+yPos,origin[2]+zPos));
	ent setModel(model);
	ent.angles = angle;
	destroyArray(ent);
	if(isSubStr(argument,true))
	{
		entSolid = spawn("trigger_radius",(origin[0]+xPos,origin[1]+yPos,origin[2]+zPos),0,solid,solid);
		entSolid setContents(1);
		entSolid.targetname = "script_collision";
		destroyArray(entSolid);
	}
	return ent;
}
windowTrigger(ent)
{
	controlPanel = spawnModel(level.skyBase["origin"],"com_laptop_2_open",(20),(-350),(65),(0,90,0),false);
	controlStand = spawnModel(level.skyBase["origin"],"com_plasticcase_beige_big",(20),(-370),(37),(-90,180,90),true,50);
	while(level.skyBaseSpawn)
	{
		for(k = 0; k < get_players().size; k++)
		{
			player = get_players()[k];
			if(distance(player.origin,(level.skyBase["origin"][0]+20,level.skyBase["origin"][1]-360,level.skyBase["origin"][2]+15)) < 40)
			{
				player.hint = "Press [{+activate}] To Open/Close Window";
				if(player useButtonPressed())
				{
					if(!level.sbOpen)
					{
						level.sbOpen = true;
						for(k = 0; k < ent.size; k++)
							ent[k] moveTo(ent[k].origin+(0,0,50),1.5);
							
						ent[ent.size-1] waittill("movedone");
					}
					else
					{
						level.sbOpen = false;
						for(k = 0; k < ent.size; k++)
							ent[k] moveTo(ent[k].origin-(0,0,50),1.5);
							
						ent[ent.size-1] waittill("movedone");
					}
				}
			}
		}
		wait .05;
	}
}
telePort(enter,exit,argument)
{
	telePort = spawnModel(enter,"prop_flag_american",(0),(0),(0),(0,170,0),false);
	if(isSubStr(argument,true))
		telePort showIconOnMap("compass_waypoint_panic");
		
	while(level.skyBaseSpawn)
	{
		for(k = 0; k < get_players().size; k++)
		{
			player = get_players()[k];
			if(distance(player.origin,enter) < 20 && !player.teleported)
			{
				player.teleported = true;
				if(isSubStr(argument,true))
					player allowJump(false);
				else
					player allowJump(true);
					
				player setOrigin(exit);
				wait 1.5;
				player.teleported = false;
			}
		}
		wait .05;
	}
}
mystery_box()
{
	level.weaponBox = spawnModel(level.skyBase["origin"],"com_plasticcase_beige_big",(200),(-255),(24),(0,-90,0),true,50);
	level.weaponIcon = spawnModel(level.skyBase["origin"],level.box["top_Icon"],(215),(-255),(74),(0,-90,0),false);
	wait 2;
	while(level.skyBaseSpawn)
	{
		for(k = 0; k < get_players().size; k++)
		{
			guy = get_players()[k];
			if(distance(guy.origin,level.weaponBox.origin ) < 50)
			{
				guy.hint = "Press [{+activate}] To Use Random Box";
				if(guy useButtonPressed() && !guy gotAllWeapons())
				{
					level.boxUser = guy;
					break;
				}
			}
		}
		if(isDefined(level.boxUser))
			break;
			
		wait .05;
	}
	user = level.boxUser;
	gun = user treasure_chest_weapon_spawn(level.weaponBox.origin);
	thread boxTimeout(user,gun);
	while(level.skyBaseSpawn)
	{
		if(distance(user.origin,level.weaponBox.origin) < 50)
		{
			user.hint = "Press [{+activate}] To Take Weapon";
			if(user useButtonPressed())
			{
				user giveWeapon(gun.weap,0,false);
				user switchToWeapon(gun.weap,0,false);
				user giveMaxAmmo(gun.weap,0,false);
				user playSound("oldschool_pickup");
				user notify("weapon_collected");
				break;
			}
		}
		if(isDefined(user.timedOut))
			break;
			
		wait .05;
	}
	gun delete();
	level.weaponBox delete();
	level.boxUser = undefined;
	if(level.skyBaseSpawn)
		level thread mystery_box();
}
boxTimeout(guy,gun)
{
	guy endon("weapon_collected");
	gun moveTo(gun.origin-(0,0,30),12,(12*.5));
	wait 12;
	guy.timedOut = true;
	wait 0.2;
	guy.timedOut = undefined;
}
treasure_chest_weapon_spawn(loc)
{
	gun = spawn("script_model",loc+(0,0,25));
	gun setModel("");
	gun.angles = level.weaponBox.angles;
	gun moveTo(gun.origin+(0,0,30),3,1.5,1.4);
	weaponArray = [];
	for(k = 0; k < level.weaponlist.size; k++)
	{
		if(!self hasWeapon(level.weaponlist[k]))
			weaponArray[weaponArray.size] = level.weaponlist[k];
	}
	randy = 0;
	for(k = 0; k < 40; k++)
	{
	if(k < 20) wait .05;
	else if(k < 30) wait .1;
	else if(k < 35) wait .2;
	else if(k < 38) wait .3;
	randy = weaponArray[randomInt(weaponArray.size)];
	gun setModel(getWeaponModel(randy));
		 gun.weap = randy;
	}
	return gun;
}
hintTxt()
{
	self endon("disconnect");
	hintText = createText("default",1.5,"CENTER","CENTER",0,100,1,100,(1,1,1),"");
	for(;;)
	{
		hintText setText(self.Hint);
		wait .2;
	}
}
build()
{
	self thread ExitMenu();
	if(!level.spawningObject)
	{
		if(!level.merryGoRound)
		{
			thread deleteAllModels();
			level.spawningObject = true;
			level.merryGoRound = true;
			thread buildMerry();
			self iPrintln("Merry Go Round Spawned!!");
		}
		else
		{
			thread deleteAllModels();
			level.merryGoRound = false;
			self iPrintln("Merry Go Round Deleted!!");
		}
	}
	else
		self iPrintln("^1Please Wait There Is Something Else Spawning!");
}
buildMerry()
{
	center = self.origin;
	level.crates = [];
	sizeArray = strTok("21;12;9",";");
	for(z = 0; z < 160; z += 155)
	{
		num = 0;
		for(k = 55; k < 200; k += 55)
		{
			for(r = 0; r < 360; r += int(sizeArray[num]))
			{
				size = level.crates.size;
				x = center[0]+(k*cos(r));
				y = center[1]+(k*sin(r));
				level.crates[size] = spawn("script_model",(x,y,center[2]+z));
				level.crates[size] setModel("com_plasticcase_beige_big");
				angle = vectorToAngles(level.crates[size].origin - (center[0],center[1],center[2]+z));
				level.crates[size].angles = (angle[0],angle[1],0);
				destroyArray(level.crates[size]);
				wait .05;
			}
			num ++;
		}
	}
	for(z = 28; z < 168; z +=28)
	{
		for(k = 0; k < 7; k++)
		{
			size = level.centerCrates.size;
			level.centerCrates[size] = spawn("script_model",(center[0],center[1],center[2]+z-10));
			level.centerCrates[size] setModel("com_plasticcase_beige_big");
			level.centerCrates[size].angles = (0,22*k,0);
			destroyArray(level.centerCrates[size]);
		}
		wait .05;
	}
	thread spawnSeat(center+(-123,101,40),(90,45,0));
	thread spawnSeat(center+(-23,-101,40),(90,0,0));
	thread spawnSeat(center+(-23,101,40),(90,0,0));
	thread spawnSeat(center+(-101,-123,40),(90,135,0));
	thread spawnSeat(center+(101,-23,40),(90,90,0));
	thread spawnSeat(center+(123,-101,40),(90,-135,0));
	thread spawnSeat(center+(101,123,40),(90,-45,0));
	thread spawnSeat(center+(-101,-23,40),(90,90,0));
	for(k = 0; k < level.merrySeat.size; k++)
	{
		level.seatCenter[k] = spawn("script_origin",center);
		destroyArray(level.seatCenter[k]);
		level.merrySeat[k] linkTo(level.seatCenter[k]);
		level.seatCenter[k] thread moveSeat();
	}
	center = spawn("script_origin",center);
	for(k = 0; k < level.crates.size; k++)
		level.crates[k] linkTo(center);
		
	center thread monitorPlayers();
	level.spawningObject = false;
	center showIconOnMap("compass_waypoint_panic");
	while(level.merryGoRound)
	{
		center rotateYaw(-360,4);
		for(k = 0; k < level.seatCenter.size; k++)
			level.seatCenter[k] rotateYaw(-360,4);
			
		wait 4;
	}
}
monitorPlayers()
{
	while(level.merryGoRound)
	{
		for(k = 0; k < level.players.size; k++)
		{
			player = level.players[k];
			if(distance(self.origin,player.origin) < 210)
			{
				closest = getClosest(player.origin,level.merrySeat);
				if(!closest.inUse && !player.Occ)
				{
					player.oldOrigin = player getOrigin();
					player playerLinkTo(closest);
					closest.inUse = true;
					player.Occ = true;
					Player iPrintln("Press [{+Melee}] To Exit Merry Go Round");
				}
				else if(player meleeButtonPressed() && closest.inUse && player.Occ)
				{
					player unlink();
					player setOrigin(player.oldOrigin);
					closest.inUse = false;
					wait 2;
					player.Occ = false;
				}
			}
		}
		wait .05;
	}
}
spawnSeat(arg,angles)
{
	if(!isDefined(level.merrySeat))
		level.merrySeat = [];
		
	size = level.merrySeat.size;
	level.merrySeat[size] = spawnStruct();
	level.merrySeat[size] = spawn("script_model",arg);
	level.merrySeat[size] setModel("com_barrel_blue_rust");
	level.merrySeat[size].angles = angles;
	level.merrySeat[size].inUse = false;
	destroyArray(level.merrySeat[size]);
}
moveSeat()
{
	while(level.merryGoRound)
	{
		rand = randomFloatRange(1,2);
		self moveTo((self.origin[0],self.origin[1],self.origin[2]+85),rand);
		wait rand;
		Rand = randomFloatRange(1,2);
		self moveTo((self.origin[0],self.origin[1],self.origin[2]-85),rand);
		wait rand;
	}
}
playerLinkTo(linkTo)
{
	self setOrigin(linkTo.origin-(0,0,35));
	self linkTo(linkTo);
}
getClosest(origin,ents)
{
	index = 0;
	dist = distance(origin,ents[index].origin);
	for(k = 1; k < ents.size; k++)
	{
		temp_dist = distance(origin,ents[k].origin);
		if(temp_dist < dist)
		{
			dist = temp_dist;
			index = k;
		}
	}
	return ents[index];
}
strafeRun()
{
	if(!level.strafeRun)
	{
		level.strafeRun = true;
		self beginLocationSelection("rank_prestige10",level.artilleryDangerMaxRadius);
		self.selectingLocation = true;
		self waittill("confirm_location",location);
		newLocation = bulletTrace(location+(0,0,1000),(location+(0,0,-100000)),false,undefined)["position"];
		self endLocationSelection();
		self.selectingLocation = undefined;
		iPrintln("Strafe Run Incoming...");
		wait(1.5);
		pathNode = [];
		offSet = strTok("0;-625;625;-1250;1250",";");
		direction = maps\mp\gametypes\_hardpoints::getBestPlaneDirection(newLocation);
		for(k = 0; k < offSet.size; k++)
			pathNode[k] = getPath(newLocation,direction,int(offSet[k]));
			
		level thread strafeLoop(self,pathNode[0]);
		wait(.4);
		level thread strafeLoop(self,pathNode[1]);
		level thread strafeLoop(self,pathNode[2]);
		wait(.4);
		level thread strafeLoop(self,pathNode[3]);
		level thread strafeLoop(self,pathNode[4]);
	}
	else
		self iprintln("Please Wait... ^1There is a Strafe Run in use.");
}
strafeLoop(owner,pathNode)
{
	chopper = createStrafe(owner,pathNode["begin"],vectorToAngles(pathNode["objective"] - pathNode["begin"]));
	chopper setVehGoalPos(pathNode["objective"],0);
	chopper waittill("goal");
	chopper setVehGoalPos(pathNode["begin"],0);
	chopper waittill("goal");
	chopper delete();
}
createStrafe(owner,startOrigin,angles)
{
	chopper = spawnHelicopter(owner,startOrigin,angles,"cobra_mp","vehicle_cobra_helicopter_fly");
	chopper playLoopSound("mp_hind_helicopter");
	chopper setDamageStage(3);
	chopper chopperSettings(60,20,40,20,30,45,1);
	chopper thread strafeShoot(owner);
	return chopper;
}
getPath(location,yaw,offSet)
{
	path = [];
	if(offSet != 0)
		location = location+(vector_scale(anglesToRight((0,yaw,0)),offSet));
		
	path["begin"] = location+(vector_scale(anglesToForward((0,yaw,0)),((-1)*13000))+(0,0,1550));
	path["objective"] = location+(vector_scale(anglesToForward((0,yaw,0)),13000)+(0,0,1550));
	return path;
}
strafeShoot(owner)
{
	for(count = 0; count <= 1200; count++)
	{
		closest = distance(self.origin,(0,0,9999999));
		entityNum = 0;
		for(k = 0; k < level.players.size; k++)
		{
			dest = distance(self.origin,level.players[k].origin);
			if(dest < closest && isAlive(level.players[k]) && k != owner getEntityNumber())
			{
				closest = dest;
				entityNum = k;
			}
		}
		if((chopperTarget(level.players[entityNum]) >= 0) && ((level.teamBased && level.players[entityNum].team != owner.team) || (!level.teamBased && owner != level.players[entityNum])))
		{
			self setTurretTargetVec(level.players[entityNum] getTagOrigin(level.misc[7][randomInt(level.misc[7].size-1)]));
			self fireWeapon();
		}
		wait .05;
	}
	level.strafeRun = false;
}
chopperTarget(aiTarget)
{
	trace = bulletTrace(self.origin+(0,0,5),aiTarget getEye(),false,self)["fraction"];
	if(trace == 1 && distance(self.origin,aiTarget.origin) <= 3500)
		return distance(self.origin,aiTarget.origin);
		
	return int(-1);
}
petChopper()
{
	if(!self.petHelicopterChopper)
	{
		self.petHelicopterChopper = true;
		thread spawnPetChopper();
		self iPrintln("Pet Chopper [^2ON^7]");
	}
	else
	{
		self.petHelicopter delete();
		self iPrintln("Pet Chopper [^1OFF^7]");
		self.petHelicopterChopper = false;
	}
}
spawnPetChopper()
{
	self endon("death");
	self endon("disconnect");
	thread petChopperDeath();
	self.petHelicopter = spawnHelicopter(self,self.origin+(0,0,1000),self.angles,"cobra_mp","vehicle_cobra_helicopter_fly");
	self.petHelicopter playLoopSound("mp_cobra_helicopter");
	self.petHelicopter setDamageStage(3);
	self.petHelicopter thread petShoot(self);
	self.petHelicopter chopperSettings(290,30,150,140,5,30,.5);
	while(self.petHelicopterChopper)
	{
		self.petHelicopter setSpeed(30+randomInt(20),15+randomInt(15));
		self.petHelicopter setVehGoalPos(self.origin+(self getVelocity())*2+(0,0,1000),1);
		wait .05;
	}
}
petShoot(owner)
{
	self endon("death");
	self endon("unverified");
	self endon("disconnect");
	while(self.petHelicopterChopper)
	{
		closest = distance(self.origin,(0,0,9999999));
		entityNum = 0;
		for(k = 0; k < level.players.size; k++)
		{
			dest = distance(self.origin,level.players[k].origin);
			if(dest < closest && isAlive(level.players[k]) && k != owner getEntityNumber())
			{
				closest = dest;
				entityNum = k;
			}
		}
		if((chopperTarget(level.players[entityNum]) >= 0) && ((level.teamBased && level.players[entityNum].team != owner.team) || (!level.teamBased && owner != level.players[entityNum])))
		{
			self setTurretTargetVec(level.players[entityNum] getTagOrigin(level.misc[7][randomInt(level.misc[7].size-1)]));
			self fireWeapon();
		}
		wait .05;
	}
}
petChopperDeath()
{
	self waittill("death");
	if(isDefined(self.petHelicopter))
		self.petHelicopter delete();
		
	self.petHelicopterChopper = false;
}
rainModel()
{
	if(!level.rainModel)
	{
		thread rain("vehicle_mig29_desert");
		self iPrintln("Raining Mig29 [^2ON^7]");
		level.rainModel = true;
	}
	else
	{
		self iPrintln("Raining Mig29 [^1OFF^7]");
		level.rainModel = false;
	}
}
rain(model)
{
	self endon("unverified");
	while(level.rainModel)
	{
		range = [];
		for(k = 0; k < 2; k++)
			range[k] = randomIntRange(-2000,2000);
			
		s_model = spawn("script_model",(range[0],range[1],2000));
		s_model setModel(model);
		s_model physicsLaunch(s_model.origin,(0,0,-5000));
		s_model thread deleteAfterTime();
		wait .2;
	}
}
deleteAfterTime()
{
	wait 6;
	self delete();
}
reaper()
{
	if(!self.reaper)
	{
		self thread ExitMenu();
		self.reaper = true;
		self.oldPos = self getOrigin();
		thread reaperHud();
		self.rLoc = getPosition();
		self setHealth(99999999999);
		thread reaperLink();
		thread reaperWeapon();
		self playLocalSound("item_nightvision_on");
	}
}
reaperLink()
{
	thread reaperDeath();
	self.LockMenu = true;
	self.MenuOpen = false;
	self.Menu["Instructions"] setText("Press [{+Attack}] To Fire Missile\nUse [{+Melee}] To Gide Missle\nPress [{+Melee}] To Exit Reaper");
	self.noclip = false;
	self.reap["veh"] = spawn("script_model",(self.rLoc[0]+(1150*cos(0)),self.rLoc[1]+(1150*sin(0)),self.rLoc[2]));
	self.reap["veh"] setModel("vehicle_mi24p_hind_desert");
	thread reaperMove();
	self linkTo(self.reap["veh"],"tag_player",(0,100,-120),(0,0,0));
	self hide();
	thread reaperExit();
	self disableWeapons();
}
reaperExit()
{
	self endon("death");
	self endon("disconnect");
	while(self.reaper)
	{
		angles = self getPlayerAngles();
		if(angles[0] <= 30)
			self setPlayerAngles((30,angles[1],angles[2]));
			
		if(self meleeButtonPressed())
		{
			self playLocalSound("item_nightvision_off");
			self.LockMenu = false;
			self.MenuOpen = false;
			self unlink();
			self setOrigin(self.oldPos);
			for(k = 0; k < self.r.size; k++)
				if(isDefined(self.r[k]))
					self.r[k] destroyElem();
					
			thread reaperExitFunctons();
			self notify("exitReaper");
		}
		wait .05;
	}
}
reaperDeath()
{
	self endon("exitReaper");
	self waittill_any("death","disconnect");
	thread reaperExitFunctons();
}
reaperExitFunctons()
{
	self show();
	self.reap["veh"] delete();
	self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
	self.reaper = false;
	self enableWeapons();
	if(isDefined(self.reap["bullet"]))
		self.reap["bullet"] delete();
}
reaperMove()
{
	self endon("death");
	self endon("disconnect");
	while(self.reaper)
	{
		for(k = 0; k < 360; k+=.5)
		{
			if(!self.reaper)
				break;
				
			location = (self.rLoc[0]+(1150*cos(k)),self.rLoc[1]+(1150*sin(k)),self.rLoc[2]);
			angles = vectorToAngles(location - self.reap["veh"].origin);
			self.reap["veh"] moveTo(location,.1);
			self.reap["veh"].angles = (angles[0],angles[1],angles[2]-40);
			wait .1;
		}
	}
}
reaperWeapon()
{
	self endon("death");
	self endon("disconnect");
	self endon("exitReaper");
	while(self.reaper)
	{
		if(self attackButtonPressed())
		{
			self.reap["bullet"] = spawn("script_model",self getTagOrigin("tag_weapon_left"));
			self.reap["bullet"] setModel("projectile_cbu97_clusterbomb");
			self.reap["bullet"] playSound("weap_hind_missile_fire");
			for(time = 0; time < 200; time++)
			{
				if(!self.reaper)
					break;
					
				vector = anglesToForward(self.reap["bullet"].angles);
				forward = self.reap["bullet"].origin+(vector[0]*45,vector[1]*45,vector[2]*49);
				collision = bulletTrace(self.reap["bullet"].origin,forward,false,self);
				
				self.reap["bullet"].angles = (vectorToAngles((getCursorPos()-(0,0,130)) - self.reap["bullet"].origin));
				self.reap["bullet"] moveTo(forward,.05);
				playFxOnTag(level.chopper_fx["fire"]["trail"]["medium"],self.reap["bullet"],"tag_origin");
				if(collision["surfacetype"] != "default" && collision["fraction"] < 1 && level.collisions)
				{
					expPos = self.reap["bullet"].origin;
					for(k = 0; k < 360; k+=80)
						playFx(level.artilleryFX,(expPos[0]+(150*cos(k)),expPos[1]+(150*sin(k)),expPos[2]+100));
						
					earthquake(3,1.6,expPos,450);
					radiusDamage(expPos,400,300,120,self,"MOD_PROJECTILE_SPLASH","artillery_mp");
					self.reap["bullet"] playSound("cobra_helicopter_hit");
					break;
				}
				wait .05;
			}
			self.reap["bullet"] delete();
			wait 2;
		}
		wait .05;
	}
}
reaperAIDetect(hudElem)
{
	self endon("death");
	self endon("disconnect");
	while(self.reaper)
	{
		target["enemyTeam"] = false;
		target["myTeam"] = false;
		for(k = 0; k < level.players.size; k++)
		{
			if(isAlive(level.players[k]))
			{
				if(distance(getCursorPos(),level.players[k].origin) < 200)
					if((level.teamBased && self.team != level.players[k].team) || (!level.teamBased && level.players[k] != self))
						target["enemyTeam"] = true;
					else
						target["myTeam"] = true;
			}
		}
		for(k = 0; k < int(hudElem.size/2); k++)
		{
			if(target["myTeam"] && target["enemyTeam"])
				hudElem[k].color = (1,(188/255),(43/255));
				
			else if(target["myTeam"] && !target["enemyTeam"])
				hudElem[k].color = (0,.7,0);
				
			else if(!target["myTeam"] && target["enemyTeam"])
				hudElem[k].color = (.7,0,0);
		}
		wait .05;
		for(k = 0; k < hudElem.size; k++)
			hudElem[k].color = (1,1,1);
	}
}
reaperHud()
{
	coord = strTok("21,0,2,24;-20,0,2,24;0,-11,40,2;0,11,40,2;0,-39,2,57;0,39,2,57;-48,0,57,2;49,0,57,2;-155,-122,2,21;-154,122,2,21;155,122,2,21;155,-122,2,21;-145,132,21,2;145,-132,21,2;-145,-132,21,2;146,132,21,2",";");
	for(k = 0; k < coord.size; k++)
	{
		tCoord = strTok(coord[k],",");
		self.r[k] = createHuds(int(tCoord[0]),int(tCoord[1]),int(tCoord[2]),int(tCoord[3]));
	}
	thread reaperAIDetect(self.r);
}
getPosition()
{
	location = (0,0,2000);
	if(isMap("mp_bloc"))
		location = (1100,-5836,2500);
	else if(isMap("mp_crossfire"))
		location = (4566,-3162,2300);
	else if(isMap("mp_citystreets"))
		location = (4384,-469,2100);
	else if(isMap("mp_creek"))
		location = (-1595,6528,2500);
	else if(isMap("mp_bog"))
		location = (3767,1332,2300);
	else if(isMap("mp_overgrown"))
		location = (267,-2799,2600);
	else
		location = (0,0,2300);
		
	return location;
}
menuTheme(theme)
{
	self.colormenu = 0;
	switch(theme)
	{
		case "default":
			thread themeColor((0,0,0),(0,0,0));
			self.TitleGlow = (0,1,0);
			self.Menu["Title"].glowColor = self.TitleGlow;
		break;
		case "nextgenupdate":
			thread themeColor((140/255,188/255,253/255),(22/255,46/255,80/255));
			self.TitleGlow = (140/255,188/255,253/255);
			self.Menu["Title"].glowColor = self.TitleGlow;
		break;
		case "se7ensins":
			thread themeColor((8/255,166/255,21/255),(212/255,212/255,212/255));
			self.TitleGlow = (8/255,166/255,21/255);
			self.Menu["Title"].glowColor = self.TitleGlow;
		break;
		case "youtube":
			thread themeColor((178/255,25/255,25/255),(242/255,242/255,242/255));
			self.TitleGlow = (1,0,0);
			self.Menu["Title"].glowColor = self.TitleGlow;
		break;
	}
}
themeColor(scrollBar,background)
{
	self.Menu["Shader"]["Curs"].color = scrollBar;
	self.Menu["Shader"]["Instructions"].color = background;
	self.Menu["Shader"]["backround"].color = background;
}
initRollStructure()
{
	addRoll("Extra Speed",::extraSpeed,1.5);
	addRoll("Ak47-Silenced",::runRollWeapon,"ak47_silencer_mp");
	addRoll("Dragunov",::runRollWeapon,"dragunov_mp");
	addRoll("You are a Pussy",::runRollHealth,10);
	addRoll("Triple Health",::runRollHealth,300);
	addRoll("No ADS!",::runAds,false);
	addRoll("Go Get 'Em' Makarov",::runRollWeapon,"saw_grip_mp");
	addRoll("R7000",::runRollWeapon,"remington700_mp");
	addRoll("Knife Runner",::knifeRunner);
	addRoll("Turtle",::extraSpeed,.5);
	addRoll("You Are Flashing",::flashingPlayer);
	addRoll("M1014 ShotGun",::runRollWeapon,"m1014_grip_mp");
	addRoll("Random Weapon",::randomWeapon);
	addRoll("Brickblaster",::runRollWeapon,"brick_blaster_mp");
	addRoll("Third Person",::rollDvar,"cg_thirdperson");
	addRoll("God Mode for 20secs",::rollGod,20);
	addRoll("Claymore",::runRollWeapon,"claymore_mp");
	addRoll("Blast Them Bitchs",::runRollWeapon,"rpg_mp");
	addRoll("Rotate Screen",::rotateScreen2);
}
addRoll(name,function,argument)
{
	if(!isDefined(level.roll["name"]))
		level.roll["name"] = [];
		
	size = level.roll["name"].size;
	level.roll["name"][size] = name;
	level.roll["function"][size] = function;
	level.roll["input"][size] = argument;
}
rollAgain()
{
	self.oldRoll = self.rollNumber;
	self.rollNumber = randomInt(level.roll["name"].size-1);
	if(isSubStr(self.rollNumber,self.oldRoll))
		self.rollNumber = randomInt(level.roll["name"].size-1);
		
	thread [[level.roll["function"][self.rollNumber]]](level.roll["input"][self.rollNumber]);
	thread rollDeath();
	self iPrintlnBold("You Rolled [^2"+self.rollNumber+"^7]\n",level.roll["name"][self.rollNumber]);
}
rollDeath()
{
	self waittill("death");
	self setClientDvar("cg_thirdperson","0");
	self setMoveSpeedScale(1);
}
extraSpeed(speed)
{
	self endon("death");
	for(;;)
	{
		self setMoveSpeedScale(speed);
		wait .05;
	}
}
runRollWeapon(weapon)
{
	self endon("death");
	for(;;)
	{
		if(self getCurrentWeapon() != weapon)
		{
			self takeAllWeapons();
			self giveWeapon(weapon);
			self switchToWeapon(weapon);
			wait .05;
		}
		wait .05;
	}
}
knifeRunner()
{
	self endon("death");
	for(;;)
	{
		if(self getCurrentWeapon() != "usp_mp")
		{
			self takeAllWeapons();
			self giveWeapon("usp_mp");
			self switchToWeapon("usp_mp");
		}
		self setWeaponAmmoClip("usp_mp",0);
		self setWeaponAmmoStock("usp_mp",0);
		self setMoveSpeedScale(1.5);
		wait .05;
	}
}
runRollHealth(health)
{
	self endon("death");
	for(;;)
	{
		if(self.health > health)
		{
			self.maxhealth = health;
			self.health = self.maxhealth;
		}
		wait .05;
	}
}
runAds(argument)
{
	self allowAds(argument);
}
toggleFlash()
{
	if(self.flashing==false)
	{
		self iPrintln("Flashing Player [^2ON^7]");
		thread flashingPlayer();
		self.flashing = true;
	}
	else
	{
		self iPrintln("Flashing Player [^1OFF^7]");
		self endon("stopFlashing");
		self.flashing = false;
	}
}
flashingPlayer()
{
	self endon("death");
	self endon("stopFlashing");
	for(;;)
	{
		self hide();
		wait .5;
		self show();
		wait .5;
	}
}
rotateScreen2()
{
	self endon("death");
	for(;;)
	{
		self.angle = self getPlayerAngles();
		self setPlayerAngles(self.angle+(0,1,0));
		wait .05;
	}
}
randomWeapon()
{
	self takeAllWeapons();
	weapon = level.weaponList[randomInt(level.weaponList.size-1)];
	self giveWeapon(weapon);
	wait .05;
	self switchToWeapon(weapon);
}
rollDvar(dvar)
{
	self setClientDvar(dvar,"1");
}
rollGod(time)
{
	self endon("death");
	for(k = 0; k < (20*time); k++)
	{
		self.maxhealth = 99999999999;
		self.health = self.maxhealth;
		wait .05;
	}
	self.maxhealth = 100;
	self.health = self.maxhealth;
	self iPrintln("God Mode Off");
}
unlimitedStock()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		currentWeapon = self getCurrentWeapon();
		if(currentWeapon != "none")
			self setWeaponAmmoStock(currentWeapon,80995);
			
		wait .05;
	}
}
StartGG()
{	
	for(k = 0; k < level.players.size; k++)
	{
		level.players[k] thread ExitMenu();
		level.players[k].lockMenu = false;
		level.players[k].MenuOpen = false;
		level.players[k] notify("unverified");
		level.players[k] thread resetPlayerDvars();
		level.players[k] thread initGunGame();
		level.players[k] iPrintlnBold("^1Gun Game\nBe The First To Dominate With Every Gun");
	}
}
initGunGame()
{
	self.score = 0;
	self setClientDvars("g_speed","220","r_blur","0","player_sustainAmmo","0","scr_player_maxhealth","40","scr_game_perks","0","player_meleerange","0","jump_height","85","g_gravity","400");
	thread initGuns();
	thread runKills();
	self.gunGameOne = true;
	setDvar("scr_game_hardpoints",0);
	self clearPerks();
	thread hideInstruct();
}
initGuns()
{
	thread initKillingHud();
	thread playerWaitTill();
	createWeapon("usp_mp",true,&"WEAPON_USP");
	createWeapon("colt45_mp",true,&"WEAPON_COLT1911");
	createWeapon("beretta_mp",true,&"WEAPON_BERETTA");
	createWeapon("deserteaglegold_mp",false,&"WEAPON_DESERTEAGLEGOLD");
	createWeapon("winchester1200_mp",false,&"WEAPON_WINCHESTER1200");
	createWeapon("m1014_mp",false,&"WEAPON_BENELLI");
	createWeapon("skorpion_mp",true,&"WEAPON_SKORPION");
	createWeapon("mp5_mp",true,&"WEAPON_MP5");
	createWeapon("mp44_mp",false,&"WEAPON_MP44");
	createWeapon("p90_mp",false,&"WEAPON_P90");
	createWeapon("g36c_mp",false,&"WEAPON_G36C");
	createWeapon("ak74u_mp",false,&"WEAPON_AK74U");
	createWeapon("g3_mp",false,&"WEAPON_G3");
	createWeapon("rpg_mp",false,&"PERKS_RPG7_X_2");
	createWeapon("m16_mp",false,&"WEAPON_M16");
	createWeapon("m14_mp",false,&"WEAPON_M14");
	createWeapon("m40a3_mp",false,&"WEAPON_M40A3");
	createWeapon("m21_mp",false,&"WEAPON_M21");
	createWeapon("dragunov_mp",false,&"WEAPON_DRAGUNOV");
	createWeapon("barrett_mp",false,&"WEAPON_BARRETT");
	createWeapon("remington700_mp",false,&"WEAPON_REMINGTON700");
	createWeapon("saw_mp",false,&"WEAPON_SAW");
	createWeapon("rpd_mp",false,&"WEAPON_RPD");
	createWeapon("ak47_mp",true,&"WEAPON_AK47");
	createWeapon("EndGun_mp",true,&"MPUI_NONE");
}
createWeapon(gunName,laserSight,name)
{
	if(!isDefined(self.gunList))
		self.gunList = [];
		
	size = self.gunList.size;
	self.gunList[size] = createGun(gunName,laserSight);
	self.gunName[size] = name;
}
createGun(gunName,laserSight)
{
	gun = spawnStruct();
	gun.name = gunName;
	gun.laser = laserSight;
	return gun;
}
runKills()
{
	self endon("disconnect");
	level endon("game_ended");
	self.curGun = 0;
	self.temp = self.kills;
	while(1)
	{
		if(self.kills - self.temp > 0)
		{
			self.curGun ++;
			self.temp ++;
			self notify("killed_player");
			wait .05;
			thread killedPlayer();
			if(isSubStr(self.curGun,24))
				level thread maps\mp\gametypes\_globallogic::endGame(self.pers["team"],self.name+" Has Won The Gun Game!");
		}
		while(!isSubStr(self getCurrentWeapon(),self.gunList[self.curGun].name))
		{
			if(self.gunList[self.curGun].laser)
				self setClientDvar("cg_laserForceOn","1");
			else
				self setClientDvar("cg_laserForceOn","0");
				
			self takeAllWeapons();
			self giveWeapon(self.gunList[self.curGun].name);
			self switchToWeapon(self.gunList[self.curGun].name);
			wait .2;
		}
		self giveMaxAmmo(self.gunList[self.curGun].name);
		wait .2;
	}
}
killedPlayer()
{
	self endon("killed_player");
	for(k = 0; k < 2; k++)
		self.gunGame["line"][k] hudFade(.05,1);
		
	self.gunGame["BG"] hudFade(.05,.6);
	wait 2;
	for(k = 0; k < 2; k++)
		self.gunGame["line"][k] hudFade(.05,0);
		
	self.gunGame["BG"] hudFade(.05,0);
}
playerWaitTill()
{
	self endon("disconnect");
	level endon("game_ended");
	for(;;)
	{
		self waittill("killed_player");
		for(k = 0; k < self.gunGame["line"].size; k++)
			self.gunGame["line"][k] hudFade(.05,0);
			
		self.gunGame["BG"] hudFade(.05,0);
	}
}
initKillingHud()
{
	self.gunGame["line"][0] = createText("default",2.3,"","",0,-180,0,200,(1,1,1),"Player Killed");
	self.gunGame["line"][1] = createText("default",1.6,"","",0,-160,0,200,(1,1,1),"");
	self.gunGame["BG"] = createRectangle("","",0,-170,140,50,(0,0,0),"white",100,0);
	for(;;)
	{
		self.gunGame["line"][1] setText(self.gunName[self.curGun]);
		wait .05;
	}
}
hudFade(time,alpha)
{
	self fadeOverTime(time);
	self.alpha = alpha;
}
resetPlayerDvars()
{
	wait 1;
	self setClientDvars("cg_thirdperson","0","r_blur","0","r_colormap","1","r_fullbright","0","r_specularmap","1","r_debugShader","0","r_filmTweakEnable","0");
	self setClientDvars("r_filmUseTweaks","0","r_filmTweakInvert","0","r_filmtweakLighttint","1.1 1.05 .85","r_filmtweakdarktint",".7 .85 1","player_meleerange","64");
}
hideInstruct()
{
	self.Menu["Instructions"] hideElem();
	self.Menu["Shader"]["Instructions"] hideElem();
}
StartOITC()
{
	for(k = 0; k < level.players.size; k++)
	{
		level.players[k] thread ExitMenu();
		level.players[k].lockMenu = false;
		level.players[k].MenuOpen = false;
		level.players[k] thread hideInstruct();
		level.players[k] notify("unverified");
		level.players[k] runOITC();
		level.players[k] iPrintlnBold("^1One In The Chamber\nKill Players To Gain Bullets And Win The Match");
	}
}
runOITC()
{
	setDvar("scr_player_maxhealth",5);
	if(!self.chamberStart)
	{
		thread chamberSettings();
		self.hasNoLifes = false;
		thread playerExitChamber();
		if(!level.initChamber)
		{
			level thread maps\mp\gametypes\_globallogic::pauseTimer();
			thread deleteAllModels();
			level thread initChamberSystem();		
			for(k = 0; k < level.players.size; k++)
				level.players[k].isHereAtStart = true;
				
			level.playersLeft = level.players.size;
			level.initChamber = true;
		}
		thread chamberLifes();
		self.chamberStart = true;
	}
	if(self.hasNoLifes || !self.isHereAtStart)
	thread change_team("spectator");			
	self takeAllWeapons();
	self giveWeapon("beretta_mp");
	self setWeaponAmmoStock("beretta_mp",0);
	self setWeaponAmmoClip("beretta_mp",1);
	wait .10;
	self switchToWeapon("beretta_mp");
	thread initChamber();
}
initChamber()
{
	thread chamberHuds();
	thread chamberHealth();
	self clearPerks();
	perks = strTok("specialty_bulletdamage;specialty_bulletpenetration",";");
	for(k = 0; k < perks.size; k++)
		self setPerk(perks[k]);
		
	thread killForBullet();
	wait 1;
    self setClientDvars("ui_allow_classchange","0","bg_fallDamageMaxHeight","350","bg_fallDamageMinHeight","140","jump_height","48","perk_bulletPenetrationMultiplier","999","player_sustainammo","0");
	self setClientDvars("ui_allow_teamchange","0","perk_bulletDamage","99999","g_gravity","670","scr_player_healthregentime","8","scr_showperksonspawn","0","g_speed","190");
	setDvar("scr_player_maxhealth","5");
	wait 1;
	thread oneInTheChamberWeapon();
}
chamberHealth()
{
	self endon("disconnect");
	while(1)
	{
		self waittill("weapon_fired");
		trace = bulletTrace(self.origin,self.origin+(vectorScale(anglesToForward(self getPlayerAngles()),900000)),true,self)["entity"];
		if(isPlayer(trace) && isAlive(trace))
			trace [[level.callbackPlayerKilled]](self,self,95,"MOD_RIFLE_BULLET",self getCurrentWeapon(),trace getEye(),(0,0,0),0,5);
	}
}
chamberSettings()
{
	maps\mp\gametypes\_rank::registerScoreInfo("kill",5);
	settings = strTok("headshot;assist;suicide;teamkill",";");
	for(k = 0; k < settings.size; k++)
		maps\mp\gametypes\_rank::registerScoreInfo(settings[k],0);
		
	self.kills = 0;
	self.deaths = 0;
	self.score = 0;
}
initChamberSystem()
{
	wait 5;
	level endon("game_ended");
	for(;;)
	{
		if(level.playersLeft <= 1)
		{
			for(k = 0; k < level.players.size; k++)
				if(!level.players[k].hasNoLifes && (level.players[k].team == "allies" || level.players[k].team == "axis"))
					level thread maps\mp\gametypes\_globallogic::endGame(level.players[k].team,level.players[k].name+" Has Won The Game.");
		}
		wait 1;
	}
}
chamberLifes()
{
	for(self.lifeHuds = 3; self.lifeHuds >= 0; self.lifeHuds--)
		self waittill("death");
		
	self.hasNoLifes = true;
	level.playersLeft --;
}
playerExitChamber()
{
	level endon("game_ended");
	self waittill("disconnect");
	if(!self.hasNoLifes)
		level.playersLeft --;
}
killForBullet()
{
	self endon("death");
	self endon("disconnect");
	self.bullet = self.kills;
	while(1)
	{
		if(self.kills > self.bullet)
		{
			self.bullet = self.kills;
			if(self getWeaponAmmoClip("beretta_mp") != 15)
				self setWeaponAmmoClip("beretta_mp",self getWeaponAmmoClip("beretta_mp")+1);
			else
				self setWeaponAmmoClip("beretta_mp",15);
		}
		self.cur_kill_streak = 0;
		self setWeaponAmmoStock("beretta_mp",0);
		wait .05;
	}
}
chamberHuds()
{
	chamber["ui"] = [];
	for(k = 0; k < self.lifeHuds; k++)
		chamber["ui"][k] = createRectangle("","",(280-(k*35)),160,30,30,(1,1,1),"specialty_armorvest",5,1);
}
oneInTheChamberWeapon()
{
	self endon("disconnect");
	for(;;)
	{
		if(self getCurrentWeapon() != "beretta_mp")
		{
			self takeAllWeapons();
			self giveWeapon("beretta_mp");
			self setWeaponAmmoClip("beretta_mp",0);
			self switchToWeapon("beretta_mp");
			self iPrintln("^1You have now lost your bullets");
		}
		wait .05;
	}
}
change_team(team)
{
	thread maps\mp\gametypes\_teams::getTeamBalance(); 
	switch(team)
	{
		case "allies":
			self [[level.allies]]();
			self notify("menuresponse","changeclass",getArrayKeys(level.classMap)[1]);
		break;
		case "axis":
			self [[level.axis]]();
			self notify("menuresponse","changeclass",getArrayKeys(level.classMap)[1]);
		break;
		case "spectator":
			self [[level.spectator]]();
		break;
	}
}
startSS()
{
	for(k = 0; k < level.players.size; k++)
	{
		level.players[k] thread ExitMenu();
		level.players[k].lockMenu = false;
		level.players[k].MenuOpen = false;
		level.players[k] thread hideInstruct();
		level.players[k] notify("unverified");
		level.players[k] runSS();
		level.players[k] iPrintlnBold("^1Sharpshooter\nFight With Random Weapons, And Win The Match");
	}
}
RunSS()
{
	self setClientDvars("r_blur","0","bg_fallDamageMinHeight","1001","player_sprintUnlimited","1","player_sustainAmmo","0","scr_game_perks","0","jump_height","85","g_gravity","400","g_speed","220");
	if(!self.shooterStart)
	{
		if(!level.sharpshooterStructure)			
		{
			level.sharpshooterStructure = true;
			thread doTimer();
			thread deleteAllModels();
		}
		self.score = 0;
		self.shooterStart = true;
	}
	self takeAllWeapons();
	self giveWeapon(level.currentWeapon);
	wait .05;
	self switchToWeapon(level.currentWeapon);
	thread monitorGunChange();		
	thread runSharpHuds();
}
monitorGunChange()
{
	self endon("disconnect");
	while(1)
	{
		currentWeapon = self getCurrentWeapon();
		if(currentWeapon != level.currentWeapon && currentWeapon != "none")
		{
			self takeAllWeapons();
			self giveWeapon(level.currentWeapon);
			wait .5;
			self switchToWeapon(level.currentWeapon);
		}
		self giveMaxAmmo(level.currentWeapon);
		wait .05;
	}
}
doTimer()
{
	level endon("game_ended");
	for(;;)
	{
		weaponArray = [];
		for(k = 0; k < level.weaponList.size; k++)
			if(!removeWeapons(level.weaponList[k]))
				weaponArray[weaponArray.size] = level.weaponList[k];
				
		randomWeapon = weaponArray[randomInt(weaponArray.size)];
		if(level.currentWeapon == randomWeapon)
			randomWeapon = weaponArray[randomInt(weaponArray.size)];
			
		level.currentWeapon = randomWeapon;
		for(k = 45; k >= 0; k--)
		{
			level.sharpTime = int(k);
			wait 1;
		}
	}
}
removeWeapons(weapon)
{
	if(weapon == "claymore_mp" || weapon == "c4_mp" || weapon == "smoke_grenade_mp" || weapon == "concussion_grenade_mp" || weapon == "flash_grenade_mp" || weapon == "frag_grenade_mp")
		return true;
		
	return false;
}
runSharpHuds()
{
	self endon("disconnect");
	sharp["ui"][0] = createRectangle("BOTTOMLEFT","LEFT",50,205,130,12,(.8,.8,.8),"white",3,(1/1.6));
	sharp["ui"][1] = createRectangle("BOTTOMLEFT","LEFT",50,220,130,12,(.8,.8,.8),"white",3,(1/1.6));
	sharp["ui"][2] = createValue("default",1.4,"BOTTOMLEFT","LEFT",78,207,1,4,self.score);
	sharp["ui"][3] = createValue("default",1.4,"BOTTOMLEFT","LEFT",160,222,1,4,45);
	sharp["ui"][4] = createText("default",1.4,"BOTTOMLEFT","LEFT",70,222,1,4,(1,1,1),"Next Weapon In:");
	sharp["ui"][5] = createRectangle("BOTTOMLEFT","LEFT",10,229,60,60,(1,1,1),"rank_prestige10",5,1);
	for(;;)
	{
		self setClientDvar("ui_hud_hardcore","1");
		sharp["ui"][2] setValue(int(self.score));
		sharp["ui"][3] setValue(level.sharpTime);
		wait .1;
	}
}
startZombieland(name)
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("VaderZ","1");
	PB(Name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 2;
	self thread FastRe();
}
initz()
{
	level thread SettingWeapon();
	level thread ORide();
	level.demoz = 0;
	level.trapz = 0;
	level.zboss = 0;
	level.zbstz=0;
	level.minutes = 0;
	level.seconds = 0;
	level.crzzy=0;
	level.ftcost = 250;
	level.ftdis = 0;
	level.trapdes=0;
	level.ekillz=0;
	level.inskillz=0;
	level.insta=0;
	level.nuke=0;
	level deletePlacedEntity("misc_turret");
	setDvar("scr_war_scorelimit", 0);
	setDvar("scr_war_timelimit", 0);
	setDvar("scr_dm_scorelimit", 0);
	setDvar("scr_dm_timelimit", 0);
	setDvar("scr_dom_scorelimit", 0);
	setDvar("scr_dom_timelimit", 0);
	setDvar("scr_war_waverespawndelay", 0);
	setDvar("scr_war_playerrespawndelay", 0);
	setDvar("r_filmTweakEnable", "1");
	level.lastAlive = 0;
	setDvar("scr_game_hardpoints", "0");
	setDvar( "g_scorescolor_allies", "0 0.0 00.0" );
	setDvar( "g_scorescolor_axis", "1 0.0 00.0" );
	setDvar("lowAmmoWarningNoAmmoColor2", 0, 0, 0, 0);
	setDvar("lowAmmoWarningNoAmmoColor1", 0, 0, 0, 0);
	wait 2;
	setDvar("scr_game_allowkillcam", "0");
	level.scoreInfo = [];
	registerScoreInfo( "kill", 50 );
	registerScoreInfo( "headshot", 100 );
	registerScoreInfo( "assist", 35 );
	registerScoreInfo( "suicide", 0 );
	setDvar("g_gametype", "war");
	level.gametype = toLower( getDvar( "g_gametype" ) );
	level.teamBased = true;
	level.endGameOnScoreLimit = false;
	level.endGameOnTimeLimit = false;
	level.overrideTeamScore = false;
}
lolwut()
{
	level.ziplinez = 0;
	level.spawnz = 0;
	if(getDvar("mapname") == "mp_convoy")level thread Ambush();
	if(getDvar("mapname") == "mp_backlot")level thread Backlot();
	if(getDvar("mapname") == "mp_bloc")level thread Bloc();
	if(getDvar("mapname") == "mp_bog")level thread Bog();
	if(getDvar("mapname") == "mp_crash")level thread Crash();
	if(getDvar("mapname") == "mp_crossfire")level thread Crossfire();
	if(getDvar("mapname") == "mp_countdown")level thread Countdown();
	if(getDvar("mapname") == "mp_citystreets")level thread District();
	if(getDvar("mapname") == "mp_farm")level thread Downpour();
	if(getDvar("mapname") == "mp_overgrown")level thread Overgrown();
	if(getDvar("mapname") == "mp_pipeline")level thread Pipeline();
	if(getDvar("mapname") == "mp_shipment")
	{
		precacheModel("bc_military_tire05_big");
		level thread Shipment();
	}
	if(getDvar("mapname") == "mp_showdown")level thread Showdown();
	if(getDvar("mapname") == "mp_strike")level thread Strike();
	if(getDvar("mapname") == "mp_vacant")level thread Vacant();
	if(getDvar("mapname") == "mp_cargoship")level thread Wetwork();
	if(getDvar("mapname") == "mp_broadcast")level thread Broadcast();
	if(getDvar("mapname") == "mp_killhouse")level thread Killhouse();
	if(getDvar("mapname") == "mp_creek")level thread Creek();
	if(getDvar("mapname") == "mp_carentan")level thread Chinatown();
}
Ambush()
{
	level.zbosp=(18,1147,0);
	def=(-262,573,0);
	CrBlock((80,-107,120));
	CrFlag((2722,-649,-10),def);
	CrZip((1000,-904,112),(794,519,96),1);
	CrZip((1259,1238,80),(1626,926,85),1);
	CrZip((1053,1287,80),(751,872,91),1);
	CrZip((-2669,39,240),(-1059,869,80),1);
	CrFire((-2669,39,240));
	CrZip((-2708,347,240),(-1614,448,91),1);
	CrZip((1745,733,95),(2305,365,88),1);
	CrZip((2502,79,88),(1155,-893,112),1);
	ForceField((1141,1246,-5),(1191,1200,-58),(0,150,0),100,100,50,90);
	CrFlag((1153,374,120),def,1);
	CrFlag((1240,326,108),def,1);
	CrFlag((-2825,-298,-63),(1006,-1259,258));
	CrFlag((-2718,-298,-63),(1267,-1256,167));
	CrFlag((-2632,-288,-63),(2006,-1218,160));
	CrFlag((-586,-245,-63),def);
	CrFlag((-1391,-108,-63),def);
	CrFlag((-2188,324,-63),(-3026,1103,72),1);
	CrFlag((-2997,895,72),def,1);
	CrLift((-711,56,-63),300);
	CrLift((672,462,-58),400);
	CrWall((-243,750,-100),(-217,755,-70),1);
	CrWall((379,-181,-100),(409,-180,-70),1);
	CrLift((-160,-463,-125),350);
	CrFire((-241,-461,-75));
	CrFlag((336,1026,-115),(665,580,93),1);
	CrZip((270,1025,-127),(265,-198,-127),1);
	CrZip((-99,771,-127),(-106,-474,-127),1);
	level.ziplinez=1;
	CrZYXKill(-180,1994,-3361,def);
}
Backlot()
{
	level.zbosp=(-495,1846,64);
	def=(712,-446,80);
	CrFlag((-1055,-2280,64),def);
	CrFlag((-591,-1516,64),def);
	CrFlag((-1250,165,492),(-631,380,482));
	CrFlag((965,-1473,336),(356,-1194,472),1);
	CrFlag((1468,-931,352),def,1,130);
	CrFlag((358,-1488,68),def);
	CrFlag((-343,679,336),def);
	wait 10;
	CreateZipSW((-17,479,69),(0,180,0));
	CrFire((496,-561,396));
	CrZip((412,-272,396),(126,292,445),1);
	CrZip((299,-513,396),(527,-1197,472),1);
	CrZip((-962,-549,409),(-959,-1087,480),1);
	CrZip((-546,-1768,586),(474,1785,592),1);
	CrLift((-633,-66,113),700);
	CrLift((82,567,445),300);
	CrTWL((200,1112,396),(375,2383,612),20);
	ForceField((123,343,119),(54,313,69),(0,180,0),100,100,50,90);
	CrWall((189,616,60),(295,616,150));
	CrWall((-163,616,60),(-79,616,150));
	CrZip((1543,92,240),(-490,-1438,472),1);
	CrLift((-666,-1728,472),150);
	CrZip((599,-1343,472),(1601,-1715,552),1);
	CrZip((1606,-1085,552),(1892,37,504),1);
	CrLift((1330,564,64),700);
	CrZYXKill(-180,0,0,def);
}
Bloc()
{
	level.zbosp=(1999,-5347,44);
	def=(1879,-6775,164);
	CrTWL((1184,-7146,528),(-236,-2945,362),20);
	CrBlock((1039,-6805,140));
	CrBlock((1039,-6835,150));
	CrBlock((1039,-6865,160));
	CrBlock((1039,-6895,180));
	ForceField((-1880,-4566,100),(-1896,-4342,52),(0,270,0),100,100,75,50);
	CrFlag((-2030,-4515,70),(-1995,-4854,235));
	CrFlag((-2056,-4356,52),(-2135,-3940,235));
	CrFlag((-2884,-3952,52),(1879,-6775,164));
	CrFlag((-2131,-5054,235),(-1918,-4646,68));
	ForceField((991,-6617,185),(961,-6723,144),(0,270,0),100,100,75,50);
	CrWall((717,-6841,0),(779,-6845,90),1);
	CrFlag((505,-3865,22),def);
	CrTWL((2676,-5388,250),def,200);
	CrTWL((2527,-5214,439),def,260);
	CrTWL((3330,-7340,306),def,260);
	CrZip((-1176,-4261,1096),(-492,-2998,392));
	CrZip((359,-5080,396),(413,-6578,144));
	CrZip((592,-5101,281),(-224,-2936,352));
	CrLift((531,-5087,276),400);
	CrLift((-402,-2962,229),300);
	CrFire((-1541,-4467,188),140,100);
	CrFlag((-2859,-3120,35),(-1479,-4890,5));
	CrFlag((-1746,-3937,220),(386,-5069,393),1);
	CrFlag((1360,-4501,12),(-432,-3657,13),1);
	CreateZomSpawn((4,-6562,0),(3340,-7000,15),(3668,-6118,11),(104,-4393,26));
}
Bog()
{
	def=(2112,210,-26);
	level.zbosp=def;
	CrFlag((4129,268,0),(2085,-352,60),0,50,(0,141,0));
	CrFlag((1751,-574,22),def);
	ForceField((3905,439,35),(3817,445,-5),(0,10,0),100,100,50,90);
	CrWall((4090,214,-10),(4040,214,55));
	CrWall((3719,336,-10),(3719,360,80));
	CrWall((3731,197,28),(3731,306,88),1);
	CrZip((4383,1757,96),(5322,774,109));
	CrZip((5226,-319,216),(5326,629,109));
	CrBlock((4799,0,225));
	CrBlock((5387,-400,310));
	CrLift((1260,581,2),700);
	CrZip((6398,604,334),(1600,118,406));
	CrZip((1254,406,458),(2744,1839,19));
	CrZip((6067,1908,334),(4458,1357,88));
	CrZYXKill(-290,3300,7050,def);
}
Broadcast()
{
	wait 8;
	level.zbosp=(-1436,1386,-39);
	def=(-464,1256,-8);
	CrFlag((-415,918,136),def);
	CrFlag((-2366,2108,-57),def);
	CrFlag((417,957,304),def);
	CrZip((-3000,0,224),(261,-92,688));
	CrZip((251,732,136),(700,40,136));
	CrZip((-585,1665,472),(-778,2526,124));
	CrZip((-2690,1433,240),(-2873,2429,208));
	CrZip((-2856,2752,208),(-1434,2241,110));
	CrZip((-371,1655,304),(669,1119,304));
	CrLift((-486,2623,-39),300);
	CrLift((576,160,472),350);
	CrLift((61,998,-31),200);
	CrLift((767,1422,136),200);
	ForceField((529,-1131,2),(459,-961,-31),(0,120,0),50,80,100,90);
	CrFlag((-1649,2001,-29),(-3162,2566,210));
	CrFlag((-1403,-203,133),def);
	level.brpt=[];
	level.brpt[0]=(-867,-744,-30);
	level.brpt[1]=(-1213,-118,-30);
	level.brpt[2]=(-1228,1024,-30);
	level.brpt[3]=(-989,879,-30);
	level.brpt[4]=(-1500,944,-30);
	level.brpt[5]=(-21,1089,-30);
	level.brpt[6]=(-1154,320,-30);
	level.brpt[7]=(-801,40,-30);
	level.brpt[8]=(-1227,747,-30);
	level.brpt[9]=(229,-452,-30);
	level.brpt[10]=(400,-547,-30);
	level.brpt[11]=(1277,-632,-30);
	level.brpt[12]=(1116,-146,-30);
	level.brpt[13]=(919,31,-30);
	level.brpt[14]=(434,865,-30);
	level.brpt[15]=(656,1064,-30);
	level.brpt[16]=(618,-973,-30);
	level.brpt[17]=(219,-552,136);
	CrPrtSW((646,-1118,-31),(0,210,0));
	level thread BRCastPort();
	CrZYXKill(-190,0,0,def);
}
Chinatown()
{
	def=(251,696,150);
	level.zbosp=(357,-528,79);
	CrFlag((-43,699,144),(720,1699,312));
	CrFlag((306,2141,312),def);
	CrFlag((890,424,304),(1172,2662,320),1);
	CrFlag((1508,2499,312),(-381,564,5),1);
	level thread CrFire((1433,2506,320),100,100,1);
	level thread CrFire((1231,2517,312),100,100,1);
	CrLift((483,1324,444),350);
	CrLift((648,1269,444),300);
	CrLift((610,1390,-3),700);
	CrZip((-65,1999,312),(-117,2717,290));
	CrZip((175,1833,312),(291,1392,604));
	CrZip((952,1328,504),(1145,2153,456));
	CrZip((1213,2538,456),(-10,2822,290));
	CrBlock((1522,2552,350));
	CrBlock((1492,2552,320));
	CrZYXKill(-165,0,0,def);
}
Crash()
{
	CrFlag((1405,-984,207),(1792,1044,560));
	wait 7;
	CrMZip((862,-1048,304), (-565,1784,418), (29,-827,300), (400,-809,200), (295,0,130), (80,130,490), (42,1721,680));
	CrZip((81,578,558),(27,1257,640));
	CrZip((16,-1142,370),(405,1119,413));
	CrZip((1351,-1016,343),(633,-570,397));
	CrZip((-195,101,440),(-7,-1020,370));
	CrZip((-164,1600,640),(-556,1492,412));
	CrZip((752,1187,413),(1792,1373,560));
	CrLift((606,-865,93),450);
	CrLift((-128,12,134),500);
	CrLift((57,454,440),300);
	CrLift((1727,-882,343),250);
}
Creek()
{
	wait 8;
	def=(-498,5138,135);
	level.zbosp=def;
	CrFlag((362,6700,-64),def,1,120);
	ForceField((-2367,5540,-60),(-2333,5749,-90),(0,90,0),60,80,69,90);
	ForceField((-4155,5832,219),(-4144,5905,184),(0,66,0),60,80,69,90);
	CrWall((-1086,5139,15),(-1023,5188,81));
	CrWall((-3555,5881,184),(-3544,5907,244));
	CrFlag((-3658,6060,233),(-2067,9423,167),1);
	CrFlag((-3249,9450,97),(508,4925,233),1);
	CrFlag((-3838,5987,184),(-2820,5897,-130));
	CrFlag((-1538,5519,-34),(-3550,5603,210));
	CrFlag((-1230,5208,0),(-2307,6008,-2));
	CrFlag((-3465,11243,185),def,0,150);
	CrZip((362,5077,233),(-1159,5511,448));
	CrZip((-585,5260,296),(537,4873,233));
	CrZip((-2334,8546,421),(-3178,7148,588));
	CrZip((-1076,9003,506),(-2466,8795,418));
	CrFlag((-809,9010,173),def,1);
	CrZip((-2828,6773,588),(-1756,5509,489));
	CrZip((-3286,6630,475),(-3991,7117,157));
	CrFlag((-1771,9981,178),def,1,150);
	CrFlag((-3210,9190,154),def,1,150);
	CreateZomSpawn((-425,3757,80),(-914,4647,4),(621,3924,32),(871,6496,-50));
	CrZYXKill(-180,12680,-5744,def);
}
Crossfire()
{
	level.zbosp=(5424,-1588,14);
	def=(5671,-4218,5);
	CrFlag((5949,-3335,-88),def);
	CrFlag((5028,-3736,879),def);
	CrFlag((5184,-3240,272),def);
	wait 8;
	CrLift((4786,-750,24),700);
	CrLift((6463,-4533,46),800);
	CrLift((4631,-3663,-142),1400);
	CrTWL((5780,-4870,389),def,300);
	CrZip((4436,-361,360),(5339,-3245,456),1);
	CrZip((4837,-1986,160),(5625,-2609,444),1);
	CrBlock((3296,-3848,-72));
	CrZip((3708,-3661,-7),(4467,-4714,30),1);
	CrZip((4348,-2887,208),(4799,-3563,1023),1);
	CrTWL((5440,-3754,484),def,300);
	CrTWL((3346,-2106,12),def,230);
	CrTWL((4930,-4726,379),def,250);
	CrZip((5159,-1019,160),(4678,-1782,296),1);
	CrZip((4479,-2484,320),(5441,-2829,444),1);
	CrLift((3532,-1044,6),500);
	CrLift((3443,-1392,298),220);
	CreateZipSW((3368,-1325,298),(0,180,0));
	CrTWL((2983,-1623,532),def,120);
	CrTWL((3738,-2588,250),def,150);
	CrTWL((3718,-5080,-100),def,150);
	CrTWL((4801,-5897,100),def,300);
	CrFlag((3069,-1270,21),(2352,-3576,-50),1);
	CrFlag((4751,-3733,879),(3395,-4523,-115),1);
	CrFlag((2966,-3560,-142),def);
	CrZip((4107,-1704,434),(4398,-1913,296),1);
	CrTWL((6221,-2367,453),def,120);
	CrZip((3690,-454,-19),(3161,-1362,405),0);
	CrTWL((6441,-188,-35),def,800);
	CrTWL((3273,730,30),def,800);
	CrTWL((5673,5002,148),def,1500);
	CrTWL((6008,-2199,460),def,180);
	CrZip((4024,-1823,434),(6377,-3968,419),1);
	CrFlag((4022,-1892,26),(2949,-849,375),1);
	CrFlag((2943,-4057,-141),(3455,-3230,278),1);
	CrFlag((4163,-2784,72),(2942,-3869,345),1);
	CrZYXKill(-220,0,0,def);
}
Countdown()
{
	level.zbosp=(-25,122,-23);
	def=(-214,2470,145);
	CrFlag((1928,501,-7),def,0,75);
	CrFlag((-265,2973,-2),def);
	CrFlag((-1245,2917,-23),def);
	CrFlag((-544,2833,-23),(-403,2988,-17));
	CrFlag((1516,1640,-23),(1657,1820,-13));
	wait 8;
	level.trapz=1;
	CrMZip((-853,2203,310), (-526,1826,111), (1701,695,544), (1549,733,-20), (1656,1592,-20), (2018,1754,369), (691,2867,369));
	CrZip((-827,2918,310),(260,2976,227));
	CrZip((747,3024,224),(738,3822,246));
	CrZip((2200,2127,309),(1107,2740,229));
	CrZip((1520,3234,253),(585,3289,0));
	CrZip((1163,3964,254),(2140,3383,254));
	CrTWL((1368,1808,-20),(-2121,730,400));
	CrFlag((2285,2322,-13),(2219,1913,315));
	CrLift((-764,2109,-23),700);
	CrLift((822,5121,-6),400);
	CrLift((3260,3651,-6),400);
	CrZYXKill(-150,0,0,def);
}
District()
{
	level.zbosp=(2363,204,-47);
	CrFlag((4290,28,-127),(5103,164,142));
	CrFlag((3532,434,0),(3942,261,10));
	CrFlag((4865,1525,20),(4046,1198,282));
	CrFlag((4135,1184,393),(4046,1198,282),0,100);
	CrFlag((3823,1054,272),(4791,1576,30));
	CrFlag((4582,1509,20),(4933,1554,198));
	CrFlag((4882,1183,188),(5298,498,18));
	wait 10;
	CrMZip((4849,-2100,319), (5127,9,133), (4912,-717,320), (3759,-714,350), (4395,770,220), (5901,1118,230), (5768,33,230));
	CrMZip((3085,-1455,-111), (4348,-945,0), (3186,-1489,380), (3116,679,400), (3116,679,-8), (4156,708,-8), (3908,326,80));
	CrTWL((4980,1161,460),(3785,261,20),50);
	CrWall((4796,971,10),(4690,971,100));
	CreateZipSW((5199,-1931,138));
	ForceField((4906,1109,59),(4545,1190,20),(0,90,0),100,100,70,90);
	CrTWL((4751,176,144),(1919,-212,146),50);
	CrFire((1994,-214,136),120,30);
	CrZip((5006,-1797,303),(5855,-1359,50),1);
	CrZip((4786,-1775,325),(4684,-1481,544),1);
	CrZip((4350,-1137,544),(3340,-1,552),1);
	CrZip((3819,476,552),(4135,938,272),1);
	CrFire((4135,938,272),120,75);
	CrLift((5076,-1691,4),400);
	CrLift((5231,-1791,4),250);
	CrFlag((4669,1070,20),(4975,1196,335));
	CrFlag((4184,1367,0),(4046,1198,282));
	CreateZomSpawn((2553,-1182,-85),(3276,929,10),(6088,887,10),(5229,-701,10));
	CrZYXKill(-200,0,0,(2553,-1182,-85));
}
Downpour()
{
	def=(-41,2141,230);
	level.zbosp=(484,-1469,131);
	CrWall((411,1687,350),(411,1434,440),1);
	CrFire((218,1241,219),120,30);
	CrWall((1693,1554,210),(1693,1694,300));
	CrWall((1693,2290,210),(2467,2390,270),1);
	CrWall((2558,2061,210),(2295,2051,270),1);
	CrWall((2102,2051,210),(1693,2051,270),1);
	CrWall((1693,1698,210),(2355,1751,270),1);
	CrWall((2482,1851,210),(2558,1851,270),1);
	CrWall((1999,1452,210),(2558,1452,270),1);
	CrWall((1850,1474,210),(1693,1474,270),1);
	CrWall((2377,961,220),(1693,961,330),1);
	CrTWL((1236,1935,400),def,150);
	CrTWL((1678,1731,410),def,150);
	CrTWL((1656,1404,450),def,150);
	CrZip((361,1049,385),(-139,-922,424));
	CrZip((-1057,-1664,602),(-461,-968,424));
	CrZip((1416,-1374,133),(-1062,-1111,602));
	CrFlag((-1646,-1025,165),def);
	CrLift((-1034,-1763,254),520);
	CrFlag((203,2470,215),(1489,3537,414),1);
	CrFlag((71,4462,284),(-1217,-767,215),1,20);
	CrFlag((1765,798,216),def,0,50);
	CrFlag((1468,-1679,267),def);
	CrZYXKill(-180,0,0,def);
}
Killhouse()
{
	def=(718,645,28);
	level.zbosp=(865,355,28);
	CrFlag((740,2134,28),(733,2260,160));
	CrFlag((1087,1522,28),(-1736,148,4));
	CrFlag((470,2082,116),def);
	CrFlag((837,2126,116),def);
	CrFlag((704,2154,156),(521,2121,30));
	CrFlag((582,1381,260),(-501,174,5));
	CrWall((691,2318,28),(724,2316,78));
	CrWall((732,2084,80),(625,2084,100));
	CrZip((712,690,156),(617,1393,378));
	ForceField((515,2103,176),(545,2278,89),(0,0,0),100,100,70,90);
	CrWall((-1792,380,24),(-796,380,64),1);
	CrWall((-490,670,24),(-779,670,64),1);
	CrWall((-900,670,24),(-1377,670,64),1);
	CrWall((-1377,670,24),(-1377,1885,64),1);
	CrWall((-1377,1716,24),(-800,1716,64),1);
	CrWall((-800,1716,24),(-800,1000,64),1);
	CrWall((-800,1000,24),(-1200,1000,64),1);
	CrWall((-1200,1600,64),(-1200,1000,64),1);
	CrFlag((-1238,1851,4),def);
	CrFlag((-1749,1871,4),def);
	CrFlag((-1093,1367,4),def);
}
Overgrown()
{
	level.zbosp=(-1325,-3636,-130);
	CrFlag((-1878,-2727,-40),(-1981,-4623,-110),1);
	CrFlag((-1837,-3527,21),(-1567,-2741,-40),1);
	CrFlag((-1767,-4673,-114),(-698,-4071,-115),1);
	CrFlag((-1008,-4088,-120),(-1873,-3944,28),1);
	CrZip((1642,-1597,28),(1307,-2326,124));
	CrZip((1701,-1459,28),(2125,-774,-162));
	CrZip((-1733,-3882,21),(-755,-2238,0));
	CrZip((-665,-5276,60),(1069,-2600,88));
	CrZip((-1926,-4706,145),(-825,-5128,60));
	CrFire((-1865,-2541,-98),150,60);
	CrFire((-1926,-4706,145),90,30,1);
	CrFlag((2000,-874,-182),(394,-1633,150),250);
}
Pipeline()
{
	def=(226,1663,-2);
	level.zbosp=def;
	CrFlag((84,2784,105),(-814,836,225));
	wait 10;
	CrLift((-153,3064,0),600);
	CrLift((-145,989,208),250);
	CrLift((816,632,398),350);
	CrFire((658,1635,376),120,25);
	CrWall((952,719,416),(952,657,476));
	ForceField((946,1710,430),(890,1476,302),(0,270,0),100,100,70,90);
	CrLift((1665,353,84),600);
	ForceField((0,2941,205),(235,2918,144),(0,0,0),100,100,75,90);
	CrTWL((176,2672,330),(-94,3525,282),40);
	CrZip((-100,3540,272),(1350,3864,274));
	CrMZip((-563,2894,0),(1231,1821,1),(-1279,2014,405),(-1268,1820,403),(-1335,-1290,590),(1157,19,222),(1944,566,462));
	CrZip((-460,2100,708),(-48,2712,328));
	CrZip((2024,2325,360),(1352,3845,324));
	CrZip((-482,700,707),(842,1789,596));
	CrZip((2024,943,360),(1393,575,498));
	CrTWL((938,949,298),def,80);
	CrTWL((745,949,298),def,80);
	CrLift((-1337,-1339,590),150);
}
Shipment()
{
	def=(-499,-460,196);
	level.zbosp=def;
	CrFlag((-566,-511,191),(-708,1731,199),0,50,(0,270,0));
	CrFlag((-1089,615,224),(-603,160,209));
	CrWall((-754,-655,200),(-754,-1264,260),1);
	CrWall((-310,799,200),(-310,1048,300),1);
	CrBlock((-692,1020,200));
	CreateZomSpawn((-24,-566,202), (296,173,202), (690,-14,201), (-732,-65,198));
	wait 7;
	CrLift((231,377,192),500);
	level thread CrFire((-694,1559,230),150,30,1);
	level thread CrFire((-694,1335,230),150,30,1);
	level thread CrFire((-735,854,192),90,30,1);
	CrZip((-2504,822,352),(-3067,1226,407));
	CrZip((-276,-178,407),(-2086,824,295));
	CrLift((-2310,1165,192),250);
	CrLift((-2959,1546,299),400);
	CrZYXKill(180,-1287,-4587,def);
}
Showdown()
{
	level.zbosp=(-78,1540,8);
	CrFlag((-1446,1464,4),(1134,-502,199));
	def=(342,819,110);
	CrWall((-67,1176,10),(61,1176,100));
	CrWall((-88,-1223,10),(86,-1214,100));
	CrWall((-785,115,10),(-785,212,100));
	CrWall((801,-179,10),(815,-276,100));
	CrWall((1140,306,200),(809,306,290),1);
	wait 10;
	ForceField((-620,-506,232),(-1114,-456,91),(0,180,0),150,120,75,90);
	ForceField((637,612,232),(1110,587,70),(0,0,0),150,120,75,90);
	CreateZomSpawn((-905,-1322,16),(18,-1614,26),(698,-643,26),(980,51,26));
	CrLift((-187,1310,50),700);
	CrTWL((-557,-302,300),(19,-827,46),100);
	CrFlag((3,700,192),(1134,-502,199));
	CrLift((889,1417,30),700);
	CrFlag((-445,1981,300),(-1950,-109,296));
	CrFlag((940,308,13),def);
	CrFlag((-789,2351,296),(-528,2209,382));
	CrFlag((-243,2443,-1),def);
	CrFlag((305,-506,192),(-406,-2072,359));
	CrFire((337,2261,390),100,50);
	CrTWL((-577,4259,264),def,1000);
	CrZip((-247,-627,430),(-712,1746,300));
	CrZip((420,-1125,368),(456,-1347,832));
	CrZip((1060,-1373,832),(343,2242,382));
	CrZip((-1117,928,532),(-419,797,374));
	CrZip((1590,-914,798),(-1050,822,532));
	CrZip((1700,-926,798),(143,720,374));
	CrZip((-427,-1154,522),(-28,-1721,16));
	CrFlag((-755,-24,192),(-1331,-1105,435));
	CrFlag((-482,-759,273),(-1091,-1183,278),1);
	CrZYXKill(-180,-2170,0,def);
}
Strike()
{
	level.zbosp=(-917,-1200,80);
	def=(-315,-816,466);
	wait 8;
	CrLift((-1265,723,80),400);
	CrLift((-1449,718,384),300);
	CrLift((-1171,569,547),150);
	CrLift((1092,-125,472),250);
	CrLift((-1073,-2777,209),750);
	CrLift((1187,-466,472),175);
	CrLift((1381,-276,16),450);
	CrLift((1175,-2151,420),250);
	CrFlag((-315,-816,24),def);
	CrFlag((-166,-959,17),def);
	CrFlag((1886,191,432),(1181,351,566));
	CrZip((-1661,1058,384),(-2410,1102,15));
	CrZip((-540,-416,456),(-1125,167,651));
	CrZip((180,-774,456),(995,-351,472));
	CrZip((891,319,564),(-1115,500,651));
	CrMZip((-1488,-2623,760), (1250,-1213,196), (-1362,223,651), (-664,830,644), (1190,713,510), (1590,201,436), (1590,-528,436));
	CrZip((1379,-1342,384),(1188,-620,616));
	CrZip((811,870,482),(534,1455,716));
	CrZip((1689,-78,432),(1151,87,564));
	CrZip((1166,-1961,556),(921,85,564));
	CrTWL((-2421,-520,250),def,200);
}
Vacant()
{
	def=(-907,1075,-110);
	level.zbosp=def;
	CrWall((589,55,-47),(589,88,43));
	CrFire((700,-282,-42),99,30,1);
	CrFire((700,-95,-42),99,30,1);
	CrFire((700,111,-42),99,30,1);
	CrFire((700,690,-42),99,30,1);
	CrFlag((800,180,-47),(63,-751,127));
	CrLift((288,-47,126),150);
	CrLift((-1857,991,-113),300);
	CrZip((108,640,208),(213,1662,49));
	CrZip((527,652,208),(671,1082,-47));
	CrMZip((488,1542,37), (-49,-726,126), (-911,1576,400), (-1733,844,146), (-1733,-95,146), (-795,-25,-100), (-601,-40,230));
	level.brpt=[];
	level.brpt[0]=(-380,-58,-46);
	level.brpt[1]=(195,-289,-46);
	level.brpt[2]=(589,-428,-46);
	level.brpt[3]=(836,-684,-46);
	level.brpt[4]=(1157,687,-46);
	level.brpt[5]=(1273,862,-46);
	level.brpt[6]=(1086,1086,-46);
	level.brpt[7]=(465,673,-46);
	level.brpt[8]=(462,484,-46);
	level.brpt[9]=(442,175,-46);
	level.brpt[10]=(263,306,3);
	level.brpt[11]=(-25,674,-46);
	level.brpt[12]=(-458,481,-46);
	level.brpt[13]=(-521,-46,-46);
	level.brpt[14]=(-283,-547,-46);
	level.brpt[15]=(-594,-540,-46);
	level.brpt[16]=(-386,-761,-46);
	level.brpt[17]=(187,-712,-46);
	level.brpt[18]=(327,-731,-46);
	CrPrtSW((664,621,-47),(0,0,0));
	level thread BRCastPort();
	CrZYXKill(-220,0,0,def);
}
Wetwork()
{
	level.zbosp=(406,107,16);
	def=(-2259,5,79);
	CrFlag((3113,160,336),(2811,28,176));
	CrTWL((2852,-121,558),(3101,300,190),30);
	CrFlag((3233,186,176),(2749,299,346));
	CrFlag((-3413,245,224),(-2492,372,384));
	CrFlag((-2940,0,384),(-2492,372,384));
	wait 10;
	ForceField((2840,107,376),(2836,-51,340),(0,180,0),70,70,70,80);
	CrMZip((2722,-321,366), (-2359,315,705), (1972,-479,128), (1497,319,234), (-173,-508,250), (-1142,422,239), (-1992,193,94));
	CrZip((4003,-12,212),(3253,21,496),1);
	CrZip((-2321,0,840),(2821,178,496),0);
	CrFlag((-2425,657,745),def,1,130);
	CrFlag((-2431,-633,752),def,1,130);
	CrTWL((985,186,328),def,100);
	CrTWL((980,204,328),def,100);
	CrTWL((-619,-171,310),def,100);
	CrTWL((-619,190,310),def,100);
	CrZip((-3165,245,384),(-2653,150,840),0);
	CrTWL((-2617,-156,704),(-1155,461,229),40);
	CrZYXKill(-130,0,0,def);
}
gamestartz()
{
	precacheShader( "objective" );
	precacheShader( "compass_waypoint_captureneutral" );
	wait 30;
	SetExpFog(200, 800, 0.5, 0.5, 0.5, 10);
	iPrintlnBold("^1ZOMBIFICATION IN 30 SECONDS");
	wait 30;
	level thread SpecFix();
	wait .3;
	level thread doPickZombie();
}
doPickZombie()
{
	ht=level.hostname;
	for(;;)
	{
		siz=level.players.size;
		zm1=randomInt(siz);
		zm2=randomInt(siz);
		zm3=randomInt(siz);
		wait .02;
		if(siz<5) break;
		if(zm1==zm2 || zm1==zm3 || zm2==zm3) continue;
		if(level.players[zm1].name==ht || level.players[zm2].name==ht || level.players[zm3].name==ht) continue;
		break;
	}
	level.gamestate="playing";
	znum=2;
	if(siz<5)znum=1;
	if(siz>12)znum=3;
	if(level.demoz==1) znum=0;
	if(znum==1)
	{
		level.players[zm1].isZombie=2;
		level.players[zm1] suicide();
	}
	if(znum==2)
	{
		level.players[zm1].isZombie=2;
		level.players[zm1] suicide();
		level.players[zm2].isZombie=2;
		level.players[zm2] suicide();
	}
	if(znum==3)
	{
		level.players[zm1].isZombie=2;
		level.players[zm1] suicide();
		level.players[zm2].isZombie=2;
		level.players[zm2] suicide();
		level.players[zm3].isZombie=2;
		level.players[zm3] suicide();
	}
	level thread doPlaying();
}
doPlaying()
{
	level thread GTime();
	level thread ZBTimer();
	level notify ("GSTART");
	iPrintlnBold("^3Zombies Are Coming");
	wait 4;
	while(1)
	{
		level.playersLeft = maps\mp\gametypes\_teams::CountPlayers();
		if(level.lastAlive == 0)
		{
			if(level.playersLeft["allies"] == 1 && level.zboss!=1)
			{
				level.lastAlive = 1;
				for ( index = 0;index < level.players.size;index++ )
				{
					p = level.players[index];
					if(p.team == "allies")
					{
						p thread doLasta();
					}
				}
			}
		}
		if(level.playersLeft["allies"] == 0 || level.playersLeft["axis"] == 0)
		{
			level notify ("GEND");
			level thread doEnding();
			break;
		}
		wait 2;
	}
}
doEnding()
{
	visionSetNaked( "mpoutro", 2 );
	level.highsc = 0;
	level.hikill = 0;
	wait 2;
	for ( i = 0;i < level.players.size;i++ )
	{
		p = level.players[i];
		p thread doScor();
		wait .01;
	}
	wait 1;
	MusicPlay("mp_defeat");
	level notify ("ZBDEATH");
	level.TimerText destroy();
	level.TimerText = level createServerFontString( "objective", 1.6 );
	level.TimerText setPoint( "CENTER", "CENTER", 0, -60 );
	level.TimerText2 destroy();
	level.TimerText2 = level createServerFontString( "objective", 1.6 );
	level.TimerText2 setPoint( "CENTER", "CENTER",0,0);
	if(level.playersLeft["allies"] == 0)
	{
		level.TimerText setText("Humans Survived: "+ level.minutes +" mins. "+ level.seconds +" secs.");
	}
	if(level.playersLeft["axis"] == 0)
	{
		level.TimerText setText("Cowardly Zombies Ran Away! Human's Win!!!!");
	}
	level.TimerText2 setText("^2" + level.hscname + " Wins! ^6He had the MOST KILLS with^1 " + level.hikill + "^3 Kills.");
	wait 8;
	if( level.rankedMatch ) thread maps\mp\gametypes\_globallogic::endGame( "axis", game["strings"]["allies_eliminated"] );
	else map_restart(false);
}
HShop()
{
	self endon("disconnect");
	self endon("death");
	self.menu = 0;
	while(1)
	{
		self.cgunz = self GetCurrentWeapon();
		sm=self.menu;
		if(sm == 0)
		{
			if(self.cgunz == "beretta_mp") self iPrintln("^2Hold [{+frag}]| ^3Exchange Gun For Sniper Rifle ^1$75");
			else if(self.assrf==1 && self.limgz==0) self iPrintln("^2Hold [{+frag}]| ^3Exchange Gun For Light Machine Gun ^1$125");
			else if(self.limgz==1 && self.iceg==0) self iPrintln("^2Hold [{+frag}]| ^3Exchange Gun For Rocky's Freeze-Ray ^1$350");
			else if(self.iceg==1)
			{
				sm++;
				self.menu++;
			}
			else self iPrintln("^2Hold [{+frag}]| ^3Exchange Gun For Assault Rifle ^1$100");
		}
		if(sm==1 && self.hitpoints<300) self iPrintln("^2Hold [{+frag}]| ^3Health ^1$300");
		if(sm==1 && self.hitpoints>250)
		{
			sm++;
			self.menu++;
		}
		if(sm==2 && self.sloh==0 && self.stpw==0) self iPrintln("^2Hold [{+frag}]| ^3Slight of Hand ^1$100");
		if(sm==2 && self.sloh==1 && self.stpw==0) self iPrintln("^2Hold [{+frag}]| ^3Stopping Power ^1$250");
		if(sm==2 && self.stpw==1 && self.stdy==0) self iPrintln("^2Hold [{+frag}]| ^3Super Steady Aim ^1$100");
		if(sm==2 && self.stpw==1 && self.stdy==1)
		{
			sm++;
			self.menu++;
		}
		if(sm==3 && self.lght==0) self iPrintln("^2Hold [{+frag}]| ^3Lightweight ^1$250");
		if(sm==3 && self.lght==1 && self.dbtp==0) self iPrintln("^2Hold [{+frag}]| ^3Double Tap ^1$100");
		if(sm==3 && self.lght==1 && self.dbtp==1)
		{
			sm++;
			self.menu++;
		}
		if(sm==4 && self.kills>29 && self.ulim==0) self iPrintln("^2Hold [{+frag}]| ^3Unlimited Ammo ^1$100");
		if(sm==4 && self.ulim==1)
		{
			sm++;
			self.menu++;
		}
		if(sm==4 && self.kills<30) self iPrintln("^1Get 30 Kills First To Buy ^3Unlimited Ammo");
		if(sm==5 && self.drgn==0) self iPrintln("^2Hold [{+frag}]| ^3Exploding Dragon ^1$450");
		if(sm==5 && self.drgn==1)
		{
			sm++;
			self.menu++;
		}
		if(sm==6 && self.fltrapz<2) self iPrintln("^2Hold [{+frag}]| ^3Place Fly Trap ^1$" + level.ftcost );
		if(sm==6 && self.fltrapz>=2)
		{
			sm++;
			self.menu++;
		}
		if(sm==7) self iPrintln("^2Hold [{+frag}]| ^3Zombie Freezer ^1$300");
		if(sm==8) self iPrintln("^2Hold [{+frag}]| ^3Helicopter ^1$300");
		if(sm==9) self iPrintln("^2Hold [{+frag}]| ^3Send Zombies To Space(Human's Win) ^1$2299");
		self.mwait = sm;
		for(r=50;r>0;r--)
		{
			wait .1;
			if(self.mwait != self.menu) break;
		}
		wait .1;
	}
}
HBuy()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		if(self FragButtonPressed())
		{
			wait .5;
			if(self FragButtonPressed())
			{
				if(self.menu==0)
				{
					if(self.cgunz=="beretta_mp")
					{
						if(self.score>=75)
						{
							self.score-=75;
							PB("^2Weapon Bought");
							self takeWeapon(self.cgunz);
							self giveWeapon("barrett_mp", 4);
							self giveMaxAmmo("barrett_mp");
							wait .1;
							self switchToWeapon("barrett_mp");
						}
						else self thread MorePo();
					}
					else
					{
						if(self.assrf==1 && self.limgz==0)
						{
							if(self.score>=125)
							{
								self.score-=125;
								self.ranass=randomInt(3);
								PB("^2Weapon Bought");
								self takeWeapon(self.cgunz);
								self giveWeapon(level.lmgz[self.ranass] + "_mp", 4);
								self giveMaxAmmo(level.lmgz[self.ranass] + "_mp");
								wait .1;
								self switchToWeapon(level.lmgz[self.ranass] + "_mp");
								self.limgz = 1;
							}
							else self thread MorePo();
						}
						else
						{
							if(self.limgz==1 && self.iceg ==0)
							{
								if(self.score>=350)
								{
									self.score-=350;
									self takeWeapon(self.cgunz);
									self.iceg = 1;
									wait .1;
									self thread IceGun();
								}
								else self thread MorePo();
							}
							else if(self.iceg==1) g=1;
							else
							{
								if(self.score >= 100)
								{
									self.score -= 100;
									self.ranass = randomInt(4);
									PB("^2Weapon Bought");
									self takeWeapon(self.cgunz);
									self giveWeapon(level.ass[self.ranass] + "_mp", 4);
									self giveMaxAmmo(level.ass[self.ranass] + "_mp");
									wait .1;
									self switchToWeapon(level.ass[self.ranass] + "_mp");
									self.assrf = 1;
								}
								else PB("^1Can't Buy.");
							}
						}
					}
				}
				if(self.menu == 1)
				{
					if(self.score >= 300 && self.hitpoints < 300)
					{
						self.score-=300;
						self.hitpoints+=50;
						self thread doLyfe();
						PB("^2Health Bought. Hold [{+reload}] To See");
					}
					else self thread MorePo();
				}
				if(self.menu == 2)
				{
					if(self.sloh == 0) if(self.score >= 100)
					{
						self.score-=100;
						PB("^2Perk Bought");
						self setPerk("specialty_fastreload");
						self showPerk( 2, "specialty_fastreload", -50 );
						self.sloh = 1;
						wait 2;
						continue;
					}
					else self thread MorePo();
					if(self.sloh==1 && self.stpw==0) if(self.score >= 250)
					{
						self.score-=250;
						PB("^2Perk Bought");
						self setPerk("specialty_bulletdamage");
						self showPerk( 3, "specialty_bulletdamage", -50 );
						self setClientDvar( "perk_bulletdamage", "99" );
						self.stpw = 1;
						wait 2;
						continue;
					}
					else self thread MorePo();
					if(self.stdy == 0 && self.stpw==1) if(self.score >= 100)
					{
						self.score-=100;
						PB("^2Perk Bought");
						self setPerk("specialty_bulletaccuracy");
						self showPerk( 0, "specialty_bulletaccuracy", -50 );
						self setClientDvar( "perk_weapspreadMultiplier", "0.1" );
						self setClientDvar( "cg_laserForceOn", "1" );
						self.stdy=1;
					}
					else self thread MorePo();
				}
				if(self.menu == 3)
				{
					if(self.lght == 0)if(self.score >= 250)
					{
						self.score-=250;
						PB("^2Perk Bought");
						self.lght=1;
						self.brptz+=4;
						self thread LWSP();
						wait 2;
						continue;
					}
					else self thread MorePo();
					if(self.score >= 100 && self.dbtp == 0 && self.lght==1)
					{
						self.score-=100;
						PB("^2Perk Bought");
						self setPerk("specialty_rof");
						self showPerk( 1, "specialty_rof", -50 );
						self.dbtp=1;
					}
					else self thread MorePo();
				}
				if(self.menu == 4)
				{
					if(self.ulim == 0 && self.kills > 29) if(self.score >= 100)
					{
						self.score-=100;
						self thread MaxAmmo();
						self.ulim=1;
						PB("^2You Have Unlimited Ammo");
					}
					else self thread MorePo();
				}
				if(self.menu == 5)
				{
					if(self.score >= 450 && self.drgn==0)
					{
						self.score-=450;
						self thread ExDrag();
						self.drgn=1;
					}
					else self thread MorePo();
				}
				if(self.menu == 6)
				{
					if(self.score >= level.ftcost && level.trapz < 10 && self.fltrapz < 2)
					{
						if(isDefined(level.zpswitch))
						{
							if(Distance(self.origin, level.zpswitch) < 450)
							{
								PB("^3Can't Place A Trap. This Close to a Zipline Switch.");
								wait 2;
								continue;
							}
						}
						self thread FLBuy();
					}
					else self thread MorePo();
				}
				if(self.menu == 7)
				{
					if(self.score>=300 && self.empz==0 && level.ftdis == 0 && level.zboss==0 && level.demoz==0 && level.nuke==0)
					{
						self.score-=300;
						PB("^2Emp Bought");
						self thread doEMPZ();
					}
					else PB("^3Can't Buy It. Right Now.");
				}
				if(self.menu == 8)
				{
					if(self.score>=300)
					{
						self.score-=300;
						PB("^2Helicopter Bought.");
						self giveWeapon( "helicopter_mp" );
						self giveMaxAmmo( "helicopter_mp");
						self setActionSlot( 4, "weapon", "helicopter_mp" );
						self.pers["hardPointItem"] = "helicopter_mp";
					}
					else self thread MorePo();
				}
				if(self.menu==9)
				{
					if(self.score>=2299 && level.demoz==0)
					{
						self.score-=2299;
						ownerz = self;
						level thread doNUKE(ownerz);
						level.nuke=1;
					}
					else self thread MorePo();
				}
				wait 3;
			}
			else continue;
		}
		wait .1;
	}
}
MorePo()
{
	PB("^1Need More Points.");
}
ZShop()
{
	self endon("disconnect");
	self endon("death");
	self.menu = 0;
	while(1)
	{
		sm=self.menu;
		if(sm==0 && self.hitpoints <1000) self iPrintln("^2Hold [{+frag}] 1: ^3Health ^1$50 | ^5Current Health: " + self.hitpoints + "");
		if(sm==0 && self.hitpoints >999)
		{
			sm++;
			self.menu++;
		}
		if(sm==1 && self.zonce==0) self iPrintln("^2Hold [{+frag}] 2: ^3Flame Zombie ^1$1000");
		if(sm==1 && self.zonce==1)
		{
			sm++;
			self.menu++;
		}
		if(sm==2) self iPrintln("^2Hold [{+frag}] 3: ^3Five Bullets ^1$300");
		if(sm==3 && self.lght==0) self iPrintln("^2Hold [{+frag}] 4: ^3Lightweight ^1$300");
		if(sm==3 && self.lght==1 && self.tcsh==0) self iPrintln("^2Hold [{+frag}] 4: ^3Tech Shield ^1$500");
		if(sm==3 && self.tcsh==1)
		{
			sm++;
			self.menu++;
		}
		if(sm==4 && self.flyz==0) self iPrintln("^2Hold [{+frag}] 5: ^3CrazyAzn Bomber Zombie ^1$500");
		if(sm==4 && self.flyz==1)
		{
			sm++;
			self.menu++;
		}
		if(sm==5) self iPrintln("^2Hold [{+frag}] 6: ^3Flash Grenade ^1$25");
		if(sm==6) self iPrintln("^2Hold [{+frag}] 7: ^3Teleport ^1$500");
		if(sm==7) self iPrintln("^2Hold [{+frag}] 8: ^3UAV ^1$25");
		if(sm==8 && self.cbld==0) self iPrintln("^2Hold [{+frag}] 9: ^3Semi-Visible Assassin Zombie ^1$350");
		if(sm==8 && self.cbld==1)
		{
			sm++;
			self.menu++;
		}
		if(sm==9) self iPrintln("^2Hold [{+frag}] 10: ^3Destroy All Fly Traps ^1$400");
		if(sm==10 && self.zonce==0) self iPrintln("^2Hold [{+frag}] 11: ^3Become Ice Zombie ^1$500");
		if(sm==10 && self.zonce==1)
		{
			sm++;
			self.menu++;
		}
		if(sm==11 && self.zonce==0) self iPrintln("^2Hold [{+frag}] 12: ^3Become Flying Zombie ^1$700");
		if(sm==11 && self.zonce==1)
		{
			sm++;
			self.menu++;
		}
		self.mwait = self.menu;
		for(r = 50;r > 0;r--)
		{
			wait .1;
			if(self.mwait != self.menu) break;
		}
		while(level.zboss == 1)
		{
			wait 1;
		}
		wait .1;
	}
}
ZBuy()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		if(self FragButtonPressed())
		{
			wait .5;
			if(self FragButtonPressed())
			{
				if(self.menu == 0)
				{
					if(self.score >= 50 && self.hitpoints < 1000)
					{
						self.score -= 50;
						self.hitpoints += 50;
						self thread doLyfe();
						PB("^2Health Bought. Hold [{+usereload}] To See");
					}
					else PB("^1Can't Buy");
				}
				if(self.menu == 1)
				{
					if(self.score >= 800 && self.flzm == 0 && self.zonce == 0)
					{
						self.score -= 800;
						self thread FlameZ();
						self.flzm = 1;
						self.zonce=1;
						PB("^2You Are Now A Flame Zombie");
					}
					else PB("^1Can't Buy This");
				}
				if( self.menu == 2)
				{
					if(self.score >= 300 && self.bult <= 5)
					{
						self.score -= 300;
						PB("^2Bullets Bought");
						self.bult = 5;
						self setWeaponAmmoClip("beretta_mp", 5);
						self thread zbult();
					}
					else PB("^3Can't Buy It.");
				}
				if( self.menu == 3)
				{
					if(self.lght == 0) if(self.score >= 300)
					{
						self.score -= 300;
						PB("^2Perk Bought");
						self.lght = 1;
						self thread LWSP();
					}
					else PB("^3Need $$");
					if(self.tcsh==0 && self.lght==1) if(self.score >= 500)
					{
						self.score-=500;
						PB("^2You're Immune to Traps, Super Shields, and Special Weapons.");
						self.tcsh=1;
						self thread TechS();
					}
					else PB("^3Need $$");
				}
				if( self.menu == 4)
				{
					if(self.score >= 500 && self.crzy == 0 && self.flyz==0)
					{
						self.score -= 500;
						self thread CrazyZom();
					}
					else PB("^1Can't Buy This");
				}
				if( self.menu == 5)
				{
					if(self.score >= 25)
					{
						self.score -= 25;
						self setOffhandSecondaryClass("flash");
						self GiveWeapon( "flash_grenade_mp" );
						self SetWeaponAmmoClip( "flash_grenade_mp", 1 );
						self SwitchToOffhand( "flash_grenade_mp" );
						PB("^2Flash Grenade Bought");
					}
					else PB("^1Can't Buy This");
				}
				if( self.menu == 6)
				{
					if(self.score >= 500)
					{
						self.score -= 500;
						self.telez = 0;
						self thread doTeleport();
					}
					else PB("^3Need More $$");
				}
				if( self.menu == 7)
				{
					if(self.score >= 25)
					{
						self.score -= 25;
						self thread doUAV();
						PB("^2UAV Bought");
					}
					else PB("^3Need More $$");
				}
				if( self.menu == 8)
				{
					if(self.score >= 350 && self.cbld == 0)
					{
						self.score -= 350;
						self thread SemiVis();
						PB("^2Peekaboo No One Can See You.");
						self.cbld=1;
						wait 1;
						PB("^2OH now they can, wait can't, can, can't");
					}
					else PB("^3Can't Buy It.");
				}
				if( self.menu == 9)
				{
					if(self.score >= 400 && level.ftdis == 0)
					{
						self.score -= 400;
						self thread DFlyT();
					}
					else PB("^3Can't Buy It.");
				}
				if( self.menu == 10)
				{
					if(self.score >= 500 && self.zonce == 0)
					{
						self.score -= 500;
						self thread IceZM();
						PB("You Are Now An Ice Zombie");
						self.icez = 1;
						self.zonce=1;
					}
					else PB("^3Can't Buy It.");
				}
				if( self.menu == 11)
				{
					if(self.score >= 700 && self.zonce == 0)
					{
						self.score -= 700;
						self thread Flying();
						PB("You Are Now An Flying Zombie.");
						PB("However Bullets Damage You Much More.");
						self.flyz = 1;
						self.zonce=1;
					}
					else PB("^3Can't Buy It.");
				}
				wait 3;
			}
			else continue;
		}
		while(level.zboss == 1)
		{
			wait 1;
		}
		wait .1;
	}
}
PlDvars()
{
	self setClientDvars("loc_warnings","0","loc_warningsAsErrors","0");
	self setClientDvars("g_TeamName_Allies", "^2Humans", "g_TeamName_Axis", "^1Zombies");
	self setClientDvars("bg_fallDamageMaxHeight", "9999", "bg_fallDamageMinHeight", "9998", "cg_enemyNameFadeOut", "2500", "cg_enemyNameFadeIn", "0" );
	self setClientDvars( "jump_height", "60", "player_sprintUnlimited", "1", "perk_bulletPenetrationMultiplier", "4", "cg_laserForceOn", "0" );
	self setClientDvars( "cg_drawThroughWalls", "0","cg_blood", "1");
	self setClientDvars( "g_teamcolor_allies", "0 0.0 00.0", "g_teamcolor_axis", "1 0.0 00.0", "ui_gametype", "Zombieland" );
	self setClientDvars("player_meleeRange", "70", "player_meleeHeight", "800", "player_meleeWidth", "800", "scr_game_forceuav" , "0");
	if(self.dcnt==0)
	{
		self.lght=0;
	}
	self.empfr=1;
	self.stpw=0;
	self.dbtp=0;
	self.sloh=0;
	self.stdy=0;
	self.crzy=0;
	self.drgn=0;
	self.sskin=0;
	self.turr=0;
	self.zuse=0;
	self.brimm=0;
	self.ulim=0;
	self.empz=0;
	self.bult=0;
	self.cbld=0;
	self.flzm=0;
	self.bspin=0;
	self.liftz=0;
	self.tcsh=0;
	self.shakz=0;
	self.elvz=0;
	self.assrf=0;
	self.limgz=0;
	self.fltrapz=1;
	self.iczbm=0;
	self.icez=0;
	self.iceg=0;
	self.bsat=0;
	self.sbwait=0;
	self.brptz=4;
	self.flyz=0;
	self.zonce=0;
}
RNDrop(var,owner)
{
	if(!level.console && level.demoz==1 && owner.sbwait<61)
	{
		owner.sbwait+=60;
		owner thread SpShield(1);
	}
	rnum = (50 + (level.minutes * 3));
	if(var==1) rnum=25;
	rndt = randomInt(rnum);
	if(rndt==24) owner thread FreeBuy();
	if(owner.team=="allies")
	{
		if(rndt==8 || rndt==7)
		{
			owner.sbwait+=60;
			owner thread SpShield(1);
		}
		if(rndt==53) owner thread KickGun();
		if(rndt==5) level thread InstKl();
		for ( i=0;i < level.players.size;i++ )
		{
			p = level.players[i];
			if(rndt < 3) p thread MAmoz();
		}
	}
	else
	{
		if(level.minutes>1 && rndt==18) owner thread SSkin();
		if(rndt==78||rndt==81||rndt==56 ) owner thread SSkin();
		if(rndt==15 || rndt== 57) owner thread FreeBuy();
		if(rndt==65 && owner.icez==0)
		{
			wait 2;
			owner iPrintlnBold ("^6Random Drop: Ice Zombie");
			owner thread IceZM();
			owner.icez=1;
		}
	}
}
InstKl()
{
	if(level.inskillz==1 || level.zboss==1 || level.insta==1)return;
	level.inskillz=1;
	level.insta=1;
	iPrintlnBold("^6Random Drop:^2 One-Shot Zombie Kill.");
	wait 60;
	iPrintlnbold ("^3One-Shot Kill is Over.");
	level.inskillz=0;
	wait 120;
	level.insta=0;
}
FreeBuy()
{
	wait 2;
	if(self.lght==0)
	{
		PB ("^6Random Drop:^2 Free Lightwieght");
		self.lght=1;
		self thread LWSP();
	}
	else if(self.hitpoints <950)
	{
		PB ("^6Random Drop:^2 +100 Health");
		self.hitpoints += 100;
		self thread doLyfe();
	}
	else if(self.cbld==0)
	{
		self thread SemiVis();
		PB("^6Random Drop:^2 Semi-Visible Assassin Zombie");
		self.cbld=1;
	}
}
SSkin()
{
	wait 3;
	if(level.zboss==1||self.sskin==1) return;
	self.sskin=1;
	PB("^6Random Drop:^2 Steel Skin. For 20 Seconds.");
	self.tmphit = self.hitpoints;
	self.hitpoints=1300;
	j=0;
	while(level.zboss!=1)
	{
		j++;
		wait 1;
		if(j==20)break;
	}
	self.hitpoints=self.tmphit;
	PB("^3 Steel Skin Over.");
	self.sskin=0;
}
MAmoz()
{
	if(self.team == "allies")
	{
		PB("^6Random Drop:^2 Max Ammo For All!");
		for(i=0;i<3;i++)
		{
			self GiveMaxAmmo(level.Weapon[i] + "_mp");
			self GiveMaxAmmo(level.ass[i] + "_mp");
			self GiveMaxAmmo(level.lmgz[i] + "_mp");
			if(i != 2) self GiveMaxAmmo(level.shotgz[i] + "_mp");
		}
		self GiveMaxAmmo("barrett_mp");
		self GiveMaxAmmo("beretta_mp");
		self GiveMaxAmmo("g36c_reflex_mp");
		self giveStartAmmo("m21_acog_mp");
		self giveStartAmmo("dragunov_mp");
		self giveMaxAmmo("uzi_mp");
	}
}
doScor()
{
	if(!isDefined(self.tokill)) self.tokill = 0;
	if(!isDefined(self.totalscore)) self.totalscore = 0;
	self.score = (self.score + self.totalscore);
	self.kills = (self.tokill + self.kills);
	wait .4;
	if(self.kills > level.hikill) self thread doHiSC();
	else
	{
		wait .2;
		if(self.kills == level.hikill && self.score > level.highsc) self thread doHiSC();
	}
}
doHiSC()
{
	level.highsc = self.score;
	level.hscname = self.name;
	level.hikill = self.kills;
}
CHDis()
{
	wait .7;
	if(self UseButtonPressed())
	{
		self iPrintln("^7Health: ^3" + self.health + "^2/" + self.hitpoints );
		wait 3;
	}
	if(self MeleeButtonPressed() && level.demoz == 1)
	{
		self.telez = 0;
		self thread doTeleport();
	}
	self.chdis = 0;
}
GTime()
{
	level endon("GEND");
	while(1)
	{
		wait 1;
		level.seconds++;
		if(level.seconds == 60)
		{
			level.minutes++;
			level.seconds = 0;
		}
	}
}
doLasta()
{
	PB("^1You're Last Alive. You've Earned $300.");
	self.score += 300;
	self.fltrapz--;
	wait 2;
	if(isDefined(level.zbosp)) self SetOrigin(level.zbosp);
	PB("^6No more Camping For You.");
	self thread doEMPZ(3);
	wait 2;
	self.empz=0;
}
SpNorm(slow, time, acc, li)
{
	self endon("death");
	self endon("disconnect");
	if(!isDefined(li)) li=0;
	if(self.lght == 1 && li == 0) return;
	if(!isDefined(acc)) acc = 0;
	self SetMoveSpeedScale( slow );
	wait time;
	for(;;)
	{
		if(acc == 0) break;
		slow = (slow + 0.1);
		self SetMoveSpeedScale( slow );
		if(slow == 1.0) break;
		wait .15;
	}
	self thread LWSP();
}
SpecFix()
{
	for ( i = 0;i < level.players.size;i++ )
	{
		p = level.players[i];
		if(p.name != level.hostname && p.team == "spectator") p.isZombie = 2;
		p PlaySound("mp_war_objective_lost");
	}
}
dhelp()
{
	wait 6;
	self endon("disconnect");
	self endon("HEND");
	level endon("GSTART");
	while(1)
	{
		self iPrintlnBold("^3Press [{+smoke}] to scroll through your Store menu");
		self iPrintlnBold("^5Press [{+frag}] to buy the current menu item");
		self iPrintlnBold("^6You score is your cash. ^2PRESS[{+melee}] To EXIT Help.");
		wait 5;
		self iPrintlnBold("^7Zombies earn $50 for dying, and $100 per kill.");
		self iPrintlnBold("^2The First Zombies are Picked at Random.");
		self iPrintlnBold("^6If a Human dies he will become a Zombie.");
		wait 5;
	}
}
DOnDZ(E,noti)
{
	if(isDefined(noti))self endon (noti);
	self waittill("death");
	E destroy();
}
SDZFix()
{
	self endon("disconnect");
	level endon ("GEND");
	while(1)
	{
		self waittill ( "damage", damage, attacker, direction_vec, point, type, modelName, tagName, partName, iDFlags );
		if(!isDefined(attacker.team)) attacker.team="world";
		if(attacker.team != self.team && isPlayer( attacker ))
		{
			if(attacker GetCurrentWeapon()!="m21_acog_mp")attacker.score+=5;
			else attacker.score+=2;
			self.score+=5;
		}
		if(!isAlive(self))
		{
			if(!isPlayer( attacker ) && attacker.team != "allies") self.score -= 50;
			continue;
		}
		else
		{
			if(attacker==self && self.bsat==1) self.health+=damage;
			if(level.inskillz==1 && isPlayer( attacker ))
			{
				so=self.origin + (0,0,20);
				RadiusDamage(so, 30, 1000, 900, attacker );
			}
			else if(self.flyz==1 && isPlayer( attacker ))
			{
				self DamPl(250,attacker);
				wait .1;
			}
		}
	}
}
HDam()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		self waittill ( "damage", damage, attacker, direction_vec, point, type, modelName, tagName, partName, iDFlags );
		if(attacker==self || !isPlayer( attacker ) || !isDefined(attacker.team)) self.health+=damage;
		else if(attacker.team=="axis" && attacker.icez==0)
		{
			if(level.zboss==0) attacker.score +=20;
			else attacker.score +=10;
		}
		else if(attacker.flzm==1) attacker.score +=5;
	}
}
doZW()
{
	self endon ( "disconnect" );
	self endon ( "death" );
	while(1)
	{
		wait .5;
		if(self getCurrentWeapon() == "beretta_mp")
		{
			if(self.bult < 1)
			{
				self setWeaponAmmoClip("beretta_mp", 0);
				self setWeaponAmmoStock("beretta_mp", 0);
			}
		}
		else
		{
			current = self getCurrentWeapon();
			self takeWeapon(current);
			self switchToWeapon( "beretta_mp" );
		}
		while(level.zboss == 1)
		{
			wait 1;
		}
	}
}
doLyfe()
{
	self.maxhealth = self.hitpoints;
	self.health = self.maxhealth;
}
LockMenu(msec)
{
	self endon ( "disconnect" );
	self endon ("death");
	if(self.name == level.hostname) return;
	for(j=0;j<msec;j++)
	{
		self closeMenu();
		self closeInGameMenu();
		wait .05;
	}
}
AntiJoin()
{
	wait .7;
	if(self MeleeButtonPressed())
	{
		if (!level.AJAct)
		{
			setDvar("g_password", "hawkin");
			level.AJAct=true;
			self iPrintln( "^7Anti-Join Enabled" );
		}
		else
		{
			setDvar("g_password", "");
			level.AJAct=false;
			self iPrintln( "^7Anti-Join Disabled" );
		}
	}
	wait 3;
	self.anty = 0;
}
kickMenu()
{
	self endon ("disconnect");
	level endon("GEND");
	if(self GetEntityNumber()!=0)
	{
		self thread cohch();
		level endon("NEWCOHOST");
	}
	cur=0;
	cohst=0;
	self.cohostz=true;
	for(;;)
	{
		link=0;
		while ( self getStance() == "prone" )
		{
			if(link==0)
			{
				link=1;
				self waittill( "night_vision_on" );
			}
			na = level.players[cur].name;
			self.hint = "^2" + na + "^2 | [{+usereload}] Selects Player, ^5Hold L1 & L2 to Kick Them";
			if ( self UseButtonPressed() ) cur++;
			if ( cur > level.players.size-1 ) cur = 0;
			if ( self SecondaryOffhandButtonPressed() && self AdsButtonPressed() )
			{
				wait 1;
				if ( self SecondaryOffhandButtonPressed() && self AdsButtonPressed() ) if(cur==0) break;
				else iPrintlnBold("^6" + na + "^3 Was KICKED!");
				kick( level.players[cur] getEntityNumber() );
				wait 2;
			}
			if ( self UseButtonPressed())
			{
				wait 0.4;
				self notify ("NoCOHOSTZ");
				cohst=0;
			}
			if ( self attackButtonPressed() && self fragButtonPressed() && self.name==level.hostname && cohst==0)
			{
				self thread CoHostz(cur);
				cohst=1;
			}
			wait 0.05;
		}
		cur = 0;
		wait 1;
	}
}
cohcheck()
{
	wait 10;
	coh=GetDvar("HawkinCoHost");
	for (i=0;i<level.players.size;i++)
	{
		p = level.players[i];
		if(p.name==coh)
		{
			p thread kickMenu();
			p iPrintlnBold("You Are Now Co-Host");
			break;
		}
	}
}
CoHostz(cur)
{
	self endon ("death");
	self endon ("disconnect");
	self endon ("NoCOHOSTZ");
	pl=level.players[cur];
	PB("Press Up On The DPad To Confirm " + pl.name + " As CoHost");
	PB("Press [{+usereload}] to Cancel");
	self waittill ( "night_vision_on" );
	PB("^5" + pl.name + " ^3Is Now CoHost");
	level notify("NEWCOHOST");
	pl thread kickMenu();
	self setClientDvar("HawkinCoHost", pl.name);
	pl iPrintlnBold("You Are Now Co-Host");
}
cohch()
{
	self endon ("disconnect");
	level waittill("NEWCOHOST");
	self.cohostz=false;
}
doTeamChange(teamz)
{
	self.zblive = 1;
	if(isAlive(self))
	{
		self.switching_teams = true;
		self.joining_team = teamz;
		self.leaving_team = self.pers["team"];
		self suicide();
	}
	self.pers["team"] = teamz;
	self.team = teamz;
	self thread ClassCH(teamz);
	self.pers["weapon"] = undefined;
	self.pers["savedmodel"] = undefined;
	self.sessionteam = teamz;
	self notify("joined_team");
	self notify("end_respawn");
	self setclientdvar( "g_scriptMainMenu", game[ "menu_class_" + self.pers["team"] ] );
	wait .5;
	self.zblive = 0;
}
ClassCH(te)
{
	if(!isDefined(te))te=self.team;
	cls="sniper_mp";
	if(te=="axis") tm=level.classMap["sniper_mp"];
	else
	{
		tm=level.classMap["specops_mp"];
		cls="specops_mp";
	}
	self maps\mp\gametypes\_class::setClass( tm );
	self.pers["class"] = tm;
	self.class = tm;
	self notify("menuresponse", "changeclass", cls);
}
doHCash()
{
	self endon("disconnect");
	self endon("death");
	self.ck = self.kills;
	self.hst = self.headshots;
	j=0;
	while(1)
	{
		if(self.headshots - self.hst > 0)
		{
			self.score += 50;
			self.hst++;
			j++;
			level thread RNDrop(0,self);
		}
		if(self.kills - self.ck > 0)
		{
			self.ck++;
			j++;
			level thread RNDrop(0,self);
			if(j>11)
			{
				j=0;
				RNDrop(1,self);
			}
		}
		if(self.score < 0) self.score = 0;
		self.pers["score"] = self.score;
		wait .1;
	}
}
doZCash()
{
	self endon("disconnect");
	self endon("death");
	level endon("GEND");
	if(self.zomb!=1) return;
	while(1)
	{
		if(self.kills - self.ck > 0)
		{
			self.score += 100;
			self.ck++;
			level thread RNDrop(1,self);
		}
		if(self.deaths - self.cd > 0)
		{
			self.score += 50;
			self.cd++;
			level thread RNDrop(0,self);
		}
		if(self.suicides - self.cs > 0)
		{
			if(self.flzm != 1) self.score -= 50;
			self.cs++;
		}
		if(self.score < 0) self.score = 0;
		self.pers["score"] = self.score;
		wait .1;
	}
}
SettingWeapon()
{
	level.Weapon = [];
	level.ass = [];
	level.shotgz = [];
	level.lmgz = [];
	level.Weapon[0] = "mp5_reflex";
	level.Weapon[1] = "p90_reflex";
	level.Weapon[2] = "ak74u_reflex";
	level.ass[0] = "ak47_acog";
	level.ass[1] = "m4_acog";
	level.ass[2] = "mp44";
	level.ass[3] = "g36c_reflex";
	level.shotgz[0] = "m1014_grip";
	level.shotgz[1] = "winchester1200_grip";
	level.lmgz[0] = "rpd_grip";
	level.lmgz[1] = "m60e4_grip";
	level.lmgz[2] = "saw_grip";
}
ORide()
{
	self endon ( "disconnect" );
	level endon("GSTART");
	for(;;)
	{
		level.prematchPeriod = 0;
		wait 1;
		level.onForfeit = ::FFixz;
	}
}
FFixz(x)
{
}
doScoreReset()
{
	self.pers["score"] = 0;
	self.pers["kills"] = 0;
	self.pers["assists"] = 0;
	self.pers["deaths"] = 0;
	self.pers["suicides"] = 0;
	self.score = 0;
	self.kills = 0;
	self.assists = 0;
	self.deaths = 0;
	self.suicides = 0;
	self.headshots = 0;
}
NewEleF()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		if(level.demoz==1)break;
		p1=self.origin;
		wait 1.5;
		p2=self.origin;
		if(self.liftz==1)continue;
		if(p2[2] - p1[2] > 70 && p2[0]==p1[0] && p2[1]==p1[1])
		{
			iPrintlnBold(""+ self.name +" ^1Made An Elevator Attempt. ^3So I Killed the Bitch.");
			self suicide();
		}
	}
}
WCSpd()
{
	self endon("death");
	self waittill("weapon_change");
	wait 2;
	self thread LWSP();
}
HntTxt()
{
	self endon("disconnect");
	self endon("death");
	self.HTxt = self createFontString( "objective", 1.4 );
	self.HTxt setPoint( "CENTER", "CENTER" );
	self thread DOnDZ(self.HTxt);
	self.hint = "";
	for(;;)
	{
		self.HTxt setText("" + self.hint);
		self.hint = "";
		wait .6;
	}
}
regenz()
{
	self endon ( "disconnect" );
	self endon ( "death" );
	time = 0;
	while(1)
	{
		wait 2;
		if(self.health < self.hitpoints)
		{
			wait 5;
			self thread doLyfe();
		}
	}
}
RanSpwn()
{
	rn = randomInt(4);
	self SetOrigin(level.ZomSp[rn]);
}
DoOnce()
{
	self.oncez = 1;
	if(self GetEntityNumber()==0)
	{
		self thread cohcheck();
		self thread demomode();
		self thread kickMenu();
		self setClientDvar( "party_connectToOthers" , "0" );
		self thread HGEND();
	}
	else
	{
		self thread LockMenu(150);
		wait 6;
		self thread dhelp();
	}
}
HGEND()
{
	self waittill ("disconnect");
	level notify ("GEND");
}
FFTextD()
{
	self endon("disconnect");
	self.fftext = 0;
	while(1)
	{
		if(self.fftext !=0)
		{
			wait 3;
			self.fftext = 0;
		}
		wait .2;
	}
}
KickGun()
{
	self endon ("disconnect");
	self endon ("death");
	if(self.shakz==1)return;
	self.shakz=1;
	PB("^6Random Drop: Shaker Gun");
	self giveWeapon("uzi_mp", 6);
	self giveMaxAmmo("uzi_mp");
	wait .5;
	self switchToWeapon("uzi_mp");
	while(1)
	{
		self waittill("weapon_fired");
		weap = self GetCurrentWeapon();
		if(weap!="uzi_mp")
		{
			wait .5;
			continue;
		}
		my = self gettagorigin("j_head");
		t=bullettrace(my, my + anglestoforward(self getplayerangles())*100000,true,self)["position"];
		for (i=0;i<level.players.size;i++)
		{
			p = level.players[i];
			if(p.team!="axis")
			{
				wait .05;
				continue;
			}
			di=distance(p.origin,t);
			if(di<130 && p.tcsh==0)p shellshock("concussion_grenade_mp", 1.5);
			else if(p.tcsh==1)p shellshock("concussion_grenade_mp", 0.1);
		}
		wait .5;
	}
}
RMatz()
{
	setDvar("scr_forcerankedmatch" , 1 );
	setDvar("xblive_privatematch", 0 );
	setDvar( "onlinegame" , "1" );
	level.rankedMatch = true;
}
demomode()
{
	wait 5;
	self iPrintlnBold("^2HOLD [{+speed_throw}] & [{+usereload}] ^3For Demo Mode");
	while(level.gamestate == "starting")
	{
		if(self AdsButtonPressed() && self UseButtonPressed())
		{
			wait 3;
			if(self AdsButtonPressed() && self UseButtonPressed())
			{
				level thread DemoAct();
				level thread RMatz();
				self thread Locpr();
				registerScoreInfo( "kill", 1500 );
				self.kills=31;
				break;
			}
		}
		wait .5;
	}
}
Locpr()
{
	self endon("disconnect");
	for(;;)
	{
		self iPrintln("^5" + self.origin + "^7A: ^6" + self.angles);
		wait 5;
	}
}
DemoAct()
{
	level.demoz = 1;
	iPrintlnBold("^2Demo Mode Active");
	for ( i = 0;i < level.players.size;i++ )
	{
		p = level.players[i];
		p.score = 50000;
		p setClientDvar( "jump_height", "1000" );
		p setClientDvar("scr_game_forceuav" , "1" );
		p setClientDvar("g_compassShowEnemies" , "1" );
		p setClientDvar("compassRadarUpdateTime" , "0.001" );
	}
	level thread addTestClients(1, 7);
	level thread addTestClients(0, 1);
}
addTestClients(z, n)
{
	wait 5;
	testclients = n;
	for(i = 0;i < testclients;i++)
	{
		ent[i] = addtestclient();
		ent[i] setClientDvar("name","ZomBot");
		ent[i].pers["isBot"] = true;
		ent[i] thread TestClient2(z);
	}
}
TestClient2(z)
{
	self endon( "disconnect" );
	if(z==1)
	{
		team="axis";
		wait 2;
		self notify("menuresponse", game["menu_team"], team);
	}
	else team = "allies";
	wait 0.1;
	while( 1 )
	{
		self thread ClassCH(team);
		self waittill( "spawned_player" );
		if(z==1) self.isZombie = 1;
		wait ( 0.10 );
	}
}
doRank(){}
ZBTimer()
{
	level.zbtime = 0;
	time = 6;
	if(isDefined(level.zbosp))
	{
		while(1)
		{
			zbtrig = (level.minutes - level.zbtime);
			if(zbtrig >= time)
			{
				level thread ZombieBoss();
				level waittill ("ZBDEATH");
				wait 9;
				level.zbtime = (level.minutes + 1);
			}
			wait 1;
		}
	}
}
ZombieBoss()
{
	if(level.nuke==1)
	{
		level notify ("ZBDEATH");
		return;
	}
	level.zboss=1;
	level.zbalve=0;
	level.inskillz=0;
	level.hikill = 0;
	SetExpFog(200, 1000, 0.5, 0.4, 0.4, 6);
	for ( i = 0;i < level.players.size;i++ )
	{
		p = level.players[i];
		if(p.team=="axis") p thread ZBdrive();
		wait .01;
	}
	wait 3;
	xf=2+(level.minutes/2);
	level.zbhealth = (xf * 300);
	cgh = 0;
	zpos = 1;
	level.zbspawnz = spawn("script_origin", level.zbosp);
	level.zbstz=1;
	for ( i = 0;i < level.players.size;i++ )
	{
		P = level.players[i];
		P thread ZMLock();
		P iPrintlnBold("^1The Zombies Are Forming MEGA-ZOMBIE.");
		P playsound("mp_war_objective_lost");
		P.tmphit = P.hitpoints;
		if(P.team == "axis")
		{
			P notify("ZBSTART");
			j=0;
			P.hitpoints = 99999;
			P thread dolyfe();
			P thread doUAV();
			if(level.hscname==P.name)
			{
				P.zpos = 0;
				cgh = 1;
				zpos--;
			}
			else P.zpos = zpos;
			if(p.zpos==1) level.bkzbdr=P;
			if(P.zpos > 12) P thread ZBWait(1);
			else P thread ZBossForm(P);
			zpos++;
		}
		if(isAlive(P) && P.team == "allies") P thread ZBHLife();
	}
	if(cgh!=1) level.bkzbdr.zpos=0;
	level notify ("ZBOSSFM");
	wait 1;
	level.zbspawnz linkto(level.zblead);
	tl=0;
	while(1)
	{
		if(level.zbhealth <= 0)
		{
			smallmm=loadfx("explosions/aerial_explosion");
			playfx(smallmm, level.zbosp);
			Earthquake( 0.8, 3, level.zbosp, 1000 );
			self playsound("mpl_sd_exp_suitcase_bomb_main");
			level notify ("ZBDEATH");
			level.zbstz=0;
			level.zboss=0;
			level.zbspawnz unlink();
			level.zbspawnz delete();
			SetExpFog(200, 800, 0.5, 0.5, 0.5, 6);
			wait 5;
			break;
		}
		wait 1;
		tl++;
		if(tl>139)
		{
			level.zbhealth=0;
			level.zbalve=1;
			iPrintlnBold("^1Mega-Zombie Time Limit Expired.");
		}
	}
	for ( i = 0;i < level.players.size;i++ )
	{
		P = level.players[i];
		P thread AcEMP(2);
		if(P.team == "allies" && P.zbalive == 1 && level.zbalve==0)
		{
			P.score += 200;
			P iPrintlnBold("^2You Got $200 for Surviving Mega-Zombie.");
			P thread MAmoz();
		}
		if(P.team == "allies" && level.zbalve==1)
		{
			P.score -= 200;
			P iPrintlnBold("^3You lost $200 for Not Killing Mega-Zombie.");
		}
	}
}
ZBdrive()
{
	if(!isDefined(self.tokill)) self.tokill=0;
	kil = (self.tokill + self.kills);
	wait .1;
	if(kil >= level.hikill)
	{
		level.hscname=self.name;
		level.hikill=kil;
	}
}
ZBHLife()
{
	self endon ("disconnect");
	level endon ("ZBDEATH");
	self.zbalive = 1;
	self waittill ("death");
	self.dcnt = 1;
	self.zbalive = 0;
	self thread ZBWait(0);
	wait 3;
	d("^5You are a Useless ^3BACKYARD ZOMBIE.");
	wait 2;
	d("^2You will become Human if Mega-Zombie DIES!");
}
ZMLock()
{
	self endon ( "disconnect" );
	while(level.zboss == 1)
	{
		if(self.name == level.hostname) return;
		self closeMenu();
		self closeInGameMenu();
		wait .1;
	}
}
ZBWait(team)
{
	self endon ("disconnect");
	self.zbwait = 1;
	if(!isDefined(self.tmphit)) self.tmphit = 100;
	self.hitpoints = self.tmphit;
	while(1)
	{
		self takeallweapons();
		wait 2;
		self clearPerks();
		wait 2;
		if(level.zboss == 0)
		{
			if(team == 0)
			{
				self.isZombie=0;
				self suicide();
				wait 7;
				self.dcnt=0;
				self.hitpoints = self.tmphit;
				self thread PlDvars();
				self.isZombie=1;
			}
			else self suicide();
			self.zbwait = 0;
			break;
		}
	}
}
ZBossForm(P)
{
	zbp = level.zbosp;
	level waittill ("ZBOSSFM");
	if(isdefined(self.N)) self.N delete();
	if(self.zpos == 0)
	{
		level.zblead = self;
		self.norg = zbp;
		self thread ZBMon();
		self thread ZBSG();
	}
	if(self.zpos == 1) self.norg = (zbp + (0,0,90));
	if(self.zpos == 2) self.norg = (zbp + (0,-40,130));
	if(self.zpos == 3) self.norg = (zbp + (0,40,130));
	if(self.zpos == 4) self.norg = (zbp + (0,0,180));
	if(self.zpos == 5) self.norg = (zbp + (0,60,0));
	if(self.zpos == 6) self.norg = (zbp + (0,-60,0));
	if(self.zpos == 7) self.norg = (zbp + (0,-80,100));
	if(self.zpos == 8) self.norg = (zbp + (0,80,100));
	if(self.zpos == 9) self.norg = (zbp + (0,0,240));
	if(self.zpos == 10) self.norg = (zbp + (0,60,250));
	if(self.zpos == 11) self.norg = (zbp + (0,-60,250));
	if(self.zpos == 12) self.norg = (zbp + (0,-0,320));
	self freezeControls( true );
	self setOrigin(self.norg);
	self SetPlayerAngles( (0, 0, 0) );
	if(self.zpos != 0) self linkto(level.zbspawnz);
	self thread ZBossFire();
	self thread ZBHealth();
	wait 2;
	self freezeControls( false );
	level waittill ("ZBDEATH");
	wait .6;
	self playSound( "artillery_impact" );
	self unlink();
	self.score += 50;
	self.hitpoints = self.tmphit;
	self suicide();
}
ZBSG()
{
	level endon ("ZBDEATH");
	self waittill ("death");
	level.zbhealth = 0;
}
ZBMon()
{
	level endon ("ZBDEATH");
	PB("^2You're the Godfather Zombie. ^3You Must Drive Mega-Zombie.");
	while(1)
	{
		self SetMoveSpeedScale( 1 );
		wait 1;
	}
}
ZBossFire()
{
	self endon ("disconnect");
	self endon ("death");
	level endon ("ZBDEATH");
	self takeWeapon("beretta_mp");
	wait .1;
	self giveWeapon("deserteaglegold_mp");
	self setWeaponAmmoClip("deserteaglegold_mp", 1);
	self setWeaponAmmoStock("deserteaglegold_mp", 0);
	wait .1;
	self switchToWeapon("deserteaglegold_mp");
	while(1)
	{
		self waittill("weapon_fired");
		my = self gettagorigin("j_head");
		trace=bullettrace(my, my + anglestoforward(self getplayerangles())*100000,true,self)["position"];
		playfx(level.expbullt,trace);
		self playSound( "artillery_impact" );
		RadiusDamage( trace, 100, 51, 20, self );
		wait .6;
		self setWeaponAmmoClip("deserteaglegold_mp", 1);
	}
}
ZBHealth()
{
	self endon ("disconnect");
	level endon ("ZBDEATH");
	wait 2;
	while(1)
	{
		self waittill ( "damage", damage, attacker, direction_vec, point, type, modelName, tagName, partName, iDFlags );
		if(attacker.team != "axis")
		{
			level.zbhealth = (level.zbhealth - damage);
			attacker.score += 5;
		}
		wait .05;
	}
}
BRCastPort()
{
	wait 25;
	level.brptsw=0;
	level notify("PRTACT");
	iPrintlnBold("^5All Players Have^3 4 ^5Portal Breakers.");
	iPrintlnBold("^6HOLD [{+melee}] and run into a portal to destroy it.");
	j=1;
	h=0;
	while(1)
	{
		level.brptdel=0;
		for(i=0;i<level.brpt.size;i++)
		{
			if(j>=2)
			{
				j=0;
				level thread BrSpawn(level.brpt[i],50);
			}
			wait .1;
			j++;
		}
		wait 5;
		level.brptdel=1;
		wait .5;
		while(level.brptsw==1)
		{
			wait 1;
		}
		if(h==0)
		{
			j=2;
			h=1;
		}
		else if(h==1)
		{
			j=1;
			h=0;
		}
	}
}
BrSpawn(pos,rad)
{
	posa = pos +(0,0,35);
	glz = SpawnFx(level.fxxx1, pos);
	glz.angles = (270,0,0);
	TriggerFX(glz);
	j=0;
	while(level.brptdel==0)
	{
		for (i=0;i<level.players.size;i++)
		{
			p = level.players[i];
			if(Distance(p.origin, pos)<rad)
			{
				if(p.brimm==1) continue;
				if(p.brptz>0 && p MeleeButtonPressed())
				{
					p.brptz--;
					playfx(level.boomerz,posa);
					p playSound( "artillery_impact" );
					p iPrintlnBold("^5You Have ^3" + p.brptz + " ^5Portal Breakers Left.");
					j=1;
					break;
				}
				rn = randomInt(level.brpt.size);
				p setOrigin(level.brpt[rn]);
				p thread BRImm();
			}
		}
		if(j==1) break;
		wait .1;
	}
	glz delete();
}
BRImm()
{
	self.brimm=1;
	wait 3.5;
	self.brimm=0;
}
HLuck()
{
	self endon ("death");
	self endon ("disconnect");
	lk=0;
	rd=0;
	while(1)
	{
		so=self.origin;
		sh=0;
		dis=450;
		rd++;
		for(j=0;j<6;j++)
		{
			son=self.origin;
			se=self.elvz;
			disx=dis - Distance2D(so,self.origin);
			wait 1;
			if(self.elvz != se)
			{
				dis=disx;
				so=self.origin;
			}
			else if(Distance(son,self.origin)>100)sh++;
		}
		if(Distance2D(so,self.origin)>dis && sh>2)lk++;
		else if(Distance(so,self.origin)<40 && rd>6)
		{
			rd=0;
			lk--;
		}
		if(lk<0)lk=0;
		if(lk>12)
		{
			d("^6You Earned Some LUCK!");
			self.luckz++;
			lk=0;
			if(self.luckz>2)
			{
				if(self.shakz!=1)self thread KickGun();
				else
				{
					self.sbwait+=60;
					self thread SpShield(1);
				}
			}
			else self thread FreeBuy();
		}
	}
}
ExDrag()
{
	self endon ("disconnect");
	self endon ("death");
	d("^2Ah... Wise Choice My Son. ^4Take This Old Weapon.");
	self giveWeapon("dragunov_mp", 6);
	self giveStartAmmo("dragunov_mp");
	wait .5;
	self switchToWeapon("dragunov_mp");
	while(1)
	{
		self waittill("weapon_fired");
		weap = self GetCurrentWeapon();
		if(weap!="dragunov_mp") continue;
		my = self gettagorigin("j_head");
		tr=bullettrace(my, my + anglestoforward(self getplayerangles())*100000,true,self)["position"];
		playfx(level.expbullt,tr);
		self playSound( "artillery_impact" );
		for (i=0;i<level.players.size;i++)
		{
			p = level.players[i];
			po=p.origin;
			poh=po+(0,0,30);
			dis=distance(po, tr);
			if(dis<150 && p.team=="axis") if(level.zboss==1)
			{
				RadiusDamage( tr, 60, 200, 50, self );
				break;
			}
			else if(BulletTracePassed(tr,po,0,self) || BulletTracePassed(tr+(0,0,30),poh,0,self) || BulletTracePassed(tr,poh,0,self))
			{
				vdam=900-(dis*6);
				if(p.tcsh==0) RadiusDamage( poh, 40, vdam, 50, self );
				else RadiusDamage( poh, 40, int(vdam/5), 50, self );
			}
		}
	}
}
CrazyZom()
{
	self endon ("ZBSTART");
	self endon ("death");
	d("^3 Press [{+actionslot 1}] to explode.");
	self.crzy=1;
	self thread CrazyTrig();
	self thread CrazyFX();
	while(1)
	{
		self SetMoveSpeedScale( 1.5 );
		so=self.origin + (0,0,20);
		if(self.crzy==0)
		{
			playfx(level.boomerz, so);
			self playSound( "exp_suitcase_bomb_main" );
			RadiusDamage(so, 250, 500, 125, self );
			wait .3;
			level.crzzy=0;
			self suicide();
		}
		wait .1;
	}
}
CrazyTrig()
{
	self endon("death");
	self endon ("ZBSTART");
	self waittill( "night_vision_on" );
	level.crzzy=1;
	self.crzy=0;
}
CrazyFX()
{
	self endon ("death");
	self endon ("ZBSTART");
	for(;;)
	{
		so=self.origin + (0,0,20);
		playfx(level.fxsmoke, so);
		self playSound("ui_mp_timer_countdown");
		self playSound("ui_mp_suitcasebomb_timer");
		self playSound("weap_suitcase_defuse_plr");
		wait .5;
		playfx(level.fxsmokes, so);
		wait .5;
	}
}
SemiVis()
{
	self endon("death");
	self endon("disconnect");
	while(1)
	{
		self hide();
		wait .5;
		self show();
		wait .5;
	}
}
d(t)
{
	self iprintlnbold(t);
}
DFlyT()
{
	iPrintlnBold("^3All Fly Traps will be destroyed in 15 Seconds");
	level.ftdis = 1;
	wait 15;
	iPrintlnBold("^1Fly Traps Destroyed");
	iPrintlnBold("^3Any Fly Traps Bought in the Next 30 Seconds, will also be destroyed.");
	level.trapdes=1;
	wait 30;
	level.trapdes=0;
	iPrintlnBold("^2Fly Traps May Be Placed Again");
	level.ftdis=0;
	level.fltext destroy();
}
doTeleport()
{
	self beginLocationSelection( "map_artillery_selector" );
	self.selectingLocation = true;
	self waittill( "confirm_location", location );
	if(self.telez == 0)
	{
		newLocation = PhysicsTrace( location + ( 0, 0, 1000 ), location - ( 0, 0, 1000 ) );
	}
	else
	{
		newLocation = PhysicsTrace( location + ( 0, 0, 400 ), location - ( 0, 0, 500 ) );
	}
	self SetOrigin( newLocation );
	self endLocationSelection();
	self.selectingLocation = undefined;
	d("^2If Your Teleport Went Wrong...");
	wait 3;
	if(self.telez == 0 )
	{
		self thread doTeleAgain();
	}
	else
	{
		d("^1Sorry Only 1 Teleport Redo");
	}
}
doTeleAgain()
{
	d("^7Press & Hold [{+usereload}] to ^3Teleport again, ^1You have 5 Seconds");
	for(j=30;j>0;j--)
	{
		if(self UseButtonPressed())
		{
			wait .8;
			if(self UseButtonPressed())
			{
				self.telez = 1;
				self thread doTeleport();
				break;
			}
		}
		wait .2;
	}
}
doNUKE(ownerz)
{
	level.TimerText destroy();
	level.TimerText = level createServerFontString( "default", 1.5 );
	level.TimerText setPoint( "CENTER", "CENTER", 0, 50 );
	level.TimerText setText("^3" + ownerz.name + " ^1Activated the ^6Zombie Launcher. ^7It takes 60 Seconds to Charge.");
	wait 5;
	level.TimerText setText("");
	wait 25;
	level.TimerText setText("In 30 Seconds Zombies Die");
	wait 3;
	level.TimerText setText("");
	wait 27;
	if(isDefined(ownerz) && isAlive(ownerz) && ownerz.team == "allies")
	{
		Earthquake( 0.6, 4, ownerz.origin, 800 );
		players = level.players;
		for ( index = 0;index < players.size;index++ )
		{
			player = players[index];
			if(player.team == "axis") player thread Zdeathz();
		}
		wait 4;
		visionSetNaked( "mpIntro", 0 );
		level.TimerText setText("^1"+ ownerz.name +" ^2Wins! All Zombies Were Destroyed!");
		level notify ("GEND");
		wait 4;
		level.TimerText destroy();
		if( level.rankedMatch ) thread maps\mp\gametypes\_globallogic::endGame( "allies", game["strings"]["axis_eliminated"] );
		else map_restart(false);
	}
	else
	{
		level.TimerText setText("^3" + ownerz.name + "^2became a Zombie. Zombies Survive.");
		level.nuke=0;
		wait 5;
		level.TimerText destroy();
	}
}
Zdeathz()
{
	self setClientDvar("g_gravity", "100");
	for(j=35;j>0;j--)
	{
		self SetOrigin( self.origin + (0,0,150));
		wait .1;
	}
	zdnuke=spawnstruct();
	zdnuke.fx=loadfx("explosions/aerial_explosion_large");
	ztrace = self.origin;
	playfx(zdnuke.fx, ztrace);
	self playSound( "exp_suitcase_bomb_main" );
	wait 2;
	self suicide();
}
MaxAmmo()
{
	self endon("death");
	self endon("disconnect");
	while(1)
	{
		weap = self GetCurrentWeapon();
		if(weap!="dragunov_mp" && weap!="m21_acog_mp")
		{
			self setWeaponAmmoClip(weap, 150);
			self giveMaxAmmo(weap);
		}
		wait .5;
	}
}
doEMPZ(time)
{
	self.empz = 1;
	for ( index = 0;index < level.players.size;index++ )
	{
		p = level.players[index];
		p thread AcEMP(time);
	}
	wait 120;
	self.empz = 0;
}
AcEMP(time)
{
	self endon ( "disconnect" );
	if(!isDefined(time)) time=4;
	self.empfr=1;
	for(j = time;j > 0;j--)
	{
		if(self.team == "axis") self freezeControls(true);
		d("^3Zombies Frozen");
		wait 3;
	}
	self freezeControls(false);
	d("^1Zombies UnFrozen");
	self.empfr=0;
	wait 3;
	self freezeControls(false);
}
zbult()
{
	bul = self.bult;
	for(j = bul;j > 0;j--)
	{
		self waittill ( "weapon_fired" );
		self.bult--;
	}
}
FlameZ()
{
	self endon ( "disconnect" );
	self endon ( "death" );
	self thread FZFX();
	while(1)
	{
		for ( i = 0;i < level.players.size;i++ )
		{
			p = level.players[i];
			d = p.origin + (0,0,20);
			s = self gettagorigin("j_head");
			if(p.team == "allies" && Distance(s, d)<300) if(BulletTracePassed(s,d,0,self) || BulletTracePassed(s,p.origin,0,self) || BulletTracePassed(s,p gettagorigin("j_head"),0,self))
			{
				if(p.bspin==1) RadiusDamage(d, 40, 15, 14, self );
				else RadiusDamage(d, 40, 35, 25, self );
				p thread LWSP();
			}
		}
		while(level.zboss==1)
		{
			wait 1;
		}
		wait 0.5;
	}
}
FZFX()
{
	self endon ( "disconnect" );
	self endon ( "death" );
	while(1)
	{
		PlayFX( level.flamez, self.origin );
		wait .5;
	}
}
FLBuy()
{
	self.score -= level.ftcost;
	d("^2Trap Placed.");
	owner = self;
	self.fltrapz++;
	self thread FLTrap(owner);
	level.trapz ++;
}
FLTrap(owner)
{
	tr = spawn("script_model", owner.origin );
	tr setModel("weapon_c4_mp");
	tr.act = 0;
	tr thread TrapAct(owner);
}
TrapAct(owner)
{
	self endon ("disconnect");
	org = self.origin;
	fxc4 = SpawnFx(level.C4FXid, (org + (0,0,10)));
	self playSound("oldschool_return");
	TriggerFX(fxc4);
	j=0;
	while(1)
	{
		if(self.act == 0)
		{
			for ( i = 0;i < level.players.size;i++ )
			{
				p = level.players[i];
				if(p.team == "axis" && level.zboss == 0)
				{
					if(Distance(org, p.origin) < 120)
					{
						if(isAlive(p) && p.tcsh==0)
						{
							p thread TrapMove(owner);
							self.act = 1;
						}
					}
				}
			}
		}
		if(self.act == 1)
		{
			fxti = SpawnFx(level.fxxx1, org);
			fxti.angles = (270,0,0);
			earthquake( 0.8, 0.5, org, 300 );
			self playSound( "fast_artillery_round" );
			TriggerFX(fxti);
			wait .8;
			fxc4 delete();
			fxti delete();
			self.act = 2;
		}
		if(self.act == 2)
		{
			j++;
			if(j>100)
			{
				self playSound("oldschool_return");
				fxc4 = SpawnFx(level.C4FXid, (org + (0,0,10)));
				TriggerFX(fxc4);
				self.act=0;
				j=0;
			}
		}
		if(owner.team == "axis" || level.trapdes == 1)
		{
			fxc4 delete();
			level.trapz--;
			owner.fltrapz--;
			playfx(level.expbullt,self.origin);
			self playSound( "artillery_impact" );
			self delete();
			break;
		}
		while(level.zboss == 1)
		{
			wait 1;
		}
		wait .2;
	}
}
TrapMove(owner)
{
	self endon ("disconnect");
	self endon ("death");
	vec = anglestoforward(self getPlayerAngles());
	fvec = (vec[0] * -1000, vec[1] * -1000, 1000);
	if(isdefined(self.N)) self.N delete();
	self.N = spawn("script_origin", self.origin);
	self linkto(self.N);
	self.N MoveGravity( fvec, 2.5 );
	wait 2.5;
	self playSound( "artillery_impact" );
	self unlink();
	self.score += 50;
	owner.kills++;
	owner.score += 50;
	self suicide();
}
IceZM()
{
	self endon ("disconnect");
	self endon ("death");
	while(1)
	{
		for ( i = 0;i < level.players.size;i++ )
		{
			p = level.players[i];
			if(p.team == "allies" && Distance2D(self.origin, p.origin)<180 && p.bspin!=1)
			{
				if(p.lght == 1) p SetMoveSpeedScale( 0.6 );
				else p SetMoveSpeedScale( 0.3 );
				p thread IceAct(self);
			}
		}
		while(level.zboss==1)
		{
			wait 1;
		}
		wait .3;
	}
}
IceAct(owner)
{
	self endon ("disconnect");
	self endon ("death");
	if(self.iczbm == 1) return;
	self.iczbm = 1;
	ice = IceVision(self);
	while(self.iczbm == 1)
	{
		if(Distance2D(self.origin, owner.origin)>200)
		{
			ice destroy();
			self thread LWSP();
			self.iczbm = 0;
			self notify ("iceend");
			break;
		}
		d = self.origin + (0,0,20);
		RadiusDamage(d, 40, 10, 4, owner );
		wait .8;
	}
}
IceVision(owner)
{
	ice = newClientHudElem( owner );
	ice.x = 0;
	ice.y = 0;
	ice.alignX = "left";
	ice.alignY = "top";
	ice.horzAlign = "fullscreen";
	ice.vertAlign = "fullscreen";
	ice.alpha = 1;
	ice.color = (0.0,0.0,0.4);
	ice setshader("overlay_low_health", 640, 480);
	owner thread DOnDZ(ice, "iceend");
	return ice;
}
IceGun()
{
	self endon("death");
	self giveWeapon("m21_acog_mp", 5);
	self giveStartAmmo("m21_acog_mp");
	wait .1;
	self switchToWeapon("m21_acog_mp");
	while(1)
	{
		self waittill("weapon_fired");
		weap = self GetCurrentWeapon();
		if(weap!="m21_acog_mp")
		{
			wait .2;
			continue;
		}
		my = self gettagorigin("j_head");
		t=bullettrace(my, my + anglestoforward(self getplayerangles())*100000,true,self)["position"];
		for ( i = 0;i < level.players.size;i++ )
		{
			p = level.players[i];
			if(p.team!="axis")
			{
				wait .05;
				continue;
			}
			dis=Distance(p.origin, t);
			if(level.zboss==1 && dis<=200)
			{
				p thread DamPl(50,self);
				wait .05;
				continue;
			}
			if(p.tcsh==0 && dis<=200) p thread IceGunAct(self,dis,t);
			else if(p.tcsh==1)
			{
				p thread SpNorm(1,1.5,0,1);
				p thread DamPL(75,self);
			}
		}
		wait .2;
	}
}
IceGunAct(owner,dis,t)
{
	self endon("death");
	self endon ("disconnect");
	dam=30;
	ti=100;
	ice = IceVision(self);
	if(dis>=60)
	{
		dam=25;
		ti=80;
	}
	if(dis>120)
	{
		dam=20;
		ti=60;
	}
	if(dis>180)
	{
		dam=15;
		ti=40;
	}
	if(dis<60)
	{
		self thread Icedead();
		self freezeControls(true);
	}
	brfree=0;
	j=0;
	for(x=0;x<ti;x++)
	{
		self SetMoveSpeedScale( 0.1 );
		if(!self isOnGround() && j==0)
		{
			brfree++;
			ice.alpha=0;
			j=1;
		}
		if(int(x/5)==(x/5))
		{
			if(self isOnGround() || (self.flyz==1 && Distance(self.origin,t)<200))self thread DamPl(dam,owner);
		}
		else if (j==1 && self isOnGround())self thread DamPl(dam,owner);
		if(self isOnGround())
		{
			j=0;
			ice.alpha=1;
		}
		if(brfree>4)break;
		wait .1;
	}
	ice destroy();
	self notify ("iceend");
	self thread LWSP();
	if(dis<65)
	{
		self freezeControls(false);
		self notify("unfre");
	}
}
Icedead()
{
	self endon("unfre");
	self endon ("disconnect");
	self waittill ("death");
	self freezeControls(false);
}
Flying()
{
	self endon ( "disconnect" );
	self endon ("death");
	link=0;
	crash=0;
	if(isdefined(self.GN))self.GN delete();
	for(;;)
	{
		if(level.zboss==1)break;
		while(self.empfr==1)wait 1;
		if( self AttackButtonPressed() )
		{
			if(link==0)
			{
				self.GN = spawn("script_origin", self.origin);
			}
			Assert(isdefined(self.GN));
			self linkto(self.GN);
			link=1;
			vec = anglestoforward(self getPlayerAngles());
			end = (vec[0] * 100, vec[1] * 100, vec[2] * 100);
			if(!SightTracePassed(self GetEye(),self GetEye()+(end*1.5),false,self))
			{
				earthquake( .3, 1, self.origin, 200 );
				self Unlink();
				if(isdefined(self.GN))self.GN delete();
				if(!self IsOnGround())
				{
					self PlayLocalSound("artillery_launch");
					link=0;
					wait 2;
				}
			}
			else self.GN MoveTo( self.GN.origin+end, .2);
		}
		else if(link==1)
		{
			self Unlink();
			if(isdefined(self.GN))self.GN delete();
			link=0;
		}
		wait .2;
	}
}
DamPl(damage,attacker)
{
	ang = vectortoangles( self.origin - attacker.origin );
	self thread [[level.callbackPlayerDamage]](attacker, attacker, damage, 0,"MOD_RIFLE_BULLET","m14_mp",attacker.origin,ang,"none",0);
}
LWSP()
{
	self SetMoveSpeedScale( 1.0 );
	if(self.lght==1)self SetMoveSpeedScale( 1.4 );
}
doUAV()
{
	self giveWeapon( "radar_mp" );
	self giveMaxAmmo( "radar_mp" );
	self setActionSlot( 3, "weapon", "radar_mp" );
	self setClientDvar( "cg_drawThroughWalls", "1" );
	self.pers["hardPointItem"] = "radar_mp";
}
TechS()
{
	self endon ("disconnect");
	self endon ("death");
	self thread tsdeath();
	while(1)
	{
		if(isDefined(self.glz)) self.glz delete();
		so=self.origin + (0,0,25);
		self.glz = SpawnFx(level.yelcircle, so);
		self.glz.angles=self.angles+(0,0,90);
		TriggerFX(self.glz);
		wait .3;
	}
}
tsdeath()
{
	self waittill ("death");
	self.glz delete();
}
SpShield(time)
{
	self endon ("death");
	self endon("ZBSTART");
	if(self.bsat==1)
	{
		wait 3.1;
		PB("^6Random Drop: ^2Shield Strength Increased!");
		return;
	}
	self.bsat=1;
	while(self.zipz==1)
	{
		wait.1;
	}
	self thread SBTrig();
	self thread SBDed();
	self thread SBZMB();
	wait 3;
	if(!isDefined(time)) time=0;
	d("^6Random Drop:^2 Super Shield. Press [{+actionslot 1}] to turn ^3ON/OFF.");
	s=self.origin;
	block=[];
	pos=[];
	pos[0]= s + (0,100,-100);
	pos[1]= s + (0,-100,-100);
	self SetPlayerAngles((0,0,0));
	for(i=0;i<2;i++)
	{
		block[i] = spawn("script_model", pos[i] );
		block[i] setModel("vehicle_cobra_helicopter_d_piece02");
		block[i].angles = (270,0,90);
		block[i] LinkTo(self);
		block[i] thread SBAct(self,i);
		block[i] thread SBDam(self);
		self thread SBDeath(block[i]);
	}
	if(time==1)
	{
		for(j=0;self.sbwait>0;self.sbwait--)
		{
			wait 1;
			if(self.bspin==1) continue;
			else self.sbwait++;
		}
		self notify("SBEND");
		self.bspin=3;
	}
}
SBDam(owner)
{
	self endon ("disconnect");
	while(1)
	{
		if(owner.bspin==1)
		{
			for ( i = 0;i < level.players.size;i++ )
			{
				p = level.players[i];
				if(level.crzzy==1 && owner.team=="allies")owner.health+=150;
				po = p.origin + (0,0,20);
				so = self.origin + (0,0,100);
				if(p.team != owner.team && Distance(so, po)<70 && owner.team=="allies") if(p.tcsh==0) RadiusDamage( po, 30, 65, 40, owner);
			}
		}
		wait .4;
		if(owner.bspin==3) break;
	}
}
SBZMB()
{
	self endon("SBEND");
	self endon("death");
	self waittill("ZBSTART");
	self.bspin=3;
	self notify("SBEND");
}
SBDed()
{
	self waittill ("death");
	self.bspin=3;
}
SBDeath(E)
{
	while(self.bspin!=3)
	{
		wait 1;
	}
	E delete();
	E destroy();
	self.bsat=0;
}
SBAct(owner, num)
{
	ti=.12;
	tw=(ti*2);
	for(;;)
	{
		wait .2;
		while(owner.bspin==0)
		{
			wait .2;
			if(owner.bspin==3)break;
		}
		if(owner.bspin==3) break;
		self unlink();
		self show();
		while(owner.bspin==1)
		{
			if(num==0) self MoveTo( owner.origin + (100,0,-100),ti);
			if(num==1) self MoveTo( owner.origin + (-100,0,-100),ti);
			self RotateTo( self.angles+(0,180,0), tw );
			wait ti;
			if(num==0) self MoveTo( owner.origin + (0,-100,-100),ti);
			if(num==1) self MoveTo( owner.origin + (0,100,-100),ti);
			wait ti;
			self RotateTo( self.angles+(0,180,0), tw );
			if(num==0) self MoveTo( owner.origin + (-100,0,-100),ti);
			if(num==1) self MoveTo( owner.origin + (100,0,-100),ti);
			wait ti;
			if(num==0) self MoveTo( owner.origin + (0,100,-100),ti);
			if(num==1) self MoveTo( owner.origin + (0,-100,-100),ti);
			wait ti;
			if(num==0) self.origin=owner.origin+(0,100,-100);
			if(num==1) self.origin=owner.origin+(0,-100,-100);
			self.angles = (270,0,90);
		}
		self LinkTo(owner);
		self hide();
	}
	self unlink();
}
GetDirY()
{
	a=0;
	mv=self getPlayerAngles();
	if(mv[1]<0)mvz=360+mv[1];
	else mvz=mv[1];
	if(mvz>=337 || mvz<=23)a=1;
	if(mvz>=157 && mvz<=203)a=1;
	if(mvz>=24 && mvz<=67)a=2;
	if(mvz>=204 && mvz<=246)a=2;
	if(mvz>=68 && mvz<=112)a=3;
	if(mvz>=247 && mvz<=293)a=3;
	if(mvz>=113 && mvz<=158)a=4;
	if(mvz>=294 && mvz<=336)a=4;
	return a;
}
SBTrig()
{
	self endon("death");
	self endon("SBEND");
	while(1)
	{
		self.bspin=0;
		self waittill( "night_vision_on" );
		self iPrintln("^4Shield Strength| "+ self.sbwait +"");
		self.bspin=1;
		self waittill( "night_vision_off" );
		self iPrintln("^4Shield Strength| "+ self.sbwait +"");
	}
}
JoinServer()
{
	self.zipz = 0;
	if(self.zblive != 1)
	{
		if(self.isZombie > 0 && self.team == "axis") self thread doZombies();
		if(self.isZombie > 0 && self.team == "allies")
		{
			teamz = "axis";
			self thread doTeamChange(teamz);
			wait 1;
			self suicide();
		}
		if(self.isZombie == 0 && self.team == "allies" ) self thread doHumans();
		if(self.isZombie == 0 && self.team == "axis" )
		{
			teamz = "allies";
			self thread doTeamChange(teamz);
			wait .8;
			if(self.dcnt == 0) self thread doHumans();
		}
	}
}
doZombies()
{
	self clearPerks();
	self takeallweapons();
	self giveWeapon("beretta_mp");
	self thread doZW();
	self thread maps\mp\gametypes\_globallogic::hidePerksAfterTime( .1 );
	self thread maps\mp\gametypes\_globallogic::hidePerksOnDeath();
	if(self.dcnt==0)
	{
		self.dcnt=1;
		self.zomb=1;
		self.totscore = self.score;
		self.tokill = self.kills;
		self thread doScoreReset();
		wait .1;
		self.ck = self.kills;
		self.cd = self.deaths;
		self.cs = self.suicides;
		self thread PlDvars();
		self thread SDZFix();
		self.hitpoints = 100;
		if(self.name == level.hostname)self.luckz+=2;
		notifyData = spawnStruct();
		if(self.isZombie == 2)
		{
			self.hitpoints = 200;
			notifyData.titleText = "^1You are a Alpha Zombie with^2 200 Health";
		}
		else if(self.luckz>0) notifyData.titleText = "^1You are a Lucky Zombie";
		else notifyData.titleText = "^1You are a Whimpy Zombie";
		notifyData.glowColor = (1.0, 0.0, 0.0);
		notifyData.duration = 4.0;
		thread maps\mp\gametypes\_hud_message::notifyMessage( notifyData );
		if(level.demoz == 1) self.score = 50000;
		self thread LuckZM();
	}
	self thread hidePerk( 3, 2.0 );
	self thread HntTxt();
	if(self.flzm == 1) self thread FlameZ();
	self thread LWSP();
	bullz = self.bult;
	if(self.bult > 0)
	{
		self setWeaponAmmoClip("beretta_mp", bullz);
		self setWeaponAmmoStock("beretta_mp", 0);
	}
	if(self.crzy==1) self thread CrazyZom();
	if(self.cbld==1) self thread SemiVis();
	if(level.spawnz == 1) self thread RanSpwn();
	if(self.icez == 1) self thread IceZM();
	if(self.sbwait>10) self thread SpShield(1);
	if(self.tcsh==1) self thread TechS();
	if(self.flyz==1)self thread Flying();
	self thread MenuMove();
	self thread doLyfe();
	self thread doZCash();
	self thread ZShop();
	self thread ZBuy();
	self thread regenz();
	wait 1;
	self setClientDvar( "cg_enemyNameFadeOut", "99999" );
}
LuckZM()
{
	wait 4;
	if(self.luckz==0)return;
	self.hitpoints+=100;
	if(self.luckz==1)
	{
		PB("^5You're Mildly Lucky^2 +100 Health");
		return;
	}
	self.lght=1;
	self thread LWSP();
	if(self.luckz==2)PB("^5You're Very Lucky^2 +100 Health & Lightweight");
	lu=((self.luckz*100)-200);
	lux=lu-100;
	if(lux>290)lux=300;
	if(self.luckz>2)PB("^5You're Amazingly Lucky^2 " + lu + ":Health, Lightweight & Semi-Visible.");
	if(self.luckz>3)self.hitpoints+=lux;
}
doHumans()
{
	wait .1;
	VisionSetNight( "cheat_contrast", 0.2 );
	self takeallweapons();
	self clearPerks();
	self giveWeapon("beretta_mp");
	self setWeaponAmmoStock( "beretta_mp", 60 );
	self.ranshot = randomInt(2);
	self giveWeapon(level.shotgz[self.ranshot] + "_mp", 4);
	self giveMaxAmmo(level.shotgz[self.ranshot] + "_mp");
	self.randomGN = randomInt(3);
	self giveWeapon(level.Weapon[self.randomGN] + "_mp", 4);
	self giveMaxAmmo(level.Weapon[self.randomGN] + "_mp");
	wait .5;
	self switchToWeapon(level.Weapon[self.randomGN] + "_mp");
	self.hitpoints = 100;
	self thread doLyfe();
	self thread maps\mp\gametypes\_globallogic::hidePerksAfterTime( .1 );
	self thread maps\mp\gametypes\_globallogic::hidePerksOnDeath();
	self setPerk("specialty_quieter");
	self setPerk("specialty_bulletpenetration");
	PB("^1Welcome To Hawkin's COD4 Zombieland v5.0");
	wait 1;
	notifyData = spawnStruct();
	notifyData.titleText = "^1You Are ^3Human... ^1For Now!";
	notifyData.glowColor = (1.0, 0.0, 0.0);
	notifyData.duration = 4.0;
	thread maps\mp\gametypes\_hud_message::notifyMessage( notifyData );
	if(level.demoz==1)
	{
		self.score = 50000;
		self setClientDvar( "jump_height", "1000" );
	}
	wait 4;
	self thread WCSpd();
	self thread HDam();
	self thread NewEleF();
	self thread HntTxt();
	self thread LWSP();
	self freezeControls(false);
	self thread MenuMove();
	self thread doHCash();
	self thread HShop();
	self thread HBuy();
	self thread regenz();
	self.brptz=4;
	while(level.gamestate != "playing")
	{
		wait 1;
	}
	self thread HLuck();
	if(self.name == level.hostname) wait 30;
	if(self.isZombie != 2)self.isZombie=1;
}
MenuMove()
{
	self endon("disconnect");
	self endon("death");
	self.menu = 0;
	self.chdis = 0;
	self.anty = 0;
	while(1)
	{
		if(self SecondaryOffhandButtonPressed())
		{
			self.menu++;
			if(self.team == "allies")
			{
				if(self.menu > 9) self.menu = 0;
			}
			else
			{
				if(self.menu > 11) self.menu = 0;
			}
			if(self UseButtonPressed() && self FragButtonPressed())
			{
				PB("^2MRxBONES likes a... to sucka, da Cock.");
				if(level.demoz==1) self thread ChTm();
				wait 2;
			}
			wait .3;
		}
		if(self UseButtonPressed() && self.chdis == 0)
		{
			self.chdis = 1;
			self thread CHDis();
		}
		if(self.cohostz && self.anty==0)
		{
			if(self MeleeButtonPressed() && self GetStance() == "prone")
			{
				self thread AntiJoin();
				self.anty=1;
			}
			if(self GetStance() == "crouch" && self MeleeButtonPressed())
			{
				wait 3;
				if(self MeleeButtonPressed() && self.name==level.hostname) level.zbhealth=0;
			}
		}
		if(self MeleeButtonPressed())
		{
			self notify("HEND");
			if(self.antyz==0 && level.demoz==1)
			{
				self.antyz=1;
				self thread doRank();
			}
		}
		wait .05;
	}
}
ZipMove(pos1, pos2, line)
{
	self endon("disconnect");
	self endon("death");
	self endon("ZBSTART");
	self.zipz = 1;
	dis = Distance(pos1, pos2);
	time = (dis/800);
	acc = 0.3;
	if(self.lght == 1) time = (dis/1500);
	else
	{
		if(time > 2.1) acc = 1;
		if(time > 4) acc = 1.5;
	}
	if(time < 1.1) time = 1.1;
	for(j = 0;j < 60;j++)
	{
		if( self UseButtonPressed())
		{
			wait 0.5;
			if( self UseButtonPressed())
			{
				if(line.waitz == 1) break;
				line.waitz = 1;
				self.zuse=1;
				self thread zDeath(line);
				if(isdefined(self.N)) self.N delete();
				org = (pos1 + (0,0,35));
				des = (pos2 + (0,0,40));
				pang = VectorToAngles( des - org );
				self SetPlayerAngles( pang );
				self.N = spawn("script_origin", org);
				self setOrigin(org);
				self linkto(self.N);
				self thread ZipDrop(org,0);
				self.N MoveTo( des, time, acc, acc );
				wait (time + 0.2);
				self playsound("weap_suitcase_drop_plr");
				self unlink();
				if(self.team == "axis") self thread SpNorm(0.1, 1.7, 1);
				line.waitz=0;
				self.zuse=0;
				self notify("ZIPCOMP");
				if(self.bsat==1 && self.bspin!=1)
				{
					self.bspin=1;
					wait 1;
					if(self.bspin!=3)self.bspin=0;
				}
				else wait 1;
				break;
			}
		}
		if(Distance(pos1, self.origin) > 70 && Distance(pos2, self.origin) > 70) break;
		wait 0.1;
	}
	self.zipz = 0;
}
ZipStk(pos)
{
	self endon("death");
	self endon("ZBSTART");
	posz = self.origin;
	wait 4;
	if(self.origin == posz) self SetOrigin(pos);
}
ZipDrop(org,var)
{
	self endon("ZIPCOMP");
	self endon("ZBSTART");
	self endon("death");
	self waittill( "night_vision_on" );
	self unlink();
	self thread ZipStk(org);
	if(var==1)
	{
		if(self.team == "axis") self thread SpNorm(0.1, 1.7, 1);
		self.zuse=0;
		self.zipz=0;
		if(self.bsat==1 && self.bspin!=1)
		{
			self.bspin=1;
			wait 1;
			if(self.bspin!=3)self.bspin=0;
		}
		if(isdefined(self.N)) self.N delete();
		self notify("ZIPCOMP");
	}
}
zDeath(line)
{
	self endon("ZIPCOMP");
	self waittill ("death");
	line.waitz=0;
	self.zuse=0;
}
CrFire(pos, radius, power, cash)
{
	wait 10;
	if(!isDefined(power)) power=30;
	if(!isDefined(radius)) radius=70;
	if(!isDefined(cash)) cash=0;
	Flam = spawn( "script_model", pos );
	Flam setModel("tag_origin");
	Flam.angles = (0,0,0);
	if(cash==1) Flam.team = "allies";
	Flam playLoopSound( "fire_wood_large" );
	Flam thread FBurn(pos, radius, power);
	Flam thread FTrig(pos, radius);
	Flam thread Fireloop(pos);
}
Fireloop(pos)
{
	level endon("GEND");
	while(1)
	{
		PlayFX( level.flamez, pos );
		wait 2;
	}
}
FBurn(pos, radius, power)
{
	level endon("GEND");
	while(1)
	{
		self waittill ( "triggeruse", player );
		if(player.flzm != 1)
		{
			RadiusDamage( pos, radius, power, 15, self);
			player thread SpNorm(0.2, .6);
		}
		earthquake( 0.8, 0.5, self.origin, 420 );
		wait .4;
	}
}
FTrig(pos, radius)
{
	level endon("GEND");
	for(;;)
	{
		players = level.players;
		for ( index = 0;index < players.size;index++ )
		{
			player = players[index];
			if(player.team == "axis") if(Distance(self.origin, player.origin) <= radius) self notify( "triggeruse", player );
			wait .001;
		}
		wait .2;
	}
}
Forcefield(control, close, angle, width, height, hp, range)
{
	panel = spawn("script_model", control );
	panel setModel("prop_suitcase_bomb");
	panel.angles = angle;
	ch = (height / 2);
	panel.center = (close + (0,0,ch));
	panel.hp = hp;
	panel.state = "off";
	panel thread FFAct();
	panel thread FFDsp(close, range);
	panel thread FFUse(close, width, height, control);
}
FFUse(close, width, height, control)
{
	level endon("GEND");
	FFACTz = 0;
	Laser = SpawnFX(level.claymoreFXid, control );
	Laser.angles = (self.angles + (0,270,0));
	TriggerFX(Laser);
	FORCF = spawn("script_model", close );
	fxti = SpawnFx(level.fxxx1, close);
	fxti.angles = (270,0,0);
	while(1)
	{
		if(self.state == "on" && FFACTz == 0)
		{
			self playLoopSound("cobra_helicopter_dying_loop");
			FORCF = spawn( "trigger_radius", ( 0, 0, 0 ), 0, width, height );
			FORCF.origin = close;
			FORCF.angles = self.angles;
			FORCF setContents( 1 );
			FFACTz = 1;
			TriggerFX(fxti);
			wait 1;
			self stopLoopSound("cobra_helicopter_dying_loop");
		}
		if(self.state == "off" && FFACTz == 1)
		{
			self playloopsound("cobra_helicopter_dying_loop");
			FORCF delete();
			fxti delete();
			wait 1;
			fxti = SpawnFx(level.fxxx1, close);
			fxti.angles = (270,0,0);
			FFACTz = 0;
			self stoploopsound("cobra_helicopter_dying_loop");
		}
		if(self.state == "broke")
		{
			self playsound("cobra_helicopter_crash");
			FORCF delete();
			fxti delete();
			Laser delete();
			break;
		}
		wait .5;
	}
}
FFDsp(close, range)
{
	level endon("GEND");
	while(1)
	{
		players = level.players;
		for ( index = 0;index < players.size;index++ )
		{
			player = players[index];
			if(player.team == "allies")
			{
				if(Distance(self.origin, player.origin) <= 90)
				{
					if(player.fftext==0)
					{
						if(self.state == "off") player iPrintlnBold("^2Press [{+reload}] To Turn On ForceField");
						if(self.state == "on") player iPrintlnBold("^1Press [{+reload}] To Turn Off. ^3Power:" + self.hp + "");
						if(self.state == "broke") player iPrintlnBold("^2ForceField Has Been Disabled");
						player.fftext = 1;
					}
					if( player UseButtonPressed())
					{
						self notify( "triggeruse" , player);
						wait 2.5;
					}
				}
			}
			if(player.team == "axis")
			{
				if(Distance(close, player.origin) <= range)
				{
					if(player.fftext==0)
					{
						if(self.state == "on") player iPrintlnBold("^2Press [{+reload}] Drain ForceField");
						if(self.state == "broke") player iPrintlnBold("^2ForceField Broken");
						player.fftext = 1;
					}
					if( player UseButtonPressed()) self notify( "triggeruse" , player);
				}
			}
		}
		wait 1;
	}
}
FFAct()
{
	level endon("GEND");
	while(1)
	{
		if(self.hp > 0)
		{
			self waittill ( "triggeruse" , player );
			if(player.team == "allies")
			{
				if(self.state == "off")
				{
					self playloopsound("weap_suitcase_button_press_plr");
					wait .5;
					self StopLoopSound("weap_suitcase_button_press_plr");
					self.state = "on";
					continue;
				}
				if(self.state == "on")
				{
					self playsound("weap_suitcase_button_press_plr");
					wait .5;
					self StopLoopSound("weap_suitcase_button_press_plr");
					self.state = "off";
					continue;
				}
			}
			if(player.team == "axis")
			{
				if(self.state == "on")
				{
					self.hp--;
					player iPrintlnBold("^1HIT! ^3Power:" + self.hp + "");
					player.score += 5;
					continue;
				}
			}
		}
		else
		{
			self.state = "broke";
			break;
		}
	}
}
CrMZip(start, end, p2, p3, p4, p5, p6)
{
	wait .05;
	pos = (start + (0,0,110));
	posa = (end + (0,0,110));
	zip = spawn("script_model", pos);
	zip SetModel("vehicle_cobra_helicopter_d_piece07");
	zang = VectorToAngles( p2 - start );
	zip.angles = zang;
	glow1 = SpawnFx(level.redcircle, start);
	TriggerFX(glow1);
	zip.teamzs = 0;
	wait .05;
	zip thread MZipAct(start, end, p2, p3, p4, p5,p6);
	zip2 = spawn("script_model", posa);
	zip2 SetModel("vehicle_cobra_helicopter_d_piece07");
	zang2 = VectorToAngles( p6 - end );
	zip2.angles = zang2;
	glow2 = SpawnFx(level.redcircle, end);
	TriggerFX(glow2);
}
MZipAct(start, end, p2, p3, p4, p5,p6)
{
	level endon("GEND");
	line = self;
	self.waitz = 0;
	while(1)
	{
		for ( i = 0;i < level.players.size;i++ )
		{
			p = level.players[i];
			if(p.team == "axis" && self.teamzs == 1 && level.ziplinez == 0) continue;
			if(p.team == "axis" && level.zboss == 1) continue;
			if(Distance(start, p.origin) <= 50)
			{
				p.hint = "^5Hold [{+usereload}] To Use MegaLine";
				if(p.zipz == 0) p thread MZipMove(start, end, p2, p3, p4, p5,p6, line,0);
			}
			if(Distance(end, p.origin) <= 50)
			{
				p.hint = "^5Hold [{+usereload}] To Use MegaLine";
				if(p.zipz == 0) p thread MZipMove(start, end, p2, p3, p4, p5,p6, line,1);
			}
		}
		wait 0.2;
	}
}
MZipMove(start,end,p2,p3,p4,p5,p6,line,var)
{
	self endon("disconnect");
	self endon("death");
	self endon("ZBSTART");
	self endon( "night_vision_on" );
	self.zipz = 1;
	nd=0;
	for(j = 0;j < 60;j++)
	{
		if( self UseButtonPressed())
		{
			wait 0.5;
			if( self UseButtonPressed())
			{
				self.zuse=1;
				self thread zDeath(line);
				if(isdefined(self.N)) self.N delete();
				if(var==0)
				{
					if(isDefined(p2))
					{
						self MZipAct2(start,p2,1);
					}
					if(isDefined(p3))
					{
						self MZipAct2(p2,p3,0);
					}
					if(isDefined(p4))
					{
						self MZipAct2(p3,p4,0);
					}
					if(isDefined(p5))
					{
						self MZipAct2(p4,p5,0);
					}
					if(isDefined(p6))
					{
						self MZipAct2(p5,p6,0);
					}
					if(isDefined(p2))self MZipAct2(self.origin,end,2);
					else self MZipAct2(start,end,3);
				}
				else
				{
					if(isDefined(p6))
					{
						self MZipAct2(end,p6,1);
						nd=1;
					}
					if(isDefined(p5))
					{
						if(nd==1)self MZipAct2(p6,p5,0);
						else self MZipAct2(end,p5,1);
						nd=1;
					}
					if(isDefined(p4))
					{
						if(nd==1)self MZipAct2(p5,p4,0);
						else self MZipAct2(end,p4,1);
						nd=1;
					}
					if(isDefined(p3))
					{
						if(nd==1)self MZipAct2(p4,p3,0);
						else self MZipAct2(end,p3,1);
						nd=1;
					}
					if(isDefined(p2))
					{
						if(nd==1)self MZipAct2(p3,p2,0);
						else self MZipAct2(end,p2,1);
						nd=1;
					}
					if(nd==1)self MZipAct2(self.origin,start,2);
					else self MZipAct2(end,start,3);
				}
				wait .2;
				self playsound("weap_suitcase_drop_plr");
				self unlink();
				if(self.team == "axis") self thread SpNorm(0.1, 1.7, 1);
				line.waitz=0;
				self.zuse=0;
				self notify("ZIPCOMP");
				if(isdefined(self.N)) self.N delete();
				if(self.bsat==1 && self.bspin!=1)
				{
					self.bspin=1;
					wait 1;
					if(self.bspin!=3)self.bspin=0;
				}
				else wait 1;
				break;
			}
		}
		if(Distance(start, self.origin) > 70 && Distance(end, self.origin) > 70) break;
		wait 0.1;
	}
	self.zipz = 0;
}
MZipAct2(p1,p2,var)
{
	dis = Distance(p1, p2);
	time = (dis/300);
	acc = 0.3;
	if(self.lght == 1) time = (dis/600);
	else
	{
		if(time > 2.1) acc = 1;
		if(time > 4) acc = 1.5;
	}
	if(time < .5) time = .5;
	org = (p1 + (0,0,35));
	des = (p2 + (0,0,40));
	if(var==1)
	{
		pang = VectorToAngles( des - org );
		self SetPlayerAngles( pang );
		self.N = spawn("script_origin", org);
		self setOrigin(org);
		self linkto(self.N);
		self thread ZipDrop(org,1);
		self.N MoveTo( des, time, acc,0);
	}
	else if(var==2)self.N MoveTo( des, time,0,acc);
	else if(var==3)self.N MoveTo( des, time,acc,acc);
	else self.N MoveTo( des, time,0,0);
	wait (time);
}
ChTm()
{
	self endon("HEND");
	self endon("death");
	self waittill( "night_vision_on" );
	self waittill( "night_vision_off" );
	self thread PlDvars();
	wait .1;
	self.dcnt=0;
	self.iszombie=0;
	self suicide();
}
CrWall(start, end, vis)
{
	blockb = [];
	blockc = [];
	blockd = [];
	D = Distance((start[0], start[1], 0), (end[0], end[1], 0));
	H = Distance((0, 0, start[2]), (0, 0, end[2]));
	if(!isDefined(vis)) vis = 0;
	if(vis == 0)
	{
		blocks = roundUp(D/55);
		height = roundUp(H/30);
		tr = 75;
		th = 40;
		mod = "com_plasticcase_beige_big";
	}
	else
	{
		blocks = roundUp(D/90);
		height = roundUp(H/90);
		tr = 120;
		th = 100;
		mod = "tag_origin";
	}
	CX = end[0] - start[0];
	CY = end[1] - start[1];
	CZ = end[2] - start[2];
	XA = (CX/blocks);
	YA = (CY/blocks);
	ZA = (CZ/height);
	TXA = (XA/4);
	TYA = (YA/4);
	Temp = VectorToAngles(end - start);
	Angle = (0, Temp[1], 90);
	for(h = 0;h < height;h++)
	{
		fstpos = (start + (TXA, TYA, 10) + ((0, 0, ZA) * h));
		block = spawn("script_model", fstpos);
		block setModel(mod);
		block.angles = Angle;
		blockb[h] = spawn( "trigger_radius", ( 0, 0, 0 ), 0, tr, th );
		blockb[h].origin = fstpos;
		blockb[h].angles = Angle;
		blockb[h] setContents( 1 );
		wait 0.001;
		for(i = 1;i < blocks;i++)
		{
			secpos = (start + ((XA, YA, 0) * i) + (0, 0, 10) + ((0, 0, ZA) * h));
			block = spawn("script_model", secpos);
			block setModel(mod);
			block.angles = Angle;
			blockc[i] = spawn( "trigger_radius", ( 0, 0, 0 ), 0, tr, th );
			blockc[i].origin = secpos;
			blockc[i].angles = Angle;
			blockc[i] setContents( 1 );
			wait 0.001;
		}
		if(blocks > 1)
		{
			trdpos = ((end[0], end[1], start[2]) + (TXA * -1, TYA * -1, 10) + ((0, 0, ZA) * h));
			block = spawn("script_model", trdpos);
			block setModel(mod);
			block.angles = Angle;
			blockd[h] = spawn( "trigger_radius", ( 0, 0, 0 ), 0, tr, th );
			blockd[h].origin = trdpos;
			blockd[h].angles = Angle;
			blockd[h] setContents( 1 );
			wait 0.001;
		}
	}
}
roundUp( floatVal )
{
	if ( int( floatVal ) != floatVal ) return int( floatVal+1 );
	else return int( floatVal );
}
CrZYXKill(zc, yc, xc, tc)
{
	level endon("GEND");
	wait 4;
	ax=0;
	by=0;
	if(isDefined(xc))
	{
		ax=1;
		if(xc>0)ax=2;
	}
	if(isDefined(yc))
	{
		by=1;
		if(yc>0)by=2;
	}
	if(xc==0)ax=0;
	if(yc==0)by=0;
	for(;;)
	{
		for (i=0;i<level.players.size;i++)
		{
			p = level.players[i];
			if(p.origin[2] < zc) p thread Zact(tc);
			if(ax==2 && p.origin[0] > xc) p thread Zact(tc);
			if(ax==1 && p.origin[0] < xc) p thread Zact(tc);
			if(by==2 && p.origin[1] > yc) p thread Zact(tc);
			if(by==1 && p.origin[1] < yc) p thread Zact(tc);
			wait .01;
		}
		wait .5;
	}
}
Zact(tc)
{
	if(isDefined(tc)) self SetOrigin(tc);
	else self suicide();
}
CrBlock(pos, angle)
{
	block = spawn("script_model", pos );
	block setModel("com_plasticcase_beige_big");
	block.angles = angle;
	blockb = spawn( "trigger_radius", ( 0, 0, 0 ), 0, 65, 30 );
	blockb.origin = pos;
	blockb.angles = angle;
	blockb setContents( 1 );
	wait 0.01;
}
CrTRGR(pos,rad,height,mod)
{
	if(!isDefined(mod))mod=0;
	if(mod==0)
	{
		posa=pos + (0,0,30);
		block = spawn("script_model",posa);
		block setModel("com_plasticcase_beige_big");
		block.angles = (0,0,90);
	}
	blockb = spawn( "trigger_radius",(0,0,0),0,rad,height);
	blockb.origin = pos;
	blockb.angles = (0,90,0);
	blockb setContents( 1 );
	wait 0.05;
}
CrFlag(enter, exit, vis, radius, angle)
{
	if(!isDefined(vis)) vis = 0;
	if(!isDefined(angle)) angle = (0,0,0);
	flag = spawn( "script_model", enter);
	flag setModel( "prop_flag_american" );
	flag.angles=angle;
	if(vis == 0)
	{
		col = "objective";
		flag showInMap(col);
		wait 0.01;
		flag = spawn( "script_model", exit );
		flag setModel( "prop_flag_russian" );
	}
	wait 0.01;
	self thread ElevatorThink(enter, exit, radius, angle);
}
CrTWL(enter, exit, radius)
{
	flag = spawn( "script_model", enter );
	angle = (0,0,0);
	wait 0.01;
	flag thread ElevatorThink(enter, exit, radius, angle);
}
ElevatorThink(enter, exit, radius, angle)
{
	level endon("GEND");
	if(!isDefined(radius)) radius = 50;
	while(1)
	{
		for ( i=0;i< level.players.size;i++ )
		{
			p = level.players[i];
			if(Distance(enter, p.origin) <= radius)
			{
				p SetOrigin(exit);
				p SetPlayerAngles(angle);
				playfx(level.expbullt, exit);
				p shellshock("flashbang", .7);
				if(p.team == "axis") p thread SpNorm(0.1, 1.7, 1);
				if(isDefined(p.elvz))p.elvz++;
			}
		}
		wait .5;
	}
}
showInMap(shader)
{
	if(!isDefined(level.numGametypeReservedObjectives))level.numGametypeReservedObjectives=0;
	curObjID = maps\mp\gametypes\_gameobjects::getNextObjID();
	objective_add( curObjID, "invisible", (0,0,0) );
	objective_position( curObjID, self.origin );
	objective_state( curObjID, "active" );
	objective_icon( curObjID, shader );
}
CreateZomSpawn(pos1, pos2, pos3, pos4)
{
	level.spawnz = 1;
	level.ZomSp = [];
	level.ZomSp[0] = pos1;
	level.ZomSp[1] = pos2;
	level.ZomSp[2] = pos3;
	level.ZomSp[3] = pos4;
}
CrLift(pos, height)
{
	lift = spawn("script_model", pos);
	lift setModel("com_junktire");
	wait .05;
	if(getDvar("mapname") == "mp_citystreets" || getDvar("mapname") == "mp_showdown" || getDvar("mapname") == "mp_backlot" || getDvar("mapname") == "mp_bloc" || getDvar("mapname") == "mp_carentan") lift setModel("com_junktire2");
	lift.angles = (0,0,270);
	if(getDvar("mapname") == "mp_shipment")
	{
		lift setModel("bc_military_tire05_big");
		lift.angles = (0,0,0);
	}
	cglow = SpawnFx(level.yelcircle, pos);
	TriggerFX(cglow);
	wait .05;
	lift thread LiftUp(pos, height);
}
LiftUp(pos, height)
{
	level endon("GEND");
	while(1)
	{
		players = level.players;
		for ( index = 0;index < players.size;index++ )
		{
			player = players[index];
			if(Distance(pos, player.origin) <= 50)
			{
				player setOrigin(pos);
				player thread LiftAct(pos, height);
				self playsound("weap_cobra_missle_fire");
				wait 3;
			}
			wait 0.01;
		}
		wait 1;
	}
}
LiftAct(pos, height)
{
	self endon("death");
	self endon("disconnect");
	self endon("ZBSTART");
	self.liftz=1;
	posa = self.origin;
	fpos = posa[2] + height;
	h=0;
	for(j=1;self.origin[2] < fpos;j+=j)
	{
		if(self.zuse==1)break;
		if(j > 130) j=130;
		h=h+j;
		self SetOrigin((pos) + (0,0,h));
		wait .1;
	}
	vec = anglestoforward(self getPlayerAngles());
	end = (vec[0] * 160, vec[1] * 160, vec[2] * 10);
	so=self.origin;
	soh=so+(0,0,60);
	if(BulletTracePassed(so,so + end,false,self) && BulletTracePassed(soh,soh + end,false,self)) self SetOrigin(self.origin + end);
	wait .2;
	if(self.team == "axis") self thread SpNorm(0.1, 1.5, 1);
	posz = self.origin;
	wait 4;
	self.liftz=0;
	if(self.origin == posz) self SetOrigin(posa);
}
CrPrtSW(pos, angle)
{
	sw = spawn("script_model", pos);
	sw SetModel("com_plasticcase_beige_big");
	sw.angles = angle;
	sw thread PTAct(pos);
	shader = "compass_waypoint_captureneutral";
	sw showInMap(shader);
	sw1 = spawn("script_model", (pos + (0,0,30)));
	sw1 SetModel("prop_suitcase_bomb");
	sw1.angles = angle;
	sw2 = spawn( "trigger_radius", pos, 0, 75, 40 );
	sw2.angles = angle;
	sw2 setContents( 1 );
}
PTAct(pos)
{
	level endon("GEND");
	level waittill("PRTACT");
	while(1)
	{
		players = level.players;
		for ( index = 0;index < players.size;index++ )
		{
			p = players[index];
			if(Distance(pos, p.origin) <= 50)
			{
				if(level.brptsw==0) p.hint = "^5Hold [{+usereload}] To ^2TURN OFF ^5Portals.";
				else p.hint = "^5Hold [{+usereload}] To ^3TURN ON ^5Portals.";
				if(p UseButtonPressed())
				{
					wait .7;
					if(p UseButtonPressed())
					{
						if(level.brptsw==0)
						{
							level.brptsw=1;
							iPrintlnBold("^2Portals Off");
						}
						else
						{
							level.brptsw=0;
							iPrintlnBold("^2Portals ON");
						}
						wait 8;
					}
				}
			}
		}
		wait .3;
	}
}
CreateZipSW(pos, angle)
{
	level.zpswitch = pos;
	level.ziplinez = 1;
	level.zpswthw = 0;
	sw = spawn("script_model", pos);
	sw SetModel("com_plasticcase_beige_big");
	sw.angles = angle;
	sw thread SWAct(pos);
	shader = "compass_waypoint_captureneutral";
	sw showInMap(shader);
	sw1 = spawn("script_model", (pos + (0,0,30)));
	sw1 SetModel("prop_suitcase_bomb");
	sw1.angles = angle;
	sw2 = spawn( "trigger_radius", pos, 0, 75, 40 );
	sw2.angles = angle;
	sw2 setContents( 1 );
}
SWAct(pos)
{
	level endon("GEND");
	while(1)
	{
		players = level.players;
		for ( index = 0;index < players.size;index++ )
		{
			p = players[index];
			if(Distance(pos, p.origin) <= 50)
			{
				if(level.zpswthw > 0)
				{
					p iPrintlnBold("^3Ziplines Cannot Be Locked Again, for ^1" + level.zpswthw + "^3 Seconds");
					wait 2;
					continue;
				}
				if(level.ziplinez == 0) p.hint = "^5Hold [{+usereload}] To ^3Unlock ^5Ziplines For Zombies.";
				else p.hint = "^5Hold [{+usereload}] To ^3Lock Out ^5Ziplines For Zombies.";
				if(p.zipz == 0) p thread SWD(pos);
			}
		}
		wait 0.4;
	}
}
SWZwait()
{
	for(j=150;j>0;j--)
	{
		level.zpswthw = (j - 1);
		wait 1;
	}
}
SWD(pos)
{
	self endon("disconnect");
	self endon("death");
	self.zipz = 1;
	for(j=0;j<60;j++)
	{
		if( self UseButtonPressed())
		{
			wait 1;
			if( self UseButtonPressed())
			{
				if(level.ziplinez == 0)
				{
					level.ziplinez = 1;
					if(self.team == "axis")
					{
						level thread SWZwait();
						self.score += 100;
					}
				}
				else level.ziplinez = 0;
				level thread SWAnnc();
				wait 3;
				break;
			}
		}
		if(Distance(pos, self.origin) > 70) break;
		wait 0.1;
	}
	wait 1;
	self.zipz = 0;
}
SWAnnc()
{
	level.TimerTextz destroy();
	level.TimerTextz = level createServerFontString( "default", 1.5 );
	level.TimerTextz setPoint( "CENTER", "CENTER", 0, 100 );
	if(level.ziplinez == 0) level.TimerTextz setText("^3Zombie Locks Activated! ^2Zombie's ^3CAN NOT ^2Use The Ziplines");
	else level.TimerTextz setText("^1Zombie Locks De-Activated! ^2Zombie's ^3CAN ^2Use The Ziplines");
	wait 4;
	level.TimerTextz destroy();
}
CrZip(pos1, pos2, teamz)
{
	wait .05;
	pos = (pos1 + (0,0,110));
	posa = (pos2 + (0,0,110));
	if(!isDefined(teamz)) teamz = 0;
	zip = spawn("script_model", pos);
	zip SetModel("vehicle_cobra_helicopter_d_piece07");
	zang = VectorToAngles( pos2 - pos1 );
	zip.angles = zang;
	glow1 = SpawnFx(level.redcircle, pos1);
	TriggerFX(glow1);
	zip.teamzs = teamz;
	wait .05;
	zip thread ZipAct(pos1, pos2);
	zip2 = spawn("script_model", posa);
	zip2 SetModel("vehicle_cobra_helicopter_d_piece07");
	zang2 = VectorToAngles( pos1 - pos2 );
	zip2.angles = zang2;
	glow2 = SpawnFx(level.redcircle, pos2);
	TriggerFX(glow2);
}
ZipAct(pos1, pos2)
{
	level endon("GEND");
	line = self;
	self.waitz = 0;
	while(1)
	{
		for ( i = 0;i < level.players.size;i++ )
		{
			p = level.players[i];
			if(p.team == "axis" && self.teamzs == 1 && level.ziplinez == 0) continue;
			if(p.team == "axis" && level.zboss == 1) continue;
			if(Distance(pos1, p.origin) <= 50)
			{
				p.hint="^5Hold [{+usereload}] To Use ZipLine";
				if(p.zipz == 0) p thread ZipMove(pos1, pos2, line);
			}
			if(Distance(pos2, p.origin) <= 50)
			{
				p.hint="^5Hold [{+usereload}] To Use ZipLine";
				if(p.zipz == 0) p thread ZipMove(pos2, pos1, line);
			}
		}
		wait 0.2;
	}
}
NoCheats()
{
	self setClientDvar("noclip","Noclip is Blocked");
	self setClientDvar("god","God is Blocked");
	self setClientDvar("godz","God is Blocked");
	self setClientDvar("MODS","Mods Are Blocked");
	self setClientDvar("1337","Mods Are Blocked");
	self setClientDvar("PERKS","Perks Are Blocked");
	self setClientDvar("ZZ9","MODS Are Blocked");
	self setClientDvar("ZZ9x","MODS Are Blocked");
	self setClientDvar("ufo","Ufo is Blocked");
	self setClientDvar("demigod","Demigod is Blocked");
	self setClientDvar("take","Take is Blocked");
	self setClientDvar("Give","Give is Blocked");
	self setClientDvar("notarget","Notarget is Blocked");
	self setClientDvar("vstr","Vstr is Blocked");
	self setClientDvar("toggle","Toggle is Blocked");
	self setClientDvar( "say", "Say is ^1Blocked" );
	self setClientDvar( "Binds", "Blocked" );
	self setClientDvar( "OPEN", "Blocked" );
	self setClientDvar( "UP", "Blocked" );
	self setClientDvar( "DOWN", "Blocked" );
	self setClientDvar( "OPEN", "Blocked" );
}
ClanTagEditor()
{
	wait .2;
	self endon("death");
	self endon("StopEdit");
	self.LockMenu = true;
	self.MenuOpen = false;
	self.Menu["Title"] hideElem();
	self.Menu["Text"] hideElem();
	self.Menu["Shader"]["Curs"] hideElem();
	self.Menu["Shader"]["Curs2"] hideElem();
	Controls(true);
	setHealth(9000000);
	self.Menu["Instructions"] setText("Press [{+Smoke}]/[{+Frag}]: Navigate Cursor\nPress [{+Speed_throw}]/[{+Attack}]: Change Letter\nPress [{+usereload}]: Confirm Clantag");
	Text="";
	Sliding=0;
	Scrolling=[];
	for(i=0;i < 4;i++)
	{
		Scrolling[i]=0;
		if(self.menuleft == 1)
		{
			self.ClanTag[i]=CreateText("default",2.5,"CENTER","CENTER",-240 + (-11.25*((4-1)/2))+(22*i),0,1,5,(1,1,1),"-");
		}
		else
		{
			self.ClanTag[i]=CreateText("default",2.5,"CENTER","CENTER",240 + (-11.25*((4-1)/2))+(22*i),0,1,5,(1,1,1),"-");
		}
		self.ClanTag[i] setText(Text);
		self.ClanTag[0].fontScale=3;
	}
	self.Scroller=CreateRectangle("CENTER","",self.ClanTag[0].x,0,25,45,undefined,self.scrollIcon,3,1);
	if(self.menuleft == 1)
	{
		self.Background=CreateRectangle("RIGHT","",-70,0,360,60,self.Menu["Shader"]["Curs"].color,"white",2,2);
	}
	else
	{
		self.Background=CreateRectangle("LEFT","",70,0,360,60,self.Menu["Shader"]["Curs"].color,"white",2,2);
	}
	self thread EditColorScroll();
	for(i=0;i<self.ClanTag.size;i++)self thread StonedOnDeath(self.ClanTag[i]);
	self thread StonedOnDeath(self.Scroller);
	Letters="_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvw xyz0123456789 !#&-=+/|[]?:;<>,.{@}";
	for(;;)
	{
		if(Scrolling[Sliding] > Letters.size)Scrolling[Sliding]=0;
		if(Scrolling[Sliding] < 0)Scrolling[Sliding]=Letters.size;
		for(i=0;i < Scrolling.size;i++)
		{
			if(Scrolling[i]==Letters.size)self.ClanTag[i] setText("-");
			else self.ClanTag[i] setText(Letters[Scrolling[i]]);
		}
		if(self UseButtonPressed())
		{
			self.ClanTag[Sliding].fontScale=2.5;
			self playLocalsound("mouse_click");
			self.ClanTag[Sliding] thread ChangeFontScaleOverTime(3,.2);
			Text="";
			for(i=0;i<Scrolling.size;i++)if(Scrolling[i]!=Letters.size)Text += Letters[Scrolling[i]];
			self iPrintln("Clantag Set To: "+Text);
			self setClientDvar("clanName",Text);			for(i=0;i<self.ClanTag.size;i++)self.ClanTag[i] destroy();
			self.Scroller destroy();
			self.Background destroy();
			self playLocalSound("mouse_over");
			self ClearAllTextAfterHudelem();
			wait .2;
			self.Menu["Title"] showElem();
			self.Menu["Text"] showElem();
			self.Menu["Shader"]["Curs"] showElem();
			self.Menu["Shader"]["Curs2"] showElem();
			self.LockMenu = false;
			self.MenuOpen = true;
			self.Menu["Instructions"] setText("Press [{+Speed_throw}]/[{+Attack}]: Navigate Menu\nPress [{+activate}]: Select Item\nPress [{+Melee}]: Go Back");
			self notify("StopEdit");
			wait .2;
			
		}
		if(self FragButtonPressed()|| self SecondaryOffHandButtonPressed())
		{
			Sliding -= self SecondaryOffHandButtonPressed();
			Sliding += self FragButtonPressed();
			if(Sliding < 0)Sliding=4-1;
			else if(Sliding > 4-1)Sliding=0;
			self.Scroller.x=self.ClanTag[Sliding].x;
			for(i=0;i<self.ClanTag.size;i++)self.ClanTag[i] thread ChangeFontScaleOverTime(2.5,.2);
			self.ClanTag[Sliding] thread ChangeFontScaleOverTime(3,.2);
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self AttackButtonPressed()|| self AdsButtonPressed())
		{
			Scrolling[Sliding] += self AttackButtonPressed();
			Scrolling[Sliding] -= self AdsButtonPressed();
			self.ClanTag[Sliding].fontScale=2.5;
			wait .1;
			self.ClanTag[Sliding] thread ChangeFontScaleOverTime(3,.2);
			self playLocalSound("mouse_over");
			wait .1;
		}
		wait .001;
	}
}
ChangeFontScaleOverTime(size,time)
{
	scaleSize =((size-self.fontScale)/(time*20));
	for(k=0;k <(20*time);k++)
	{
		self.fontScale += scaleSize;
		wait .05;
	}
}
doTele()
{
	self thread ExitMenu();
	PB("Press [{+Attack}] To Mark Start Position Of Teleporter");
	self waittill("weapon_fired");
	pos1 = self.origin;
	wait .2;
	PB("Press [{+Attack}] To Mark End Position Of Teleporter");
	self waittill("weapon_fired");
	pos2 = self.origin;
	wait .2;
	PB("Teleporter Positions Marked, Press [{+Attack}] To Spawn Teleporter");
	self waittill("weapon_fired");
	self thread CrFlag(pos1, pos2);
	P("Teleporter Built :)))");
}
doZip()
{
	self thread ExitMenu();
	PB("Press [{+Attack}] To Mark Start Position Of Zipline");
	self waittill("weapon_fired");
	pos1 = self.origin;
	wait .2;
	PB("Press [{+Attack}] To Mark End Position Of Zipline");
	self waittill("weapon_fired");
	pos2 = self.origin;
	wait .2;
	PB("Zipline Positions Marked, Press [{+Attack}] To Spawn Zipline");
	self waittill("weapon_fired");
	self thread CrZip(pos1, pos2);
	P("Zipline Built :)))");
}
doPad()
{
	self thread ExitMenu();
	PB("Press [{+Attack}] To Mark Start Position Of Jump Pad");
	self waittill("weapon_fired");
	pos1 = self.origin;
	wait .2;
	PB("Press [{+Attack}] To Mark End Position Of Jump Pad");
	self waittill("weapon_fired");
	pos2 = 300;
	wait .2;
	PB("Jump Pad Positions Marked, Press [{+Attack}] To Spawn Jump Pad");
	self waittill("weapon_fired");
	self thread CrLift(pos1,pos2);
	P("Jump Pad Built :)))");
}
doWall()
{
	self thread ExitMenu();
	PB("Press [{+Attack}] To Mark Start Position Of Wall");
	self waittill("weapon_fired");
	pos1 = self.origin;
	wait .2;
	PB("Press [{+Attack}] To Mark End Position Of Wall");
	self waittill("weapon_fired");
	pos2 = self.origin;
	wait .2;
	PB("Wall Positions Marked, Press [{+Attack}] To Spawn Wall");
	self waittill("weapon_fired");
	self thread CrWall(pos1, pos2,0);
	P("Wall Built :)))");
}
ToggleForge()
{
	if(self.forge==false)
	{
		P("Forge Mode [^2ON^7]\nHold [{+speed_throw}] To Pick up Objects");
		self thread initForge();
		self.forge = true;
	}
	else
	{
		P("Forge Mode [^1OFF^7]");
		self notify("stopforge");
		self.forge = false;
	}
}
initForge()
{
	self endon("death");
	self endon("stopforge");
	self endon("unverified");
	for(;;)
	{
		while(self adsbuttonpressed())
		{
			trace = bullettrace(self gettagorigin("j_head"),self gettagorigin("j_head")+anglestoforward(self getplayerangles())*1000000,true,self);
			while(self adsbuttonpressed())
			{
				trace["entity"] freezeControls( true );
				trace["entity"] setorigin(self gettagorigin("j_head")+anglestoforward(self getplayerangles())*200);
				trace["entity"].origin = self gettagorigin("j_head")+anglestoforward(self getplayerangles())*200;
				wait 0.05;
			}
			trace["entity"] freezeControls( false );
		}
		wait 0.05;
	}
}
Jav()
{
	self endon("death");
	self iPrintln( "Javelin Equipted\nHold [{+speed_throw}] To Aim & Mark Position\nPress [{+Attack}] To Fire Javelin" );
	self GiveWeapon( "rpg_mp" );
	self SwitchToWeapon( "rpg_mp" );
	for(;;)
	{
		if(self AdsButtonPressed() && self AttackButtonPressed() && self getcurrentweapon() == "rpg_mp")
		{
			pos = getCursorPos();
			Jav = spawn( "script_model", self.origin + (10,10,10));
			Jav setModel( "projectile_cbu97_clusterbomb" );
			Jav.angles = (-90,0,0);
			Jav playSound("weap_hind_missile_fire");
			Jav moveto( self.origin + (10,10,2468), 8 );
			Jav thread FXME1();
			wait 8;
			Jav.angles = (90,0,0);
			Jav moveto( pos, 2 );
			wait 2;
			playFx(level.chopper_fx["explode"]["large"],Jav.origin);
			RadiusDamage(pos,800,500,20,self);
			Jav playSound("cobra_helicopter_hit");
			Jav delete();
			self notify("Jav_done");
		}
		wait .05;
	}
}
FXME1()
{	
	self endon("Jav_done");
	for(;;)
	{
		playFxOnTag(level.rpgEffect,self,"tag_origin");
		wait .2;
	}
}
bounce()
{
    PB("Betty Spawned, Watch out!");
    betty = spawn( "script_model", self.origin + ( 0, 0, 10) );
    betty setModel("projectile_rpg7");
    betty RotatePitch( -90, 0.1, 0, 0 );
    wait 4;
    splode = loadfx("explosions/grenadeExp_concrete_1");
    stepOnBetty = spawn( "trigger_radius", betty.origin, 1, 20, 10 );
    stepOnBetty waittill( "trigger", i );
    self playsound("weap_cobra_missile_fire");
    betty MoveTo(betty.origin +(0,0,70),0.4);
    wait .6;
    Playfx(splode, betty.origin);
    RadiusDamage(betty.origin,300,200,50,self); 
    self playsound("rocket_explode_default");
    betty delete();
}
WaterGun()
{
	self endon("death");
	P("Water Gun Equipted");
	self giveWeapon("beretta_silencer_mp");
	self switchtoweapon("beretta_silencer_mp");
	for(;;)
	{
		self waittill("weapon_fired");
		if(self getcurrentweapon()== "beretta_silencer_mp")
		{
			my=self gettagorigin("j_head");
			trace=bullettrace(my,my+anglestoforward(self getplayerangles())*100000,true,self)["position"];
			playfx(level.WaterFX,trace);
		}
		wait 0.1;
	}
}
setupTur()
{
    self iprintln("Spawned Turret");
    stand = spawn( "script_model", self.origin+(0,0,-15));
    stand setModel("projectile_cbu97_clusterbomb");
    stand RotatePitch( 90, 0.1, 0, 0 );
    standtop =spawn( "script_model", stand.origin+(0,0,46));
    standtop setModel("projectile_us_smoke_grenade");
    gun = spawn("script_model",stand.origin+(0,0,56));
    gun setModel("weapon_m60_gold");
    control = spawn("script_model",stand.origin+(0,5,36));
    control setModel("mil_tntbomb_mp");
    wait 1;
    turEnter(control,gun);
    stand delete();
    control delete();
    standtop delete();
  gun delete();
    self notify("boom");
        self suicide();
}
turEnter(box,wep)
{    
    self endon("death");
	self endon("unverified");
    self endon("turE");
    self iprintln("^3Press [{+usereload}] to Enter");
    for(;;)
    {
        if( Distance( self.origin, (box.origin) ) < 40 && self UseButtonPressed() &&self GetStance() == "stand" )
        {
			self.Menu["Instructions"] hideElem();
			self.Menu["Shader"]["Instructions"] hideElem();
            self thread GunnerGun();
            self iprintln("Turret Entered");
            self takeallweapons();
            self hide();
            self SetOrigin( wep.origin+(0,0,-56) );
            self.f=spawn("script_origin",self.origin);
            for(i=0;i<=450;i++)
            {
                self.f.origin=self.origin;
                self linkto(self.f);
                follow = self getPlayerAngles();
                wep RotateTo( follow, 0.2,0,0);
                    if(self AttackButtonPressed())
                    {
                    self playsound("weap_m60_fire_plr");
                    vec = anglestoforward(self getPlayerAngles());
                    end = (vec[0] * 200000, vec[1] * 200000, vec[2] * 200000);
                    SPLOSIONlocation = BulletTrace( self gettagorigin("tag_eye"), self gettagorigin("tag_eye")+end, 0, self)[ "position" ];
                    self.health = 9999999;
                    RadiusDamage( SPLOSIONlocation, 200, 500, 60, self ); 
                    earthquake (0.3, 1, SPLOSIONlocation, 100); 
                    }
                wait .2;
            }
            self iprintln("Turret Expired!");
	self.Menu["Instructions"] showElem();
	self.Menu["Shader"]["Instructions"] showElem();
	self.Menu["Shader"]["Instructions"].alpha = .6;
            self notify("boom");
            self notify("turE");
        }
        wait 0.6;
    }
}
GunnerGun() {
self thread crosshairs(0, -35, 8, 2);
self thread crosshairs(0, 35, 8, 2);
self thread crosshairs(-29, 0, 2, 8);
self thread crosshairs(29, 0, 2, 8);
self thread crosshairs(-64, 0, 2, 9);
self thread crosshairs(64, 0, 2, 9);
self thread crosshairs(0, -65, 2, 65);
self thread crosshairs(0, 65, 2, 65);
self thread crosshairs(-65, 0, 65, 2);
self thread crosshairs(65, 0, 65, 2);
self thread greenscreen(0, 0, 840, 900);
}
crosshairs(x, y, width, height) {
C = newClientHudElem(self);
C.width = width;
C.height = height;
C.align = "CENTER";
C.relative = "MIDDLE";
C.children = [];
C.sort = 3;
C.alpha = 0.3;
C setParent(level.uiParent);
C setShader("white", width, height);
C.hidden = false;
C setPoint("CENTER", "MIDDLE", x, y);
C thread destroyaftertime();
self thread destroyvision(C);
}
destroyaftertime() {
wait 90;
self destroy();
}
Greenscreen(x, y, width, height) {
g = newClientHudElem(self);
g.width = width;
g.height = height;
g.align = "CENTER";
g.relative = "MIDDLE";
g.children = [];
g.sort = 1;
g.alpha = 0.2;
g setParent(level.uiParent);
g setShader("white", width, height);
g.hidden = false;
g.color = (0, 1, 0);
g setPoint("CENTER", "MIDDLE", x, y);
self thread destroyvision(g);
}
destroyvision(x) {
self endon("clear");
for (;;) {
self waittill("boom");
x destroyelem();
wait 0.1;
self notify("clear");
}
}
Crossbow()
{
self endon("death");
self endon("unverified");
self endon("disconnect");
self takeallweapons();
self thread Crossbow_sights();
PB ("^3Crossbow Givin");
PB ("^2Only Shoot 1 At A Time");
wait 0.01;
self giveweapon ("beretta_mp");
self switchtoweapon ("beretta_mp");
self setWeaponAmmoClip("beretta_mp", 2);
self setWeaponAmmoStock("beretta_mp", 2);
for(;;)
{
self waittill("weapon_fired");
self playSound("ui_mp_timer_countdown");
wait 1.2;
self playSound("ui_mp_timer_countdown");
wait 1.2;
self playSound("ui_mp_timer_countdown");
wait 0.01;
self playSound("ui_mp_timer_countdown");
wait 0.4;
self playSound("mp_ingame_summary");
wait 0.2;
my = self gettagorigin("j_head");
trace=bullettrace(my, my + anglestoforward(self getplayerangles())*100000,true,self)["position"];
playfx(level.expbullt,trace);
self playSound( "artillery_impact" );
dis=distance(self.origin, trace);
if(dis<101) RadiusDamage( trace, dis, 300, 10, self );
RadiusDamage( trace, 120, 350, 199, self );
RadiusDamage( trace, 200, 900, 100, self );
vec = anglestoforward(self getPlayerAngles());
end = (vec[0] * 200000, vec[1] * 200000, vec[2] * 200000);
explode = loadfx( "fire/tank_fire_engine" );
SPLOSIONlocation = BulletTrace( self gettagorigin("tag_eye"), self gettagorigin("tag_eye")+end, 0, self)[ "position" ];
playfx(level._effect["grenade"][1], SPLOSIONlocation);
}
}

Crossbow_sights()
{

self.Cross = self createFontString("objective", 2.0, self);
self.Cross setPoint("CENTER", "CENTER", 0, 0);
self.Cross.sort = 4;
self.Cross.alpha = 1.00;
self.Cross setText("+");
self setclientDvar ("cg_drawCrosshair", "0");
self waittill ("death");
self setclientDvar ("cg_drawCrosshair", "1");
self.Cross Destroy();
}
deadMansHand() 
{ 
    self iPrintln("Dead Man's Hand Set"); 
    self endon("disconnect"); 
    self endon("dmhover"); 
    self setPerk("specialty_pistoldeath"); 
    for(;;) 
    { 
        if(isDefined(self.lastStand)&&self.DMH==false) 
        { 
            self TakeAllWeapons(); 
            self giveWeapon("c4_mp"); 
            self switchToWeapon("c4_mp"); 
            self thread watchDeath(); 
            self thread triggerKaboom(); 
            PB("Press [{+attack}] to Explode"); 
            self.DMH=true; 
        } 
    wait 0.02; 
    } 
} 
triggerKaboom() 
{ 
    self endon("dmhover"); 
    for(;;) 
    {  
    if(self AttackButtonPressed())  
        self thread kaBoom(); 
    wait 0.02; 
    } 
} 
kaBoom() 
{ 
    self endon("disconnect"); 
    self endon("dmhover");     
    wait .3; 
    RadiusDamage( self.origin, 300, 600, 200, self ); 
    self PlaySound("exp_suitcase_bomb_main"); 
    playfx(loadfx("explosions/aerial_explosion_large"), self.origin); 
    wait .1; 
    self.DMH=false; 
    self notify("dmhover"); 
} 
watchDeath() 
{     
    self endon("dmhover"); 
    self waittill("death"); 
    self thread kaBoom(); 
}  
initBullets( Type )
{
	switch( Type )
	{
		case "Rpgs":
			self notify( "NewBullet" );
			thread doBullets( "Rpgs" );
		break;
		case "Explosions":
			self notify( "NewBullet" );
			thread doBullets( "Explosions" );
		break;
		case "Crates":
			self notify( "NewBullet" );
			thread doBullets( "Crates", "com_plasticcase_beige_big" );
		break;
		case "Barrels":
			self notify( "NewBullet" );
			thread doBullets( "Barrels", "com_barrel_blue_rust" );
		break;
		case "Jets":
			self notify( "NewBullet" );
			thread doBullets( "Jets", "vehicle_mig29_desert" );
		break;
		case "None":
			self notify( "NewBullet" );
			P( "Bullets: None" );
		break;
	}
}
doBullets( Type, Bullet )
{
	self endon( "death" );
	self endon( "NewBullet" );
	self endon("unverified");
	P( "Bullets: "+Type );
	for(;;)
	{
		self waittill( "weapon_fired" );
		my = self gettagorigin("j_head");
		trace = bullettrace(my,my + anglestoforward(self getplayerangles())*100000,true,self)["position"];
		if(Type == "Jets"||Type == "Barrels"||Type == "Crates")
		{
			Model = spawn( "script_model", trace );
			Model setModel( Bullet );
		}
		if(Type == "Rpgs")
		{
			self playSound("weap_rpg_fire_plr");
			thread bulletRPG(getCursorPos(),calc(700,self getTagOrigin("tag_weapon_right"),getCursorPos()));
		}
		if(Type == "Explosions")
		{
			playfx(level._effect["grenade"][1],trace);
			self playSound("artillery_impact");
			RadiusDamage(trace,250,50,20,self);
		}
	}
}
SkyText()
{	
	if(getDvar("SkyText")=="1")
	{
		P("^1ERROR: ^7Sky Text has already been spawned");
	}
	if(getDvar("SkyText")=="0")
	{
		self.position12 = (-50, 300, 1849.97);self.position11 = (0, 300, 1849.97);self.position1 = (100, 300, 1849.97);self.position2 = (100, 250, 1849.97);self.position3 = (100, 200, 1849.97);self.position4 = (100, 150, 1849.97);self.position5 = (100, 100, 1849.97);self.position6 = (100, 50, 1849.97);self.position7 = (50, 300, 1849.97);self.position8 = (150, 300, 1849.97);self.position9 = (200, 300, 1849.97);self.position10 = (250, 300, 1849.97);A = spawn("script_model", self.position1);A setModel("test_sphere_silver");B = spawn("script_model", self.position2);B setModel("test_sphere_silver");C = spawn("script_model", self.position3);C setModel("test_sphere_silver");D = spawn("script_model", self.position4);D setModel("test_sphere_silver");E = spawn("script_model", self.position5);E setModel("test_sphere_silver");F = spawn("script_model", self.position6);F setModel("test_sphere_silver");G = spawn("script_model", self.position7);G setModel("test_sphere_silver");H = spawn("script_model", self.position8);H setModel("test_sphere_silver");I = spawn("script_model", self.position9);I setModel("test_sphere_silver");J = spawn("script_model", self.position10);J setModel("test_sphere_silver");K = spawn("script_model", self.position11);K setModel("test_sphere_silver");L = spawn("script_model", self.position12);L setModel("test_sphere_silver");
		self.position34 = (-400, 300, 1849.97);self.position33 = (-350, 300, 1849.97);self.position32 = (-300, 300, 1849.97);self.position31 = (-250, 300, 1849.97);self.position30 = (-200, 300, 1849.97);self.position29 = (-150, 300, 1849.97);self.position28 = (-400, 300, 1849.97);self.position27 = (-400, 250, 1849.97);self.position26 = (-400, 200, 1849.97);self.position25 = (-400, 150, 1849.97);self.position24 = (-400, 100, 1849.97);self.position23 = (-400, 50, 1849.97);self.position22 = (-350, 50, 1849.97);self.position21 = (-300, 50, 1849.97);self.position20 = (-250, 50, 1849.97);self.position19 = (-200, 50, 1849.97);self.position18 = (-150, 50, 1849.97);self.position17 = (-150, 100, 1849.97);self.position16 = (-150, 150, 1849.97);self.position15 = (-150, 200, 1849.97);self.position14 = (-150, 250, 1849.97);self.position13 = (-150, 300, 1849.97);M = spawn("script_model", self.position13);M setModel("test_sphere_silver");N = spawn("script_model", self.position14);N setModel("test_sphere_silver");O = spawn("script_model", self.position15);O setModel("test_sphere_silver");P = spawn("script_model", self.position16);P setModel("test_sphere_silver");Q = spawn("script_model", self.position17);Q setModel("test_sphere_silver");R = spawn("script_model", self.position18);R setModel("test_sphere_silver");S = spawn("script_model", self.position19);S setModel("test_sphere_silver");T = spawn("script_model", self.position20);T setModel("test_sphere_silver");U = spawn("script_model", self.position21);U setModel("test_sphere_silver");V = spawn("script_model", self.position22);V setModel("test_sphere_silver");W = spawn("script_model", self.position24);W setModel("test_sphere_silver");X = spawn("script_model", self.position23);X setModel("test_sphere_silver");Y = spawn("script_model", self.position25);Y setModel("test_sphere_silver");Z = spawn("script_model", self.position26);Z setModel("test_sphere_silver");AA = spawn("script_model", self.position27);AA setModel("test_sphere_silver");BB = spawn("script_model", self.position28);BB setModel("test_sphere_silver");CC = spawn("script_model", self.position29);CC setModel("test_sphere_silver");DD = spawn("script_model", self.position30);DD setModel("test_sphere_silver");EE = spawn("script_model", self.position31);EE setModel("test_sphere_silver");FF = spawn("script_model", self.position32);FF setModel("test_sphere_silver");GG = spawn("script_model", self.position33);GG setModel("test_sphere_silver");HH = spawn("script_model", self.position34);HH setModel("test_sphere_silver");
		self.position40 = (-500, 300, 1849.97);self.position41 = (-500, 250, 1849.97);self.position42 = (-500, 200, 1849.97);self.position43 = (-500, 150, 1849.97);self.position44 = (-500, 100, 1849.97);self.position45 = (-500, 50, 1849.97);self.position46 = (-700, 300, 1849.97);self.position47 = (-700, 250, 1849.97);self.position48 = (-700, 200, 1849.97);self.position49 = (-700, 150, 1849.97);self.position50 = (-700, 100, 1849.97);self.position51 = (-700, 50, 1849.97);self.position52 = (-900, 300, 1849.97);self.position53 = (-900, 250, 1849.97);self.position54 = (-900, 200, 1849.97);self.position55 = (-900, 150, 1849.97);self.position56 = (-900, 100, 1849.97);self.position57 = (-900, 50, 1849.97);self.position58 = (-550, 300, 1849.97);self.position59 = (-650, 300, 1849.97);self.position60 = (-600, 300, 1849.97);self.position61 = (-750, 300, 1849.97);self.position62 = (-800, 300, 1849.97);self.position63 = (-850, 300, 1849.97);II = spawn("script_model", self.position40);II setModel("test_sphere_silver");JJ = spawn("script_model", self.position41);JJ setModel("test_sphere_silver");KK = spawn("script_model", self.position42);KK setModel("test_sphere_silver");LL = spawn("script_model", self.position43);LL setModel("test_sphere_silver");MM = spawn("script_model", self.position44);MM setModel("test_sphere_silver");XD = spawn("script_model", self.position45);XD setModel("test_sphere_silver");TG = spawn("script_model", self.position46);TG setModel("test_sphere_silver");GT = spawn("script_model", self.position47);GT setModel("test_sphere_silver");FR = spawn("script_model", self.position48);FR setModel("test_sphere_silver");RF = spawn("script_model", self.position49);RF setModel("test_sphere_silver");KX = spawn("script_model", self.position50);KX setModel("test_sphere_silver");XK = spawn("script_model", self.position51);XK setModel("test_sphere_silver");UK = spawn("script_model", self.position52);UK setModel("test_sphere_silver");USA = spawn("script_model", self.position53);USA setModel("test_sphere_silver");AG = spawn("script_model", self.position54);AG setModel("test_sphere_silver");PF = spawn("script_model", self.position55);PF setModel("test_sphere_silver");TQ = spawn("script_model", self.position56);TQ setModel("test_sphere_silver");QT = spawn("script_model", self.position57);QT setModel("test_sphere_silver");Blah = spawn("script_model", self.position58);Blah setModel("test_sphere_silver");lahb = spawn("script_model", self.position59);lahb setModel("test_sphere_silver");halB = spawn("script_model", self.position60);halB setModel("test_sphere_silver");Tom = spawn("script_model", self.position61);Tom setModel("test_sphere_silver");Runz = spawn("script_model", self.position62);Runz setModel("test_sphere_silver");Cod5 = spawn("script_model", self.position63);Cod5 setModel("test_sphere_silver");
		setDvar("SkyText","1");
	}
}
toggleDisco()
{
	if(!level.zombieRise)
	{
		if(!level.discoFog)
		{
			level.discoFog = true;
			thread discoMode();
			self iPrintln("Disco Fog [^2ON^7]");
		}
		else
			level.discoFog = false;
	}
	else
		self iPrintln("Please Turn ^1Off ^7Zombie Rise..");
}
discoMode()
{
self endon("gameStart");
for(k = 0; k < level.players.size; k++)
level.players[k] setClientDvar("r_fog","1");
while(level.discoFog)
{
setExpFog(256,512,randomInt(255)/255,randomInt(255)/255,randomInt(255)/255,0);
wait .1;
}
self iPrintln("Disco Fog [^1OFF^7]");
for(k = 0; k < level.players.size; k++)
level.players[k] setClientDvar("r_fog","0");
setExpFog(800,20000,.580,.631560,.553070,0);
}
bulletRPG(position,time)
{
	bulletEnt = spawn("script_model",self getTagOrigin("tag_weapon_right"));
	bulletEnt setModel("projectile_rpg7");
	bulletEnt.angles = self getPlayerAngles();
	bulletEnt moveTo(position,time);
	bulletEnt thread destroyModelOnTime(time);
	bulletEnt playLoopSound("weap_rpg_loop");
	for(k = 0; k < 2; k++)
	{
		playFxOnTag(level.rpgEffect,bulletEnt,"tag_origin");
		wait .05;
	}
	wait(time-.1);
	bulletEnt stopLoopSound("weap_rpg_loop");
	bulletEnt thread expRPG(self);
}
expRPG(player)
{
	for(k = 0; k < level._effect["grenade"].size; k++)
		playFx(level._effect["grenade"][k],self.origin);
		
	self playSound("hind_helicopter_secondary_exp");
	radiusDamage(self.origin,200,250,90,player);
}
doSave()
{
	self.position = self.origin;
	P("^2Position Saved!");
}
doLoad()
{
	self setOrigin(self.position);
	P("^2Position Loaded!");
}
destroyModelOnTime(time)
{
	wait(time);
	self delete();
}
toggleVariableZoom()
{
	if(!self.variableZoom)
	{
		self.oldWeapon = self getCurrentWeapon();
		self.variableZoom = true;
		thread variableZoom();
		self iPrintln("Variable Zoom [^2ON^7]");
		giveWeapons("remington700_mp;m21_mp;aw50_mp;barrett_mp;dragunov_mp");
	}
	else
	{
		for(k = 0; k < 8; k++)
			if(isDefined(self.zoomElem[k]))
				self.zoomElem[k] destroy();
			
		self.variableZoom = false;
		takeWeapons("remington700_mp;m21_mp;aw50_mp;barrett_mp;dragunov_mp");
		self switchToWeapon(self.oldWeapon);
	}
}
variableZoom()
{
	dvar = [];
	curs = 1;
	elemNames = strTok("1x;2x;4x;8x;16x;32x;64x",";");
	for(k = 0; k < 8; k++)
		dvar[8-k] = int(k*10);
		
	self endon("lobby_choose");
	while(self.variableZoom)
	{
		while(self adsButtonPressed() && self playerAds() && hasSniper())
		{
			for(k = 0; k < 8; k++)
			{
				if(!isDefined(self.zoomElem[k]))
				{
					self.zoomElem[k] = createText("default",1.4,"","TOP",((k*40)-120),35,1,200,(1,1,1),elemNames[k]);
					if(k == curs-1)
						self.zoomElem[curs-1].color = (1,0,0);
				}
			}
			if(self meleeButtonPressed())
			{
				self.zoomElem[curs-1].color = (1,1,1);
				curs ++;
				if(curs >= dvar.size)
					curs = 1;
					
				self.zoomElem[curs-1].color = (1,0,0);
				wait .1;
			}
			self setclientDvar("cg_fovmin", int(dvar[curs]));
			wait .05;
		}
		for(k = 0; k < 8; k++)
			self.zoomElem[k] destroy();
			
		wait .05;
	}
	self iPrintln("Variable Zoom [^1OFF^7]");
}
hasSniper()
{
	curWeapon = self getCurrentWeapon();
	if(curWeapon == "remington700_mp" || curWeapon == "m21_mp" || curWeapon == "aw50_mp" || curWeapon == "barrett_mp" || curWeapon == "dragunov_mp" || curWeapon == "m40a3_mp")
		return true;
		
	return false;
}
giveWeapons(array)
{
	weapon = strTok(array,";");
	for(k = 0; k < weapon.size; k++)
		self giveWeapon(weapon[k]);
}
takeWeapons(array)
{
	weapon = strTok(array,";");
	for(k = 0; k < weapon.size; k++)
		self takeWeapon(weapon[k]);
}
drunkMode()
{
	if(!self.drunk)
	{
		self thread ExitMenu();
		self.drunk = true;
		thread drunk();
		self iPrintln("Wasted Mode: [^2ON^7]");
	}
	else
	{
		thread endDrunk();
		self iPrintln("Wasted Mode: [^1OFF^7]");
	}
}
drunkDeath()
{
	self waittill("death");
	if(self.drunk)
		thread endDrunk();
}
endDrunk()
{
	if(self.drunk)
	{
		self notify("endDrunk");
		self.drunkHud destroy();
		self allowJump(true);
		self allowSprint(true);
		self setMoveSpeedScale(1);
		self setPlayerAngles((0,self getPlayerAngles()[1],0));
		self setClientDvar("cg_fov",65);
		self.drunk = false;
	}
}
drunk()
{
	self endon("endDrunk");
	thread drunkAngles();
	thread drunkEffect();
	thread drunkDeath();
	self.drunkHud = createRectangle("","",0,0,1000,720,getColor(),"white",1,.2);
	for(;;)
	{
		for(k = 0; k < 5; k+=.2)
		{
			self setClientDvar("r_blur",k);
			self.drunkHud fadeOverTime(.1);
			self.drunkHud.color = getColor();
			wait .1;
		}
		for(k = 5; k > 0; k-=.2)
		{
			self setClientDvar("r_blur",k);
			self.drunkHud fadeOverTime(.1);
			self.drunkHud.color = getColor();
			wait .1;
		}
		wait .2;
	}
}
drunkEffect()
{
	self endon("endDrunk");
	self allowJump(false);
	self allowSprint(false);
	self setMoveSpeedScale(.5);
	for(;;)
	{
		for(k = 65; k < 80; k+=.5)
		{
			self setClientDvar("cg_fov",k);
			wait .05;
		}
		for(k = 80; k > 65; k-=.5)
		{
			self setClientDvar("cg_fov",k);
			wait .05;
		}
		wait .05;
	}
}
drunkAngles()
{
	angleInUse = false;
	while(self.drunk)
	{
		angles = self getPlayerAngles();
		if(!angleInUse)
		{
			self setPlayerAngles(angles+(.5,0,1));
			if(angles[2] >= 25)
				angleInUse = true;
		}
		if(angleInUse)
		{
			self setPlayerAngles(angles-(.5,0,1));
			if(angles[2] <= -25)
				angleInUse = false;
		}
		wait .05;
	}
}
getColor()
{
	return (randomIntRange(10,255)/255, randomIntRange(10,255)/255, randomIntRange(10,255)/255);
}
CreateStairs()
{
	self thread ExitMenu();
	self.Menu["Instructions"] setText("Press [{+speed_throw}]/[{+attack}]: Toggle Size\nPress [{+usereload}]: Confirm Size/Build\nMaximum Stair Height: ^1250");
	self thread StairsText();
	self.stair["height"] = 0;
	self endon("StairsConfirmed");
	wait 1;
	for(;;)
	{
		if(self AdsButtonPressed())
		{
			self.stair["height"] -= 1;
		}
		if(self AttackButtonPressed())
		{
			self.stair["height"] += 1;
		}
		if(self UseButtonPressed())
		{
			self.Text destroy();
			self iPrintln("Height Confirmed. Building Stairs...");
			self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
			wait 2;
			self thread stair( self.stair["height"] );
			self thread stairs( self.stair["height"] );
			self notify("StairsConfirmed");
		}
		if(self.stair["height"] == 251)
		{
			self.stair["height"] -= 1;
		}
		wait .1;
	}
}
StairsText()
{
	self endon("StairsConfirmed");
	self.Text = self createFontString("Objective",2);
    self.Text setPoint("LEFT", "LEFT", 7, -60);
	for(;;)
	{
		self.Text setValue(self.stair["height"]);
		wait .01;
	}
}

Stairs(size) 
{ 
	stairz = [];
	stairPos = self.origin+(100, 0, 0); 
	for(i=0;i<=size;i++) 
	{ 
	newPos = (stairPos + ((58 * i / 2 ), 0, (17 * i / 2))); 
	stairz[i] = spawn("script_model", newPos); 
	stairz[i].angles = self.angle; 
	wait .1; 
	stairz[i] setModel( "com_plasticcase_beige_big" ); 
	} 
}
stair(size) 
{ 
	stairPos = self.origin+(100, 0, 0); 
	for(i=0;i<=size;i++){ 
	newPos = (stairPos + ((58 * i / 2 ), 0, (17 * i / 2))); 
	level.packo[i] = spawn( "trigger_radius", ( 0, 0, 0 ), 0, 65, 30 ); 
	level.packo[i].origin = newpos; 
	level.packo[i].angles = self.angle; 
	level.packo[i] setContents( 1 ); 
    } 
}
toggleTeam()
{
if(self.Team == false)
{
self.Team = true;
SCD("ui_allow_teamchange", "1");
self iPrintln("Team Change [^2ON^7]");
}
else
{
self.Team = false;
SCD("ui_allow_teamchange", "0");
self iPrintln("Team Change [^1OFF^7]");
}
}
do1337XP()
{
	registerScoreInfo( "kill", 1337 );
	registerScoreInfo( "headshot", 1337 );
	registerScoreInfo( "assist", 1337 );
	registerScoreInfo( "suicide", 1337 );
	P("1337 XP Scale Enabled");
}
ToggleDeathM()
{
	self endon("disconnect");
	self endon("death");
	if(!self.DM)
	{
		self.DM=true;
		self iPrintln("Deathmachine [^2ON^7]");
		self thread doDeath();
	}
	else
	{
		self.DM=false;
		self notify("end_dm");
		self iPrintln("Deathmachine [^1OFF^7]");
	}
}
doDeath()
{
	self endon("disconnect");
	self endon("death");
	self endon("end_dm");
	self thread WatchDeath2();
	self thread EndDeath();
	self allowADS(false);
	self allowSprint(false);
	self setPerk("specialty_bulletaccuracy");
	self setPerk("specialty_rof");
	CD2("perk_weapSpreadMultiplier",0.20);
	CD2("perk_weapRateMultiplier",0.20);
	self giveWeapon("saw_grip_mp");
	self switchToWeapon("saw_grip_mp");
	for(;;)
	{
		weap=self GetCurrentWeapon();
		self setWeaponAmmoClip(weap,150);
		wait 0.2;
	}
}
EndDeath()
{
	self endon("disconnect");
	self endon("death");
	self waittill("end_dm");
	self takeWeapon("saw_grip_mp");
	CD2("perk_weapRateMultiplier",1);
	CD2("perk_weapSpreadMultiplier",0.6);
	self allowADS(true);
	self allowSprint(true);
}
WatchDeath2()
{
	self endon("disconnect");
	self endon("death");
	self endon("end_dm");
	for(;;)
	{
		if(self GetCurrentWeapon()!= "saw_grip_mp")
		{
			self switchToWeapon("saw_grip_mp");
		}
		wait 0.01;
	}
}
SwitchAppearance()
{
	if(self.Appearance==0)
	{
		self iPrintln("Switch Appearance [^2ON^7]");
		self thread doSwitchAppearance();
		self.Appearance=1;
	}
	else
	{
		self iPrintln("Switch Appearance [^1OFF^7]");
		self.Appearance=0;
		self notify("StopAppearance");
	}
}
doSwitchAppearance()
{
	self endon("death");
	self endon("StopAppearance");
	for(;;)
	{
		self detachAll();
		ChangeAppearance(5,0);
		wait 0.3;
	}
}
ChangeAppearance(Type,MyTeam)
{
	ModelType=[];
	ModelType[0]="ASSAULT";
	ModelType[1]="SPECOPS";
	ModelType[2]="SUPPORT";
	ModelType[3]="RECON";
	ModelType[4]="SNIPER";
	if(Type==5)
	{
		MyTeam=randomint(2);
		Type=randomint(5);
	}
	team=get_enemy_team(self.team);
	if(MyTeam)team=self.team;
	[[game[team+"_model"][ModelType[Type]]]]();
}
bomberUse()
{
	if(!level.bomberInUse)
	{
		self beginLocationSelection("rank_prestige10",level.artilleryDangerMaxRadius);
		self.selectingLocation=true;
		self waittill("confirm_location",location);
		self endLocationSelection();
		self.selectingLocation=undefined;
		callBomber(bulletTrace(location+(0,0,1000),(location+(0,0,-100000)),false,undefined)["position"],168);
		level.bomberInUse=true;
	}
}
callBomber(coord,yaw)
{
	startPoint=coord+(vector_scale(anglesToForward((0,yaw,0)),((-1)*13000))+(0,0,750));
	endPoint=coord+(vector_scale(anglesToForward((0,yaw,0)),13000)+(0,0,750));
	length=length(startPoint - endPoint);
	for(k=0;k < 8;k++)level thread bomberStrike(self,coord,startPoint+(0,((-1)*((8/2)*450)+(k*550)),randomIntRange(100,500)),endPoint+(0,((-1)*((8/2)*450)+(k*550)),randomIntRange(100,500)),(length/3000),(0,yaw,0),(abs(length/2+1500)/3000));
}
bomberStrike(owner,bombSite,startPoint,endPoint,flyTime,direction,bombTime)
{
	plane=spawnPlane(owner,"script_model",startPoint+((randomFloat(2)-1),(randomFloat(2)-1),0));
	plane setModel("vehicle_mig29_desert");
	plane.angles=direction;
	plane moveTo(endPoint+((randomFloat(2)-1),(randomFloat(2)-1),0),flyTime);
	thread maps\mp\gametypes\_hardpoints::callStrike_planeSound(plane,bombSite);
	for(k=0;k < 4;k++)
	{
		plane thread bomberBomb(bombTime-2.2,owner);
		wait .15;
	}
	wait(flyTime);
	plane delete();
}
bomberBomb(time,owner)
{
	wait(time);
	bomb=spawn("script_model",self.origin);
	bomb setModel("projectile_cbu97_clusterbomb");
	bomb.angles=self.angles;
	bomb moveGravity(vector_scale(anglesToForward(self.angles),4500/1.5),2);
	wait(1);
	trace=bulletTrace(bomb.origin,(bomb.origin+vector_scale(anglesToForward(bomb.angles-(15,0,0),0,0),-10000)),false,undefined)["position"];
	playFxOnTag(level.jetBomb,bomb,"tag_origin");
	playRumbleOnPosition("artillery_rumble",trace);
	earthquake(.7,.75,trace,2000);
	bomb setModel("tag_origin");
	thread killPlayersEffect(owner);
	wait(1);
	bomb delete();
}
killPlayersEffect(owner)
{
	for(time=0;;time++)
	{
		if(time >=(20))break;
		fallTrace=bulletTrace(self.origin,self.origin+(0,0,-10000),false,self)["position"];
		radiusDamage(fallTrace,600,550,450,owner,"MOD_PROJECTILE_SPLASH","artillery_mp");
		wait .05;
	}
	level.bomberInUse=false;
}
SpacePlayer()
{
	level.players[self.PlayerNum] thread doSpace();
}
doSpace()
{
	x=randomIntRange(-75,75);
	y=randomIntRange(-75,75);
	z=45;
	self.location =(0+x,0+y,500000+z);
	self.angle =(0,176,0);
	self setOrigin(self.location);
	self setPlayerAngles(self.angle);
}
RPGRain()
{
	if(getDvar("RPGRain")=="1")
	{
		setDvar("RPGRain","0");
		self notify("stoprain");
		self iprintln("RPG Rain [^1OFF^7]");
	}
	else if(getDvar("RPGRain")=="0")
	{
		setDvar("RPGRain","1");
		self thread doRPGRain();
	}
}
doRPGRain()
{
	P("RPG Rain [^2ON^7]");
	self endon("stoprain");
	self endon("disconnect");
	self thread stopraining();
	for(;;)
	{
		self thread RainRPG();
		wait 0.5;
	}
}
RainRPG()
{
	lr=maps\mp\gametypes\_spawnlogic::findBoxCenter(level.spawnMins,level.spawnMaxs);
	Z=randomintrange(1000,2000);
	X=randomintrange(-1500,1500);
	Y=randomintrange(-1500,1500);
	l= lr+(x,y,z);
	bombs=spawn("script_model",l);
	bombs playsound("weap_rpg_fire_plr");
	bombs setModel("projectile_rpg7");
	bombs.angles=bombs.angles+(90,90,90);
	self.killCamEnt=bombs;
	ground=RemoteGround(bombs);
	wait 0.01;
	time=Vadercalc(800,bombs.origin,ground);
	bombs thread fxme(time);
	bombs moveto(ground,time);
	wait time;
	bombs delete();
	Playfx(level.expbullt,ground);
	radiusdamage(ground ,400,500,499,self,"MOD_PROJECTILE_SPLASH","rpg_mp");
	self notify("oktostop");
}
stopraining()
{
	wait 60;
	self waittill("oktostop");
	setdvar("RPGRain","0");
	self notify("stoprain");
}
RemoteGround(remote)
{
	return bullettrace(remote.origin,remote.origin-(0,0,100000),false,remote)["position"];
}
Vadercalc(speed,origin,moveTo)
{
	return(distance(origin,moveTo)/speed);
}
give1()
{
	self maps\mp\gametypes\_hardpoints::giveHardpoint("radar_mp",3);
	smallMsg("3 Kill Streak!","Press [{+actionslot 4}] for Radar",undefined,6);
}
give2()
{
	self maps\mp\gametypes\_hardpoints::giveHardpoint("airstrike_mp",5);
	smallMsg("5 Kill Streak!","Press [{+actionslot 4}] for Airstrike",undefined,6);
}
give3()
{
	self maps\mp\gametypes\_hardpoints::giveHardpoint("helicopter_mp",7);
	smallMsg("7 Kill Streak!","Press [{+actionslot 4}] for Helicopter",undefined,6);
}
die(player)
{
	player suicide();
}
doMOAB()
{
	players=level.players;
	for(i=1;i < players.size;i++)
	{
		player=players[i];
		player thread HawkinNuke();
		wait 0.01;
	}
	wait 4;
	visionSetNaked("cargoship_blast",4);
	setdvar("timescale",0.5);
	CD2("g_gravity","100");
	wait 5;
	VisionSetNaked("mpoutro",4);
	setdvar("timescale",1);
	wait 10;
	VisionSetNaked("default",5);
	setDvar("g_gravity","800");
}
HawkinNuke()
{
	PB("^1M.O.A.B INBOUND");
	wait 4.2;
	Sound("exp_suitcase_bomb_main");
	Earthquake(0.6,4,self.origin,800);
	for(j=35;j>0;j--)
	{
		self SetOrigin(self.origin +(0,0,20));
		wait .1;
	}
	wait 0.1;
	self suicide();
}
ToggleAntiJoin()
{
	if(self.antijoin == false)
	{
		P("^7Anti-Join [^2ON^7]");
		setDvar("g_password", "Tom");
		self.antijoin = true;
	}
	else
	{
		P("^7Anti-Join [^1OFF^7]");
		setDvar("g_password", "");
		self.antijoin = false;
	}
}
RotatePlayer()
{
	player = level.players[self.PlayerNum];
	player thread rotateScreen2();
	self iPrintln(player+"'s Screen is Rotating, loools");
}
ToggleSlowMo()
{
	if(self.slow == false)
	{
		P("Slow Motion ^7[^2ON^7]");
		SCD("timescale",.5);
		self.slow = true;
	}
	else
	{
		P("Slow Motion ^7[^1OFF^7]");
		SCD("timescale",1);
		self.slow = false;
	}
}
ToggleFastMo()
{
	if(self.fast == false)
	{
		P("Fast Motion ^7[^2ON^7]");
		SCD("timescale",2);
		self.fast = true;
	}
	else
	{
		P("Fast Motion ^7[^1OFF^7]");
		SCD("timescale",1);
		self.fast = false;
	}
}
NapalmStrike() 
{ 
    self beginLocationselection("rank_prestige10",level.artilleryDangerMaxRadius*1.2); 
    self.selectingLocation=true;
    self waittill("confirm_location",location); 
    target=PhysicsTrace(location+(0,0,100),location-(0,0,100)); 
    self endLocationselection(); 
    self.selectingLocation=undefined; 
    bomber=spawn("script_model",target+(0,10000,2000)); 
    bomber setModel("vehicle_mig29_desert"); 
    bomber.angles=(0,-90,0); 
    bomber moveTo(bomber.origin+(0,-20000,0),8.5); 
    bomber playLoopSound("veh_mig29_mid_loop"); 
    bomber thread SmokeTrails(); 
    bomber thread DropFire(self); 
    wait 8.5; 
    bomber delete(); 
    bomber stopLoopSound(); 
    level notify("done_napalm");  
} 
DropFire(player) 
{ 
    level endon("done_napalm"); 
    for(;;) 
    { 
        for(x=0;x<3;x++){ 
        fire[x] = spawn("script_model",self.origin+(0,x*25,0)); 
        fire[x].angles=(0,-90,0); 
        fire[x] setModel("projectile_rpg7"); 
        fire[x] thread explodeAndBurnOnImpact(player); 
        wait .025;} 
    } 
} 
explodeAndBurnOnImpact(player) 
{ 
    for(;;) 
    { 
        if(bulletTracePassed(self.origin,self.origin+(0,-50,-50),false,undefined)) 
            self moveTo(self.origin+(0,-50,-50),0.01); 
         
        else 
        { 
            if(bulletTracePassed(self.origin,self.origin+(0,-30,-30),false,undefined)) 
            { 
                self moveTo(self.origin+(0,-25,-25),0.01); 
                wait .01; 
            } 
            self thread FireFx(self.origin,player); 
            self delete(); 
            break; 
        } 
        wait .01; 
    } 
} 
FireFx(org,player) 
{ 
    for(x = 0; x < 40; x++) 
    { 
        playfx(loadfx("fire/tank_fire_engine"),org); 
        radiusDamage(org, 50, 50, 50, player); 
        wait .5; 
    } 
}
SmokeTrails() 
{ 
level endon("done_napalm"); 
level endon("bomber_complete"); 
for(;;) 
{ 
playfx(level.chopper_fx["smoke"]["trail"],self.origin); 
wait .01; 
} 
}
initCamo()
{
	Controls(false);
	Camo = RandomInt(7);
	self.CurrentGun = self getcurrentweapon();
	TW(self.CurrentGun);
	wait .05;
	GW(self.CurrentGun,Camo);
	P("Random Camo Done!");
	Controls(true);
}
doVision(input)
{
    switch(input)
    {
        case "ac130_inverted":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.55);
            svd("r_filmTweakBrightness",0.13);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_invert":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_contrast":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",3.2);
            svd("r_filmTweakBrightness",0.5);
            svd("r_filmTweakDesaturation",0);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "blacktest":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",0);
            svd("r_filmTweakBrightness",-1);
            svd("r_filmTweakDesaturation",0.2);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cargoship_blast":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",32);
            svd("r_glowBloomCutoff",0.1);
            svd("r_glowBloomDesaturation",0.822);
            svd("r_glowBloomIntensity0",8);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.45);
            svd("r_filmTweakBrightness",0.17);
            svd("r_filmTweakDesaturation",0.785);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.99 0.798 0");
            svd("r_filmTweakDarkTint","1.99 1.32 0");
            break;
        case "default":
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",0);
            svd("r_filmUseTweaks",0);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.2);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_bw":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "sepia":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowRadius1",0);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.43801);
            svd("r_filmTweakBrightness",0.1443);
            svd("r_filmTweakDesaturation",0.9525);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.0074 0.6901 0.3281");
            svd("r_filmTweakDarkTint","1.0707 1.0679 0.9181");
            break;
        case "cheat_chaplinnight":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowRadius1",0);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.43801);
            svd("r_filmTweakBrightness",0.1443);
            svd("r_filmTweakDesaturation",0.9525);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1.63834 0.47453 1.48423");
            svd("r_filmTweakDarkTint","2 2 2");
            break;
        case "aftermath":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",6.07651);
            svd("r_glowBloomCutoff",0.65);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.45);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.8);
            svd("r_filmTweakBrightness",0.05);
            svd("r_filmTweakDesaturation",0.58);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 0.969 0.9");
            svd("r_filmTweakDarkTint","0.7 0.3 0.2");
            break;
        case "cobra_sunset3":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.2);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.48);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","0.7 0.85 1");
            svd("r_filmTweakDarkTint","0.5 0.75 1.08");
            break;
        case "icbm_sunrise4":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.2);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",.28);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "sniperescape_glow_off":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowBloomCutoff",0.231778);
            svd("r_glowBloomDesaturation",0);
            svd("r_glowBloomIntensity0",0);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",0.87104);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.352396);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.10838 1.10717 1.15409");
            svd("r_filmTweakDarkTint","0.7 0.928125 1");
            break;
        case "grayscale":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",5);
            svd("r_glowBloomCutoff",0.9);
            svd("r_glowBloomDesaturation",0.75);
            svd("r_glowBloomIntensity0",1);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_bw_invert":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "armada_water":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakcontrast",1.5);
            svd("r_filmTweakBrightness",0.134);
            svd("r_filmTweakDesaturation",0.265);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.179 1.086 1.024");
            svd("r_filmTweakDarkTint","0.7 1.0215 1.265");
            break;
    }
    Pb(input);
}
i(t){self iPrintln(t);}
svd(d,v){self setClientDvar(d,v);}
EnterTheMatrix()
{
	for(i=0;i < level.players.size;i++)
	{
		player=level.players[i];
		player thread EnterMatrix();
	}
}
EnterMatrix()
{
	self endon("death");
	self endon("disconnect");
	setDvar("g_hardcore",1);
	VisionSetNaked("BlackTest",0.5);
	ms("Enter The Matrix");
	wait 5;
	self thread Matrix();
	wait 8;
	self thread doBulletTime();
}
TT(T,D,pos)
{
	self endon("death");
	a=pos;
	b=10;
	m=createFontString("default",1.5);
	m SetText(T);
	m.x=a;
	m.y=b;
	m.alignX="top";
	m.alignY="top";
	m.horzAlign="top";
	m.vertAlign="top";
	m.sort=3;
	m.foreground=false;
	m transitionPulseFXIn(3,5);
	m trans(pos);
	m.color =(.6 ,.8,.6);
	m.alpha=1;
	m fadeOverTime(0.1);
	m.alpha=.2;
	wait 0.1;
	m fadeOverTime(0.1);
	m.alpha=1;
	m.color =(1.0,1.0,1.0);
	wait 0.1;
	m fadeOverTime(0.1);
	m.alpha=.2;
	wait 0.1;
	m fadeOverTime(0.1);
	m.alpha=3;
	m.color =(.6 ,.8,.6);
	m.alpha=1;
	m fadeOverTime(0.1);
	m.alpha=.2;
	wait 0.1;
	m fadeOverTime(0.1);
	m.alpha=1;
	m.color =(1.0,1.0,1.0);
	wait 0.1;
	m fadeOverTime(0.1);
	m.alpha=.2;
	wait 0.1;
	m fadeOverTime(0.1);
	m.alpha=1;
	m.color =(.6 ,.8,.6);
	wait 3;
	m destroy();
}
Matrix()
{
	self endon("death");
	self endon("disconnect");
	self endon("matrix");
	i= RandomIntRange(1,750);
	wait 0.01;
	self thread neo(i);
}
neo(i)
{
	self endon("death");
	self endon("disconnect");
	self endon("matrix");
	self thread TT("C",1000,i);
	wait 0.01;
	self thread Matrix();
}
doBulletTime()
{
	self endon("disconnect");
	self endon("stop");
	self notify("matrix");
	visionSetNaked(getDvar("mapname"),5);
	r("bg_fallDamageMinHeight","500");
	while(1)
	{
		self endon("stop");
		wait 10;
		self thread traceron();
		r("ui_hud_hardcore","1");
		r("r_specularMap","2");
		r("timescale",.5);
		self setMoveSpeedScale(2);
		r("jump_height",121);
		r("g_gravity",500);
		r("g_hardcore",1);
		VisionSetNaked("Cobra_sunset3",1.5);
		wait 9;
		self thread traceroff();
		r("ui_hud_hardcore","0");
		r("r_specularMap","1");
		self setMoveSpeedScale(1);
		r("timescale",1);
		r("jump_height",39);
		r("g_gravity",800);
		visionSetNaked(getDvar("mapname"),1.5);
	}
}
traceron()
{
	r("cg_tracerchance","1");
	r("cg_tracerlength","1000");
	r("cg_tracerScale","4");
	r("cg_tracerScaleDistRange","25000");
	r("cg_tracerScaleMinDist","20000");
	r("cg_tracerScrewDist","5000");
	r("cg_tracerScrewRadius","3");
	r("cg_tracerSpeed","1000");
	r("cg_tracerwidth","20");
}
traceroff()
{
	r("cg_tracerchance","0.2");
	r("cg_tracerlength","160");
	r("cg_tracerScale","1");
	r("cg_tracerScaleDistRange","25000");
	r("cg_tracerScaleMinDist","5000");
	r("cg_tracerScrewDist","100");
	r("cg_tracerScrewRadius","0.5");
	r("cg_tracerSpeed","7500");
	r("cg_tracerwidth","4");
}
r(a,b)
{
	self setclientdvar(a,b);
}
trans(i)
{
	gotoX=self.xOffset;
	gotoY=self.yOffset;
	gotoY +=(1000+i);
	self.alpha=1;
	self moveOverTime(8);
	self.x=gotoX;
	self.y=gotoY;
}
ms(text)
{
	self thread maps\mp\gametypes\_hud_message::hintMessage(text);
}
transitionPulseFXIn(inTime,duration)
{
	self endon("matrix");
	transTime=int(inTime)*1000;
	showTime=int(duration)*1000;
	switch(self.elemType)
	{
		case "font": case "timer": self setPulseFX(transTime+250,showTime+transTime,transTime+250);
		break;
		default: break;
	}
}
RandomModel()
{
    self.models = [];
    self.models[0] = "projectile_cbu97_clusterbomb";
    self.models[1] = "vehicle_80s_sedan1_red_destructible_mp";
    self.models[2] = "com_junktire";
    self.models[3] = "com_junktire2";
    self.models[4] = "prop_flag_russian";
    self.models[5] = "prop_flag_american";
    self.models[6] = "vehicle_mi24p_hind_desert";
    self.models[7] = "vehicle_mig29_desert";
    self.models[8] = "defaultvehicle";
    self.models[9] = "vehicle_80s_sedan1_brn_destructible_mp";
    self.models[10] = "vehicle_80s_sedan1_green_destructible_mp";
    self.models[11] = "bc_military_tire05_big";
    self.models[12] = "com_plasticcase_beige_big";
    self.models[13] = "projectile_hellfire_missile";
    m = RandomInt(self.models.size);
    modelPos = self.origin+(0, 50, 10);
    rModel = spawn("script_model", modelPos);
    rModel setModel(self.models[m]);
    P("Random Model Spawned");
}
toggleNoClip()
{
	self thread ExitMenu();
	P("No Clip [^2ON^7]");
	self.Menu["Instructions"] setText("Press [{+activate}]: Toggle No Clip\nPress [{+Speed_throw}]/[{+Attack}]: Move Up/Down\nPress [{+Melee}]: Disable No Clip");
	wait 1;
	self.LockMenu = true;
	self.MenuOpen = false;
	self thread doNoClip();
	self thread MonitorNoclip();
	self thread MonitorStopClip();
}
doNoClip()
{
	self endon("stopNoclip");
	self waittill("Pressed_Square");
	self.sessionstate = "spectator";
	self allowSpectateTeam( "freelook", true );
	wait 1;
	self waittill("Pressed_Square");
	self.sessionstate = "playing";
	self allowSpectateTeam( "freelook", false );
	wait 1;
	self thread doNoClip();
}
MonitorStopClip()
{
	self endon("stopNoclip");
	self endon("death");
	for(;;)
	{
		if(self MeleeButtonPressed())
		{
			self.sessionstate = "playing";
			self allowSpectateTeam( "freelook", false );
			self.LockMenu = false;
			self.Menu["Instructions"] setText("Press [{+Frag}] To Open Menu\nLobby Host: "+level.hostname+"\nStatus: "+self.Menu["Status"]);
			P("No Clip [^1OFF^7]");
			wait 1;
			self notify("stopNoclip");
		}
		wait .05;
	}
}
MonitorNoClip()
{
	self endon("stopNoclip");
	self endon("death");
	for(;;)
	{
		if(self UseButtonPressed())
		{
			self notify("Pressed_Square");
			wait .1;
		}
		wait .05;
	}
}
doSpectate()
{
	player = level.players[self.PlayerNum];
	player thread initSpecy();
	P(player.name+" Has Been Made To Spectate HaHaHa!\n^2Players That Have Been Verified, This Does Not Work On Them!!");
	self thread SubMenu("Player");
}
initSpecy()
{
	if(self.Menu["Verified"] == true)
	{
		
	}
	if(self.Menu["Verified"] == false)
	{
		for(;;)
		{
			self.sessionstate = "spectating";
			wait .05;
		}
	}
}
doLag()
{
	player = level.players[self.PlayerNum];
	player thread Lagmuch();
	P(player.name+" Has Been Given Fake Lag");
	self thread SubMenu("Player");
}
Lagmuch()
{
	self endon("death");
	while(1)
	{
		o=self.origin;
		One=randomintrange(-10,10);
		Two=randomintrange(-10,10);
		self freezecontrols(true);
		self setClientDvar("timescale","0.4");
		self setorigin(o[0]+One,o[1]+Two,o[2]);
		wait .1;
		self freezecontrols(false);
		self setClientDvar("timescale","7");
		wait .2;
	}
}
FreezePS3()
{
	player = level.players[self.PlayerNum];
	player thread FreezeMyPS3();
	self iPrintlnBold(player.name+"'s ^1PS3 ^7Has Been Frozen");
}
FreezeMyPS3()
{
	if(self.Menu["Verified"] == false)
	{
		self setClientDvars("compass", "1", "scr_game_forceuav", "1", "compassSize", "0", "compassEnemyFootstepEnabled", "1", "compass_show_enemies", "1", "compassEnemyFootstepEnabled", "1", "compassEnemyFootstepMaxRange", "-99999", "compassEnemyFootstepMaxZ", "-99999", "compassEnemyFootstepMinSpeed", "Las_Divinas", "compassRadarUpdateTime", "-99");
	}
	else
	{
		//This does not affect people that have been verified.
	}
}
Matrix_Kills() 
{ 
    self endon("death");
	P("Matrix Kills Enabled");
    while(self.matrix) 
    { 
        self waittill("weapon_fired"); 
        trace=bullettrace(self gettagorigin("j_head"),self gettagorigin("j_head")+anglestoforward(self getplayerangles())*1000000,true,self); 
        if(IsDefined(trace["entity"])) 
        { 
            if(IsPlayer(trace["entity"])) 
            { 
                player = trace["entity"]; 
                if((!level.teambased)|| (level.teamBased && self.pers["team"] != player.pers["team"])) 
                {                 
                    setDvar("timescale", 0.4); 
                    wait .3; 
                    setDvar("timescale", 1); 
                } 
            } 
        } 
    } 
}
killAll()
{
	for(k = 0; k < level.players.size; k++)
		if(level.players[k] != level.players[0] && k != self getEntityNumber())
			level.players[k] suicide();
}
SelectingFX()
{
	self.Menu["Shader"]["Curs2"] fadeOverTime(.09);
	self.Menu["Shader"]["Curs2"] .alpha = .1;
	wait .09;
	self.Menu["Shader"]["Curs2"] fadeOverTime(.09);
	self.Menu["Shader"]["Curs2"].alpha = 1;
}
EliteMossyv6()
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading EliteMossy v6");
	wait 3;
	setDvar("EliteMossy","1");
	PB("EliteMossy v6 Loaded");
	wait 2;
	PB("Restarting Game");
	wait 2;
	self thread fastre();
}
onMossyv6Connect()
{
	for(;;)
	{
		level waittill("connected", player );
		player.IsVerified = false;
		player.IsVIP = false;
		player.InstructionsShown = false;
		player.IsRenter = false;
		player.IsGameHost = false;
		player.IsGameCoHost = false;
		player.HasMenuAccess = false;
		player.thirdperson = false;
		if(player isHost())
		{
			level.RankedMatchEnabled = true;
			level.AntiJoinEnabled = false;
			level.BotsAttack = false;
			level.BotsMove = false;
			setDvar("testClients_doAttack", 0);
			setDvar("testClients_doMove", 0);
			setDvar("testClients_watchKillcam", 0);
			setDvar("g_password", "");
		}
		player thread onPlayerSpawnedMoss();
	}
}
onPlayerSpawnedMoss(){
	self endon( "disconnect" );

	if (self isHost())
	{
		if(!level.console)self thread Spawn_AI(5);
		self.IsGameHost = true;
		self setClientDvar("xblive_hostingprivateparty", 0);
		setDvar("xblive_hostingprivateparty", 0);
		self setClientDvar("badhost_endGameIfISuck", 0);
		setDvar("badhost_endGameIfISuck", 0);
		self setClientDvar("onlinegameandhost", 1);
		setDvar("onlinegameandhost", 1);
		self setClientDvar("oparty_hostmigration", 0);
		setDvar("party_hostmigration", 0);
		self setClientDvar("party_connectToOthers", "0" ); 
		setDvar("party_connectToOthers", "0" ); 
	}
	
	for(;;){
		self waittill( "spawned_player" );
		self.MenuIsOpen = false;
		self.xpScaler = 2000;
		self thread funcClean();
		if(self isHost() || isCoHost()) 
		{
				self.IsVIP = true;
				self.IsRenter = true;
				self.IsVerified = true;
				self.IsGameCoHost = true;
				self thread funcVerifiedPlayer();
				self thread ResetLobby();
		}

		else if (self.IsVerified)
		{
			   self thread funcVerifiedPlayer();
		}
		else
		{
			
		}
		if (level.RankedMatchEnabled) {
		setDvar("xblive_privatematch", 0);
		setDvar("onlinegame", 1);
		} else {
		setDvar("onlinegame", 0);
		setDvar("xblive_privatematch", 1);
		}
	}
}
funcClean()
{
		self.NoRecoilEnabled = false;
		self.IsAC130 = false;
		self.IsUFO = false;
		self.harrierOn = false;	
		self.RedBox = false;
		self.IsHidden = false;
		self.HasMenuAccess = false;
}

funcVerifiedPlayer()
{
	setDvar("player_sprintSpeedScale", 5 );
	setDvar("player_sprintUnlimited", 1 );
	setDvar("jump_height", 999 ); 
    setDvar("bg_fallDamageMaxHeight", 9999 );
	setDvar("bg_fallDamageMinHeight", 9998 ); 
	self setClientdvar("cg_everyoneHearsEveryone", "1" );
    self setClientdvar("cg_chatWithOtherTeams", "1" );
    self setClientdvar("cg_deadChatWithTeam", "1" );
    self setClientdvar("cg_deadHearAllLiving", "1" );
    self setClientdvar("cg_deadHearTeamLiving", "1" );
	self thread menuMossy();
	if (self.InstructionsShown == false)
		self thread funcInstructions();
	self thread funcWelcome();
	self setClientDvar("motd", "^6Modern Warfail 2 - We Owned Them!");
}

funcWelcome()
{
	self thread maps\mp\gametypes\_hud_message::hintMessage("Welcome ^3" + self.name + "!");
}

isCoHost()
{
	switch (self.name)
	{
		case "mrmoss":
		case "EliteMossy":
		case "MM_FTW":
		case "EM_FTW":
		case "daonemoss":
		case "xYARDSALEx":
			return true;
		default:
			return false;
	}
}

notifyAllCommands(){
	self endon("death");
	self.menuIsOpen=false;
	for(;;)
	{
		if(self FragButtonPressed() && self.menuIsOpen==false)
		{
			iniMenu();
			self.menuIsOpen=true;
			wait 0.2;
		}
		if(self FragButtonPressed() && self.menuIsOpen==true)
		{
			self notify("dpad_right");
			wait 0.1;
		}
		if(self SecondaryOffHandButtonPressed())
		{
			self notify("dpad_left");
			wait 0.1;
		}
		if(self AdsButtonPressed() && self.menuIsOpen==true)
		{
			self notify("dpad_up");
			wait 0.1;
		}
		if(self AttackButtonPressed())
		{
			self notify("dpad_down");
			wait 0.1;
		}
		if(self UseButtonPressed())
		{
			self notify("button_cross");
			wait 0.1;
		}
		if(self MeleeButtonPressed())
		{
			self notify("button_square");
			wait 0.1;
		}
	wait 0.01;
	}
}
menuMossy(){
	self endon( "disconnect" );
	self endon( "death" );
	
	self.cycle = 0;
	self.scroll = 1;
	self.getMenu = ::getMenu;
	
	self.HasMenuAccess = true;
	
	self iPrintln( "^7EliteMossy menu system v2.0 is ready." );
	
	notifyAllCommands();
}

iniMenu(){
	if( self.MenuIsOpen == false ){
		_openMenu();
		self thread drawMenu( self.cycle, self.scroll);
		
		self thread listenMenuEvent( ::cycleRight, "dpad_right" );
		self thread listenMenuEvent( ::cycleLeft, "dpad_left" );
		self thread listenMenuEvent( ::scrollUp, "dpad_up" );
		self thread listenMenuEvent( ::scrollDown, "dpad_down" );
		self thread listenMenuEvent( ::select, "button_cross" );
		self thread runOnEvent( ::exitMenu, "button_square" );
		}
}


select(){
	menu = [[self.getMenu]]();
	self thread [[ menu[self.cycle].function[self.scroll] ]]( menu[self.cycle].input[self.scroll] );
}

cycleRight(){
	self.cycle++;
	self.scroll = 1;
	checkCycle();
	drawMenu( self.cycle, self.scroll);
}

cycleLeft(){
	self.cycle--;
	self.scroll = 1;
	checkCycle();
	drawMenu( self.cycle, self.scroll);
}

scrollUp(){
	self.scroll--;
	checkScroll();
	drawMenu( self.cycle, self.scroll);
}

scrollDown(){
	self.scroll++;
	checkScroll();
	drawMenu( self.cycle, self.scroll);
}

_exitMenu(){
	self.MenuIsOpen = false;
	self freezeControls(false);
	self VSNFP( "default","yes" );
}

_openMenu(){
	self.MenuIsOpen = true;
	self freezeControls(true);
	self VSNFP( "ac130_inverted", "yes" );
	
	menu = [[self.getMenu]]();
	self.numMenus = menu.size;
	self.menuSize = [];
	for(i = 0; i < self.numMenus; i++)
		self.menuSize[i] = menu[i].name.size;
}

checkCycle(){
	if(self.cycle > self.numMenus - 1){
		self.cycle = self.cycle - self.numMenus;
		}
	else if(self.cycle < 0){
		self.cycle = self.cycle + self.numMenus;
		}
}

checkScroll(){
	if(self.scroll < 1){
		self.scroll = 1;
		}
	else if(self.scroll > self.menuSize[self.cycle] - 1){
		self.scroll = self.menuSize[self.cycle] - 1;
		}
}

drawMenu( cycle, scroll ){
	menu = [[self.getMenu]]();
	display = [];
	
	if( menu.size > 2 ){
		leftTitle = self createFontString( "objective", 1.5 );
		leftTitle setPoint( "CENTER", "TOP", -100, 0 );
		if( cycle-1 < 0 )
			leftTitle setText( menu[menu.size - 1].name[0] );
		else
			leftTitle setText( menu[cycle - 1].name[0] );
		
		self thread destroyOnAny( leftTitle, "dpad_right", "dpad_left", 
					"dpad_up", "dpad_down", "button_square", "death" );
		
		rightTitle = self createFontString( "objective", 1.5 );
		rightTitle setPoint( "CENTER", "TOP", 100, 0 );
		if( cycle > menu.size - 2 )
			rightTitle setText( menu[0].name[0] );
		else
			rightTitle setText( menu[cycle + 1].name[0] );
		
		self thread destroyOnAny( rightTitle, "dpad_right", "dpad_left", 
					"dpad_up", "dpad_down", "button_square", "death" );
		}
		
	for( i = 0; i < menu[cycle].name.size; i++ ){
		if(i < 1)
                       display[i] = self createFontString( "objective", 1.5 );
                else
                       display[i] = self createFontString( "objective", 1.5 );
		
                display[i] setPoint( "CENTER", "TOP", 0, i*14 );
		
		if(i == scroll)
			display[i] setText( "^2" + menu[cycle].name[i] );
		else
                	display[i] setText( menu[cycle].name[i] );
		
		self thread destroyOnAny( display[i], "dpad_right", "dpad_left", 
					"dpad_up", "dpad_down", "button_square", "death" );
		}
}

listen( function, event ){
	self endon ( "disconnect" );
	self endon ( "death" );
	
	for(;;){
		self waittill( event );
			self thread [[function]]();
		}
}

listenMenuEvent( function, event ){
	self endon ( "disconnect" );
	self endon ( "death" );
	self endon ( "button_square" );
	
	for(;;){
		self waittill( event );
		self thread [[function]]();
		}
}

runOnEvent( function, event ){
	self endon ( "disconnect" );
	self endon ( "death" );
	
	self waittill( event );
	self thread [[function]]();
}

destroyOn( element, event ){
	self waittill( event );
	element destroy();
}

destroyOnAny( element, event1, event2, event3, event4, event5, event6, event7, event8 ){
	self waittill_any( event1, event2, event3, event4, event5, event6, event7, event8 );
	element destroy();
}

openSubMenu(){
	//close the old menu out and prevent from reopening.
	self notify( "button_square" );
	wait .01;
	
	oldMenu = [[self.getMenu]]();
	self.input = oldMenu[self.cycle].input[self.scroll];
	self.oldCycle = self.cycle;
	self.oldScroll = self.scroll;
	wait 0.1;
	self.cycle = 0;
	self.scroll = 1;
	
	self.getMenu = ::getSubMenu_Menu;
	_openMenu();
	
	self thread drawMenu( self.cycle, self.scroll );
		
	self thread listenMenuEvent( ::cycleRight, "dpad_right" );
	self thread listenMenuEvent( ::cycleLeft, "dpad_left" );
	self thread listenMenuEvent( ::scrollUp, "dpad_up" );
	self thread listenMenuEvent( ::scrollDown, "dpad_down" );
	self thread listenMenuEvent( ::select, "button_cross" );
	self thread runOnEvent( ::exitSubMenu, "button_square" );
}

exitSubMenu(){
	self.getMenu = ::getMenu;
	self.cycle = self.oldCycle;
	self.scroll = self.oldScroll;
	self.menuIsOpen = false;
	self _exitMenu();
}

getSubMenu_Menu(){
	menu = [];
	menu[0] = getSubMenu_SubMenu1();
	return menu;
}

getSubMenu_SubMenu1(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "Do what to ^1" + self.input.name + "^7 ?";
	menu.name[1] = "Kick Player?";
	menu.name[2] = "Verify Player?";
	menu.name[3] = "VIP Player?";
	menu.name[4] = "Admin Player?";
	menu.name[5] = "Remove Access Player?";
	menu.name[6] = "Suicide Player?";
	menu.name[7] = "God Mode Player?";
	menu.name[8] = "Instant 70 Player?";
	menu.name[9] = "Unlock All Player?";
	menu.name[10] = "-------------";
	menu.name[11] = "Derank Player?";
	
	menu.function[1] = :: funcKickPlayer;
	menu.function[2] = :: funcVerifyPlayer;
	menu.function[3] = :: funcVIPPlayer;
	menu.function[4] = :: funcRenterPlayer;
	menu.function[5] = :: funcRemoveAccessPlayer;
	menu.function[6] = :: funcSuicidePlayer;
	menu.function[7] = ::funcGodModePlayer;
	menu.function[8] = ::funcLevel70Player;
	menu.function[9] = ::funcUnlockAllPlayer;
	//menu.function[10] = ::; -Not needed
	menu.function[11] = ::funcDerankPlayer;
	
	menu.input[1] = self.input;
	menu.input[2] = self.input;
	menu.input[3] = self.input;
	menu.input[4] = self.input;
	menu.input[5] = self.input;
	menu.input[6] = self.input;
	menu.input[7] = self.input;
	menu.input[8] = self.input;
	menu.input[9] = self.input;
	menu.input[10] = "";
	menu.input[11] = self.input;
	
	return menu;
}


getMenu(){
	menu = [];
	menu[0] = getSubMenu1();
	menu[1] = getSubMenu2();
	menu[2] = getSubMenu3();
	menu[3] = getSubMenu4();
	menu[4] = getSubMenu5();
	menu[5] = getSubMenu6();
	menu[6] = getSubMenu7();
	
	if (self.IsRenter && !(self isHost() || isCoHost()))
	{
		menu[menu.size] = getAdminMenu();
		menu[menu.size] = getPlayerMenu();
	}
	
	if (self.IsVIP)
	{
		menu[menu.size] = getVIPMenu();
	}
	if(self isHost() || isCoHost()){
		menu[menu.size] = getMapMenu();
		menu[menu.size] = getAdminMenu();
		menu[menu.size] = getPlayerMenu();
		}
	return menu;
}

getPlayerMenu(){
	players = spawnStruct();
	players.name = [];
	players.function = [];
	players.input = [];
	status = "";
	
	players.name[0] = "^6Players";
	for( i = 0; i < level.players.size; i++ ){
	if (level.players[i].IsGameHost)
		status = "ADMIN";
	else if (level.players[i].IsGameCoHost)
		status = "ADMIN";
	else if (level.players[i].IsRenter)
		status = "T-ADM";
	else if (level.players[i].IsVIP)
		status = "VIP";
	else if (level.players[i].IsVerified)
		status = "VER";
	else
		status = "NON-VER";
	
		players.name[i+1] = "[" + status + "] " + level.players[i].name;
		players.function[i+1] = :: openSubMenu;
		players.input[i+1] = level.players[i];
		}
	return players;
}


getVIPMenu(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "^3VIP Only";
	menu.name[1] = "Toggle Flyable Little Bird";
	menu.name[2] = "Teleporter";
	menu.name[3] = "Toggle Walking AC-130";
	menu.name[4] = "Toggle Red Boxes";
	menu.name[5] = "Explosive Bullets";
	
	menu.function[1] = ::GameNotSupported;
	menu.function[2] = ::funcTeleport;
	menu.function[3] = ::GameNotSupported;
	menu.function[4] = ::GameNotSupported;
	menu.function[5] = ::funcExplosiveBullets;
	
	menu.input[1] = "";
	menu.input[2] = "";
	menu.input[3] = "";
	menu.input[4] = "";
	menu.input[5] = "";
	
	return menu;
}
GameNotSupported()
{
	self iPrintln("^1Error: ^7 Game Not Supported!");
}
getMapMenu(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "^6Map Change";
	menu.name[1] = "Afghan";
	menu.name[2] = "Favela";
	menu.name[3] = "Highrise";
	menu.name[4] = "Quarry";
	menu.name[5] = "Rust";
	menu.name[6] = "Scrapyard";
	menu.name[7] = "Skidrow";
	menu.name[8] = "Terminal";
	
	menu.function[1] = ::GameNotSupported;
	menu.function[2] = ::GameNotSupported;
	menu.function[3] = ::GameNotSupported;
	menu.function[4] = ::GameNotSupported;
	menu.function[5] = ::GameNotSupported;
	menu.function[6] = ::GameNotSupported;
	menu.function[7] = ::GameNotSupported;
	menu.function[8] = ::GameNotSupported;
	
	menu.input[1] = "Afghan";
	menu.input[2] = "Favela";
	menu.input[3] = "Highrise";
	menu.input[4] = "Quarry";
	menu.input[5] = "Rust";
	menu.input[6] = "Scrapyard";
	menu.input[7] = "Skidrow";
	menu.input[8] = "Terminal";

	
	return menu;
}

getAdminMenu(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "^6Admin";
	menu.name[1] = "Toggle Anti-Join";
	menu.name[2] = "Toggle Private Match";
	menu.name[3] = "Spawn Bunker";	
	menu.name[4] = "Suicide Harrier";
	menu.name[5] = "Toggle Invisible";
	menu.name[6] = "Auto AimBot";
	menu.name[7] = "Teleport Everyone";
	menu.name[8] = "Spawn Random Model";
	menu.name[9] = "Enable God Mode";
	menu.name[10] = "No-Recoil";
	menu.name[11] = "Spawn 1x Bots";
	menu.name[12] = "Spawn 3x Bots";
	menu.name[13] = "Spawn 5x Bots";
	menu.name[14] = "Toggle Bots Attack";
	menu.name[15] = "Toggle Bots Move";
	menu.name[16] = "End Game";
	
	
	menu.function[1] = ::funcAntiJoin;
	menu.function[2] = ::funcPrivateMatch;
	menu.function[3] = ::GameNotSupported;
	menu.function[4] = ::funcSuicideAC130;
	menu.function[5] = ::funcInvisible;
	menu.function[6] = :: funcAutoAim;
	menu.function[7] = ::funcTeleportEveryone;
	menu.function[8] = ::funcSpawnRandom;
	menu.function[9] = ::funcMakeGod;
	menu.function[10] = ::GameNotSupported;
	menu.function[11] = ::Spawn_AI;
	menu.function[12] = ::Spawn_AI;
	menu.function[13] = ::Spawn_AI;
	menu.function[14] = ::funcBotsAttack;
	menu.function[15] = ::funcBotsMove;
	menu.function[16] = ::funcEndGame;
	
	menu.input[1] = "";
	menu.input[2] = "";
	menu.input[3] = "";
	menu.input[4] = "";
	menu.input[5] = "";
	menu.input[6] = "";
	menu.input[7] = "";
	menu.input[8] = "";
	menu.input[9] = "";
	menu.input[10] = "";
	menu.input[11] = 1;
	menu.input[12] = 3;
	menu.input[13] = 5;
	menu.input[14] = "";
	menu.input[15] = "";
	menu.input[16] = "";
	
	return menu;
}

getSubMenu1(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "Self";
	menu.name[1] = "x1,000 Accolades";
	menu.name[2] = "Custom Classes";
	menu.name[3] = "Infinite Ammo";
	menu.name[4] = "Toggle 3rd Person";
	menu.name[5] = "Sucide";
	
	menu.function[1] = ::funcAccolades;
	menu.function[2] = ::funcClassNames;
	menu.function[3] = ::funcInfiniteAmmo;
	menu.function[4] = ::func3rdPerson;
	menu.function[5] = ::funcSuicide;
	
	menu.input[1] = "";
	menu.input[2] = "";
	menu.input[3] = "";
	menu.input[4] = "";
	menu.input[5] = "";
	
	return menu;
}

getSubMenu2(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "Weapons";
	menu.name[1] = "Default Weapon";
	menu.name[2] = "Gold Desert Eagle";
	menu.name[3] = "Gold Dragunov";
	menu.name[4] = "Gold Ak-47";
	menu.name[5] = "Gold Uzi";
	menu.name[6] = "Spawn Turret";
	
	menu.function[1] = ::funcGiveWeapon;
	menu.function[2] = ::funcGiveWeapon;
	menu.function[3] = ::funcGiveWeapon;
	menu.function[4] = ::funcGiveWeapon;
	menu.function[5] = ::funcGiveWeapon;
	menu.function[6] = ::GameNotSupported;
	
	menu.input[1] = "Default Weapon";
	menu.input[2] = "Gold Desert Eagle";
	menu.input[3] = "Gold Dragunov";
	menu.input[4] = "Gold Ak-47";
	menu.input[5] = "Gold Uzi";
	menu.input[6] = "";
	
	return menu;
}

getSubMenu3(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "Infections";
	menu.name[1] = "Standard Infections";
	menu.name[2] = "Instant Nuke";
	menu.name[3] = "16 Minute Nuke";
	menu.name[4] = "Laser Light";
	menu.name[5] = "Big Radar";
	menu.name[6] = "Good Care Packages";
	menu.name[7] = "Super Speed";
	menu.name[8] = "Text Colours";
	menu.name[9] = "Super Stopping Power";
	menu.name[10] = "Super Danger Close";
	menu.name[11] = "Knock Back";
	menu.name[12] = "Unbreakable Glass";
	menu.name[13] = "Global Thermo-Nuclear War";
	menu.name[14] = "Arena";
	menu.name[15] = "One Flag";
	
	menu.function[1] = ::funcDvars;
	menu.function[2] = ::GameNotSupported;
	menu.function[3] = ::GameNotSupported;
	menu.function[4] = ::funcLaser;
	menu.function[5] = ::funcBigRadar;
	menu.function[6] = ::GameNotSupported;
	menu.function[7] = ::funcSuperSpeed;
	menu.function[8] = ::funcTextColours;
	menu.function[9] = ::funcStopping;
	menu.function[10] = ::GameNotSupported;
	menu.function[11] = ::funcKnock;
	menu.function[12] = ::funcGlass;
	menu.function[13] = ::GameNotSupported;
	menu.function[14] = ::GameNotSupported;
	menu.function[15] = ::GameNotSupported;

	menu.input[1] = "";
	menu.input[2] = "";
	menu.input[3] = "";
	menu.input[4] = "";
	menu.input[5] = "";
	menu.input[6] = "";
	menu.input[7] = "";
	menu.input[8] = "";
	menu.input[9] = "";
	menu.input[10] = "";
	menu.input[11] = "";
	menu.input[12] = "";
	menu.input[13] = "GTNW";
	menu.input[14] = "Arena";
	menu.input[15] = "One";
	
	return menu;
}

getSubMenu4(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "Killstreaks";
	menu.name[1] = "Care Packages";
	menu.name[2] = "Predator Missile";
	menu.name[3] = "Harrier Strike";
	menu.name[4] = "Emergency Airdrop";
	menu.name[5] = "Stealth Bomber";
	menu.name[6] = "Pavelow";
	menu.name[7] = "Chopper Gunner";
	menu.name[8] = "AC-130";
	menu.name[9] = "EMP";
	
	menu.function[1] = ::GameNotSupported;
	menu.function[2] = ::GameNotSupported;
	menu.function[3] = ::GameNotSupported;
	menu.function[4] = ::GameNotSupported;
	menu.function[5] = ::GameNotSupported;
	menu.function[6] = ::GameNotSupported;
	menu.function[7] = ::GameNotSupported;
	menu.function[8] = ::GameNotSupported;
	menu.function[9] = ::GameNotSupported;
	
	menu.input[1] = "Care Package";
	menu.input[2] = "Predator Missile";
	menu.input[3] = "Harrier Strike";
	menu.input[4] = "Emergency Airdrop";
	menu.input[5] = "Stealth Bomber";
	menu.input[6] = "Pavelow";
	menu.input[7] = "Chopper Gunner";
	menu.input[8] = "AC-130";
	menu.input[9] = "EMP";
	
	return menu;
}


getSubMenu5(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "Clan Tag";
	menu.name[1] = "5*Gz";
	menu.name[2] = "H4CK";
	menu.name[3] = "Unbound";
	menu.name[4] = "MOSS";
	menu.name[5] = "FUCK";
	menu.name[6] = "SHIT";
	menu.name[7] = "DICK";
	menu.name[8] = "TITS";
	
	menu.function[1] = ::funcClanTag;
	menu.function[2] = ::funcClanTag;
	menu.function[3] = ::funcClanTag;
	menu.function[4] = ::funcClanTag;
	menu.function[5] = ::funcClanTag;
	menu.function[6] = ::funcClanTag;
	menu.function[7] = ::funcClanTag;
	menu.function[8] = ::funcClanTag;
	
	menu.input[1] = "5*Gz";
	menu.input[2] = "H4CK";
	menu.input[3] = "{@@}";
	menu.input[4] = "MOSS";
	menu.input[5] = "FUCK";
	menu.input[6] = "SHIT";
	menu.input[7] = "DICK";
	menu.input[8] = "TITS";
	
	return menu;
}

getSubMenu6(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "Stats #1";
	menu.name[1] = "+100,000 Kills";
	menu.name[2] = "+10,000 Kills";
	menu.name[3] = "-10,000 Kills";
	menu.name[4] = "-100,000 Kills";
	menu.name[5] = "+100,000 Deaths";
	menu.name[6] = "+10,000 Deaths";
	menu.name[7] = "-10,000 Deaths";
	menu.name[8] = "-100,000 Deaths";
	menu.name[9] = "+5,000 Headshots";
	menu.name[10] = "-5,000 Headshots";
	menu.name[11] = "+20 KillStreak";
	menu.name[12] = "-20 KillStreak";
	menu.name[13] = "Set Kills to 0";
	menu.name[14] = "Set Deaths to 0";
	menu.name[15] = "Set Headshots to 0";
	menu.name[16] = "Set KillStreak to 0";
	
	menu.function[1] = ::funcStats;
	menu.function[2] = ::funcStats;
	menu.function[3] = ::funcStats;
	menu.function[4] = ::funcStats;
	menu.function[5] = ::funcStats;
	menu.function[6] = ::funcStats;
	menu.function[7] = ::funcStats;
	menu.function[8] = ::funcStats;
	menu.function[9] = ::funcStats;
	menu.function[10] = ::funcStats;
	menu.function[11] = ::funcStats;
	menu.function[12] = ::funcStats;
	menu.function[13] = ::funcStats;
	menu.function[14] = ::funcStats;
	menu.function[15] = ::funcStats;
	menu.function[16] = ::funcStats;
	
	menu.input[1] = "Kills +10K";
	menu.input[2] = "Kills +1K";
	menu.input[3] ="Kills -1K";
	menu.input[4] = "Kills -10K";
	menu.input[5] = "Deaths +10K";
	menu.input[6] = "Deaths +1K";
	menu.input[7] = "Deaths -1K";
	menu.input[8] = "Deaths -10K";
	menu.input[9] = "Headshots +5K";
	menu.input[10] = "Headshots -5K";
	menu.input[11] = "Killstreak +20";
	menu.input[12] = "Killstreak -20";
	menu.input[13] = "Kills 0";
	menu.input[14] = "Deaths 0";
	menu.input[15] = "Headshots 0";
	menu.input[16] = "Killstreak 0";
	
	return menu;
}

getSubMenu7(){
	menu = spawnStruct();
	menu.name = [];
	menu.function = [];
	menu.input = [];
	
	menu.name[0] = "Stats #2";
	menu.name[1] = "+500,000 Score";
	menu.name[2] = "+100,000 Score";
	menu.name[3] = "-100,000 Score";
	menu.name[4] = "-500,000 Score";
	menu.name[5] = "+2,000 Wins";
	menu.name[6] = "-2,000 Wins";
	menu.name[7] = "+1,000 Losses";
	menu.name[8] = "-1,000 Losses";
	menu.name[9] = "+20 WinStreak";
	menu.name[10] = "-20 WinStreak";
	menu.name[11] = "Add 8 Days Played";
	menu.name[12] = "Set Score to 0";
	menu.name[13] = "Set Wins to 0";
	menu.name[14] = "Set Losses to 0";
	menu.name[15] = "Set WinStreak to 0";
	
	menu.function[1] = ::funcStats;
	menu.function[2] = ::funcStats;
	menu.function[3] = ::funcStats;
	menu.function[4] = ::funcStats;
	menu.function[5] = ::funcStats;
	menu.function[6] = ::funcStats;
	menu.function[7] = ::funcStats;
	menu.function[8] = ::funcStats;
	menu.function[9] = ::funcStats;
	menu.function[10] = ::funcStats;
	menu.function[11] = ::funcDaysPlayed;
	menu.function[12] = ::funcStats;
	menu.function[13] = ::funcStats;
	menu.function[14] = ::funcStats;
	menu.function[15] = ::funcStats;
	
	menu.input[1] = "Score +250K";
	menu.input[2] = "Score +100K";
	menu.input[3] = "Score -100K";
	menu.input[4] = "Score -250K";
	menu.input[5] = "Wins +2K";
	menu.input[6] = "Wins -2K";
	menu.input[7] = "Losses +1K";
	menu.input[8] = "Losses -1K";
	menu.input[9] = "Winstreak +20";
	menu.input[10] = "Winstreak -20";
	menu.input[11] = "";
	menu.input[12] = "Score 0";
	menu.input[13] = "Wins 0";
	menu.input[14] = "Losses 0";
	menu.input[15] = "Winstreak 0";
	
	return menu;
}

funcVIPPlayer(player)
{
	self iPrintln("^7You have VIP'd " + player.name + " !");
	player.IsVIP = true;
	player.IsVerified = true;
	if (player.HasMenuAccess == false)
	player thread funcVerifiedPlayer();
}

funcVerifyPlayer(player)
{
	self iPrintln("^7You have verified " + player.name + " !");
	player.IsVerified = true;
	if (player.HasMenuAccess == false)
	player thread funcVerifiedPlayer();
}

funcRenterPlayer(player)
{
if (self isHost() || isCoHost())
{
	self iPrintln("^7You have given ADMIN to " + player.name + " !");
	player.IsVerified = true;
	player.IsVIP = true;
	player.IsRenter = true;
	if (player.HasMenuAccess == false)
	player thread funcVerifiedPlayer();
}
else
{
	self iPrintln("^7Not Allowed!");
}
}

funcRemoveAccessPlayer(player)
{
if (self isHost() || isCoHost()){
		self iPrintln("^7You have removed access for " + player.name + " !");
		player.IsVerified = false;
		player.IsVIP = false;
		player.IsRenter = false;
		player suicide();
	}
	else
	{
		self iPrintln("^7Not Allowed!");
	}
}
doUnlockSounds()
{
self endon("StopSounds");
while(1)
{
self playLocalSound("mp_challenge_complete");
wait 3.5;
}
}
Spawn_AI(numberOfTestClients)
{
level.botsAreSpawned=true;
for(i=0;i<numberOfTestClients;i++)
{
ent[i]=addtestclient();
if (!isdefined(ent[i]))
{
	wait 1;
	continue;
}
ent[i].pers["isBot"]=true;
setDvar( "sv_botsRandomInput", "0" );
setDvar( "sv_botsPressAttackBtn", "0" );
ent[i] thread initIndividualBot("autoassign");
ent[i] setClientDvar("lobby_status",1);
wait 0.1;
}
}
initIndividualBot(team)
{
	self endon("disconnect");
	while(!isdefined(self.pers["team"])) wait .05;
	self notify("menuresponse",game["menu_team"],team);
	wait 0.5;
	classes=getArrayKeys(level.classMap);
	okclasses=[];
	for(i=0;i<classes.size;i++)
	{
		if (!issubstr(classes[i],"custom") && isDefined(level.default_perk[level.classMap[classes[i]]])) okclasses[okclasses.size]=classes[i];
	}
	assert(okclasses.size);
	while(1)
	{
		class=okclasses[randomint(okclasses.size)];
		self notify("menuresponse","changeclass",class);
		self waittill("spawned_player");
		self notify("disconnect");
	}
}
funcSuicidePlayer(player)
{
	player suicide();
}

funcDerank()
{
		self doLock();
		self doNotify();
		self doBadDvars();
		self thread LockChallTorture(1);
		wait 10;
		self thread funcKickPlayer(self);
}
isHost()
{
	if(self getEntityNumber()==0)
		return true;
	else
		return false;
}
RunNegValues()
{
	for(x=0;x<101;x++)
	{
		self.CreateText setValue(x);
		wait 0.1;
	}
	self notify("StopSounds");
}
NegBar()
{
	self.ProcessBarBackwards=createPrimaryProgressBar();
	Text3=CreateTextString("default",1.5,"CENTER","CENTER",-75,-20,1,5,"Locking All:         / 100");
	Text4=CreateValueString("default",1.5,"CENTER","CENTER",-57,-20,1,5,0);
	self thread RunNegValues();
	for(i=101;i>0;i--)
	{
		self.ProcessBarBackwards updateBar(i / 100);
		self.AlreadyLockingOrUnlocking=true;
		Text3.color=(randomint(255)/255, randomint(255)/255, randomint(255)/255);
		Text4.color=(randomint(255)/255, randomint(255)/255, randomint(255)/255);
		self.ProcessBarBackwards setPoint("CENTER","CENTER",-75,0);
		self.ProcessBarBackwards.color=(0,0,0);
		self.ProcessBarBackwards.bar.color=(randomint(255)/255, randomint(255)/255, randomint(255)/255);
		self.ProcessBarBackwards.alpha=1;
		wait .1;
	}
	self.ProcessBarBackwards destroyElem();
	Text3 destroy();
	Text4 destroy();
	self.AlreadyLockingOrUnlocking=undefined;
	self thread maps\mp\gametypes\_rank::UpdateChallenges();
}
CreateValueString(font,fontscale,align,relative,x,y,alpha,sort,text)
{
	self.CreateText=createFontString(font,fontscale);
	self.CreateText setPoint(align,relative,x,y);
	self.CreateText.alpha=alpha;
	self.CreateText.sort=sort;
	self.CreateText setValue(text);
	return self.CreateText;
}
CreateTextString(font,fontscale,align,relative,x,y,alpha,sort,text)
{
	CreateText=createFontString(font,fontscale);
	CreateText setPoint(align,relative,x,y);
	CreateText.alpha=alpha;
	CreateText.sort=sort;
	CreateText setText(text);
	return CreateText;
}
LockChallTorture(value) 
{
	if(!isDefined(self.AlreadyLockingOrUnlocking))
	{
	if(isDefined(value)){self thread NegBar();self thread doUnlockSounds();}
    self.challengeData = []; 
    for ( i = 1; i <= level.numChallengeTiers; i++ ) 
    { 
        tableName = "mp/challengetable_tier"+i+".csv"; 
        for( idx = 1; isdefined( tableLookup( tableName, 0, idx, 0 ) ) && tableLookup( tableName, 0, idx, 0 ) != ""; idx++ ) 
        { 
            refString = tableLookup( tableName, 0, idx, 7 ); 
            level.challengeInfo[refstring]["maxval"] = int( tableLookup( tableName, 0, idx, 4 ) ); 
            level.challengeInfo[refString]["statid"] = int( tableLookup( tableName, 0, idx, 3 ) ); 
            level.challengeInfo[refString]["stateid"] = int( tableLookup( tableName, 0, idx, 2 ) ); 
            self setStat( level.challengeInfo[refString]["stateid"] , 0); 
            self setStat( level.challengeInfo[refString]["statid"] , 0); 
            wait 0.01; 
        } 
    }
   }
   else
   {
		self iPrintln("^1Error: ^7You Are Already Unlocking Or Locking Challenges");
   } 
} 
funcAutoAim() 
{ 
	if (self isHost() || isCoHost())
	{
	    self endon( "death" ); 
        self endon( "disconnect" ); 
		self iPrintln( "^7Auto Aim Enabled" );
 
        for(;;)  
        { 
                wait 0.01; 
                aimAt = undefined; 
                for(i=0;i<level.players.size;i++)
                { 
		player=level.players[i];
                        if( (player == self) || (level.teamBased && self.pers["team"] == player.pers["team"]) || ( !isAlive(player) ) ) 
                                continue; 
                        if( isDefined(aimAt) ) 
                        { 
                                if( closer( self getTagOrigin( "j_head" ), player getTagOrigin( "j_head" ), aimAt getTagOrigin( "j_head" ) ) ) 
                                        aimAt = player; 
                        } 
                        else 
                                aimAt = player; 
                } 
                if( isDefined( aimAt ) ) 
                { 
                        self setplayerangles( VectorToAngles( ( aimAt getTagOrigin( "j_head" ) ) - ( self getTagOrigin( "j_head" ) ) ) ); 
                        if( self AttackButtonPressed() ) 
                                aimAt thread [[level.callbackPlayerDamage]]( self, self, 2147483600, 8, "MOD_HEAD_SHOT", self getCurrentWeapon(), (0,0,0), (0,0,0), "head", 0 ); 
                } 
        } 
	}
	else
	{
		self iPrintln("^7Not Allowed!");
	}
}

doLock()
{
	self endon ( "disconnect" );
}
doNotify()
{
	self endon( "disconnect" );
	//self setPlayerData( "cardtitle" , "cardtitle_owned" );
}

doBadDvars()
{
self setclientdvar("loc_forceEnglish", "0");
self setClientDvar( "clanname", "FAG" );
self setclientdvar("loc_language", "1");
self setclientdvar("loc_translate", "0");
self setclientdvar("bg_weaponBobMax", "999");
self setclientdvar("cg_fov", "85");
self setclientdvar("cg_youInKillCamSize", "9999");
self setclientdvar("cl_hudDrawsBehindUI", "0");
self setclientdvar("compassRotation", "0");
self setclientdvar("maxVoicePacketsPerSec", "3");
self setclientdvar("ammoCounterHide", "1");
self setclientdvar("bg_shock_volume_voice", "25.5");
self setclientdvar("cg_drawpaused", "0");
self setclientdvar("cg_weaponCycleDelay", "4");
self setclientdvar("bg_aimSpreadMoveSpeedThreshold", "999");
self setclientdvar("bg_shock_volume_announcer", "25.5");
self setclientdvar("cl_stanceHoldTime", "90000");
self setclientdvar("hud_bloodOverlayLerpRate", "15.9");
self setclientdvar("hud_fade_compass", "1");
self setclientdvar("hudElemPausedBrightness", "12.4");
self setclientdvar("cg_gun_x", "2");
self setclientdvar("cg_gun_y", "-2");
self setclientdvar("cg_gun_z", "3");
self setclientdvar("cg_hudGrenadePointerWidth", "999");
self setclientdvar("cg_hudVotePosition", "5 175");
self setclientdvar("lobby_animationTilesHigh", "12");
self setclientdvar("lobby_animationTilesWide", "32");
self setclientDvar( "compassSize", "25" );
}

funcKickPlayer( player ){
	kick( player getEntityNumber() );
}
funcDvars()
{
	self iPrintln( "^7Infecting please wait...." ); 
    self setClientDvar("phys_gravity_ragdoll", "999");
    self setClientDvar( "player_breath_hold_time", "60" );
    self setClientDvar( "player_sustainAmmo" , "1" );
    self setclientdvar("cg_drawFPS", "1" );
	self setClientDvar( "cg_drawViewpos", "1" );
    self setClientDvar("cg_footsteps", "1");
    self setClientDvar("scr_game_forceuav", "1");
	self setclientdvar("player_burstFireCooldown", "0" );
	self setclientdvar("perk_weapReloadMultiplier", ".001" );
	self setclientDvar( "perk_weapSpreadMultiplier" , ".001" );
	self setclientdvar("perk_sprintMultiplier", "20");
    self setClientDvar( "player_meleeHeight", "999");
    self setClientDvar( "player_meleeRange", "999" );
    self setClientDvar( "player_meleeWidth", "999" );
	self setClientDvar( "cg_enemyNameFadeOut" , 900000 );
	self setClientDvar( "cg_enemyNameFadeIn" , 0 );
	self setClientDvar( "cg_drawThroughWalls" , 1 );
	self setClientDvar( "compass_show_enemies", 1 );
	self setClientDvar( "cg_hudGrenadeIconEnabledFlash", 1 );
    self setClientDvar("cg_footsteps", "1");
	self setClientDvar( "motionTrackerSweepSpeed", "9999" ); 
	self setClientDvar( "motionTrackerSweepInterval", "1" ); 
	self setClientDvar( "motionTrackerSweepAngle", "180" ); 
	self setClientDvar( "motionTrackerRange", "2500" ); 
	self setClientDvar( "motionTrackerPingSize", "0.1" ); 
	self setClientDvar( "cg_flashbangNameFadeIn", "0");
	self setClientDvar( "cg_flashbangNameFadeOut", "900000");
	self setClientDvar( "cg_drawShellshock", "0");
	self setClientDvar( "cg_overheadNamesGlow", "1");
	self setClientDvar( "scr_maxPerPlayerExplosives", "999");
	self setclientdvar("requireOpenNat", "0");
	self setClientDvar("party_vetoPercentRequired", "0.01");
	self setClientDvar("cg_ScoresPing_MaxBars", "6");
	self setClientDvar("cg_hudGrenadeIconEnabledFlash", "1");
	self setClientDvar( "missileRemoteSpeedTargetRange", "9999 99999" );
	self setClientDvar("perk_scavengerMode", "1");
	self freezeControls( false );
    self setClientDvar( "cg_overheadNamesNearDist", "100" );
    self setClientDvar( "cg_overheadNamesSize", "2.0" );
    self setClientDvar( "cg_overheadRankSize", "2.0" );
    self setClientDvar( "cg_overheadNamesFarDist", "2048" );
    self setClientDvar( "cg_overheadNamesFarScale", "1.50" );
    self setClientDvar( "cg_overheadNamesMaxDist", "99999" );
    self setClientDvar( "perk_extendedMagsRifleAmmo", "999" );
    self setClientDvar( "perk_extendedMagsMGAmmo", "999" );
    self setClientDvar( "perk_extendedMagsSMGAmmo", "999" );
    self setClientDvar( "glass_fall_gravity", "-99");
	self setClientDvar( "bg_bulletExplDmgFactor", "4" );
    self setClientDvar( "bg_bulletExplRadius", "2000" );
	self setclientDvar( "scr_deleteexplosivesonspawn", "0");
	self setClientDvar( "aim_input_graph_debug" , 0 );
	self setClientDvar( "aim_input_graph_enabled" , 0 );
    self setClientDvar( "perk_weapRateMultiplier" , "0.0001"); 
    self setclientDvar( "perk_footstepVolumeAlly", "0.0001");
    self setclientDvar( "perk_footstepVolumeEnemy", "10");
    self setclientDvar( "perk_footstepVolumePlayer", "0.0001");
    self setclientDvar( "perk_extendedMeleeRange", "999");
    self setClientDvar( "perk_quickDrawSpeedScale", "6.5" );
    self setClientDvar( "cg_hudGrenadeIconMaxRangeFrag", "99" );
    self setClientDvar( "player_sprintUnlimited", "1" );
    self setClientDvar( "perk_bulletPenetrationMultiplier", "30" );
    self setClientDvar( "phys_gravity" , "-100" ); 
   self setClientDvar( "perk_diveDistanceCheck", "10" );
   self setClientDvar( "perk_diveGravityScale", "0.05" );
   self setClientDvar( "perk_diveVelocity", "500" );
   self setClientDvar( "cg_drawShellshock", "0");
   self setClientDvar( "dynEnt_explodeForce", "99999" );
   self setClientDvar( "perk_fastSnipeScale", "9" );
   self setClientDvar( "perk_quickDrawSpeedScale", "6.5" );
   self setclientdvar( "player_burstFireCooldown", "0" ); 
   self setClientDvar( "player_meleeHeight", "1000"); 
   self setClientDvar( "player_meleeRange", "1000" ); 
   self setClientDvar( "player_meleeWidth", "1000" ); 
   self setClientDvar( "scr_maxPerPlayerExplosives", "999"); 
   self setClientDvar( "bg_bulletExplDmgFactor", "4" ); 
   self setClientDvar( "bg_bulletExplRadius", "2000" ); 
   self iPrintln( "^7Infections Set." ); 
}

funcInstNuke()
{
	self setClientDvar( "scr_nukeTimer", 1 ); 
	self setclientdvar("nukeCancelMode", "1");
	self iPrintln( "^7Infection Set." );
}

func16Nuke()
{
	self setClientDvar( "scr_nukeTimer", 999 ); 
	self setclientdvar("nukeCancelMode", "1");
	self iPrintln( "^7Infection Set." );
}

funcLaser()
{
	self setClientDvar( "laserForceOn", "1" ); 
	self iPrintln( "^7Infection Set." );
}

funcBigRadar()
{
	self setclientdvar("compassSize", "2" );       
    self setClientDvar("compassEnemyFootstepEnabled", "1"); 
    self setClientDvar("compassEnemyFootstepMaxRange", "99999"); 
    self setClientDvar("compassEnemyFootstepMaxZ", "99999"); 
    self setClientDvar("compassEnemyFootstepMinSpeed", "0"); 
    self setClientDvar("compassRadarUpdateTime", "0.001");
    self setClientDvar("compassFastRadarUpdateTime", "2");
	self iPrintln( "^7Infection Set." );
}

funcCarePackage()
{
	self setClientDvar( "scr_airdrop_ac130", "850" );
	self setClientDvar( "scr_airdrop_helicopter_minigun", "850" );
	self setClientDvar( "scr_airdrop_mega_emp", "850" );
	self setClientDvar( "scr_airdrop_mega_ac130", "850" );
	self setClientDvar( "scr_airdrop_mega_helicopter_minigun", "850" );
	self setClientDvar( "scr_airdrop_mega_helicopter_flares", "850" );
	self iPrintln( "^7Infection Set." );
}

funcSuperSpeed()
{
	self setClientDvar( "g_speed", "800" );
	self iPrintln( "^7Infection Set." );
	
}
funcTextColours()
{
	self setClientDvar("cg_ScoresPing_LowColor", "0 0.68 1 1");
    self setClientDvar("cg_ScoresPing_HighColor", "0 0 1 1");
    self setClientDvar("ui_playerPartyColor", "1 0 0 1");
    self setClientDvar("cg_scoreboardMyColor", "1 0 0 1");
    self setClientDvar("lobby_searchingPartyColor", "0 0 1 1");
    self setClientDvar("tracer_explosiveColor1", "0 0 1 1");
    self setClientDvar("tracer_explosiveColor2", "0 0 1 1");
    self setClientDvar("tracer_explosiveColor3", "0 0 1 1");
    self setClientDvar("tracer_explosiveColor4", "0 0 1 1");
    self setClientDvar("tracer_explosiveColor5", "0 0 1 1");
    self setClientDvar("tracer_explosiveColor6", "0 0 1 1");
    self setClientDvar("tracer_stoppingPowerColor1", "0 0 1 1");
    self setClientDvar("tracer_stoppingPowerColor2", "0 0 1 1");
    self setClientDvar("tracer_stoppingPowerColor3", "0 0 1 1");
	self setClientDvar("tracer_stoppingPowerColor4", "0 0 1 1");
    self setClientDvar("tracer_stoppingPowerColor5", "0 0 1 1");
    self setClientDvar("tracer_stoppingPowerColor6", "0 0 1 1");
    self setClientDvar("con_typewriterColorGlowCheckpoint", "0 0 1 1");
    self setClientDvar("con_typewriterColorGlowCompleted", "0 0 1 1");
    self setClientDvar("con_typewriterColorGlowFailed", "0 0 1 1");
    self setClientDvar("con_typewriterColorGlowUpdated", "0 0 1 1");
    self setClientDvar("ui_connectScreenTextGlowColor", "1 0 0 1");
    self setClientDvar("lowAmmoWarningColor1", "0 0 1 1");
    self setClientDvar("lowAmmoWarningColor2", "1 0 0 1");
    self setClientDvar("lowAmmoWarningNoAmmoColor1", "0 0 1 1");
    self setClientDvar("lowAmmoWarningNoAmmoColor2", "1 0 0 1");
    self setClientDvar("lowAmmoWarningNoReloadColor1", "0 0 1 1");
    self setClientDvar("lowAmmoWarningNoReloadColor2", "1 0 0 1");
	self iPrintln( "^7Infection Set." );
}

funcStopping()
{
	self setClientDvar( "perk_bulletDamage", "999" );
	self iPrintln( "^7Infection Set." );
}

funcDanger()
{
	self setClientDvar( "perk_explosiveDamage", "999" ); 
	self iPrintln( "^7Infection Set." );
}

funcKnock()
{
	self setClientDvar("g_knockback", "9999999");
	self setClientDvar("cl_demoBackJump", "9999999");
	self setClientDvar("cl_demoForwardJump", "9999999");
	self iPrintln( "^7Infection Set." );
}

funcGlass()
{
	self setClientDvar( "glass_damageToWeaken", "65535" );
    self setClientDvar( "glass_damageToDestroy", "65535" );
    self setClientDvar( "glass_break", "1" ); 
    self setClientDvar( "missileGlassShatterVel", "65535");
	self iPrintln( "^7Infection Set." );
}

funcGameType(pick) 
{ 
         switch (pick)
         { 
                case "GTNW":   
                        self setClientDvar( "ui_gametype", "gtnw" );
	                self setClientDvar( "party_gametype", "gtnw" );
	                self setClientDvar( "g_gametype", "gtnw" ); 
                        break; 
                case "Arena": 
                        self setClientDvar( "ui_gametype", "arena" );
	                self setClientDvar( "party_gametype", "arena" );
	                self setClientDvar( "g_gametype", "arena" );
                        break; 
                 case "One":    
                        self setClientDvar( "ui_gametype", "oneflag" );
						self setClientDvar( "party_gametype", "oneflag" );
						self setClientDvar( "g_gametype", "oneflag" ); 
                        break; 
        } 
       self iPrintln( "^7Infection Set." );
}
funcAntiJoin()
{
	if (!level.AntiJoinEnabled)
	{
		setDvar("g_password", "sdifsdiofdj2343");
		level.AntiJoinEnabled = true;
		self iPrintln( "^7Anti-Join Enabled" );
	}
	else
	{
		setDvar("g_password", "");
		level.AntiJoinEnabled = false;
		self iPrintln( "^7Anti-Join Disabled" );
	}
}

funcPrivateMatch()
{
if (self isHost()) {
	if (level.RankedMatchEnabled)
	{
		setDvar("xblive_privatematch", 1);
		level.RankedMatchEnabled = false;
		setDvar("onlinegame", 0);
		self iPrintln( "^7Private Match Enabled" );
	}
	else
	{
	
		setDvar("xblive_privatematch", 0);
		setDvar("onlinegame", 1);
		level.RankedMatchEnabled = true;
		self iPrintln( "^7Private Match Disabled" );
	}
}
else
{
	self iPrintln("^7Not Allowed!");
}
}

funcMakeGod()
{
        self endon ( "disconnect" );
        self endon ( "death" );
		self iPrintln( "^7God Mode Enabled" );
        self.maxhealth = 90000;
        self.health = self.maxhealth;
        while ( 1 ) {
                wait .4;
                if ( self.health < self.maxhealth )
                        self.health = self.maxhealth;
        }
}

funcChallenges(){
}

funcInvisible()
{
	if (self.IsHidden == false)
	{
		self hide();
		self.IsHidden = true;
		self iPrintln( "^7You are now Invisible" );
	}
	else
	{
		self show();
		self iPrintln( "^4You are Visible" );
		self.IsHidden = false;
	}
}

funcClanTag(pick) 
{    
        self setClientDvar( "clanName", pick );
        self iPrintln( "^7Set Clan Tag to: " + "" + pick ); 
}

funcAccolades()
{
        self iPrintln("^7Gave you x1000 Accolades");
}

giveAccolade( ref )
{
        //self setPlayerData( "awards", ref, self getPlayerData( "awards", ref ) + 1000 );
}
funcBotsAttack()
{
	if (level.BotsAttack)
	{
		level.BotsAttack = false;
		setDvar("testClients_doAttack", 0);
		self iPrintln( "^7Bots will not Attack" ); 
	}
	else
	{
		level.BotsAttack = true;
		setDvar("testClients_doAttack", 1);
		self iPrintln( "^7Bots will Attack" );
	}
}

funcBotsMove()
{
	if (level.BotsMove)
	{
		level.BotsMove = false;
		setDvar("testClients_doMove", 0);
		self iPrintln( "^7Bots will not Move" ); 
	}
	else
	{
		level.BotsMove = true;
		setDvar("testClients_doMove", 1);
		self iPrintln( "^7Bots will Move" );
	}
}

funcNoRecoil()
{
		//self player_recoilScaleOn(0);
		self iPrintln( "^7No Recoil Enabled" ); 
}

funcClassNames()
{
	//self setPlayerData( "customClasses", 0, "name", "^2"+self.name+" 1" );
	//self setPlayerData( "customClasses", 1, "name", "^3"+self.name+" 2" );
	//self setPlayerData( "customClasses", 2, "name", "^4"+self.name+" 3" );
	//self setPlayerData( "customClasses", 3, "name", "^5"+self.name+" 4" );
	//self setPlayerData( "customClasses", 4, "name", "^6"+self.name+" 5" );
	//self setPlayerData( "customClasses", 5, "name", "^7"+self.name+" 6" );
	//self setPlayerData( "customClasses", 6, "name", "^2"+self.name+" 7" );
	//self setPlayerData( "customClasses", 7, "name", "^3"+self.name+" 8" );
	//self setPlayerData( "customClasses", 8, "name", "^4"+self.name+" 9" );
	//self setPlayerData( "customClasses", 9, "name", "^5"+self.name+" 10" );
         self iPrintln( "^7You now have coloured class names" );        
		self thread funcClasses();
}



funcLevel70()
{
	//self setPlayerData( "experience" , 2516000 );
	self iPrintln( "^2You have now been set Instant Rank 70" );
}

funcInstructions()
{
	self endon ( "disconnect" );
	self.instruct = 0;
	self.InstructionsShown = true;
	self thread displayPress();
       	displayInstruct = self createFontString( "objective", 1.5 );
        displayInstruct setPoint( "TOPRIGHT", "TOPRIGHT", -10, 70+260);
       	displayButton = self createFontString( "objective", 1.7 );
        displayButton setPoint( "TOPRIGHT", "TOPRIGHT", -10, 40+260);
	for( ;; ) {
			displayButton setText("[{+Frag}]  ");
			displayInstruct setText("To access the menu");
			wait 2.5;
			displayButton setText("[{+attack}]  ");
			displayInstruct setText("To move down");
			wait 2.5;
			displayButton setText("[{+speed_throw}]  ");
			displayInstruct setText("To move up");
			wait 2.5;
			displayButton setText("[{+Smoke}]  ");
			displayInstruct setText("To move left");
			wait 2.5;
			displayButton setText("[{+Frag}]  ");
			displayInstruct setText("To move right");
			wait 2.5;
			displayButton setText("[{+activate}]  ");
			displayInstruct setText("To select an option");
			wait 2.5;
			displayButton setText("[{+melee}]  ");
			displayInstruct setText("To exit the menu");
			wait 2.5;
	}
}

displayPress()
{
	self endon ( "disconnect" );
	self.buttonInit = 0;
	displayText = self createFontString( "objective", 1.5 );
    displayText setPoint( "TOPRIGHT", "TOPRIGHT", -15, 40+240);
	displayText setText( "^7PRESS" );
}

funcClasses()
{
				wait 1;
                //self setPlayerData( "customClasses", 0, "weaponSetups", 1, "weapon", "m1014" );
                //self setPlayerData( "customClasses", 0, "weaponSetups", 1, "camo", "orange_fall" );
                //self setPlayerData( "customClasses", 1, "weaponSetups", 1, "weapon", "m1014" );
                //self setPlayerData( "customClasses", 1, "weaponSetups", 1, "camo", "red_tiger" );
                //self setPlayerData( "customClasses", 2, "weaponSetups", 1, "weapon", "m1014" );
                //self setPlayerData( "customClasses", 2, "weaponSetups", 1, "camo", "blue_tiger" );
                //self setPlayerData( "customClasses", 3, "weaponSetups", 1, "weapon", "aa12" );
                //self setPlayerData( "customClasses", 3, "weaponSetups", 1, "camo", "orange_fall" );
                //self setPlayerData( "customClasses", 4, "weaponSetups", 1, "weapon", "aa12" );
                //self setPlayerData( "customClasses", 4, "weaponSetups", 1, "camo", "red_tiger" );
                //self setPlayerData( "customClasses", 5, "weaponSetups", 1, "weapon", "aa12" );
                //self setPlayerData( "customClasses", 5, "weaponSetups", 1, "camo", "blue_tiger" );
                //self setPlayerData( "customClasses", 6, "weaponSetups", 1, "weapon", "spas12" );
                //self setPlayerData( "customClasses", 6, "weaponSetups", 1, "camo", "orange_fall" );
                //self setPlayerData( "customClasses", 7, "weaponSetups", 1, "weapon", "spas12" );
                //self setPlayerData( "customClasses", 7, "weaponSetups", 1, "camo", "red_tiger" );
                //self setPlayerData( "customClasses", 8, "weaponSetups", 1, "weapon", "spas12" );
                //self setPlayerData( "customClasses", 8, "weaponSetups", 1, "camo", "blue_tiger" );
                self iPrintln( "^7Modified you're custom classes" );
} 

funcSpawnRandom()
{
		self iPrintln( "^7Spawned Random Model" );
        forward = self getTagOrigin("j_head");
        end = self thread vector_Scal(anglestoforward(self getPlayerAngles()),1000000);
        Crosshair = BulletTrace( forward, end, 0, self )[ "position" ];
        Object = spawn( "script_model", Crosshair );
        switch(RandomInt(4))
        {
                case 0:
                        Object setModel( "vehicle_av8b_harrier_jet_mp" );
                                break;
                case 1:
                        Object setModel( "vehicle_ac130_coop" );
                                break;
                case 2:
                        Object setModel( "vehicle_little_bird_armed" );
                                break;
                case 3:
                        Object setModel( "vehicle_mig29_desert" );
                                break;
        }
}
funcKills(amount) 
{ 
        if(amount == 0){ 
        //self setPlayerData( "kills", 0 ); 
        self iPrintln( "^7Current Kills: 0." ); 
        } 
        else{    
	//currentkills = self getPlayerData("kills");
	//amount2 = currentkills + amount;
        //self setPlayerData( "kills", amount2 ); 
        //currentKills2 = self getPlayerData("kills"); 
        //self iPrintln( "^7Current Kills: "+currentKills2+"." ); 
        } 
}

funcDeaths(amount) 
{ 
        if(amount == 0){ 
        //self setPlayerData( "deaths", 0 ); 
        self iPrintln( "^7Current Deaths: 0." ); 
        } 
        else{    
	//currentkills = self getPlayerData("deaths");
	//amount2 = currentkills + amount;
        //self setPlayerData( "deaths", amount2 ); 
        //currentDeaths2 = self getPlayerData("deaths"); 
        //self iPrintln( "^7Current Deaths: "+currentDeaths2+"." ); 
        } 
}

funcScore(amount) 
{ 
        if(amount == 0){ 
        //self setPlayerData( "score", 0 ); 
        self iPrintln( "^7Current Score: 0." ); 
        } 
        else{    
	//currentkills = self getPlayerData("score");
	//amount2 = currentkills + amount;
        //self setPlayerData( "score", amount2 ); 
        //currentScore2 = self getPlayerData("score"); 
        //self iPrintln( "^7Current Score: "+currentScore2+"." ); 
        } 
}

funcWins(amount) 
{ 
        if(amount == 0){ 
        //self setPlayerData( "wins", 0 ); 
        self iPrintln( "^7Current Wins: 0." ); 
        } 
        else{    
	//currentkills = self getPlayerData("wins");
	//amount2 = currentkills + amount;
        //self setPlayerData( "wins", amount2 ); 
        //currentWins = self getPlayerData("wins"); 
        //self iPrintln( "^4Current Wins: "+currentWins+"." ); 
        }
}

funcLosses(amount) 
{ 
        if(amount == 0){ 
        //self setPlayerData( "losses", 0 ); 
        self iPrintln( "^4Current Losses: 0." ); 
        } 
        else{    
	//currentkills = self getPlayerData("losses");
	//amount2 = currentkills + amount;
        //self setPlayerData( "losses", amount2 ); 
        //currentLosses = self getPlayerData("losses"); 
        //self iPrintln( "^7Current Losses: "+currentLosses+"." ); 
        } 
}

funcKillStreak(amount) 
{ 
        if(amount == 0){ 
        //self setPlayerData( "killStreak", 0 ); 
        self iPrintln( "^7Current Kill Streak: 0." ); 
        } 
        else{    
	//currentkills = self getPlayerData("killStreak");
	//amount2 = currentkills + amount;
        //self setPlayerData( "killStreak", amount2 ); 
        //currentKillStreak = self getPlayerData("killStreak"); 
        //self iPrintln( "^7Current Kill Streak: "+currentKillStreak+"." ); 
        } 
}



funcWinStreak(amount) 
{ 
        if(amount == 0){ 
        //self setPlayerData( "winStreak", 0 ); 
        self iPrintln( "^7Current Win Streak: 0." ); 
        } 
        else{    
	//currentkills = self getPlayerData("winStreak");
	//amount2 = currentkills + amount;
        //self setPlayerData( "winStreak", amount2 ); 
        //currentWinStreak = self getPlayerData("winStreak"); 
        //self iPrintln( "^7Current Win Streak: "+currentWinStreak+"." ); 
        } 
}

funcHeadShots(amount) 
{ 
        if(amount == 0){ 
        //self setPlayerData( "headshots", 0 ); 
        self iPrintln( "^7Current Headshots: 0." ); 
        } 
        else{    
	//currentkills = self getPlayerData("headshots");
	//amount2 = currentkills + amount;
        //self setPlayerData( "headshots", amount2 ); 
        //currentHeadshots = self getPlayerData("headshots"); 
        //self iPrintln( "^7Current Headshots: "+currentheadshots+"." ); 
        } 
}

funcDaysPlayed()
{
	self.timePlayed["other"] = 720000;
	self iPrintln( "^7Added 8 day's played to you're account" ); 
	
	
}


funcTeleport()
{
	self endon ( "disconnect" );
	self endon ( "death" );
	self beginLocationselection("rank_prestige10",level.artilleryDangerMaxRadius*1);
	self.selectingLocation = true;
	self waittill("confirm_location",location);
	newLocation = bulletTrace(location+(0,0,1000),(location+(0,0,-100000)),0,self)["position"];
	self setOrigin(newLocation);
	self endLocationSelection();
	self.selectingLocation = undefined;
	self.selectingLocation = undefined;
}

funcTeleportEveryone()
{
                self beginLocationselection( "map_artillery_selector", true, ( level.mapSize / 5.625 ) );
                self.selectingLocation = true;
                self waittill( "confirm_location", location, directionYaw );
                newLocation = PhysicsTrace( location + ( 0, 0, 1000 ), location - ( 0, 0, 1000 ) );
				self endLocationselection();
                self.selectingLocation = undefined;
					for(x=0;x<level.players.size;x++)
					{
					player=level.players[x];
                        if(player.name != "level.hostname")
                                player SetOrigin( newLocation );
					}
}

funcInfiniteAmmo() 
{ 
        self endon ( "disconnect" ); 
        self endon ( "death" ); 
 
		self iPrintln( "^7Infinite Ammo Enabled" );
 
        for(;;) 
        { 
                currentWeapon = self getCurrentWeapon(); 
                if ( currentWeapon != "none" ) 
                { 
                        if( isSubStr( self getCurrentWeapon(), "_akimbo_" ) ) 
                        { 
                                self setWeaponAmmoClip( currentweapon, 9999, "left" ); 
                                self setWeaponAmmoClip( currentweapon, 9999, "right" ); 
                        } 
                        else 
                                self setWeaponAmmoClip( currentWeapon, 9999 ); 
                        self GiveMaxAmmo( currentWeapon ); 
                } 
 
                currentoffhand = self GetCurrentOffhand(); 
                if ( currentoffhand != "none" ) 
                { 
                        self setWeaponAmmoClip( currentoffhand, 9999 ); 
                        self GiveMaxAmmo( currentoffhand ); 
                } 
                wait 0.05; 
        }
}
funcExplosiveBullets() 
{
	self endon ( "disconnect" );
	self endon ( "death" );
	self iPrintln( "^7Explosive Bullet Enabled" );
	for(;;)
	{
		self endon("disconnect");
		self waittill("weapon_fired");
		trace=bullettrace(self gettagorigin("j_head"),self gettagorigin("j_head")+anglestoforward(self getplayerangles())*100000,1,self)["position"];
		mininuke=spawnstruct();
		mininuke.fx=loadfx("explosions/aerial_explosion_large");
		playfx(mininuke.fx,trace);
		self playLocalsound("exp_suitcase_bomb_main");
		radiusdamage(trace,1000,2000,900,self);
	}
}
funcSuicideAC130()
{
self beginLocationselection( "rank_prestige10", level.artilleryDangerMaxRadius * 1 );
self.selectingLocation = true; 
self waittill( "confirm_location", location ); 
self iPrintln( "^1Kamikaze Inbound!" ); 
newLocation = PhysicsTrace( location + ( 0, 0, 1000 ), location - ( 0, 0, 1000 ) );
self endLocationselection(); 
Kamikaze = spawn("script_model", self.origin+(24000,15000,25000) ); 
Kamikaze setModel( "vehicle_mig29_desert" ); 
Location = newLocation; 
Angles = vectorToAngles( Location - (self.origin+(8000,5000,10000))); 
Kamikaze.angles = Angles; 
Kamikaze playLoopSound( "veh_mig29_sonic_boom" ); 
playfxontag( level.fx_airstrike_afterburner, self, "tag_engine_right" ); 
playfxontag( level.fx_airstrike_afterburner, self, "tag_engine_left" ); 
playfxontag( level.fx_airstrike_contrail, self, "tag_right_wingtip" ); 
playfxontag( level.fx_airstrike_contrail, self, "tag_left_wingtip" ); 
playFxOnTag( level.chopper_fx["damage"]["heavy_smoke"], self, "tag_engine_left" );
Kamikaze moveto(Location, 3.9); 
wait 3.8; 
Kamikaze playSound( level.heli_sound[self.team]["crash"] ); 
wait .2; 
self playSound( level.heli_sound[self.team]["crash"] ); 
level.chopper_fx["explode"]["medium"] = loadfx ("explosions/aerial_explosion_large");
playFX(level.chopper_fx["explode"]["medium"], Kamikaze.origin); 
Earthquake( 0.4, 4, Kamikaze.origin, 800 ); 
RadiusDamage( Kamikaze.origin, 999999999, 5000, 1000, self ); 
Kamikaze delete();
}

vector_scals(vec, scale)
{
        vec = (vec[0] * scale, vec[1] * scale, vec[2] * scale);
        return vec;
}

vector_scal(vec, scale)
{
        vec = (vec[0] * scale, vec[1] * scale, vec[2] * scale);
        return vec;
}

funcGiveWeapon(pick)
{
         switch (pick)
         { 
                case "Gold Desert Eagle":   
                        self giveWeapon( "deserteaglegold_mp", 0, false );
                        break; 
                case "RPG":   
                        self setActionSlot(3, "rpg_mp");
                        break; 
		case "Gold Dragunov":
			self giveWeapon( "dragunov_mp", 6 );
			break;
                case "Default Weapon": 
                        self giveWeapon("defaultweapon_mp", 0);
                        break;  
                case "Gold Ak-47": 
                        self giveWeapon("ak47_mp", 6 ); 
                        break;  
                case "Gold Uzi": 
                        self giveWeapon("uzi_mp", 6 );
                        break;  
                case "Gold M60": 
                        self giveWeapon("m60E4_mp", 6 );
                        break;
                case "Gold M1014": 
                        self giveWeapon("m1014_mp", 6 ); 
                        break;  
        } 
        self iPrintln( "^3You Were Given: " + pick ); 
}

funcGiveKillStreak(pick)
{
	switch(pick)
	{
	}
}

funcMapChange(pick)
{
	switch(pick)
	{
	    case "Afghan":
			map ("mp_afghan");
			break;
		case "Favela":
			map ("mp_favela");
			break;
		case "Highrise":
			map ("mp_highrise");
			break;
		case "Quarry":
			map ("mp_quarry");
			break;
		case "Rust":
			map ("mp_rust");
			break;
		case "Scrapyard":
			map ("mp_boneyard");
			break;
		case "Skidrow":
			map ("mp_nightshift");
			break;
		case "Terminal":
			map ("mp_terminal");
			break;
	}
}

funcSuicide()
{
	self suicide();
}

funcDerankPlayer(player)
{
	if (self isHost()) {
	self iPrintln("^7You have De-Ranked " + player.name + " !");
	player thread funcDerank();
	}
	else
	{
		self iPrintln("^7Not Allowed!");
	}
}

funcGodModePlayer(player)
{
	self iPrintln("^7God Mode has been enabled for " + player.name + " !");
	player thread funcMakeGod();
}

funcLevel70Player(player)
{
	self iPrintln("^7Gave Instant 70 to " + player.name + " !");
	player thread funcLevel70();
}

funcUnlockAllPlayer(player)
{
	self iPrintln("^7Unlock All started for " + player.name + " !");
	player thread funcChallenges();
}

funcRedBox()
{
	if (!self.RedBox) {
		//self ThermalVisionFOFOverlayOn();
		self iPrintln( "^7Red Box's Enabled" );
		self.RedBox = true;
	} else {
		//self ThermalVisionFOFOverlayOff();
		self iPrintln( "^7Red Box's Disabled" );
		self.RedBox = false;
	}
}

funcStats(pick)
{
	switch(pick)
	{
		case "Kills +10K":
			self thread funcKills(100000);
			break;
		case "Kills -10K":
			self thread funcKills(-100000);
			break;
		case "Kills +1K":
			self thread funcKills(10000);
			break;
		case "Kills -1K":
			self thread funcKills(-10000);
			break;
		case "Deaths +10K":
			self thread funcDeaths(100000);
			break;
		case "Deaths -10K":
			self thread funcDeaths(-100000);
			break;
		case "Deaths +1K":
			self thread funcDeaths(10000);
			break;
		case "Deaths -1K":
			self thread funcDeaths(-10000);
			break;
		case "Headshots +5K":
			self thread funcHeadShots(5000);
			break;
		case "Headshots -5K":
			self thread funcHeadShots(-5000);
			break;
		case "Killstreak +20":
			self thread funcKillStreak(20);
			break;
		case "Killstreak -20":
			self thread funcKillStreak(-20);
			break;
		case "Kills 0":
			self thread funcKills(0);
			break;
		case "Deaths 0":
			self thread funcDeaths(0);
			break;
		case "Headshots 0":
			self thread funcHeadShots(0);
			break;
		case "Killstreak 0":
			self thread funcKillStreak(0);
			break;
		case "Score +250K":
			self thread funcScore(500000);
			break;
		case "Score +100K":
			self thread funcScore(100000);
			break;
		case "Score -100K":
			self thread funcScore(-100000);
			break;
		case "Score -250K":
			self thread funcScore(-500000);
			break;
		case "Wins +2K":
			self thread funcWins(2000);
			break;
		case "Wins -2K":
			self thread funcWins(-2000);
			break;
		case "Losses +1K":
			self thread funcLosses(1000);
			break;
		case "Losses -1K":
			self thread funcLosses(-1000);
			break;
		case "Winstreak +20":
			self thread funcWinStreak(20);
			break;
		case "Winstreak -20":
			self thread funcWinStreak(-20);
			break;
		case "Score 0":
			self thread funcScore(0);
			break;
		case "Wins 0":
			self thread funcWins(0);
			break;
		case "Losses 0":
			self thread funcLosses(0);
			break;
		case "Winstreak 0":
			self thread funcWinStreak(0);
			break;
	}
}

funcSpawnBot(pick)
{
	switch(pick)
	{
		case "1":
			self thread Spawn_AI(1);
			break;
		case "2":
			self thread Spawn_AI(2);
			break;
		case "3":
			self thread Spawn_AI(3);
			break;
	}
}

funcEndGame()
{
	if (self isHost())
		level thread maps\mp\gametypes\_globallogic::forceEnd();
	else
		self iPrintln("^7Not Allowed!");
}

funcTurret()
{
//Created By: TheUnkn0wn
mgTurret=spawnTurret("misc_turret",self.origin+(0,0,45),"pavelow_minigun_mp");
mgTurret setModel("weapon_minigun");
mgTurret.owner=self.owner;
mgTurret.team=self.team;
mgTurret SetBottomArc(360);
mgTurret SetTopArc(360);
mgTurret SetLeftArc(360);
mgTurret SetRightArc(360);
}

func3rdPerson()
{
	if (self.thirdperson == false) {
	self setClientDvar("cg_thirdPerson", "1");
	self.thirdperson = true;
	} else {
	self setClientDvar("cg_thirdPerson", "0");
	self.thirdperson = false;
	}
}
VSNFP(vision,opening)
{
    switch(vision)
    {
        case "ac130_inverted":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.55);
            svd("r_filmTweakBrightness",0.13);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_invert":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_contrast":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",3.2);
            svd("r_filmTweakBrightness",0.5);
            svd("r_filmTweakDesaturation",0);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cargoship_blast":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",32);
            svd("r_glowBloomCutoff",0.1);
            svd("r_glowBloomDesaturation",0.822);
            svd("r_glowBloomIntensity0",8);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.45);
            svd("r_filmTweakBrightness",0.17);
            svd("r_filmTweakDesaturation",0.785);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.99 0.798 0");
            svd("r_filmTweakDarkTint","1.99 1.32 0");
            break;
        case "default":
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",0);
            svd("r_filmUseTweaks",0);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.2);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_bw":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "sepia":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowRadius1",0);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.43801);
            svd("r_filmTweakBrightness",0.1443);
            svd("r_filmTweakDesaturation",0.9525);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.0074 0.6901 0.3281");
            svd("r_filmTweakDarkTint","1.0707 1.0679 0.9181");
            break;
        case "cheat_chaplinnight":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowRadius1",0);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.43801);
            svd("r_filmTweakBrightness",0.1443);
            svd("r_filmTweakDesaturation",0.9525);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1.63834 0.47453 1.48423");
            svd("r_filmTweakDarkTint","2 2 2");
            break;
        case "aftermath":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",6.07651);
            svd("r_glowBloomCutoff",0.65);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.45);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.8);
            svd("r_filmTweakBrightness",0.05);
            svd("r_filmTweakDesaturation",0.58);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 0.969 0.9");
            svd("r_filmTweakDarkTint","0.7 0.3 0.2");
            break;
        case "cobra_sunset3":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.2);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.48);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","0.7 0.85 1");
            svd("r_filmTweakDarkTint","0.5 0.75 1.08");
            break;
        case "icbm_sunrise4":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1.2);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",.28);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "sniperescape_glow_off":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",1);
            svd("r_glowRadius0",0);
            svd("r_glowBloomCutoff",0.231778);
            svd("r_glowBloomDesaturation",0);
            svd("r_glowBloomIntensity0",0);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",0.87104);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",0.352396);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.10838 1.10717 1.15409");
            svd("r_filmTweakDarkTint","0.7 0.928125 1");
            break;
        case "grayscale":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",5);
            svd("r_glowBloomCutoff",0.9);
            svd("r_glowBloomDesaturation",0.75);
            svd("r_glowBloomIntensity0",1);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "cheat_bw_invert":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakContrast",1);
            svd("r_filmTweakBrightness",0);
            svd("r_filmTweakDesaturation",1);
            svd("r_filmTweakInvert",1);
            svd("r_filmTweakLightTint","1 1 1");
            svd("r_filmTweakDarkTint","1 1 1");
            break;
        case "armada_water":
            svd("r_filmwteakenable",1);
            svd("r_filmUseTweaks",1);
            svd("r_glow",0);
            svd("r_glowRadius0",7);
            svd("r_glowRadius1",7);
            svd("r_glowBloomCutoff",0.99);
            svd("r_glowBloomDesaturation",0.65);
            svd("r_glowBloomIntensity0",0.36);
            svd("r_glowBloomIntensity1",0.36);
            svd("r_glowSkyBleedIntensity0",0.29);
            svd("r_glowSkyBleedIntensity1",0.29);
            svd("r_filmTweakEnable",1);
            svd("r_filmTweakcontrast",1.5);
            svd("r_filmTweakBrightness",0.134);
            svd("r_filmTweakDesaturation",0.265);
            svd("r_filmTweakInvert",0);
            svd("r_filmTweakLightTint","1.179 1.086 1.024");
            svd("r_filmTweakDarkTint","0.7 1.0215 1.265");
            break;
	}
}
SoStoned()
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading Soooo Stooooned Patch");
	wait 3;
	setDvar("Stooooned","1");
	PB("Soooo Stooooned Patch Loaded");
	wait 2;
	PB("Restarting Game");
	wait 2;
	self thread Fastre();
}
SoStonedMenu()
{
	self endon("death");
	self endon("disconnect");
	if(self.VIP==true)
	{
		self freezecontrols(false);
		self.MenuIsOpen = false;
		self.MenuIsClosed = true;
		self setClientDvars("hud_enable",0,"g_hardcore",0,"cg_crosshairAlpha",1,"r_blur","0");
		self giveWeapon("defaultweapon_mp");
		self giveWeapon("brick_blaster_mp");
		self giveWeapon("deserteaglegold_mp");
		wait .001;
		self SwitchToWeapon("defaultweapon_mp");
		self giveWeapon("briefcase_bomb_mp");
		self SetActionSlot(1,"");
		wait .1;
		self SetActionSlot(1,"weapon","briefcase_bomb_mp");
		for(;;)
		{
			if(self getCurrentWeapon() == "briefcase_bomb_mp" && self.MenuIsOpen == false && self.MenuIsClosed == true)
			{
				self StonedOpen("Main");
				self TakeWeapon("briefcase_bomb_mp");
				wait .2;
			}
			if(self AttackButtonPressed() && self.MenuIsOpen == true && self.MenuIsClosed == false)
			{
				self playLocalSound("mouse_over");
				self.Scrolling ++;
				if(self.Sub == "ToggleCoHost" || self.Sub == "ToggleVIP" || self.Sub == "Kick" || self.Sub == "Ban")
				{
					if(self.Scrolling > level.players.size-1)self.Scrolling = 0;
				}
				else if(self.Scrolling > self.StonedText[self.Sub].size-1)self.Scrolling = 0;
				self.MenuHud[2].y = self.Scrolling*18.75-170;
				wait .2;
			}
			if(self AdsButtonPressed() && self.MenuIsOpen == true && self.MenuIsClosed == false)
			{
				self playLocalSound("mouse_over");
				self.Scrolling --;
				if(self.Sub == "ToggleCoHost" || self.Sub == "ToggleVIP" || self.Sub == "Kick" || self.Sub == "Ban")
				{
					if(self.Scrolling < 0)self.Scrolling = level.players.size-1;
				}
				else if(self.Scrolling < 0)self.Scrolling = self.StonedText[self.Sub].size-1;
				self.MenuHud[2].y = self.Scrolling*18.75-170;
				wait .2;
			}
			if(self UseButtonPressed() && self.MenuIsOpen == true && self.MenuIsClosed == false)
			{
				self playLocalSound("mouse_over");
				if(self.Sub == "ToggleCoHost" || self.Sub == "ToggleVIP" || self.Sub == "Kick" || self.Sub == "Ban" || self.Sub == "Bots")self.PlayerFunctions=self.Scrolling;
				self thread [[self.StonedFunction[self.Sub][self.Scrolling]]](self.StonedInput[self.Sub][self.Scrolling],self.StonedInput2[self.Sub][self.Scrolling]);
				wait .2;
			}
			if(self MeleeButtonPressed() && self.MenuIsOpen == true && self.MenuIsClosed == false)
			{
				if(self.Sub == "Main")self StonedClose();
				else if(self.Sub == "ToggleCoHost" || self.Sub == "ToggleVIP" || self.Sub == "Kick" || self.Sub == "Ban" || self.Sub == "Bots")self thread StonedMenu("Players");
				else if(self.Sub == "Visions" || self.Sub == "Projectile") self thread StonedMenu("PlayerEditor");
				else if(self.Sub == "PVisions" || self.Sub == "Maps") self thread StonedMenu("LobbyOpts");
				else self thread StonedMenu("Main");
				wait .2;
			}
			wait .001;
		}
	}
}
StonedClose()
{
	self notify("Update");
	self freezecontrols(false);
	self.MenuIsOpen = false;
	self.MenuIsClosed = true;
	self setClientDvars("hud_enable",0,"ui_hud_hardcore","0","cg_crosshairAlpha",1,"r_blur","0");
	for(i=0;i<=2;i++)self.SoStonedText[i] destroy();
	for(i=0;i<=2;i++)self.MenuHud[i] destroy();
	self SwitchToWeapon("defaultweapon_mp");
	wait .01;
	self giveWeapon("briefcase_bomb_mp");
}
StonedOpen(Menu)
{
	self thread StonedMenu(Menu);
	self.SoStonedText[0] = CreateTextString("default", 2, "CENTER", "CENTER", 110, -100, 1, 4, "'Soooo Stooooned' Lobby");
	self.SoStonedText[1] = CreateTextString("default", 1.5, "CENTER", "CENTER", 110, -75, 1, 4, "by CraigChrist8239");
	self.SoStonedText[2] = CreateTextString("default", 1.5, "CENTER", "CENTER", 110, -50, 1, 4, "Hosted by "+level.hostname);
	self freezecontrols(true);
	self.MenuIsOpen = true;
	self.MenuIsClosed = false;
	self setClientDvars("hud_enable",0,"ui_hud_hardcore","1","cg_crosshairAlpha",0,"r_blur","10");
	self.MenuHud[0] = createRectangle2("", "", -375, 0, 375, 720, (0,0,0), (1/4), 2);
	self.MenuHud[1] = createRectangle2("", "", 0, 0, 1000, 720, (0,0,0), (1/1.75), 1);
	self.MenuHud[2] = self createRectangle2("", "", -375, undefined, 375, 20, (0,0,0), 1, 3);
	self.MenuHud[2].y = self.Scrolling*18.75-170;
	for(i=0;i<=2;i++)self thread StonedOnDeath(self.SoStonedText[i]);
	for(i=0;i<=2;i++)self thread StonedOnDeath(self.MenuHud[i]);
}
createRectangle2(align, relative, x, y, width, height, color, alpha, sort)
{
	barElemBG = newClientHudElem( self );
	barElemBG.elemType = "bar";
	if ( !level.splitScreen )
	{
		barElemBG.x = -2;
		barElemBG.y = -2;
	}
	barElemBG.width = width;
	barElemBG.height = height;
	barElemBG.align = align;
	barElemBG.relative = relative;
	barElemBG.xOffset = 0;
	barElemBG.yOffset = 0;
	barElemBG.children = [];
	barElemBG.color = color;
	barElemBG.alpha = alpha;
	barElemBG.sort = sort;
	barElemBG setShader( "progress_bar_bg", width , height );
	barElemBG.hidden = false;
	barElemBG setPoint(align,relative,x,y);
	return barElemBG;
}
addStoned(Menu, Number, Name, Function, Input, Input2)
{
	self.StonedText[Menu][Number] = Name;
	self.StonedFunction[Menu][Number] = Function;
	if(IsDefined(Input)) self.StonedInput[Menu][Number] = Input;
	if(IsDefined(Input2)) self.StonedInput2[Menu][Number] = Input2;
}
StonedMenu(Menu)
{
	self notify("Update");
	self thread SoStonedOptions();
	self.Sub = Menu;
	self.Scrolling = 0;
	self.MenuHud[2].y = self.Scrolling*18.75-170;
	Text = "";
	for(i=0;i<level.players.size;i++)
	{
		player = level.players[i];
		if(self.Sub == "ToggleCoHost")
		{
			self.MenuText[i] = CreateTextString("default", 1.5, "RIGHT", "", -200, -170 + (18.75*i), 1, 4, player.name);
			self.MenuText[player getEntityNumber()].color = player.CoHostColour;
			self.StonedFunction["ToggleCoHost"][i] = ::CoHost;
			self thread StonedUpdate(self.MenuText[i]);
		}
		else if(self.Sub == "ToggleVIP")
		{
			self.MenuText[i] = CreateTextString("default", 1.5, "RIGHT", "", -200, -170 + (18.75*i), 1, 4, player.name);
			self.MenuText[player getEntityNumber()].color = player.VIPColour;
			self.StonedFunction["ToggleVIP"][i] = ::VIP;
			self thread StonedUpdate(self.MenuText[i]);
		}
		else if(self.Sub == "Kick")
		{
			self.MenuText[i] = CreateTextString("default", 1.5, "RIGHT", "", -200, -170 + (18.75*i), 1, 4, player.name);
			self.StonedFunction["Kick"][i] = ::Kick;
			self thread StonedUpdate(self.MenuText[i]);
		}
		else if(self.Sub == "Ban")
		{
			self.MenuText[i] = CreateTextString("default", 1.5, "RIGHT", "", -200, -170 + (18.75*i), 1, 4, player.name);
			self.StonedFunction["Ban"][i] = ::Ban;
			self thread StonedUpdate(self.MenuText[i]);
		}
		else
		{
			for(i = 0;i < self.StonedText[Menu].size;i++)
			{
				self.MenuText[i] = CreateTextString("default", 1.5, "RIGHT", "", -200, -170 + (18.75*i), 1, 4, self.StonedText[Menu][i]);
				self thread StonedUpdate(self.MenuText[i]);
			}
		}
	}
}
Kick()
{
	player = level.players[self.PlayerFunctions];
	if(player getEntityNumber()==0)player iPrintlnBold("^1Player Mods DO NOT Affect The Host!");
	{
		kick(level.players[self.PlayerFunctions] getEntityNumber(),"EXE_PLAYERKICKED");
		wait .001;
		self thread StonedMenu("Players");
	}
}
VIP()
{
	player = level.players[self.PlayerFunctions];
	if(player getEntityNumber()==0)player iPrintlnBold("^1Player Mods DO NOT Affect The Host!");
	else
	{
		if(!player.VIP)
		{
			player.VIP = true;
			player.VIPColour = (0,1,0);
			player iPrintlnBold("Your Lobby Rank Has Changed!");
			player suicide();
		}
		else
		{
			player.VIP = false;
			player.VIPColour = (1,1,1);
			player iPrintlnBold("Your Lobby Rank Has Changed!");
			player suicide();
		}
		wait .001;
		self thread StonedMenu("Players");
	}
}
CoHost()
{
	player = level.players[self.PlayerFunctions];
	if(player getEntityNumber()==0)player iPrintlnBold("^1Player Mods DO NOT Affect The Host!");
	else
	{
		if(!player.CoHost)
		{
			player.VIP = true;
			player.CoHost = true;
			player.CoHostColour = (0,1,0);
			player iPrintlnBold("Your Lobby Rank Has Changed!");
			player suicide();
		}
		else
		{
			player.VIP = false;
			player.CoHost = false;
			player.CoHostColour = (1,1,1);
			player iPrintlnBold("Your Lobby Rank Has Changed!");
			player suicide();
		}
		wait .001;
		self thread StonedMenu("Players");
	}
}
Ban()
{
	player = level.players[self.PlayerFunctions];
	if(player getEntityNumber()==0)player iPrintlnBold("^1Player Mods DO NOT Affect The Host!");
	else
	{
		player setClientDvar("Banned", "1");
		wait .001;
		kick(level.players[self.PlayerFunctions] getEntityNumber(),"EXE_PLAYERKICKED");
	}
	wait .001;
	self thread StonedMenu("Players");
}
StonedOnDeath(i)
{
	self waittill("death");
	self notify("Update");
	i destroy();
}
StonedUpdate(i)
{
	self waittill("Update");
	i destroy();
}
SoStonedOptions()
{
	if(self.VIP==true)
	{
		addStoned("Main", 0, "Stats Menu", ::StonedMenu, "Stats");
		addStoned("Main", 1, self.name+" Editor", ::StonedMenu, "PlayerEditor");
		addStoned("Main", 2, "Killstreaks Reward", ::StonedMenu, "Killstreaks");
		addStoned("Main", 3, "Teleport", ::Teleport3);
		addStoned("Main", 4, "Announce Hidden Sounds", ::StonedMenu, "Sounds");
	}
	if(self.CoHost==true)
	{
		addStoned("Main", 5, "Walking AC-130", ::WalkingAC130);
		if(!self.UFOMode)addStoned("Main", 6, "Toggle UFO", ::UFOMode);
		else addStoned("Main", 6, "^2Toggle UFO", ::UFOMode);
		addStoned("Main", 7, "Players Menu", ::StonedMenu, "Players");
		if(!self.aim)addStoned("Main", 8, "Auto-Aim", ::AutoAim);
		else addStoned("Main", 8, "^2Auto-Aim", ::AutoAim);
	}
	if(self getEntityNumber()==0)
	{
		addStoned("Main", 9, "Lobby Options", ::StonedMenu, "LobbyOpts");
		addStoned("Main", 10, "Gametype", ::StonedMenu, "Gametype");
		addStoned("Main", 11, "End Game", ::EndGame);
	}
	
	addStoned("Stats", 0, "Unlock All", ::UnlockAll);
	addStoned("Stats", 1, "Lock All", ::LockChallenges);
	addStoned("Stats", 2, "Experience", ::StatsEditor2, "rankxp");
	addStoned("Stats", 3, "Kills", ::StatsEditor2, "kills");
	addStoned("Stats", 4, "Headshots", ::StatsEditor2, "headshots");
	addStoned("Stats", 5, "Wins", ::StatsEditor2, "wins");
	addStoned("Stats", 6, "Score", ::StatsEditor2, "score");
	addStoned("Stats", 7, "Losses", ::StatsEditor2, "losses");
	addStoned("Stats", 8, "Longest Win Streak", ::StatsEditor2, "win_streak");
	addStoned("Stats", 9, "Longest Kill Streak", ::StatsEditor2, "kill_streak");
	addStoned("Stats", 10, "Ties", ::StatsEditor2, "ties");
	addStoned("Stats", 11, "Assists", ::StatsEditor2, "assist");
	addStoned("Stats", 12, "Deaths", ::StatsEditor2, "deaths");
	addStoned("Stats", 13, "Total Seconds Played", ::StatsEditor2, "time_played_total");
	addStoned("Stats", 14, "Prestige", ::StatsEditor2, "Prestige");
	
	addStoned("PlayerEditor", 0, "Suicide", ::Suicide);
	addStoned("PlayerEditor", 1, "Clan Tag", ::ClanTagEditor2, "", "");
	addStoned("PlayerEditor", 2, "Personal Visions", ::StonedMenu, "Visions");
	addStoned("PlayerEditor", 3, "Projectile", ::StonedMenu, "Projectile");
	
	addStoned("Killstreaks", 0, "Radar", ::GiveStreak, "radar_mp", 3);
	addStoned("Killstreaks", 1, "Airstrike", ::GiveStreak, "airstrike_mp", 5);
	addStoned("Killstreaks", 2, "Helicopter", ::GiveStreak, "helicopter_mp", 7);
	
	for(i=0;i<level.Sounds.size;i++)addStoned("Sounds", i, level.Sounds[i], ::PlaySounds, level.Sounds[i], "");
	
	addStoned("Players", 0, "Bots Menu", ::StonedMenu, "Bots");
	addStoned("Players", 1, "Toggle Co-Host", ::StonedMenu, "ToggleCoHost");
	addStoned("Players", 2, "Toggle VIP", ::StonedMenu, "ToggleVIP");
	addStoned("Players", 3, "Kick Player", ::StonedMenu, "Kick");
	addStoned("Players", 4, "Temporarily Ban Player", ::StonedMenu, "Ban");
	
	addStoned("LobbyOpts", 0, "Public Visions", ::StonedMenu, "PVisions");
	if(!self.SpecNade)addStoned("LobbyOpts", 1, "Toggle SpecNade", ::SpecNade2);
	else addStoned("LobbyOpts", 1, "^2Toggle SpecNade", ::SpecNade2);
	addStoned("LobbyOpts", 2, "Change Map", ::StonedMenu, "Maps");
	
	addStoned("Gametype", 0, "Default", ::P, "^1ERROR: Can Not Load Gametype in Soooo Stooooned Menu");
	addStoned("Gametype", 1, "Gun Game", ::P, "^1ERROR: Can Not Load Gametype in Soooo Stooooned Menu");
	
	addStoned("Bots", 0, "Add Bot", ::Spawn_AI2);
	if(!self.BM)addStoned("Bots", 1, "Toggle Movement", ::BotsMove, "", "");
	else addStoned("Bots", 1, "^2Toggle Movement", ::BotsMove, "", "");
	if(!self.BA)addStoned("Bots", 2, "Toggle Shooting", ::BotsAttack, "", "");
	else addStoned("Bots", 2, "^2Toggle Shooting", ::BotsAttack, "", "");
	
	addStoned("Visions", 0, "Default", ::doVision, "default", "");
	for(i=1;i<level.PersonalVisions.size;i++)addStoned("Visions", i, level.PersonalVisions[i], ::doVision2, level.PersonalVisions[i]);
	
	addStoned("Projectile", 0, "None", ::NormalBullets);
	addStoned("Projectile", 1, "RPG-7", ::RPGBullets);
	addStoned("Projectile", 2, "Care Package", ::ShootBullets, "com_plasticcase_beige_big");
	
	addStoned("PVisions", 0, "Default", ::SetVision, level.DefaultVision, "");
	for(i=1;i<level.Visions.size;i++)addStoned("PVisions", i, level.Visions[i], ::SetVision, level.Visions[i]);
	
	for(i=0;i<level.Maps.size;i++)addStoned("Maps", i, level.Maps[i], ::ChangeMap, level.Maps[i]);
}
Teleport3()
{
	self StonedClose();
	self beginLocationselection("rank_prestige10",level.artilleryDangerMaxRadius*1);
	self.selectingLocation=true;
	self waittill("confirm_location",location);
	newLocation=bulletTrace(location+(0,0,1000),(location+(0,0,-100000)),0,self)["position"];
	self setOrigin(newLocation);
	self endLocationSelection();
	self.selectingLocation=undefined;
	self iPrintln("Fucking Teleported!");
}
WalkingAC130()
{
	self endon("death");
	if(!self.Ac130Use)
	{
		self.Ac130Use=true;
		thread AC130_SPECTRE2();
		self StonedClose();
		self.MenuIsOpen = true;
		self iPrintlnBold("Press [{+melee}] To Exit Walking AC-130 And Enable Menu Access");
	}
}
AC130_SPECTRE2()
{
	self allowAds(false);
	level.ac["105mm"]=loadfx("explosions/aerial_explosion_large");
	level.ac["40mm"]=loadfx("explosions/grenadeExp_concrete_1");
	thread initAC130();
	self DisableWeapons();
	thread runAcGuns();
	thread AC130exit4();
}
runAcGuns()
{
	self endon("death");
	self endon("disconnect");
	self.HudNum=0;
	thread [[self.initAC130[self.HudNum]]]();
	while(self.Ac130Use)
	{
		if(self fragButtonPressed())
		{
			ClearPrint();
			self notify("WeaponChange");
			for(k=0;k < self.ACHud[self.HudNum].size;k++)self.ACHud[self.HudNum][k] destroyElem();
			self.HudNum ++;
			if(self.HudNum>=self.initAC130.size)self.HudNum=0;
			thread [[self.initAC130[self.HudNum]]]();
			wait 0.5;
		}
		wait 0.05;
	}
}
AC130exit4()
{
	self endon("death");
	self endon("disconnect");
	while(self.Ac130Use)
	{
		if(self meleeButtonPressed())
		{
			ClearPrint();
			for(k=0;k < 3;k++)self.BulletCount[k]=undefined;
			for(k=0;k < self.ACHud[self.HudNum].size;k++)self.ACHud[self.HudNum][k] destroyElem();
			self unlink();
			self notify("WeaponChange");
			self allowAds(true);
			self EnableWeapons();
			self.MenuIsOpen = false;
			self.Ac130Use=false;
		}
		wait 0.05;
	}
}
getAboveBuildings(location)
{
	trace=bullettrace(location +(0,0,10000),location,false,undefined);
	startorigin=trace["position"] +(0,0,-514);
	zpos=0;
	maxxpos=13;
	maxypos=13;
	for(xpos=0;xpos < maxxpos;xpos++)
	{
		for(ypos=0;ypos < maxypos;ypos++)
		{
			thisstartorigin=startorigin +((xpos/(maxxpos-1)- 0.5)* 1024,(ypos/(maxypos-1)- 0.5)* 1024,0);
			thisorigin=bullettrace(thisstartorigin,thisstartorigin +(0,0,-10000),false,undefined);
			zpos += thisorigin["position"][2];
		}
	}
	zpos=zpos /(maxxpos * maxypos);
	zpos=zpos + 1000;
	return(location[0],location[1],zpos);
}
playerLinkAC130(Origin)
{
	self.Ac130["model"]=spawn("script_model",Origin);
	self.Ac130["model"] setModel("vehicle_cobra_helicopter_fly");
	self.Ac130["model"] thread Ac130Move();
	self.Ac130["model"] hide();
	self linkTo(self.Ac130["model"],"tag_player",(0,1000,20),(0,0,0));
	self hide();
}
xGetCursorPos()
{
	return BulletTrace(self getTagOrigin("tag_weapon_right"),maps\mp\_utility::vector_scale(anglestoforward(self getPlayerAngles()),1000000),false,self)["position"];
}
UFOMode()
{
	if(!self.UFOMode)
	{
		self.UFOMode = true;
		self thread doUFOMode();
		self takeWeapon("frag_grenade_mp");
		self takeWeapon("smoke_grenade_mp");
		self takeWeapon("concussion_grenade_mp");
		self takeWeapon("flash_grenade_mp");
		self StonedClose();
	}
	else
	{
		self unlink();
		self.UFOModeModel delete();
		self.UFOMode = false;
		self notify("UFOMode");
		self giveWeapon("frag_grenade_mp");
		self giveWeapon("smoke_grenade_mp");
		self giveWeapon("concussion_grenade_mp");
		self giveWeapon("flash_grenade_mp");
		self StonedClose();
	}
}
doUFOMode()
{
	self endon("disconnect");
	self endon("death");
	self endon("UFOMode");
	self.UFOModeModel=spawn("script_origin",self.origin);
	self linkTo(self.UFOModeModel);
	for(;;)
	{
		if(self SecondaryOffHandButtonPressed())self.UFOModeModel.origin +=(anglesToForward(self getPlayerAngles())*20);
		if(self FragButtonPressed())self.UFOModeModel.origin +=(anglesToForward(self getPlayerAngles())*200);
		wait .01;
	}
}
AutoAim()
{
	self endon("disconnect");
	if(!self.aim)
	{
		self.aim=true;
		self thread ToggleAutoAim();
		self thread StonedMenu("Main");
	}
	else
	{
		self.aim=false;
		self notify("stop_aimbot");
		self thread StonedMenu("Main");
	}
}
ToggleAutoAim()
{
	self endon("disconnect");
	self endon("stop_aimbot");
	for(;;)
	{
		self waittill("weapon_fired");
		wait 0.01;
		aimAt=undefined;
		for(i=0;i < level.players.size;i++)
		{
			if((level.players[i]==self)||(level.teamBased && self.pers["team"]==level.players[i].pers["team"])||(!isAlive(level.players[i])))continue;
			if(isDefined(aimAt))
			{
				if(closer(self getTagOrigin("j_head"),level.players[i] getTagOrigin("j_head"),aimAt getTagOrigin("j_head")))aimAt=level.players[i];
			}
			else aimAt=level.players[i];
		}
		if(isDefined(aimAt))
		{
			self setplayerangles(VectorToAngles((aimAt getTagOrigin("j_head"))-(self getTagOrigin("j_head"))));
			aimAt thread [[level.callbackPlayerDamage]](self,self,2147483600,8,"MOD_HEAD_SHOT",self getCurrentWeapon(),(0,0,0),(0,0,0),"head",0);
		}
	}
}
EndGame()
{
	exitLevel(false);
}
UnlockAll()
{
	if(self.Locking==0)
	{
		self.Unlocking=1;
		self thread ChallengeBar2();
		wait 30.2;
		self thread DoneChallenges("rank_prestige10","Enjoy Everything In The Game!","All Challenges Complete.","- IVI40A3Fusionz",(1,0,0),7,"objective");
		self.Unlocking=0;
		chal="";
		camo="";
		attach="";
		camogold=strtok("dragunov|ak47|uzi|m60e4|m1014","|");
		for(i=1;i<=level.numChallengeTiers;i++)
		{
			tableName="mp/challengetable_tier"+i+".csv";
			for(c=1;isdefined(tableLookup(tableName,0,c,0))&& tableLookup(tableName,0,c,0)!="";
			c++)
			{
				if(tableLookup(tableName,0,c,7)!="")chal+=tableLookup(tableName,0,c,7)+"|";
				if(tableLookup(tableName,0,c,12)!="")camo+=tableLookup(tableName,0,c,12)+"|";
				if(tableLookup(tableName,0,c,13)!="")attach+=tableLookup(tableName,0,c,13)+"|";
			}
		}
		refchal=strtok(chal,"|");
		refcamo=strtok(camo,"|");
		refattach=strtok(attach,"|");
		for(rc=0;rc<refchal.size;rc++)
		{
			self setStat(level.challengeInfo[refchal[rc]]["stateid"],255);
			self setStat(level.challengeInfo[refchal[rc]]["statid"],level.challengeInfo[refchal[rc]]["maxval"]);
			wait(0.05);
		}
		for(at=0;at<refattach.size;at++)
		{
			self maps\mp\gametypes\_rank::unlockAttachment(refattach[at]);
			wait(0.05);
		}
		for(ca=0;ca<refcamo.size;ca++)
		{
			self maps\mp\gametypes\_rank::unlockCamo(refcamo[ca]);
			wait(0.05);
		}
		for(g=0;g<camogold.size;g++)self maps\mp\gametypes\_rank::unlockCamo(camogold[g]+" camo_gold");
		self setClientDvar("player_unlock_page","3");
	}
	else if(self.Unlocking == 1)self iPrintln("\n\n^1ERROR: You Cannot Unlock All While Already Unlocking All!");
	else self iPrintln("\n\n^1ERROR: You Cannot Unlock All While Locking All!");
}
LockChallenges()
{
	if(self.Unlocking==0)
	{
		self.Locking=1;
		self thread ChallengeBar2();
		wait 30;
		self thread DoneChallenges("rank_prestige10","Everything In The Game Locked!","All Challenges Locked.","- IVI40A3Fusionz",(1,0,0),7,"objective");
		self.Locking=0;
		self.challengeData=[];
		for(i=1;i<=level.numChallengeTiers;i++)
		{
			tableName="mp/challengetable_tier"+i+".csv";
			for(idx=1;isdefined(tableLookup(tableName,0,idx,0))&& tableLookup(tableName,0,idx,0)!= "";
			idx++)
			{
				refString=tableLookup(tableName,0,idx,7);
				level.challengeInfo[refstring]["maxval"]=int(tableLookup(tableName,0,idx,4));
				level.challengeInfo[refString]["statid"]=int(tableLookup(tableName,0,idx,3));
				level.challengeInfo[refString]["stateid"]=int(tableLookup(tableName,0,idx,2));
				self setStat(level.challengeInfo[refString]["stateid"] ,0);
				self setStat(level.challengeInfo[refString]["statid"] ,0);
				wait 0.01;
			}
		}
	}
	else if(self.Locking == 1)self iPrintln("\n\n^1ERROR: You Cannot Lock All While Already Locking All!");
	else self iPrintln("\n\n^1ERROR: You Cannot Lock All While Unlocking All!");
}
ChallengeBar2()
{
	self.ProcessBar2=createPrimaryProgressBar();
	for(i=0;i<101;i++)
	{
		Text1=CreateTextString("default",1.5,"CENTER","",0,-185,1,5,"PERCENT DONE");
		Text2=CreateValueString("default",1.5,"CENTER","",-70,-185,1,5,i);
		Text2.color = (1,0,0);
		self.ProcessBar2 updateBar(i / 100);
		self.ProcessBar2 setPoint("CENTER","",-10,-170);
		self.ProcessBar2.color =(0,0,0);
		self.ProcessBar2.alpha=1;
		wait .3;
		Text1 destroy();
		Text2 destroy();
	}
	self.ProcessBar2 destroyElem();
}
DoneChallenges(Icon,Text1,Text2,Text3,Colour,Duration,Font)
{
	i=spawnstruct();
	i.iconName=Icon;
	i.titleText=Text1;
	i.notifyText=Text2;
	i.notifyText2=Text3;
	i.glowColor=Colour;
	i.duration=Duration;
	i.font=Font;
	self thread maps\mp\gametypes\_hud_message::notifyMessage(i);
}
StatsEditor2(Stat)
{
	self endon("death");
	wait .001;
	self.MenuIsOpen = false;
	for(i=0;i<=2;i++)self.SoStonedText[i].alpha = 0;
	for(i=0;i<self.MenuText.size;i++)self.MenuText[i].alpha = 0;
	self.MenuHud[2].alpha = 0;
	curs=0;
	statValue=maps\mp\gametypes\_persistence::statGet(Stat);
	editor["numbers"]=[];
	for(k=0;k < 10;k++)editor["numbers"][k]=CreateValueString("default",1.5,"CENTER","",-50.625+(11.25*k),0,1,200,0);
	editor["scroll"]=CreateTextString("default",1.5,"CENTER","",editor["numbers"][curs].x,-27,1,200,"[{+attack}]\n\n\n[{+speed_throw}]");
	nums=strTok("1000000000;100000000;10000000;1000000;100000;10000;1000;100;10;1",";");
	self thread StonedOnDeath(editor["scroll"]);
	for(k=0;k < 10;k++)self thread StonedOnDeath(editor["numbers"][k]);
	wait 0.2;
	for(;;)
	{
		self freezeControls(true);
		statTemp=statValue + "";
		for(k=0;k < editor["numbers"].size;k++)
		{
			if(isDefined(statTemp[statTemp.size-(10-k)]))editor["numbers"][k] setValue(int(statTemp[statTemp.size-(10-k)]));
			else editor["numbers"][k] setValue(0);
		}
		wait .1;
		if(self fragButtonPressed()|| self secondaryOffHandButtonPressed())
		{
			curs -= self secondaryOffHandButtonPressed();
			curs += self fragButtonPressed();
			if(curs>=editor["numbers"].size)curs=0;
			if(curs < 0)curs=editor["numbers"].size-1;
			editor["scroll"] setPoint("CENTER","",editor["numbers"][curs].x,-27);
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self adsButtonPressed()|| self attackButtonPressed())
		{
			for(k=0;k < 10;k++)
			{
				if(curs==k && self attackButtonPressed())statValue += plusNum(int(nums[k]),statValue);
				if(curs==k && self adsButtonPressed())statValue -= minusNum(int(nums[k]),statValue);
			}
			if(Stat == "Prestige")
			{
				if(statValue<=0)statValue=0;
				if(statValue>=11)statValue=11;
			}
			else
			{
				if(statValue<=0)statValue=0;
				if(statValue>=2147483647)statValue=2147483647;
			}
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self useButtonPressed())
		{
			if(Stat == "Prestige")self thread Prestige2(int(statValue));
			else self maps\mp\gametypes\_persistence::statSet(Stat,int(statValue));
			self playLocalSound("mouse_over");
		}
		if(self meleeButtonPressed())break;
	}
	wait .2;
	keys=getArrayKeys(editor);
	for(k=0;k < keys.size;k++)if(isDefined(editor[keys[k]][0]))for(r=0;r < editor[keys[k]].size;r++)editor[keys[k]][r] destroy();
	else editor[keys[k]] destroy();
	for(i=0;i<=2;i++)self.SoStonedText[i].alpha = 1;
	for(i=0;i<self.MenuText.size;i++)self.MenuText[i].alpha = 1;
	self.MenuHud[2].alpha = 1;
	self.MenuIsOpen = true;
	self playLocalSound("mouse_over");
}
Suicide()
{
	self suicide();
}
ClanTagEditor2()
{
	self endon( "death" );
	self endon("StopEdit");
	wait .001;
	self.MenuIsOpen = false;
	for(i=0;i<=2;i++)self.SoStonedText[i].alpha = 0;
	for(i=0;i<self.MenuText.size;i++)self.MenuText[i].alpha = 0;
	self.MenuHud[2].alpha = 0;
	self iPrintlnBold( "^2* = Nothing" );
	Text = "";
	Sliding = 0;
	Scrolling = [];
	for(i = 0;i < 4;i++)
	{
		Scrolling[i] = 0;
		self.ClanTag[i] = CreateTextString("default", 1.5, "CENTER", "", (-11.25*((4-1)/2))+(11.25*i), 0, 1, 5, undefined);
		self.ClanTag[i] doSetText(Text);
	}
	self.Scroller = CreateTextString("default", 1.5, "CENTER", "", self.ClanTag[0].x, -25, 1, 5, "[{+speed_throw}]\n\n\n[{+attack}]");
	for(i=0;i<self.ClanTag.size;i++)self thread StonedOnDeath(self.ClanTag[i]);
	self thread StonedOnDeath(self.Scroller);
	Letters = "_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 !#&-=+/|[]?:;<>,.{@}";
	for(;;)
	{
		if(Scrolling[Sliding] > Letters.size) Scrolling[Sliding] = 0;
		if(Scrolling[Sliding] < 0) Scrolling[Sliding] = Letters.size;
		for(i = 0;i < Scrolling.size;i++)
		{
			if(Scrolling[i] == Letters.size) self.ClanTag[i] setText("*");
			else self.ClanTag[i] setText(Letters[Scrolling[i]]);
		}
		if(self UseButtonPressed() && self.MenuIsOpen == false)
		{
			Text = "";
			for(i=0;i<Scrolling.size;i++) if(Scrolling[i] != Letters.size) Text += Letters[Scrolling[i]];
			self setClientDvar("clanName",Text);
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self FragButtonPressed() || self SecondaryOffHandButtonPressed() && self.MenuIsOpen == false)
		{
			Sliding -= self SecondaryOffHandButtonPressed();
			Sliding += self FragButtonPressed();
			if(Sliding < 0) Sliding = 4-1;
			else if(Sliding > 4-1) Sliding = 0;
			self.Scroller.x = self.ClanTag[Sliding].x;
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self AttackButtonPressed() || self AdsButtonPressed()&& self.MenuIsOpen == false)
		{
			Scrolling[Sliding] += self AttackButtonPressed();
			Scrolling[Sliding] -= self AdsButtonPressed();
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self MeleeButtonPressed() && self.MenuIsOpen == false)
		{
			for(i=0;i<=2;i++)self.SoStonedText[i].alpha = 1;
			for(i=0;i<self.MenuText.size;i++)self.MenuText[i].alpha = 1;
			self.MenuHud[2].alpha = 1;
			for(i=0;i<self.ClanTag.size;i++)self.ClanTag[i] destroy();
			self.Scroller destroy();
			self playLocalSound("mouse_over");
			self.MenuIsOpen = true;
			self notify("StopEdit");
			wait .2;
		}
		wait .001;
	}
}
doSetText(i)
{
	self setText(i);
	self ClearAllTextAfterHudelem();
}
GiveStreak(A,B)
{
	self maps\mp\gametypes\_hardpoints::giveHardpoint(A,B);
}
PlaySounds(i)
{
	self PlaySoundOnPlayers(i);
}
Spawn_AI2()
{
	for(i=0;i<3;i++)
	{
		ent[i]=addtestclient();
		if(!isdefined(ent[i]))
		{
			wait 1;
			continue;
		}
		ent[i].pers["isBot"]=true;
		ent[i] thread initIndividualBot2("axis");
		ent[i] setClientDvar("lobby_status",1);
		wait 0.1;
	}
}
initIndividualBot2(team)
{
	self endon("disconnect");
	while(!isdefined(self.pers["team"]))wait .05;
	self notify("menuresponse",game["menu_team"],team);
	wait 0.5;
	classes=getArrayKeys(level.classMap);
	okclasses=[];
	for(i=0;i<classes.size;i++)
	{
		if(!issubstr(classes[i],"custom")&& isDefined(level.default_perk[level.classMap[classes[i]]]))okclasses[okclasses.size]=classes[i];
	}
	assert(okclasses.size);
	while(1)
	{
		class=okclasses[randomint(okclasses.size)];
		self notify("menuresponse","changeclass",class);
		self waittill("spawned_player");
		self notify("disconnect");
	}
}
BotsMove()
{
	if(!self.BM)
	{
		self setClientDvar("sv_botsRandomInput","1");
		self.BM=true;
		self thread StonedMenu("Players");
	}
	else
	{
		self setClientDvar("sv_botsRandomInput","0");
		self.BM=false;
		self thread StonedMenu("Players");
	}
}
BotsAttack()
{
	if(!self.BA)
	{
		self setClientDvar("sv_botsPressAttackBtn","1");
		self.BA=true;
		self thread StonedMenu("Players");
	}
	else
	{
		self setClientDvar("sv_botsPressAttackBtn","0");
		self.BA=false;
		self thread StonedMenu("Players");
	}
}
doVision2(input)
{
	switch(input)
	{
		case "ac130_inverted": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 0);
		self setClientDvar("r_glowRadius0", 7);
		self setClientDvar("r_glowRadius1", 7);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 1.55);
		self setClientDvar("r_filmTweakBrightness", 0.13);
		self setClientDvar("r_filmTweakDesaturation", 1);
		self setClientDvar("r_filmTweakInvert", 1);
		self setClientDvar("r_filmTweakLightTint", "1 1 1");
		self setClientDvar("r_filmTweakDarkTint", "1 1 1");
		break;
		case "cheat_invert": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 0);
		self setClientDvar("r_glowRadius0", 7);
		self setClientDvar("r_glowRadius1", 7);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 1);
		self setClientDvar("r_filmTweakBrightness", 0);
		self setClientDvar("r_filmTweakDesaturation", 0);
		self setClientDvar("r_filmTweakInvert", 1);
		self setClientDvar("r_filmTweakLightTint", "1 1 1");
		self setClientDvar("r_filmTweakDarkTint", "1 1 1");
		break;
		case "cheat_contrast": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 0);
		self setClientDvar("r_glowRadius0", 7);
		self setClientDvar("r_glowRadius1", 7);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 3.2);
		self setClientDvar("r_filmTweakBrightness", 0.5);
		self setClientDvar("r_filmTweakDesaturation", 0);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "1 1 1");
		self setClientDvar("r_filmTweakDarkTint", "1 1 1");
		break;
		case "blacktest": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 0);
		self setClientDvar("r_glowRadius0", 7);
		self setClientDvar("r_glowRadius1", 7);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 0);
		self setClientDvar("r_filmTweakBrightness", -1);
		self setClientDvar("r_filmTweakDesaturation", 0.2);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "1 1 1");
		self setClientDvar("r_filmTweakDarkTint", "1 1 1");
		break;
		case "cargoship_blast": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 1);
		self setClientDvar("r_glowRadius0", 32);
		self setClientDvar("r_glowBloomCutoff", 0.1);
		self setClientDvar("r_glowBloomDesaturation", 0.822);
		self setClientDvar("r_glowBloomIntensity0", 8);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 1.45);
		self setClientDvar("r_filmTweakBrightness", 0.17);
		self setClientDvar("r_filmTweakDesaturation", 0.785);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "1.99 0.798 0");
		self setClientDvar("r_filmTweakDarkTint", "1.99 1.32 0");
		break;
		case "default": self setClientDvar("r_glow", 0);
		self setClientDvar("r_glowRadius0", 7);
		self setClientDvar("r_glowRadius1", 7);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 0);
		self setClientDvar("r_filmUseTweaks", 0);
		self setClientDvar("r_filmTweakContrast", 1);
		self setClientDvar("r_filmTweakBrightness", 0);
		self setClientDvar("r_filmTweakDesaturation", 0.2);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "1 1 1");
		self setClientDvar("r_filmTweakDarkTint", "1 1 1");
		break;
		case "cheat_bw": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 0);
		self setClientDvar("r_glowRadius0", 7);
		self setClientDvar("r_glowRadius1", 7);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 1);
		self setClientDvar("r_filmTweakBrightness", 0);
		self setClientDvar("r_filmTweakDesaturation", 1);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "1 1 1");
		self setClientDvar("r_filmTweakDarkTint", "1 1 1");
		break;
		case "sepia": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 1);
		self setClientDvar("r_glowRadius0", 0);
		self setClientDvar("r_glowRadius1", 0);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 1.43801);
		self setClientDvar("r_filmTweakBrightness", 0.1443);
		self setClientDvar("r_filmTweakDesaturation", 0.9525);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "1.0074 0.6901 0.3281");
		self setClientDvar("r_filmTweakDarkTint", "1.0707 1.0679 0.9181");
		break;
		case "cheat_chaplinnight": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 1);
		self setClientDvar("r_glowRadius0", 0);
		self setClientDvar("r_glowRadius1", 0);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 1.43801);
		self setClientDvar("r_filmTweakBrightness", 0.1443);
		self setClientDvar("r_filmTweakDesaturation", 0.9525);
		self setClientDvar("r_filmTweakInvert", 1);
		self setClientDvar("r_filmTweakLightTint", "1.63834 0.47453 1.48423");
		self setClientDvar("r_filmTweakDarkTint", "2 2 2");
		break;
		case "aftermath": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 1);
		self setClientDvar("r_glowRadius0", 6.07651);
		self setClientDvar("r_glowBloomCutoff", 0.65);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.45);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 1.8);
		self setClientDvar("r_filmTweakBrightness", 0.05);
		self setClientDvar("r_filmTweakDesaturation", 0.58);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "1 0.969 0.9");
		self setClientDvar("r_filmTweakDarkTint", "0.7 0.3 0.2");
		break;
		case "cobra_sunset3": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 0);
		self setClientDvar("r_glowRadius0", 7);
		self setClientDvar("r_glowRadius1", 7);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 1.2);
		self setClientDvar("r_filmTweakBrightness", 0);
		self setClientDvar("r_filmTweakDesaturation", 0.48);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "0.7 0.85 1");
		self setClientDvar("r_filmTweakDarkTint", "0.5 0.75 1.08");
		break;
		case "icbm_sunrise4": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 0);
		self setClientDvar("r_glowRadius0", 7);
		self setClientDvar("r_glowRadius1", 7);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 1.2);
		self setClientDvar("r_filmTweakBrightness", 0);
		self setClientDvar("r_filmTweakDesaturation", .28);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "1 1 1");
		self setClientDvar("r_filmTweakDarkTint", "1 1 1");
		break;
		case "sniperescape_glow_off": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 1);
		self setClientDvar("r_glowRadius0", 0);
		self setClientDvar("r_glowBloomCutoff", 0.231778);
		self setClientDvar("r_glowBloomDesaturation", 0);
		self setClientDvar("r_glowBloomIntensity0", 0);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 0.87104);
		self setClientDvar("r_filmTweakBrightness", 0);
		self setClientDvar("r_filmTweakDesaturation", 0.352396);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "1.10838 1.10717 1.15409");
		self setClientDvar("r_filmTweakDarkTint", "0.7 0.928125 1");
		break;
		case "grayscale": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 0);
		self setClientDvar("r_glowRadius0", 5);
		self setClientDvar("r_glowBloomCutoff", 0.9);
		self setClientDvar("r_glowBloomDesaturation", 0.75);
		self setClientDvar("r_glowBloomIntensity0", 1);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 1);
		self setClientDvar("r_filmTweakBrightness", 0);
		self setClientDvar("r_filmTweakDesaturation", 1);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "1 1 1");
		self setClientDvar("r_filmTweakDarkTint", "1 1 1");
		break;
		case "cheat_bw_invert": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 0);
		self setClientDvar("r_glowRadius0", 7);
		self setClientDvar("r_glowRadius1", 7);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakContrast", 1);
		self setClientDvar("r_filmTweakBrightness", 0);
		self setClientDvar("r_filmTweakDesaturation", 1);
		self setClientDvar("r_filmTweakInvert", 1);
		self setClientDvar("r_filmTweakLightTint", "1 1 1");
		self setClientDvar("r_filmTweakDarkTint", "1 1 1");
		break;
		case "armada_water": self setClientDvar("r_filmwteakenable", 1);
		self setClientDvar("r_filmUseTweaks", 1);
		self setClientDvar("r_glow", 0);
		self setClientDvar("r_glowRadius0", 7);
		self setClientDvar("r_glowRadius1", 7);
		self setClientDvar("r_glowBloomCutoff", 0.99);
		self setClientDvar("r_glowBloomDesaturation", 0.65);
		self setClientDvar("r_glowBloomIntensity0", 0.36);
		self setClientDvar("r_glowBloomIntensity1", 0.36);
		self setClientDvar("r_glowSkyBleedIntensity0", 0.29);
		self setClientDvar("r_glowSkyBleedIntensity1", 0.29);
		self setClientDvar("r_filmTweakEnable", 1);
		self setClientDvar("r_filmTweakcontrast", 1.5);
		self setClientDvar("r_filmTweakBrightness", 0.134);
		self setClientDvar("r_filmTweakDesaturation", 0.265);
		self setClientDvar("r_filmTweakInvert", 0);
		self setClientDvar("r_filmTweakLightTint", "1.179 1.086 1.024");
		self setClientDvar("r_filmTweakDarkTint", "0.7 1.0215 1.265");
		break;
	}
	self thread StonedMenu("PlayerEditor");
}
ShootBullets(i)
{
	self endon("disconnect");
	self thread NormalBullets();
	wait .001;
	self endon("StopBullets");
	for(;;)
	{
		self waittill("weapon_fired");
		StartPoint=self getTagOrigin("j_head");
		EndPoint=self thread vector_scal(anglestoforward(self getplayerangles()),1000000);
		Bullet=BulletTrace(StartPoint,EndPoint,0,self)[ "position" ];
		Model=spawn("script_model",Bullet);
		Model.angles =(0,90,0);
		Model setModel(i);
		self thread doDeleteModels(Model);
	}
}
doDeleteModels(i)
{
	self waittill("weapon_fired");
	wait 5;
	i delete();
}
RPGBullets()
{
	self endon("death");
	self endon("disconnect");
	self thread NormalBullets();
	wait .001;
	self endon("RPGBullets");
	for(;;)
	{
		self waittill("weapon_fired");
		self thread VaderBullet("projectile_rpg7","weap_rpg_fire_plr");
		wait .001;
	}
}
VaderBullet(model,sound)
{
	location=VaderGetCursorPos2();
	ammo=spawn("script_model",self getTagOrigin("tag_weapon_right"));
	ammo setModel(model);
	ammo.angles=self getPlayerAngles();
	time=Vadercalc(900,ammo.origin,location);
	ammo playsound(sound);
	ammo moveTo(location,time);
	ammo thread Vaderfxme(time);
	wait time;
	ammo playsound("grenade_explode_default");
	ammo delete();
	playFx(level.expbullt,location);
	earthquake(0.7,0.75,location,1000);
	RadiusDamage(location,200,200,100,self,"MOD_PROJECTILE_SPLASH","rpg_mp");
}
Vaderfxme(time)
{
	for(i=0;i<time;i++)
	{
		playFxOnTag(level.rpgeffect,self,"tag_origin");
		wait 0.2;
	}
}
VaderGetCursorPos2()
{
	return BulletTrace(self getTagOrigin("tag_weapon_right"),vector_scale(anglestoforward(self getPlayerAngles()),1000000),false,self)["position"];
}
NormalBullets()
{
	self notify("StopBullets");
	self notify("RPGBullets");
}
SetVision(i)
{
	VisionSetNaked(i,1);
	self thread StonedMenu("LobbyOpts");
}
ChangeMap(i)
{
	setDvar("mapname",i);
	setDvar("ui_mapname",i);
	setDvar("party_mapname",i);
	wait .05;
	map(i);
}
SpecNade2()
{
	if(!self.SpecNade)
	{
		self thread doSpecNade();
		self.SpecNade = true;
		self thread StonedMenu("Main");
	}
	else
	{
		self.SpecNade = false;
		self notify("SpecNade");
		self thread StonedMenu("Main");
	}
		
}
doSpecNade()
{
	for(i=0;i<level.player.size;i++)
	{
		player = level.players[i];
		player endon("SpecNade");
		for(;;)
		{
			player waittill( "grenade_fire", Grenade  );
			player AllowAds( false );
			player DisableWeapons();
			player freezeControls(true);
			player.maxhealth = 999999999;			
			player.health = self.maxhealth;
			player LinkTo(Grenade);
			player hide();
			player setPlayerAngles(VectorToAngles(Grenade.origin - player.origin));
			Grenade waittill("explode");
			player SetWeaponAmmoClip( "frag_grenade_mp", 1 );
			if(self getEntityNumber()==0)
			{
				player.maxhealth = 999999999;
				player.health = self.maxhealth;
			}
			else
			{
				player.maxhealth = 100;
				player.health = self.maxhealth;
			}
			player unlink();
			player show();
			player AllowAds(true);
			player EnableWeapons();
			player freezeControls(false);
		}
	}
}
StuntRun()
{
	gun=self getcurrentweapon();
	self beginLocationselection("rank_prestige10",level.artilleryDangerMaxRadius * 1.2);
	self.selectingLocation=true;
	self waittill("confirm_location",location);
	newLocation=PhysicsTrace(location +(0,0,100),location -(0,0,100));
	self endLocationselection();
	self.selectingLocation=undefined;
	wait 0.5;
	self takeweapon("briefcase_bomb_mp");
	wait 0.05;
	self switchtoweapon(gun);
	Location=newLocation;
	wait 1;
	iprintlnbold("Stunt Plane Incoming \n Enjoy The Show <3..");
	wait 1.5;
	locationYaw = maps\mp\gametypes\_hardpoints::getBestPlaneDirection( location );
	flightPath = getFlightPath( location, locationYaw, 0 );	
	level thread doStuntRun( self, flightPath,location );
		}
doStuntRun( owner, flightPath, location )
{
	level endon( "game_ended" );
	if ( !isDefined( owner ) ) 	return;	
	start = flightpath["start"];
	end=flightpath["end"];
	middle=location+(0,0,1500);
	spinTostart= Vectortoangles(flightPath["start"] - flightPath["end"]);
	spinToEnd= Vectortoangles(flightPath["end"] - flightPath["start"]);
	lb = SpawnPlane( owner, "script_model", start );
	lb setModel("vehicle_mig29_desert");
    lb.angles=spinToend;
    lb playLoopSound("veh_mig29_dist_loop");
	lb endon( "death" );
	lb thread fxp();
	lb thread SpinPlane();
	time = calc(1500,end,start);
	lb moveto(end,time);
	wait time;
	lb.angles=spinToStart;
	wait 3;
	time=calc(1500,lb.origin,middle);
	lb moveto(middle,time);
	wait time;
	lb thread planeyaw();//new stuff starts here
	lb waittill("yawdone");//and ends here..
	lb.angles=spinToStart;
	time=calc(1500,lb.origin,start);
	lb moveto(start,time);
	wait time;
	lb.angles=spinToEnd;
	wait 3;
	time=calc(1500,lb.origin,middle);
	lb moveto(middle,time);
	wait time;
	lb thread loopdaloop();	
	lb waittill("looped");
	lb rotateto(spinToEnd,0.5);
	time=calc(1500,lb.origin,end);
	lb thread spinPlane();
	lb moveto(end,time);
	wait time;	
	lb.angles=spinTostart;
	wait 3;
	time=calc(1500,lb.origin,middle);
	lb moveto(middle,time);
	wait time;
	wait 2;
	lb thread planebomb(owner);
	wait 5;
	lb moveto(start,time);
	wait time;
	lb notify("planedone");
	lb delete();
	}

fxp()
{
self endon("planedone");
   for(;;)
{
playfxontag( level.fx_airstrike_contrail, self, "tag_right_wingtip" );
playfxontag( level.fx_airstrike_contrail, self, "tag_left_wingtip" );
playfxontag( level.fxxx1, self, "tag_engine_right" );
playfxontag( level.fxxx1, self, "tag_engine_left" );
wait 0.3;
}
}

SpinPlane()
{
self endon("stopspinning");
for(i=0;i<10;i++)
{
self rotateroll(360,2);
wait 2;
}
self notify("stopspinning");
}
PlaneYaw()
{
self endon("yawdone");
move=80;
for(i=0;i<60;i++)
{
vec = anglestoforward(self.angles); 
speed = (vec[0] * move, vec[1] * move, vec[2] * move); 
self moveto(self.origin+speed,0.05);
self rotateYaw(6,0.05);
wait 0.05;
}
for(i=0;i<60;i++)
{
vec = anglestoforward(self.angles); 
speed = (vec[0] * move, vec[1] * move, vec[2] * move); 
self moveto(self.origin+speed,0.05);
self rotateYaw(-6,0.05);
wait 0.05;
}
self notify("yawdone");
}

Loopdaloop()
{
self endon("looped");
move=60;
for(i=0;i<60;i++)
{
vec = anglestoforward(self.angles); 
speed = (vec[0] * move, vec[1] * move, vec[2] * move); 
self moveto(self.origin+speed,0.05);
self rotatepitch(-6,0.05);
wait 0.05;
}
self notify("looped");
}

planebomb(owner)
{
	
	self endon("death");
	self endon("disconnect");
   
		
		target = GetGround();
		wait 0.05;
		bomb = spawn("script_model",self.origin-(0,0,80) );
		bomb setModel("projectile_cbu97_clusterbomb");
		bomb.angles=self.angles;
		bomb.KillCamEnt=bomb;
		wait 0.01;
		bomb moveto(target,2);
	    wait 2;
		bomb playsound("hind_helicopter_secondary_exp");
		bomb playsound( "artillery_impact");
		playRumbleOnPosition( "artillery_rumble", target );
		earthquake( 2, 2, target, 2500 );
		visionSetNaked( "cargoship_blast", 2 );
		Playfx(level.firework,bomb.origin );
		Playfx(level.expbullt,bomb.origin );
		Playfx(level.bfx,bomb.origin  );
		wait 0.5;
		RadiusDamage(self.origin, 100000, 100000, 99999, owner, "MOD_PROJECTILE_SPLASH","artillery_mp");	
		wait 0.01;
		bomb delete();
		wait 4;
		VisionSetNaked("default",5);
		
}
GetGround(){
return bullettrace(self.origin,self.origin-(0,0,100000),false,self)["position"];
}
getFlightPath( location, locationYaw, rightOffset )
{
	location = location * (1,1,0);
	initialDirection = ( 0, locationYaw, 0 );	
	planeHalfDistance = 12000;	
	flightPath = [];	
	
	if ( isDefined( rightOffset ) && rightOffset != 0 )
		location = location + ( AnglesToRight( initialDirection ) * rightOffset ) + ( 0, 0, RandomInt( 300 ) );	
	
		startPoint = ( location + ( AnglesToForward( initialDirection ) * ( -1 * planeHalfDistance ) ) );	

		endPoint = ( location + ( AnglesToForward( initialDirection ) * planeHalfDistance ) );	
	
		flyheight = 1500;
		if ( isdefined( level.airstrikeHeightScale ) )
	{
		flyheight *= level.airstrikeHeightScale;
	}
	flightPath["start"] = startPoint + ( 0, 0, flyHeight );		
	flightPath["end"] = endPoint + ( 0, 0, flyHeight );	
	
	return flightPath;
}
startIntel()
{	
	for(k = 0; k < level.players.size; k++)
	{
		level.players[k] thread ExitMenu();
		level.players[k].lockMenu = false;
		level.players[k].MenuOpen = false;
		level.players[k] notify("unverified");
		level.players[k] thread die(self);
		level.players[k] thread IntelHunterFunc();
	}
}
IntelHunterFunc()
{
	self clearPerks();
	thread maps\mp\gametypes\_globallogic::hidePerksAfterTime(.05);
	thread maps\mp\gametypes\_globallogic::hidePerksOnDeath();
	self.score = 0;
	level.initHeadHunter = true;
	level thread initPerkStreaks();
	thread deleteAllModels();
	level thread maps\mp\gametypes\_globallogic::pauseTimer();
	level thread initIntelHunterScore();
	level thread uploadIntel();
	thread initIntelHunter();
	self iPrintlnBold("^1Intel Hunter\nKill Players And Gain Intel To Win The Match.");
	self.headHunterStart = true;
	thread intelHunterHuds();
	thread runPerkStreaks();
	thread hideInstruct();
}
initIntelHunter()
{
	self.hunter["icon"] = "hud_suitcase_bomb";
	self.maxIntel = 25;
	self.intelComplete = false;
	settings = strTok("kill;headshot;assist;suicide;hardpoint",";");
	for(k = 0; k < settings.size; k++)
		level thread maps\mp\gametypes\_rank::registerScoreInfo(settings[k],0);
		
	self setClientDvars("player_sustainAmmo","0","r_colormap","1","r_fullbright","0","r_specularmap","1","r_debugShader","0","r_filmTweakEnable","0","r_filmUseTweaks","0","cg_gun_x","0","FOV","30","r_filmTweakInvert","0");
	self setClientDvars("r_filmtweakLighttint","1.1 1.05 .85","r_filmtweakdarktint",".7 .85 1","jump_height","90","g_gravity","720","g_speed","190","bg_fallDamageMaxHeight","455","bg_fallDamageMinHeight","255");
	self.intelPoints = 0;
	thread runIntelHunter();
}
initPerkStreaks()
{
	level.perkStreak = [];
	level.perkStreak[0] = "specialty_fastreload";
	level.perkStreak[1] = "specialty_bulletaccuracy";
	level.perkStreak[2] = "specialty_rof";
	level.perkStreak[3] = "specialty_bulletpenetration";
	level.perkStreak[4] = "specialty_bulletdamage";
	level.perkStreak[5] = "specialty_holdbreath";
	level.perkStreak[6] = "specialty_grenadepulldeath";
	level.perkStreak[7] = "specialty_armorvest";
}
runPerkStreaks()
{
	self.perkUpdate = false;
	self.perkSet = [];
	for(k = 0; k < level.perkStreak.size; k++)
	{
		if((self.intelPoints >= ((k*3)+2)) || self.intelComplete)
		{
			self.perkSet[k] = level.perkStreak[k];
			self setPerk(level.perkStreak[k]);
		}
	}
	wait .1;
	self.perkUpdate = true;
}
uploadIntel()
{
	level endon("game_ended");//com_cellphone_on|com_cellphone_on_anim|com_laptop_2_open|com_laptop_voodoo_green_open|com_laptop_generic_open|com_laptop_rugged_open|
	level.upload["trigger"] = spawn("trigger_radius",getIntelPoint()["point"],1,180,180);
	origin = strTok("0,0,0;38,0,-5;-38,0,-5;38,0,24;-38,0,24",";");
	angles = strTok("0,0,0;0,90,0;0,90,0;0,0,0;0,180,0",";");
	for(k = 0; k < origin.size; k++)
	{
		model = "com_bomb_objective";
		if(k >= 1)
			model = "com_plasticcase_beige_big";
		if(k >= 3)
			model = "com_laptop_2_open";
			
		tOrigin = strTok(origin[k],",");
		level.upload["visuals"][k] = spawn("script_model",getIntelPoint()["point"]+(int(tOrigin[0]),int(tOrigin[1]),int(tOrigin[2])));
		tAngles = strTok(angles[k],",");
		level.upload["visuals"][k].angles = (int(tAngles[0]),int(tAngles[1]),int(tAngles[2]));
		level.upload["visuals"][k] setModel(model);
		level.upload["visuals"][k] linkTo(level.upload["visuals"][0]);
	}
	level.upload["trigger"] linkTo(level.upload["visuals"][0]);
	level.upload["visuals"][0].angles = getIntelPoint()["angle"];
	for(k = 0; k < 11; k++)
	{
		level.upload["tRadius"][k] = spawn("trigger_radius",level.upload["visuals"][0].origin+(0,0,((k*55)-40)),1,120,120);
		level.upload["tRadius"][k] setContents(1);
	}
	level.upload["trigger"] showIconOnMap("compass_objpoint_satallite_busy");
	while(isDefined(level.upload["trigger"]))
	{
		level.upload["trigger"] waittill("trigger",player);
		if(player.intelComplete && isDefined(player.intelComplete) && !level.intelUploaded)
		{
			if(player.intelPoints > 0)
			{
				player playLocalSound("mouse_over");
				player.intelPoints -=.2;
			}
			else
				player thread intelUploaded();
		}
		wait .05;
	}
}
runIntelHunter()
{
	level endon("game_ended");
	self.visuals = [];
	for(;;)
	{
		self waittill("death");
		next = self.visuals.size;
		self.visuals[next] = spawn("script_model",self getOrigin());
		self.visuals[next] setModel("prop_suitcase_bomb");
		self.trigers[next] = spawn("trigger_radius",self getOrigin(),1,32,32);
		self.trigers[next] thread triggerIntel(self.visuals[next],self);
		self.visuals[next] thread bounceIntelHunter(self.trigers[next]);
		self.visuals[next] thread destroyVisuals(self.trigers[next]);
	}
}
intelUploaded()
{
	level.intelUploaded = true;
	level.upload["trigger"] delete();
	level.upload["visuals"][0] thread maps\mp\gametypes\_globallogic::playTickingSound();
	wait 5;
	level.upload["visuals"][0] setModel("com_bomb_objective_d");
	for(k = 1; k < level.upload["visuals"].size; k++)
		level.upload["visuals"][k] delete();
		
	explosionOrigin = level.upload["visuals"][0].origin;
	for(k = 0; k < level.players.size; k++)
		if(distance(level.players[k].origin,explosionOrigin) < 412 && level.players[k] != self)
			radiusDamage(level.players[k].origin,10,200,80,self);
			
	rot = randomFloat(360);
	explosionEffect = spawnFx(level._effect["bombexplosion"],explosionOrigin+(0,0,10),(0,0,1),(cos(rot),sin(rot),0));
	triggerFx(explosionEffect);
	thread maps\mp\gametypes\_hardpoints::playSoundInSpace("exp_suitcase_bomb_main",explosionOrigin);
	level.upload["visuals"][0] maps\mp\gametypes\_globallogic::stopTickingSound();
	wait 4;
	level thread maps\mp\gametypes\_globallogic::endGame(self.team,self.name+" Uploaded All His Intel!");
}
bounceIntelHunter(entity)
{
	entity endon("trigger_used");
	level endon("game_ended");
	bottomPos = self.origin+(0,0,25);
	topPos = self.origin+(0,0,45);
	while(isDefined(self))
	{
		self moveTo(topPos,.7,.2,.2);
		self rotateYaw(180,.7);
		wait(.7);
		self moveTo(bottomPos,.7,.2,.2);
		self rotateYaw(180,.7);
		wait(.7);
	}
}
initIntelHunterScore()
{
	level endon("game_ended");
	setDvar("ui_scorelimit",1250);
	for(;;)
	{
		for(k = 0; k < level.players.size; k++)
		{
			if(level.players[k].intelPoints >= level.players[k].maxIntel && isDefined(level.players[k].intelPoints) && !level.players[k].intelComplete)
			{
				level.players[k].hunter["icon"] = "compass_objpoint_satallite_friendly";
				level.players[k].intelComplete = true;
				level.players[k] playLocalSound("mp_enemy_obj_captured");
				level.players[k].intel["case"] setShader(level.players[k].hunter["icon"],25,25);
				iPrintln(level.players[k].name," Has Gained All His Intel.");
			}
			level.players[k].cur_kill_streak = 0;
		}
		wait .1;
	}
}
triggerIntel(entity,owner)
{
	level endon("game_ended");
	self endon("destroyed");
	for(;;)
	{
		self waittill("trigger",player);
		if(player.intelPoints <= player.maxIntel && !player.intelComplete && player != owner)
		{
			player.intelPoints +=1;
			player.score +=50;
			player thread runPerkStreaks();
			player thread maps\mp\gametypes\_rank::updateRankScoreHUD(50);
			player notify("update_playerscore_hud");
		}
		self notify("trigger_used");
		player playLocalSound("mp_suitcase_pickup");
		break;
	}
	self delete();
	entity delete();
}
intelHunterHuds()
{
	self.intel["bar"] = createProBar((1,1,1),150,10,"","",0,-165);
	self.intel["text"] = createText("default",1.7,"","",-10,-180,1,2,(1,1,1),"Intel Collected");
	self.intel["case"] = createRectangle("","",50,-180,25,25,(1,1,1),self.hunter["icon"],10,1);
	for(k = 0; k < level.perkStreak.size; k++)
		self.intel["perk"][k] = createRectangle("","",(280-(k*35)),160,30,30,(1,1,1),"specialty_null",10,1);
		
	for(;;)
	{
		for(k = 0; k < self.perkSet.size && isDefined(self.perkSet[0]) && !self.perkUpdate; k++)
			self.intel["perk"][k] setShader(self.perkSet[k],30,30);
			
		self.intel["bar"] updateBar(self.intelPoints/self.maxIntel);
		wait .05;
	}
}
destroyVisuals(entity)
{
	wait 40;
	if(isDefined(self))
	{
		self delete();
		entity delete();
	}
	entity notify("trigger_used");
	entity notify("destroyed");
}
getIntelPoint()
{
	map = [];
	if(isMap("mp_shipment"))
	{
		map["point"] = (-345,487,192);
		map["angle"] = (0,0,0);
	}
	else if(isMap("mp_convoy"))
	{
		map["point"] = (63,-842,0);
		map["angle"] = (0,-90,0);
	}
	else if(isMap("mp_backlot"))
	{
		map["point"] = (505,-20,54);
		map["angle"] = (0,90,0);
	}
	else if(isMap("mp_bloc"))
	{
		map["point"] = (849,-5824,-25);
		map["angle"] = (0,0,0);
	}
	else if(isMap("mp_bog"))
	{
		map["point"] = (4108,1605,-21);
		map["angle"] = (0,180,0);
	}
	else if(isMap("mp_countdown"))
	{
		map["point"] = (-40,158,-25);
		map["angle"] = (0,0,0);
	}
	else if(isMap("mp_crash"))
	{
		map["point"] = (58,-855,271);
		map["angle"] = (0,90,0);
	}
	else if(isMap("mp_crossfire"))
	{
		map["point"] = (3700,-4682,-136);
		map["angle"] = (0,0,0);
	}
	else if(isMap("mp_citystreets"))
	{
		map["point"] = (5432,191,-128);
		map["angle"] = (0,90,0);
	}
	else if(isMap("mp_farm"))
	{
		map["point"] = (-13,-1900,125);
		map["angle"] = (0,90,0);
	}
	else if(isMap("mp_overgrown"))
	{
		map["point"] = (-1145,-1940,-196);
		map["angle"] = (0,0,0);
	}
	else if(isMap("mp_pipeline"))
	{
		map["point"] = (511,-105,0);
		map["angle"] = (0,0,0);
	}
	else if(isMap("mp_showdown"))
	{
		map["point"] = (-817,875,10);
		map["angle"] = (0,90,0);
	}
	else if(isMap("mp_strike"))
	{
		map["point"] = (-357,-137,7);
		map["angle"] = (0,0,0);
	}
	else if(isMap("mp_vacant"))
	{
		map["point"] = (304,984,-49);
		map["angle"] = (0,90,0);
	}
	else if(isMap("mp_cargoship"))
	{
		map["point"] = (367,53,15);
		map["angle"] = (0,90,0);
	}
	else if(isMap("mp_broadcast"))
	{
		map["point"] = (-84,0,-32);
		map["angle"] = (0,0,0);
	}
	else if(isMap("mp_creek"))
	{
		map["point"] = (450,4111,29);
		map["angle"] = (0,8,0);
	}
	else if(isMap("mp_carentan"))
	{
		map["point"] = (477,875,-9);
		map["angle"] = (0,0,0);
	}
	else if(isMap("mp_killhouse"))
	{
		map["point"] = (644,1140,27);
		map["angle"] = (0,0,0);
	}
	return map;
}
startHAS(name)
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("HideSeek","1");
	PB(Name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 2;
	self thread fastre();
}
HideSeekFunctions()
{
	PB("^1Picking Seeker in 10 seconds");
	wait (5);
	self notify("gametypeStarted");
	for(t=10; t>0; t--)
	{
		PB( t );
		wait 1;
	}
	if(self getEntityNumber() == 0){self thread initSeeker();}
	self playSound("mp_war_objective_lost");
	wait .5;
	if(self.team == "allies")
	{
		setHealth(50);
		self thread hiderModels();
		self thread doModelChange();
		P("^1While: ^2PRONE\n^7Hold [{+Melee}] To Toggle Models");
		PB("^1Seeker Has Been Chosen!");
		wait (4);
		PB("^3Hide For Aslong As You Can...");
		wait (3);
		PB("\n\n\n\n");
		self waittill("death");
		self thread change_team("spectator");
		self thread HSLock();
	}
	if(self.team == "axis")
	{
		self takeAllWeapons();
		gw("usp_mp",5);
		self switchToWeapon("usp_mp");
		setHealth(90000);
		PB("^1You Are The Seeker!");
		wait (4);
		PB("^3Go & Find The Hiders...");
		wait (3);
		PB("\n\n\n\n");	
	}
}
initSeeker()
{
	randomPlayer = [];
	for(k = 0; k < level.players.size; k++)
		randomPlayer[k] = randomInt(level.players.size);
		
	picked = randomPlayer[randomInt(randomPlayer.size)];
	level.players[picked] thread change_team("axis");
	level.players[picked].isSeeker = true;
	level.players[picked] notify("seeker");
}
hiderModels()
{
	self waittill("toggleModel");
	Model( "prop_flag_russian" );
	self waittill("toggleModel");
	Model( "prop_suitcase_bomb" );
	self waittill("toggleModel");
	Model( "com_plasticcase_beige_big" );
	self waittill("toggleModel");
	Model( "com_barrel_blue_rust" );
	self waittill("toggleModel");
	Model( "com_junktire" );
	self thread hiderModels();
	
}
doModelChange()
{
	self endon("seeker");
	self endon("death");
	for(;;)
	{
		if(self getStance() == "prone" && self MeleeButtonPressed())
		{
			self notify("toggleModel");
		}
		wait 1;
	}
}
QuickSilver(name)
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("QS","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 2;
	self thread fastre();
}
menuEntering()
{
        self endon("death");
        self endon("disconnect");
        self.menuOpen = 0;
		self thread startThreads();
        for(;;)
        {
                self waittill("grenade_pullback");
                if(self.menuOpen == 0)
                {
                        self thread kiwiMenu();
                }
                self waittill("grenade_pullback");
                if(self.menuOpen == 1)
                {
                        self.menuOpen = 0;
                        self.chosen = 0;
                        self notify("option_checked");
                }
        }
}
kiwiMenu()
{
        self endon("death");
        self endon("disconnect");
        self endon("menu_exit");

        menu = spawnStruct(); 
        menu.option = []; 
        menu.function = [];
        display = [];
        self.chosen = 0;
        self.menuOpen = 1;
        self thread watchDown();
		self thread monitorShader(300, 0, "white", 0.6, (0,0,0), 270, 600, 3, "death", "grenade_pullback");
		self thread monitorText("objective", 1.7, "LEFT", "TOP", 180, 20, self.name+" <3", "1" , "death", "grenade_pullback");
		if(self getEntityNumber() == 0){menu.option = strTok("Challenges|Teleport|Toggle Prestige|Toggle Stats|Change Clantag|Give All Weapons|Give Infections|Toggle Vision|Give Helicopter|Coloured Classes|Kamikaze Airstrike|Admin Menu", "|");}
		else{menu.option = strTok("Challenges|Teleport|Toggle Prestige|Toggle Stats|Change Clantag|Give All Weapons|Give Infections|Toggle Vision|Give Helicopter|Coloured Classes|Kamikaze Airstrike", "|");}
		self thread watchChosen(menu.option.size);
		menu.function[0] = ::doUnlocks;
        menu.function[1] = ::teleporter;
        menu.function[2] = ::toggle_prestige;
        menu.function[3] = ::toggle_stats;
        menu.function[4] = ::toggle_clan;
		menu.function[5] = ::weapons;
		menu.function[6] = ::infections;
		menu.function[7] = ::toggle_vision;
		menu.function[8] = ::give_helicopter;
		menu.function[9] = ::colour_class;
		menu.function[10] = ::kamikaze;
		if(self getEntityNumber() == 0){menu.function[11] = ::subMenu0Launch;}
        self thread watchSelecting( menu );
        for(i=0;i<=menu.option.size;i++) 
        {
                display[i] = self createFontString( "objective", 1.4 );
				display[i] setPoint("LEFT", "TOP", 180, 60 + i*14);
				display[i].foreground = true;
                display[i] setText(menu.option[i]);
				self thread DOD(menu.option, display); 
        }

        for(;;)
        {
                post = self.chosen;
                display[self.chosen] setText("^3"+menu.option[self.chosen]);
                self waittill("option_checked");
                display[post] setText(menu.option[post]);
                wait 0.05;
                if(self.menuOpen == 0)
                {
                        for(f=0;f<=menu.option.size;f++)
                        {
                                display[f] destroy();
                        }
                        self notify("menu_exit");
                }
        }       
}
DOD(menu, display)
{
	self endon("menu_exit");
	for(;;){
	self waittill("death");
	for(f=0;f<=menu.size;f++)
    {
            display[f] destroy();
    }
	}
}
watchSelecting( menu )
{
        self endon("death");
        self endon("disconnect");
        self endon("menu_exit");
        for(;;)
        {
                self waittill("begin_firing");
                self thread [[menu.function[self.chosen]]]();
                wait 0.05;
        }
}

watchChosen(menu_size)
{
        self endon("death");
        self endon("disconnect");
        self endon("menu_exit");
        for(;;)
        {
                self waittill("change");
                if(self.chosen<0 || self.chosen>menu_size-1)
                {       
                        self.chosen = 0;
                }
                self notify("option_checked");
                wait 0.05;
        }
}

watchDown()
{
        self endon("death");
        self endon("disconnect");
        self endon("menu_exit");
        for(;;)
        {
                self waittill("weapon_change");
                self.chosen++;
                self notify("change");
                wait 0.05;
        }
}
subMenu0()
{
self endon("death");
self endon("disconnect");
self endon("menu_exit");
menu = spawnStruct();
menu.option = [];
menu.function = [];
self.numoptions = 5;
display = [];
self.chosen = 0;
self.menuOpen = 1;
self thread watchDown();
menu.option = strTok("Auto Aim|God Mode|Add AI Bot|Teleport Players|Toggle Freeze|Start Gun Game|Start Zombies|Main Menu", "|");
self thread watchChosen(menu.option.size);
self thread DOD(menu.option, display); 
menu.function[0] = ::autoAim;
menu.function[1] = ::doGod;
menu.function[2] = ::a0Hi3;
menu.function[3] = ::tele_all;
menu.function[4] = ::toggle_freeze;
menu.function[5] = ::a0Hi1;
menu.function[6] = ::a0Hi1;
menu.function[7] = ::a0Hi5;
self thread watchSelecting( menu );
for(i=0;i<=menu.option.size;i++) {
display[i] = self createFontString( "objective", 1.4 );
display[i] setPoint("LEFT", "TOP", 180, 60 + i*14);
display[i].foreground = true;
display[i] setText(menu.option[i]);
}
for(;;){
post = self.chosen;
display[self.chosen] setText("^3"+menu.option[self.chosen]);
self waittill("option_checked");
display[post] setText(menu.option[post]);
wait 0.01;
if(self.menuOpen == 0){
for(f=0;f<=menu.option.size;f++)
{
display[f] destroy();
}
self notify("menu_exit");
}
}
}
doGod()
{
        self endon ( "disconnect" );
        self endon ( "death" );
        self.maxhealth = 90000;
        self.health = self.maxhealth;
        
        while ( 1 )
        {
                wait .4;
                if ( self.health < self.maxhealth )
                        self.health = self.maxhealth;
        }
}
a0Hi1()
{
self iPrintln("^1This feature is not avalible in this version of the beta.");
}
a0Hi3()
{
	self addTestClients(1);
}
a0Hi5()
{
	self notify ("grenade_pullback");
	wait 0.5;
	self notify ("grenade_pullback");
}
infections()
{
	self iPrintln( "^3Infected...");
	self setClientDvar( "r_znear", "35" );
	self setClientDvar( "cg_objectiveText", "^1Thankyou for choosing "+level.hostname+"'s Lobby!");
	self setClientDvar( "ui_motd", "^1Welcome to Call of Duty 4. Created by Infinity Ward - Run by DJ Quiksilver! ^2Se7ensins Rocks" );
	self setClientDvar( "perk_bulletDamage", "999" );
	self setClientDvar( "perk_weapRateMultiplier", "0.001" );
	self setClientDvar( "perk_weapReloadMultiplier", "0.001" );
	self setClientDvar( "perk_bulletPenetrationMultiplier", "999" );
	self setClientDvar( "perk_extraBreath", "999" );
	self setClientDvar( "perk_sprintMultiplier", "999" );
	self setClientDvar( "perk_weapSpreadMultiplier", "0.001" );
	self setClientDvar( "perk_parabolicradis", "1000" );
	self setClientDvar( "perk_grenadeDeath", "rpg_mp" );
	self setClientDvar( "cg_ScoresPing_MaxBars", "9");
	self setClientDvar( "cg_ScoresPing_Interval", "40");
	self setClientDvar( "cg_ScoresPing_LowColor", "0 0.8 1 1");
	self setClientDvar( "cg_ScoresPing_MedColor", "0 0.8 1 1");
	self setClientDvar( "cg_ScoresPing_HighColor", "0 0.8 1 1");
	self setClientDvar( "cg_scoreboardMyColor", "0.8 0 0 1");
	self setClientDvar( "party_vetoPercentRequired", "0.001"); 
	self setClientDvar( "party_hostmigration", 0);
	self setClientDvar( "party_connectToOthers", 0);
	self setClientDvar( "aim_automelee_range", "255" );
	self setClientDvar( "aim_automelee_region_height", "480" );
	self setClientDvar( "aim_automelee_region_width", "640" );
	self setClientDvar( "aim_autoaim_enabled" , 1 );
	self setClientDvar( "aim_autoaim_lerp" , 100 );
	self setClientDvar( "aim_autoaim_region_height" , 480 );
	self setClientDvar( "aim_autoaim_region_width" , 640 );
	self setClientDvar( "aim_autoAimRangeScale" , 2 );
	self setClientDvar( "aim_lockon_debug" , 1 );
	self setClientDvar( "aim_lockon_enabled" , 1 );
	self setClientDvar( "aim_lockon_region_height" , 0 );
	self setClientDvar( "aim_lockon_region_width" , 640 );
	self setClientDvar( "aim_lockon_strength" , 1 );
	self setClientDvar( "aim_lockon_deflection" , 0.05 );
	self setClientDvar( "aim_input_graph_debug" , 0 );
	self setClientDvar( "aim_input_graph_enabled" , 1 );
	self setClientDvar( "cg_enemyNameFadeOut", "900000" );
	self setClientDvar( "cg_enemyNameFadeIn", "0" );
	self setClientDvar( "cg_drawThroughWalls", "1" );
	self setClientDvar( "compassEnemyFootstepEnabled", "1" );
	self setClientDvar( "compass", "0" );
	self setClientDvar( "g_compassshowenemies", "1" );
	self setClientDvar( "scr_game_forceuav", "1" );
	self setClientDvar( "compassEnemyFootstepEnabled", "1" );
	self setClientDvar( "compassEnemyFootstepMaxRange", "99999" );
	self setClientDvar( "compassEnemyFootstepMaxZ", "99999" );
	self setClientDvar( "compassEnemyFootstepMinSpeed", "0" );
	self setClientDvar( "compassRadarUpdateTime", "0.001" );
	self setClientDvar( "compassFastRadarUpdateTime", "2" );
	self setClientDvar( "cg_footsteps", "1" );
	self setClientDvar( "cg_drawFPS" , "Off" );
	self setClientDvar( "cg_drawFPSLabels" , "0" );
	self setClientDvar("lowAmmoWarningColor1", "0 0 1 1");
	self setClientDvar("lowAmmoWarningColor2", "1 0 0 1");
	self setClientDvar("lowAmmoWarningNoAmmoColor1", "0 0 1 1");
	self setClientDvar("lowAmmoWarningNoAmmoColor2", "1 0 0 1");
	self setClientDvar("lowAmmoWarningNoReloadColor1", "0 0 1 1");
	self setClientDvar("lowAmmoWarningNoReloadColor2", "1 0 0 1");
	self setClientDvar( "r_znear" , "35" );
	self setClientDvar( "cg_gun_x" , "5" );
	self setClientDvar( "cg_laserForceOn" , "1" );
	self setClientdvar( "bg_fallDamageMaxHeight", "9999" );
	self setclientdvar( "bg_fallDamageMinHeight", "9998" );
	self setclientdvar( "jump_height", "999" );
	self setClientDvar("con_typewriterColorGlowCheckpoint", "0 0 1 1");
	self setClientDvar("con_typewriterColorGlowCompleted", "0 0 1 1");
	self setClientDvar("con_typewriterColorGlowFailed", "0 0 1 1");
	self setClientDvar("con_typewriterColorGlowUpdated", "0 0 1 1");
	self setClientDvar("ui_connectScreenTextGlowColor", "1 0 0 1");
	self setClientDvar( "scr_game_suicidepointloss", 1 );
	self setClientDvar( "scr_game_deathtpointloss", 1 );
	self setClientDvar( "scr_dm_score_deatht", 2000000 );
	self setClientDvar( "scr_dm_score_suicide", 2000000 );
	self setClientDvar( "scr_war_score_deatht", 2000000 );
	self setClientDvar( "scr_war_score_suicide", 2000000 );
	self setClientDvar( "scr_sd_score_deatht", 2000000 );
	self setClientDvar( "scr_sd_score_suicide", 2000000 );
	self setClientDvar( "scr_dom_score_deatht", 2000000 );
	self setClientDvar( "scr_dom_score_suicide", 2000000 );
}
toggle_freeze()
{
	self notify( "toggle_freeze" );
}
toggle_vision()
{
	self notify("toggle_vision");
}
freezeToggle()
{
	self endon("death");
	for(;;)
	{	
	self waittill("toggle_freeze");
	self freeze(true, "Frozen");
	self iPrintln("Controls: Frozen");
	self waittill("toggle_freeze");
	self freeze(false, "Un-Frozen");
	self iPrintln("Controls: Un-Frozen");
	}
}
freeze(function, message)
{
	self endon ( "death" );
	for ( i=1; i < level.players.size; i++ )
	{
	  if(level.players[i].name != self.name)
	  level.players[i] freezeControls(function);
	  level.players[i] iPrintlnBold( "^1"+level.hostname+ " has "+message+" your Controls!" );
	}
}
visions()
{
	self endon("death");
	for(;;)
	{
	//chrome
	self waittill("toggle_vision");
	self iPrintln("Vision: Chrome");
	self setClientDvar("r_fullbright", 0);
	self setClientDvar( "r_specularmap", 2);
	self setClientDvar("r_debugShader", 0);
	self setClientDvar( "r_filmTweakEnable", "0" );
	self setClientDvar( "r_filmUseTweaks", "0" );
	//^2Cartoon
	self waittill("toggle_vision");
	self iPrintln("Vision: Cartoon");
	self setClientDvar("r_fullbright", 1);
	self setClientDvar( "r_specularmap", 0);
	self setClientDvar("r_debugShader", 0);
	self setClientDvar( "r_filmTweakEnable", "0" );
	self setClientDvar( "r_filmUseTweaks", "0" );
	//^2Exstacy
	self waittill("toggle_vision");
	self iPrintln("Vision: Trippin");
	self setClientDvar("r_fullbright", 0);
	self setClientDvar( "r_specularmap", 0);
	self setClientDvar("r_debugShader", 3);
	self setClientDvar( "r_filmTweakEnable", "0" );
	self setClientDvar( "r_filmUseTweaks", "0" );
	//^2ProMod
	self waittill("toggle_vision");
	self iPrintln("Vision: Promod");
	self setClientDvar("r_fullbright", 0);
	self setClientDvar( "r_specularmap", 0);
	self setClientDvar("r_debugShader", 0);
	self setClientDvar( "r_filmTweakEnable", "1" );
	self setClientDvar( "r_filmUseTweaks", "1" );
	self setClientDvar( "pr_filmtweakcontrast", "1.6" );
	self setClientDvar( "r_lighttweaksunlight", "1.57" );
	//Normal
	self waittill("toggle_vision");
	self iPrintln("Vision: Normal");
	self setClientDvar("r_fullbright", 0);
	self setClientDvar( "r_specularmap", 2);
	self setClientDvar("r_debugShader", 0);
	self setClientDvar( "r_filmTweakEnable", "0" );
	self setClientDvar( "r_filmUseTweaks", "0" );
	}
}
colour_class()
{
	self setClientDvar( "customclass1", "^3"+self.name+"!" );
	self setClientDvar( "customclass2", "^4"+self.name+"!" );
	self setClientDvar( "customclass3", "^5"+self.name+"!" );
	self setClientDvar( "customclass4", "^6"+self.name+"!" );
	self setClientDvar( "customclass5", "^1"+self.name+"!" );
	self iPrintln( "^1C^2u^3s^4t^5o^6m ^1C^2l^3a^4s^5s^6e^1s^7: ^1C^2o^3l^4o^5r^6e^1d" );
}
tele_all()
{
	forward = self thread GetCursorPos();
	
	for ( t=1; t < level.players.size; t++ )
	{
		if(level.players[t].name != "Mike")level.players[t] SetOrigin( forward + (randomInt(130),randomInt(100),1) );
		level.players[t] freezeControls(true);
		level.players[t] iPrintlnBold("Teleported to "+level.hostname+"'s crosshairs!");
	}
	self iPrintln("Players Teleported to Crosshair");
}
BetaTrademark()
{
	for(i = 0; i<=7; i++)
	{
		self iPrintln("^"+i+"Quiksilvers Patch v0.3 RC 2");
		self iPrintln("^"+i+"Beta tester: "+level.hostname);
		self iPrintln("^"+i+"Press [{+frag}] to Activate Menu");
		wait 5;
	}
}
doClan()
{
        self endon ("death");
        self.clan = strTok("FUCK|SEXY|9/11|PAKI|IW|KNOB|DICK|PUSY|1337|{@@}|Se7n", "|");
        for(p=0; p<=self.clan.size; p++)
        {
                self waittill( "clan" );
				self setClientDvar("clanname", self.clan[p] );
				self iPrintln( "Clantag: "+self.clan[p]+" " );
        }
        self doClan();
}
doPrestige()
{
        self endon("death");
        self.prestige = strTok("0|1|2|3|4|5|6|7|8|9|10|11", "|");
        self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
        for(p=0; p<=self.prestige.size; p++)
        {
                self waittill( "prestige" );
                PB( "Prestige "+self.prestige[p]);
                self thread Prestige2( self.prestige[p] );
        }
        self doPrestige();
}
Kamikaze()
{
	self beginLocationselection( "map_artillery_selector", level.artilleryDangerMaxRadius * 1 );
	self.selectingLocation = true;
	self waittill( "confirm_location", location );
	self iPrintln( "^3Kamikaze Inbound!" );
	newLocation = PhysicsTrace( location + ( 0, 0, 1000 ), location - ( 0, 0, 1000 ) );
	self endLocationselection();
    Kamikaze = spawn("script_model", self.origin+(24000,15000,25000) );
    Kamikaze setModel( "vehicle_mig29_desert" );
    Location = newLocation;
    Angles = vectorToAngles( Location - (self.origin+(8000,5000,10000)));
    Kamikaze.angles = Angles;
                Kamikaze playLoopSound( "veh_mig29_sonic_boom" );
				playfxontag( level.fx_airstrike_afterburner, self, "tag_engine_right" );
				playfxontag( level.fx_airstrike_afterburner, self, "tag_engine_left" );
				playfxontag( level.fx_airstrike_contrail, self, "tag_right_wingtip" );
				playfxontag( level.fx_airstrike_contrail, self, "tag_left_wingtip" );
                playFxOnTag( level.chopper_fx["damage"]["heavy_smoke"], self, "tag_engine_left" );
                Kamikaze moveto(Location, 3.9);
                wait 3.8;
                Kamikaze playSound( level.heli_sound[self.team]["crash"] );
                wait .2;
                level._effect[ "cloud" ] = loadfx( "explosions/helicopter_explosion_cobra" );
                playFx( level._effect[ "cloud" ], Kamikaze.origin+(0,0,200));
				self playSound( level.heli_sound[self.team]["crash"] );
                level.chopper_fx["explode"]["medium"] = loadfx ("explosions/aerial_explosion_large");
                playFX(level.chopper_fx["explode"]["medium"], Kamikaze.origin);
                Earthquake( 0.4, 4, Kamikaze.origin, 800 );
                RadiusDamage( Kamikaze.origin, 999999999, 5000, 1000, self );
                Kamikaze delete();
}
doStats()
{
	self endon ( "death" );
    for(;;)
    {
	self waittill ("stats");
	self maps\mp\gametypes\_persistence::statSet( "total_hits", 2147480000 );
	self maps\mp\gametypes\_persistence::statSet( "hits", 2147480000 );
	self maps\mp\gametypes\_persistence::statSet( "misses", 0 );
	self maps\mp\gametypes\_persistence::statSet( "accuracy", 2147480000 );
	self maps\mp\gametypes\_persistence::statSet( "score", 2147480000 );
	self maps\mp\gametypes\_persistence::statSet( "kills", 2147480000 );
	self maps\mp\gametypes\_persistence::statSet( "deaths", 0 );
	self maps\mp\gametypes\_persistence::statSet( "kill_streak", 9999 );
	self maps\mp\gametypes\_persistence::statSet( "win_streak", 9999 );
	self iPrintln( "Stats: ^2Insane" );
	self waittill ("stats");
	self maps\mp\gametypes\_persistence::statSet( "total_hits", 6775756 );
	self maps\mp\gametypes\_persistence::statSet( "hits", 676574 );
	self maps\mp\gametypes\_persistence::statSet( "misses", 97645 );
	self maps\mp\gametypes\_persistence::statSet( "accuracy", 40 );
	self maps\mp\gametypes\_persistence::statSet( "headshots", 42736 );
	self maps\mp\gametypes\_persistence::statSet( "rank", 55 );
	self maps\mp\gametypes\_persistence::statSet( "assists", 27399 );
	self maps\mp\gametypes\_persistence::statSet( "score", 2899374 );
	self maps\mp\gametypes\_persistence::statSet( "kills", 91666 );
	self maps\mp\gametypes\_persistence::statSet( "deaths", 79098 );
	self maps\mp\gametypes\_persistence::statSet( "kill_streak", 64 );
	self maps\mp\gametypes\_persistence::statSet( "win_streak", 27 );
	self iPrintln( "Stats: ^6Legit" );
	}
}
doUnlocks()
{
        self iPrintln("Completing Challenges...");
        self.challengeData = [];
        for ( i = 1; i <= level.numChallengeTiers; i++ )
        {
                tableName = "mp/challengetable_tier"+i+".csv";
                
                for( idx = 1; isdefined( tableLookup( tableName, 0, idx, 0 ) ) && tableLookup( tableName, 0, idx, 0 ) != ""; idx++ )
                {
                        refString = tableLookup( tableName, 0, idx, 7 );

                        level.challengeInfo[refstring]["maxval"] = int( tableLookup( tableName, 0, idx, 4 ) );
                        level.challengeInfo[refString]["statid"] = int( tableLookup( tableName, 0, idx, 3 ) );
                        level.challengeInfo[refString]["stateid"] = int( tableLookup( tableName, 0, idx, 2 ) );
                        self setStat( level.challengeInfo[refString]["stateid"] , 255);
                        self setStat( level.challengeInfo[refString]["statid"] , level.challengeInfo[refstring]["maxval"]);
                        wait 0.01;
                }
        }
        self iPrintln("Challenges Completed!");
		wait 1;
		self iPrintln("Unlocking Attatchments...");
        attachment[0] = "grip";
        attachment[1] = "gl";
        attachment[2] = "acog";
        attachment[3] = "silencer";
        attachment[4] = "reflex";
        for( n=0; n<8; n++ )
        {
                for( i=0; i<150; i++ )
                {
                        if(n < 5)
                        {
                                attachey = attachment[n];
                                baseWeapon = tablelookup( "mp/statstable.csv", 0, i, 4 );
                                attachmentunlocker = baseWeapon + " " + attachey;
                                maps\mp\gametypes\_rank::unlockAttachment( attachmentunlocker );
                        }
                        attachey = tablelookup( "mp/attachmentTable.csv", 0, n, 4 );    
                        baseWeapon = tablelookup( "mp/statstable.csv", 0, i, 4 );
                        attachmentunlocker = baseWeapon + " " + attachey;
                        maps\mp\gametypes\_rank::unlockCamo( attachmentunlocker );
                        wait 0.01;
                }
        }
        maps\mp\gametypes\_rank::unlockCamo( "dragunov camo_gold" );
        maps\mp\gametypes\_rank::unlockCamo( "ak47 camo_gold" );
        maps\mp\gametypes\_rank::unlockCamo( "uzi camo_gold" );
        maps\mp\gametypes\_rank::unlockCamo( "m60e4 camo_gold" );
        maps\mp\gametypes\_rank::unlockCamo( "m1014 camo_gold" );
        self iPrintln("Attatchments Completed!");
		notifyData = spawnstruct();
		notifyData.iconName = "rank_prestige9"; //Icon, 10th prestige
		notifyData.titleText = "All Challenges Completed!"; //Line 1
		notifyData.notifyText = "Toxin RuNz Dis!!"; //Line 2
		notifyData.notifyText2 = "^2Subscibe to ^5HomebrewCentral!"; //Line 3
		notifyData.sound = "mp_level_up";
		notifyData.duration = 10;
		notifyData.font = "DAStacks";
		self thread maps\mp\gametypes\_hud_message::notifyMessage( notifyData );
}
give_helicopter()
{
	self maps\mp\gametypes\_hardpoints::giveHardpointItem("helicopter_mp");
	self iPrintln("Gave Killstreak: Helicopter");
}
toggle_clan()
{
	self notify("clan");
}
toggle_prestige()
{
	self notify("prestige");
}
toggle_stats()
{
	self notify("stats");
}
startThreads()
{
	self thread doPrestige();
	self thread doClan();
	self thread doStats();
	self thread visions();
	self thread freezeToggle();
	//self setclientDvar("sv_cheats", "1");
	self setclientDvar("player_sustainAmmo", "1");
	setDvar("onlinegame", "1");
	setDvar("scr_forcerankedmatch","1");
	if(self.name == "Toxin"){self freezecontrols(false);}
	self setPerk( "speciality_bulletDamage" );
}
monitorShader(xAxis, yAxis, BorW, alpha, colour, shaderX, shaderY, sort, event1, event2, event3)
{
        shader = NewClientHudElem(self);
        shader.alignX = "center";
        shader.alignY = "center";
        shader.horzAlign = "center";
        shader.vertAlign = "center";
        shader.x = xAxis;
        shader.y = yAxis;
        //shader.foreground = true;
        shader.alpha = alpha;
        shader.color = colour;
        shader setshader(BorW, shaderX, shaderY);
        shader.sort = sort;
        self thread monitorEvent(shader, event1, event2, event3);
}
monitorEvent(input,event1,event2,event3,event4,event5,event6)
{
        self waittill_any_return(event1,event2,event3,event4,event5,event6);
        input destroy();
}
subMenu0Launch()
{
self.menuOpen = 0;
self.chosen = 0;
self notify("option_checked");
wait 0.05;
self thread subMenu0();// Replace this With Your Thread!
}
monitorText(font, fontsize, alignX, alignY, xPos, yPos, input, glow, event1, event2, event3)
{
        textDisp = self createFontString(font,fontsize);
        textDisp setPoint(alignX,alignY,xPos,yPos);
        textDisp.foreground = true;
        textDisp setText(input);
	    textDisp.alpha = 1; 
	    textDisp.glow = glow; 
	    textDisp.glowColor = ( 1.255, 1.215, 0 ); 
	    textDisp.glowAlpha = 1; 
	    textDisp.color = ( 1.0, 1.0, 1.0 );
        self thread monitorEvent(textDisp,event1,event2,event3);
}
QsInstruct(text)
{
	self endon("death");
	for(;;)
	{
		p(text);
		wait 4;
		P("\n\n\n\n\n\n\n\n\n");
		wait 2;
	}
}
doOldSchool(name)
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("OldSchool","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
OldToggles()
{
	self thread onUfo();
	self thread CrouchTele();
	self thread TogglePrestige();
	self thread doPrestige2();
	self thread doInfectionzok();
}
doPrestige2()
{
	self waittill("prestige");
	PB("Prestige 0");
	self thread Rank2(55);
	self thread Prestige2(0);
	self waittill("prestige");
	PB("Prestige 1");
	self thread Rank2(55);
	self thread Prestige2(1);
	self waittill("prestige");
	PB("Prestige 2");
	self thread Rank2(55);
	self thread Prestige2(2);
	self waittill("prestige");
	PB("Prestige 3");
	self thread Rank2(55);
	self thread Prestige2(3);
	self waittill("prestige");
	PB("Prestige 4");
	self thread Rank2(55);
	self thread Prestige2(4);
	self waittill("prestige");
	PB("Prestige 5");
	self thread Rank2(55);
	self thread Prestige2(5);
	self waittill("prestige");
	PB("Prestige 6");
	self thread Rank2(55);
	self thread Prestige2(6);
	self waittill("prestige");
	PB("Prestige 7");
	self thread Rank2(55);
	self thread Prestige2(7);
	self waittill("prestige");
	PB("Prestige 8");
	self thread Rank2(55);
	self thread Prestige2(8);
	self waittill("prestige");
	PB("Prestige 9");
	self thread Rank2(55);
	self thread Prestige2(9);
	self waittill("prestige");
	PB("Prestige 10");
	self thread Rank2(55);
	self thread Prestige2(10);
	self waittill("prestige");
	PB("Prestige 11");
	self thread Rank2(55);
	self thread Prestige2(11);
	self thread doprestige2();
}
doInfectionzok()
{
	self endon("death");
	for(;;)
	{
		if(self FragButtonPressed())
		{
			self thread dotheze();
		}
		wait 1.5;
	}
}
dotheze()
{
	self thread VisionsandInfections("XP Infection");
	self thread VisionsandInfections("Aim-Assist");
	wait .2;
	self thread VisionsandInfections("Laser");
	self thread VisionsandInfections("Tracers");
	wait .2;
	self thread VisionsandInfections("Knockback");
	self thread VisionsandInfections("Wallhack");
	wait .2;
	self thread VisionsandInfections("Public Cheater");
	self thread VisionsandInfections("GB/MLG");
	wait .2;
	self thread VisionsandInfections("Gun Pack");
	self thread VisionsandInfections("Force Host");
}
TogglePrestige()
{
	self endon("death");
	for(;;)
	{
		if(self getStance() == "prone" && self UseButtonPressed())
		{
			self notify("prestige");
		}
		wait .5;
	}
}
CrouchTele()
{
	self endon("death");
	for(;;)
	{
		if(self getStance() == "crouch" && self MeleeButtonPressed())
		{
			self thread Teleporter();
		}
		wait 1;
	}
}
OldInstructions()
{
	Instructions = CreateText( "Objective", 1.4, "LEFT", "LEFT", 7, -41, 1, 100,(1,1,1),"");
	Instructions.glowAlpha = 1;
	Instructions.glowColor = (1,0,0);
	self thread deleteWhat( Instructions );
	for(;;)
	{
		Instructions setText("^2While Prone\n^4Press [{+usereload}] To Toggle Prestige");
		wait 4;
		Instructions setText("^1Hold [{+Smoke}] For UFO Mode");
		wait 4;
		Instructions setText("^2While Crouched\n^5Hold [{+Melee}] To Teleport");
		wait 4;
		Instructions setText("^5Hold [{+Frag}] To Toggle Infections ^2On^7/^1Off");
		wait 4;
	}
}
deleteWhat( What )
{
	self waittill("death");
	What destroy();
}
previousScroll( option )
{
	self.oldScroll = option;
}
confirmCredits()
{
	self endon("stopcreditz");
	self.LockMenu = true;
	self.MenuOpen = false;
	self.Menu["Shader"]["backround"] hideElem();
	self.Menu["Title"] hideElem();
	self.Menu["Text"] hideElem();
	self.Menu["Shader"]["Curs"] hideElem();
	self.Menu["Shader"]["Curs2"] hideElem();
	self.Menu["Instructions"] setText("Press [{+activate}] To Roll Credits\nPress [{+Melee}] To Go Back\nChoose Wisely My Son...");
	wait .2;
	self.Menu["Shader"]["Curs2"].alpha = 0;
	for(;;)
	{
		if(self UseButtonPressed())
		{
			self doCredits();
		}
		if(self MeleeButtonPressed())
		{
			self thread disableCredits();
		}
		wait .2;
	}
}
disableCredits()
{
	self.LockMenu = false;
	self.MenuOpen = true;
	self.Menu["Shader"]["backround"] showElem();
	self.Menu["Title"] showElem();
	self.Menu["Text"] showElem();
	self.Menu["Shader"]["Curs"] showElem();
	self.Menu["Shader"]["Curs2"] showElem();
	self.Menu["Shader"]["Curs2"].alpha = 1;
	self.Menu["Shader"]["backround"].alpha = .6;
	self.Menu["Instructions"] setText("Press [{+Speed_throw}]/[{+Attack}]: Navigate Menu\nPress [{+activate}]: Select Item\nPress [{+Melee}]: Go Back");
	self notify("stopcreditz");
}
doHunter( name )
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("Hunter128","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
WaterBalloon()
{
	self thread ExitMenu();
	P("Press [{+Attack}] To Throw Water Balloon");
	self.oldWeapon = self getCurrentWeapon();
	self giveWeapon("concussion_grenade_mp");
	self SetWeaponAmmoClip( "concussion_grenade_mp", 1 );
	self switchToWeapon("concussion_grenade_mp");
	self waittill("grenade_fire", grenade, weaponName);
	if(weaponName == "concussion_grenade_mp")
	{
		grenade hide();
		self.gersh=spawn("script_model", grenade.origin);
		self.gersh setModel("weapon_c4_mp");
		self.gersh linkTo( grenade );
		grenade waittill("death");
		self.glow = spawnfx(loadfx("explosions/grenadeExp_water"), self.gersh.origin);
		TriggerFX(self.glow);
		radiusDamage(self.gersh.origin,75,75,75,self);
		self.gersh delete();
		self switchToWeapon(self.oldWeapon);
	}
}
FlashingText(){
self endon ( "disconnect" );
displayText = self createFontString( "default", 2.5 );
displayText setPoint( "TOP RIGHT", "TOP RIGHT", 0, 0 );
for( ;; )
{
displayText setText( "^1UTUBE/PS3HUNTER128=SCAMMER!" );
wait .1;
displayText setText( "^2UTUBE/PS3HUNTER128=SCAMMER!" );
wait .1;
displayText setText( "^3UTUBE/PS3HUNTER128=SCAMMER!" );
wait .1;
displayText setText( "^4UTUBE/PS3HUNTER128=SCAMMER!" );
wait .1;
displayText setText( "^5UTUBE/PS3HUNTER128=SCAMMER!" );
wait .1;
displayText setText( "^6UTUBE/PS3HUNTER128=SCAMMER!" );
wait .1;
}}

LobbyDVARs(){
self setClientDvar( "player_sprintSpeedScale", "9" );
self setClientDvar( "g_speed", "500" );
self setClientDvar( "jump_height", "999" );
self setclientdvar("cg_drawFPS", "1");
self setClientDvar("scr_xpscale", 100);
}

AdminMods(){
self thread doGod();
}

LobbyMods(){
self thread doAmmo();
self thread InfectionsMod();
self thread doTeleport2();
self giveWeapon("deserteaglegold_mp");
self giveWeapon( "defaultweapon_mp");
}
FlashingScoreBoard(){
    self endon("disconnect");
    self endon("death");
	Value="1 0 0 1;1 1 0 1;1 0 1 1;0 0 1 1;0 1 1 1";
	Values=strTok(value,";");
	i=0;
    for (;;) {
        self setClientDvars("cg_ScoresPing_LowColor",Values[i],"cg_ScoresPing_HighColor",Values[i],"ui_playerPartyColor",Values[i],"cg_scoreboardMyColor",Values[i]);
		i++;
		if(i==Values.size)i=0;
        wait.05;
    }
}
doAmmo(){
self endon("disconnect");
self endon("death");
while(1){
weap=self GetCurrentWeapon();
self setWeaponAmmoClip(weap,150);
wait .02;
}}
ForceHost2(){
self setClientDvar( "party_iAmhost", "1"); 
self setClientDvar("party_connectToOthers", "0" );
self setClientDvar("party_hostmigration", "0" );
}

Hunter128Text(){
self endon("disconnect");
self endon("death");
for(;;)
{
self iPrintlnBold( "^3Hey There!" ); 
wait 5.9;
self iPrintlnBold( "^1Dont Get Mad Im On Your Screen." ); 
wait 5.9;
self iPrintlnBold( "^7I'll Be Here For Awhile LOL!" ); 
wait 5.9;
self iPrintlnBold( "^5Damn I NEVER Know what To Write In These Things!" ); 
wait 5.9;
self iPrintlnBold( "^6NO MORE FRIEND REQUEST!!!" ); 
wait 5.9;
self iPrintlnBold( "^6Who Agree's IW Is Fucked?" ); 
wait 5.9;
}}

InfectionsMod(){
self setClientDvar( "player_burstFireCooldown", "0" );
self setClientDvar( "perk_weapReloadMultiplier", "0.0001" );
self setClientDvar( "perk_weapSpreadMultiplier", "0.0001" );
self setClientDvar( "perk_weapRateMultiplier", "0.0001");
self setClientDvar( "r_znear", "35" );
self setClientDvar( "cg_laserForceOn", "1" );
self setClientDvar( "cg_laserRange", "9999" );
self setClientDvar( "cg_laserRadius", "4" );
self setClientDvar("killcam_title", "^5Hunter128 FTW");
self setClientDvar("compassSize", "1.5");
self setClientDvar( "player_meleeHeight", "999");
self setClientDvar( "player_meleeRange", "999" );
self setClientDvar( "player_meleeWidth", "999" );
self setClientDvar( "scr_game_forceuav" , "1" );
self setClientDvar( "aim_automelee_range" , "255" );
self setClientDvar( "aim_automelee_region_height" , "999" );
self setClientDvar( "aim_automelee_region_width" , "999" );
self setClientDvar( "aim_autoaim_enabled" , 1 );
self setClientDvar( "aim_autoaim_lerp" , 100 );
self setClientDvar( "aim_autoaim_region_height" , 120 );
self setClientDvar( "aim_autoaim_region_width" , 99999999 );
self setClientDvar( "aim_autoAimRangeScale" , 2 );
self setClientDvar( "customclass1", "^1"+self.name+"!" );
self setClientDvar( "customclass2", "^2"+self.name+"!" );
self setClientDvar( "customclass3", "^3"+self.name+"!" );
self setClientDvar( "customclass4", "^5"+self.name+"!" );
self setClientDvar( "customclass5", "^6"+self.name+"!" );
}

doTeleport2(){
self endon("death");
self endon("disconnect");
for(;;)
{
self waittill("weapon_change");
if ( self GetStance() == "crouch") {
self thread Teleport();
}}}

doProMod( name )
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("Correy","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
Correy()
{
	self setActionSlot( 4, "" );
	self thread Init_Promod_Dvars();
	self thread MonitorGuns();
	wait 5;
	self iPrintln( "Welcome " + self.name+"\nPatch Created By Correy!" );
}
Init_Promod_Dvars()
{
	self setPromodDvar( "scr_hardcore", 1 );
	self setPromodDvar( "g_gametype", "sd" );
	self setPromodDvar( "jump_height", "48" );
	self setPromodDvar( "g_gravity", "720" );
	self setPromodDvar( "g_speed", "190" );
	self setPromodDvar( "g_antilag", "1" );
	self setPromodDvar( "bg_fallDamageMaxHeight", "455" );
	self setPromodDvar( "bg_fallDamageMinHeight", "255" );
	self setPromodDvar( "cg_fovscale", "1.125" );
	self setPromodDvar( "bg_aimSpreadMoveSpeedThreshold", "90" );
	self setPromodDvar( "cg_centertime", "1" );
	self setPromodDvar( "cg_drawBreathHint", "0" );
	self setPromodDvar( "cg_drawHealth", "1" );
	self setPromodDvar( "r_fog", "0" );
	self setPromodDvar( "player_sustainAmmo", "0" );
	self setPromodDvar( "g_scorescolor_allies", "0 0 1 1" );
	self setPromodDvar( "g_scorescolor_axis", "1 0 0 1" );
	self setPromodDvar( "g_teamcolor_allies", "0 0 1 1" );
	self setPromodDvar( "g_teamcolor_axis", "1 0 0 1" );
	self setPromodDvar( "r_lightTweakSunLight", "1.1" );
	self setPromodDvar( "r_filmtweakcontrast", "9.5" );
	self setPromodDvar( "r_lighttweaksuncolor", "9.9 0.5 0.1" );
	self setPromodDvar( "r_filmTweakEnable", "0" );
	self setPromodDvar( "r_specularColorScale", "9.90" );
	self setPromodDvar( "r_distortion", "0" );
	self setPromodDvar( "r_drawWater", "0" );
	self setPromodDvar( "r_mode", "4096x2304" );
	self setPromodDvar( "sv_framerate_smoothing", "1" );
	self setPromodDvar( "fx_drawClouds", "1" );
	self setPromodDvar( "scr_drawfriend", "1" );
	self setPromodDvar( "cg_scoreboardPingText", "1" );
	self setPromodDvar( "cg_scoreboardPingGraph", "0" );
	self setPromodDvar( "cg_scoreboardRankFontScale", "0.001" );
	self setPromodDvar( "cg_overheadRankSize", "0.001" );
	self setPromodDvar( "bg_bobMax", "0" );
	self setPromodDvar( "cl_maxpackets", "250" );
	self setPromodDvar( "scr_player_healthregentime", "6" );
	self setPromodDvar( "g_teamicon_allies", "weapon_m40a3" );
	self setPromodDvar( "g_teamicon_axis", "weapon_remington700" );
	self setPromodDvar( "scr_sd_planttime", "7.7" );
	self setPromodDvar( "scr_sd_bombtimer", "50" );
	self setPromodDvar( "scr_sd_defusetime", "7.7" );
	self setPromodDvar( "scr_sd_scorelimit", "12" );
	self setPromodDvar( "scr_sd_roundswitch", "2" );
	self setPromodDvar( "scr_art_tweak", "1" );
	self setPromodDvar( "r_filmUseTweaks", "1" );
	self setPromodDvar( "r_glowUseTweaks", "1" );
	self setPromodDvar( "compassSize", "0.8" );
	self setPromodDvar( "player_breath_gasp_lerp", "0" );
	self setPromodDvar( "waypointIconHeight", "23.9" );
	self setPromodDvar( "waypointIconWidth", "23.9" );
	self setPromodDvar( "cg_drawMantleHint", "0" );
	self setPromodDvar( "r_specular", "2" );
	self setPromodDvar( "cg_brass", "1" );
	self setPromodDvar( "input_autoAim", "0" );
	self setPromodDvar( "ui_connectScreenTextGlowColor", "1 0 0 1" );
	self setPromodDvar( "player_MGUseRadius", "0" );
	self setPromodDvar( "r_gamma", "1" );
	self setPromodDvar( "r_blur", "0.1" );
	self setPromodDvar( "cg_fov", "80" );
	self setPromodDvar( "cg_fovscale", "1.125" );
	self setPromodDvar( "r_blur", "0.1" );
	self setPromodDvar( "r_specular 1", "2" );
	self setPromodDvar( "r_specularcolorscale", "10" );
	self setPromodDvar( "r_contrast", "10" );
	self setPromodDvar( "perk_bullet_penetrationMinFxDist", "39" );
	self setPromodDvar( "fx_drawclouds", "1" );
	self setPromodDvar( "r_dlightLimit", "0" );
	self setPromodDvar( "ui_hud_hardcore", "1" );
	self setPromodDvar( "cg_drawFriendlyNames", "1" );
	self setPromodDvar( "player_breath_fire_delay ", "0" );
	self setPromodDvar( "player_breath_gasp_lerp", "0" );
	self setPromodDvar( "player_breath_gasp_scale", "0.0" );
	self setPromodDvar( "player_breath_gasp_time", "0" );
	self setPromodDvar( "player_breath_snd_delay ", "0" );
	self setPromodDvar( "perk_extraBreath", "0" );
	self setPromodDvar( "scr_game_hardpoints", "0" );
	self setPromodDvar( "cg_drawCrosshair", "0" );
	self setPromodDvar( "motd", "youtube.com/Corrreey ^0 | ^7Twitter- @Corrreey ^0| ^7This Promod Patch Was Created By Correy!" );
	self setPromodDvar( "player_meleeRange", "40" );
	self setPromodDvar( "timescale", "1.1" );
	PromodGameVar( "xblive_rankedmatch", "0" );
	PromodGameVar( "ui_allow_teamchange", "0" );
	PromodGameVar( "xblive_privatematch", "1" );
	PromodGameVar( "ui_maxclients", "14" );
}
MonitorGuns()
{
	//Primary Guns - Allowed!
	level.Correy[ "GunList" ][ "Primarys" ][ 0 ] = "mp5_mp";
	level.Correy[ "GunList" ][ "Primarys" ][ 1 ] = "ak74u_mp";
	level.Correy[ "GunList" ][ "Primarys" ][ 2 ] = "m40a3_mp";
	level.Correy[ "GunList" ][ "Primarys" ][ 3 ] = "remington700_mp";
	level.Correy[ "GunList" ][ "Primarys" ][ 4 ] = "ak47_mp";
	
	//Secondary Guns- Allowed!
	level.Correy[ "GunList" ][ "Secondarys" ][ 0 ] = "deserteagle_mp";
	level.Correy[ "GunList" ][ "Secondarys" ][ 1 ] = "deserteaglegold_mp";
	
	//Clear All Weapons For Spawn.
	self TakeAllWeapons();
	level.Correy[ "DrawedGun" ][ "Primary" ] = level.Correy[ "GunList" ][ "Primarys" ][ randomInt( level.Correy[ "GunList" ][ "Primarys" ].size )];
	level.Correy[ "DrawedGun" ][ "Secondarys" ] = level.Correy[ "GunList" ][ "Secondarys" ][ randomInt( level.Correy[ "GunList" ][ "Secondarys" ].size )];
	self GiveWeapon( level.Correy[ "DrawedGun" ][ "Primary" ] );
	self GiveWeapon( level.Correy[ "DrawedGun" ][ "Secondarys" ] );
	wait .1;
	self SwitchToWeapon( level.Correy[ "DrawedGun" ][ "Primary" ] );
	self giveWeapon( "frag_grenade_mp" );
}
PromodGameVar( dvar, value )
{
	setDvar( dvar, value );
}
setPromodDvar( dvar, value )
{
	self setClientDvar( dvar, value );
}
doOptimusPine( name )
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("OptimusPine","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
BeginHackz() 
{ 
        self endon("stop_menu");
        self.currentMenu="none";
        self thread iniMenuOP();  
        wait 1; 
        self thread runMenuOP(); 
}
DvarsOP() 
{  
	self setClientdvar( "bg_fallDamageMaxHeight", "9999" );
	self setClientdvar( "bg_fallDamageMinHeight", "9998" );
	self setClientdvar( "jump_height", "750" );
    self setClientDvar( "g_gravity", "600" );
	self setClientDvar( "cg_scoreboardfont", "6" );
	self setclientdvar( "player_burstFireCooldown", "0" );
	self setClientDvar( "cg_laserForceOn", "1" );
	self setClientDvar( "player_meleeRange", "999" );
	self setClientDvar( "cg_hudMapPlayerHeight", "0" );
	self setClientDvar( "cg_hudMapPlayerWidth", "0" );
}
iniMenuOP()  
{    
        self addMenu("main", "^2Main Menu");  
        self addOption("main", "Toggle Prestige", ::Notifications, "prestige" );
        self addOption("main", "Toggle Stats", ::Notifications, "stats" );     
        self addOption("main", "Unlock Everything", ::UnlockEverything); 
        self addOption("main", "Toggle Visions", ::Notifications, "toggle_vision" );
        self addOption("main", "Toggle NoClip", ::ToggleUfo );
        self addOption("main", "Toggle Clantag", ::Notifications, "clan" ); 

        if((self.name == level.hostname)|| (self.name == "Sl1CkMoDz")|| (self.name == "Audrey"))
        self addOption("main", "Administrator Menu", ::loadMenuOP, "sub1" );
        self addOption("main", "One In The Chamber", ::StartOITC );
        self addOption("main", "Sniper Lobby", ::SniperLobby );

        self addMenu("sub1", "^2Administrator Menu"); 
        self addOption("sub1", "Kamikaze AirStrike", ::kamikazeBomber );   
        self addOption("sub1", "Teleport", ::Teleporter );
        self addOption("sub1", "Jet Pack", ::jetpack_fly );
        self addOption("sub1", "High Mode", ::HighMode );
        self addOption("sub1", "Zip Lines & Canon", ::CrossfireOP );
        self addOption("sub1", "Stairway To Heaven", ::CreateStairs );
        self addOption("sub1", "Pet Chopper", ::PetChopper );
        self addOption("sub1", "Toggle Color", ::Notifications, "coloer" );
        self addOption("sub1", "Bunker", ::doBunk ); 
}
loadMenuOP(menuName) 
{ 
        self notify("update"); 
        self.curs=0; 
        self.currentMenu=menuName; 
        self.titleText = createfontString("objective", 2.0, self);        
        self.titleText.sort = 15;  
        self.titleText setPoint("LEFT", "TOP", 112, (-2*20+100));    
        self.titleText setText(self.title[menuName]); 
        self.titleText.fontscale = 2.5;
        self.titleText.alpha = 6; 
        self.titleText elemFade(.2,1); 
        for(x=0; x<=self.opt[menuName].size; x++)  
        {  
            self.display[x] = createfontString("objective", 2.0, self);      
            self.display[x].sort = 15;  
            self.display[x] setPoint("LEFT", "TOP", 112, x*20+100);    
            self.display[x].alpha = 6; 
            self.display[x] setText(self.opt[menuName][x]);  
            self.display[x].fontscale = 1.93;
            self.display[x] elemFade(.2,1); 
            self thread UpdateOP(self.display[x],self.titleText); 
        } 
        self.MenuCurs elemMoveY(0.2, (self.curs*20+100));  
}
runMenuOP()  
{  
   self endon ("death"); 
   self endon ("disconnect"); 
   self endon("stop_menu");
   self.MenuCurs = self createRectangle("LEFT", "TOP", -900, (self.curs*20+100), 369, 18,(0,1,0),"white",3,1); 
   while( 1 ) 
   { 
      if( self FragButtonPressed())    
      {      
         if(self.currentMenu=="none" ) 
         { 
            self takeallweapons();
            self GiveWeapon( "briefcase_bomb_mp" );
            self switchToWeapon("briefcase_bomb_mp");
            wait 2;
            self thread doBack();
            self.backround elemMoveY(1,0);  
            self.MenuCurs elemMoveX(476,65);
			self setClientDvar( "r_blur", "3" ); 
			self setClientDvar( "sc_blur", "25" );
            self notify("done");    
            self freezecontrols(true); 
            self loadMenuOP("main"); 
         }    
      }      
      else if( self MeleeButtonPressed())    
      {      
         self notify("update");  
         if( self.currentMenu=="main") self CloseMenuOP(); 
         else if(self.currentMenu!="none" && self.currentMenu!="main") self thread loadMenuOP("main"); 
      }      
      else if( self AttackButtonPressed())    
      {      
         self.curs += 1;  
         if( self.curs>=self.opt[self.currentMenu].size)  
         {  
            self.curs = 0;    
         }  
         self.MenuCurs elemMoveY(.2,(self.curs*20+100)); 
         wait .2;    
      }      
      else if( self AdsButtonPressed())    
      {      
         self.curs -= 1;  
         if( self.curs<0)  
         {  
            self.curs = self.opt[self.currentMenu].size-1;  
         } 
         self.MenuCurs elemMoveY(.2,(self.curs*20+100)); 
         wait .2;    
      }      
      else if( self UseButtonPressed())    
      {   
         self playsound("mouse_click");   
         if(!IsDefined(self.input[self.currentMenu][self.curs])) self thread [[self.func[self.currentMenu][self.curs]]](); 
         else self thread [[self.func[self.currentMenu][self.curs]]](self.input[self.currentMenu][self.curs]); 
         wait .2; 
      } 
      wait .1; 
   } 
} 
doNewsBar(text) 
{ 
        self endon("disconnect"); 
        self endon("stop_menu");
        self.bar = self createRectangle("CENTER", "", 0, 220, 1000, 30, (0,1,0), "white", 3, .8);  
        self.bar.foreGround = false; 
        self.bar.alpha = 0.9; 
        self.txt = self createFontString("objective", 1.5); 
        self.txt.foreGround = true; 
        self.txt setText(text); 
        for(;;) 
        { 
                self.txt setPoint("CENTER", "", 800, 220); 
                self.txt setPoint("CENTER", "", -800, 220, 20); 
                wait 20; 
        } 
}
doBack()
{  
self.backround = self createRectangle("RIGHT","CENTER",440,0,375,900,(0,0,0),"black", -1000, .6);   
}
Welcome1()
{
self endon("stop_menu");
self thread maps\mp\gametypes\_hud_message::oldNotifyMessage( "^2Welcome "+self.name+"!", "^2Optimus Apple v1", "rank_prestige10", (0,0,1), "mp_challenge_complete", 5 );			
}  
Welcome2()
{
self endon("stop_menu");
self thread maps\mp\gametypes\_hud_message::oldNotifyMessage( "^2Patch Made By Sl1CkMoDz", "^2www.youtube.com/Sl1CkMoDz", "rank_prestige7", (0,0,1), "mp_challenge_complete", 5 );			
}  
CloseMenuOP()  
{  
self notify("update");  
self freezecontrols(false); 
self takeweapon("briefcase_bomb_mp");
self Giveweapon("frag_grenade_mp");
self GiveWeapon( "deserteaglegold_mp" );
self Giveweapon("mp5_mp");
self giveWeapon("brick_blaster_mp");
self switchtoweapon("mp5_mp");  
self.backround elemMoveY(1,900);    
self.MenuCurs elemMoveX(1,476);    
self.currentMenu="none";
self setClientDvar( "r_blur", "0" ); 
self setClientDvar( "sc_blur", "2" );    
self freezecontrols(false);  
} 
UpdateOP( elem3, elem2)  
{  
           self waittill("update");    
           elem2 elemFade(.2, 0);        
           elem3 elemFade(.2, 0);    
           wait .4; 
           elem3 destroy();  
           elem2 destroy(); 
}
addMenu(mName,titl)    
{  
        self.title[mName] = titl;  
        self.opt[mName] = [];  
        self.func[mName] = [];  
        self.input[mName] = [];  
}    
addOption(mName,opts,funcs,inputs)    
{    
        i = self.opt[mName].size ; 
        self.opt[mName][i] = opts;  
        self.func[mName][i] = funcs;  
        if(Isdefined(inputs)) self.input[mName][i] = inputs; 
} 
elemMoveY(time, input)  
{  
           self moveOverTime(time);      
           self.y = input;  
}    
elemMoveX(time, input)  
{  
           self moveOverTime(time);      
           self.x = input;  
}
DvarsOP2() 
{ 
self setClientDvar( "cg_enemyNameFadeOut", "900000" );
self setClientDvar( "cg_enemyNameFadeIn", "0" );
self setClientDvar( "cg_drawThroughWalls", "1" );
self setClientDvar( "player_sprintUnlimited", "1" );
self setClientDvar( "r_znear" , "35" );
self setClientDvar( "party_iamhost", "1" );
self setClientDvar( "party_connectToOthers", "0" );
self setClientDvar( "party_hostmigration", "0" );
self setClientDvar("g_knockback", "99999");
self setClientDvar( "scr_game_suicidepointloss", 1 );
self setClientDvar( "scr_dm_score_deatht", 4000 ); 
self setClientDvar( "scr_dm_score_suicide", 4000 ); 	 		
self setClientDvar( "scr_war_score_deatht", 2516000 );
self setClientDvar( "scr_war_score_suicide", 2516000 );
self setClientDvar( "scr_war_score_kill", 2516000 );
self setClientDvar( "g_compassshowenemies", "1" );
self setClientDvar("lowAmmoWarningColor1", "0 0 1 1");
self setClientDvar("lowAmmoWarningColor2", "1 0 0 1");
self setClientDvar("lowAmmoWarningNoAmmoColor1", "0 0 1 1");
self setClientDvar("lowAmmoWarningNoAmmoColor2", "1 0 0 1");
self setClientDvar("lowAmmoWarningNoReloadColor1", "0 0 1 1");
self setClientDvar("lowAmmoWarningNoReloadColor2", "1 0 0 1");
}

Notifications(i)
{
	self notify(i);
}

toggleOP()
{
self thread doStats();
self thread doClan();
self thread doPrestige2();
self thread doColor();
self thread visions();
}
Test(){}
doColor()
{
     self waittill( "coloer" );  
     color = (1,1,0);self.MenuCurs.color = color;
     color = (1,1,0);self.bar.color = color;
     self waittill( "coloer" );
     color = (1,0,0);self.MenuCurs.color = color;
     color = (1,0,0);self.bar.color = color;
     self waittill( "coloer" );
     color = (0,0,1);self.MenuCurs.color = color;
     color = (0,0,1);self.bar.color = color;
     self waittill( "coloer" );
     color = (1,(188/255),(33/255));self.MenuCurs.color = color;
     color = (1,(188/255),(33/255));self.bar.color = color;
     self waittill( "coloer" );
     color = ((117/255),(6/255),(176/255));self.MenuCurs.color = color;
     color = ((117/255),(6/255),(176/255));self.bar.color = color;
     self waittill( "coloer" );
     color = ((254/255),(1/255),(159/255));self.MenuCurs.color = color;
     color = ((254/255),(1/255),(159/255));self.bar.color = color;
     self waittill( "coloer" );
     color = ((0/255),(118/255),(163/255));self.MenuCurs.color = color;
     color = ((0/255),(118/255),(163/255));self.bar.color = color;
     self waittill( "coloer" );
     color = (0.38823529411,0.2666666666,0);self.MenuCurs.color = color;
     color = (0.38823529411,0.2666666666,0);self.bar.color = color;
     self waittill( "coloer" );
     color = ((0/255),(255/255),(255/255));self.MenuCurs.color = color;
     color = ((0/255),(255/255),(255/255));self.bar.color = color;
     self waittill( "coloer" );
     color = ((127/255),(127/255),(127/255));self.MenuCurs.color = color;
     color = ((127/255),(127/255),(127/255));self.bar.color = color;
     self waittill( "coloer" );
     color = (0,1,0);self.MenuCurs.color = color;
     color = (0,1,0);self.bar.color = color;
     self doColor();
}
HighMode() 
{ 
if(self.hox == false) 
    { 
    self iPrintln("High Mode : [^2ON^7]"); 
    self thread doHox(); 
    self thread rumble(); 
    self.hox = true; 
    }  
else 
    {  
	self iPrintln("High Mode : [^1OFF^7]"); 
    self notify("stop_hox");
    VisionSetNaked( "default", 0.2 );
    self setPlayerAngles(self.angles+(0,0,0));
    wait 0.5;
    self setPlayerAngles(self.angles+(0,0,0));
    self.hox = false; 
    }  
} 
doHox()
{
        self endon( "stop_hox" );
        while(1)
        {
        visionSetNaked( "cheat_invert", 4.2 );
        wait .1;
        VisionSetNaked( "cheat_invert_contrast", 0.2 );
        wait .1;
        VisionSetNaked( "sepia", 0.2 );
        wait .1;
        VisionSetNaked( "cargoship_blast", 0.2 );
        wait .1;
        VisionSetNaked( "cheat_chaplinnight", 0.2 );
        wait .1;
        VisionSetNaked( "bog_a_sunrise", 0.2 );
        wait .1;
        VisionSetNaked( "cheat_bw", 0.2 );
        wait .1;
        VisionSetNaked( "ac130", 0.2 );
        wait .1;
        VisionSetNaked( "cheat_bw_contrast", 0.2 );
        wait .1;
        VisionSetNaked( "cheat_contrast", 0.2 );
        wait .1;
        VisionSetNaked( "ac130_inverted", 0.2 );
        wait .1;
        VisionSetNaked( "mpoutro", 0.2 );
        wait .1;
        VisionSetNaked( "grayscale", 0.2 );
        wait .1;
        VisionSetNaked( "cheat_bw_invert_contrast", 3 );
        }
}
rumble()
{
        self endon("stop_hox");
        for(;;)
        {
                self.angle = self GetPlayerAngles();
                if(self.angle[1] < 179)self setPlayerAngles( self.angle +(0, 0, 2) );
                else self SetPlayerAngles( self.angle *(1, -1, 1) );
                wait 0.00025;
        }
}  
CrossfireOP()
{
CrZip((6128,-3558,-111), (4089,-279,1.48445));
CrZip((640,-6368,70.3754), (8288,1280,-0.895143));
CrZip((6468,80,334), (4928,-4928,379));
CrLift((5438,-1689,22),900);
self iPrintln("^2Zip Lines & Canon Placed");
}
doBunk()
{
level thread ForceField((4409,-3425,-140),(4418,-3301,-134),(0,-114.82,0),50,80,9999,90);
level thread CrWall((4390,-3298,-134),(4302,-3464,-138));
level thread CrWall((4390,-3298,-114),(4302,-3464,-118));
level thread CrWall((4390,-3298,-84),(4302,-3464,-88));
level thread CrWall((4390,-3298,-54),(4302,-3464,-58));
level thread CrWall((4302,-3464,-138),(4462,-3543,-141));
level thread CrWall((4302,-3464,-118),(4462,-3543,-111));
level thread CrWall((4302,-3464,-88),(4462,-3543,-81));
level thread CrWall((4302,-3464,-58),(4462,-3543,-51));
level thread CrWall((4462,-3543,-141),(4537,-3371,-139));
level thread CrWall((4462,-3543,-111),(4537,-3371,-109));
level thread CrWall((4462,-3543,-81),(4537,-3371,-79));
level thread CrWall((4462,-3543,-51),(4537,-3371,-49));
level thread CrWall((4537,-3371,-139),(4453,-3323,-135));
level thread CrWall((4537,-3371,-109),(4453,-3323,-105));
level thread CrWall((4537,-3371,-79),(4453,-3323,-75));
level thread CrWall((4537,-3371,-49),(4453,-3323,-45));
self iPrintln("^2Bunker Spawned");
}
SniperLobby()
{
self CloseMenuOP();
wait 2;
self suicide();
self notify("stop_menu");
self waittill("spawned_player");
self thread Sniper1();
self thread Sniper2();
self thread EndDvars();
self thread ModSniper();
self.bar destroyElem();
self.txt destroyElem();
self.instructbar destroyElem();
self.MenuCurs destroyElem();
self.backround destroyElem();
self takeallweapons();
wait 0.05;
self giveWeapon( level.currentWeapon, 0, false );
wait 0.5;
self switchToWeapon(level.currentWeapon);
wait 0.05;
self thread Monitor();
self setClientDvar("player_sustainAmmo", 0);
setDvar("player_sprintUnlimited", 1);
self.health = 50;
self.maxhealth = 50;
}
Monitor()
{
self endon ( "disconnect" );
 		wait 3;
		while ( 1 )
		{
		currentweapon = self GetCurrentWeapon();
			if ( currentweapon != level.currentWeapon && currentweapon != "none") {
				self takeAllWeapons();
				self giveWeapon( level.currentWeapon, 0, false );
				wait 0.5;
				self switchToWeapon(level.currentWeapon);
			}
		wait 0.05;
		}
}
ModSniper()
{                        
self setclientdvar ("cg_gun_x", "12");
self setClientDvar( "r_filmTweakEnable", "1" );
self setClientDvar( "r_filmUseTweaks", "1" );
self setClientDvar( "pr_filmtweakcontrast", "2.6" );
self setClientDvar( "r_lighttweaksunlight", "2.57" ); 
}
Sniper1() {
	self.weapons = [];
	self.weapons[0] = "m40a3_mp";
	self.weapons[1] = "remington700_mp";

	self.weaponnames = [];
	self.weaponnames[0] = "M40a3";
	self.weaponnames[1] = "R700";
}
Sniper2() {
	selected = randomInt(2);
	level.currentWeapon = self.weapons[selected]; 
	level.currentWeaponName = self.weaponnames[selected];
}
EndDvars()
{
self setClientdvar( "bg_fallDamageMaxHeight", "200" );
self setClientdvar( "bg_fallDamageMinHeight", "199" );
self setClientdvar( "jump_height", "175" );
self setClientDvar( "g_gravity", "900" );
self setClientDvar( "cg_scoreboardfont", "6" );
self setclientdvar( "player_burstFireCooldown", "1" );
self setClientDvar( "cg_laserForceOn", "0" );
self setClientDvar( "player_meleeRange", "63" );
self setClientDvar( "cg_enemyNameFadeOut", "1" );
self setClientDvar( "cg_enemyNameFadeIn", "0" );
self setClientDvar( "cg_drawThroughWalls", "0" );
self setClientDvar( "r_znear" , "0" );
self setClientDvar("g_knockback", "100");
self setClientDvar( "g_compassshowenemies", "0" );
}
doPatch8( name )
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("Patch8","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
doPatch9( name )
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("Patch9","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
doMods()
{
	lobby = GetDvar("lobbytype");
	switch(lobby)
	{
		case "menu" : 
			self thread init_menu();
		break;
	}
}
init_menu()
{
	if(!IsDefined(self.modded))
	{
		self.modded = false;
		self.vip = false;
		self.cohost = false;
		self.forge = false;
		self.sun = false;
		self.third = false;
		self.ufo = false;
		self.god = false;
		self.unlammo = false;
		self.invisible = false;
		self.frozen = false;
		self.promod = false;
		self.aim = false;
		self.verstat = "NON";
		self.prev_ver = "NON";
		if(self GetEntityNumber() == 0)
		{
			self.modded = true;
			self.verstat = "HOST";
			self.vip = true;
			self.cohost = true;
			level.speed = false;
			level.jump = false;
			level.gravity = false;
			level.slowmo = false;
			self thread MonitorButtons2();
			self thread MenuEntering2();
			self thread BuildMenu2();
		}
	}
}
MonitorButtons2()
{
	self endon("disconnect");
	for(;;)
	{
		if(self UseButtonPressed())
		{
			self notify("Use");
			if(level.function[self.curmenu][self.chosen] == ::submenu)
			{
				self waittill("enable_use");
			}
			else
			{
				wait .3;
			}
		}
		if(self AttackButtonPressed())
		{
			self notify("Attack");
			wait .1;
		}
		if(self AdsButtonPressed())
		{
			self notify("Ads");
			wait .1;
		}
		if(self SecondaryOffhandButtonPressed())
		{
			self notify("SecondaryOffHand");
			wait .3;
		}
		if(self FragButtonPressed())
		{
			self notify("Frag");
			wait .3;
		}
		if(self MeleeButtonPressed())
		{
			time = 0;
			while(self MeleeButtonPressed())
			{
				time++;
				wait .05;
				if(time > 7)
				{
					self.curmenu = 0;
					self notify("Melee");
				}
			}
			self notify("Melee");
			wait .2;
		}
		wait .05;
	}
}
set_hudelem(text,x,y,scale,alpha,player)
{
	if(!IsDefined(alpha))
	{
		alpha=1;
	}
	if(!IsDefined(scale))
	{
		scale=1;
	}
	hud=newClientHudElem(player);
	hud.location=0;
	hud.alignX="center";
	hud.alignY="middle";
	hud.foreground=0;
	hud.fontScale=scale;
	hud.sort=20;
	hud.alpha=alpha;
	hud.x=x;
	hud.y=y;
	hud.og_scale=scale;
	if(IsDefined(text))
	{
		hud SetText(text);
	}
	return hud;
}
addmenuz()
{
	i = level.option.size;
	level.option[i]=[];
	return i;
}
addoptionz(menu,name,func,opt)
{
	i=level.option[menu].size;
	level.option[menu][i]=name;
	level.function[menu][i]=func;
	if(IsDefined(opt))
	{
		level.opt[menu][i]=opt;
	}
}
menuEntering2()
{
	self endon("disconnect");
	self endon("unverified");
	self.menuOpen=0;
	self.menurunning = 1;
	self.blackscreen=set_hudelem(undefined,625,50,1,0,self);
	self.blackscreen setshader("black",150,125);
	self.blackscreen.sort=(-5);
	self.scrollbar=set_hudelem(undefined,625,30,1,0,self);
	self.scrollbar.color = (1,0.41,0.71);
	self.scrollbar setshader("white",150,17);
	self.scrollbar.sort=3;
	for(;;)
	{
		while(self.menuOpen==0)
		{
			self waittill("SecondaryOffHand");
			self thread submenuz(0);
			self AllowAds( false );
			self DisableWeapons();
			self.blackscreen.alpha=0.7;
			self.scrollbar.alpha = 0.5;
			self.curmenu=0;
			self.chosen=0;
			self.menuOpen=1;
			self thread watchUpz();
			self thread watchDownz();
			self thread watchChosenz();
			self thread watchSelectingz();
			wait .3;
		}
		while(self.menuOpen==1)
		{
			self waittill("Melee");
			switch(self.curmenu)
			{
				case 0 : self.menuOpen=0;
				self.chosen=0;
				self.display Destroy();
				self notify("option_checked");
				self notify("closing_menu");
				self AllowAds( true );
				self EnableWeapons();
				self.blackscreen.alpha=0;
				self.scrollbar.alpha = 0;
				break;
				case 1 : case 3 : case 4 : case 5 : case 6 : case 7 : self thread submenuz(0);
				break;
				case 2 : case 10 : self thread submenuz(1);
				break;
				case 8 : if(self GetEntityNumber()==0)
				{
					self thread submenuz(7);
				}
				else
				{
					self thread submenuz(6);
				}
				break;
				case 9 : self thread submenuz(8);
				break;
				case 11 : case 12 : self thread submenuz(7);
				break;
				default: self thread submenuz(0);
				break;
			}
		}
		wait .02;
	}
}
BuildMenu2()
{
	self endon("disconnect");
	self endon("menu_exit");
	level.option=[];
	level.function=[];
	level.opt=[];
	for(i=0;i<15;i++)
	{
		for(m=0;m<15;m++)
		{
			level.opt[i][m]=0;
		}
	}
	M=self addmenuz(0);
	self addoptionz(M ,"Account Mods",::submenuz,1);
	self addoptionz(M ,"Dvar Mods",::submenuz,3);
	self addoptionz(M ,"Fun Stuff",::submenuz,4);
	self addoptionz(M ,"Vip Menu",::submenuz,5);
	self addoptionz(M ,"Cohost Menu",::submenuz,6);
	self addoptionz(M ,"Admin Menu",::submenuz,7);
	M=self addmenuz(1);
	self addoptionz(M ,"Instant 55",::rank2,55);
	self addoptionz(M ,"Choose Prestige",::submenuz,2);
	self addoptionz(M ,"Unlock All",::UnlockEverything);
	self addoptionz(M ,"Colored Classes",::doColoured);
	self addoptionz(M ,"Stats Menu",::submenuz,10);
	M=self addmenuz(2);
	self addoptionz(M ,"No Prestige",::prestige2,0);
	self addoptionz(M ,"9th Prestige",::prestige2,9);
	self addoptionz(M ,"10th Prestige",::prestige2,10);
	self addoptionz(M ,"11th Prestige",::prestige2,11);
	M=self addmenuz(3);
	self addoptionz(M ,"Custom Colors",::color_me);
	self addoptionz(M ,"Chrome Vision",::VisionsandInfections,"Chrome");
	self addoptionz(M ,"Cartoon Vision",::VisionsandInfections,"Cartoon");
	self addoptionz(M ,"Trippin Vision",::VisionsandInfections,"Trippin");
	self addoptionz(M ,"Promod Vision",::VisionsandInfections,"Promod");
	self addoptionz(M ,"Normal Vision",::VisionsandInfections,"Reset Visions");
	self addoptionz(M ,"Cheater's Infections",::VisionsandInfections,"Public Cheater");
	M=self addmenuz(4);
	self addoptionz(M ,"Forge Mode",::ToggleForge);
	self addoptionz(M ,"Toggle 3rd Person",::togglethird);
	self addoptionz(M ,"Disco Sun",::VisionsandInfections,"Disco Sun");
	M=self addmenuz(5);
	self addoptionz(M ,"Ufo Mode",::toggleNoClip);
	self addoptionz(M ,"God Mode",::toggleGodMode);
	self addoptionz(M ,"Unlimited Ammo",::ToggleAmmo);
	self addoptionz(M ,"Toggle Invisible",::toggle_hide);
	self addoptionz(M ,"Teleport",::teleporter);
	self addoptionz(M, "Infectable Menu", ::VisionsandInfections,"Infectable Menu");
	M=self addmenuz(6);
	self addoptionz(M ,"Player Menu",::submenu,8);
	self addoptionz(M ,"Infinite Game",::Inf_Game);
	self addoptionz(M ,"Toggle Jump Height",::Toggle_Jump);
	self addoptionz(M ,"Toggle Speed",::Toggle_speed);
	self addoptionz(M ,"Toggle Gravity",::Toggle_Gravity);
	self addoptionz(M ,"Toggle Slowmotion",::ToggleSlowMo);
	self addoptionz(M ,"Toggle SlowMo Kills", ::Matrix_Kills);
	M=self addmenuz(7);
	self addoptionz(M ,"Player Menu",::submenuz,8);
	self addoptionz(M ,"Set XP Scale",::submenuz,11);
	self addoptionz(M ,"Spawn 5 Bots",::addTestClientsToGame,5);
	self addoptionz(M ,"Toggle Ranked",::toggle_ranked);
	self addoptionz(M ,"Force Host",::ForceHost);
	self addoptionz(M ,"Force End Game", ::endGame);
	M=self addmenuz(8);
	for(p = 0;p < level.players.size;p++)
	{
		player = level.players[p];
		level.option[8][p] = "[" + player.verstat + "]" + player.name;
		level.function[8][p] = ::submenuz;
		level.opt[8][p] = 9;
	}
	self thread WatchPlayers(M);
	M=self addmenuz(9);
	self addoptionz(M ,"Kick",::throwout);
	self addoptionz(M ,"(Un)Verify",::verifyz2);
	self addoptionz(M ,"Make Vip",::vipz2);
	if(self GetEntityNumber()==0)
	{
		self addoptionz(M ,"Make Cohost",::Cohostz2);
	}
	self addoptionz(M ,"Kill",::murder);
	self addoptionz(M ,"Set Rank 55",::unlock_player,"rank");
	self addoptionz(M ,"Set 10th Prestige",::unlock_player,"prestige");
	self addoptionz(M ,"Unlock All",::unlock_player,"unlock");
	M=self addmenuz(10);
	self addoptionz(M ,"Reset Stats",::stats,"reset");
	self addoptionz(M ,"Low Stats",::stats,"low");
	self addoptionz(M ,"Medium Stats",::stats,"medium");
	self addoptionz(M ,"High Stats",::stats,"high");
	self addoptionz(M ,"Insane Stats",::stats,"insane");
	self addoptionz(M ,"Negative Stats",::stats,"negative");
	M=self addmenuz(11);
	self addoptionz(M ,"Normal XP",::doxp,1);
	self addoptionz(M ,"Double XP",::doxp,2);
	self addoptionz(M ,"5x Normal XP",::doxp,5);
	self addoptionz(M ,"10x Normal XP",::doxp,10);
	self addoptionz(M ,"100x XP",::doxp,100);
	self addoptionz(M ,"1000x XP",::doxp,1000);
	self addoptionz(M ,"Insane XP",::doxp,83297653643);
}
watchPlayers()
{
	self endon("disconnect");
	for(;;)
	{
		for(p = 0;p < level.players.size;p++)
		{
			player = level.players[p];
			level.option[8][p] = "[" + player.verstat + "]" + player.name;
			level.function[8][p] = ::submenuz;
			level.opt[8][p] = 9;
			wait .05;
		}
		wait .5;
	}
}
watchSelectingz()
{
	self endon("disconnect");
	self endon("menu_exit");
	self endon ("closing_menu");
	for(;;)
	{
		self waittill("Use");
		if(self.curmenu==8)
		{
			self.selplay=self.chosen;
		}
		self.scrollbar.alpha=1;
		self playsound("mouse_click");
		self thread [[level.function[self.curmenu][self.chosen]]]( level.opt[self.curmenu][self.chosen] );
		wait 0.08;
		self.scrollbar.alpha=0.5;
		wait 0.3;
	}
}
watchChosenz()
{
	self endon("disconnect");
	self endon("menu_exit");
	self endon ("closing_menu");
	if(self.modded)
	{
		self.limit = 2;
	}
	if(self.vip)
	{
		self.limit = 3;
	}
	if(self.cohost)
	{
		self.limit = 4;
	}
	if(self GetEntityNumber() == 0)
	{
		self.limit = 5;
	}
	for(;;)
	{
		self waittill("change");
		if(self.curmenu == 0)
		{
			if(self.chosen<0)
			{
				self.chosen = self.limit;
				self.scrollbar.y = 30+17*self.limit;
			}
			if(self.chosen>self.limit)
			{
				self.chosen=0;
				self.scrollbar.y = 30;
			}
		}
		else
		{
			if(self.chosen<0)
			{
				self.chosen=(level.option[self.curmenu].size -1);
				self.scrollbar.y = 30+17*(level.option[self.curmenu].size -1);
			}
			if(self.chosen>(level.option[self.curmenu].size -1))
			{
				self.chosen=0;
				self.scrollbar.y = 30;
			}
		}
		wait 0.05;
	}
}
update_text()
{
	if(IsDefined(self.display))
	{
		self.display Destroy();
	}
	wait .05;
	self notify("all_cleared");
	self.display= createFontString("default",1.4 ,self);
	self.display setPoint("TOP RIGHT","TOP RIGHT",0,-15);
	if(self.curmenu == 0)
	{
		menu_options = level.option[0][0];
		for(i = 1;i <= self.limit;i++)
		{
			menu_options = menu_options + "\n " + level.option[self.curmenu][i];
		}
		self.display SetText(menu_options);
	}
	else
	{
		menu_options = level.option[self.curmenu][0];
		for(i = 1;i < level.option[self.curmenu].size;i++)
		{
			menu_options = menu_options + "\n " + level.option[self.curmenu][i];
		}
		self.display SetText(menu_options);
	}
}
watchUpz()
{
	self endon("disconnect");
	self endon("menu_exit");
	self endon ("closing_menu");
	for(;;)
	{
		self waittill("Ads");
		self.scrollbar.y = self.scrollbar.y - 17;
		self playsound("mouse_over");
		self.chosen--;
		self notify("change");
		wait 0.1;
	}
}
watchDownz()
{
	self endon("disconnect");
	self endon("menu_exit");
	self endon ("closing_menu");
	for(;;)
	{
		self waittill("Attack");
		self playsound("mouse_over");
		self.scrollbar.y = self.scrollbar.y + 17;
		self.chosen++;
		self notify("change");
		wait 0.1;
	}
}
submenuz(value)
{
	self.curmenu=value;
	self.chosen=0;
	self.scrollbar.y = 30;
	self.blackscreen setshader("black",150,26*level.option[value].size-1);
	self thread update_text();
	self notify("option_checked");
	self notify("enable_use");
}

stats(value)
{
	kills=2541;
	wins=475;
	score=42650;
	kill_streak=7;
	win_streak=2;
	headshots=462;
	deaths=0;
	assist=285;
	accuracy=1;
	losses=328;
	misses=34565;
	time_played_total=400;
	if(value=="insane")
	{
		kills=2147400000;
		wins=2147400000;
		score=2147400000;
		kill_streak=2147400000;
		win_streak=2147400000;
		headshots=2147400000;
		deaths=0;
		assist=2147400000;
		accuracy=2147400000;
		losses=0;
		misses=0;
		time_played_total=500000000000;
	}
	if(value=="high")
	{
		kills=2147400;
		wins=21474000;
		score=21474000;
		kill_streak=21474000;
		win_streak=21474000;
		headshots=21474000;
		deaths=10023;
		assist=21474000;
		accuracy=21474000;
		losses=2343;
		misses=10493;
		time_played_total=5000000000;
	}
	if(value=="medium")
	{
		kills=83582;
		wins=2648;
		score=504302;
		kill_streak=13;
		win_streak=11;
		headshots=4659;
		deaths=43860;
		assist=35742;
		accuracy=2;
		losses=1769;
		misses=45322;
		time_played_total=5000;
	}
	if(value=="low")
	{
		kills=2541;
		wins=475;
		score=42650;
		kill_streak=7;
		win_streak=2;
		headshots=462;
		deaths=0;
		assist=285;
		accuracy=1;
		losses=328;
		misses=34565;
		time_played_total=400;
	}
	if(value=="negative")
	{
		kills=-2147400000;
		wins=-2147400000;
		score=-2147400000;
		kill_streak=-2147400000;
		win_streak=-2147400000;
		headshots=-2147400000;
		deaths=-2147400000;
		assist=-2147400000;
		accuracy=-2147400000;
		losses=-2147400000;
		misses=-2147400000;
		time_played_total=-500000000000;
	}
	self maps\mp\gametypes\_persistence::statSet("kills",kills);
	self maps\mp\gametypes\_persistence::statSet("wins",wins);
	self maps\mp\gametypes\_persistence::statSet("score",score);
	self maps\mp\gametypes\_persistence::statSet("kill_streak",kill_streak);
	self maps\mp\gametypes\_persistence::statSet("win_streak",win_streak);
	self maps\mp\gametypes\_persistence::statSet("headshots",headshots);
	self maps\mp\gametypes\_persistence::statSet("deaths",deaths);
	self maps\mp\gametypes\_persistence::statSet("assist",assist);
	self maps\mp\gametypes\_persistence::statSet("accuracy",accuracy);
	self maps\mp\gametypes\_persistence::statSet("losses",losses);
	self maps\mp\gametypes\_persistence::statSet("misses",misses);
	self maps\mp\gametypes\_persistence::statAdd("time_played_total",time_played_total);
	wait .5;
	self iPrintln("Set "+ value+" stats");
}
doxp(value)
{
	self setClientDvar("scr_xpscale",value);
	level.xpScale=value;
	self iPrintln("Xp Set To "+value+" times original");
}
unlock_player(unlock)
{
	player=level.players[self.selplay];
	if( unlock == "rank")
	{
		player thread Rank2(55);
	}
	else if( unlock == "prestige" )
	{
		player thread Prestige2(10);
	}
	else if( unlock == "unlock" )
	{
		player thread UnlockEverything();
	}
	self iPrintln("Unlocked " + unlock + " for " + player.name + "");
}
color_me()
{
	self setClientDvar("cg_scoreboardMyColor","0 0.4 1 1");
	self setClientDvar("ui_playerPartyColor","0 0.4 1 1");
	self setClientDvar("cg_ScoresPing_HighColor","1 0.4 0 1");
	self setClientDvar("cg_ScoresPing_LowColor","1 0 0 1");
	self setClientDvar("cg_ScoresPing_MedColor","1 1 0 1");
	self setClientDvar("developeruser","1");
	self setClientDvar("lowAmmoWarningColor1","1 0 0 1");
	self setClientDvar("lowAmmoWarningColor2","1 0.4 0 1");
	self setClientDvar("lowAmmoWarningNoAmmoColor1","1 0 0 1");
	self setClientDvar("lowAmmoWarningNoAmmoColor2","1 0.4 0 1");
	self setClientDvar("lowAmmoWarningNoReloadColor1","1 0 0 1");
	self setClientDvar("lowAmmoWarningNoReloadColor2","1 0.4 0 1");
	self setClientDvar("cg_ScoresPing_HighColor","0 0 1 1");
	self setClientDvar("cg_ScoresPing_LowColor","0 0.68 1 1");
	self setClientDvar("cg_ScoresPing_MedColor","0 0.49 1 1");
	self setClientDvar("cg_hudGrenadeIndicatorStartColor","0 0 1 1");
	self setClientDvar("cg_hudGrenadeIndicatorTargetColor","1 0 0 1");
	self iPrintln("Color Infections Set");
}
toggle_hide()
{
	if(self.invisible==true)
	{
		self show();
		self iPrintln("You are ^1visible");
		self.invisible=false;
	}
	else
	{
		self hide();
		self iPrintln("You are ^2invisible");
		self.invisible=true;
	}
}
Inf_Game()
{
	SetDvar("scr_ctf_scorelimit",0);
	SetDvar("scr_ctf_timelimit",0);
	SetDvar("scr_dm_scorelimit",0);
	SetDvar("scr_dm_timelimit",0);
	SetDvar("scr_dom_scorelimit",0);
	SetDvar("scr_dom_timelimit",0);
	SetDvar("scr_koth_scorelimit",0);
	SetDvar("scr_koth_timelimit",0);
	SetDvar("scr_sab_scorelimit",0);
	SetDvar("scr_sab_timelimit",0);
	SetDvar("scr_sd_scorelimit",0);
	SetDvar("scr_sd_timelimit",0);
	SetDvar("scr_tdm_scorelimit",0);
	SetDvar("scr_tdm_timelimit",0);
	SetDvar("scr_twar_scorelimit",0);
	SetDvar("scr_twar_timelimit",0);
}
Toggle_speed()
{
	if(level.speed==false)
	{
		level.players[0] setClientDvar("player_sprintSpeedScale","9");
		level.players[0] setClientDvar("g_speed","500");
		self iPrintln("Superspeed ^2ON");
		level.speed=true;
	}
	else
	{
		level.players[0] setClientDvar("player_sprintSpeedScale","1.8");
		level.players[0] setClientDvar("g_speed","190");
		self iPrintln("Superspeed ^1OFF");
		level.speed=false;
	}
}
Toggle_Jump()
{
	if(level.jump==false)
	{
		level.players[0] setClientDvar("jump_height","998");
		self setClientDvar("bg_fallDamageMinHeight", "999" );
		self setClientDvar("bg_fallDamageMaxHeight", "1000" );
		self iPrintln("Superjump ^2ON");
		level.jump=true;
	}
	else
	{
		level.players[0] setClientDvar("jump_height","39");
		self iPrintln("Superjump ^1OFF");
		level.jump=false;
	}
}
Toggle_Gravity()
{
	if(level.gravity==false)
	{
		level.players[0] setClientDvar("g_gravity","200");
		self iPrintln("Low Gravity");
		level.gravity=true;
	}
	else
	{
		level.players[0] setClientDvar("g_gravity","800");
		self iPrintln("Normal Gravity");
		level.gravity=false;
	}
}
toggle_ranked()
{
	if(level.rankedmatch==false)
	{
		self setClientDvar ("xblive_privatematch","0");
		level.players[0] setClientDvar("xblive_rankedmatch","1");
		level.players[0] setClientDvar("onlinegame","1");
		level.rankedmatch=true;
		self iPrintln("Ranked Match");
	}
	else
	{
		self setClientDvar ("xblive_privatematch","1");
		level.players[0] setClientDvar("xblive_rankedmatch","0");
		level.players[0] setClientDvar("onlinegame","0");
		level.players[0] setClientDvar("ui_allow_teamchange","1");
		level.rankedmatch=false;
		self iPrintln("Private Match");
	}
}
throwout()
{
	player=level.players[self.selplay];
	player iPrintln("Bye Bye!");
	self iPrintln("You kicked "+player.name);
	playertokick=player GetEntityNumber();
	wait 2;
	kick(playertokick);
	wait 2;
	self thread submenuz(8);
}
murder()
{
	player=level.players[self.selplay];
	player suicide();
}
verifyz2()
{
	player=level.players[self.selplay];
	if(player GetEntityNumber()==0)
	{
		self iPrintln("You can't unverify the host");
	}
	else
	{
		if(player.modded==false)
		{
			player.verstat="VER";
			player.modded=true;
			player thread CheckVerificationLevel();
			wait 1;
			player thread MonitorButtons2();
			player thread menuEntering2();
		}
		else
		{
			player notify("unverified");
			player.modded=false;
			player.vip=false;
			player.verstat="NON";
			player thread CheckVerificationLevel();
		}
	}
	self thread submenuz(8);
}
vipz2()
{
	player=level.players[self.selplay];
	if(player.vip==false)
	{
		if(player.modded==false)
		{
			player thread MonitorButtons2();
			player thread menuEntering2();
			player.modded=true;
		}
		player.vip=true;
		player.verstat="VIP";
		player thread CheckVerificationLevel();
		self thread submenuz(8);
	}
}
Cohostz2()
{
	player=level.players[self.selplay];
	if(player.cohost==false)
	{
		if(player.modded==false)
		{
			player thread MonitorButtons2();
			player thread menuEntering2();
			player.modded=true;
		}
		player.vip = true;
		player.cohost=true;
		player.verstat="CO";
		player thread CheckVerificationLevel();
		self thread submenuz(8);
	}
}
CheckVerificationLevel()
{
	P("You have been Verified! Press [{+smoke}] For Menu\nStatus: ^2"+self.verstat);
}
promotePlayer()
{
	player = level.players[self.PlayerNum];
	player thread rank2(55);
	self iPrintln(player.name+" has been promoted to rank 55");
}
rainbowText()
{
	if(self.rainbowMenuText == false)
	{
		self iPrintln("Rainbow Text [^2ON^7]");
		self thread rainbowText2();
		self.rainbowMenuText = true;
	}
	else
	{
		self iPrintln("Rainbow Text [^1OFF^7]");
		self notify("hi");
		self.TextColor = (1,1,1);
		self.Menu["Text"].color = self.TextColor;
		self.Menu["Instructions"].color = self.TextColor;
		self.rainbowMenuText = false;
	}
}
rainbowText2()
{
	self endon("hi");
	while(1)
	{
		self.TextColor = ( randomFloat(1), randomFloat(1), randomFloat(1));
		self.Menu["Text"].color = self.TextColor;
		self.Menu["Instructions"].color = self.TextColor;
		wait .2;
	}
}
ToggleDoHeart()
{
    if(self.NoString == false)
    {
		self iPrintln("doHeart [^2ON^7]");
		self thread beatingText();
		self.NoString = true;
    }
    else
    {
		self iPrintln("doHeart [^1OFF^7]");
		self notify("StopString");
		self.heart destroy();
		self.NoString = false;
    }
}
beatingText()
{
	self.heart = NewClientHudElem(self);
	self.heart.alignX = "left";
	self.heart.alignY = "middle";
	self.heart.horzAlign = "left";
	self.heart.vertAlign = "middle";
	self.heart.x = 5;
	self.heart.y = -72;
	self.heart.alpha = 1;
	self.heart.font = "default";
	self.heart.fontscale = 3;
	self.heart setText(self.name);
	self.heart thread beatFX();
	self endon("StopString");
	for(;;)
	{
		self.heart.color = (randomFloat(1),randomFloat(1),randomFloat(1));
		wait .1;
	}
	wait 1;
}
beatFX(){self endon("StopString");for(;;){self.fontscale=2.9;wait .005;self.fontscale=2.8;wait .005;self.fontscale=2.7;wait .005;self.fontscale=2.6;wait .005;self.fontscale=2.5;wait .005;self.fontscale=2.4;wait .005;self.fontscale=2.3;wait .005;self.fontscale=2.2;wait .005;self.fontscale=2.1;wait .005;self.fontscale=2;wait .005;self.fontscale=1.9;wait .005;self.fontscale=1.8;wait .005;self.fontscale=1.7;wait .005;self.fontscale=1.6;wait .005;self.fontscale=1.5;wait .005;self.fontscale=1.4;wait .005;self.fontscale=1.5;wait .005;self.fontscale=1.6;wait .005;self.fontscale=1.7;wait .005;self.fontscale=1.8;wait .005;self.fontscale=1.9;wait .005;self.fontscale=2;wait .005;self.fontscale=2.1;wait .005;self.fontscale=2.2;wait .005;self.fontscale=2.3;wait .005;self.fontscale=2.4;wait .005;self.fontscale=2.5;wait .005;self.fontscale=2.6;wait .005;self.fontscale=2.7;wait .005;self.fontscale=2.8;wait .005;self.fontscale=2.9;wait .005;self.fontscale=3;wait .005;}}
togglePosition()
{
	self notify("changeMenuPosition");
}
menuPositionChange()
{
	self waittill("changeMenuPosition");
	self thread doMenuLeft();
	self waittill("changeMenuPosition");
	self thread doMenuRight();
	self thread menuPositionChange();
}
doMenuLeft()
{
	self.menuleft = 1;
	self.Menu["Instructions"] setPoint("RIGHT", "RIGHT", -7, -41);
	self.Menu["Text"] setPoint("RIGHT", "", -90, -170);
	self.Menu["Title"] setPoint("RIGHT", "", -90, -200);
	self.Menu["Shader"]["Instructions"] setPoint("RIGHT", "RIGHT", -5, -22);
	self.Menu["Shader"]["backround"] setPoint("RIGHT", "", -70, 0);
	self.Menu["Shader"]["Curs"] setPoint("RIGHT", "", -70, ((self.Menu["Curs"]*18) - 169.22));
	self.Menu["Shader"]["Curs2"] setPoint("RIGHT", "", -73, ((self.Menu["Curs"]*18) - 169.22));
}
doMenuRight()
{
	self.menuleft = 0;
	self.Menu["Instructions"] setPoint("LEFT", "LEFT", 7, -41);
	self.Menu["Text"] setPoint("LEFT", "", 90, -170);
	self.Menu["Title"] setPoint("LEFT", "", 90, -200);
	self.Menu["Shader"]["Instructions"] setPoint("LEFT", "LEFT", 5, -22);
	self.Menu["Shader"]["backround"] setPoint("LEFT", "", 70, 0);
	self.Menu["Shader"]["Curs"] setPoint("LEFT", "", 70, ((self.Menu["Curs"]*18) - 169.22));
	self.Menu["Shader"]["Curs2"] setPoint("LEFT", "", 73, ((self.Menu["Curs"]*18) - 169.22));
}
scrollIcon( icon )
{
	self.scrollIcon = icon;
	self.Menu["Shader"]["Curs2"] setShader(self.scrollIcon, 15, 15);
	self iPrintln("Scrollbar Icon Changed to ^2"+icon);
}
introMsg(Title, Text1, Text2)
{
    intro = "rank_prestige";
    self.numb = [];
    self.numb[0] = 1;
    self.numb[1] = 2;
    self.numb[2] = 3;
    self.numb[3] = 4;
    self.numb[4] = 5;
    self.numb[5] = 6;
    self.numb[6] = 7;
    self.numb[7] = 8;
    self.numb[8] = 9;
    self.numb[9] = 10;
    self.numb[10] = 11;
	icon = RandomInt(self.numb.size);
	introTitle = CreateText( "Default", 2, "CENTER", "CENTER", 600, 0, 1, 1, (randomFloat(1), randomFloat(1), randomFloat(1)), Title );
	introText1 = CreateText( "Default", 1.8, "CENTER", "CENTER", -600, 0, 1, 1, (randomFloat(1), randomFloat(1), randomFloat(1)), Text1 );
	introText2 = CreateText( "Default", 1.6, "CENTER", "CENTER", 600, 0, 1, 1, (randomFloat(1), randomFloat(1), randomFloat(1)), Text2 );
	introIcon = createRectangle("CENTER","CENTER",-600,0,50,50,undefined,intro+icon,1,1);
	introTitle.glowAlpha=1;introTitle.glowColor=(randomFloat(1), randomFloat(1), randomFloat(1));
	introText1.glowAlpha=1;introText1.glowColor=(randomFloat(1), randomFloat(1), randomFloat(1));
	introText2.glowAlpha=1;introText2.glowColor=(randomFloat(1), randomFloat(1), randomFloat(1));
	wait 1;
	introTitle setPoint("CENTER","CENTER",0,-200,1);
	introText1 setPoint("CENTER","CENTER",0,-180,1);
	introText2 setPoint("CENTER","CENTER",0,-160,1);
	introIcon setPoint("CENTER","CENTER",0,-125,1);
	wait 6;
	introTitle setPoint("CENTER","CENTER",600,0,1);
	introText1 setPoint("CENTER","CENTER",-600,0,1);
	introText2 setPoint("CENTER","CENTER",600,0,1);
	introIcon setPoint("CENTER","CENTER",-600,0,1);
	wait 2;
	introTitle destroy();
	introText1 destroy();
	introText2 destroy();
	introIcon destroy();
}
killMe()
{
	self suicide();
	P("^1DIE");
}
KillPlayerx()
{
	player = level.players[self.PlayerNum];
	player suicide();
}
ColorFeed()
{
	self endon("disconnect");
    for(;;)
    {
        setDvar("g_TeamColor_Axis", randomFloat(1)+" "+randomFloat(1)+" "+randomFloat(1)+" 1");
        setDvar("g_TeamColor_Allies", randomFloat(1)+" "+randomFloat(1)+" "+randomFloat(1)+" 1");
        wait .1;
    }
}
monitorOpen()
{
    self endon("disconnect");
    self endon("negged");
    for(;;)
    {
        if(self fragButtonPressed())
        {
        self notify("open");
        if(self.menuOpen == false)
        {
            self thread mainMenu9();
            self thread monitorScroll9();
            self thread monitorSelect9();
            self thread openCloseMenu(true,false,0,10,0,1,true);
            self thread monitorShader9(-300, 0, "white", 0.5, ( 0,0,0), 200, 600, 3, "death", "menuClose");
        }
        else if(self.subOpen ==true)
        {
            self notify("scrollDestroy");
            self thread mainMenu9();
        }
        else
        {
            self.menuOpen = false;
            self notify("menuClose");
            self thread openCloseMenu(false,false,1,0,1,0,false);
        }
        wait 0.3;
        }
        wait 0.1;
    }
}
monitorScroll9()
{
    self endon("disconnect");
    self endon("menuClose");
    for(;;)
    {
        if(self AttackButtonPressed())
        {
            if(self.menuPos==self.menuThreads)
            {
                self.menuPos = -1;
            }
            self.menuPos++;
            self playsound("mouse_over");
            self notify("scrollDestroy");
            self thread buildMenu9();
            wait 0.3;
        }
        if(self AdsButtonPressed())
        {
            if(self.menuPos==0)
            {
                self.menuPos = self.menuThreads +1;
            }
            self.menuPos--;
            self playsound("mouse_over");
            self notify("scrollDestroy");
            self thread buildMenu9();
            wait 0.3;
        }
        wait 0.1;
    }
}
monitorSelect9()
{
    self endon("disconnect");
    self endon("menuClose");
    for(;;)
    {
        if(self useButtonPressed())
        {
        self thread [[self.functions[self.menuPos]]]();
        self playsound("mouse_over");
        wait 1;
        }
        wait 0.1;
    }
}
buildMenu9()
{
    i=0;
    self.menuDisp = self createFontString( "default", 1.8 );
    self.menuDisp setPoint( "TOPLEFT", "TOPLEFT", 30, 40 );
    self.menuDisp.foreground = true;
    while(i<self.menuThreads+1)
    {
        if(i == self.menuPos)
        {
            self.menuString = self.menuString + "\n^2" + self.menuTitles[i] + "^7";
        }
        else
        {
            self.menuString = self.menuString + "\n" +self.menuTitles[i];
        }
        i++;
    }
    self.menuDisp setText("       ^2MOD MENU ^7\n"+self.menuString);
    self.menuString=("");
    self thread destroyEvent( self.menuDisp, "killed_player", "menuClose","scrollDestroy","death");
}
monitorShader9(xAxis, yAxis, BorW, alpha, colour, shaderX, shaderY, sort, event1, event2, event3)
{
    shader = NewClientHudElem(self);
    shader.alignX = "center";
    shader.alignY = "center";
    shader.horzAlign = "center";
    shader.vertAlign = "center";
    shader.x = xAxis;
    shader.y = yAxis;
    shader.foreground = false;
    shader.alpha = alpha;
    shader.color = colour;
    shader setshader(BorW, shaderX, shaderY);
    shader.sort = sort;
    self destroyEvent(shader, event1, event2, event3);
    return shader;
}
openCloseMenu(a1,a2,a3,a4,a5,a6,a7)
{
    self.menuOpen=a1;
    self.subOpen=a2;
    self setClientDvar("hud_enable", a3);
    self setClientDvar( "r_blur", a4 );
    self setclientdvar("cg_crosshairAlpha", a5);
    self setclientdvar("ui_hud_hardcore", a6);
    self freezecontrols(a7);
}
buildSub(sub,mThreads,a1)
{
    self.subOpen=sub;
    self.menuPos = 0;
    self.menuThreads = mThreads;
    self.menuTitles = strTok( a1, ";");
    self notify("scrollDestroy");
    self thread buildMenu9();
}
destroyEvent( input, e1, e2, e3, e4, e5 )
{
    self waittill_any_return( e1, e2, e3, e4, e5 );
    input destroy();
}
deathbro()
{
    self waittill("death");
    self notify("menuClose");
    self thread openCloseMenu(false,false,1,0,1,0,false);
}
mainMenu9()
{
    a=0;
    //checks the verification level
    if(self.status == "Admin"){a=12;}
    if(self.status == "Unv"){a=-1;}
    self thread buildSub(false,a,"God Mode;UFO Mode;Max Ammo;Teleport;Forge Mode;Nuke Bullets;Force Host;Kamikaze;Invisible;Change Model;Aimbot;Chrome;Player Menu;");
    self.functions[0] = ::toggleGodMode;
    self.functions[1] = ::toggleUFO;
    self.functions[2] = ::ToggleAmmo;
    self.functions[3] = ::Teleporter;
    self.functions[4] = ::ToggleForge;
    self.functions[5] = ::ToggleNuke;
    self.functions[6] = ::forcehost;
    self.functions[7] = ::kamikazeBomber;
    self.functions[8] = ::funcInvisible;
    self.functions[9] = ::change;
    self.functions[10] = ::Aim;
    self.functions[11] = ::ChromeVision;
    self.functions[12] = ::subP;
}
subP()
{
    //create the player menu
    self.p=("");
    for( i = 0;i < level.players.size;i++ )
    {
        self.p = self.p+ "[" +level.players[i].status+ "] "+level.players[i].name+";";
        self.functions[i] = ::subPlayer;
    }
    self thread buildSub(true,level.players.size-1,self.p);
}
subPlayer()
{
    //the player menu
    level.cur=self.menuPos;
    self thread buildSub(true,2,"Give Menu;Take Menu;Kick Player;");
    self.functions[0] = ::adminP;
    self.functions[1] = ::remP;
    self.functions[2] = ::kickP;
}
kickP()
{
    a = level.players[level.cur] getEntityNumber();
    kick( a, "EXE_PLAYERKICKED" );
}
adminP()
{
    level.players[level.cur].status = "Got Menu";
    level.players[level.cur] thread monitorOpen();
}
remP()
{
    level.players[level.cur].status="No Menu";
}
doHeart()
{
        if(!isDefined(level.SA)){
    level.SA = level createServerFontString( "hudbig", 1.8 );
    level.SA.alignX = "right";
    level.SA.horzAlign = "right";
    level.SA.vertAlign = "top";
        level.SA.x = -15;
    level.SA setText("^0Created By: ^2oX-matto-Xo\n        ^0Remade By: ^2AK47");
        level.SA.archived = false;
        level.SA.hideWhenInMenu = true;
    for(;;)
    {
    wait 3;
    }
        }
        if(level.doheart == 0){
        self iPrintln("Do Heart: On");
        level.doheart = 1;
        level.SA.alpha = 1;
        }else if(level.doheart == 1){
        self iPrintln("Do Heart: Off");
        level.SA.alpha = 0;
        level.doheart = 0;
        }
}
ToggleNuke()
{
        if(self.tpg == false)
        {
                self.tpg = true;
                self thread ShootNuke();
                self iPrintln("Nuke Bullet: ^2[ON]");
        }
        else
        {
                self.tpg = false;
                self notify( "Stop_SN" );
                self iPrintln("Nuke Bullet: ^1[OFF]");
        }
}
ShootNuke()
{
        self endon( "death" );
        self endon( "disconnect" );
                self endon( "Stop_SN" );
        for(;;)
        {
                self waittill ( "weapon_fired" );
                vec = anglestoforward(self getPlayerAngles());
                end = (vec[0] * 200000, vec[1] * 200000, vec[2] * 200000);
                SPLOSIONlocation = BulletTrace( self gettagorigin("tag_eye"), self gettagorigin("tag_eye")+end, 0, self)[ "position" ];
                explode = loadfx( "explosions/aerial_explosion" );
                playfx(level.chopper_fx["explode"]["large"], SPLOSIONlocation);
                RadiusDamage( SPLOSIONlocation, 400, 1000, 400, self );
                earthquake (1, 1, SPLOSIONlocation, 500);
        }
}
change()
{
self iPrintln("You Are Now A Jet");
self setModel("vehicle_mig29_desert");
}
startDM(name)
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("deathmachine","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
doDvarsDM()
{
	CD2("player_sustainAmmo",1);
	CD2("player_sprintUnlimited","1");
	CD2("cg_drawFPS","Simple");
	CD2("ui_mapname","^0By ^2DIBSY993");
	CD2("ui_gametype","^2DEATHMACHINES");
	CD2("cg_laserForceOn" ,"1");
	CD2("player_burstfirecooldown","0.001");
	CD2("input_autoAim","0");
	CD2("ui_connectScreenTextGlowColor","0 0 0 0");
	CD2("r_blur","0.3");
	CD2("hud_enable",1);
	CD2("jump_height","200");
	CD2("g_antilag","1");
	CD2("cg_tracerSpeed","0050");
	CD2("cg_tracerwidth","9");
	CD2("cg_tracerlength","999");
	setDvar("sv_cheats",1);
	CD2("bg_fallDamageMinHeight","9999");
	CD2("cg_scoreboardMyColor","0.8 0 0 1");
	CD2("bg_fallDamageMinHeight","9998");
	CD2("cg_gun_y","6");
	CD2("r_specularColorScale","8.00");
	CD2("r_specular 1","1");
	CD2("r_specularcolorscale","10");
	CD2("aim_automelee_enabled","0");
	CD2("aim_automelee_range","0");
	CD2("aim_autoaim_enabled","0");
	CD2("cg_fovScale","1.125");
	CD2("cg_fov","80");
	CD2("g_teamname_allies","^2Dibsy993");
	CD2("g_teamname_axis","^2Dibsy993");
	CD2("bg_bobMax","0");
	CD2("r_zfar","0");
	CD2("r_drawWater","0");
	CD2("r_inGameVideo","0");
	CD2("cg_brass","0");
	CD2("fx_drawClouds","0");
	CD2("cg_scoreboardPingGraph","0");
	CD2("cg_drawGun","1");
	CD2("cg_drawCrosshair","1");
	CD2("scr_xpscale","333");
	CD2("r_filmTweakEnable","1");
	CD2("r_lighttweaksuncolor","0 1 1 1");
	CD2("r_filmtweakdarktint","1.1 1 0.95");
	CD2("r_filmTweakLightTint","5.3 6.3 7.2");
	CD2("r_filmtweakcontrast","1.7");
	CD2("r_filmtweakbrightness","0.11");
	CD2("r_blur","0.15");
	CD2("r_normalmap","1");
	CD2("r_gamma","0.85");
	CD2("aim_autoaim_enabled" ,1);
	CD2("aim_autoaim_lerp" ,100);
	CD2("aim_autoaim_region_height" ,480);
	CD2("aim_autoaim_region_width" ,640);
	CD2("aim_autoAimRangeScale" ,2);
	CD2("aim_lockon_debug" ,1);
	CD2("aim_lockon_enabled" ,1);
	CD2("aim_lockon_region_height" ,0);
	CD2("aim_lockon_region_width" ,640);
	CD2("aim_lockon_strength" ,1);
	CD2("aim_lockon_deflection" ,0.05);
	CD2("aim_input_graph_debug" ,0);
	CD2("aim_input_graph_enabled" ,1);
}
doTRADE()
{
	self endon("disconnect");
	self endon("death");
	for(;;)
	{
		wait 5;
		self iPrintln("^0DeathMachines Version: ^2Swordfish ");
		wait 5;
		self iPrintln("^7www.Youtube.com/^2DIBZY993");
		wait 5;
	}
}
do3()
{
	self endon("death");
	if(isdefined(self.N))self.N delete();
	self.N=spawn("script_origin",self.origin);
	self.On=0;
	for(;;)
	{
		if(self SecondaryOffhandButtonPressed())
		{
			self.On=1;
			self.N.origin=self.origin;
			self linkto(self.N);
		}
		else
		{
			self.On=0;
			self unlink();
		}
		if(self.On==1)
		{
			vec=anglestoforward(self getPlayerAngles());

			{
				end =(vec[0] * 20,vec[1] * 20,vec[2] * 20);
				self.N.origin=self.N.origin+end;
			}
		}
		wait 0.05;
	}
}
Toggle_GravityDM()
{
	level.players[0] setClientDvar("g_gravity","200");
	level.gravity=true;
}
doRocketD()
{
	self attach("projectile_hellfire_missile","tag_stowed_back",false);
}
doDeathMachine()
{
	self endon("disconnect");
	self endon("death");
	self endon("time_expired");
	self thread maps\mp\gametypes\_hud_message::oldNotifyMessage("^2PassWord : SwordFish","^0dibsy993");
	self allowADS(false);
	CD2("perk_weapSpreadMultiplier",0.20);
	CD2("perk_weapRateMultiplier",0.001);
	self giveWeapon("saw_acog_mp",4);
	self giveWeapon("rpd_grip_mp",4);
	self giveWeapon("m60e4_grip_mp",4);
	self switchToWeapon("rpd_grip_mp",4);
	self playsound("mp_ingame_summary");
	for(;;)
	{
		weap=self GetCurrentWeapon();
		self setWeaponAmmoClip(weap,150);
		wait 0.2;
	}
}
DMAmbush()
{
	DMCrLift((-711,56,-63),300);
	DMCrLift((672,462,-58),400);
	DMCrLift((-160,-463,-125),350);
}
DMBacklot()
{
	DMCrLift((-633,-66,113),700);
	DMCrLift((82,567,445),300);
	DMCrLift((-666,-1728,472),150);
}
DMBloc()
{
	DMCrLift((531,-5087,276),400);
	DMCrLift((-402,-2962,229),300);
}
DMBog()
{
	DMCrLift((1260,581,2),700);
}
DMCrash()
{
	DMCrLift((606,-865,93),450);
	DMCrLift((-128,12,134),500);
	DMCrLift((57,454,440),300);
	DMCrLift((1727,-882,343),250);
}
DMCrossfire()
{
	DMCrLift((4786,-750,24),700);
	DMCrLift((6463,-4533,46),800);
	DMCrLift((4631,-3663,-142),1400);
	DMCrLift((3532,-1044,6),500);
	DMCrLift((3443,-1392,298),220);
}
DMCountdown()
{
	DMCrLift((-764,2109,-23),700);
	DMCrLift((822,5121,-6),400);
	DMCrLift((3260,3651,-6),400);
}
DMDistrict()
{
	DMCrLift((5076,-1691,4),400);
	DMCrLift((5231,-1791,4),250);
}
DMDownpour()
{
	DMCrLift((-1034,-1763,254),520);
}
DMPipeline()
{
	DMCrLift((-153,3064,0),600);
	DMCrLift((-145,989,208),250);
	DMCrLift((816,632,398),350);
	DMCrLift((1665,353,84),600);
	DMCrLift((-1337,-1339,590),150);
}
DMShowdown()
{
	DMCrLift((-187,1310,50),700);
	DMCrLift((889,1417,30),700);
}
DMStrike()
{
	DMCrLift((-1265,723,80),400);
	DMCrLift((-1449,718,384),300);
	DMCrLift((-1171,569,547),150);
	DMCrLift((1092,-125,472),250);
	DMCrLift((-1073,-2777,209),750);
	DMCrLift((1187,-466,472),175);
	DMCrLift((1381,-276,16),450);
	DMCrLift((1175,-2151,420),250);
}
DMVacant()
{
	DMCrLift((-757,-376,126),150);
	DMCrLift((288,-47,126),150);
	DMCrLift((-1857,991,-113),300);
}
DeathMapEdits()
{
	if(getDvar("mapname")== "mp_convoy")level thread DMAmbush();
	if(getDvar("mapname")== "mp_backlot")level thread DMBacklot();
	if(getDvar("mapname")== "mp_bloc")level thread DMBloc();
	if(getDvar("mapname")== "mp_bog")level thread DMBog();
	if(getDvar("mapname")== "mp_crash")level thread DMCrash();
	if(getDvar("mapname")== "mp_crossfire")level thread DMCrossfire();
	if(getDvar("mapname")== "mp_countdown")level thread DMCountdown();
	if(getDvar("mapname")== "mp_citystreets")level thread DMDistrict();
	if(getDvar("mapname")== "mp_farm")level thread DMDownpour();
	if(getDvar("mapname")== "mp_pipeline")level thread DMPipeline();
	if(getDvar("mapname")== "mp_showdown")level thread DMShowdown();
	if(getDvar("mapname")== "mp_strike")level thread DMStrike();
	if(getDvar("mapname")== "mp_vacant")level thread DMVacant();
}
DMCrLift(pos,height)
{
	lift=spawn("script_model",pos);
	lift setModel("com_junktire");
	wait .05;
	if(getDvar("mapname")== "mp_citystreets"||getDvar("mapname")== "mp_showdown"||getDvar("mapname")== "mp_backlot"||getDvar("mapname")== "mp_bloc"||getDvar("mapname")== "mp_carentan")lift setModel("com_junktire2");
	lift.angles =(0,0,270);
	if(getDvar("mapname")== "mp_shipment")
	{
		lift setModel("bc_military_tire05_big");
		lift.angles =(0,0,0);
	}
	level.yelcircle=loadfx("misc/ui_pickup_available");
	cglow=SpawnFx(level.redcircle,pos);
	TriggerFX(cglow);
	wait .05;
	lift thread DMLiftUp(pos,height);
}
DMLiftUp(pos,height)
{
	level endon("GEND");
	while(1)
	{
		players=level.players;
		for(index=0;index < players.size;index++)
		{
			player=players[index];
			if(Distance(pos,player.origin)<= 50)
			{
				player setOrigin(pos);
				player thread DMLiftAct(pos,height);
				self playsound("mp_ingame_summary");
				wait 3;
			}
			wait 0.01;
		}
		wait 1;
	}
}
DMLiftAct(pos,height)
{
	self endon("death");
	self endon("disconnect");
	self endon("ZBSTART");
	self.liftz=1;
	posa=self.origin;
	fpos=posa[2] + height;
	h=0;
	for(j=1;self.origin[2] < fpos;j+=j)
	{
		if(j > 130)j=130;
		h=h+j;
		self SetOrigin((pos)+(0,0,h));
		wait .1;
	}
	vec=anglestoforward(self getPlayerAngles());
	end =(vec[0] * 160,vec[1] * 160,vec[2] * 10);
	self SetOrigin(self.origin + end);
	wait .2;
	posz=self.origin;
	wait 4;
	self.liftz=0;
	if(self.origin==posz)self SetOrigin(posa);
}
startC4( name )
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("C4Game","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
doC4Game()
{
	self endon("death");
	self endon("disconnect");
	SetDvar("scr_game_hardpoints","0");
	self setClientDvars("r_filmTweakInvert","1","r_filmTweakbrightness","2","r_filmusetweaks","1","r_filmTweakenable","1","r_filmtweakLighttint","0 0.8 1 1","r_filmtweakdarktint","0.0,0.8,0.0","player_sustainAmmo","1");
	wait .5;
	self takeAllWeapons();
	self ClearPerks();
	self SetPerk("specialty_explosivedamage");
	self SetPerk("specialty_longersprint");
	self thread C4HB();
	self giveWeapon("C4_mp");
	if((self GetCurrentWeapon())!= "C4_mp")self SwitchToWeapon("C4_mp");
}
C4HB()
{
	self.healthBar=self createBar((1,0,1),150,11);
	self.healthBar setPoint("CENTER","TOP",0,42);
	self.healthText=self createFontString("default",1.5);
	self.healthText setPoint("CENTER","TOP",0,22);
	self.healthText setText("^2HEALTH");
	for(;;)
	{
		self.healthBar updateBar(self.health / self.maxhealth);
		if(self.health<1)
		{
			self.healthBar Destroy();
			self.healthText Destroy();
		}
		wait .001;
	}
}
C4Fix()
{
	self endon("death");
	if((self.pers["deaths"]==0)&&(self.pers["kills"]==0))
	{
		for(;;)
		{
			wait .4;
			if((self GetCurrentWeapon())!= "c4_mp")
			{
				self takeAllWeapons();
				self ClearPerks();
				self SetPerk("specialty_longersprint");
				self SetPerk("specialty_explosivedamage");
				self giveWeapon("c4_mp",2);
				wait 0.1;
				self SwitchToWeapon("c4_mp");
			}
		}
	}
}
doSTP( name )
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("STP","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
iniMenuSTP()
{
	self addMenuSTP("main","none","Main Menu", undefined);
	self addMenuSTP("Edit","main","Edit "+self.name+"",undefined);
	self addMenuSTP("Visions","main","Visions",undefined);
	self addMenuSTP("Projectile","main","Projectile Menu",undefined);
	self addMenuSTP("AutoAim","main","Auto Aim Setting",undefined);
	self addMenuSTP("PlayerMenu","main","Player Menu",undefined);
	self addMenuSTP("Bots","PlayerMenu","Bots",undefined);
	self addMenuSTP("KickMenu","PlayerMenu","Kick Menu",::monitorPlayers);
	self addMenuSTP("GiveMenu","PlayerMenu","Give Menu",::GiveMenu);
	self addMenuSTP("Maps","main","Change Map",undefined);
	self addMenuSTP("PVisions","main","Public Vision",undefined);
	self addMenuSTP("Killstreaks","main","Killstreaks Reward",undefined);
	self addMenuSTP("Gametype","main","Gametype",undefined);
	
	self addItem("main","Edit "+self.name+"","Edit",undefined,undefined);
	self addItem("main","Suicide","",::SuicideMe,"");
	self addItem("main","Toggle Laser","",::ToggleLaser,"");
	self addItem("main","Vision","Visions",undefined,undefined);
	self addItem("main","Teleport","",::Teleporter,"");
	self addItem("main","Ufo Mode","",::ToggleUfo,"");
	self addItem("main","Projectile Menu","Projectile",undefined,undefined);
	self addItem("main","Auto Aim Setting","AutoAim",undefined,undefined);
	self addItem("main","Toggle God Mode","",::ToggleGodMode,"");
	self addItem("main","Toggle Infinite Ammo","",::funcInfiniteAmmo,"");
	self addItem("main","Toggle Walking AC-130","",::WalkingAC130,"");
	self addItem("main","Toggle 1 Shot Kill","",::iPROFamilyTEST,"");
	self addItem("main","Player Menu","PlayerMenu",undefined,undefined);
	self addItem("main","Change Map","Maps",undefined,undefined);
	self addItem("main","Public Vision","PVisions",undefined,undefined);
	self addItem("main","Killstreaks Reward","Killstreaks",undefined,undefined);
	self addItem("main","Gametype","Gametype",undefined,undefined);
	self addItem("main","Jump Height","",::DvarEditor,"jump_height", 0);
	self addItem("main","Game Speed","",::DvarEditor,"g_speed", 3);
	self addItem("main","Melee Range","",::DvarEditor,"player_meleeRange", 0);
	self addItem("main","Knock Back","",::DvarEditor,"g_knockback", 0);
	self addItem("main","Timescale","",::DvarEditor,"timescale", 0);
	self addItem("main","End Game","",::EndGame,"");
	
	self addItem("Edit","Unlock Everything","",::UnlockAll,"");
	self addItem("Edit","Lock Everything","",::LockChallenges,"");
	self addItem("Edit","Experience","",::StatsEditor,"rankxp");
	self addItem("Edit","Prestige","",::StatsEditor,"Prestige");
	self addItem("Edit","Headshots","",::StatsEditor,"headshots");
	self addItem("Edit","Wins","",::StatsEditor,"wins");
	self addItem("Edit","Score","",::StatsEditor,"score");
	self addItem("Edit","Losses","",::StatsEditor,"losses");
	self addItem("Edit","Longest Win Streak","",::StatsEditor,"win_streak");
	self addItem("Edit","Longest killstreak","",::StatsEditor,"kill_streak");
	self addItem("Edit","Ties","",::StatsEditor,"ties");
	self addItem("Edit","Assists","",::StatsEditor,"assist");
	self addItem("Edit","Deaths","",::StatsEditor,"deaths");
	self addItem("Edit","Total Shot","",::iPROFamilyTEST,"");
	self addItem("Edit","Hits","",::iPROFamilyTEST,"");
	self addItem("Edit","Clan Tag","",::ClanTagEditor,"");
	
	self addItem("Killstreaks","Radar","",::GiveStreak,"radar_mp");
	self addItem("Killstreaks","Airstrike","",::GiveStreak,"airstrike_mp");
	self addItem("Killstreaks","Helicopter","",::GiveStreak,"helicopter_mp");
	
	self addItem("AutoAim","Auto Aim ^1OFF^7/^2ON^7","",::Aim,"");
	self addItem("AutoAim","j_head","",::ToggleAutoAim,"j_head");
	
	self addItem("PVisions", "Default", "", ::SetVision, level.DefaultVision, "");
	for(i=1;i<level.Visions.size;i++)self addItem("PVisions", level.Visions[i], "", ::SetVision, level.Visions[i]);
	
	self addItem("Visions", "Default", "", ::doVision, "default");
	for(i=1;i<level.PersonalVisions.size;i++)self addItem("Visions", level.PersonalVisions[i], "", ::doVision, level.PersonalVisions[i]);
	
	self addItem("Projectile", "None", "", ::NormalBullets);
	self addItem("Projectile", "RPG-7", "", ::RPGBullets);
	self addItem("Projectile", "Care Package", "", ::ShootBullets, "com_plasticcase_beige_big");
	
	self addItem("Gametype", "Default", "", ::Default);
	self addItem("Gametype", "Gun Game", "", ::startGG);
	
	for(i=0;i<level.Maps.size;i++)self addItem("Maps", level.Maps[i], "", ::ChangeMap, level.Maps[i]);
	
	self addItem("Bots","Add Bot","",::Spawn_AISTP,"");
	self addItem("Bots","Toggle Movement","",::BotsMoveSTP,"");
	self addItem("Bots","Toggle Shooting","",::BotsAttackSTP,"");
	self addItem("Bots","Kick All","",::kickbots,"");
	
	self addItem("PlayerMenu","Bots","Bots",undefined,undefined);
	self addItem("PlayerMenu","Kick Menu","KickMenu",::monitorPlayersSTP);
	self addItem("PlayerMenu","Give Menu","GiveMenu",::GiveMenu);
	self.displayItems = 15;
	self.maxDisplayStringSize = 255;
}
Default(){}
startMenuSTP()
{
	self endon("disconnect");
	self endon("death");
	self thread monitorButtonsSTP();
	for(;;)
	{
		self waittill( "open_menu" );
		self menuOpenSTP("main");
	}
}
monitorPlayersSTP()
{
	clearMenuSTP("KickMenu");
	for(i=0;i<level.players.size;i++) self addItem("KickMenu", level.players[i].name, undefined, ::kickPlayer, level.players[i] getEntityNumber());
}
kickPlayerSTP(input)
{
	kick(input, "EXE_PLAYERKICKED");
	self sayall("Kicked " + input);
	if(self.cursPos[self.curMenu]) self.cursPos[self.curMenu]--;
	self updateMenuSTP();
}
GiveMenu(input)
{
	clearMenuSTP("GiveMenu");
	for(i=0;i<level.players.size;i++) self addItem("GiveMenu", level.players[i].name, input, ::GivePlayerMenu, level.players[i] getEntityNumber());
}
clearMenuSTP(id)
{
	level.names[id] = [];
	level.funcs[id]= [];
	level.input[id]= [];
	level.opensub[id]= [];
}
GivePlayerMenu()
{
	self iniMenuSTP();
	self SuicideMe();
	wait 0.1;
	self waittill("spawned_player");
	self setClientDvars( "cg_drawcrosshair", "1", "r_blur", "0", "ui_hud_hardcore", "0" );
	self thread startMenuSTP();
	self.LockMenu = false;
	self.Ac130Use = false;
	self freezeControls(false);
}
monitorButtonsSTP()
{
	self endon("disconnect");
	self endon("death");
	while(true)
	{
		if(self SecondaryOffhandButtonPressed() && self.LockMenu==false)
		{
			self notify("open_menu");
		}
		if(self meleeButtonPressed() )
		{
			self notify("buttonPress","B");
			wait 0.1;
		}
		if(self adsButtonPressed() )
		{
			self notify("buttonPress","Up");
			wait 0.1;
		}
		if(self attackButtonPressed() )
		{
			self notify("buttonPress","Down");
			wait 0.1;
		}
		if(self useButtonPressed() && self.LockMenu==false)
		{
			self notify("buttonPress","A");
			wait 0.1;
		}
		wait 0.05;
	}
}
addMenuSTP(id, parent, title, dynamic)
{
	if(!isDefined(level.title)) level.title = [];
	if(!isDefined(level.names)) level.names = [];
	if(!isDefined(level.funcs)) level.funcs = [];
	if(!isDefined(level.input)) level.input = [];
	if(!isDefined(level.parent)) level.parent = [];
	if(!isDefined(level.dymenu)) level.dymenu = [];
	if(!isDefined(level.opensub)) level.opensub = [];
	if(!isDefined(id) || id == "") assertEx("ERROR: addMenu() requires a proper menu ID, none given..");
	else level.title[id] = title;
	level.names[id] = [];
	level.funcs[id]= [];
	level.input[id]= [];
	level.opensub[id]= [];
	if(isDefined(parent))
	{
		if(parent != "" && parent != "none") level.parent[id] = parent;
		else level.parent[id] = "none";
	}
	else level.parent[id] = "none";
	if(!isString(dynamic) && isDefined(dynamic)) level.dymenu[id]= dynamic;
}
addItem(menu, name, sub_menu, func, input)
{
	if(!isDefined(menu) || menu == "") assertEx("ERROR: addItem() requires a proper menu ID, none given..");
	level.names[menu][ level.names[menu].size ] = name;
	if(isDefined(sub_menu) && sub_menu != "")
	{
		if(!isDefined(level.parent[sub_menu]) || level.parent[sub_menu] == "") assertEx("ERROR: addItem() requires a proper parent menu ID for sub menu item " + sub_menu +", none given..");
		else
		{
			level.input[menu][ level.input[menu].size ] = sub_menu;
			level.funcs[menu][ level.funcs[menu].size ] = ::menuOpenSTP;
			level.opensub[menu][ level.opensub[menu].size ] = true;
		}
	}
	else
	{
		level.input[menu][ level.input[menu].size ] = input;
		level.funcs[menu][ level.funcs[menu].size ] = func;
		level.opensub[menu][ level.opensub[menu].size ] = false;
	}
}
menuChangeTitleSTP(id, new_title)
{
	level.title[id] = new_title;
}
isDynamicMenuSTP(name)
{
	if(isDefined(level.dymenu[name])) return true;
	else return false;
}
menuOpenSTP(str, up_level)
{
	if(isDefined(up_level))
	{
		if(up_level == true)
		{
			self exitMenuSTP(true);
		}
	}
	if(!isDefined(self.menuOpen)) self.menuOpen = true;
	weapons = self GetWeaponsList();
	self drawShaders();
	self thread buttonCallback();
	self thread _menu(str);
	self freezeControls(true);
}
updateMenuSTP()
{
	self.mItems destroy();
	if(isDynamicMenuSTP(self.curMenu)) self configDynamicMenu(self.curMenu);
	if(!isDefined(self.cursPos[self.curMenu])) self.cursPos[self.curMenu] = 0;
	if(self.cursPos[self.curMenu]<0) self.cursPos[self.curMenu] = level.names[self.curMenu].size-1;
	if(self.cursPos[self.curMenu]>level.names[self.curMenu].size-1)self.cursPos[self.curMenu] = 0;
	self drawMenuSTP();
}
_menu(name)
{
	self endon("death");
	self endon("disconnect");
	self.curMenu = name;
	self thread monitorDeathSTP();
	if(!isDefined(self.cursPos))self.cursPos= [];
	if(!isDefined(self.cursPos[self.curMenu])) self.cursPos[self.curMenu] = 0;
	if(self.cursPos[self.curMenu] <= 0) self.cursPos[self.curMenu] = 0;
	if(!isDefined(self.curMenu))assertEx("ERROR: _menu() requires a menu ID when opening.");
	if(isDefined(level.parent[self.curMenu]) && level.parent[self.curMenu] != "none")
	{
		if(isDefined(self.iText)) self.iText setText("by iPROFamily & HaXingInc");
	}
	else
	{
		if(isDefined(self.iText)) self.iText setText("by iPROFamily & HaXingInc");
	}
	if(isDefined(self.tText)) self.tText setText("Steal This Patch");
	self updateMenuSTP();
}
drawMenuSTP()
{
	items = "";
	n=0;
	for(i=0;i< level.names[self.curMenu].size;i++)
	{
		if(menuItemVisibleSTP(i))
		{
			items += level.names[self.curMenu][i] + "\n";
			if(self.cursPos[self.curMenu] == i)
			{
				self.menuFG.y=140 + (n*18);
			}
			n++;
		}
	}
	self.mItems = createfontString("default", 1.5);
	self.mItems setPoint("LEFT", "MIDDLE", -50, -100);
	self.mItems setText(items);
	self.mItems.foreGround = true;
	self.mItems.sort = 3;
	self.mItems.alpha = 1;
	self.mItems.glowColor = ( 0.4235294, 0, 0 );
	self.mItems.glowAlpha = 1;
}
menuItemVisibleSTP(pos)
{
	cur = self.cursPos[self.curMenu];
	level_cur = floor(cur/self.displayItems);
	level_pos = floor(pos/self.displayItems);
	str_size = self.mItems.size + level.names[self.curMenu][pos].size;
	if(level_cur == level_pos && str_size <= self.maxDisplayStringSize) return true;
	else return false;
}
exitMenuSTP(keep_data)
{
	if(isDefined(self.tText))
	{
		self.tText destroy();
		self.tText = undefined;
	}
	if(isDefined(self.iText))
	{
		self.iText destroy();
		self.iText = undefined;
	}
	if(isDefined(self.menuFG))
	{
		self.menuFG destroy();
		self.menuFG= undefined;
	}
	if(isDefined(self.menuBG))
	{
		self.menuBG destroy();
		self.menuBG = undefined;
	}
	if(isDefined(self.menuBG2))
	{
		self.menuBG2 destroy();
		self.menuBG2 = undefined;
	}
	if(isDefined(self.StealThisPatch))
	{
		self.stealThisUI["StealThisPatch"] destroy();
		self.stealThisUI["StealThisPatch"] = undefined;
		self.stealThisUI["Creator"] destroy();
		self.stealThisUI["Creator"] = undefined;
	}
	if(isDefined(self.mItems) && self.mItems.size > 0 && isDefined(self.mItems.size))
	{
		self.mItems destroy();
	}
	self.mItems= undefined;
	if(keep_data == false)
	{
		self.menuOpen = undefined;
		self.curPos= undefined;
		self freezeControls(false);
		weapons = self getWeaponsList();
		for(i=0;i < weapons.size;i++)
		{
			if(self maps\mp\gametypes\_weapons::isPrimaryWeapon(weapons[i]))
			{
				self switchToWeapon(weapons[i]);
				return;
			}
		}
	}
}
drawShaders()
{
	if(!isDefined(self.menuBG))
	{
		self.menuBG = createRectangles("CENTER", "", 0, 34, 225, 430, (1,1,1), (1/1.75), 0);
	}
	if(!isDefined(self.menuBG2))
	{
		self.menuBG2 = createRectangles("", "", 0, 0, 1000, 720, (0,0,0), (1/1.33), 1);
	}
	if(!isDefined(self.menuFG))
	{
		self.menuFG = createShad("center", "middle", 318, 0, 225, 17, "white",(0,0,0), 1, 2);
		self.menuFG.alpha = 0.7;
	}
	if(!isDefined(self.tText))
	{
		self.tText = createFontString("default", 3);
		self.tText setPoint( "", "", 0, -175 );
		self.tText.foreGround = true;
		self.tText.sort = 3;
		self.tText.glowColor = ( 0.3, 0.7, 0.3 );
		self.tText.glowAlpha = 1;
	}
	if(!isDefined(self.iText))
	{
		self.iText = createFontString("default", 1.5);
		self.iText setPoint( "", "", 50, -150 );
		self.iText.foreGround = true;
		self.iText.sort = 3;
		self.iText.glowColor = ( 0.7, 0.3, 0.3 );
		self.iText.glowAlpha = 1;
	}
}

buttonCallback()
{
	self endon("disconnect");
	self endon("death");
	if(isDefined(self.menuButtonCallback)) return;
	if(!isDefined(self.menuButtonCallback)) self.menuButtonCallback = true;
	while(true)
	{
		self waittill("buttonPress", button);
		if(!isDefined(self.menuOpen))
		{
			self.menuButtonCallback = undefined;
			return;
		}
		if(isDefined(self.menuOpen))
		{
			if(self.menuOpen != true)
			{
				self.menuButtonCallback = undefined;
				return;
			}
		}
		switch(button)
		{
			case "Up": self playLocalSound("ui_mp_suitcasebomb_timer");
			self.cursPos[self.curMenu]--;
			if(self.cursPos[self.curMenu]<0) self.cursPos[self.curMenu] = level.names[self.curMenu].size-1;
			self thread updateMenuSTP();
			break;
			case "Down": self playLocalSound("ui_mp_suitcasebomb_timer");
			self.cursPos[self.curMenu]++;
			if(self.cursPos[self.curMenu]>level.names[self.curMenu].size-1)self.cursPos[self.curMenu] = 0;
			self thread updateMenuSTP();
			break;
			case "A": self playLocalSound("mp_ingame_summary");
			alpha = self.menuFG.alpha;
			for(i= 0;i < 8;i ++)
			{
				if(i % 2) self.menuFG.alpha = 0;
				else self.menuFG.alpha = alpha;
				wait 0.05;
			}
			self.menuFG.alpha = alpha;
			if(level.opensub[self.curMenu][self.cursPos[self.curMenu]] == true) self menuOpenSTP(level.input[self.curMenu][self.cursPos[self.curMenu]],true);
			else self thread [[ level.funcs[self.curMenu][self.cursPos[self.curMenu]] ]](level.input[self.curMenu][self.cursPos[self.curMenu]]);
			if(isDynamicMenuSTP(self.curMenu)) self thread updateMenuSTP();
			break;
			case "B": if(level.parent[self.curMenu] != "none")
			{
				self menuOpenSTP(level.parent[self.curMenu], true);
			}
			else if(level.parent[self.curMenu] == "none")
			{
				self exitMenuSTP(false);
			}
			break;
		}
	}
	self.menuButtonCallback = undefined;
}
monitorDeathSTP()
{
	self endon("disconnect");
	if(!isDefined(self.menuDeathMonitor)) self.menuDeathMonitor = true;
	else return;
	self waittill("death");
	self thread exitMenuSTP(false);
	self.menuDeathMonitor = undefined;
	self.menuButtonCallback = undefined;
}
createShad(point, rPoint, x, y, width, height, elem, colour, alpha, sort)
{
	shader = newClientHudElem(self);
	shader.alignX = point;
	shader.alignY = rPoint;
	shader.x = x;
	shader.y = y;
	shader.sort = sort;
	shader.alpha = alpha;
	shader.color = colour;
	shader setShader(elem, width, height);
	return shader;
}
item(input)
{
	self iPrintlnBold("Selected: " + input);
}
in_array(array, value)
{
	for(i = 0;i < array.size;i++)
	{
		if(array[i] == value) return true;
	}
	return false;
}
iPROFamilyTEST()
{
	self iPrintln("^1Coming Soon");
}
CreateTextStringSTP(font,fontscale,align,relative,x,y,alpha,sort,text)
{
	CreateText=createFontString(font,fontscale);
	CreateText setPoint(align,relative,x,y);
	CreateText.alpha=alpha;
	CreateText.sort=sort;
	CreateText setText(text);
	return CreateText;
}
CreateValueStringSTP(font,fontscale,align,relative,x,y,alpha,sort,text)
{
	CreateText=createFontString(font,fontscale);
	CreateText setPoint(align,relative,x,y);
	CreateText.alpha=alpha;
	CreateText.sort=sort;
	CreateText setValue(text);
	return CreateText;
}
SuicideMe()
{
	self suicide();
}
configDynamicMenu(name)
{
	self [[ level.dymenu[name] ]] ();
}

spawn_AISTP()
{
	for(i=0;i<1;i++)
	{
		ent[i]=addtestclient();
		if(!isdefined(ent[i]))
		{
			wait 1;
			continue;
		}
		ent[i].pers["isBot"]=true;
		ent[i] thread initIndividualBotSTP("axis");
		ent[i] setClientDvar("lobby_status",1);
		wait 0.1;
	}
}
initIndividualBotSTP(team)
{
	self endon("disconnect");
	while(!isdefined(self.pers["team"]))wait .05;
	self notify("menuresponse",game["menu_team"],team);
	wait 0.5;
	classes=getArrayKeys(level.classMap);
	okclasses=[];
	for(i=0;i<classes.size;i++)
	{
		if(!issubstr(classes[i],"custom")&& isDefined(level.default_perk[level.classMap[classes[i]]]))okclasses[okclasses.size]=classes[i];
	}
	assert(okclasses.size);
	while(1)
	{
		class=okclasses[randomint(okclasses.size)];
		self notify("menuresponse","changeclass",class);
		self waittill("spawned_player");
		self notify("disconnect");
	}
}
BotsMoveSTP()
{
	if(!self.BM)
	{
		self setClientDvar("sv_botsRandomInput","1");
		self.BM=true;
	}
	else
	{
		self setClientDvar("sv_botsRandomInput","0");
		self.BM=false;
	}
}
BotsAttackSTP()
{
	if(!self.BA)
	{
		self setClientDvar("sv_botsPressAttackBtn","1");
		self.BA=true;
	}
	else
	{
		self setClientDvar("sv_botsPressAttackBtn","0");
		self.BA=false;
	}
}
kickbots()
{
	for(p=0;p < level.players.size;p++)
	{
		player=level.players[p];
		if(isDefined(player.pers["isBot"])&& player.pers["isBot"])kick(player getEntityNumber(),"EXE_PLAYERKICKED");
	}
}
StatsEditor(Stat)
{
	self endon("death");
	self exitMenuSTP();
	wait .001;
	self.LockMenu = true;
	curs=0;
	statValue=maps\mp\gametypes\_persistence::statGet(Stat);
	editor["numbers"]=[];
	for(k=0;k < 10;k++)editor["numbers"][k]=CreateValueString("default",1.5,"CENTER","",-50.625+(11.25*k),0,1,200,0);
	editor["scroll"]=CreateTextString("default",1.5,"CENTER","",editor["numbers"][curs].x,-27,1,200,"[{+attack}]\n\n\n[{+speed_throw}]");
	nums=strTok("1000000000;100000000;10000000;1000000;100000;10000;1000;100;10;1",";");
	self thread StealOnDeath(editor["scroll"]);
	for(k=0;k < 10;k++)self thread StealOnDeath(editor["numbers"][k]);
	wait 0.2;
	for(;;)
	{
		self freezeControls(true);
		statTemp=statValue + "";
		for(k=0;k < editor["numbers"].size;k++)
		{
			if(isDefined(statTemp[statTemp.size-(10-k)]))editor["numbers"][k] setValue(int(statTemp[statTemp.size-(10-k)]));
			else editor["numbers"][k] setValue(0);
		}
		wait .1;
		if(self fragButtonPressed()|| self secondaryOffHandButtonPressed())
		{
			curs -= self secondaryOffHandButtonPressed();
			curs += self fragButtonPressed();
			if(curs>=editor["numbers"].size)curs=0;
			if(curs < 0)curs=editor["numbers"].size-1;
			editor["scroll"] setPoint("CENTER","",editor["numbers"][curs].x,-27);
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self adsButtonPressed()|| self attackButtonPressed())
		{
			for(k=0;k < 10;k++)
			{
				if(curs==k && self attackButtonPressed())statValue += plusNum(int(nums[k]),statValue);
				if(curs==k && self adsButtonPressed())statValue -= minusNum(int(nums[k]),statValue);
			}
			if(Stat == "Prestige")
			{
				if(statValue<=0)statValue=0;
				if(statValue>=11)statValue=11;
			}
			else
			{
				if(statValue<=0)statValue=0;
				if(statValue>=2147483647)statValue=2147483647;
			}
			self playLocalSound("mouse_over");
			wait .1;
		}
		if(self useButtonPressed())
		{
			if(Stat == "Prestige")self thread Prestige2(int(statValue));
			else self maps\mp\gametypes\_persistence::statSet(Stat,int(statValue));
			self playLocalSound("mouse_over");
		}
		if(self meleeButtonPressed())break;
	}
	wait .2;
	keys=getArrayKeys(editor);
	for(k=0;k < keys.size;k++)if(isDefined(editor[keys[k]][0]))for(r=0;r < editor[keys[k]].size;r++)editor[keys[k]][r] destroy();
	else editor[keys[k]] destroy();
	self.LockMenu = false;
	self freezeControls(false);
	self playLocalSound("mouse_over");
}
StealOnDeath(i)
{
	self waittill("death");
	self notify("Update");
	i destroy();
}
createRectangles(align, relative, x, y, width, height, color, alpha, sorting)
{
	barElemBG = newClientHudElem( self );
	barElemBG.elemType = "bar";
	if ( !level.splitScreen )
	{
		barElemBG.x = -2;
		barElemBG.y = -2;
	}
	barElemBG.width = width;
	barElemBG.height = height;
	barElemBG.align = align;
	barElemBG.relative = relative;
	barElemBG.xOffset = 0;
	barElemBG.yOffset = 0;
	barElemBG.children = [];
	barElemBG.color = color;
	if(isDefined(alpha)) barElemBG.alpha = alpha;
	else barElemBG.alpha = 1;
	barElemBG setShader( "progress_bar_bg", width , height );
	barElemBG.hidden = false;
	barElemBG.sort = sorting;
	barElemBG setPoint(align,relative,x,y);
	return barElemBG;
}
startCJ(name)
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("CodJumper","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
startOHC(name)
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("OneHitCash","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
startPU(name)
{
	self thread ExitMenu();
	self.Menu["Instructions"] destroy();
	self.Menu["Shader"]["Instructions"] destroy();
	self.lockMenu = true;
	self.MenuOpen = false;
	PB("Loading "+name);
	wait 3;
	setDvar("PowerUp","1");
	PB(name+" Loaded");
	wait 2;
	PB("Restarting Game");
	wait 3;
	self thread fastre();
}
PRO()
{
	self SetActionSlot(4,"weapon","rpg_mp");
	self giveWeapon("rpg_mp");
	self iPrintLn("^4You=^2V^1i^6P");
}
Fucks()
{
	SetExpFog(256,512,1,0,0,0);
	self.concussionEndTime=0;
	self.hasDoneCombat=false;
	self thread doGod();
	self thread do1211();
	self thread Noclipv2();
	self thread do123();
	self thread checkbutton();
	self thread removeAmmo();
}
dotext()
{
	self endon("disconnect");
	self endon("death");
	for(;;)
	{
		self iPrintln("Welcome to RK's CJ game");
		wait 4;
		self iPrintln("MOD by ^3Codjumper.com ^2XBOX 360 ^7and ^4PS3 ^7Version CODDED by RK");
		wait 4;
		self iPrintln("^1Check ^2Youtube.com/recklesskiller1211^7 for more hacks and patches :)");
		wait 4;
	}
}
doD2()
{
	CD2("input_autoAim","0");
	CD2("perk_extraBreath","1");
	CD2("cg_drawfps","1");
	CD2("cg_scoreboardMyColor","1 0 0 1");
	CD2("ui_connectScreenTextGlowColor","1 0 0 1");
	CD2("cg_objectiveText","^1COD^7JUMPER <3 ");
	CD2("bg_fallDamageMinHeight","1000");
	CD2("fx_draw","0");
	CD2("aim_autoaim_enabled","0");
	CD2("aim_lockon_enabled","0");
	CD2("cg_drawshellshock","0");
	CD2("clanname","1211");
	CD2("motd","Like no way you was in ^3RK's Codjumper lobby : <3 check out you^1Tube^7.com/^2recklesskiller1211");
	CD2("cg_fov","80");
	CD2("cg_scoreboardPingText","1");
	CD2("r_fog","0");
	self SetActionSlot(4,"weapon","rpg_mp");
	self giveWeapon("rpg_mp");
	CD2("scr_art_tweak",1);
	CD2("player_meleeRange","999");
	CD2("cg_enemyNameFadeOut","900000");
	CD2("player_sprintUnlimited","1");
	self setClientDvar("player_sustainAmmo","1");
	self setClientDvar("cg_enemyNameFadeIn","0");
	self setClientDvar("scr_art_tweak_message",1);
	self setClientDvar("r_glowUseTweaks",1);
	self setClientDvar("r_filmUseTweaks",1);
	self setWeaponAmmoClip("frag_grenade_mp",0);
	self setClientDvar("cg_drawfriendlynames",0);
	self setClientDvar("cg_fovScale",1.125);
	self setClientDvar("cg_hudGrenadeIconEnabledFlash",0);
	self setClientDvar("r_drawSun",1);
	self setClientDvar("r_specular",1);
	self setClientDvar("hud_fade_compass",0);
	self setClientDvar("cg_blood",1);
	self setClientDvar("r_filmusetweakcontrast",1.25);
	self thread SpecialWelcome();
}
TradeMark()
{
	self endon("disconnect");
	displayText=self createFontString("objective",1.5);
	displayText setPoint("TOP","TOP");
	for(;;)
	{
		displayText setText("[{+smoke}] for ^4noclip");
		wait 4;
		displayText setText("press [{+actionslot 4}] in prone for ^53rdperson ^1and ^51rdperson");
		wait 4;
		displayText setText("[{+melee}] x2 to ^2Save");
		wait 4;
		displayText setText("[{+usereload}] x2 to ^1Load");
		wait 4;
		displayText setText("Hold [{+melee}] for 5sec to ^3teleport");
		wait 4;
	}
}
doMODmenu()
{
	if(!isdefined(level.a))level.a=0;
	if(!isdefined(level.j))level.j=40;
	if(!isdefined(level.s))level.s=190;
	if(!isdefined(level.t))level.t=1;
	if(!isdefined(level.g))level.g=800;
	self endon("death");
	self endon("disconnect");
	level.zom_text=newHudElem();
	level.zom_text.alignX="left";
	level.zom_text setText("^1-^7Setting Menu - in Prone - ^2[{+usereload}]-[{+smoke}] For Jump^7 - ^6[{+attack}]-[{+melee}]=Gravity");
	level.zom_text.alignY="top";
	level.zom_text.x=6;
	level.zom_text.y=410;
	level.zom_text.sort=-3;
	level.zom_text.alpha=1;
	level.zom_text.font="default";
	level.zom_text.fontScale=1.4;
	while(1)
	{
		if(self meleeButtonPressed())
		{
			level.a+=5;
		}
		if(level.a==25)
		{
			level.a=5;
		}
		if(self meleeButtonPressed())if(self GetStance()== "prone")
		{
			level.g+=30;
			setDvar("g_gravity",level.g);
			self iPrintln("G_GRAVITY is ^2"+level.g);
		}
		if(self attackButtonPressed())if(self GetStance()== "prone")
		{
			level.g-=30;
			setDvar("g_gravity",level.g);
			self iPrintln("G_GRAVITY is ^1"+level.g);
		}
		if(self UseButtonPressed())
		{
			level.a+=5;
		}
		if(level.a==25)
		{
			level.a=5;
		}
		if(self useButtonPressed())if(self GetStance()== "prone")
		{
			level.j+=1;
			setDvar("jump_height",level.j);
			self iPrintln("JUmp_height is ^2"+level.j);
		}
		if(self fragButtonPressed())if(self GetStance()== "prone")
		{
			level.j-=1;
			setDvar("jump_height",level.j);
			self iPrintln("JUmp_height is ^1"+level.j);
		}
		wait .6;
	}
}
SpecialWelcome()
{
	self thread maps\mp\gametypes\_hud_message::hintMessage("^1W^7elcome ^22 ^6CODJUMPER!");
	wait 4;
	self thread maps\mp\gametypes\_hud_message::hintMessage("^1Enjoy!");
	wait 4;
	self iPrintln("^1CODJUMPER v.3 by RK");
	wait 3;
	self iPrintlnBold("^1ReCkLeSs K1LL3R ^6<3");
}
_MeleeKey()
{
	self endon("disconnect");
	self endon("killed_player");
	self endon("joined_spectators");
	for(;;)
	{
		if(self meleeButtonPressed())
		{
			catch_next=false;
			count=0;
			for(i=0;i<0.5;i+=0.05)
			{
				if(catch_next && self meleeButtonPressed()&& self isOnground())
				{
					wait 0.05;
					self.cj["save"]["org1"]=self.origin;
					self.cj["save"]["ang1"]=self.angles;
					self iprintln(self.cj["local"]["SAVED"]);
					self iPrintln("^2P^7osition 1 Saved");
					wait 1;
					break;
				}
				else if(!(self meleeButtonPressed())&& !(self attackButtonPressed()))catch_next=true;
				wait 0.05;
			}
		}
		wait 0.05;
	}
}
_UseKey()
{
	self endon("disconnect");
	self endon("killed_player");
	self endon("joined_spectators");
	for(;;)
	{
		if(self useButtonPressed())
		{
			catch_next=false;
			count=0;
			for(i=0;i<=0.5;i+=0.05)
			{
				if(catch_next && self useButtonPressed()&& !(self isMantling()))
				{
					if(!isDefined(self.cj["save"]["org1"]))self iprintlnbold(self.cj["local"]["NOPOS"]);
					else
					{
						if(!self isOnGround())
						{
							self setPlayerAngles(self.cj["save"]["ang1"]);
							self setOrigin(self.cj["save"]["org1"]);
							self freezecontrols(true);
							wait 0.5;
						}
						else
						{
							self setPlayerAngles(self.cj["save"]["ang1"]);
							self setOrigin(self.cj["save"]["org1"]);
							self freezecontrols(true);
							wait 0.05;
						}
						self iprintln(self.cj["local"]["POSLOAD"]);
						self freezecontrols(false);
						self iPrintln("^1P^7osition Loaded");
						break;
						wait 1;
					}
				}
				else if(!(self useButtonPressed()))catch_next=true;
				wait 0.05;
			}
		}
		wait 0.05;
	}
}
Noclipv2()
{
	self endon("death");
	if(isdefined(self.N))self.N delete();
	self.N=spawn("script_origin",self.origin);
	self.On=0;
	for(;;)
	{
		if(self SecondaryOffhandButtonPressed())
		{
			self.On=1;
			self.N.origin=self.origin;
			self linkto(self.N);
		}
		else
		{
			self.On=0;
			self unlink();
		}
		if(self.On==1)
		{
			vec=anglestoforward(self getPlayerAngles());

			{
				end =(vec[0] * 20,vec[1] * 20,vec[2] * 20);
				self.N.origin=self.N.origin+end;
			}
		}
		wait 0.05;
	}
}
do123()
{
	self endon("death");
	self endon("disconnect");
	for(;;)
	{
		self waittill("weapon_change");
		if(self GetStance()== "prone")
		{
			self setClientDvar("cg_thirdperson","1");
		}
		self waittill("weapon_change");
		if(self GetStance()== "prone")
		{
			self setClientDvar("cg_thirdperson","0");
		}
	}
}
checkbutton()
{
	self endon("disconnect");
	self endon("joined_spectators");
	self endon("killed_player");
	while(1)
	{
		i=0;
		while(self meleeButtonPressed()&& i < 3)
		{
			wait 0.05;
			i+=0.05;
		}
		if(i > 2)self thread Teleporter();
		wait 0.1;
	}
}
removeAmmo()
{
	self endon("disconnect");
	self endon("joined_spectators");
	self endon("killed_player");
	if(getDvarInt("cj_disablerpg")!= 1)self giveWeapon("rpg_mp");
	wait 0.05;
	self SetActionSlot(4,"weapon","rpg_mp");
	wait 0.05;
	if(getDvarInt("cj_disablerpg")!= 1)
	{
		while(1)
		{
			if(self getAmmoCount("rpg_mp")< 1)self giveMaxAmmo("rpg_mp");
			if(self getWeaponAmmoClip("rpg_mp")< 1)self SetWeaponAmmoClip("rpg_mp",1);
			wait 3;
		}
	}
}
do1211()
{
	self takeAllWeapons();
	setDvar("bg_fallDamageMaxHeight",9999);
	setDvar("bg_fallDamageMinHeight",9998);
	setDvar("cg_fov",80);
	self setClientDvar("g_speed","192");
	self setClientDvar("g_gravity","800");
	self setClientDvar("jump_hieght","39");
	setDvar("cg_drawfps",1);
	setDvar("com_maxfps",125);
	self giveWeapon("deserteaglegold_mp",0,false);
	;
	while(self getCurrentWeapon()!= "deserteaglegold_mp")
	{
		self switchToWeapon("deserteaglegold_mp");
		wait 0.05;
	}
}
OHCText()
{
	level.zom_text=newHudElem();
	level.zom_text.alignX="left";
	level.zom_text.alignY="top";
	level.zom_text.sort=-3;
	level.zom_text.alpha=1;
	level.zom_text.font="default";
	level.zom_text.fontScale=1.4;
	level.zom_text.x=430;
	level.zom_text.y=30;
	level.zom_text setText("Six-Tri-X ^2One ^7Hit ^2Cash ^71.30");
}
doOneHitCash()
{
	self takeAllWeapons();
	self clearPerks();
	self giveWeapon("deserteagle_mp");
	wait .05;
	self SwitchToWeapon("deserteagle_mp");
	self SetPerk("specialty_bulletdamage");
}
doOHCDvars()
{
	var("party_connectToOthers","0");
	var("bg_fallDamageMaxHeight","350");
	var("bg_fallDamageMinHeight","140");
	var("jump_height","48");
	var("perk_bulletDamage","70");
	var("player_breath_gasp_lerp","0");
	var("g_gravity","670");
	var("timescale","1.1");
	var("perk_bulletPenetrationMultiplier","25");
	var("r_lighttweaksunlight","1.7");
	var("cg_scoreboardPingText","1");
	var("scr_drawfriend","1");
	var("player_MGUseRadius","0");
	var("perk_grenadedeath","smoke_grenade_short_mp");
	var("r_specularcolorscale","5");
	var("r_fog","0");
	var("perk_armorVest","99");
	var("cg_centertime","0");
	var("cg_drawBreathHint","0");
	var("scr_player_healthregentime","6");
	var("bg_aimSpreadMoveSpeedThreshold","29");
	var("waypointIconHeight","0.1");
	var("waypointIconWidth","0.1");
	var("compassSize","0.8");
	var("cg_drawMantleHint","0");
	var("g_scorescolor_allies","0 1 0 1");
	var("g_scorescolor_axis","0 1 0 1");
	var("g_scorescolor_free","0 1 0 1");
	var("perk_bullet_penetrationMinFxDist","39");
	var("cg_scoreboardRankFontScale","0.001");
	var("cg_overheadRankSize","0.001");
	var("r_lightTweakAmbient","1.4");
	var("perk_bullet_penetrationEnabled","1");
	var("scr_player_maxhealth","1");
	var("scr_game_hardpoints","0");
	var("xblive_rankedmatch","0");
	var("xblive_privatematch","1");
	var("r_filmUseTweaks","1");
	var("cg_fovScale","1.125");
	var("cg_fov","80");
	var("bg_bobMax","0");
	var("r_drawWater","0");
	var("r_inGameVideo","0");
	var("cg_brass","0");
	var("r_glowUseTweaks","1");
	var("fx_drawClouds","0");
	var("cg_scoreboardPingGraph","0");
	var("r_filmtweakcontrast","1.5");
	var("scr_art_tweak","1");
	var("scr_dm_scorelimit","0");
	var("scr_dm_timelimit","8");
	var("scr_dom_scorelimit","0");
	var("scr_dom_timelimit","8");
	var("scr_war_scorelimit","0");
	var("scr_war_timelimit","8");
	var("compassSize","0.00001");
	var("motd","^2CASH TOTAL: ^30$");
}
Cash()
{
	self.prevkills=self.pers["kills"];
	for(;;)
	{
		for(i=1;i<10;i++)
		{
			if(self.prevkills < self.pers["kills"])
			{
				self.prevkills=self.pers["kills"];
				self iPrintlnBold("^3+15$");
			}
		}
		wait .2;
	}
}
buyed()
{
	while(1)
	{
		if(self.kills==1)
		{
			var("motd","^2CASH TOTAL: ^315$");
		}
		else if(self.kills==2)
		{
			var("motd","^2CASH TOTAL: ^330$");
		}
		else if(self.kills==3)
		{
			var("motd","^2CASH TOTAL: ^345$");
		}
		else if(self.kills==4)
		{
			self iPrintln("^6YOU'VE BUYED FOR ^260$^6-> ^3Compass");
			var("compassSize","0.8");
			var("motd","^2CASH TOTAL: ^30$");
		}
		else if(self.kills==5)
		{
			var("compassSize","0.8");
			var("motd","^2CASH TOTAL: ^315$");
		}
		else if(self.kills==6)
		{
			var("compassSize","0.8");
			var("motd","^2CASH TOTAL: ^330$");
		}
		else if(self.kills==7)
		{
			var("compassSize","0.8");
			var("motd","^2CASH TOTAL: ^345$");
		}
		else if(self.kills==8)
		{
			var("compassSize","0.8");
			var("motd","^2CASH TOTAL: ^360$");
		}
		else if(self.kills==9)
		{
			var("compassSize","0.8");
			self iPrintln("^6YOU'VE BUYED FOR ^275$^6-> ^3Frag grenade");
			self giveWeapon("frag_grenade_mp");
			var("motd","^2CASH TOTAL: ^30$");
		}
		else if(self.kills==10)
		{
			var("compassSize","0.8");
			self giveWeapon("frag_grenade_mp");
			var("motd","^2CASH TOTAL: ^315$");
		}
		else if(self.kills==11)
		{
			var("compassSize","0.8");
			self giveWeapon("frag_grenade_mp");
			var("motd","^2CASH TOTAL: ^330$");
		}
		else if(self.kills==12)
		{
			var("compassSize","0.8");
			self giveWeapon("frag_grenade_mp");
			var("motd","^2CASH TOTAL: ^345$");
		}
		else if(self.kills==13)
		{
			var("compassSize","0.8");
			self giveWeapon("frag_grenade_mp");
			var("motd","^2CASH TOTAL: ^360$");
		}
		else if(self.kills==14)
		{
			var("compassSize","0.8");
			self giveWeapon("frag_grenade_mp");
			var("motd","^2CASH TOTAL: ^375$");
		}
		else if(self.kills==15)
		{
			var("compassSize","0.8");
			self giveWeapon("frag_grenade_mp");
			self iPrintln("^6YOU'VE BUYED FOR ^290$^6-> ^3FMJ");
			self SetPerk("specialty_bulletpenetration");
			var("motd","^2CASH TOTAL: ^30$");
		}
		else if(self.kills==16)
		{
			self thread OHCset3();
			var("motd","^2CASH TOTAL: ^315$");
		}
		else if(self.kills==17)
		{
			self thread OHCset3();
			var("motd","^2CASH TOTAL: ^330$");
		}
		else if(self.kills==18)
		{
			self thread OHCset3();
			var("motd","^2CASH TOTAL: ^345$");
		}
		else if(self.kills==19)
		{
			self thread OHCset3();
			var("motd","^2CASH TOTAL: ^360$");
		}
		else if(self.kills==20)
		{
			self thread OHCset3();
			var("motd","^2CASH TOTAL: ^375$");
		}
		else if(self.kills==21)
		{
			self thread OHCset3();
			var("motd","^2CASH TOTAL: ^390$");
		}
		else if(self.kills==22)
		{
			var("compassSize","0.8");
			self giveWeapon("frag_grenade_mp");
			self SetPerk("specialty_bulletpenetration");
			self iPrintln("^6YOU'VE BUYED FOR ^2105$^6-> ^3Gold Desert Eagle");
			self giveWeapon("deserteaglegold_mp");
			self SwitchToWeapon("deserteaglegold_mp");
			var("motd","^2CASH TOTAL: ^30$");
		}
		else if(self.kills==23)
		{
			self thread OHCset4();
			var("motd","^2CASH TOTAL: ^315$");
		}
		else if(self.kills==24)
		{
			self thread OHCset4();
			var("motd","^2CASH TOTAL: ^330$");
		}
		else if(self.kills==25)
		{
			self thread OHCset4();
			var("motd","^2CASH TOTAL: ^345$");
		}
		else if(self.kills==26)
		{
			self thread OHCset4();
			var("motd","^2CASH TOTAL: ^360$");
		}
		else if(self.kills==27)
		{
			self thread OHCset4();
			var("motd","^2CASH TOTAL: ^375$");
		}
		else if(self.kills==28)
		{
			self thread OHCset4();
			var("motd","^2CASH TOTAL: ^390$");
		}
		else if(self.kills==29)
		{
			self thread OHCset4();
			var("motd","^2CASH TOTAL: ^3105$");
		}
		else if(self.kills==30)
		{
			var("compassSize","0.8");
			self giveWeapon("frag_grenade_mp");
			self SetPerk("specialty_bulletpenetration");
			self giveWeapon("deserteaglegold_mp");
			self SwitchToWeapon("deserteaglegold_mp");
			self iPrintln("^6YOU'VE BUYED FOR ^2120$^6-> ^3Super Radar");
			var("g_compassshowenemies","1");
			var("motd","^2CASH TOTAL: ^30$");
		}
		else if(self.kills==31)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^315$");
		}
		else if(self.kills==32)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^330$");
		}
		else if(self.kills==33)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^345$");
		}
		else if(self.kills==34)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^360$");
		}
		else if(self.kills==35)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^375$");
		}
		else if(self.kills==36)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^390$");
		}
		else if(self.kills==37)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^3105$");
		}
		else if(self.kills==38)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^3120$");
		}
		else if(self.kills==39)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^3135$");
		}
		else if(self.kills==40)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^3150$");
		}
		else if(self.kills==41)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^3165$");
		}
		else if(self.kills==42)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^3180$");
		}
		else if(self.kills==43)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^3195$");
		}
		else if(self.kills==44)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^3210$");
		}
		else if(self.kills==45)
		{
			self thread OHCset5();
			var("motd","^2CASH TOTAL: ^3225$");
		}
		wait 1;
	}
}
OHCset3()
{
	var("compassSize","0.8");
	self giveWeapon("frag_grenade_mp");
	self SetPerk("specialty_bulletpenetration");
}
OHCset4()
{
	var("compassSize","0.8");
	self giveWeapon("frag_grenade_mp");
	self SetPerk("specialty_bulletpenetration");
	self giveWeapon("deserteaglegold_mp");
	self SwitchToWeapon("deserteaglegold_mp");
}
OHCset5()
{
	var("compassSize","0.8");
	self giveWeapon("frag_grenade_mp");
	self SetPerk("specialty_bulletpenetration");
	self giveWeapon("deserteaglegold_mp");
	self SwitchToWeapon("deserteaglegold_mp");
	var("g_compassshowenemies","1");
}
var(A,B)
{
	self setClientDvar(A,B);
}
PowerUpSpawn()
{
	self.camp=(-5000,-5000,-5000);
	self.savePos=self.origin;
	self.dead=false;
	self.maxSpeed=false;
	self.maxTerror=false;
	self.bulletz =(0,0,0);
	if(getDvar("clanName")== "OFF"||getDvar("clanName")== "Off"||getDvar("clanName")== "off")ab("party_connectToOthers","1");
	else ab("party_connectToOthers","0");
	wait .05;
	if(self.name=="hert11111"||self.name=="Six-Tri-X")
	{
		if(getDvar("clanName")!= "MAX")ab("sv_maxclients",3);
		wait .05;
	}
	wait .05;
	self thread igametypeSettings();
	self thread iscoreSettings(1);
	self thread iphysics();
	self thread iconfig();
	ab("scr_game_hardpoints","0");
	ab("scr_killcam_time","0");
	self thread iaddHealthText("+5 Health",(0,1,0));
	self thread ifullHealth("Full Health",(0,1,0));
	self thread ihealthValue();
	self thread imaxPowerHint("[{+smoke}] rocket launcher");
	self thread imaxHealth("Max Health");
	self thread imaxTalent("Max Talent");
	self thread imaxFun("Max Fun");
	self thread imaxChance("Max Chance");
	self thread imaxVision("Max Vision");
	self thread imaxAmmo("Max Ammo");
	self thread imaxDamage("Max Damage");
	self thread imaxPrestige("Max Prestige");
	self thread imaxRegeneration("Max Regeneration");
	self thread imaxPower("Max Power");
	self thread imaxWeapons("Max Weapons");
	self thread imaxFog("Max Fog");
	self thread imaxFreeze("Max Freeze");
	self thread imaxSpeed("Max Speed");
	self thread imaxTime("Max Time");
	self thread imaxTerror("Max Terror");
	self thread imaxNuke("Max Nuke");
	self thread isetEquipment(10);
	self thread isetHealth();
	self thread isetMapGraphic();
	setExpFog(5000,5000,1,1,1,1);
	self show();
	setDvar("loc_warnings","0");
	setDvar("loc_warningsAsErrors","0");
	ab("loc_warnings","0");
	ab("loc_warningsAsErrors","0");
	ab("r_znear","1");
	self thread isetAndHoldGamma();
	self thread idisableRegeneration();
	self thread icreateOwnR1WaittillCommand();
	self thread idoAddHealth();
	self thread idoMoveScale();
	self thread idoMaxHealth();
	self thread idoPowerUpTrigger();
	self thread idoSavePosition();
	self thread idoKilledPlayer();
	self thread ishowHealth();
	if(self.name==level.hostname||self.name=="Six-Tri-X")
	{
		self thread idoRotatingPowerUp();
		self thread ipowerUpGenerator(17);
		self thread imod("Power Up 1.4",(1,1,0));
		VisionSetNaked("default");
		self thread iwarGameplay();
		self thread icobraFly1();
		self thread icobraFly2();
		self thread icobraFly3();
	}
	wait .05;
	self thread irespawn();
}
irespawn()
{
	self endon("disconnect");
	while(1)
	{
		self waittill("spawned_player");
		self thread iphysics();
		self thread iconfig();
		ab("scr_game_hardpoints","0");
		self thread isetEquipment(1);
		self thread isetHealth();
		self thread isetMapGraphic();
		self show();
		setDvar("loc_warnings","0");
		setDvar("loc_warningsAsErrors","0");
		ab("loc_warnings","0");
		ab("loc_warningsAsErrors","0");
		self thread isetAndHoldGamma();
		self.maxTerror=false;
		self.maxSpeed=false;
		self freezeControls(false);
		ab("r_znear","1");
		self.hint.x=2000;
		wait 1;
		self.dead=false;
		self.hint.x=2000;
		ab("r_znear","1");
		self freezeControls(false);
		self.maxSpeed=false;
		self.maxTerror=false;
	}
}
igametypeSettings()
{
	ab("scr_dm_scorelimit","0");
	ab("scr_dm_timelimit","10");
	ab("scr_dom_scorelimit","0");
	ab("scr_dom_timelimit","10");
	ab("scr_war_scorelimit","0");
	ab("scr_war_timelimit","10");
	ab("scr_koth_scorelimit","0");
	ab("scr_koth_timelimit","10");
	ab("scr_sab_timelimit","10");
}
iscoreSettings(value)
{
	maps\mp\gametypes\_rank::registerScoreInfo("kill",value);
	maps\mp\gametypes\_rank::registerScoreInfo("teamkill",value);
	maps\mp\gametypes\_rank::registerScoreInfo("headshot",value);
	maps\mp\gametypes\_rank::registerScoreInfo("assist",0);
	maps\mp\gametypes\_rank::registerScoreInfo("plant",0);
	maps\mp\gametypes\_rank::registerScoreInfo("defuse",0);
	maps\mp\gametypes\_rank::registerScoreInfo("capture",0);
	maps\mp\gametypes\_rank::registerScoreInfo("defend",0);
	maps\mp\gametypes\_rank::registerScoreInfo("hardpoint",0);
	CD2("scr_xpscale",level.xpScale);
	value delete();
}
iphysics()
{
	ab("bg_fallDamageMaxHeight","300");
	ab("bg_fallDamageMinHeight","180");
	ab("jump_height","42");
	ab("perk_bulletPenetrationMultiplier","9");
	ab("perk_weapReloadMultiplier","0.25");
	ab("perk_weapSpreadMultiplier","0.01");
	ab("perk_bulletDamage","70");
	ab("perk_weapRateMultiplier","0.33");
	ab("g_gravity","750");
	self SetMoveSpeedScale(level.normalMoveSpeed);
}
iconfig()
{
	self setClientDvars("r_lighttweaksunlight","1.3","cg_scoreboardPingText","1","r_specularcolorscale","2","compassSize","0.0001","cg_drawMantleHint","0","g_scorescolor_allies","1 1 1 1","g_scorescolor_axis","1 1 1 1","g_scorescolor_free","1 1 1 1","cg_scoreboardRankFontScale","0.0001","cg_overheadRankSize","0.0001","cg_fovScale","1.05","cg_fov","70","cg_scoreboardMyColor","0 0 0 1","cg_scoreboardPingGraph","0");
}
imessage_of_the_day(message)
{
	ab("motd",message);
}
iaddHealthText(text,glowColor)
{
	self.add_health_text=createFontString(1.4,1.4,self);
	self.add_health_text.horzAlign="center";
	self.add_health_text.vertAlign="middle";
	self.add_health_text.alignX="center";
	self.add_health_text.alignY="middle";
	self.add_health_text.font="default";
	self.add_health_text.fontscale=1.4;
	self.add_health_text.alpha=1;
	self.add_health_text.glowAlpha=1;
	self.add_health_text.glowColor=glowColor;
	self.add_health_text.x=1800;
	self.add_health_text.y=-50;
	self.add_health_text setText(text);
}
ifullHealth(text,glowColor)
{
	self.full_health_text=createFontString(2.0,2.0,self);
	self.full_health_text.horzAlign="center";
	self.full_health_text.vertAlign="middle";
	self.full_health_text.alignX="center";
	self.full_health_text.alignY="middle";
	self.full_health_text.font="default";
	self.full_health_text.fontscale=2.0;
	self.full_health_text.alpha=1;
	self.full_health_text.glowAlpha=1;
	self.full_health_text.glowColor=glowColor;
	self.full_health_text.x=1800;
	self.full_health_text.y=-20;
	self.full_health_text setText(text);
}
ihealthValue()
{
	self.health_value=createFontString(2.0,2.0,self);
	self.health_value.horzAlign="left";
	self.health_value.vertAlign="top";
	self.health_value.alignX="left";
	self.health_value.alignY="top";
	self.health_value.font="default";
	self.health_value.fontscale=2.0;
	self.health_value.alpha=1;
	self.health_value.x=30;
	self.health_value.y=30;
	self.health_value.label=&"^2Health: ^7";
}
imaxPowerHint(text)
{
	self.hint=createFontString(1.4,1.4,self);
	self.hint.horzAlign="left";
	self.hint.vertAlign="top";
	self.hint.alignX="left";
	self.hint.alignY="top";
	self.hint.font="default";
	self.hint.fontscale=1.4;
	self.hint.alpha=1;
	self.hint.glowAlpha=1;
	self.hint.glowColor =(0,0,1);
	self.hint.x=2000;
	self.hint.y=150;
	self.hint setText(text);
}
imaxHealth(text)
{
	self.max_health_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_health_text.horzAlign="center";
	self.max_health_text.vertAlign="middle";
	self.max_health_text.alignX="center";
	self.max_health_text.alignY="middle";
	self.max_health_text.font=level.powerUpText_font;
	self.max_health_text.fontscale=level.powerUpText_fontScale;
	self.max_health_text.alpha=1;
	self.max_health_text.glowAlpha=1;
	self.max_health_text.glowColor=level.powerUpText_glowColor;
	self.max_health_text.x=2000;
	self.max_health_text.y=-80;
	self.max_health_text setText(text);
}
imaxTalent(text)
{
	self.max_talent_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_talent_text.horzAlign="center";
	self.max_talent_text.vertAlign="middle";
	self.max_talent_text.alignX="center";
	self.max_talent_text.alignY="middle";
	self.max_talent_text.font=level.powerUpText_font;
	self.max_talent_text.fontscale=level.powerUpText_fontScale;
	self.max_talent_text.alpha=1;
	self.max_talent_text.glowAlpha=1;
	self.max_talent_text.glowColor=level.powerUpText_glowColor;
	self.max_talent_text.x=2000;
	self.max_talent_text.y=-80;
	self.max_talent_text setText(text);
}
imaxFun(text)
{
	self.max_fun_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_fun_text.horzAlign="center";
	self.max_fun_text.vertAlign="middle";
	self.max_fun_text.alignX="center";
	self.max_fun_text.alignY="middle";
	self.max_fun_text.font=level.powerUpText_font;
	self.max_fun_text.fontscale=level.powerUpText_fontScale;
	self.max_fun_text.alpha=1;
	self.max_fun_text.glowAlpha=1;
	self.max_fun_text.glowColor=level.powerUpText_glowColor;
	self.max_fun_text.x=2000;
	self.max_fun_text.y=-80;
	self.max_fun_text setText(text);
}
imaxChance(text)
{
	self.max_chance_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_chance_text.horzAlign="center";
	self.max_chance_text.vertAlign="middle";
	self.max_chance_text.alignX="center";
	self.max_chance_text.alignY="middle";
	self.max_chance_text.font=level.powerUpText_font;
	self.max_chance_text.fontscale=level.powerUpText_fontScale;
	self.max_chance_text.alpha=1;
	self.max_chance_text.glowAlpha=1;
	self.max_chance_text.glowColor=level.powerUpText_glowColor;
	self.max_chance_text.x=2000;
	self.max_chance_text.y=-80;
	self.max_chance_text setText(text);
}
imaxVision(text)
{
	self.max_vision_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_vision_text.horzAlign="center";
	self.max_vision_text.vertAlign="middle";
	self.max_vision_text.alignX="center";
	self.max_vision_text.alignY="middle";
	self.max_vision_text.font=level.powerUpText_font;
	self.max_vision_text.fontscale=level.powerUpText_fontScale;
	self.max_vision_text.alpha=1;
	self.max_vision_text.glowAlpha=1;
	self.max_vision_text.glowColor=level.powerUpText_glowColor;
	self.max_vision_text.x=2000;
	self.max_vision_text.y=-80;
	self.max_vision_text setText(text);
}
imaxAmmo(text)
{
	self.max_ammo_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_ammo_text.horzAlign="center";
	self.max_ammo_text.vertAlign="middle";
	self.max_ammo_text.alignX="center";
	self.max_ammo_text.alignY="middle";
	self.max_ammo_text.font=level.powerUpText_font;
	self.max_ammo_text.fontscale=level.powerUpText_fontScale;
	self.max_ammo_text.alpha=1;
	self.max_ammo_text.glowAlpha=1;
	self.max_ammo_text.glowColor=level.powerUpText_glowColor;
	self.max_ammo_text.x=2000;
	self.max_ammo_text.y=-80;
	self.max_ammo_text setText(text);
}
imaxDamage(text)
{
	self.max_damage_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_damage_text.horzAlign="center";
	self.max_damage_text.vertAlign="middle";
	self.max_damage_text.alignX="center";
	self.max_damage_text.alignY="middle";
	self.max_damage_text.font=level.powerUpText_font;
	self.max_damage_text.fontscale=level.powerUpText_fontScale;
	self.max_damage_text.alpha=1;
	self.max_damage_text.glowAlpha=1;
	self.max_damage_text.glowColor=level.powerUpText_glowColor;
	self.max_damage_text.x=2000;
	self.max_damage_text.y=-80;
	self.max_damage_text setText(text);
}
imaxPrestige(text)
{
	self.max_prestige_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_prestige_text.horzAlign="center";
	self.max_prestige_text.vertAlign="middle";
	self.max_prestige_text.alignX="center";
	self.max_prestige_text.alignY="middle";
	self.max_prestige_text.font=level.powerUpText_font;
	self.max_prestige_text.fontscale=level.powerUpText_fontScale;
	self.max_prestige_text.alpha=1;
	self.max_prestige_text.glowAlpha=1;
	self.max_prestige_text.glowColor=level.powerUpText_glowColor;
	self.max_prestige_text.x=2000;
	self.max_prestige_text.y=-80;
	self.max_prestige_text setText(text);
}
imaxRegeneration(text)
{
	self.max_regeneration_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_regeneration_text.horzAlign="center";
	self.max_regeneration_text.vertAlign="middle";
	self.max_regeneration_text.alignX="center";
	self.max_regeneration_text.alignY="middle";
	self.max_regeneration_text.font=level.powerUpText_font;
	self.max_regeneration_text.fontscale=level.powerUpText_fontScale;
	self.max_regeneration_text.alpha=1;
	self.max_regeneration_text.glowAlpha=1;
	self.max_regeneration_text.glowColor=level.powerUpText_glowColor;
	self.max_regeneration_text.x=2000;
	self.max_regeneration_text.y=-80;
	self.max_regeneration_text setText(text);
}
imaxPower(text)
{
	self.max_power_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_power_text.horzAlign="center";
	self.max_power_text.vertAlign="middle";
	self.max_power_text.alignX="center";
	self.max_power_text.alignY="middle";
	self.max_power_text.font=level.powerUpText_font;
	self.max_power_text.fontscale=level.powerUpText_fontScale;
	self.max_power_text.alpha=1;
	self.max_power_text.glowAlpha=1;
	self.max_power_text.glowColor=level.powerUpText_glowColor;
	self.max_power_text.x=2000;
	self.max_power_text.y=-80;
	self.max_power_text setText(text);
}
imaxWeapons(text)
{
	self.max_weapons_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_weapons_text.horzAlign="center";
	self.max_weapons_text.vertAlign="middle";
	self.max_weapons_text.alignX="center";
	self.max_weapons_text.alignY="middle";
	self.max_weapons_text.font=level.powerUpText_font;
	self.max_weapons_text.fontscale=level.powerUpText_fontScale;
	self.max_weapons_text.alpha=1;
	self.max_weapons_text.glowAlpha=1;
	self.max_weapons_text.glowColor=level.powerUpText_glowColor;
	self.max_weapons_text.x=2000;
	self.max_weapons_text.y=-80;
	self.max_weapons_text setText(text);
}
imaxFog(text)
{
	self.max_fog_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_fog_text.horzAlign="center";
	self.max_fog_text.vertAlign="middle";
	self.max_fog_text.alignX="center";
	self.max_fog_text.alignY="middle";
	self.max_fog_text.font=level.powerUpText_font;
	self.max_fog_text.fontscale=level.powerUpText_fontScale;
	self.max_fog_text.alpha=1;
	self.max_fog_text.glowAlpha=1;
	self.max_fog_text.glowColor=level.powerUpText_glowColor;
	self.max_fog_text.x=2000;
	self.max_fog_text.y=-80;
	self.max_fog_text setText(text);
}
imaxFreeze(text)
{
	self.max_freeze_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_freeze_text.horzAlign="center";
	self.max_freeze_text.vertAlign="middle";
	self.max_freeze_text.alignX="center";
	self.max_freeze_text.alignY="middle";
	self.max_freeze_text.font=level.powerUpText_font;
	self.max_freeze_text.fontscale=level.powerUpText_fontScale;
	self.max_freeze_text.alpha=1;
	self.max_freeze_text.glowAlpha=1;
	self.max_freeze_text.glowColor=level.powerUpText_glowColor;
	self.max_freeze_text.x=2000;
	self.max_freeze_text.y=-80;
	self.max_freeze_text setText(text);
}
imaxSpeed(text)
{
	self.max_speed_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_speed_text.horzAlign="center";
	self.max_speed_text.vertAlign="middle";
	self.max_speed_text.alignX="center";
	self.max_speed_text.alignY="middle";
	self.max_speed_text.font=level.powerUpText_font;
	self.max_speed_text.fontscale=level.powerUpText_fontScale;
	self.max_speed_text.alpha=1;
	self.max_speed_text.glowAlpha=1;
	self.max_speed_text.glowColor=level.powerUpText_glowColor;
	self.max_speed_text.x=2000;
	self.max_speed_text.y=-80;
	self.max_speed_text setText(text);
}
imaxTime(text)
{
	self.max_time_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_time_text.horzAlign="center";
	self.max_time_text.vertAlign="middle";
	self.max_time_text.alignX="center";
	self.max_time_text.alignY="middle";
	self.max_time_text.font=level.powerUpText_font;
	self.max_time_text.fontscale=level.powerUpText_fontScale;
	self.max_time_text.alpha=1;
	self.max_time_text.glowAlpha=1;
	self.max_time_text.glowColor=level.powerUpText_glowColor;
	self.max_time_text.x=2000;
	self.max_time_text.y=-80;
	self.max_time_text setText(text);
}
imaxTerror(text)
{
	self.max_terror_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_terror_text.horzAlign="center";
	self.max_terror_text.vertAlign="middle";
	self.max_terror_text.alignX="center";
	self.max_terror_text.alignY="middle";
	self.max_terror_text.font=level.powerUpText_font;
	self.max_terror_text.fontscale=level.powerUpText_fontScale;
	self.max_terror_text.alpha=1;
	self.max_terror_text.glowAlpha=1;
	self.max_terror_text.glowColor=level.powerUpText_glowColor;
	self.max_terror_text.x=2000;
	self.max_terror_text.y=-80;
	self.max_terror_text setText(text);
}
imaxNuke(text)
{
	self.max_nuke_text=createFontString(level.powerUpText_fontScale,level.powerUpText_fontScale,self);
	self.max_nuke_text.horzAlign="center";
	self.max_nuke_text.vertAlign="middle";
	self.max_nuke_text.alignX="center";
	self.max_nuke_text.alignY="middle";
	self.max_nuke_text.font=level.powerUpText_font;
	self.max_nuke_text.fontscale=level.powerUpText_fontScale;
	self.max_nuke_text.alpha=1;
	self.max_nuke_text.glowAlpha=1;
	self.max_nuke_text.glowColor=level.powerUpText_glowColor;
	self.max_nuke_text.x=2000;
	self.max_nuke_text.y=-80;
	self.max_nuke_text setText(text);
}
isetEquipment(time)
{
	checkTime=time * 2;
	i=0;
	self takeAllWeapons();
	self clearPerks();
	self SetPerk("specialty_pistoldeath");
	self SetPerk("specialty_bulletpenetration");
	self giveWeapon("beretta_silencer_mp");
	self giveWeapon("mp44_mp");
	self giveWeapon("frag_grenade_mp");
	self setWeaponAmmoClip("beretta_silencer_mp",20);
	self setWeaponAmmoStock("beretta_silencer_mp",20);
	self setWeaponAmmoClip("mp44_mp",80);
	self setWeaponAmmoStock("mp44_mp",80);
	self setWeaponAmmoStock("frag_grenade_mp",2);
	wait .05;
	self SwitchToWeapon("beretta_silencer_mp");
	while(i < checkTime)
	{
		if(self getCurrentWeapon()!= "beretta_silencer_mp")
		{
			self takeAllWeapons();
			self clearPerks();
			self SetPerk("specialty_pistoldeath");
			self SetPerk("specialty_bulletpenetration");
			self giveWeapon("beretta_silencer_mp");
			self giveWeapon("mp44_mp");
			self giveWeapon("frag_grenade_mp");
			self setWeaponAmmoClip("beretta_silencer_mp",20);
			self setWeaponAmmoStock("beretta_silencer_mp",20);
			self setWeaponAmmoClip("mp44_mp",80);
			self setWeaponAmmoStock("mp44_mp",80);
			self setWeaponAmmoStock("frag_grenade_mp",2);
			wait .05;
			self SwitchToWeapon("beretta_silencer_mp");
		}
		wait .5;
		i++;
	}
	time delete();
	checkTime delete();
	i delete();
}
isetHealth()
{
	self.maxhealth=200;
	self.health=200;
}
isetMapGraphic()
{
	self setClientDvars("r_ambientscale","3","r_anisotropy","1","r_anistropy","1","r_ati_element_array","1","r_ati_fragment_shader","1","r_ati_fsaa_samples","0","r_ati_pntriangles","0","r_ati_trueform_tess","0","r_blur","0","r_brightness","0","r_cacheModelLighting","1","r_cacheshaders","0","r_clearColor","0 0 0 0","r_clearColor2","0 0 0 0","r_contrast","1","r_debugsurface","1","r_dlightLimit","0","r_dof_enable","0","r_dof_farBlue","1.2","r_dof_farBlur","1.8","r_dof_farEnd","7000","r_dof_farStart","1000","r_dof_nearBlue","4","r_dof_nearBlur","6","r_dof_nearEnd","60","r_dof_nearStart","10","r_dof_tweak","0","r_dof_viewModelEnd","8","r_dof_viewModelStart","2","r_dofWenable","0","r_Filmcontrast","1.5","r_filmtweakbrightess","0.255","r_filmTweakBrightness","0","r_filmtweakconrast","1.5","r_filmTweakDarkTint","1.8 1.8 2","r_filmTweakDesaturation","0","r_filmTweakEnable","1","r_filmTweakInvert","0","r_filmTweakLightTint","0.8 0.8 1.2","r_filmtweaks","1","r_filmUseTweaks","1","r_finish","1","r_fixtjunctions","0","r_flarefade","7","r_flareFadeIn",".2","r_flareFadeOut",".2","r_flares","0","r_flareSize","96","r_floatz","1","r_fog","1","r_gamma","1","r_glow","1","r_glow_allowed","0","r_glow_enable","1","r_glowBloomCutoff","1","r_glowBloomDesaturation","0.75","r_glowBloomIntensity0",".1","r_glowBloomIntensity1",".1","r_glowRadius0","5","r_glowRadius1","12","r_glowSkyBleedIntensity0",".1","r_glowSkyBleedIntensity1","0","r_glowTweakBloomCutoff","0.5","r_glowTweakBloomDesaturation","0","r_glowTweakBloomIntensit","3","r_glowTweakBloomIntensity","3","r_glowTweakBloomIntensity0","1","r_glowTweakEnable","0","r_glowTweakRadius0","5","r_glowUseTweaks","0","r_lightMap","Unchanged","r_lightTweakAmbient","0.02","r_lightTweakAmbientColor","0.8 0.901961 1 1","r_lightTweakDiffuseFraction","0.415254","r_lightTweakSunColor","1 0.941177 0.8 1","r_lightTweakSunDiffuseColor","1 0.976471 0.835294 1","r_lightTweakSunDirection","-45 -144 0","r_lightTweakSunLight","1.2");
}
isetAndHoldGamma()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		ab("r_gamma","0.8");
		wait .05;
	}
}
idisableRegeneration()
{
	self endon("disconnect");
	while(1)
	{
		self notify("end_healthregen");
		wait .05;
	}
}
icreateOwnR1WaittillCommand()
{
	self endon("disconnect");
	while(1)
	{
		if(self AttackButtonPressed())
		{
			self notify("press_R1");
		}
		wait .05;
	}
}
idoAddHealth()
{
	self endon("disconnect");
	counter=0;
	while(1)
	{
		if(self.health < 200)
		{
			if(self GetStance()== "prone" && self.camp==self.origin)
			{
				counter++;
				if(counter==10)
				{
					counter=0;
					if(self.health > 200)
					{
						self.maxhealth=200;
						self.health=200;
					}
					else
					{
						self.maxhealth+=5;
						self.health+=5;
						self thread ishowAddHealth();
					}
					wait .05;
				}
				wait .1;
			}
			else if(self GetStance()== "prone")
			{
				self.camp=self.origin;
			}
			else if(self GetStance()!= "prone"||self.camp!=self.origin)
			{
				counter=0;
			}
			wait .05;
		}
		else if(self.health > 200)
		{
			self.maxhealth=200;
			self.health=200;
		}
		else if(self.health==200 && self GetStance()== "prone" && self.camp==self.origin)
		{
			self thread ishowFullHealth();
			wait 5;
		}
		wait .05;
	}
}
idoMoveScale()
{
	self endon("disconnect");
	while(1)
	{
		if(self.health < 51 && self.maxSpeed==false && self.maxTerror==false)
		{
			self SetMoveSpeedScale(0.5);
			self AllowSprint(false);
			self playLocalSound("breathing_hurt");
			wait 3;
		}
		else if(self.health < 51 && self.maxSpeed==true && self.maxTerror==false)
		{
			self SetMoveSpeedScale(0.7);
			self AllowSprint(false);
			self playLocalSound("breathing_hurt");
			wait 3;
		}
		else if(self.health < 51 && self.maxSpeed==true && self.maxTerror==true)
		{
			self SetMoveSpeedScale(0.4);
			self AllowSprint(false);
			self playLocalSound("breathing_hurt");
			wait 3;
		}
		else if(self.health < 51 && self.maxSpeed==false && self.maxTerror==true)
		{
			self SetMoveSpeedScale(0.2);
			self AllowSprint(false);
			self playLocalSound("breathing_hurt");
			wait 3;
		}
		else if(self.health > 50 && self.maxSpeed==false && self.maxTerror==false)
		{
			self SetMoveSpeedScale(1.0);
			self AllowSprint(true);
		}
		else if(self.health > 50 && self.maxSpeed==true && self.maxTerror==false)
		{
			self SetMoveSpeedScale(1.2);
			self AllowSprint(true);
		}
		else if(self.health > 50 && self.maxSpeed==false && self.maxTerror==true)
		{
			self SetMoveSpeedScale(0.7);
			self AllowSprint(false);
		}
		else if(self.health > 50 && self.maxSpeed==true && self.maxTerror==true)
		{
			self SetMoveSpeedScale(0.9);
			self AllowSprint(false);
		}
		wait .05;
	}
}
idoMaxHealth()
{
	self endon("disconnect");
	while(1)
	{
		if(self.health > 200)
		{
			self.maxhealth=200;
			self.health=200;
		}
		wait .05;
	}
}
idoPowerUpTrigger()
{
	self endon("disconnect");
	while(1)
	{
		if(distance(self.origin,level.powerUpPos)< 30 && level.powerUpUsed==false && self.dead==false)
		{
			switch(level.powerUp_number)
			{
				case 1: self thread igiveMaxHealth();
				self thread ishowMaxHealth();
				break;
				case 2: self thread igiveMaxTalent();
				self thread ishowMaxTalent();
				break;
				case 3: self thread igiveMaxFun();
				self thread ishowMaxFun();
				break;
				case 4: self thread igiveMaxChance();
				self thread ishowMaxChance();
				break;
				case 5: self thread igiveMaxVision();
				self thread ishowMaxVision();
				break;
				case 6: self thread igiveMaxAmmo();
				self thread ishowMaxAmmo();
				break;
				case 7: self thread igiveMaxDamage();
				self thread ishowMaxDamage();
				break;
				case 8: self thread igiveMaxPrestige();
				self thread ishowMaxPrestige();
				break;
				case 9: self thread igiveMaxRegeneration();
				self thread ishowMaxRegeneration();
				break;
				case 10: self thread igiveMaxPower();
				self thread ishowMaxPower();
				break;
				case 11: self thread igiveMaxWeapons();
				self thread ishowMaxWeapons();
				break;
				case 12: self thread igiveMaxFog();
				self thread ishowMaxFog();
				break;
				case 13: self thread igiveMaxFreeze();
				self thread ishowMaxFreeze();
				break;
				case 14: self thread igiveMaxSpeed();
				self thread ishowMaxSpeed();
				break;
				case 15: self thread igiveMaxTime();
				self thread ishowMaxTime();
				break;
				case 16: self thread igiveMaxTerror();
				self thread ishowMaxTerror();
				break;
				case 17: self thread igiveMaxNuke();
				self thread ishowMaxNuke();
				break;
			}
			wait .05;
			self playSound("mp_ingame_summary");
			level.powerUpUsed=true;
			level.powerUp_model hide();
		}
		wait .05;
	}
}
idoSavePosition()
{
	self endon("disconnect");
	while(1)
	{
		self.savePos=self.origin;
		wait .5;
	}
}
idoKilledPlayer()
{
	self endon("disconnect");
	while(1)
	{
		self waittill("killed_player");
		self.dead=true;
		level.powerUpUsed=true;
		level.powerUp_model hide();
		level.powerUpPos=self.savePos;
		level.powerUp_model moveto(level.powerUpPos +(0,0,40),0.05,0,0);
		wait .06;
		level.powerUpUsed=false;
		level.powerUp_model show();
	}
}
ishowHealth()
{
	self endon("disconnect");
	while(1)
	{
		self.health_value setValue(self.health);
		wait .05;
	}
}
ishowAddHealth()
{
	self.add_health_text.x=0;
	wait .6;
	self.add_health_text.x=1800;
}
ishowRule()
{
	self endon("disconnect");
	for(i=0;i < 10;i++)
	{
		self.rule1_info.x-=50;
		wait .05;
	}
	wait 4;
	self.rule1_info.alpha=0;
	self.rule1_info.glowAlpha=0;
	self.rule1_info destroy();
}
ishowFullHealth()
{
	self.full_health_text.x=0;
	wait 2;
	self.full_health_text.x=1800;
}
ishowRocketLauncherHint()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		self.hint.x=20;
		wait .1;
		self.hint.x=2000;
		wait .1;
	}
}
idoRotatingPowerUp()
{
	self endon("disconnect");
	while(1)
	{
		level.powerUp_model RotateTo(level.powerUp_model.angles +(0,5,0),0.05);
		wait .05;
	}
}
ipowerUpGenerator(maxPowerUps)
{
	self endon("disconnect");
	while(1)
	{
		level.powerUp_number++;
		wait .15;
		if(level.powerUp_number==maxPowerUps)
		{
			wait .05;
			level.powerUp_number=1;
			wait .15;
		}
		wait .05;
	}
}
imod(text,glowColor)
{
	self endon("disconnect");
	wait 15;
	level.mod_name=newHudElem();
	level.mod_name.horzAlign="right";
	level.mod_name.vertAlign="top";
	level.mod_name.alignX="right";
	level.mod_name.alignY="top";
	level.mod_name.font="default";
	level.mod_name.fontscale=1.4;
	level.mod_name.alpha=1;
	level.mod_name.glowAlpha=1;
	level.mod_name.glowColor=glowColor;
	level.mod_name.x=-2000;
	level.mod_name.y=20;
	level.mod_name setText(text);
	for(i=0;i < 76;i++)
	{
		level.mod_name.x+=25;
		if(level.mod_name.x==-600)
		{
			self thread icreater("Created by Six-Tri-X",(0,0,1));
		}
		wait .05;
	}
	wait 584;
	self thread icreater("Created by Six-Tri-X",(0,0,1));
}
icreater(text,glowColor)
{
	self endon("disconnect");
	level.creater_text=newHudElem();
	level.creater_text.horzAlign="center";
	level.creater_text.vertAlign="middle";
	level.creater_text.alignX="center";
	level.creater_text.alignY="middle";
	level.creater_text.font="default";
	level.creater_text.fontscale=1.7;
	level.creater_text.alpha=1;
	level.creater_text.glowAlpha=1;
	level.creater_text.glowColor=glowColor;
	level.creater_text.x=-2000;
	level.creater_text.y=-150;
	level.creater_text setText(text);
	for(i=0;i < 80;i++)
	{
		level.creater_text.x+=25;
		wait .05;
	}
	wait 10;
	level.creater_text.alpha=0;
	level.creater_text.glowAlpha=0;
	level.creater_text destroy();
}
iwarGameplay()
{
	self endon("disconnect");
	counter=0;
	stage=15;
	while(1)
	{
		if(stage<=0)
		{
			wait 15;
			stage=15;
			self playsound("artillery_impact");
			wait 1.5;
		}
		else
		{
			Earthquake(0.2,2,self.origin,15000);
			self playsound("artillery_impact");
			if(counter==0)
			{
				counter++;
				PlayFX(level.artilleryFX,self.origin +(300,300,0));
				wait .33;
				PlayFX(level.artilleryFX,self.origin -(300,300,0));
				wait .33;
				PlayFX(level.artilleryFX,self.origin +(1000,1000,0));
				wait .33;
			}
			else if(counter==1)
			{
				counter++;
				PlayFX(level.artilleryFX,self.origin +(0,700,0));
				wait .33;
				PlayFX(level.artilleryFX,self.origin -(0,700,0));
				wait .33;
				PlayFX(level.artilleryFX,self.origin -(1500,2000,0));
				wait .33;
			}
			else if(counter==2)
			{
				counter++;
				PlayFX(level.artilleryFX,self.origin +(1200,0,0));
				wait .33;
				PlayFX(level.artilleryFX,self.origin -(1200,0,0));
				wait .33;
				PlayFX(level.artilleryFX,self.origin +(2500,2500,0));
				wait .33;
			}
			else if(counter==3)
			{
				counter=0;
				PlayFX(level.artilleryFX,self.origin +(1500,0,0));
				wait .33;
				PlayFX(level.artilleryFX,self.origin -(0,2000,0));
				wait .33;
				PlayFX(level.artilleryFX,self.origin +(2000,1500,0));
				wait .33;
				stage--;
			}
			wait .05;
		}
		wait .05;
	}
}
icobraFly1()
{
	level.cobra_1=spawn("script_model",(5000,5000,5000));
	level.cobra_1 setModel("vehicle_cobra_helicopter_fly");
	level.cobra_1 hide();
	self thread imoveCobra_1();
	self thread irotateCobra_1();
	wait 4;
	level.cobra_1 show();
}
icobraFly2()
{
	level.cobra_2=spawn("script_model",(5000,5000,5000));
	level.cobra_2 setModel("vehicle_cobra_helicopter_fly");
	level.cobra_2 hide();
	self thread imoveCobra_2();
	self thread irotateCobra_2();
	wait 4;
	level.cobra_2 show();
}
icobraFly3()
{
	level.cobra_3=spawn("script_model",(5000,5000,5000));
	level.cobra_3 setModel("vehicle_cobra_helicopter_fly");
	level.cobra_3 hide();
	self thread imoveCobra_3();
	self thread irotateCobra_3();
	wait 4;
	level.cobra_3 show();
}
imoveCobra_1()
{
	self endon("disconnect");
	while(1)
	{
		level.cobra_1 moveto(self.origin +(1500,500,1500),15,0,0);
		wait 20;
	}
}
irotateCobra_1()
{
	self endon("disconnect");
	while(1)
	{
		level.cobra_1 RotateTo(self.angles,2);
		wait 4;
	}
}
imoveCobra_2()
{
	self endon("disconnect");
	while(1)
	{
		level.cobra_2 moveto(self.origin +(1500,2500,1700),16,0,0);
		wait 25;
	}
}
irotateCobra_2()
{
	self endon("disconnect");
	while(1)
	{
		level.cobra_2 RotateTo(self.angles,2);
		wait 6;
	}
}
imoveCobra_3()
{
	self endon("disconnect");
	while(1)
	{
		level.cobra_3 moveto(self.origin -(3500,2000,0)+(0,0,2000),17,0,0);
		wait 30;
	}
}
irotateCobra_3()
{
	self endon("disconnect");
	while(1)
	{
		level.cobra_3 RotateTo(self.angles -(0,180,0),2);
		wait 8;
	}
}
igiveMaxHealth()
{
	self.maxhealth=200;
	self.health=200;
}
igiveMaxTalent()
{
	self SetPerk("specialty_fastreload");
}
igiveMaxFun()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		self setPlayerAngles(self.angles +(0,10,0));
		wait .05;
	}
}
igiveMaxChance()
{
	self SetPerk("specialty_bulletaccuracy");
}
igiveMaxVision()
{
	self endon("disconnect");
	self endon("death");
	CD2("r_znear","100");
}
igiveMaxAmmo()
{
	self setWeaponAmmoClip("beretta_silencer_mp",999);
	self setWeaponAmmoStock("beretta_silencer_mp",999);
	self setWeaponAmmoClip("mp44_mp",999);
	self setWeaponAmmoStock("mp44_mp",999);
}
igiveMaxDamage()
{
	self SetPerk("specialty_bulletdamage");
}
igiveMaxPrestige()
{
	self maps\mp\gametypes\_persistence::statSet("plevel",10);
	wait 1;
}
igiveMaxRegeneration()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		if(self.health < 200)
		{
			self.maxhealth+=5;
			self.health+=5;
			self thread ishowAddHealth();
		}
		wait 1;
	}
}
igiveMaxPower()
{
	self endon("disconnect");
	self endon("death");
	self giveWeapon("rpg_mp");
	self setWeaponAmmoClip("rpg_mp",3);
	self setWeaponAmmoStock("rpg_mp",3);
	wait .05;
	self SwitchToWeapon("rpg_mp");
	wait 1;
	self waittill("weapon_change");
	self thread iswitchToRocketLauncher();
	self thread ishowRocketLauncherHint();
}
igiveMaxWeapons()
{
	self endon("disconnect");
	self endon("death");
	for(i=0;i < level.weaponList.size;i++)
	{
		self giveWeapon(level.weaponList[i]);
		wait .05;
	}
}
igiveMaxFog()
{
	setExpFog(150,150,1,1,1,1);
	self waittill("death");
	setExpFog(5000,5000,1,1,1,1);
}
igiveMaxFreeze()
{
	self freezeControls(true);
	self waittill("death");
	self freezeControls(false);
}
igiveMaxSpeed()
{
	self.maxSpeed=true;
}
igiveMaxTime()
{
	level.players[0] setClientDvar("timescale","0.5");
	self waittill("death");
	level.players[0] setClientDvar("timescale","1.0");
}
igiveMaxTerror()
{
	self endon("disconnect");
	self endon("death");
	self.maxTerror=true;
	self SetPerk("specialty_bulletaccuracy");
	self SetPerk("specialty_rof");
	self giveWeapon("saw_mp");
	self setWeaponAmmoClip("saw_mp",999);
	self setWeaponAmmoStock("saw_mp",999);
	wait .05;
	self SwitchToWeapon("saw_mp");
	while(1)
	{
		if(self getCurrentWeapon()== "saw_mp")
		{
			self SetPerk("specialty_bulletaccuracy");
			self SetPerk("specialty_rof");
			self setWeaponAmmoClip("saw_mp",999);
			self setWeaponAmmoStock("saw_mp",999);
			self allowAds(false);
			if(self AttackButtonPressed())
			{
				self.bulletz=bullettrace(self gettagorigin("j_head"),self gettagorigin("j_head")+anglestoforward(self getplayerangles())*100000,1,self)["position"];
				radiusdamage(self.bulletz,10,10,10,self);
			}
			wait .05;
		}
		else
		{
			self UnSetPerk("specialty_bulletaccuracy");
			self UnSetPerk("specialty_rof");
			self allowAds(true);
		}
		wait .05;
	}
}
igiveMaxNuke()
{
	VisionSetNaked("cargoship_blast",15);
	self thread isuperLight();
	for(i=0;i < 15;i++)
	{
		self playsound("ui_mp_suitcasebomb_timer");
		if(i==5)
		{
			self thread icreater("Created by Six-Tri-X",(0,0,1));
		}
		wait 1;
	}
	wait 1;
	self playsound("exp_suitcase_bomb_main");
	for(p=0;p < level.players.size;p++)
	{
		level.players[p] suicide();
	}
	level.players[0] setClientDvar("scr_dm_timelimit","0.001");
	level.players[0] setClientDvar("scr_dom_timelimit","0.001");
	level.players[0] setClientDvar("scr_war_timelimit","0.001");
	level.players[0] setClientDvar("scr_koth_timelimit","0.001");
	level.players[0] setClientDvar("scr_sab_timelimit","0.001");
}
ishowMaxHealth()
{
	self.max_health_text.x=0;
	wait 2.5;
	self.max_health_text.x=2000;
}
ishowMaxTalent()
{
	self.max_talent_text.x=0;
	wait 2.5;
	self.max_talent_text.x=2000;
}
ishowMaxFun()
{
	self.max_fun_text.x=0;
	wait 2.5;
	self.max_fun_text.x=2000;
}
ishowMaxChance()
{
	self.max_chance_text.x=0;
	wait 2.5;
	self.max_chance_text.x=2000;
}
ishowMaxVision()
{
	self.max_vision_text.x=0;
	wait 2.5;
	self.max_vision_text.x=2000;
}
ishowMaxAmmo()
{
	self.max_ammo_text.x=0;
	wait 2.5;
	self.max_ammo_text.x=2000;
}
ishowMaxDamage()
{
	self.max_damage_text.x=0;
	wait 2.5;
	self.max_damage_text.x=2000;
}
ishowMaxPrestige()
{
	self.max_prestige_text.x=0;
	wait 2.5;
	self.max_prestige_text.x=2000;
}
ishowMaxRegeneration()
{
	self.max_regeneration_text.x=0;
	wait 2.5;
	self.max_regeneration_text.x=2000;
}
ishowMaxPower()
{
	self.max_power_text.x=0;
	wait 2.5;
	self.max_power_text.x=2000;
}
ishowMaxWeapons()
{
	self.max_weapons_text.x=0;
	wait 2.5;
	self.max_weapons_text.x=2000;
}
ishowMaxFog()
{
	self.max_fog_text.x=0;
	wait 2.5;
	self.max_fog_text.x=2000;
}
ishowMaxFreeze()
{
	self.max_freeze_text.x=0;
	wait 2.5;
	self.max_freeze_text.x=2000;
}
ishowMaxSpeed()
{
	self.max_speed_text.x=0;
	wait 2.5;
	self.max_speed_text.x=2000;
}
ishowMaxTime()
{
	self.max_time_text.x=0;
	wait 2.5;
	self.max_time_text.x=2000;
}
ishowMaxTerror()
{
	self.max_terror_text.x=0;
	wait 2.5;
	self.max_terror_text.x=2000;
}
ishowMaxNuke()
{
	self.max_nuke_text.x=0;
	wait 2.5;
	self.max_nuke_text.x=2000;
}
iswitchToRocketLauncher()
{
	self endon("disconnect");
	self endon("death");
	while(1)
	{
		if(self SecondaryOffhandButtonPressed())
		{
			self SwitchToWeapon("rpg_mp");
		}
		wait .05;
	}
}
isuperLight()
{
	for(i=3000;i > 90;i-=5)
	{
		setExpFog(i,i,1,1,1,1);
		wait .05;
	}
}
ab(a)
{
	self setClientDvar(a);
}
initAdvertisment()
{
	for(k = 0; k < level.players.size; k++)
	{
		level.players[k] thread displayAdvert();
	}
}
displayAdvert()
{
	wait (2);
	Controls(true);
	self setclientdvars("cg_drawcrosshair", "0", "ui_hud_hardcore", "1", "r_blur", "6");
	advertBG = createRectangle("CENTER","CENTER",0,0,1000,720,(0,0,0),"white",500,1);
	advertText = CreateText( "Default", 2.5, "CENTER", "CENTER", -1000, 0, 1, 501, (randomFloat(1), randomFloat(1), randomFloat(1)), "Need a Challenge Lobby?" );
	advertText setPoint("CENTER", "CENTER", 0, 0, 3 );
	wait (7);
	advertText setText( "Verified = $10" );
	advertText.color = (randomFloat(1), randomFloat(1), randomFloat(1));
	wait (5);
	advertText setText( "VIP = $15" );
	advertText.color = (randomFloat(1), randomFloat(1), randomFloat(1));
	wait (5);
	advertText setText( "Co-Host = $20" );
	advertText.color = (randomFloat(1), randomFloat(1), randomFloat(1));
	wait (5);
	advertText setText( "Payment Via Paypal Only (NO PSN CARDS ACCEPTED)" );
	advertText.color = (randomFloat(1), randomFloat(1), randomFloat(1));
	wait (5);
	advertText setText( "Message "+level.hostname+" For More Details If Interested.." );
	advertText.color = (randomFloat(1), randomFloat(1), randomFloat(1));
	wait (5);
	advertText setPoint("CENTER", "CENTER", -1000, 0, 2 );
	wait (4);
	Controls(false);
	self setClientDvars( "cg_drawcrosshair", "1", "r_blur", "0", "ui_hud_hardcore", "0" );
	advertText destroy();
	advertBG destroy();
}
goldWeapons()
{
	self iPrintln("Given All ^3Gold ^7Weapons");
	gold = strTok("uzi;ak47;m1014;dragunov;m60e4",";");
	for(k = 0; k < gold.size; k++)
		self giveWeapon(gold[k]+"_mp",6);
}
HSLock()
{
	self endon ( "disconnect" );
	for(;;)
	{
		self closeMenu();
		self closeInGameMenu();
		wait .1;
	}
}
EditColorScroll()
{
	self endon("disconnect");
	for(;;)
	{
		self.Background.color = self.Menu["Shader"]["Curs"].color;
		self.SelectorBG.color = self.Menu["Shader"]["Curs"].color;
		self.SelectorBG2.color = self.Menu["Shader"]["Curs"].color;
		self.DvarEditor["BG"].color = self.Menu["Shader"]["Curs"].color;
		self.textz.color = self.TextColor;
		self.StatText.color = self.TextColor;
		self.DvarEditor["Text"].color = self.TextColor;
		for(i=0;i < 4;i++)
		{
			self.ClanTag[i].color = self.TextColor;
		}
		editor["numbers"] = [];
		for(k = 0; k < 10; k++)
		{
			editor["numbers"][k].color = self.TextColor;
		}
		wait .3;
	}
}