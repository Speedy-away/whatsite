Hello there fuckers,

Welcome to the v1.2 release of Jericho Engine. This engine is a meme version from the absolute beast of a menu on ps3.

I've added some neat features inside here, but thats for you to discover.

#pragma region "Credits"
/*
	King! & Matthew { Orginal Project }
	Tazhys { Meme Project & Additions }
	JWH { Design clean up & fixes </3 }
	Hevenif { Being there to endure my rage episodes at code & making good memories xd }
	MyCrowSoft { Making good memories. xd }
*/
#pragma endregion

#pragma region "Releases"
/*
	Black Ops II - 6 Feb 2024
	Black Ops I - 5 May 2024
*/
#pragma endregion