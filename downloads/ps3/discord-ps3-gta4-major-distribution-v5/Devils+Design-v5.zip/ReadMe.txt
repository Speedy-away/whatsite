SUB TO MY WWW.YOUTUBE.COM/ISOTEKK1
RECRUTING ISO CLAN MESSAGE ME ON YOUTUBE
OR ON XBOX LIVE GT:ISOTEKK1 WHANT THIS MODS
GO TO EBAY.COM/USER TEKK1ISO
L@@k FOR THE LOGO THAT HAS IT(RED&WHITE)


                          .-----------------TTTT_-----_______
                        /''''''''''(______O] ----------____  \______/]_
     __...---'"""\_ --''             www.YOUTUBE.COM/ISOTEKK1___________@      
 |'''                   ._   _______________=---------"""""""
 |                ..--''|   l L |_l   |
 |          ..--''      .  /-___j '   '
 |    ..--''           /  ,       '   '
 |--''                /           `    \
                      L__'         \    -
                                    -    '-.
                                     '.    /
                                       '-./