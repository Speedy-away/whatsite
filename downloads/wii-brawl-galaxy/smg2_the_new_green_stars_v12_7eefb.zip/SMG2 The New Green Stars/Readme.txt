Drag these two folders inside the root of your SD card, activate the hack in riivolution and have fun :)


Thanks for playing :D