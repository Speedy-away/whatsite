enigma.SlopeForce = 80
