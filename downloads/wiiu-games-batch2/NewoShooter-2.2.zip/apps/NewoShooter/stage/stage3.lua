--[[

Stage: 3
Title: Tunnel

This is a LUA script for the Game called "NewoShooter"

VISIT THE "NEWO SHOOTER" PAGE ON HTTP://WWW.WIIBREW.ORG FOR MORE INFO
DEVELOPED BY OWEN ( HTTP://WWW.OWENSOFT.NET )

Hopefully this way I can get other people to help build stages and interactions
I may add new features and options to the API, check the game's on the wiibrew.org wiki

Version: 1
Game Version: 1.65


--]]

--system

require("global.lua")

--[[
Add stuff to the level, run once
--]]

function level_setup()

	game_reset();

	ge.stage_objectloop=false; --stop recycling objects, saves cpu cycles, maybe
	ge.stage_has_floor=true;
	ge.stage_gravity=-5;
	ge.stage_floor_color=GRRLIB_AQUA;

	ge.effect_fog=true;
	ge.effect_fog_color=GRRLIB_AQUA;

	ge.effect_stardust=true;
	ge.effect_stardust_color=GRRLIB_WHITE;

	tunnel_model1=17;

	load_model( "model/stagetunnel01.obj", "model/stagetunnel01.png", tunnel_model1 );	--obj file, texture, index location

	set_texture(10, "stage/image/groundtexture01.png"); --ground texture

	t=0; d=25;
	--zmark is the starting point of the tunnel
	--tunnel_depth is the thickness of each tunnel section
	--turn amount is speed at which each section is moved to the left or right
	z_mark=-2500; tunnel_depth=1400; turn_amount=tunnel_depth/10;
	turning=true;

	skip_next=false;
	growing=false;
	xs=tunnel_depth/2;
	ys=tunnel_depth/2;
	zs=tunnel_depth/2;

	for i=50, 110, 1 do --build a long tunnel

		if skip_next == false then

			set_obj_type( i, TUNNEL, 0 );
			set_obj_point( i, t, 0, z_mark );
			set_obj_scale( i, xs, ys, zs );
			set_obj_health( i, 5000 );
			set_obj_model(i, tunnel_model1 );

			z_mark=z_mark+-tunnel_depth; --move marker back

			if turning then  t=t+d; end

			if i % 20 == 0 then turning=true; end

			if i == 100 then turning=false; end
			if i == 150 then turning=true; d=turn_amount; end
			if i == 300 then turning=false; end
			if i == 325 then turning=true; end
			if i == 350 then turning=true; d=turn_amount; end
			if i == 450 then turning=false; end
			if i > 400 and i < 450 then xs=xs+10;ys=ys+10;	end
			if i > 450 and i < 500 then xs=xs-10;ys=ys-10;	end

			--change the direction of the turn
			if t > ge.max_x then d=-turn_amount; turning=true; end

			--change the direction of the turn if it goes too far
			if t < ge.min_x then d=turn_amount; turning=true; end

			temp=math.random(1,3);

			cols={};

			if i > 500/2 then
				cols={ GRRLIB_WHITE, GRRLIB_AQUA,GRRLIB_WHITE };
			else
				cols={ GRRLIB_GRAY, GRRLIB_SILVER, GRRLIB_AQUA };
			end

			set_obj_color( i, cols[temp], 0 ); --cycle through random colors

			set_obj_active(i, true);
		end
--[[
--]]
		temp=math.random(0,5);
		if temp == 2 and skip_next==false then --put a random enemy in the middle of the tunnel
	 		set_obj_type( i+1, ENEMY, 0 );
			set_obj_point( i+1, t, 0, z_mark );
			set_obj_active(i+1, true);
			skip_next=true;
		elseif skip_next == true then
			skip_next=false;
		end

	end  --end for

	z_mark=z_mark-2500;
	set_obj_q( 498, BOSS, 0, 0, z_mark );

	z_mark=z_mark-1500;
	set_obj_q( 499, LEVELEND, 0, 0, z_mark);

	game_init();

end --stage setup


--[[
monitor the level, run every frame
--]]

function level_render()
end
