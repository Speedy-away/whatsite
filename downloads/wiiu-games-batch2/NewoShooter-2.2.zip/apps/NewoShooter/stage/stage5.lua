--[[

Stage: 5
Title: Water world

This is a LUA script for the Game called "NewoShooter"

VISIT THE "NEWO SHOOTER" PAGE ON HTTP://WWW.WIIBREW.ORG FOR MORE INFO
DEVELOPED BY OWEN ( HTTP://WWW.OWENSOFT.NET )

Hopefully this way I can get other people to help build stages and interactions
I may add new features and options to the API, check the game's on the wiibrew.org wiki

Version: 1
Game Version: 1.65

--]]

--system

require("global.lua")


--[[
Add stuff to the level, run once
--]]

function plant_hill( i, x, z, model1, c )
	set_obj_q( i, BLOCK, x, -2000, z );
	set_obj_scale( i, 250, 250, 250 );
	set_obj_color( i, c, 0 );
	set_obj_active(i, true);
	set_obj_setup( i, true );
	set_obj_health( i, 10000 );
	set_obj_solid( i, true );
	set_obj_looped( i, true );
	set_obj_model( i, model1 );
	set_obj_aligned( i, 3 );  --align to ground
end

function level_setup()

	game_reset();

	ge.effect_fog=true;
	ge.effect_fog_color=GRRLIB_WHITE;

	ge.stage_has_floor=false;
	ge.stage_gravity=-5;
	ge.effect_landinglights=false;
	ge.terrain_color_threshold=50;
	ge.terrain_height=70;
	ge.terrain_is_animated=true;

	ge.stage_background_color_a=GRRLIB_WHITE;
	ge.stage_background_color_b=GRRLIB_WHITE;

	set_texture(2, "stage/image/moon.png");

	my_maxz=-45000;

	--set up custom stuff

	for i=0,150,1 do --fill the rest of the array with stuff
		temp=math.random(1,3);

		if temp==1 then
			set_obj_type( i, ENEMY, 0 );
			set_obj_point( i, math.random(-700,700), math.random(0, 500), math.random(my_maxz,0) );
			set_obj_active(i, true);
		end
		if temp==3 then
			set_obj_type( i, BUILDING, 0 );
		end
		if temp==2 then
			set_obj_type( i, CLOUD, 0 );
			set_obj_active(i, true);
		end

	end

	set_obj_q( 481, TERRAIN, 0, ge.stage_floor, -16000 );
	set_obj_color( 481, GRRLIB_BLUE, 0 );

	set_obj_q( 482, BOSS, 0, 0, my_maxz );
	set_obj_q( 483, LEVELEND, 0, 0, my_maxz );

	model1=14;
	load_model( "model/asteroids01.obj", "model/asteroids01.png", model1 );
	model2=13;
	load_model( "model/mountain02.obj", "model/mountain02.png", model2 );
	model3=15;
	load_model( "model/mountain01.obj", "model/mountain01.png", model3 );

	--plant_hill( 450, 5000, -15000, model1, GRRLIB_BLACK );
	--plant_hill( 451, -5000, -25000, model1, GRRLIB_BLACK );

	plant_hill( 452, -3500, -3000, model2, GRRLIB_BLACK );
	plant_hill( 453, 1500, -3000, model2, GRRLIB_BLACK );
	plant_hill( 454, -1500, -3000, model3, GRRLIB_BLACK );
	plant_hill( 455, 800, -3500, model2, GRRLIB_BLACK );
	plant_hill( 456, -3000, -4500, model2, GRRLIB_BLACK );
	plant_hill( 457, 2800, -5000, model3, GRRLIB_BLACK );

	plant_hill( 458, -1800, -5500, model2, GRRLIB_BLACK );
	plant_hill( 459, 3500, -5000, model2, GRRLIB_BLACK );
	plant_hill( 460, -1500, -6000, model3, GRRLIB_BLACK );
	plant_hill( 461, 800, -8000, model2, GRRLIB_BLACK );
	plant_hill( 462, -2000, -10000, model2, GRRLIB_BLACK );
	plant_hill( 463, 2500, -12000, model3, GRRLIB_BLACK );

	game_init();

end --stage setup


--[[
monitor the level, run every frame
--]]

function level_render()
end
