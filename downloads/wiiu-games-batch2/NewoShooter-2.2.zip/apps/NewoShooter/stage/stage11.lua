--[[

Stage 11
Title: Starry

This is a LUA script for the Game called "NewoShooter"

VISIT THE "NEWO SHOOTER" PAGE ON HTTP://WWW.WIIBREW.ORG FOR MORE INFO
DEVELOPED BY OWEN ( HTTP://WWW.OWENSOFT.NET )

Hopefully this way I can get other people to help build stages and interactions
I may add new features and options to the API, check the game's page on the wiibrew.org wiki.

Version: 1
Game Version: 1.77

--]]
--system

require("global.lua")

--my colors
bgcolor=0xC9CD54FF
wallcol1=0xFE6D02FF
wallcol2=0x2499ABFF
dustcol=0xFFFFFFFF

--custom stuff

--[[
Add stuff to the level, run once
--]]

function level_setup()
	game_reset();
	ge.stage_objectloop=true;
	ge.stage_fullstop=false;
	ge.stage_gravity=0;
	ge.effect_fog=false;
	ge.effect_fog_color=wallcol2;

	ge.stage_has_floor=false;
	ge.stage_floor_color=wallcol2;

	ge.effect_starhighway=true;
	ge.effect_stardust_color=dustcol;

	background_texture_load( 1, "stage/image/blueplanet.png", 0, 0, 0, 0 );

	i=2;
	zpos=-1000;
	gap=0;
	for i=1,250,1 do
		zpos=zpos-gap;
		gap=math.random(100,300);

		if i % 50 == 0 then
			zpos=zpos-1500 --put a empty field in the enviroment
		end

		set_obj_type( i,  BLOCK, 0 );
		set_obj_point( i, math.random(-2900,2900), math.random(-2900,2900), zpos );
		set_obj_scale( i, math.random(100,400), math.random(100,250), gap );
		set_obj_rotation( i, 0, 0, math.random(80,140), 0,0,0 );

		set_obj_color( i, GRRLIB_BLUE, 0 );

		set_obj_active(i, true);
		set_obj_setup( i, true );
		set_obj_health( i, 1500 );
		set_obj_solid( i, true );
	end

	for i=251,300,1 do --fill the rest of the array with stuff
		set_obj_type( i, ENEMY, 0 );
		set_obj_point( i, math.random(-500,500), math.random(-200, 300), math.random(zpos,0) );
		set_obj_active(i, true);
	end

	zpos=zpos-500;
	set_obj_q( ge.obj_max-2, BOSS, 0, 0, zpos );

	zpos=zpos-2000;
	set_obj_q( ge.obj_max-1, LEVELEND, 0, 0, zpos);

	game_init();

end --stage setup


--[[
monitor the level, run every frame
--]]

function level_render()
end
