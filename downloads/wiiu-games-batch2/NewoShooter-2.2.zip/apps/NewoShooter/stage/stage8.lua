--[[

Stage 8
Title: Piano

This is a LUA script for the Game called "NewoShooter"

VISIT THE "NEWO SHOOTER" PAGE ON HTTP://WWW.WIIBREW.ORG FOR MORE INFO
DEVELOPED BY OWEN ( HTTP://WWW.OWENSOFT.NET )

Hopefully this way I can get other people to help build stages and interactions
I may add new features and options to the API, check the game's on the wiibrew.org wiki.

Version: 1
Game Version: 1.65

--]]
--system

require("global.lua")

--my colors

bgcolor=0xC9CD54FF
wallcol1=0xFE6D02FF
wallcol2=0x2499ABFF
dustcol=0x8D0246FF

--custom stuff

smallwall=250  --Y value of wall
tallwall=750
halfwall=500

lowwall=-100
highwall=400
midwall=0

--this is how the walls are added, one after the other, then repeated
pattern_tab = {

{ highwall, smallwall },
{ lowwall, smallwall },
{ midwall, tallwall },

{ highwall, halfwall },
{ highwall, halfwall },
{ highwall, halfwall },
{ highwall, halfwall },

{ lowwall, halfwall },
{ lowwall, halfwall },

}


--[[
Add stuff to the level, run once
--]]

function level_setup()
	game_reset();
	ge.stage_objectloop=false;
	ge.stage_has_floor=false;
	ge.stage_gravity=-5;
	ge.effect_stardust=true;
	ge.effect_stardust_color=dustcol;
	ge.stage_floor_color=GRRLIB_MAROON;

	ge.effect_fog=true;
	ge.effect_fog_color=bgcolor;

	t=0; d=25;
	--zmark is the starting point of the tunnel
	--tunnel_depth is the thickness of each tunnel section
	--turn amount is speed at which each section is moved to the left or right
	z_mark=-2500;
	tunnel_depth=150;
	turn_amount=70;
	turning=true;
	
	level_length = -45000;

	skip_next=false;
	wallspacing=500;

	pid=1 --pattern_index

	for i=50, 150, 1 do --build a long tunnel

		if skip_next == false then

			if pid >= #pattern_tab then
			  pid=1;
				else
			  pid=pid+1;
			end

			x=0;

			if i % 2==0 then
				x=-200; --shift sligthly to force zigzag
			else
				x=0;
			end

			set_obj_type( i,  BRIDGE, 1 );
			set_obj_point( i, x, pattern_tab[pid][1], z_mark );
			set_obj_scale( i, math.random( 200,2500), pattern_tab[pid][2], 150 );

			z_mark=z_mark+-wallspacing; ---tunnel_depth+move marker back

			cols=GRRLIB_MAROON;

			if i % 20==0 then
				z_mark=z_mark+-2500
			end

			if i % 2==0 then
				cols=wallcol1;
			else
				cols=wallcol2;
			end

			set_obj_color( i, cols, 0 ); --cols[temp] cycle through random colors

			set_obj_active(i, true);
			set_obj_setup( i, true );
			set_obj_health( i, 500 );
			set_obj_solid( i, true );
		end

		temp=math.random(0,10);
		if temp == 2 and skip_next==false then --put a random enemy in the middle of the tunnel
	 		--set_obj_type( i+1, ENEMY, 0 );
			--set_obj_point( i+1, t, 0, z_mark );
			--set_obj_active(i+1, true);
			--skip_next=true;
		elseif skip_next == true then
			skip_next=false;
		end

	end  --end for


	for i=300,350,1 do --fill the rest of the array with stuff
		temp=math.random(1,3);

		if temp==1 then
			set_obj_type( i, ENEMY, 0 );
			set_obj_point( i, math.random(-700,700), math.random(-100, 500), math.random(level_length,0) );
		end
		if temp==2 then
			set_obj_type( i, NOTHING, 0 );
		end
		if temp==3 then
			set_obj_type( i, CLOUD, 0 );
		end

		set_obj_active(i, true);
	end


	set_obj_q( ge.obj_max-2, BOSS, 0, 0, z_mark );

	set_obj_q( ge.obj_max-1, LEVELEND, 0, 0, z_mark);

	game_init();


end --stage setup


--[[
monitor the level, run every frame
--]]

function level_render()
end
