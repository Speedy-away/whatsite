--[[

Stage: 13
Title:

This is a LUA script for the Game called "NewoShooter"

--]]

--system

require("global.lua")


--[[
Add stuff to the level, run once
--]]

function level_setup()

	game_reset();

	ge.effect_fog=true;
	ge.effect_fog_color=GRRLIB_BLUE;

	ge.stage_has_floor=false;
	ge.stage_gravity=-5;
	ge.effect_landinglights=false;
	ge.terrain_color_threshold=50;
	ge.terrain_height=70;
	ge.terrain_is_animated=true;

	ge.stage_background_color_a=GRRLIB_BLACK;
	ge.stage_background_color_b=GRRLIB_WHITE;

	model1=10;

	load_model( "model/envpillar01.obj", "model/envpillar01.png", model1 );
	
	level_length = -45000;

	--set up custom stuff

	for i=0,150,1 do --fill the rest of the array with stuff
		temp=math.random(1,3);

		if temp==1 then
			set_obj_type( i, ENEMY, 0 );
			set_obj_point( i, math.random(-700,700), math.random(0, 400), math.random(level_length,0) );
			set_obj_active(i, true);
		end
		if temp==3 then
			set_obj_type( i, ENEMY, 0 ); --exploding enemy
			set_obj_point( i, math.random(-1700,1700), math.random(0, 400), math.random(level_length,0) );
			set_obj_active(i, true);
		end
		if temp==2 then
			set_obj_type( i, BLOCK, 0 );
			set_obj_point( i, math.random(-1000,1000), math.random(0, 400), math.random(level_length,0) );
			set_obj_color( i, GRRLIB_RED, 0 );
			set_obj_active(i, true);
			set_obj_setup( i, true );
			set_obj_solid( i, true );  --make the building solid
			set_obj_scale( i, 800, 800, 800 );
			set_obj_model( i, model1 );
			set_obj_health( i, 5000 );
		end

	end

	set_obj_q( ge.obj_max-3, TERRAIN, 0, ge.stage_floor, -16000 );
	set_obj_color( ge.obj_max-3, GRRLIB_BLACK, 0 );

	--fire sky causing slowdown
	set_obj_q( ge.obj_max-4, TERRAIN, 0, ge.stage_roof, -16000 );
	set_obj_color( ge.obj_max-4, GRRLIB_BLUE, 0 );


	set_obj_q( ge.obj_max-2, BOSS, 0, 0, level_length );
	set_obj_q( ge.obj_max-1, LEVELEND, 0, 0, level_length );

	game_init();

end --stage setup


