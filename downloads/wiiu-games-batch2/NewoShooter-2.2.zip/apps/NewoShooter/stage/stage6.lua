--[[

Stage 6
Title: Dark City

This is a LUA script for the Game called "NewoShooter"

VISIT THE "NEWO SHOOTER" PAGE ON HTTP://WWW.WIIBREW.ORG FOR MORE INFO
DEVELOPED BY OWEN ( HTTP://WWW.OWENSOFT.NET )

Hopefully this way I can get other people to help build stages and interactions.
I may add new features and options to the API, check the game's on the wiibrew.org wiki

Version: 1
Game Version: 1.65



--]]
--system

require("global.lua")


--[[
Add stuff to the level, run once
--]]

function level_setup()

	game_reset();  --c

	ge.stage_floor_color=GRRLIB_GRAY;

	ge.stage_has_floor=true;
	ge.stage_gravity=-5;

	--background movement flags; 1=left, 2=up, 3=right, 4=scroll down
	background_texture_load( 1, "stage/image/city_clouds.png", 0, 1, 0, 50 );  --move clouds to the left, 0 time, 50 pixels at a time
	background_texture_load( 2, "stage/image/city.png", 0, 0, 0, 0 );  -- 2 is in front of 1

	ge.effect_fog=true;
	ge.effect_fog_color=GRRLIB_BLACK;
	ge.effect_fog_distance=250; --new fog variable, smaller number more fog!

	level_length = -45000;

	--set up custom stuff

	p=0; xs=300; gap=0; height_range=500;
	x=0; y=0; z=0;
	z=-1200;

	--start building further down the map

	for i=0,20,1 do
		z=z + (level_length/20);
		x=ge.min_x*4;
		gap=math.random(0, 5)+7;  --place the free space close to the middle
		if i<4 then
			height_range=100;
		else
			height_range=500;
		end

		for j=1,20,1 do
			if j==gap then --skip this building so the player has a gap
				x=x+150;
				--continue;
			end

			p=(j+(i*20)); --20x20 obj grid, 400 objs

			xs=math.random(100, 300);
			x=x+xs;

			yscale=math.random(10, height_range);
			y=ge.stage_floor+yscale+4; --re-align buildings to floor
			--y=math.random(-1000, 1000)+yscale;

			set_obj_type( p, BLOCK, math.random(0, 3) );
			set_obj_point( p, x-(xs/2), y, z+math.random(0,800) );
			set_obj_scale( p, xs/2, yscale, xs );

			if j+1==gap then
				set_obj_color( p, GRRLIB_RED, 0 );
			else
				set_obj_color( p, GRRLIB_GRAY, -math.random(0,50) );
			end

			set_obj_health( p, 500 );
			set_obj_solid( p, true );

			set_obj_setup( p, true );
			--set_obj_setup() definition:
			--only use the values that I have assigned,
			--do not try to set defaults, this means taht you have to set everything yourself, health, firerate, etc

			set_obj_active( p, true );
		end
    end

	for i=421,500,1 do --fill the rest of the array with clouds and enemys
		t=math.random(1,3);
		z=-math.random(-1000, -level_length);

		if t == 1 then
			set_obj_type( i, ENEMY, 0 );
			set_obj_point( i, math.random(-500,500), math.random(-100, 500), math.random(level_length,0) );
		end
		if t == 2 then
			set_obj_type( i, CLOUD, math.random(0,2) );
		end
		if t == 3 then
			set_obj_type( i, CLOUD, 0 );
		end

		set_obj_active(i, true);
	end

	set_obj_q( ge.obj_max-2, BOSS, 0, 0, level_length );
	set_obj_q( ge.obj_max-1, LEVELEND, 0, 0, level_length );

	game_init();  --c


end --stage setup


--[[
monitor the level, run every frame
--]]

function level_render()
end

count = 0

function test_main()

	if count > 30 then
	--		os.exit()
	else
		count = count + 1
		print("Count "..count)
			print(average(10,15,20))
	end

	-- make table, grouping all data for the same item
	-- input is 2 columns (item, data)

	local A
	while 1 do
	 local l=io.read()
	 if l==nil then break end
	 local _,_,a,b=string.find(l,'"?([_%w]+)"?%s*(.*)$')
	 if a~=A then A=a io.write("\n",a,":") end
	 io.write(" ",b)
	end
	io.write("\n")

end

