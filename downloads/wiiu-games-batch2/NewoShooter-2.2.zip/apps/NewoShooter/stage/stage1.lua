--[[

Stage 1
Title: City on Home Planet

This is a LUA script for the Game called "NewoShooter"

VISIT THE "NEWO SHOOTER" PAGE ON HTTP://WWW.WIIBREW.ORG FOR MORE INFO
DEVELOPED BY OWEN ( HTTP://WWW.OWENSOFT.NET )


Hopefully this way I can get other people to help build stages and interactions.
I may add new features and options to the API, check the game's on the wiibrew.org wiki

This is probably the easiest type of stage to create.  It made up of a table containing
the position of the primary buildings, bosses and the enemies.  Then it randomly adds
clouds, grass and extra buildings to fill up the environment.

Version: 1
Game Version: 1.65

--]]

--system

ge = {} --game environment variables

--object types
 NOTHING= 0
 BUILDING= 1
 ENEMY= 2
 MYSHIP= 3
 METEOR= 4
 ASTEROID= 5
 MINE= 6
 BOSS= 7
 BOSSMINI= 8
 CLOUD= 9
 LEVELEND= 10
 GRASS= 11
 PLAYER= 12
 TUNNEL= 13
 TERRAIN= 14
 BRIDGE=15
 BASIC=16
 BLOCK=17

--primary colours
 GRRLIB_BLACK   =0x000000FF
 GRRLIB_MAROON  =0x800000FF
 GRRLIB_GREEN   =0x008000FF
 GRRLIB_OLIVE   =0x808000FF
 GRRLIB_NAVY    =0x000080FF
 GRRLIB_PURPLE  =0x800080FF
 GRRLIB_TEAL    =0x008080FF
 GRRLIB_GRAY    =0x808080FF
 GRRLIB_SILVER  =0xC0C0C0FF
 GRRLIB_RED     =0xFF0000FF
 GRRLIB_LIME    =0x00FF00FF
 GRRLIB_YELLOW  =0xFFFF00FF
 GRRLIB_BLUE    =0x0000FFFF
 GRRLIB_FUCHSIA =0xFF00FFFF
 GRRLIB_AQUA    =0x00FFFFFF
 GRRLIB_WHITE   =0xFFFFFFFF


--[[
Add stuff to the level, run once
--]]

function level_setup()

	game_reset();  --reset the game engine to blank

	--background_texture_load( int index [1-10], filename, int rotation_amount [0-365], move_direction[0-5], move_speed[1 second=1000], move amount [1= 1 pixel ] );
	background_texture_load( 1, "stage/image/mountain_sky.png", 0, 0, 0, 0 );
	background_texture_load( 2, "stage/image/sun.png", 0.1, 0, 50, 0 );  --rotate 0.1 degrees every half second
	background_texture_load( 3, "stage/image/clouds_small.png", 0, 4, 0, 50 );  --move up, 50 pixels at a time
	background_texture_load( 4, "stage/image/clouds_large.png", 0, 4, 0, 100 );  --move up, 100 pixels at a time
	background_texture_load( 5, "stage/image/mountain.png", 0, 0, 0, 0 );


	set_texture(10, "stage/image/groundtexture01.png"); --ground texture

	ctrltower=9;  -- index we use to identify model when we reference it
	load_model( "model/cmdtower01.obj", "model/cmdtower01.png", ctrltower );-- load a model and its texture

	mountain01=13;  -- index we use to identify model when we reference it
	load_model( "model/mountain01.obj", "model/mountain01.png", mountain01 );-- load a model and its texture

	ge.stage_has_floor=true;
	ge.stage_floor_color=0x32694AFF;
	ge.stage_gravity=-5;  --how fast enemies fall
	ge.effect_landinglights=true; --there are a few effects, only set the ones you need
	ge.effect_stardust_color=0xFFFFFFFF;
	ge.effect_fog_color=0xFFFFFFFF;

	ge.stage_background_color_a=GRRLIB_BLUE;
	ge.stage_background_color_b=GRRLIB_WHITE;

	--note that the game moves from 0 down the negative z axis usually to infinity
	--if you set the z axis to 1000, it will be off screen and looped back to a behind the last thing in the object list
	level_mapinfo={
		{1900,0,-2000, BUILDING, 0}, {-1900,0,-2000, BUILDING, 0}, {1650,0,-2500, BUILDING, 0},
		{ 0,0,-4800, ENEMY, 0},{1730,100,-5500, BUILDING, 1 }, {0,0,-6500, BRIDGE, 0 },
		{1550,0,-7000, BUILDING, 0},{-1100,0,-7500, ENEMY, 0},{1150,0,-8000, BUILDING, 0},
		{-4118,0,-8500, BUILDING, 0},{1510,0,-9500, BUILDING, 0},{-610,0,-9500, BUILDING, 0},

		{110,0,-10000, ENEMY, 0},{-580,0,-10000, BUILDING, 1},{ 580,0,-11500, BUILDING, 2},
		{800,0,-11500, BUILDING, 2},{550,0,-12150, BUILDING, 0},{-650,0,-12150, BUILDING, 0},
		{ 0,0,-13500, BRIDGE, 0 },
		{550,0,-13500, BUILDING, 0},{-350,0,-14350, BUILDING, 2},{-50,120,-15350, BOSS, 2},

		{1000,10,-16000, BUILDING, 0}, {-900,80,-18000, BUILDING, 0}, {550,0,-20000, BUILDING, 0},
		{-300,0,-20600, ENEMY, 0},{130,100,-20400, BUILDING, 1 },{130,100,-21500, BRIDGE, 0 },
		{750,0,-22700, BUILDING, 2},{0,0,-23500, ENEMY, 0},{850,0,-24900, BUILDING, 0},
		{-118,0,-24100, BUILDING, 0},{710,-100,-24900, BUILDING, 0},{-410,0,-25900, BUILDING, 0},
		{210,0,-26200, ENEMY, 0},{-680,0,-27200, BUILDING, 1},{180,0,-28800, BUILDING, 2},
		{600,0,-28300, BUILDING, 0},{ 850,180,-28500, BUILDING, 2},{-350,0,-29150, BUILDING, 0},
		{150,-110,-30350, BUILDING, 0 },{-50,120,-35350, BOSS, 2}, {1000,0,-39250, BUILDING, 0},
		{-50,120,-40350, BRIDGE, 0 },

		{ 0,0,-45000, LEVELEND, 0 },

	};

	c=0;
	spacing=1000;
	arr_count=#level_mapinfo
	for  k,v in pairs(level_mapinfo) do
		if v[5] == nil then v[5]=0; end
		set_obj_type( c, v[4], v[5] );
		--I got lazy so I just placed the buildings evenly down the lenght of the map
		--instead of manually using v[3] to hard code their position, which i had originally planned
		--function set_obj_point( obj_index, x pos, y pos, z pos);
		set_obj_point( c, v[1], v[2], v[3] );
		set_obj_color( c, GRRLIB_WHITE, 0 );
		set_obj_active( c, true);

		if v[4]==BUILDING then
			if v[5]== 1 then
				set_obj_scale( c, 300, 300, 300 );
			end
			if v[5]== 2 then
				set_obj_scale( c, 175, 175, 175 );
			end
			set_obj_rotation( c, 0, math.random(0,360), 0, 0,0,0 );
			set_obj_setup( c, true );
			set_obj_health( c, 500 );
			set_obj_aligned( c, 3 );  --align to ground
			set_obj_solid( c, true );
		end

		c=c+1;
	end


	--fill the rest of the array with clouds, grass and enemys
	--ge.obj_max returns the upper bound of my object array, this is fixed
	--the engine wil crash if you go pass it



	for i=arr_count,350,1 do
		t=math.random(1,3);
		z=math.random( -45000, -1000 );
		if t == 1 then
			set_obj_type( i, CLOUD, math.random(0,2) );
		end
		if t == 2 then
			set_obj_type( i, BLOCK, math.random(0,2) );
			set_obj_point( i, math.random(-4500,4500), 0, z ); --place at rand position
			set_obj_scale( i, 100, 100, 100 );
			--set_obj_model( i, mountain01 );
			set_obj_aligned( i, 3 );  --align to ground
			set_obj_color( i, 0x32694AFF, 0 );
		set_obj_solid( i, true );
		end
		if t == 3 then
			set_obj_type( i, GRASS, 0 );
		end

		--grass and clouds are automagically randomized in game_int but this can be changed

		set_obj_active(i, true); --make object active
	end


	level_tower_info={
		{500,0,-4000, BASIC, 0, 451},
		{-2000,0,-15000, BASIC, 0, 452},
		{550,0,-32000, BASIC, 0, 453},
		{-400,0,-40000, BASIC, 0, 454},
	};

	i=0;
	for  k,v in pairs(level_tower_info) do
		if v[5] == nil then v[5]=0; end
		i=v[6]; --index to put object

		set_obj_scale( i, 500, 500, 500 );
		set_obj_type( i, v[4], v[5] );
		set_obj_model( i, ctrltower );

		set_obj_point( i, v[1], v[2],  v[3] );
		set_obj_color( i, GRRLIB_WHITE, 0 );

		set_obj_active(i, true);
		set_obj_setup( i, true );
		set_obj_health( i, 1500 );
		set_obj_solid( i, true );
		set_obj_aligned( i, 3 );  --align to ground
	end

	-- the level end marker at the end of the stage
	-- put it further to extend the length of the stage.  if it is not set the stage loops forever
	-- set_obj_q( obj_index, obj_type, x pos, y pos, z pos )
	--set_obj_q( ge.obj_max-1, LEVELEND, 0, 0, -45000 );

	game_init();  --init the game and you are done

end --stage setup


function plant_hill( i, x, z, model1, c )
	set_obj_q( i, BLOCK, x, -2000, z );
	set_obj_scale( i, 250, 250, 250 );
	set_obj_color( i, c, 0 );
	set_obj_active(i, true);
	set_obj_setup( i, true );
	set_obj_health( i, 10000 );
	set_obj_solid( i, true );
	set_obj_looped( i, true );
	set_obj_model( i, model1 );
	set_obj_aligned( i, 3 );  --align to ground
end

--[[
monitor the level, run every frame
--]]

function level_render()

	--currently not used

end
