--[[


Stage 7
Title: C79

This is a LUA script for the Game called "NewoShooter"

VISIT THE "NEWO SHOOTER" PAGE ON HTTP://WWW.WIIBREW.ORG FOR MORE INFO
DEVELOPED BY OWEN ( HTTP://WWW.OWENSOFT.NET )

Hopefully this way I can get other people to help build stages and interactions
I may add new features and options to the API, check the game's on the wiibrew.org wiki

Version: 1
Game Version: 1.65

--]]

--system

require("global.lua")


--[[
Add stuff to the level, run once
--]]

function level_setup()

	game_reset();  --c

	ge.stage_has_floor=false;
	ge.stage_gravity=5;

	ge.effect_fog=true;
	ge.effect_fog_color=GRRLIB_WHITE;
	ge.effect_fog_distance=30;  --higher number less fog
	ge.stage_floor=-1000;

	ge.stage_background_color_a=GRRLIB_WHITE;
	ge.stage_background_color_b=GRRLIB_WHITE;

	background_texture_load( 1, "stage/image/lvl7.png", 10, 0, 0, 0 );

	my_maxz= -45000; --end of level


	--set up custom stuff

	p=0; xs=300; gap=0; height_range=500;
	x=0; y=0; z=0;
	z=-1200;

	--start building further down the map

	for i=0,20,1 do
		z=z + (my_maxz/20);
		x=ge.min_x*4;
		gap=math.random(0, 5)+7;  --place the free space close to the middle
		if i<4 then
			height_range=100;
		else
			height_range=500;
		end

		for j=1,20,1 do
			if j==gap then --skip this building so the player has a gap
				x=x+150;
				--continue;
			end

			p=(j+(i*20)); --20x20 obj grid, 400 objs

			xs=math.random(100, 300);
			x=x+xs;

			yscale=math.random(10, height_range);
			--y=ge.stage_floor+yscale; --re-align buildings to floor
			y=math.random(-2000, 2000)+yscale;

			set_obj_type( p, BLOCK, math.random(0, 3) );
			set_obj_point( p, x-(xs/2), y, z+math.random(0,800) );
			set_obj_scale( p, xs/2, yscale, xs );

			if j+1==gap then
				set_obj_color( p, GRRLIB_BLUE, math.random(-50,50)  );
			else
				set_obj_color( p, GRRLIB_AQUA, math.random(-150,150) );
			end

			set_obj_health( p, 500 );
			set_obj_solid( p, true );

			set_obj_setup( p, true );
			set_obj_active( p, true );
		end
    end


	for i=421,497,1 do --fill the rest of the array with clouds and enemys
		t=math.random(1,3);
		z=-math.random(-1000, -my_maxz);

		if t == 1 then
			set_obj_type( i, ENEMY, 0 );
			set_obj_point( i, math.random(-500,500), math.random(-500, 500), math.random(my_maxz,0) );
		end
		if t == 2 then
			set_obj_type( i, CLOUD, 0 );
		end
		if t == 3 then
			set_obj_type( i, CLOUD, 0 );
		end

		set_obj_active(i, true);
	end


	for k=1,10,1 do  --randomly add a random bridge facade, just to mix things up
		i=math.random(150,160);
		set_obj_type( i, BRIDGE, 1 );
		set_obj_scale( i, 6000, 400, 10 );
		if math.random(0,2)==1 then
			set_obj_color( i, GRRLIB_WHITE, 0  );
		else
			set_obj_color( i, GRRLIB_BLACK, 0  );
		end
		set_obj_point( i, 0, math.random(-2500, 2500), math.random(my_maxz,0) );
		set_obj_setup( i, true );
		set_obj_solid( i, true );
	end

	set_obj_q( ge.obj_max-2, BOSS, 0, 0, my_maxz );
	set_obj_q( ge.obj_max-1, LEVELEND, 0, 0, my_maxz-1000 );

	game_init();  --c


end --stage setup

