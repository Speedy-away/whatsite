--[[

Stage: 4
Title: Eternal forest

This is a LUA script for the Game called "NewoShooter"

VISIT THE "NEWO SHOOTER" PAGE ON HTTP://WWW.WIIBREW.ORG FOR MORE INFO
DEVELOPED BY OWEN ( HTTP://WWW.OWENSOFT.NET )

Hopefully this way I can get other people to help build stages and interactions
I may add new features and options to the API, check the game's on the wiibrew.org wiki

Version: 1
Game Version: 1.65


--]]

--system

require("global.lua")


--[[
Add stuff to the level, run once
--]]

function level_setup()

	game_reset();

	background_texture_load( 1, "stage/image/towers.png", 0, 0, 0, 0 );
	
	ge.effect_fog=true;
	ge.effect_fog_color=GRRLIB_OLIVE;

	ge.stage_has_floor=false;
	ge.stage_gravity=-5;
	ge.effect_landinglights=true;
	ge.terrain_color_threshold=100;
	ge.terrain_height=190;

	set_texture(3, "stage/image/moon.png");

	level_length = -45000;

	--set up custom stuff

	for i=0,150,1 do --fill the rest of the array with stuff
		temp=math.random(1,3);

		if temp==1 then
			set_obj_type( i, ENEMY, 0 );
			set_obj_point( i, math.random(-900,900), math.random(-50, 500), math.random(level_length,0) );
		end
		if temp==2 or temp==3 then
			set_obj_type( i, CLOUD, 0 );
		end

		set_obj_active(i, true);
	end

	set_obj_q( ge.obj_max-3, TERRAIN, 0, ge.stage_floor, -16000 );
	set_obj_color( ge.obj_max-3, GRRLIB_GREEN, 0 );

	set_obj_q( ge.obj_max-2, BOSS, 0, 0, level_length );
	set_obj_q( ge.obj_max-1, LEVELEND, 0, 0, level_length );

	ctrltower=9;
	load_model( "model/cmdtower01.obj", "model/cmdtower01.png", ctrltower );

	i=450;
	set_obj_q( i, BLOCK, -1000, 0, -20000 );
	set_obj_scale( i, 9000, 9000, 9000 );
	--set_obj_rotation( i, math.random(0,360), math.random(0,360), math.random(0,360), 0.03,0,0.01 );
	set_obj_color( i, GRRLIB_GREEN, 0 );
	set_obj_active(i, true);
	set_obj_setup( i, true );
	set_obj_health( i, 1500 );
	set_obj_solid( i, false );
	set_obj_fixed( i, true );
	set_obj_model( i, ctrltower );


	game_init();

end --stage setup


--[[
monitor the level, run every frame
--]]

function level_render()
end
