--[[

Stage: 16
Title: ASTEROID FIELD

This is a LUA script for the Game called "NewoShooter"

VISIT THE "NEWO SHOOTER" PAGE ON HTTP://WWW.WIIBREW.ORG FOR MORE INFO
DEVELOPED BY OWEN ( HTTP://WWW.OWENSOFT.NET )

--]]

--system

--at some point I figured out that you can include files, now the constants are
--stored in the /apps/newoshooter/global/lua.lua file.
require("global.lua")


--[[
Add stuff to the level, run once
--]]

function level_setup()

	game_reset();

	background_texture_load( 1, "stage/image/redplanet.png", 0, 0, 0, 0 );

	model1=4;
	model2=5;

	load_model( "model/asteroids01.obj", "model/asteroids01.png", model1 );
	load_model( "model/asteroids02.obj", "model/asteroids02.png", model2 );

	ge.stage_has_floor=false;
	ge.stage_gravity=0;
	ge.effect_stardust=true;
	ge.effect_stardust_color=GRRLIB_WHITE;

	ge.effect_fog=false;
	ge.effect_fog_color=GRRLIB_BLACK;

	level_length = -45000;

	level_mapinfo={
			{300,0,-300, ASTEROID}, {-200,0,-800, ASTEROID, 1}, {150,0,-500, ASTEROID},
			{-300,0,-600, ENEMY},{130,100,-800, ASTEROID, 1 },
			{150,0,-700, ASTEROID},{-300,0,-500, ENEMY},{150,0,-900, ASTEROID},
			{-118,0,-1100, ASTEROID},{210,0,-500, ASTEROID, 2},{-410,0,-200, ASTEROID},
			{410,0,-200, ENEMY},{-180,0,-200, ASTEROID, 1},{180,0,-200, ASTEROID, 2},
			{200,0,-300, ASTEROID},{150,0,-150, ASTEROID},{-150,0,-150, ASTEROID},
			{150,0,-350, ASTEROID},{-50,0,-350, ASTEROID, 2},{210,0,-250, BOSS},

			{300,10,-1200, ASTEROID}, {-200,80,-800, ASTEROID}, {150,0,-1000, ASTEROID},
			{-300,0,-600, ENEMY},{130,100,-900, ASTEROID, 1 },
			{150,0,-700, ASTEROID},{-300,0,-500, ENEMY},{150,0,-900, ASTEROID},
			{-118,0,-1100, ASTEROID},{210,-100,-500, ASTEROID, 1},{-410,0,-200, ASTEROID, 1},
			{410,0,-200, ENEMY},{-180,0,-200, ASTEROID, 1},{180,0,-200, ASTEROID, 2},
			{200,0,-300, ASTEROID},{150,180,-150, ASTEROID,2},{-150,0,-150, ASTEROID},
			{150,-110,-350, ASTEROID},{-50,120,-350, ASTEROID, 2},{210,0,-250, BOSS},


			{300,0,-400, ASTEROID}, {-200,0,-800, ASTEROID, 1}, {150,0,-2000, ASTEROID},
			{-300,0,-600, ENEMY},{130,100,-700, ASTEROID, 1 },
			{150,0,-700, ASTEROID},{-300,0,-500, ENEMY},{150,0,-900, ASTEROID},
			{-118,0,-1100, ASTEROID},{210,0,-500, ASTEROID, 2},{-410,0,-200, ASTEROID},
			{410,0,-200, ENEMY},{-180,0,-200, ASTEROID, 1},{180,0,-200, ASTEROID, 2},
			{200,0,-300, ASTEROID},{150,0,-150, ASTEROID},{-150,0,-150, ASTEROID},
			{150,0,-350, ASTEROID},{-50,0,-350, ASTEROID, 2},{210,0,-250, BOSS, 0},

			{300,10,-2500, ASTEROID}, {-200,80,-800, ASTEROID, 1}, {150,0,-3000, ASTEROID},
			{-300,0,-600, ENEMY},{130,100,-2000, ASTEROID, 1 },
			{150,0,-700, ASTEROID},{-300,0,-500, ENEMY},{150,0,-900, ASTEROID},
			{-118,0,-1100, ASTEROID},{210,-100,-500, ASTEROID, 1},{-410,0,-200, ASTEROID, 1},
			{410,0,-200, ENEMY},{-180,0,-200, ASTEROID, 1},{180,0,-200, ASTEROID, 2},
			{200,0,-300, ASTEROID},{150,180,-150, ASTEROID,2},{-150,0,-150, ASTEROID},
			{150,-110,-350, ASTEROID},{-50,120,-350, BOSS, 0},{210,0,-700, ASTEROID, 2},

	};

	c=0
	spacing=1000
	for  k,v in pairs(level_mapinfo) do
		if v[5] == nil then v[5]=0; end
		set_obj_type( c, v[4], v[5] );

		if v[5]==1 then
			set_obj_model(c, model1 );
		else
			set_obj_model(c, model2 );
		end

		--I got lazy so I just placed the buildings evenly down the lenght of the map
		--instead of using v[3], which i originally planned
		set_obj_point( c, v[1], v[2], ((level_length/#level_mapinfo) * c ) );
		set_obj_active( c, true);
		c=c+1
	end


	for i=100, 300, 1 do --fill the background with asteroids
		set_obj_type( i, ASTEROID, 0 );
		set_obj_model(i, model1 );
		set_obj_color( i, GRRLIB_RED, 0 );
		set_obj_point( i, math.random(-2500, 2500), math.random(-400, 400), math.random( level_length, 100) );
		set_obj_rotation( i, math.random(0,360), math.random(0,360), math.random(0,360), 0.03,0,0.01 );

		set_obj_health( i, 100 );
		set_obj_solid( i, true );
		set_obj_scale( i, 100, 100, 100 );

		set_obj_setup( i, true);
		set_obj_active( i, true);
	end


	set_obj_q( ge.obj_max-1, LEVELEND, 0, 0, level_length );

	game_init();

end --stage setup


--[[
monitor the level, run every frame
--]]

function level_render()
end
