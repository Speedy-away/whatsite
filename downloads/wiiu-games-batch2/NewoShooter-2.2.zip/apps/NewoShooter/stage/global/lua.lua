--[[

This is just a place holder file to prevent compile errors
the file that is actually used by the wii is in: /apps/newoshooter/global/lua.lua


--]]

