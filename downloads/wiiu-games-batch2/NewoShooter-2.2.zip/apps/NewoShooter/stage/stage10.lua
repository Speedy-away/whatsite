--[[

Stage 10
Title: Starry

This is a LUA script for the Game called "NewoShooter"

VISIT THE "NEWO SHOOTER" PAGE ON HTTP://WWW.WIIBREW.ORG FOR MORE INFO
DEVELOPED BY OWEN ( HTTP://WWW.OWENSOFT.NET )

Hopefully this way I can get other people to help build stages and interactions
I may add new features and options to the API, check the game's page on the wiibrew.org wiki.

Version: 1
Game Version: 1.77

--]]
--system

require("global.lua")

--my colors
bgcolor=0xC9CD54FF
wallcol1=0xFE6D02FF
wallcol2=0x2499ABFF
dustcol=0xFFFFFFFF

--custom stuff

--[[
Add stuff to the level, run once
--]]

function level_setup()
	game_reset();
	ge.stage_objectloop=true;
	ge.stage_fullstop=false;
	ge.stage_gravity=0;
	ge.effect_fog=true;
	ge.effect_fog_color=wallcol2;

	ge.stage_has_floor=true;
	ge.stage_floor_color=wallcol2;

	ge.effect_starhighway=true;
	ge.effect_stardust_color=dustcol;

	background_texture_load( 1, "stage/image/moon.png", 0.1, 0, 500, 0 );

	model1=5;
	load_model( "model/mountain03.obj", "model/mountain03.png", model1 );

	i=2;
	zpos=-1000;
	gap=0;
	for i=1,250,1 do
		zpos=zpos-gap;
		gap=math.random(100,300);

		if i % 50 == 0 then
			zpos=zpos-1500 --put a empty field in the enviroment
		end

		set_obj_type( i,  BLOCK, 0 );
		set_obj_point( i, math.random(-2900,2900), -100, zpos );
		set_obj_scale( i, math.random(100,400), math.random(100,250), gap );
		set_obj_rotation( i, 0, 0, math.random(80,140), 0,0,0 );

		set_obj_color( i, GRRLIB_YELLOW, 0 );

		set_obj_active(i, true);
		set_obj_setup( i, true );
		set_obj_health( i, 1500 );
		set_obj_solid( i, true );
	end

	for i=251,300,1 do --fill the rest of the array with stuff
		set_obj_type( i, ENEMY, 0 );
		set_obj_point( i, math.random(-500,500), math.random(-200, 300), math.random(zpos,0) );
		set_obj_active(i, true);
	end

	for i=301,310,1 do  --randomly add a random bridge facade, just to mix things up
		set_obj_type( i, BRIDGE, 1 );
		set_obj_scale( i, 1000, 500, 50 );
		set_obj_color( i, GRRLIB_WHITE, 0  );
		set_obj_point( i, 0, -300, math.random(zpos, 0) );
		set_obj_setup( i, true );
		set_obj_solid( i, true );
		set_obj_active(i, true);
	end


	i=450;
	set_obj_q( i, BLOCK, 9000, 0, -20000 );
	set_obj_scale( i, 9000, 9000, 9000 );
	set_obj_aligned( i, 3 );  --object is constantly aligned to the floor
	--set_obj_rotation( i, math.random(0,360), math.random(0,360), math.random(0,360), 0.03,0,0.01 );
	set_obj_color( i, GRRLIB_YELLOW, 0 );
	set_obj_active(i, true);
	set_obj_setup( i, true );
	set_obj_health( i, 1500 );
	set_obj_solid( i, false );
	set_obj_fixed( i, true );
	set_obj_model( i, model1 );

	zpos=zpos-500;
	set_obj_q( ge.obj_max-2, BOSS, 0, 0, zpos );

	zpos=zpos-1500;
	set_obj_q( ge.obj_max-1, LEVELEND, 0, 0, zpos);

	game_init();

end --stage setup


--[[
monitor the level, run every frame
--]]

function level_render()
end
