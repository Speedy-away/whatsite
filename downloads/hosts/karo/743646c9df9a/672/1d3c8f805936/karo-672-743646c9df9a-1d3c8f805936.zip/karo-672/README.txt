KARO 672 guarded web-host build

Extract the complete ZIP and serve this folder with a static HTTP server. Open index.html. Never execute console files on a PC. The entry stays inert on desktop; use only the matching console browser and firmware after explicit confirmation. Original native sources/payload bytes are unchanged; HTML gets an authored entry gate and path/resource guard. The original host may automatically prepare/load after entry.

Unavailable/corrupt originals are retained under web/_unavailable only as evidence, not offered as runnable downloads. Native PHP endpoints require their original backend and are blocked here. Some original external libraries require Internet. AppCache/offline behaviour and physical console execution remain untested.

Source: https://github.com/KAR0218/KAR0218.github.io/tree/743646c9df9ab4c83821b660c12e23a3dda57b49/672/
Preserve original source attributions. All older website/helper versions are retained.
