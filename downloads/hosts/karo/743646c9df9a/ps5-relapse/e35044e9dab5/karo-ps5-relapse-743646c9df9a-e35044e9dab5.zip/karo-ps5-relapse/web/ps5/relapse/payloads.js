/* generated for Relapse - payload menu */
window.PAYLOAD_TILES = [
    {"title": "etaHEN", "description": "AIO Homebrew enabler with etaHEN Toolbox, plugins, Kstuff, FTP and payload support. Beta 2.6", "name": "etaHEN.elf", "info": "etaHEN.elf - LightningMods", "key": "etahen"},
    {"title": "onionHEN", "description": "Homebrew enabler with kstuff-fpkg-1.13-test6and Toolbox for jailbroken PS5 consoles, built on etaHEN. Version v0.9.0", "name": "OnionHEN.elf", "info": "OnionHEN.elf - aydencharles", "key": "onionhen"},
    {"title": "onionHEN", "description": "Homebrew enabler and Toolbox for jailbroken PS5 consoles, built on etaHEN. Version v0.9.0", "name": "OnionHENk1.11.elf", "info": "OnionHENk1.11.elf - aydencharles", "key": "onionhen"},
    {"title": "ShadowMountPlus", "description": "Fully automated background Auto-Mounter for jailbroken PS5 consoles. Version 1.7beta8", "name": "shadowmountplus.elf", "info": "ShadowMountPlus_1.7beta8.elf - drakmor", "key": "shadowmountplus"},
    {"title": "ps5upload", "description": "Fast, reliable transfers from your computer to your PS5 (requires PC app). Version v5.41.0", "name": "ps5upload_v5.41.0.elf", "info": "ps5upload_v5.41.0.elf - phantomptr", "key": "ps5upload"},
    {"title": "WebKit Autoloader Installer", "description": "Installs WebKit Autoloader on the PS5 homescreen. Version v0.5.2", "name": "WebKit-Autoloader-Installer_v0.5.2.elf", "info": "WebKit-Autoloader-Installer_v0.5.2.elf - itsPLK", "key": "webkit-autoloader-installer"},
    {"title": "ps5debug-NG", "description": "PS5 debugger payload with a userland TCP wire-protocol server. Version 1.3.2", "name": "ps5debug-NG_1.3.2.elf", "info": "ps5debug-NG_1.3.2.elf - Pharaoh2k", "key": "ps5debug-ng"},
    {"title": "PS5Browser", "description": "PS5 Browser. Version v1.0.0", "name": "browser_launcher_v1.0.0.elf", "info": "browser_launcher_v1.0.0.elf - Karo", "key": "PS5Browser"},
    {"title": "zftpd", "description": "Zero-copy FTP/HTTP server. Version v1.6.0", "name": "zftpd_v1.6.0.elf", "info": "zftpd_v1.6.0.elf - seregonwar", "key": "zftpd"},
    {"title": "CheatRunner", "description": "Web-based game cheat trainer. Version v0.17.1", "name": "CheatRunner_v0.17.1.elf", "info": "CheatRunner_v0.17.1.elf - notmaj0r", "key": "cheatrunner"},
    {"title": "ftpsrv-drakmor", "description": "drakmor's fork of ftpsrv. Version 1.16-ng-stable", "name": "ftpsrv-drakmor_1.16-ng-stable.elf", "info": "ftpsrv-drakmor_1.16-ng-stable.elf - drakmor", "key": "ftpsrv-drakmor"},
    {"title": "garlic-savemgr", "description": "PS5 save decrypt/encrypt/browse utility with embedded web UI. Version v1.13.1", "name": "garlic-savemgr_v1.13.1.elf", "info": "garlic-savemgr_v1.13.1.elf - earthonion", "key": "garlic-savemgr"},
    {"title": "kstuff-lite", "description": "Lite version of kstuff. Version v1.11", "name": "kstuff-lite_v1.11.elf", "info": "kstuff-lite_v1.11.elf - EchoStretch", "key": "kstuff-lite"},
    {"title": "Lapy-JB-Daemon", "description": "Standalone homebrew jailbreak daemon for PS5. Version v1.2", "name": "Lapy-JB-Daemon_v1.2.elf", "info": "Lapy-JB-Daemon_v1.2.elf - Lapy", "key": "lapy-jb-daemon"},
    {"title": "PKG-Manager", "description": "Browse and install PKGs from USB, disc, or SMB shares directly on your PS5. Version v1.4.1", "name": "PKG-Manager_v1.4.1.elf", "info": "PKG-Manager_v1.4.1.elf - itsPLK", "key": "pkg-manager"},
    {"title": "pldmgr", "description": "Modern web dashboard to manage, import, and automatically load payloads on your PS5. Version v0.5.2", "name": "pldmgr_v0.5.2.elf", "info": "pldmgr_v0.5.2.elf - itsPLK", "key": "pldmgr"},
    {"title": "ps5-app-dumper", "description": "Dumps PS5 application files from pfsmnt to a connected USB storage device. Version v2.00", "name": "ps5-app-dumper_v2.00.elf", "info": "ps5-app-dumper_v2.00.elf - EchoStretch", "key": "ps5-app-dumper"}
];
window.PAYLOAD_ART = { dir: "ui/", pfx: "btn-", on: true };
